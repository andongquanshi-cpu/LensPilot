package com.clj.fastble.data;

import android.util.Log;

import java.util.Arrays;

/**
 * Insta360蓝牙配置文件管理(修订)
 * doc: https://arashivision.feishu.cn/wiki/TbEIwPNjiigYY2kEVLvcUwZrn6f
 */
public class BleScanProto {

    public final static int BOOT_UP_STATUS_SHUT_DOWN = 0;
    public final static int BOOT_UP_STATUS_NORMAL_BOOT_UP = 1;
    public final static int BOOT_UP_STATUS_UNCONNECTABLE = 2; // 低电(或其他不可连接状态)
    public final static int BOOT_UP_STATUS_QUICK_CAPTURE = 3;

    public final static int WIFI_CLOSE = 0;
    public final static int WIFI_UNINITIALIZED = 255;

    public final static String PROTO_Z03 = "Luna Ultra";
    public final static String PROTO_Z05 = "Luna Pro";

    /**
     * @param manufacturerData 蓝牙广播中厂商数据 data
     * @return proto
     */
    public static BleScanProto parse(byte[] manufacturerData) {
        if (manufacturerData == null) {
            return null;
        }
        if ((manufacturerData[2] & 0x1F) == 2 && manufacturerData.length > 3) { // TC4、TRC
            // 获取广播版本，第12字节的低5位表示广播版本号
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.deviceType = manufacturerData[0]; // 广播中代表相机型号的字节
            bleScanProto.wifiActiveTimeS = manufacturerData[1];
            bleScanProto.protoVersion = manufacturerData[2] & 0x1F;
            bleScanProto.wifiPWDVersion = manufacturerData[2] & 0xE0;
            bleScanProto.bootUpStatus = getStatus(manufacturerData[3]);
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
//            Log.i("BleScanProto", "tc4, bleScanProto=" + bleScanProto + ", manufacturerData=" + Arrays.toString(manufacturerData));
            return bleScanProto;
        } else if (manufacturerData[2] == 3 && manufacturerData.length > 3) { //Z03 出货版
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.wifiActiveTimeS = manufacturerData[3];
            bleScanProto.nfcCrc = manufacturerData[4];
            bleScanProto.bootUpStatus = BOOT_UP_STATUS_NORMAL_BOOT_UP;
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
            bleScanProto.deviceNamePrefix = PROTO_Z03;
//            Log.i("BleScanProto", "z0, bleScanProto=" + bleScanProto + ", manufacturerData=" + Arrays.toString(manufacturerData));
            return bleScanProto;
        } else if (manufacturerData[2] == 5 && manufacturerData.length > 3) { //Z05 出货版
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.wifiActiveTimeS = manufacturerData[3];
            bleScanProto.nfcCrc = manufacturerData[4];
            bleScanProto.bootUpStatus = BOOT_UP_STATUS_NORMAL_BOOT_UP;
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
            bleScanProto.deviceNamePrefix = PROTO_Z05;
//            Log.i("BleScanProto", "z0, bleScanProto=" + bleScanProto + ", manufacturerData=" + Arrays.toString(manufacturerData));
            return bleScanProto;
        } else if (manufacturerData[2] == 0 && manufacturerData.length == 5) { // 历史版本
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.wifiActiveTimeS = manufacturerData[3] & 0x0FF;
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
            bleScanProto.wifiPWDVersion = manufacturerData[4] & 0x0FF;
            bleScanProto.bootUpStatus = BOOT_UP_STATUS_NORMAL_BOOT_UP;
//            Log.i("BleScanProto", "length=3, bleScanProto=" + bleScanProto + ", fullManufacturerData==" + Arrays.toString(bytes));
            return bleScanProto;
        } else if (manufacturerData[2] == 0 && manufacturerData.length == 6) { // C9
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.wifiActiveTimeS = manufacturerData[3] & 0x0FF;
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
            bleScanProto.wifiPWDVersion = manufacturerData[4] & 0x0FF;
            bleScanProto.bootUpStatus = BOOT_UP_STATUS_NORMAL_BOOT_UP;
            // 相机启动的网络类型：AP = 0; STA = 1; P2P = 2; Android_Aware = 3; IOS_Aware = 4;
            bleScanProto.netType = manufacturerData[5];
//            Log.i("BleScanProto", "C9, bleScanProto=" + bleScanProto + ", fullManufacturerData==" + Arrays.toString(bytes));
            return bleScanProto;
        } else if (manufacturerData[2] == 1 && manufacturerData.length >= 6) { // 历史版本
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.wifiActiveTimeS = manufacturerData[3] & 0x0FF;
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
            bleScanProto.wifiPWDVersion = manufacturerData[4] & 0x0FF;
            bleScanProto.bootUpStatus = manufacturerData[5] & 0b00000011;
//            Log.i("BleScanProto", "bleScanProto=" + bleScanProto + ", fullManufacturerData==" + Arrays.toString(bytes));
            return bleScanProto;
        } else if ((manufacturerData[2] & 0x1F) == 4 && manufacturerData.length > 6) {
            // 新版蓝牙适配
            BleScanProto bleScanProto = new BleScanProto();
            bleScanProto.protoVersion = manufacturerData[2] & 0x1F;
            bleScanProto.wifiPWDVersion = manufacturerData[2] & 0xE0;
            // 正式版: 4:Z03，5:Z05
            bleScanProto.deviceType = manufacturerData[3];
            bleScanProto.wifiActiveTimeS = manufacturerData[4];
            bleScanProto.nfcCrc = manufacturerData[5];
            bleScanProto.nfcCrc2 = manufacturerData[6];
            bleScanProto.bootUpStatus = BOOT_UP_STATUS_NORMAL_BOOT_UP;
            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
            return bleScanProto;
        }
//      Log.i("BleScanProto", "bleScanProto=null, manufacturerData=" + Arrays.toString(manufacturerData));
        return null;
    }

    /**
     * 适配版本1，按照优先级返回状态
     * 0bit：开关机
     * 1bit：是否低电
     * 2bit：是否在互传
     */
    private static int getStatus(Byte b) {
        // 优先级1：检查关机状态（0bit为0）
        if ((b & 0x01) == 0) {
            return BleScanProto.BOOT_UP_STATUS_SHUT_DOWN;
        }
        // 优先级2：检查低电状态（1bit为1）
        if ((b & 0x02) != 0) {
            return BleScanProto.BOOT_UP_STATUS_UNCONNECTABLE;
        }
        // 其他情况返回正常开机
        return BleScanProto.BOOT_UP_STATUS_NORMAL_BOOT_UP;
    }

//    public static BleScanProto parse(byte[] scanRecord, byte[] bytes) {
//        if (scanRecord == null || bytes == null) return null;
//        var version = getBroadcastVersion(scanRecord);
//        if (version == 2) {
//            return parseV2(scanRecord);
//        } else {
//            return parseV1(bytes);
//        }
//    }
//
//    /**
//     * 蓝牙广播第2版本解析工具类
//     * @param bytes 广播协议全字节，即
//     *             @see android.bluetooth.le.ScanResult#getScanRecord()#getBytes()
//     */
//    private static BleScanProto parseV2(byte[] bytes) {
//        BleScanProto bleScanProto = new BleScanProto();
//        if (bytes.length > 12) {
//            bleScanProto.protoVersion = bytes[11] & 0x1F;
//            bleScanProto.deviceType = bytes[9];
//            bleScanProto.wifiActiveTimeS = bytes[10];
//            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
//            bleScanProto.wifiPWDVersion = bytes[11] & 0xE0;
//            bleScanProto.bootUpStatus = getStatus(bytes[12]);
//        }
//        Log.i("BleScanProto", "parseV2: "+bleScanProto.toString());
//        return bleScanProto;
//    }
//
//    /**
//     *
//     * @param bytes 蓝牙广播中厂商 data，但不包含前2个字节
//     * @return
//     */
//    private static BleScanProto parseV1(byte[] bytes) {
//        if (bytes.length == 3 && bytes[0] == 0) {
//            BleScanProto bleScanProto = new BleScanProto();
//            bleScanProto.wifiActiveTimeS = bytes[1] & 0x0FF;
//            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
//            bleScanProto.wifiPWDVersion = bytes[2] & 0x0FF;
//            bleScanProto.bootUpStatus = BOOT_UP_STATUS_NORMAL_BOOT_UP;
////            Log.i("BleScanProto", "bleScanProto = " + bleScanProto + ", bytes(3)=" + Arrays.toString(bytes));
//            return bleScanProto;
//        } else if (bytes.length >= 4 && bytes[0] == 1) {
//            BleScanProto bleScanProto = new BleScanProto();
//            bleScanProto.wifiActiveTimeS = bytes[1] & 0x0FF;
//            bleScanProto.discoverTimeMillis = System.currentTimeMillis();
//            bleScanProto.wifiPWDVersion = bytes[2] & 0x0FF;
//            bleScanProto.bootUpStatus = bytes[3] & 0b00000011; // todo
////            Log.i("BleScanProto", "bleScanProto = " + bleScanProto + ", bytes(4)=" + Arrays.toString(bytes));
//            return bleScanProto;
//        } else {
////            Log.i("BleScanProto", "bleScanProto = null, bytes=" + Arrays.toString(bytes));
//            return null;
//        }
//    }
//
//    /**
//     * 获取广播版本，第12字节的低5位表示广播版本号
//     * @param bytes 是蓝牙全部内容，ScanRecord
//     */
//    private static int getBroadcastVersion(byte[] bytes) {
//        if(bytes.length >= 12 && (bytes[8] & 0xFF) == 0xFF) {
//            return bytes[11] & 0x1F;
//        } else {
//            return 1;
//        }
//    }

    long discoverTimeMillis;
    int wifiActiveTimeS;
    int wifiPWDVersion;
    int bootUpStatus;
    int deviceType = -1; // 广播中代表相机型号的字节
    int protoVersion = 1; // 广播版本
    int netType = 0;
    String deviceNamePrefix;
    byte nfcCrc = -1;
    byte nfcCrc2 = -1;
    public long getDiscoverTimeInMillis() {
        return discoverTimeMillis;
    }

    public int getWifiActiveTimeS() {
        return wifiActiveTimeS;
    }

    public int getWifiPWDVersion() {
        return wifiPWDVersion;
    }

    public int getBootUpStatus() {
        return bootUpStatus;
    }

    public int getDeviceType() {
        return deviceType;
    }

    public int getProtoVersion() {
        return protoVersion;
    }

    public int getNetType() {
        return netType;
    }

    public String getDeviceNamePrefix() {
        return deviceNamePrefix;
    }

    public byte getNfcCrc() {
        return nfcCrc;
    }

    public byte getNfcCrc2() {
        return nfcCrc2;
    }

    BleScanProto() {
    }

    @Override
    public String toString() {
        return "BleScanProto{" +
                "wifiActiveTimeS=" + wifiActiveTimeS +
                ", wifiPWDVersion=" + wifiPWDVersion +
                ", discoverTime=" + discoverTimeMillis +
                ", bootUpStatus=" + bootUpStatus +
                ", deviceNamePrefix=" + deviceNamePrefix +
                ", protoVersion=" + protoVersion +
                ", nfcCrc=" + nfcCrc +
                ", nfcCrc2=" + nfcCrc2 +
                '}';
    }

}
