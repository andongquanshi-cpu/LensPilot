package com.clj.fastble.exception;

import java.io.Serializable;


public abstract class BleException implements Serializable {

    private static final long serialVersionUID = 8004414918500865564L;

    public static final int ERROR_CODE_TIMEOUT = 100;
    public static final int ERROR_CODE_GATT = 101;
    public static final int ERROR_CODE_OTHER = 102;
    public static final int ERROR_CODE_OPEN = 103;
    public static final int ERROR_CODE_SYNC_PACK = 104;
    public static final int ERROR_CODE_NOTIFY_FAILURE = 105;
    public static final int ERROR_CODE_SET_MTU = 106;
    public static final int ERROR_CODE_WRITE_CHARACTERISTIC_FAIL = 107;
    public static final int ERROR_CODE_SHAKE_HAND = 108;
    public static final int ERROR_CODE_WAKE_UP_AUTHORIZATION_FAIL = 109;
    public static final int ERROR_CODE_ERROR_CODE_OPEN_BUSY = 110;
    public static final int ERROR_CODE_SYSTEM_STATUS_133 = 133;
    public static final int ERROR_CODE_CHARACTERISTICS = 134;
    public static final int ERROR_CODE_THROWABLE = 135;
    public static final int ERROR_CODE_CRASH_PRIVILEGED = 136;

    private int code;
    private String description;

    public BleException(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public BleException setCode(int code) {
        this.code = code;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public BleException setDescription(String description) {
        this.description = description;
        return this;
    }

    @Override
    public String toString() {
        return "BleException { " +
               "code=" + code +
               ", description='" + description + '\'' +
               '}';
    }
}
