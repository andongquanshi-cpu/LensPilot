package com.clj.fastble.advertising;

public class ADStructure {
    public int length;
    public String type;
    public String data;

    public ADStructure() {
    }

    public String toString() {
        return "ADStructure{length=" + this.length + ", type='" + this.type + '\'' + ", data='" + this.data + '\'' + '}';
    }
}
