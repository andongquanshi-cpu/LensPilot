package com.clj.fastble.callback;

import android.bluetooth.le.ScanResult;

import com.clj.fastble.data.BleDevice;

import java.util.List;

public interface BleScanPresenterImp {

    void onScanStarted(int errorCode);

    void onRawScanResult(int callbackType, ScanResult result);

    void onScanning(BleDevice bleDevice);

    void onScanUpdate(List<BleDevice> bleDevice);

    void onScanReject();

}
