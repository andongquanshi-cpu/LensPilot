package com.clj.fastble.callback;

import android.bluetooth.le.AdvertiseSettings;

public interface BleStopWakeupCallback {

    void stopWakeupSuccess(AdvertiseSettings settingsInEffect);

    void stopWakeupError(int errorCode);

}
