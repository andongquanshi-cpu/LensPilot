package com.clj.fastble.utils;

import android.util.Log;
import android.util.SparseArray;

import com.clj.fastble.advertising.ADStructure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdvertiseUtil {

    private final static byte[] hex = "0123456789ABCDEF".getBytes();


    private static final int DATA_TYPE_SERVICE_UUIDS_16_BIT_PARTIAL = 0x02;
    private static final int DATA_TYPE_SERVICE_UUIDS_16_BIT_COMPLETE = 0x03;
    private static final int DATA_TYPE_SERVICE_UUIDS_32_BIT_PARTIAL = 0x04;
    private static final int DATA_TYPE_SERVICE_UUIDS_32_BIT_COMPLETE = 0x05;
    private static final int DATA_TYPE_SERVICE_UUIDS_128_BIT_PARTIAL = 0x06;
    private static final int DATA_TYPE_SERVICE_UUIDS_128_BIT_COMPLETE = 0x07;
    private static final int DATA_TYPE_LOCAL_NAME_SHORT = 0x08;
    private static final int DATA_TYPE_LOCAL_NAME_COMPLETE = 0x09;
    private static final int DATA_TYPE_TX_POWER_LEVEL = 0x0A;
    private static final int DATA_TYPE_SERVICE_DATA = 0x16;
    private static final int DATA_TYPE_MANUFACTURER_SPECIFIC_DATA = 0xFF;
    private static int txPowerLevel = Integer.MIN_VALUE;


    private static void analyzeAdvertisingData(byte[] advertisingData) {

        SparseArray<byte[]> manufacturerSpecificData;
        Map<String, byte[]> serviceData;
        List<String> serviceUuids = new ArrayList<>();

        if (advertisingData != null && advertisingData.length > 0) {
            int index = 0;

            while (index < advertisingData.length - 1) {
                int length = advertisingData[index];
                if (length == 0) {
                    break;
                }
                int type = advertisingData[index + 1];
                //LogUtils.e(TAG, " type:" + OKBLEDataUtils.Bytes2HexString(new byte[]{(byte) type}));
                if (type == (byte) DATA_TYPE_SERVICE_UUIDS_16_BIT_PARTIAL) {
                    if (serviceUuids == null) {
                        serviceUuids = new ArrayList<>();
                    }

                    byte[] serveruuids = subByteArray(advertisingData, index + 2, length - 1);
                    // LogUtils.e(TAG, " serveruuids:" + OKBLEDataUtils.Bytes2HexString(serveruuids));

                    if (serveruuids.length % 2 == 0) {

                        int count = serveruuids.length / 2;
                        for (int i = 0; i < count; i++) {
                            byte[] serveruuid = new byte[]{serveruuids[2 * i + 1], serveruuids[2 * i]};
                            //String uuid = CommonUUIDUtils.CommonUUIDStr_x.replace("xxxx", OKBLEDataUtils.BytesToHexString(serveruuid).toLowerCase());
                            String uuid = BytesToHexString(serveruuid);
                            serviceUuids.add(uuid);
                            //       LogUtils.e(TAG, "    serveruuid:" + uuid);
                        }
                    }
                } else if (type == (byte) DATA_TYPE_SERVICE_UUIDS_16_BIT_COMPLETE) {
                    if (serviceUuids == null) {
                        serviceUuids = new ArrayList<>();
                    }
                    byte[] serveruuids = subByteArray(advertisingData, index + 2, length - 1);
                    // LogUtils.e(TAG, " serveruuids:" + OKBLEDataUtils.Bytes2HexString(serveruuids));

                    if (serveruuids.length % 2 == 0) {

                        int count = serveruuids.length / 2;
                        for (int i = 0; i < count; i++) {
                            byte[] serveruuid = new byte[]{serveruuids[2 * i + 1], serveruuids[2 * i]};
                            //String uuid = CommonUUIDUtils.CommonUUIDStr_x.replace("xxxx", OKBLEDataUtils.BytesToHexString(serveruuid).toLowerCase());
                            String uuid = BytesToHexString(serveruuid);
                            serviceUuids.add(uuid);
                            //       LogUtils.e(TAG, "    serveruuid:" + uuid);
                        }


                    }
                } else if (type == (byte) DATA_TYPE_SERVICE_UUIDS_128_BIT_PARTIAL) {
                    if (serviceUuids == null) {
                        serviceUuids = new ArrayList<>();
                    }
                    byte[] serveruuids = subByteArray(advertisingData, index + 2, length - 1);
                    // LogUtils.e(TAG, " serveruuids:" + OKBLEDataUtils.Bytes2HexString(serveruuids));

                    if (serveruuids.length % 16 == 0) {

                        int count = serveruuids.length / 16;
                        for (int i = 0; i < count; i++) {

                            byte[] serveruuid = new byte[16];
                            for (int j = 0; j < 16; j++) {
                                serveruuid[j] = serveruuids[16 * i + (15 - j)];
                            }
                            String hexStr = BytesToHexString(serveruuid);
                            String uuid = hexStr.substring(0, 8);
                            uuid += "-";
                            uuid += hexStr.substring(8, 12);
                            uuid += "-";
                            uuid += hexStr.substring(12, 16);
                            uuid += "-";
                            uuid += hexStr.substring(16, 20);
                            uuid += "-";
                            uuid += hexStr.substring(20, 32);
                            //String uuid = CommonUUIDUtils.CommonUUIDStr_x.replace("xxxx", OKBLEDataUtils.BytesToHexString(serveruuid).toLowerCase());

                            serviceUuids.add(uuid);
                            //       LogUtils.e(TAG, "    serveruuid:" + uuid);
                        }


                    }
                } else if (type == (byte) DATA_TYPE_SERVICE_UUIDS_128_BIT_COMPLETE) {
                    if (serviceUuids == null) {
                        serviceUuids = new ArrayList<>();
                    }
                    byte[] serveruuids = subByteArray(advertisingData, index + 2, length - 1);
                    // LogUtils.e(TAG, " serveruuids:" + OKBLEDataUtils.Bytes2HexString(serveruuids));

                    if (serveruuids.length % 16 == 0) {

                        int count = serveruuids.length / 16;
                        for (int i = 0; i < count; i++) {

                            byte[] serveruuid = new byte[16];
                            for (int j = 0; j < 16; j++) {
                                serveruuid[j] = serveruuids[16 * i + (15 - j)];
                            }
                            String hexStr = BytesToHexString(serveruuid);
                            String uuid = hexStr.substring(0, 8);
                            uuid += "-";
                            uuid += hexStr.substring(8, 12);
                            uuid += "-";
                            uuid += hexStr.substring(12, 16);
                            uuid += "-";
                            uuid += hexStr.substring(16, 20);
                            uuid += "-";
                            uuid += hexStr.substring(20, 32);
                            //String uuid = CommonUUIDUtils.CommonUUIDStr_x.replace("xxxx", OKBLEDataUtils.BytesToHexString(serveruuid).toLowerCase());

                            serviceUuids.add(uuid);
                            //       LogUtils.e(TAG, "    serveruuid:" + uuid);
                        }


                    }
                } else if (type == (byte) DATA_TYPE_SERVICE_DATA) {
                    serviceData = new HashMap<>();
                    byte[] serverData = subByteArray(advertisingData, index + 2, length - 1);
                    byte[] uuid = new byte[]{serverData[1], serverData[0]};
                    byte[] data = subByteArray(serverData, 2, serverData.length - 2);
                    // String uuidStr = CommonUUIDUtils.CommonUUIDStr_x.replace("xxxx", OKBLEDataUtils.BytesToHexString(uuid).toLowerCase());
                    String uuidStr = BytesToHexString(uuid);
                    serviceData.put(uuidStr, data);

                    //   LogUtils.e(TAG, "    server data :" + OKBLEDataUtils.Bytes2HexString(data) + " uuid:" + uuidStr);

                } else if (type == (byte) DATA_TYPE_MANUFACTURER_SPECIFIC_DATA) {
                    manufacturerSpecificData = new SparseArray<>();
                    byte[] manufacturerData = subByteArray(advertisingData, index + 2, length - 1);
                    byte[] manufacturerId = new byte[]{manufacturerData[1], manufacturerData[0]};
                    //    LogUtils.e(TAG, " manufacturerId:" + OKBLEDataUtils.Bytes2HexString(manufacturerId));
                    byte[] manufacturerValue = subByteArray(manufacturerData, 2, manufacturerData.length - 2);
                    manufacturerSpecificData.append(buildUint16(manufacturerId[0], manufacturerId[1]), manufacturerValue);
                    //   LogUtils.e(TAG, " manufacturerValue:" + OKBLEDataUtils.Bytes2HexString(manufacturerValue));


                } else if (type == (byte) DATA_TYPE_LOCAL_NAME_COMPLETE) {

                    byte[] nameData = subByteArray(advertisingData, index + 2, length - 1);
//                    completeLocalName = new String(nameData);
                    //   LogUtils.e(TAG, " completeLocalName:" + completeLocalName);
                } else if (type == (byte) DATA_TYPE_TX_POWER_LEVEL) {

                    txPowerLevel = advertisingData[index + 2];
                }


                index += length + 1;//1是length自身占一个字节

            }
        }
    }


    private static SparseArray<byte[]> getManufactureData(byte[] advertisingData) {
        SparseArray<byte[]> manufacturerSpecificData = null;

        if (advertisingData != null && advertisingData.length > 0) {
            int index = 0;

            while (index < advertisingData.length - 1) {
                int length = advertisingData[index];
                if (length == 0) {
                    break;
                }
                int type = advertisingData[index + 1];
                if (type == (byte) DATA_TYPE_MANUFACTURER_SPECIFIC_DATA) {
                    manufacturerSpecificData = new SparseArray<>();
                    byte[] manufacturerData = subByteArray(advertisingData, index + 2, length - 1);
                    byte[] manufacturerId = new byte[]{manufacturerData[1], manufacturerData[0]};
                    byte[] manufacturerValue = subByteArray(manufacturerData, 2, manufacturerData.length - 2);
                    manufacturerSpecificData.append(buildUint16(manufacturerId[0], manufacturerId[1]), manufacturerValue);
                }

                index += length + 1;//1是length自身占一个字节
            }
        }

        return manufacturerSpecificData;
    }

    public static int getManufactureId(byte[] advertisingData) {
        SparseArray<byte[]> manufactureData = getManufactureData(advertisingData);
        if (manufactureData != null){
            return manufactureData.keyAt(0);
        }
        return 0x004c;
    }


    /**
     * 截取byte数组
     *
     * @param src
     * @param start
     * @param length
     * @return
     */
    public static byte[] subByteArray(byte[] src, int start, int length) {

        byte[] result = new byte[length];

        System.arraycopy(src, start, result, 0, length);


        return result;

    }

    /**
     * 字节数组转十六进制字符串
     *
     * @param b: byte[] bytes_1=new byte[]{(byte) 0xA0,(byte) 0xB1,2}
     * @return "A0B102"
     */
    public static String BytesToHexString(byte[] b) {
        if (b == null) {
            return null;
        }
        byte[] buff = new byte[2 * b.length];
        for (int i = 0; i < b.length; i++) {
            buff[2 * i] = hex[(b[i] >> 4) & 0x0f];
            buff[2 * i + 1] = hex[b[i] & 0x0f];
        }
        return new String(buff);
    }

    /**
     * 高低位 组成int，
     *
     * @param hi
     * @param lo
     * @return
     */
    public static int buildUint16(byte hi, byte lo) {
        return (int) ((hi << 8) + (lo & 0xff));
    }

    public static List<ADStructure> parseBleAdData(byte[] src) {
        List<ADStructure> mADStructureArray = new ArrayList();
        String rawDataStr = bytesToHexString(src);
        Log.e("bleinfo", "ad ble = " + rawDataStr);

        while(true) {
            String lengthStr = rawDataStr.substring(0, 2);
            if (lengthStr.equals("00")) {
                return mADStructureArray;
            }

            int length = Integer.parseInt(lengthStr, 16);
            String data = rawDataStr.substring(0, (length + 1) * 2);
            rawDataStr = rawDataStr.substring((length + 1) * 2, rawDataStr.length());
            ADStructure adStructure = new ADStructure();
            adStructure.length = length;
            adStructure.type = data.substring(2, 4);
            adStructure.data = data.substring(4, data.length());
            mADStructureArray.add(adStructure);
        }
    }
    public static String bytesToHexString(byte[] src) {
        if (src != null && src.length != 0) {
            StringBuilder stringBuilder = new StringBuilder("");
            if (src != null && src.length > 0) {
                for(int i = 0; i < src.length; ++i) {
                    int v = src[i] & 255;
                    String hex = Integer.toHexString(v);
                    if (hex.length() < 2) {
                        stringBuilder.append(0);
                    }

                    stringBuilder.append(hex);
                }

                return stringBuilder.toString();
            } else {
                return null;
            }
        } else {
            return "";
        }
    }
}
