package com.clj.fastble;

public class FastbleInstaSdkExperiment {

    public static boolean sBleScanFilterExperiment = false;

}
