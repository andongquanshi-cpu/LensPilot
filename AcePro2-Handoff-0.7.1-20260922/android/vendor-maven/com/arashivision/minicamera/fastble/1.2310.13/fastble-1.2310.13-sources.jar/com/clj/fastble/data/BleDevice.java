package com.clj.fastble.data;


import android.bluetooth.BluetoothDevice;
import android.os.Parcel;
import android.os.ParcelUuid;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseArray;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.IBleScanProtoDependence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;


public class BleDevice implements Parcelable {

    // 相机蓝牙 serviceUuid
    private final static String CAMERA_BLE_SERVICE_UUID = "be80";

    // FMG主板固件的服务
    private final static String FMG_YT_SERVICE_UUID = "3366";

    private final int DEVICE_TYPE_TC4 = 1;
    private final BluetoothDevice mDevice;
    private final String mDeviceName;
    private final byte[] mScanRecord;
    private final int mRssi;
    private final long mTimestampNanos;
    private final SparseArray<byte[]> mManufacturerSpecificData;
    private volatile boolean isParseManufacturer = false;

    private final List<ParcelUuid> mServiceUuids;

    private String mCachedName;
    private String mCachedMac;
    private String mCachedKey;
    private BleScanProto mBleScanProto;
    private boolean mHasCachedData;

    public BleDevice(BluetoothDevice device, String deviceName, int rssi, byte[] scanRecord, long timestampNanos, SparseArray<byte[]> manufacturerSpecificData, List<ParcelUuid> serviceUuids) {
        this(device, deviceName, rssi, scanRecord, timestampNanos, manufacturerSpecificData, serviceUuids, true);
    }

    public BleDevice(BluetoothDevice device, String deviceName, int rssi, byte[] scanRecord, long timestampNanos,
                     SparseArray<byte[]> manufacturerSpecificData, List<ParcelUuid> serviceUuids, boolean autoCacheData) {
        mDevice = device;
        mDeviceName = deviceName;
        mScanRecord = scanRecord;
        mRssi = rssi;
        mTimestampNanos = timestampNanos;
        if (manufacturerSpecificData == null) {
            mManufacturerSpecificData = new SparseArray<>();
        } else {
            mManufacturerSpecificData = manufacturerSpecificData;
        }
        mServiceUuids = serviceUuids;
        if (autoCacheData) {
            cacheData();
        }
        getScanProtoInner();
    }

    protected BleDevice(Parcel in) {
        mDevice = in.readParcelable(BluetoothDevice.class.getClassLoader());
        mDeviceName = in.readString();
        mScanRecord = in.createByteArray();
        mRssi = in.readInt();
        mTimestampNanos = in.readLong();
        mCachedName = in.readString();
        mCachedMac = in.readString();
        mCachedKey = in.readString();
        mHasCachedData = in.readByte() != 0;
        mManufacturerSpecificData = in.readSparseArray(SparseArray.class.getClassLoader());
        mServiceUuids = in.createTypedArrayList(ParcelUuid.CREATOR);
        getScanProtoInner();
        transformName();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(mDevice, flags);
        dest.writeString(mDeviceName);
        dest.writeByteArray(mScanRecord);
        dest.writeInt(mRssi);
        dest.writeLong(mTimestampNanos);
        dest.writeString(mCachedName);
        dest.writeString(mCachedMac);
        dest.writeString(mCachedKey);
        dest.writeByte((byte) (mHasCachedData ? 1 : 0));
        dest.writeSparseArray(mManufacturerSpecificData);
        dest.writeTypedList(mServiceUuids);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<BleDevice> CREATOR = new Creator<BleDevice>() {
        @Override
        public BleDevice createFromParcel(Parcel in) {
            return new BleDevice(in);
        }

        @Override
        public BleDevice[] newArray(int size) {
            return new BleDevice[size];
        }
    };

    public void cacheData() {
        if (!mHasCachedData) {
            mHasCachedData = true;
            mCachedName = getNameInner();
            mCachedMac = getMacInner();
            mCachedKey = getKeyInner();
            getScanProtoInner();
            transformName();
        }
    }

    private void transformName() {
        if (mCachedName != null && mBleScanProto != null) {
            final String deviceNamePrefix = mBleScanProto.getDeviceNamePrefix();
            if (!TextUtils.isEmpty(deviceNamePrefix)) {
                if (deviceNamePrefix.equals(BleScanProto.PROTO_Z03)) {
                    mCachedName = mCachedName.replace("Luna", deviceNamePrefix);
                } else if (deviceNamePrefix.equals(BleScanProto.PROTO_Z05)) {
                    mCachedName = mCachedName.replace("Luna", deviceNamePrefix);
                }
            } else {
                IBleScanProtoDependence scanProtoDependence = BleManager.getInstance().getBleScanProtoDependence();
                if (scanProtoDependence != null) {
                    String deviceType = scanProtoDependence.getDeviceType(mBleScanProto.deviceType);
                    if (deviceType != null && !deviceType.trim().isEmpty()) {
                        mCachedName = deviceType.trim() + " " + mCachedName;
                    }
                    mCachedName = scanProtoDependence.transformDeviceName(mCachedName);
                }
            }
        }
    }

    public String getNameInner() {
        try {
            if (mDeviceName != null && mDeviceName.length() != 0)
                return mDeviceName;
            if (mDevice != null)
                return mDevice.getName();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getMacInner() {
        try {
            if (mDevice != null)
                return mDevice.getAddress();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getKeyInner() {
        try {
            if (mDevice != null)
                return mDevice.getName() + mDevice.getAddress();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void getScanProtoInner() {
        try {
            if (mManufacturerSpecificData != null && mManufacturerSpecificData.size() > 0 && !isParseManufacturer) {
                isParseManufacturer = true;
                int companyId = mManufacturerSpecificData.keyAt(0);        // 前 2 个字节
                byte[] payload = mManufacturerSpecificData.valueAt(0);     // 剩余数据

                ByteBuffer buffer = ByteBuffer.allocate(2 + payload.length)
                        .order(ByteOrder.LITTLE_ENDIAN);
                buffer.putShort((short) companyId);
                buffer.put(payload);
                byte[] fullManufacturerData = buffer.array();
                mBleScanProto = BleScanProto.parse(fullManufacturerData);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getName() {
        if (!mHasCachedData) {
            cacheData();
        }
        return mCachedName;
    }

    public String getMac() {
        if (!mHasCachedData) {
            cacheData();
        }
        return mCachedMac;
    }

    public String getKey() {
        if (!mHasCachedData) {
            cacheData();
        }
        return mCachedKey;
    }

    public BleScanProto getBleScanProto() {
        return mBleScanProto;
    }

    public BluetoothDevice getDevice() {
        return mDevice;
    }

    public byte[] getScanRecord() {
        return mScanRecord;
    }

    public int getRssi() {
        return mRssi;
    }

    public long getTimestampNanos() {
        return mTimestampNanos;
    }

    public List<ParcelUuid> getServiceUuids() {
        return mServiceUuids;
    }

    public boolean isCameraServiceUuid() {
        if (mServiceUuids == null || mServiceUuids.isEmpty()) {
            return false;
        }
        for (ParcelUuid parcelUuid: mServiceUuids) {
            if (parcelUuid != null && parcelUuid.getUuid() != null) {
                String serviceUuid = parcelUuid.getUuid().toString().toLowerCase(Locale.ENGLISH);
                if (serviceUuid.contains(CAMERA_BLE_SERVICE_UUID) || serviceUuid.contains(FMG_YT_SERVICE_UUID)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "BleDevice{" +
                "mDeviceName='" + mDeviceName + '\'' +
                ", mTimestampNanos=" + mTimestampNanos +
                '}';
    }
}
