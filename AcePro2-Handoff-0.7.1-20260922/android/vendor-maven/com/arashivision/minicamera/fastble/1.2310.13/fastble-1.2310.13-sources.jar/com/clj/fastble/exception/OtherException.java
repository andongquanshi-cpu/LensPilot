package com.clj.fastble.exception;


public class OtherException extends BleException {

    public OtherException(String description) {
        super(ERROR_CODE_OTHER, description);
    }

    public OtherException(int errorCode, String description) {
        super(errorCode, description);
    }

}
