package com.clj.fastble.abtest;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;



public class SDKABTestExperimentManager {
    private static IABTest mABTest;

    public static void setABTestExperimentImpl(@NotNull IABTest wifiAb) {
        mABTest = wifiAb;
    }

    @Nullable
    public static IABTest getABTest() {
        return mABTest;
    }

    public interface IABTest {

        public boolean isThreadOptHits();

    }

}

