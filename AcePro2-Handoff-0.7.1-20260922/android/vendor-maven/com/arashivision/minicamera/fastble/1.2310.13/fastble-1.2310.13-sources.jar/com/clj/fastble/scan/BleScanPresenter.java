package com.clj.fastble.scan;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.ParcelUuid;
import android.text.TextUtils;
import android.util.SparseArray;

import com.clj.fastble.FastbleInstaSdkExperiment;
import com.clj.fastble.abtest.SDKABTestExperimentManager;
import com.clj.fastble.callback.BleScanPresenterImp;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.data.BleMsg;
import com.clj.fastble.utils.BleDeviceUtil;
import com.clj.fastble.utils.BleLog;
import com.insta360.basethread.InsHandlerThreadPriority;
import com.insta360.basethread.InsThreadManager;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class BleScanPresenter extends ScanCallback {

    private static final int MSG_UPDATE_BLE_DEVICE = 111;
    private static final int MSG_NOTIFY_BLE_SCAN_REJECT = 112;

    private String[] mDeviceNames;
    private String mDeviceMac;
    private boolean mFuzzy;
    private boolean mNeedConnect;
    private long mScanTimeout;
    private BleScanPresenterImp mBleScanPresenterImp;

    private List<BleDevice> mBleDeviceList = new ArrayList<>();
    private List<BleDevice> mUpdateBleDeviceList = new ArrayList<>();

    private Handler mMainHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_UPDATE_BLE_DEVICE:
                    notifyUpdateBleDevice();
                    break;
                case MSG_NOTIFY_BLE_SCAN_REJECT:
                    onBleScanReject();
                    break;
            }
        }
    };
    private HandlerThread mHandlerThread;
    private Handler mHandler;
    private boolean mHandling;

    private boolean mIsThreadOptHits = false;

    private static final class ScanHandler extends Handler {

        private final WeakReference<BleScanPresenter> mBleScanPresenter;

        ScanHandler(Looper looper, BleScanPresenter bleScanPresenter) {
            super(looper);
            mBleScanPresenter = new WeakReference<>(bleScanPresenter);
        }

        @Override
        public void handleMessage(Message msg) {
            BleScanPresenter bleScanPresenter = mBleScanPresenter.get();
            if (bleScanPresenter != null) {
                if (msg.what == BleMsg.MSG_SCAN_DEVICE) {
                    final BleDevice bleDevice = (BleDevice) msg.obj;
                    if (bleDevice != null) {
                        bleDevice.cacheData();
                        bleScanPresenter.handleResult(bleDevice);
                    }
                } else if (msg.what == BleMsg.MSG_SCAN_SYSTEM_ALL_DEVICES) {
                    for (BluetoothDevice bluetoothDevice : BleDeviceUtil.getAllSystemConnectedDevices()) {
                        bleScanPresenter.notifyScanResult(new BleDevice(bluetoothDevice, null, 0, null, 0, null, null));
                    }
                }
            }
        }
    }

    private void handleResult(final BleDevice bleDevice) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                onLeScan(bleDevice);
            }
        });
        checkDevice(bleDevice);
    }

    public void prepare(String[] names, String mac, boolean fuzzy, boolean needConnect,
                        long timeOut, BleScanPresenterImp bleScanPresenterImp) {
        mDeviceNames = names;
        mDeviceMac = mac;
        mFuzzy = fuzzy;
        mNeedConnect = needConnect;
        mScanTimeout = timeOut;
        mBleScanPresenterImp = bleScanPresenterImp;
        mIsThreadOptHits = SDKABTestExperimentManager.getABTest() != null && SDKABTestExperimentManager.getABTest().isThreadOptHits();
        if (!mIsThreadOptHits) {
            mHandlerThread = new HandlerThread(BleScanPresenter.class.getSimpleName());
        } else {
            mHandlerThread = InsThreadManager.INSTANCE.getInsHandlerThread("CONNECT", InsHandlerThreadPriority.MAX_PRIORITY);
        }
        mHandlerThread.start();
        mHandler = new ScanHandler(mHandlerThread.getLooper(), this);
        mHandling = true;
    }

    public boolean ismNeedConnect() {
        return mNeedConnect;
    }

    public BleScanPresenterImp getBleScanPresenterImp() {
        return mBleScanPresenterImp;
    }

    @Override
    public void onScanResult(int callbackType, ScanResult result) {
        super.onScanResult(callbackType, result);
//         BleLog.w("ScanCallback->onScanResult, callbackType = " + callbackType + ", result=" + result);
        mMainHandler.removeMessages(MSG_NOTIFY_BLE_SCAN_REJECT);
        onRawScanResult(callbackType, result);
        if (result == null || result.getDevice() == null)
            return;

        if (!mHandling)
            return;

        ScanRecord scanRecord = result.getScanRecord();
        String deviceName = null;
        byte[] bytes = null;
        SparseArray<byte[]> manufacturerSpecificData = null;
        List<ParcelUuid> serviceUuids = null;
        if (scanRecord != null) {
            deviceName = scanRecord.getDeviceName();
            bytes = scanRecord.getBytes();
            manufacturerSpecificData = scanRecord.getManufacturerSpecificData();
            serviceUuids = scanRecord.getServiceUuids();
//            if (!TextUtils.isEmpty(deviceName) && manufacturerSpecificData.size() > 0 /*&& (deviceName.contains("AirPods") || deviceName.contains("X5"))*/) {
////                Map<Integer, byte[]> advertisingDataMap = scanRecord.getAdvertisingDataMap();
//                int companyId = manufacturerSpecificData.keyAt(0);
//                byte[] payload = manufacturerSpecificData.valueAt(0);
//                BleLog.w("ScanCallback->onScanResult, mDeviceName=" + deviceName + ", mManufacturerSpecificData=" + manufacturerSpecificData.size()
//                        + ", \n companyId=" + companyId + ", payload=" + Arrays.toString(payload));
//            }
//            BleLog.w("ScanCallback->onScanResult, scanRecord = " + scanRecord + "\n bytes=" + Arrays.toString(bytes));
        }
        notifyScanResult(new BleDevice(result.getDevice(), deviceName, result.getRssi(), bytes, System.currentTimeMillis(), manufacturerSpecificData, serviceUuids, false));
    }

    private void notifyScanResult(BleDevice bleDevice) {
        Message message = Message.obtain();
        message.what = BleMsg.MSG_SCAN_DEVICE;
        message.obj = bleDevice;
        mHandler.sendMessage(message);
    }

    private void obtainAllSystemConnectedDevices() {
        Message message = Message.obtain();
        message.what = BleMsg.MSG_SCAN_SYSTEM_ALL_DEVICES;
        mHandler.sendMessage(message);
    }

    private void checkDevice(BleDevice bleDevice) {
        if (TextUtils.isEmpty(mDeviceMac) && (mDeviceNames == null || mDeviceNames.length < 1)) {
            correctDeviceAndNextStep(bleDevice);
            return;
        }

        if (!TextUtils.isEmpty(mDeviceMac)) {
            if (!mDeviceMac.equalsIgnoreCase(bleDevice.getMac()))
                return;
        }

        if (mDeviceNames != null && mDeviceNames.length > 0) {
            AtomicBoolean equal = new AtomicBoolean(false);
            for (String name : mDeviceNames) {
                String remoteName = FastbleInstaSdkExperiment.sBleScanFilterExperiment ? bleDevice.getNameInner() : bleDevice.getName();
                if (remoteName == null)
                    remoteName = "";
                if (mFuzzy ? remoteName.contains(name) : remoteName.equals(name)) {
                    equal.set(true);
                }
            }
            if (!equal.get()) {
                return;
            }
        }

        correctDeviceAndNextStep(bleDevice);
    }

    private void correctDeviceAndNextStep(final BleDevice bleDevice) {
        if (bleDevice == null) return;
        if (mNeedConnect) {
//            BleLog.i("devices detected  ------"
//                    + "  name:" + bleDevice.getName()
//                    + "  mac:" + bleDevice.getMac()
//                    + "  Rssi:" + bleDevice.getRssi()
//                    + "  scanRecord:" + HexUtil.formatHexString(bleDevice.getScanRecord()));

            mBleDeviceList.add(bleDevice);
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    BleScanner.getInstance().stopLeScan();
                }
            });
        } else {
            AtomicBoolean hasFound = new AtomicBoolean(false);
            for (BleDevice result : new ArrayList<>(mBleDeviceList)) {
                if (result != null) {
                    BluetoothDevice resultDevice = result.getDevice();
                    if (resultDevice != null && resultDevice.equals(bleDevice.getDevice())) {
                        hasFound.set(true);
                    }
                }
            }
            if (!hasFound.get()) {
//                BleLog.i("device detected  ------"
//                        + "  name: " + bleDevice.getName()
//                        + "  mac: " + bleDevice.getMac()
//                        + "  Rssi: " + bleDevice.getRssi()
//                        + "  scanRecord: " + HexUtil.formatHexString(bleDevice.getScanRecord(), true));

                mBleDeviceList.add(bleDevice);
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        onScanning(bleDevice);
                    }
                });
            } else {
                synchronized (this) {
                    mUpdateBleDeviceList.add(bleDevice);
                }
                if (!mMainHandler.hasMessages(MSG_UPDATE_BLE_DEVICE)) {
                    mMainHandler.sendEmptyMessageDelayed(MSG_UPDATE_BLE_DEVICE, 1000);
                }
            }
        }
    }

    private void notifyUpdateBleDevice() {
        synchronized (BleScanPresenter.this) {
            onScanUpdate(new ArrayList<>(mUpdateBleDeviceList));
            mUpdateBleDeviceList.clear();
        }
    }

    public final void notifyScanStarted(final int errorCode) {
        mBleDeviceList.clear();

        boolean success = errorCode == 0;
        if (!success) {
            release();
        } else {
            Message message = Message.obtain();
            message.what = MSG_NOTIFY_BLE_SCAN_REJECT;
            mMainHandler.sendMessageDelayed(message, 5_000);
            if (mHandler != null && mScanTimeout > 0) {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        BleScanner.getInstance().stopLeScan();
                    }
                }, mScanTimeout);
            }
        }
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (errorCode == ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED) {
                    // 命中实验组，且系统错误，直接关闭扫描连接
                    mMainHandler.post(() ->BleScanner.getInstance().stopLeScan());
                }
                onScanStarted(errorCode);
                if (success) {
                    obtainAllSystemConnectedDevices();
                }
            }
        });
    }

    public final void notifyScanStopped() {
        final List<BleDevice> bleDeviceList = new ArrayList<>(mBleDeviceList);
        release();
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                onScanFinished(bleDeviceList);
            }
        });
    }

    private void release() {
        BleLog.d("BleScanPresenter release");
        mHandling = false;
        mMainHandler.removeCallbacksAndMessages(null);
        mHandler.removeCallbacksAndMessages(null);
        if (!mIsThreadOptHits) {
            try {
                if (mHandlerThread != null) {
                    mHandlerThread.quit();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        mHandlerThread = null;
        synchronized (this) {
            mBleDeviceList.clear();
            mUpdateBleDeviceList.clear();
        }
    }

    public abstract void onScanStarted(int errorCode);

    public abstract void onLeScan(BleDevice bleDevice);

    public abstract void onRawScanResult(int callbackType, ScanResult result);

    public abstract void onScanning(BleDevice bleDevice);

    public abstract void onScanUpdate(List<BleDevice> bleDevice);

    public abstract void onScanFinished(List<BleDevice> bleDeviceList);

    public abstract void onBleScanReject();
}
