package com.clj.fastble.scan;

import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.os.Handler;
import android.os.Looper;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleScanAndConnectCallback;
import com.clj.fastble.callback.BleScanCallback;
import com.clj.fastble.callback.BleScanPresenterImp;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.data.BleErrorCode;
import com.clj.fastble.data.BleScanState;
import com.clj.fastble.utils.BleLog;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class BleScanner {

    public static BleScanner getInstance() {
        return BleScannerHolder.sBleScanner;
    }

    private static class BleScannerHolder {
        private static final BleScanner sBleScanner = new BleScanner();
    }

    private BleScanState mBleScanState = BleScanState.STATE_IDLE;

    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Runnable mNotifyStartSuccessRunnable = new Runnable() {
        @Override
        public void run() {
            mBleScanState = BleScanState.STATE_SCANNING;
            if (mBleScanPresenter!= null) {
                mBleScanPresenter.notifyScanStarted(BleErrorCode.SCAN_SUCCESS);
            }
        }
    };

    private BleScanPresenter mBleScanPresenter = null;
    private static class BleScanPresenterImpl extends BleScanPresenter {
        private final WeakReference<BleScanner> scannerRef;
        private BleScanPresenterImpl(BleScanner scanner) {
            scannerRef = new WeakReference<>(scanner);
        }

        private BleScanner getScanner() {
            return scannerRef.get();
        }

        @Override
        public void onScanStarted(int errorCode) {
            BleScanPresenterImp callback = getBleScanPresenterImp();
            if (callback != null) {
                callback.onScanStarted(errorCode);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            BleLog.w("ScanCallback->onScanFailed, errorCode = " + errorCode);
            BleScanner scanner = getScanner();
            if (scanner != null) {
                scanner.mHandler.removeCallbacks(scanner.mNotifyStartSuccessRunnable);
                scanner.mBleScanState = BleScanState.STATE_IDLE;
            }
            notifyScanStarted(errorCode);
        }

        @Override
        public void onRawScanResult(int callbackType, ScanResult result) {
            BleScanPresenterImp callback = getBleScanPresenterImp();
            if (callback != null) {
                callback.onRawScanResult(callbackType, result);
            }
        }

        @Override
        public void onLeScan(BleDevice bleDevice) {
            if (ismNeedConnect()) {
                BleScanAndConnectCallback callback = (BleScanAndConnectCallback)
                        getBleScanPresenterImp();
                if (callback != null) {
                    callback.onLeScan(bleDevice);
                }
            } else {
                BleScanCallback callback = (BleScanCallback) getBleScanPresenterImp();
                if (callback != null) {
                    callback.onLeScan(bleDevice);
                }
            }
        }

        @Override
        public void onScanning(BleDevice result) {
            BleScanPresenterImp callback = getBleScanPresenterImp();
            if (callback != null) {
                callback.onScanning(result);
            }
        }

        @Override
        public void onScanUpdate(List<BleDevice> bleDevice) {
            BleScanPresenterImp callback = getBleScanPresenterImp();
            if (callback != null) {
                callback.onScanUpdate(bleDevice);
            }
        }

        @Override
        public void onScanFinished(List<BleDevice> bleDeviceList) {
            if (ismNeedConnect()) {
                final BleScanAndConnectCallback callback = (BleScanAndConnectCallback)
                        getBleScanPresenterImp();
                if (bleDeviceList == null || bleDeviceList.size() < 1) {
                    if (callback != null) {
                        callback.onScanFinished(null);
                    }
                } else {
                    if (callback != null) {
                        callback.onScanFinished(bleDeviceList.get(0));
                    }
                    final List<BleDevice> list = bleDeviceList;
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            BleManager.getInstance().connect(list.get(0), callback);
                        }
                    }, 100);
                }
            } else {
                BleScanCallback callback = (BleScanCallback) getBleScanPresenterImp();
                if (callback != null) {
                    callback.onScanFinished(bleDeviceList);
                }
            }
        }

        @Override
        public void onBleScanReject() {
            BleScanPresenterImp callback = getBleScanPresenterImp();
            if (callback != null) {
                callback.onScanReject();
            }
        }
    };

    public void scan(UUID[] serviceUuids, String[] names, String mac, boolean fuzzy,
                     long timeOut, final BleScanCallback callback) {

        startLeScan(serviceUuids, names, mac, fuzzy, false, timeOut, callback);
    }

    public void scanAndConnect(UUID[] serviceUuids, String[] names, String mac, boolean fuzzy,
                               long timeOut, BleScanAndConnectCallback callback) {

        startLeScan(serviceUuids, names, mac, fuzzy, true, timeOut, callback);
    }

    private synchronized void startLeScan(UUID[] serviceUuids, String[] names, String mac, boolean fuzzy,
                                          boolean needConnect, long timeOut, BleScanPresenterImp imp) {

        if (mBleScanState != BleScanState.STATE_IDLE) {
            BleLog.w("scan action already exists, complete the previous scan action first");
            if (imp != null) {
                imp.onScanStarted(BleErrorCode.SCAN_FAILED_ALREADY_STARTED_IN_APP);
            }
            return;
        }

        mBleScanPresenter = new BleScanPresenterImpl(this);
        mBleScanPresenter.prepare(names, mac, fuzzy, needConnect, timeOut, imp);
        BleLog.d("startLeScan, timeOut=" + timeOut);

        BluetoothLeScanner bluetoothLeScanner = BleManager.getInstance().getBluetoothAdapter().getBluetoothLeScanner();
        if (bluetoothLeScanner == null) {
            mBleScanState = BleScanState.STATE_IDLE;
            mBleScanPresenter.notifyScanStarted(BleErrorCode.SCAN_FAILED_BLE_SCANNER_INVALID);
        } else {
            try {
                List<ScanFilter> filters = null;
                if (names != null && names.length > 0) {
                    filters = new ArrayList<>();
                    for (String name: names) {
                        ScanFilter scanFilter = new ScanFilter.Builder()
                                .setDeviceName(name)
//                                .setDeviceAddress(mac)
//                                .setServiceUuid(ParcelUuid.fromString("0000be80-0000-1000-8000-00805f9b34fb"), ParcelUuid.fromString("FFFFFFFF-0000-0000-0000-000000000000"))
                                .build();
                        filters.add(scanFilter);
                    }
                }
                BleLog.i("setScanMode " + BleManager.getInstance().getBleScanProtoDependence().getScanMode());
                ScanSettings scanSettings = new ScanSettings.Builder().setScanMode(BleManager.getInstance().getBleScanProtoDependence().getScanMode()).build();
                bluetoothLeScanner.startScan(filters, scanSettings, mBleScanPresenter);
                mBleScanState = BleScanState.STATE_SCANNING;
                mHandler.post(mNotifyStartSuccessRunnable);
            } catch (Exception e) {
                mBleScanState = BleScanState.STATE_IDLE;
                mBleScanPresenter.notifyScanStarted(BleErrorCode.SCAN_FAILED_LACK_PERMISSION);
                e.printStackTrace();
            }
        }
    }

    public synchronized void stopLeScan() {
        BleLog.d("stopLeScan");
        mHandler.removeCallbacks(mNotifyStartSuccessRunnable);
        try {
            if (BleManager.getInstance().getBluetoothAdapter() != null) {
                BluetoothLeScanner bluetoothLeScanner = BleManager.getInstance().getBluetoothAdapter().getBluetoothLeScanner();
                if (bluetoothLeScanner != null) {
                    bluetoothLeScanner.stopScan(mBleScanPresenter);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            BleLog.ft(e);
        }
        mBleScanState = BleScanState.STATE_IDLE;
        if (mBleScanPresenter != null) {
            mBleScanPresenter.notifyScanStopped();
        }
    }

    public BleScanState getScanState() {
        return mBleScanState;
    }


}
