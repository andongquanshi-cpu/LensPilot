package com.clj.fastble.utils;


import android.util.Log;

public final class BleLog {

    public static boolean isPrint = true;
    private static final String defaultTag = "FastBle";
    private static ILoggerCallback sLoggerCallback;

    public static void v(String msg) {
        if (isPrint && msg != null) {
            if (sLoggerCallback != null) {
                sLoggerCallback.onLogV(defaultTag, msg);
            } else {
                Log.v(defaultTag, msg);
            }
        }
    }

    public static void d(String msg) {
        if (isPrint && msg != null) {
            if (sLoggerCallback != null) {
                sLoggerCallback.onLogD(defaultTag, msg);
            } else {
                Log.d(defaultTag, msg);
            }
        }
    }

    public static void i(String msg) {
        if (isPrint && msg != null) {
            if (sLoggerCallback != null) {
                sLoggerCallback.onLogI(defaultTag, msg);
            } else {
                Log.i(defaultTag, msg);
            }
        }
    }

    public static void w(String msg) {
        if (isPrint && msg != null) {
            if (sLoggerCallback != null) {
                sLoggerCallback.onLogW(defaultTag, msg);
            } else {
                Log.w(defaultTag, msg);
            }
        }
    }

    public static void e(String msg) {
        if (isPrint && msg != null) {
            if (sLoggerCallback != null) {
                sLoggerCallback.onLogE(defaultTag, msg);
            } else {
                Log.e(defaultTag, msg);
            }
        }
    }

    public static void ft(Throwable throwable) {
        if (isPrint && throwable != null) {
            Log.e(defaultTag, throwable.getMessage(), throwable);
            if (sLoggerCallback != null) {
                sLoggerCallback.onLogFt(defaultTag, throwable);
            }
        }
    }

    public static void enableLog(boolean enable) {
        isPrint = enable;
    }

    public static void setLoggerCallback(ILoggerCallback loggerCallback) {
        sLoggerCallback = loggerCallback;
    }

    public interface ILoggerCallback {
        void onLogV(String tag, String msg);

        void onLogD(String tag, String msg);

        void onLogI(String tag, String msg);

        void onLogW(String tag, String msg);

        void onLogE(String tag, String msg);

        void onLogFt(String tag, Throwable t);
    }

}
