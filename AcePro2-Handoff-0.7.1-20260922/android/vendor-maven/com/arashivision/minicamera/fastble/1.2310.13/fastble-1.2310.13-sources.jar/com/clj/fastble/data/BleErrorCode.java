package com.clj.fastble.data;

import android.bluetooth.le.ScanCallback;

public class BleErrorCode {

    // Scan
    public static final int SCAN_SUCCESS = 0;
    public static final int SCAN_FAILED_BLUETOOTH_DISABLED = -1;
    public static final int SCAN_FAILED_BLE_SCANNER_INVALID = -2;
    public static final int SCAN_FAILED_ALREADY_STARTED_IN_APP = -3;
    public static final int SCAN_FAILED_LACK_PERMISSION = -4;
    public static final int SCAN_FAILED_ALREADY_STARTED_IN_SYSTEM = ScanCallback.SCAN_FAILED_ALREADY_STARTED;
    public static final int SCAN_FAILED_APPLICATION_REGISTRATION_FAILED = ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED;
    public static final int SCAN_FAILED_INTERNAL_ERROR = ScanCallback.SCAN_FAILED_INTERNAL_ERROR;
    public static final int SCAN_FAILED_FEATURE_UNSUPPORTED = ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED;
    public static final int SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES = ScanCallback.SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES;
    public static final int SCAN_FAILED_SCANNING_TOO_FREQUENTLY = ScanCallback.SCAN_FAILED_SCANNING_TOO_FREQUENTLY;
}
