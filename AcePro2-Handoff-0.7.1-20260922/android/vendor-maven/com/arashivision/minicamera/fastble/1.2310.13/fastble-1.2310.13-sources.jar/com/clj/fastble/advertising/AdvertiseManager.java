package com.clj.fastble.advertising;

import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;

import com.clj.fastble.callback.BleStopWakeupCallback;
import com.clj.fastble.callback.BleWakeupCallback;
import com.clj.fastble.utils.BleLog;
import com.clj.fastble.utils.HexUtil;

import static com.clj.fastble.BleManager.DEVICE_GO;

/**
 * 蓝牙唤醒
 */
public class AdvertiseManager {

    private static final String BLUE_ADVERTISE_PREFIX = "094f5242495409ff0f00";

    private final BluetoothLeAdvertiser mBluetoothLeAdvertiser;
    private AdvertiseCallbackWrapper mAdvertiseCallbackWrapper;

    public AdvertiseManager(BluetoothLeAdvertiser bluetoothLeAdvertiser) {
        this.mBluetoothLeAdvertiser = bluetoothLeAdvertiser;
    }

    public void startWeakupAdvertising(int deviceType, String deviceName, byte txPower, final BleWakeupCallback bleWakeupCallback) {
        if (mAdvertiseCallbackWrapper != null) {
            stopWakeupAdvertise(null);
        }
        //获取BluetoothLeAdvertiser，BLE发送BLE广播用的一个API
        if (mBluetoothLeAdvertiser != null) {
            try {

                //创建setting
                AdvertiseSettings.Builder builder = new AdvertiseSettings.Builder();
                //设置广播的模式,应该是跟功耗相关
                builder.setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH);
                builder.setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY);
                builder.setConnectable(true);
                builder.setTimeout(0);
                AdvertiseSettings mAdvertiseSettings = builder.build();

                AdvertiseData iBeaconAdvertiseData = createIBeaconAdvertiseData(deviceType, deviceName, (short) 0, (short) 0, txPower);

                mAdvertiseCallbackWrapper = new AdvertiseCallbackWrapper();
                mAdvertiseCallbackWrapper.bleWakeupCallback = bleWakeupCallback;
                mBluetoothLeAdvertiser.startAdvertising(mAdvertiseSettings, iBeaconAdvertiseData, mAdvertiseCallbackWrapper.advertiseCallback);
            } catch (Exception e) {
                BleLog.e("Fail to setup BleService " + e.getLocalizedMessage());
                if (bleWakeupCallback != null) {
                    bleWakeupCallback.wakeupError(-1);
                }
            }
        }
    }

    public void stopWakeupAdvertise(final BleStopWakeupCallback bleStopWakeupCallback) {
        if (mBluetoothLeAdvertiser != null && mAdvertiseCallbackWrapper != null) {
            mAdvertiseCallbackWrapper.bleStopWakeupCallback = bleStopWakeupCallback;
            mBluetoothLeAdvertiser.stopAdvertising(mAdvertiseCallbackWrapper.advertiseCallback);
            mAdvertiseCallbackWrapper = null;
        }
    }

    private static AdvertiseData createIBeaconAdvertiseData(int deviceType, String deviceName, short major, short minor, byte txPower) {

        String proximityUuid = BLUE_ADVERTISE_PREFIX + HexUtil.str2HexStr(deviceName);
        char[] uuidstr = proximityUuid.toCharArray();
        byte[] uuidBytes = new byte[16];
        for (int i = 0, x = 0; i < uuidstr.length; x++) {
            uuidBytes[x] = (byte) ((Integer.parseInt(String.valueOf(uuidstr[i++]), 16) << 4) | Integer.parseInt(String.valueOf(uuidstr[i++]), 16));
        }
        byte[] majorBytes = {(byte) (major >> 8), (byte) (major & 0xff)};
        byte[] minorBytes = {(byte) (minor >> 8), (byte) (minor & 0xff)};
        byte[] mPowerBytes = {txPower};
        byte[] manufacturerData = new byte[0x18];
        byte[] flagibeacon = {0x02, 0x15};
        byte[] flagversion = {0x01};

        System.arraycopy(flagibeacon, 0x0, manufacturerData, 0x0, 0x2);
        System.arraycopy(uuidBytes, 0x0, manufacturerData, 0x2, 0x10);
        System.arraycopy(majorBytes, 0x0, manufacturerData, 0x12, 0x2);
        System.arraycopy(minorBytes, 0x0, manufacturerData, 0x14, 0x2);
        System.arraycopy(mPowerBytes, 0x0, manufacturerData, 0x16, 0x1);
        System.arraycopy(flagversion, 0x0, manufacturerData, 0x17, 0x1);

        AdvertiseData.Builder builder = new AdvertiseData.Builder();
        int manufacturerId;
        if (deviceType == DEVICE_GO) {
            manufacturerId = 0x1A2B;
        } else {
            manufacturerId = 0x004c;
        }
        builder.addManufacturerData(manufacturerId, manufacturerData);
        AdvertiseData adv = builder.build();

        BleLog.i("manufacturerData = " + HexUtil.formatHexString(manufacturerData));
        BleLog.i("new adv " + adv.toString());

        return adv;
    }

    private static class AdvertiseCallbackWrapper {
        private boolean hasStarted = false;
        private BleWakeupCallback bleWakeupCallback;
        private BleStopWakeupCallback bleStopWakeupCallback;
        private final AdvertiseCallback advertiseCallback = new AdvertiseCallback() {
            @Override
            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                super.onStartSuccess(settingsInEffect);
                if (hasStarted) {
                    BleLog.d("onStopSuccess " + settingsInEffect.toString());
                    if (bleStopWakeupCallback != null) {
                        bleStopWakeupCallback.stopWakeupSuccess(settingsInEffect);
                    }
                } else {
                    BleLog.d("onStartSuccess " + settingsInEffect.toString());
                    if (bleWakeupCallback != null) {
                        bleWakeupCallback.wakeupSuccess(settingsInEffect);
                    }
                }
                hasStarted = !hasStarted;
            }

            @Override
            public void onStartFailure(int errorCode) {
                super.onStartFailure(errorCode);
                if (hasStarted) {
                    BleLog.e("onStopFailure, errorCode " + errorCode);
                    if (bleStopWakeupCallback != null) {
                        bleStopWakeupCallback.stopWakeupError(errorCode);
                    }
                } else {
                    BleLog.e("onStartFailure, errorCode " + errorCode);
                    if (bleWakeupCallback != null) {
                        bleWakeupCallback.wakeupError(errorCode);
                    }
                }
                hasStarted = !hasStarted;
            }
        };
    }
}
