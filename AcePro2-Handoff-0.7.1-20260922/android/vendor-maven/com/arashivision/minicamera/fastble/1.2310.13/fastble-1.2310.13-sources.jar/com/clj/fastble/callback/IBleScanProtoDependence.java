package com.clj.fastble.callback;

public interface IBleScanProtoDependence {
    String getDeviceType(int value);

    String transformDeviceName(String deviceName);

    int getScanMode();
}
