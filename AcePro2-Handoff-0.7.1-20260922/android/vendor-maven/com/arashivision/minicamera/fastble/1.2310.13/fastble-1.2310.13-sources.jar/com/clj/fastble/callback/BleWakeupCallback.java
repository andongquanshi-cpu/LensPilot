package com.clj.fastble.callback;

import android.bluetooth.le.AdvertiseSettings;

public interface BleWakeupCallback {

    void wakeupSuccess(AdvertiseSettings errorCode);

    void wakeupError(int errorCode);

}
