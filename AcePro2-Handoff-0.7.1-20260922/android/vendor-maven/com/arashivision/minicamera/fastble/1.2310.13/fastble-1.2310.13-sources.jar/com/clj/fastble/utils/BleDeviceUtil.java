package com.clj.fastble.utils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;

import com.clj.fastble.BleManager;
import com.clj.fastble.data.BleDevice;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class BleDeviceUtil {

    public static boolean isConnected(BluetoothDevice device) {
        try {
            Method m = device.getClass().getMethod("isConnected", (Class[]) null);
            return (boolean) m.invoke(device, (Object[]) null);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<BluetoothDevice> getAllSystemConnectedDevices() {
        try {
            BluetoothManager bluetoothManager = BleManager.getInstance().getBluetoothManager();
            if (bluetoothManager != null) {
                // 三星等部分手机只填STATE_CONNECTED会无返回结果，因此所有state都传入，再由isConnected()过滤
                int[] states = new int[]{BluetoothProfile.STATE_CONNECTED, BluetoothProfile.STATE_CONNECTING, BluetoothProfile.STATE_DISCONNECTED, BluetoothProfile.STATE_DISCONNECTING};
                LinkedHashSet<BluetoothDevice> connectedDevices = new LinkedHashSet<>(bluetoothManager.getDevicesMatchingConnectionStates(BluetoothProfile.GATT, states));
                Iterator<BluetoothDevice> iterator = connectedDevices.iterator();
                while (iterator.hasNext()) {
                    BluetoothDevice device = iterator.next();
                    if (!isConnected(device)) {
                        iterator.remove();
                    }
                }
                return new ArrayList<>(connectedDevices);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public static Set<BluetoothDevice> getAllSystemBondedDevices() {
        try {
            BluetoothAdapter bluetoothAdapter = BleManager.getInstance().getBluetoothAdapter();
            if (bluetoothAdapter == null) {
                return new HashSet<>();
            }
            return bluetoothAdapter.getBondedDevices();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new HashSet<>();
    }

    public static boolean createBond(BleDevice bleDevice) {
        try {
            BluetoothAdapter bluetoothAdapter = BleManager.getInstance().getBluetoothAdapter();
            if (bluetoothAdapter == null) {
                return false;
            }
            if (bleDevice == null || bleDevice.getDevice() == null) {
                return false;
            }
            return bleDevice.getDevice().createBond();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
