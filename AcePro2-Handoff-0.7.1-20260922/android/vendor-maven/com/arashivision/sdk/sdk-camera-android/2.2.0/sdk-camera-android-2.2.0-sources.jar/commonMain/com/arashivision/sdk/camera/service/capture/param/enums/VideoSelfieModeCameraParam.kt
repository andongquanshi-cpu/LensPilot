package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.VideoSelfieMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class VideoSelfieModeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<VideoSelfieMode>(CommonAttrKeys.VIDEO_SELFIE_TYPE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): VideoSelfieMode? = null

    override fun fromInt(value: Int): VideoSelfieMode {
        return VideoSelfieMode.nativeOf(value)
    }

    override fun fromName(name: String): VideoSelfieMode {
        return VideoSelfieMode.protoOf(name)
    }

    override fun toInt(data: VideoSelfieMode): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<VideoSelfieMode> {
        return device.getVideoSelfieMode(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<VideoSelfieMode> {
        return device.fetchVideoSelfieMode(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: VideoSelfieMode): Result<Unit> {
        return device.setVideoSelfieMode(functionMode, value)
    }

}