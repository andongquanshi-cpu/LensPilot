package com.arashivision.sdk.camera.platform

import com.arashivision.sdk.camera.core.model.LiveType
import com.arashivision.sdk.camera.service.preview.PreviewParams
import com.arashivision.sdk.common.type.KMPCameraPreviewPipeline
import com.arashivision.sdk.common.type.KMPContext

expect class PlatformCameraStream() {

    fun init(context: KMPContext?)

    fun openPreviewStream(
        isForLive: Boolean,
        previewParams: PreviewParams,
        isDualStream: Boolean = false,
        mediaOffset: String,
    )

    fun closePreviewStream()

    fun setH265Encode(isH265: Boolean)

    fun isH265Encode(): Boolean

    fun processStreamData(type: Int, data: ByteArray, timestamp: Long)

    fun setPipeline(pipeline: KMPCameraPreviewPipeline?)

    internal fun startLive(
        rtmpUrl: String,
        width: Int,
        height: Int,
        fps: Int,
        bitrate: Int,
        netId: Long,
        liveType: LiveType,
        callback: LiveStreamCallback,
    )

    fun stopLive()
}
