package com.arashivision.sdk.camera.api

import com.arashivision.sdk.camera.core.model.file.FileInfo
import com.arashivision.sdk.camera.core.model.file.MediaFileType
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.callback.ProgressCallback
import com.arashivision.sdk.common.file.InstaFileManager

/**
 * 相机文件服务接口。
 *
 * 提供了与相机内部存储文件交互的功能，包括获取文件服务器地址、
 * 列表查询（支持分页）、文件删除以及媒体文件和日志文件的下载。
 */
interface CameraFile {

    /**
     * 获取相机文件服务器的完整基础 URL（Endpoint）。
     * 例如：`http://192.168.42.1:80/`
     *
     * @return 文件服务器的 Endpoint 字符串。
     */
    fun getEndpoint(): String

    /**
     * 获取相机文件服务器的主机地址（IP）。
     * 例如：`192.168.42.1`
     *
     * @return 主机地址字符串。
     */
    fun getHost(): String

    /**
     * 获取相机文件服务器的端口号。
     *
     * @return 端口号（通常为 80）。
     */
    fun getProt(): Int

    /**
     * 获取相机中的媒体文件列表（回调方式）。
     *
     * @param mediaFileType 需要查询的媒体文件类型，默认为视频和照片。
     * @param includeRecording 是否包含当前正在录制中的文件，默认为 false。
     * @param callback 获取结果的回调，成功时返回文件 URI 列表。
     */
    fun listMediaFiles(mediaFileType: MediaFileType = MediaFileType.VIDEO_AND_PHOTO, includeRecording: Boolean = false, callback: Callback<List<String>>)

    /**
     * 获取相机中的媒体文件列表（挂起函数）。
     *
     * @param mediaFileType 需要查询的媒体文件类型，默认为视频和照片。
     * @param includeRecording 是否包含当前正在录制中的文件，默认为 false。
     * @return 返回包含文件 URI 列表的 [Result] 对象。
     */
    suspend fun listMediaFiles(mediaFileType: MediaFileType = MediaFileType.VIDEO_AND_PHOTO, includeRecording: Boolean = false): Result<List<String>>

    /**
     * 分页获取相机中的媒体文件列表（回调方式）。
     *
     * @param mediaFileType 需要查询的媒体文件类型，默认为视频和照片。
     * @param start 分页起始索引。
     * @param limit 每页请求的最大数量。
     * @param includeRecording 是否包含当前正在录制中的文件，默认为 false。
     * @param callback 获取结果的回调，成功时返回一个 Pair，包含当前页的文件 URI 列表以及总文件数。
     */
    fun listMediaFiles(
        mediaFileType: MediaFileType = MediaFileType.VIDEO_AND_PHOTO, start: Int, limit: Int, includeRecording: Boolean = false, callback: Callback<Pair<List<String>, Int>>
    )

    /**
     * 分页获取相机中的媒体文件列表（挂起函数）。
     *
     * @param mediaFileType 需要查询的媒体文件类型，默认为视频和照片。
     * @param start 分页起始索引。
     * @param limit 每页请求的最大数量。
     * @param includeRecording 是否包含当前正在录制中的文件，默认为 false。
     * @return 返回包含当前页文件 URI 列表及总文件数的 [Result] 对象。
     */
    suspend fun listMediaFiles(
        mediaFileType: MediaFileType = MediaFileType.VIDEO_AND_PHOTO, start: Int, limit: Int, includeRecording: Boolean = false
    ): Result<Pair<List<String>, Int>>


    /**
     * 获取相机中所有文件信息的列表（回调方式）。
     * @param callback 结果的回调。
     */
    fun getFileInfoList(callback: Callback<List<FileInfo>>)

    /**
     * 获取相机中所有文件信息的列表（挂起函数）。
     * @return 返回结果的 [Result] 对象。
     */
    suspend fun getFileInfoList(): Result<List<FileInfo>>

    /**
     * 删除相机中的指定媒体文件（回调方式）。
     *
     * @param uris 需要删除的文件 URI 列表（可变参数）。
     * @param callback 删除结果的回调。
     */
    fun deleteMediaFiles(vararg uris: String, callback: Callback<Unit>)

    /**
     * 删除相机中的指定媒体文件（挂起函数）。
     *
     * @param uris 需要删除的文件 URI 列表（可变参数）。
     * @return 返回删除结果的 [Result] 对象。
     */
    suspend fun deleteMediaFiles(vararg uris: String): Result<Unit>

    /**
     * 下载相机中的媒体文件到本地（挂起函数）。
     *
     * @param url 需要下载的文件的远程 URL。
     * @param targetDir 本地保存的目标目录路径，默认为 SDK 的工作目录。
     * @param progressCallback 可选的下载进度回调，参数为 (已下载字节数, 总字节数)。
     * @return 返回下载成功后的本地文件绝对路径的 [Result] 对象。
     */
    suspend fun downloadMediaFile(
        url: String, targetDir: String, progressCallback: ((progress: Long, total: Long) -> Unit)? = null
    ): Result<String>

    /**
     * 下载相机中的媒体文件到本地（带有进度回调的接口方式）。
     *
     * @param url 需要下载的文件的远程 URL。
     * @param targetDir 本地保存的目标目录路径，默认为 SDK 的工作目录。
     * @param progressCallback 下载进度与结果的回调接口。
     */
    fun downloadMediaFile(url: String, targetDir: String = InstaFileManager.workDir().toString(), progressCallback: ProgressCallback<String, Pair<Long, Long>>)

    /**
     * 下载相机的日志文件到本地（挂起函数）。
     *
     * @param targetDir 本地保存日志文件的目标目录路径，默认为 SDK 的日志目录。
     * @param progressCallback 可选的下载进度回调，参数为 (已下载字节数, 总字节数)。
     * @return 返回下载成功后的本地日志文件绝对路径的 [Result] 对象。
     */
    suspend fun downloadCameraLogFile(
        targetDir: String = InstaFileManager.cameraLogDir().toString(), progressCallback: ((progress: Long, total: Long) -> Unit)? = null
    ): Result<String>

    /**
     * 下载相机的日志文件到本地（带有进度回调的接口方式）。
     *
     * @param targetDir 本地保存日志文件的目标目录路径，默认为 SDK 的日志目录。
     * @param progressCallback 下载进度与结果的回调接口。
     */
    fun downloadCameraLogFile(targetDir: String = InstaFileManager.cameraLogDir().toString(), progressCallback: ProgressCallback<String, Pair<Long, Long>>)
}