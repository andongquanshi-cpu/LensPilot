package com.arashivision.sdk.camera.config.acepro

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import insta360.messages.MultiPhotographyOptionsType

class AceProCameraConfig(override val connectType: ConnectType) : ICameraConfig {

    override fun supportShutdown(): Boolean = true

    override fun supportMultiVideoOptionsList(): List<MultiPhotographyOptionsType> = emptyList()

    override fun captureMinBatteryLevel(): Int = 0

    override fun supportResetCameraWifi(fwVersion: String): Boolean = true

    override fun supportFetchCameraSensorMode(): Boolean = false

    override fun syncOptionMaxStep(): Int {
        return if (connectType == ConnectType.BLE) 16 else 60
    }

    override fun hasChargingBox(): Boolean = false

    override fun supportDownloadJsonParams(): Boolean = true

    override fun getLensName(sensorMode: SensorMode): String = "Iacwa586"

    override fun firmwareUpgradeMinBatteryLevel(): Int = 20

    override fun firmwareUpgradeMinChargingBoxBatteryLevel(): Int = 0

    override fun supportNewRecordInterface(): Boolean = true

    override fun needNotifyWhenCameraRecordOverTimeLimit(): Boolean = false

    override fun isMergedIntoRS(version: String): Boolean = false

    override fun supportBleBroadcastWakeUp(): Boolean = true

    override fun supportNewCaptureControlFlow(): Boolean = true
}