package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.VideoGammaMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded

internal class VideoGammaModeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<VideoGammaMode>(CommonAttrKeys.COLOR_MODE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): VideoGammaMode? = null

    override fun fromInt(value: Int): VideoGammaMode {
        return VideoGammaMode.nativeOf(value)
    }

    override fun fromName(name: String): VideoGammaMode {
        return VideoGammaMode.protoOf(name)
    }

    override fun toInt(data: VideoGammaMode): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<VideoGammaMode> {
        return device.getVideoGammaMode(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<VideoGammaMode> {
        return device.fetchVideoGammaMode(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: VideoGammaMode): Result<Unit> {
        return device.setVideoGammaMode(functionMode, value).thenMirrorVideoLiveIfNeeded(device, functionMode) {
            device.setVideoGammaMode(FunctionMode.VIDEO_LIVE, value)
        }
    }

}