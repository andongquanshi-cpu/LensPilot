package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.FovType
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class FovTypeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<FovType>(CommonAttrKeys.FOV_TYPE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): FovType? = null

    override fun fromInt(value: Int): FovType {
        return FovType.nativeOf(value)
    }

    override fun fromName(name: String): FovType {
        return FovType.protoOf(name)
    }

    override fun toInt(data: FovType): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<FovType> {
        return device.getFovType(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<FovType> {
        return device.fetchFovType(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: FovType): Result<Unit> {
        return device.setFovType(functionMode, value)
    }

}