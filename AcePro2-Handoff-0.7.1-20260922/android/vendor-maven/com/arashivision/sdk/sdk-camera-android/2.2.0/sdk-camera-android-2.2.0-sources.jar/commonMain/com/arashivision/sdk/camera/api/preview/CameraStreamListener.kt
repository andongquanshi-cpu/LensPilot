package com.arashivision.sdk.camera.api.preview

/**
 * 相机预览流回调监听接口。
 *
 *
 */
interface CameraStreamListener {
    /**
     * 当相机预览流开始打开时回调。
     */
    fun onOpening()

    /**
     * 当相机预览流成功打开时回调。
     */
    fun onOpened()

    /**
     * 当相机预览流关闭时回调。
     */
    fun onIdle()

    /**
     * 当预览流参数（分辨率、帧率、裁剪信息等）发生变化时回调。
     *
     * @param paramsUpdate 包含最新预览流参数的数据对象。
     */
    fun onParamsChanged(paramsUpdate: PreviewStreamParamsUpdate)

    /**
     * 当收到预览流数据帧时回调（默认空实现，按需覆写）。
     *
     * @param streamData 包含原始帧数据、时间戳和帧类型的数据对象。
     */
    fun onStreamDataNotify(streamData: PreviewStreamFrame){}

}
