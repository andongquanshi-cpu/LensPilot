package com.arashivision.sdk.camera.config

import com.arashivision.sdk.camera.config.acepro.AceProCameraConfig
import com.arashivision.sdk.camera.config.acepro2.AcePro2CameraConfig
import com.arashivision.sdk.camera.config.go3s.Go3SCameraConfig
import com.arashivision.sdk.camera.config.goultra.GoUltraCameraConfig
import com.arashivision.sdk.camera.config.nanos.NanoSCameraConfig
import com.arashivision.sdk.camera.config.oner.OneRCameraConfig
import com.arashivision.sdk.camera.config.oners.OneRSCameraConfig
import com.arashivision.sdk.camera.config.onex.OneXCameraConfig
import com.arashivision.sdk.camera.config.onex2.OneX2CameraConfig
import com.arashivision.sdk.camera.config.x3.X3CameraConfig
import com.arashivision.sdk.camera.config.x4.X4CameraConfig
import com.arashivision.sdk.camera.config.x4air.X4AirCameraConfig
import com.arashivision.sdk.camera.config.x5.X5CameraConfig
import com.arashivision.sdk.camera.config.x6.X6CameraConfig
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.OptionType
import insta360.messages.PhotographyOptionType

interface ICameraConfig {
    companion object {
        fun createCameraConfig(
            cameraType: CameraType,
            connectType: ConnectType,
        ): ICameraConfig? =
            when (cameraType) {
                CameraType.ONE_X -> OneXCameraConfig(connectType)
                CameraType.ONE_X2 -> OneX2CameraConfig(connectType)
                CameraType.ONE_R -> OneRCameraConfig(connectType)
                CameraType.ONE_RS -> OneRSCameraConfig(connectType)
                CameraType.GO_ULTRA -> GoUltraCameraConfig(connectType)
                CameraType.GO_3S -> Go3SCameraConfig(connectType)
                CameraType.NANO_S -> NanoSCameraConfig(connectType)
                CameraType.X3 -> X3CameraConfig(connectType)
                CameraType.X4 -> X4CameraConfig(connectType)
                CameraType.X5 -> X5CameraConfig(connectType)
                CameraType.X6 -> X6CameraConfig(connectType)
                CameraType.X4_AIR -> X4AirCameraConfig(connectType)
                CameraType.ACE_PRO -> AceProCameraConfig(connectType)
                CameraType.ACE_PRO_2 -> AcePro2CameraConfig(connectType)
                else -> null
            }

        fun supportCameraType(): List<CameraType> =
            listOf(
                CameraType.NANO_S,
                CameraType.ONE_R,
                CameraType.ONE_RS,
                CameraType.ONE_X,
                CameraType.ONE_X2,
                CameraType.X3,
                CameraType.X4,
                CameraType.X4_AIR,
                CameraType.X5,
                CameraType.X6,
                CameraType.GO_3S,
                CameraType.GO_ULTRA,
                CameraType.ACE_PRO,
                CameraType.ACE_PRO_2,
            )

        fun isUseUcd2(cameraType: CameraType): Boolean {
            return cameraType in listOf(CameraType.X6)
        }
    }

    val connectType: ConnectType

    fun getAllOptions(): List<OptionType> {
        val allOption =
            mutableListOf(
                OptionType.VIDEO_RESOLUTION,
                OptionType.VIDEO_BITRATE,
                OptionType.PHOTO_SIZE,
                OptionType.FLICKER_GLOBAL,
                OptionType.ORIGIN_OFFSET,
                OptionType.ORIGIN_OFFSET_V2,
                OptionType.ORIGIN_OFFSET_V3,
                OptionType.BATTERY_INFO,
                OptionType.CHARGEBOX_CONNECTED_STATUS,
                OptionType.CHARGEBOX_CONNECTED_STATUS,
                OptionType.LOCAL_TIME,
                OptionType.TIME_ZONE,
                OptionType.MUTE,
                OptionType.SERIAL_NUMBER,
                OptionType.ACTIVATE_TIME,
                OptionType.QUICK_CAPTURE_ENABLE,
                OptionType.BUTTON_PRESS_OPTIONS,
                OptionType.STORAGE_STATE,
                OptionType.STORAGE_STATE_LIST,
                OptionType.FIRMWAREREVISION,
                OptionType.WIFI_INFO,
                OptionType.OTA_PKG_VERSION,
                OptionType.BOX_OTA_PKG_VERSION,
                OptionType.GO3_VERSION,
                OptionType.HW_BLE_VERSION,
                OptionType.BOX_VERSION,
                OptionType.BOX_BT_VERSION,
                OptionType.WIFI_CHANNEL_LIST,
                OptionType.AUTHORIZATION_ID,
                OptionType.SECOND_STREAM_RES,
                OptionType.PHOTO_SUB_MODE,
                OptionType.VIDEO_SUB_MODE,
                OptionType.CAMERA_TYPE,
                OptionType.BT_REMOTE_VERSION,
                OptionType.BT_REMOTE_TYPE,
                OptionType.VIDEO_ENCODE_TYPE,
                OptionType.MAIN_VIDEO_ENCODE_TYPE,
                OptionType.SENSOR0_SERIAL_VR360,
                OptionType.SENSOR1_SERIAL_VR360,
                OptionType.SENSOR_SERIAL_VR180,
                OptionType.SENSOR_INFO,
                OptionType.IS_SELFIE,
                OptionType.CAMERA_POSTURE,
                OptionType.EXPECT_OUTPUT_TYPE,
                OptionType.INSTAPANO_FOCUS_SENSOR,
                OptionType.GYRO_TIME_STAMP,
                OptionType.CAMERA_LANGUAGE,
                OptionType.OFFSET_STATES,
                OptionType.UUID,
                OptionType.BT_WAKEUP_SW,
                OptionType.DARK_EIS_ENABLE_GLOBAL,
                OptionType.METERING_ENABLE_GLOBAL,
                OptionType.BUTTON_FOLLOW_OPTION,
                OptionType.CAMERA_POSTURE_WHEN_CAPTURE_START,
                OptionType.CHARGEBOX_CONNECTED_STATUS_WHEN_CAPTURE_START,
                OptionType.WINDOW_CROP_INFO,
                OptionType.ASSISTIVE_GRID,
                OptionType.FREEFRAME_GRID,
                OptionType.INTERNAL_SPLICING,
                OptionType.OFFSET_DETECTED_TYPE,
                OptionType.HEAT_SHELL_TYPE,
                OptionType.QUICK_READER_MOVING_FLAG,
                OptionType.HAS_CRASH,
                OptionType.TIME_WATERMARK_SWITCH,
                OptionType.DASHCAM_INFO,
                OptionType.PTZ_PANO_SAVE_SWITCH,
                OptionType.CHECK_BIAS_CORRECTED,
                OptionType.MEDIA_OFFSET,
                OptionType.MEDIA_TIME,
                OptionType.ROLLING_SHUTTER_TIME,
                OptionType.MEDIA_OFFSET_V2,
                OptionType.MEDIA_OFFSET_V3,
                OptionType.MEDIA_OFFSET_V6,
                OptionType.P2P_TRANS_STATUS,
                OptionType.LENS_ACCESSORIES_INFO
            )
        if (connectType == ConnectType.BLE) {
            allOption.remove(OptionType.ORIGIN_OFFSET)
            allOption.remove(OptionType.ORIGIN_OFFSET_V2)
            allOption.remove(OptionType.ORIGIN_OFFSET_V3)
            allOption.remove(OptionType.ORIGIN_OFFSET_3D)
            allOption.remove(OptionType.MEDIA_OFFSET)
            allOption.remove(OptionType.MEDIA_OFFSET_V2)
            allOption.remove(OptionType.MEDIA_OFFSET_V3)
            allOption.remove(OptionType.MEDIA_OFFSET_3D)
            allOption.remove(OptionType.CALIBRATION_OFFSET)
            allOption.remove(OptionType.CALIBRATION_OFFSET_3D)
        }
        return allOption
    }

    fun excludePhotographyOptions(): List<PhotographyOptionType> {
        return listOf()
    }

    fun getAllPhotographyOptions(): MutableList<PhotographyOptionType> {
        val exclude = excludePhotographyOptions()
        return mutableListOf(
            PhotographyOptionType.CHANNEL,
            PhotographyOptionType.BRIGHTNESS,
            PhotographyOptionType.CONTRAST,
            PhotographyOptionType.SATURATION,
            PhotographyOptionType.HUE,
            PhotographyOptionType.SHARPNESS,
            PhotographyOptionType.EXPOSURE_BIAS,
            PhotographyOptionType.EXPOSURE_MODE,
            PhotographyOptionType.EXPOSURE_PROG,
            PhotographyOptionType.EXPOSURE_MANUAL,
            PhotographyOptionType.AE_METER_MODE,
            PhotographyOptionType.AE_MANUAL_METER_WEIGHT,
            PhotographyOptionType.WHITE_BALANCE,
            PhotographyOptionType.WHITE_BALANCE_VALUE,
            PhotographyOptionType.FLICKER,
            PhotographyOptionType.EV_INDEX,
            PhotographyOptionType.VIDEO_GAMMA_MODE,
            PhotographyOptionType.LONG_EXPOSURE_MANUAL,
            PhotographyOptionType.STILL_EXPOSURE_OPTIONS,
            PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS,
            PhotographyOptionType.PREVIEW_MCTF_ENABLE,
            PhotographyOptionType.PREVIEW_SPORT_MODE_ENABLE,
            PhotographyOptionType.VIDEO_ISO_TOP_LIMIT,
            PhotographyOptionType.RAW_CAPTURE_TYPE,
            PhotographyOptionType.PHOTOGRAPHY_SELF_TIMER,
            PhotographyOptionType.AEB_CAPTURE_NUM,
            PhotographyOptionType.PREVIEW_SPORT_LEVEL,
            PhotographyOptionType.RECORD_DURAION,
            PhotographyOptionType.PHOTO_SIZE_ID,
            PhotographyOptionType.RECORD_RESOLUTION,
            PhotographyOptionType.PHOTO_RESOLUTION,
            PhotographyOptionType.FOV_TYPE,
            PhotographyOptionType.PHOTO_GRAPHY_BITRATE,
            PhotographyOptionType.FLOWSTATE_BASE_TYPE,
            PhotographyOptionType.VIDEO_FLOWSTATE_BASE_TYPE,
            PhotographyOptionType.DOUBLE_ZOOM,
            PhotographyOptionType.FLOWSTATE_LEVEL,
            PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5,
            PhotographyOptionType.STARLAPSE_EXPORT_TYPE,
            PhotographyOptionType.COLOR_MODE,
            PhotographyOptionType.RES_REC_LIMIT,
            PhotographyOptionType.ACCELERATE_FREQUENCY,
            PhotographyOptionType.FOCAL_LENGTH_VALUE,
            PhotographyOptionType.REMAINING_TIME,
            PhotographyOptionType.DARK_EIS_ENABLE,
            PhotographyOptionType.BURST_CAPTURE_NUM,
            PhotographyOptionType.CACHE_CAPTURE_NUM,
            PhotographyOptionType.METERING_ENABLE,
            PhotographyOptionType.BURST_CAPTURE_TIME,
            PhotographyOptionType.CACHE_CAPTURE_ENABLE,
            PhotographyOptionType.ZOOM_SCALE,
            PhotographyOptionType.MAX_REC_TIME,
            PhotographyOptionType.PANO_EXPOSURE_MODE,
            PhotographyOptionType.VIDEO_SELFIE_MODE,
            PhotographyOptionType.HDR_SWITCH_STATUS,
            PhotographyOptionType.FLOWSTATE_HORIZON_ENABLE,
            PhotographyOptionType.I_LOG_SWITCH,
            PhotographyOptionType.COLOR_RECOVERY_SWITCH,
            PhotographyOptionType.FACE_OPTIMIZE_MODE,
            PhotographyOptionType.RENDER_VLP_EULER,
            PhotographyOptionType.RENDER_VLP_RES,
            PhotographyOptionType.RENDER_VLP_FOV,
            PhotographyOptionType.RENDER_VLP_QUAT,
            PhotographyOptionType.RENDER_DISTORTION_CORRECTION,
            PhotographyOptionType.VIRTUAL_PTZ_MOVEMENT_STATUS,
            PhotographyOptionType.RENDER_CENTER_POINT,
            PhotographyOptionType.PHOTO_HDR_TYPE,
            PhotographyOptionType.PURE_VIDEO_ENHANC_TYPE,
            PhotographyOptionType.PTZ_FOV_FACTOR,
            PhotographyOptionType.TRACKING_RESET,
            PhotographyOptionType.P3_SWITCH,
            PhotographyOptionType.P3_EXTEND_PARAM,
            PhotographyOptionType.LIVEPHOTO_MODE,
            PhotographyOptionType.MACROLENS_SWITCH,
            PhotographyOptionType.BEAUTY_SWITCH,
            PhotographyOptionType.CAPTURE_BEAUTY_PARAM,
            PhotographyOptionType.IQ_3A_MODE,
        ).filter { !exclude.contains(it) }.toMutableList()
    }

    fun getSyncOptionsGroups(): List<List<OptionType>> {
        val shortGroups: List<OptionType> =
            listOf(
                OptionType.VIDEO_RESOLUTION,
                OptionType.PHOTO_SIZE,
                OptionType.GYRO_CALIBRATE_STATE,
                OptionType.AUDIO_BITRATE,
                OptionType.INSTAPANO_FOCUS_SENSOR,
                OptionType.CAPTURE_TIME_LIMIT,
                OptionType.GPS_TIMEOUT,
                OptionType.REMAINING_CAPTURE_TIME,
                OptionType.REMAINING_PICTURES,
                OptionType.BATTERY_INFO,
                OptionType.LOCAL_TIME,
                OptionType.TIME_ZONE,
                OptionType.MUTE,
                OptionType.BUTTON_PRESS_OPTIONS,
                OptionType.ACTIVATE_TIME,
                OptionType.STORAGE_STATE,
                OptionType.STORAGE_STATE_LIST,
                OptionType.LENS_INDEX,
                OptionType.SELF_TIMER,
                OptionType.GYRO_SAMPLE_RATE,
                OptionType.ACC_FULL_SCALE_RANGE,
                OptionType.GYRO_FULL_SCALE_RANGE,
                OptionType.TAKE_RAW_PICTURE,
                OptionType.GAMMA_MODE,
                OptionType.MEDIA_TIME,
                OptionType.SYS_ADOPTION,
                OptionType.GYRO_FILTER,
                OptionType.MCTF_ENABLE,
                OptionType.SPORT_MODE_ENABLE,
                OptionType.PHOTO_SUB_MODE,
                OptionType.VIDEO_SUB_MODE,
                OptionType.SECOND_STREAM_RES,
                OptionType.GYRO_POLYFIT_STATE,
                OptionType.EVO_STATUS_MODE,
                OptionType.BT_REMOTE_TYPE,
                OptionType.QUALITY_SETTING,
                OptionType.OVERHEAT_PROTECTION,
                OptionType.STANDBY_DURATION,
                OptionType.QUICK_CAPTURE_ENABLE,
                OptionType.TELEVISION_SYSTEM,
                OptionType.INTERNAL_FLOWSTATE,
                OptionType.VIDEO_ENCODE_TYPE,
                OptionType.SENSOR_INFO,
                OptionType.IS_SELFIE,
                OptionType.VIDEO_BITRATE,
                OptionType.GYRO_TIME_STAMP,
                OptionType.VIDEO_FOV,
                OptionType.STILL_FOV,
                OptionType.CHECK_BIAS_CORRECTED,
                OptionType.ROLLING_SHUTTER_TIME,
                OptionType.MOBVOI_LICENSE_VERITY_STATE,
                OptionType.FLICKER_GLOBAL,
                OptionType.TEMP_VALUE,
                OptionType.AUDIO_SAMPLERATE,
                OptionType.EXPECT_OUTPUT_TYPE,
                OptionType.HW_TYPE,
                OptionType.CHARGEBOX_CONNECTED_STATUS,
                OptionType.BT_CAR_TABLE,
                OptionType.CAMERA_LANGUAGE,
                OptionType.PTZ_CTRL,
                OptionType.MODULE_TYPE,
                OptionType.SFR_CALIBRATION_STATUS,
                OptionType.SENSOR_TEMP_VALUE,
                OptionType.FACTORY_MODE_STATUS,
                OptionType.FAC_AGEING_STATUS,
                OptionType.RAW10BIT_ENABLE,
                OptionType.CAMERA_POSTURE,
                OptionType.GYRO_BIAS,
                OptionType.VERTICAL_FLIP_ENABLE,
                OptionType.GYRO_MASETER_HW_STATE,
                OptionType.OFFSET_STATES,
                OptionType.SENSOR_283LensType,
                OptionType.VOICE_CTRL_LANGUAGE,
                OptionType.VOICE_CTRL_ENABLE,
                OptionType.MAIN_MODE,
                OptionType.AUDIO_RECODER_ENABLE,
                OptionType.AUDIO_WNR_TYPE,
                OptionType.AUTO_SHUTDOWN_TIME,
                OptionType.APP_LIVE_VIEW_STATUS,
                OptionType.CAMERA_BITRATE_TYPE,
                OptionType.WIFI_WORKING_STATUS,
                OptionType.BUTTON_FOLLOW_OPTION,
                OptionType.LED_SWITCH,
                OptionType.BEEP_SWITCH,
                OptionType.CAMERA_POSTURE_WHEN_CAPTURE_START,
                OptionType.CHARGEBOX_CONNECTED_STATUS_WHEN_CAPTURE_START,
                OptionType.CLOUD_IS_BUSY_STATUS,
                OptionType.HW_VERSION,
                OptionType.UDISK_MODE,
                OptionType.BT_WAKEUP_SW,
                OptionType.BUTTON_AUTO_FOLLOW,
                OptionType.METERING_ENABLE_GLOBAL,
                OptionType.RC_CONN_INFO,
                OptionType.AUTHORIZATION_CLEAN,
                OptionType.MAIN_VIDEO_ENCODE_TYPE,
                OptionType.IPERF_STATUS,
                OptionType.WIFI_FACTORY,
                OptionType.ASSISTIVE_GRID,
                OptionType.FREEFRAME_GRID,
                OptionType.INTERNAL_SPLICING,
                OptionType.DARK_EIS_ENABLE_GLOBAL,
                OptionType.SHARPNESS_GLOBAL,
                OptionType.LIGHT_REFRESH_RATE,
                OptionType.RF_RSSI,
                OptionType.FINDMY_ENABLE,
                OptionType.CANCEL_CAPTURE_ENABLE,
                OptionType.CANCEL_CAPTURE_GUIDE_FLAG,
                OptionType.QUICK_READER_MOVING_FLAG,
                OptionType.HAND_CONTROL_ENABLE,
                OptionType.HEAT_SHELL_TYPE,
                OptionType.OFFSET_DETECTED_TYPE,
                OptionType.CHILD_MODE,
                OptionType.HORIZON_INDICATOR_ENABLE,
                OptionType.CAMERA_BT_RSSI,
                OptionType.Q_BUTTON_CUSTOM_ACTION_INFO,
                OptionType.HAS_CRASH,
                OptionType.WINDOW_CROP_INFO,
                OptionType.TIME_WATERMARK_SWITCH,
                OptionType.DASHCAM_INFO,
                OptionType.CO_BRANDED_PRODUCT_ID,
                OptionType.PTZ_PANO_SAVE_SWITCH,
                OptionType.WIFI_STATUS,
                OptionType.RECTIFY_GYRO_BIAS,
                OptionType.WIRELESS_LINK_NUM,
                OptionType.LIVE_BROADCAST_STATUS,
                OptionType.LONG_BATTERY,
                OptionType.P2P_TRANS_STATUS,
                OptionType.HORIZON_FILP_ENABLE,
                OptionType.LENS_ACCESSORIES_INFO,
                OptionType.STREET_PHOTO_TYPE,
                OptionType.FINDMY_TOKEN_ID,
                OptionType.SERIAL_NUMBER,
                OptionType.UUID,
                OptionType.FIRMWAREREVISION,
                OptionType.CPU_TYPE,
                OptionType.WIFI_INFO,
                OptionType.WIFI_CHANNEL_LIST,
                OptionType.AUTHORIZATION_ID,
                OptionType.CAMERA_TYPE,
                OptionType.BT_REMOTE_VERSION,
                OptionType.CALIBRATION_ORIENTATION,
                OptionType.BT_MAC_ADDR,
                OptionType.SENSOR0_SERIAL_VR360,
                OptionType.SENSOR1_SERIAL_VR360,
                OptionType.SENSOR_SERIAL_VR180,
                OptionType.MOBVOI_LICENSE,
                OptionType.GYRO_INFO,
                OptionType.SENSOR_ID,
                OptionType.HW_BLE_VERSION,
                OptionType.FACTORY_CALIBRATION_STATUS,
                OptionType.OTA_PKG_VERSION,
                OptionType.BOX_OTA_PKG_VERSION,
                OptionType.BOX_BT_VERSION,
                OptionType.BOX_VERSION,
                OptionType.GO3_VERSION,
                OptionType.FINDMY_TOKEN,
                OptionType.FINDMY_TOKEN_UUID,
                OptionType.USB_STORAGE_PASSWD,
                OptionType.MOBVOI_PUBLIC_KEY,
                OptionType.CARD_LOCATION_LAST_UPDATE,
            )
        val longGroups: List<OptionType> =
            listOf(
                OptionType.ORIGIN_OFFSET,
                OptionType.MEDIA_OFFSET,
                OptionType.ORIGIN_OFFSET_V2,
                OptionType.MEDIA_OFFSET_V2,
                OptionType.ORIGIN_OFFSET_V3,
                OptionType.MEDIA_OFFSET_V3,
                OptionType.ORIGIN_OFFSET_3D,
                OptionType.MEDIA_OFFSET_3D,
                OptionType.CALIBRATION_OFFSET,
                OptionType.CALIBRATION_OFFSET_3D,
                OptionType.MEDIA_OFFSET_V6,
            )
        return if (connectType == ConnectType.BLE) {
            shortGroups.chunked(syncOptionMaxStep()) + longGroups.chunked(1)
        } else {
            getAllOptions().chunked(syncOptionMaxStep())
        }
    }

    fun getSyncPhotographyOptionsGroups(): List<List<PhotographyOptionType>> = getAllPhotographyOptions().chunked(syncOptionMaxStep())

    fun supportShutdown(): Boolean

    fun supportMultiVideoOptionsList(): List<MultiPhotographyOptionsType>

    fun captureMinBatteryLevel(): Int

    fun supportResetCameraWifi(fwVersion: String): Boolean

    fun supportFetchCameraSensorMode(): Boolean

    fun syncOptionMaxStep(): Int

    fun hasChargingBox(): Boolean

    fun supportDownloadJsonParams(): Boolean

    fun getLensName(sensorMode: SensorMode): String

    fun firmwareUpgradeMinBatteryLevel(): Int

    fun firmwareUpgradeMinChargingBoxBatteryLevel(): Int

    fun supportNewRecordInterface(): Boolean

    fun needNotifyWhenCameraRecordOverTimeLimit(): Boolean

    /**
     * 仅RS需要支持判断
     */
    fun isMergedIntoRS(version: String): Boolean

    fun isDualStream(resolution: RecordResolution): Boolean = false

    fun supportRepeatOpenStream(): Boolean = false

    fun supportBleBroadcastWakeUp(): Boolean = false

    fun supportNewCaptureControlFlow(): Boolean = false

    fun muteNegate(): Boolean = false

    fun needAuthorization(): Boolean = false

    fun supportInnerStorage(): Boolean = false

    fun supportLowPowerMode(): Boolean = false

    /**
     * 拍照是否走 AIPL 链路。
     *
     * 走该链路的机型对一次拍照会回两次结果：第一次仅表示快门已触发、不含成片路径，
     * 待落盘完成后才回第二次并携带真实路径；成片路径统一等拍摄结束通知到达时才上报。
     * 未走该链路的机型在首次结果里就带路径。
     */
    fun supportAiplPhotoCapture(): Boolean = false

}
