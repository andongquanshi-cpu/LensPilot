package com.arashivision.sdk.camera.core.model.notify

import com.arashivision.sdk.camera.core.model.BaseEnum
import com.arashivision.sdk.camera.core.model.notify.TempState.LOW

enum class CameraPosture(override val nativeValue: Int): BaseEnum {
    CAMERA_POSTURE_ROTATE_0(0),
    CAMERA_POSTURE_ROTATE_90(1),
    CAMERA_POSTURE_ROTATE_180(2),
    CAMERA_POSTURE_ROTATE_270(3),
    CAMERA_POSTURE_UP(4),
    CAMERA_POSTURE_DOWN(5);

    companion object {
        fun nativeOf(value: Int?): CameraPosture = CameraPosture.entries.firstOrNull { it.nativeValue == value } ?: CAMERA_POSTURE_ROTATE_0
    }
}