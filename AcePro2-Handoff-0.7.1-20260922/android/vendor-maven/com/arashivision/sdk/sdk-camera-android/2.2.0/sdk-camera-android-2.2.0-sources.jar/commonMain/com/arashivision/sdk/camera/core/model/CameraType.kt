package com.arashivision.sdk.camera.core.model

enum class CameraType(
    val type: String,
    val simpleName: String,
    val displayName: String,
    val bleScanProtoValue: Int = -1
) {
    ONE_X("Insta360 One2", "ONE X", "Insta360 ONE X"),
    ONE_X2("Insta360 ONE X2", "ONE X2", "Insta360 ONE X2"),
    ONE_R("Insta360 OneR", "ONE R", "Insta360 OneR"),
    ONE_RS("Insta360 OneRS", "ONE RS", "Insta360 OneRS"),
    GO("Insta360 Go", "Go", "Insta360 Go"),
    GO_2("Insta360 GO 2", "GO 2", "Insta360 GO 2"),
    GO_3("Insta360 GO 3", "GO 3", "Insta360 GO 3"),
    GO_ULTRA("Insta360 GO Ultra", "GO Ultra", "Insta360 GO Ultra", 1),
    GO_3S("Insta360 GO 3S", "GO 3S", "Insta360 GO 3S"),
    NANO_S("Insta360 Nano S", "Nano S", "Insta360 Nano S"),
    SPHERE("Insta360 Sphere", "Sphere", "Insta360 Sphere"),
    X3("Insta360 X3", "X3", "Insta360 X3"),
    X4("Insta360 X4", "X4", "Insta360 X4"),
    X5("Insta360 X5", "X5", "Insta360 X5"),
    X6("Insta360 X6", "X6", "Insta360 X6"),
    X4_AIR("Insta360 X4 Air", "X4 Air", "Insta360 X4 Air"),
    ACE("Insta360 Ace", "Ace", "Insta360 Ace"),
    ACE_PRO("Insta360 Ace Pro", "Ace Pro", "Insta360 Ace Pro"),
    ACE_PRO_2("Insta360 Ace Pro 2", "Ace Pro 2", "Insta360 Ace Pro 2"),
    UNKNOWN("Unknown", "", "");


    fun getProductCode(): String {
        return when (this) {
            GO_3 -> "IBK"
            GO_3S -> "IAT"
            X5 -> "IAH"
            X6 -> "BX"
            X4_AIR -> "IAF"
            GO_ULTRA -> "IBE"
            ACE_PRO_2 -> "IBG"
            else -> ""
        }
    }

    /**
     * 是否是广角相机
     */
    fun isWideAngleCamera(): Boolean {
        return this in listOf(GO, GO_2, GO_3, GO_3S, GO_ULTRA, ACE, ACE_PRO, ACE_PRO_2)
    }

    /**
     * 是否是全景相机
     */
    fun isPanoramaCamera(): Boolean {
        return this in listOf(ONE_X, ONE_X2, ONE_R, ONE_RS, NANO_S, SPHERE, X3, X4, X4_AIR, X5, X6)
    }

    companion object {
        const val BLE_SCAN_PROTO_UNKNOWN: Int = -1

        fun getTypeByProductCode(productCode: String?): CameraType {
            for (cameraType in entries) {
                if (cameraType.getProductCode() == productCode) return cameraType
            }
            return UNKNOWN
        }

        fun getForType(type: String?): CameraType {
            for (cameraType in entries) {
                if (cameraType.type == type) {
                    return cameraType
                }
            }
            return UNKNOWN
        }

        fun getForSimpleName(name: String?): CameraType {
            val prefix = extractDevicePrefix(name) ?: return UNKNOWN
            for (cameraType in entries) {
                if (prefix == cameraType.simpleName) {
                    return cameraType
                }
            }
            return UNKNOWN
        }

        /**
         * 清洗蓝牙名/Wi-Fi SSID 并去除序列号，提取设备前缀用于精确匹配。
         * 清洗规则：去掉 ".OSC" 后缀、去掉 "-n" 递增尾号、"_" 替换为空格；
         * 再按空格分割，去掉最后一段（视为序列号），剩余部分拼接为前缀。
         */
        private fun extractDevicePrefix(name: String?): String? {
            if (name.isNullOrEmpty()) return null
            val cleaned = name
                .replace(".OSC", "")
                .replace(Regex("-[1-9]\\d*$"), "")
                .replace("_", " ")
                .trim()
            val parts = cleaned.split(" ").filter { it.isNotEmpty() }
            if (parts.isEmpty()) return null
            if (parts.size == 1) return parts[0]
            return parts.take(parts.size - 1).joinToString(" ")
        }
    }

}