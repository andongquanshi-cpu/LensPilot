package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class ExpectOutputType(override val nativeValue: Int) : BaseEnum {
    DEFAULT(0),
    INSTA_PANO(1),
    MULTI_CAMERA(2),
    ONE_TAKE(3);

    companion object {
        fun nativeOf(nativeValue: Int?): ExpectOutputType {
            return ExpectOutputType.entries.firstOrNull { it.nativeValue == nativeValue } ?: DEFAULT
        }
    }
}