package com.arashivision.sdk.camera.api.preview

/**
 * 直播推流参数。
 *
 * @param rtmpUrl  RTMP 推流地址。
 * @param mode     直播渲染模式（全景拼接/全景原始/平面），与 functionMode 无关。
 *                 不传时由 SDK 依据相机当前镜头状态自动判定（双镜头 -> 全景拼接，单镜头/广角 -> 平面）。
 * @param width    推流画面宽度（像素）。
 * @param height   推流画面高度（像素）。
 * @param fps      推流帧率。
 * @param bitrate  推流码率（单位 Mbps，底层内部转换为 bps）。
 * @param netId    推流使用的网络 id，默认 -1（底层默认网络）。
 *                 SDK 不管理网络，调用方按需传入对应 network id（如绑定蜂窝网络时的 id）。
 */
data class CameraLiveParams(
    val rtmpUrl: String,
    val mode: LiveMode? = null,
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Int,
    val netId: Long = -1L,
)
