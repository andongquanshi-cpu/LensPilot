package com.arashivision.sdk.camera.core.delegate.timelapse

import com.arashivision.sdk.camera.core.model.timelapse.TimelapseParams
import insta360.messages.TimelapseOptions

interface TimelapseOptionDelegate {

    fun getTimelapseOption(timelapseMode: Int): Result<TimelapseParams>

    suspend fun setTimelapseOption(timelapseMode: Int, timelapseParams: TimelapseParams): Result<Unit>

    suspend fun fetchTimelapseOption(timelapseMode: Int): Result<TimelapseParams>
}