package com.arashivision.sdk.camera.core.model.authorization

enum class AuthorizationOperationType(val value: Int) {
    BLE_CONNECT(0),
    WIFI_PWD_SETTING(1),
    CLOUD_BIND(2),
    USB_STORAGE_PASSWD_SETTING(3);

    companion object {
        fun nativeOf(value: Int): AuthorizationOperationType =
            entries.firstOrNull { it.value == value } ?: BLE_CONNECT
    }
}
