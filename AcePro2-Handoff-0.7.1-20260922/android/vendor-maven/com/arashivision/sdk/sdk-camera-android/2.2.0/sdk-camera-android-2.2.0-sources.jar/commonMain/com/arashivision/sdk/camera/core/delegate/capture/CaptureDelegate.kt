package com.arashivision.sdk.camera.core.delegate.capture

import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus
import com.arashivision.sdk.camera.core.model.capture.CaptureStatus
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.photography.RawType

interface CaptureDelegate {

    val captureStatus: CaptureStatus
    val functionMode: FunctionMode

    fun fetchCaptureState(callback: Callback<CameraCaptureStatus>)
    suspend fun fetchCaptureState(): Result<CameraCaptureStatus>

    fun switchFunctionMode(functionMode: FunctionMode, callback: Callback<Unit>)
    suspend fun switchFunctionMode(functionMode: FunctionMode): Result<Unit>

    fun checkCaptureConditions(functionMode: FunctionMode): Result<Unit>

    fun isWorking(functionMode: FunctionMode = FunctionMode.NONE): Boolean

    fun isPreRecording(): Boolean

    fun cancelPreRecord()

    fun startPhotoNormal(rawType: RawType, extraData: ByteArray? = null, selfTime: Int?)
    fun stopPhotoNormal()

    fun startPhotoNormalPano(sensor: SensorMode, rawType: RawType, extraData: ByteArray? = null)

    fun startPhotoHdr(evBias: List<Int>, rawType: RawType, extraData: ByteArray? = null)

    fun startPhotoHdrPano(sensor: SensorMode, evBias: List<Int>, rawType: RawType, extraData: ByteArray? = null)

    fun startPhotoNight(rawType: RawType, extraData: ByteArray? = null)

    fun startPhotoBurst(rawType: RawType, extraData: ByteArray? = null)

    fun startPhotoInterval(extraData: ByteArray? = null)
    fun stopPhotoInterval()

    fun startPhotoStarLapse(extraData: ByteArray? = null)
    fun stopPhotoStarLapse()

    fun startVideoNormal()
    fun stopVideoNormal(extraData: ByteArray? = null)

    fun startVideoSuper()
    fun stopVideoSuper(extraData: ByteArray? = null)

    fun startVideoBulletTime()
    fun stopVideoBulletTime(extraData: ByteArray? = null)

    fun startVideoTimelapse()
    fun stopVideoTimelapse(extraData: ByteArray? = null)

    fun startVideoHdr()
    fun stopVideoHdr(extraData: ByteArray? = null)

    fun startVideoTimeShift()
    fun stopVideoTimeShift(extraData: ByteArray? = null)

    fun startVideoLooperRecording()
    fun stopVideoLooperRecording(extraData: ByteArray? = null)

    fun startVideoFpv()
    fun stopVideoFpv(extraData: ByteArray? = null)

    fun startVideoMovie()
    fun stopVideoMovie(extraData: ByteArray? = null)

    fun startVideoSlowMotion()
    fun stopVideoSlowMotion(extraData: ByteArray? = null)

    fun startVideoSelfie()
    fun stopVideoSelfie(extraData: ByteArray? = null)

    fun startVideoPure()
    fun stopVideoPure(extraData: ByteArray? = null)

    fun startVideoDashCam()
    fun stopVideoDashCam(extraData: ByteArray? = null)

    fun startVideoMosquito()
    fun stopVideoMosquito(extraData: ByteArray? = null)
}