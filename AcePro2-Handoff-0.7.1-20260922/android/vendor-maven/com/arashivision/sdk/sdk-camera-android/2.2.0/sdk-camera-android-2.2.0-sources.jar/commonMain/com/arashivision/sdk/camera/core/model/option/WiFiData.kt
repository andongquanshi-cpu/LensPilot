package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

data class WiFiData(val ssid: String, val pwd: String, val channel: Int, val mode: Mode, val state: State, val pwdVersion: Int, val mac: String, val isBusy: Boolean) {

    enum class Mode(override val nativeValue: Int) : BaseEnum {
        AP(0),
        STA(1),
        P2P(2),
        Android_Aware(3),
        IOS_Aware(4);

        companion object {
            fun nativeOf(nativeValue: Int?): Mode {
                return Mode.entries.firstOrNull { it.nativeValue == nativeValue } ?: AP
            }
        }
    }

    enum class State(override val nativeValue: Int) : BaseEnum {
        UNKNOWN(0),
        AUTO(1),
        ON(2),
        OFF(3);

        companion object {
            fun nativeOf(nativeValue: Int?): State {
                return State.entries.firstOrNull { it.nativeValue == nativeValue } ?: UNKNOWN
            }
        }
    }
}