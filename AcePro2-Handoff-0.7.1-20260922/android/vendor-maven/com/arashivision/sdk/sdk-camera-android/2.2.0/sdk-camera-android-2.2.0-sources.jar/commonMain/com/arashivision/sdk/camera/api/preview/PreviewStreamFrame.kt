package com.arashivision.sdk.camera.api.preview

/**
 * 预览流数据帧（对外稳定类型）。
 *
 * 说明：
 * - 这是对底层流数据的“瘦包装”，避免第三方调用者直接依赖底层内部类型，确保后续底层混淆或替换不影响 SDK API。
 * - `timestamp` 的单位由底层决定（当前 Demo 中通常按毫秒 ms 使用，并在送入 MediaCodec 解码前转换为微秒 us）。
 *
 * @property data 包含实际音视频或陀螺仪数据的字节数组。
 * @property timestamp 该帧数据的时间戳。
 * @property type 该帧数据的类型（如视频、音频、陀螺仪等），默认为 [PreviewStreamType.UNKNOWN]。
 */
data class PreviewStreamFrame(
    val data: ByteArray,
    val timestamp: Long,
    val type: PreviewStreamType = PreviewStreamType.UNKNOWN
)

/**
 * 预览流数据类型枚举（对外稳定枚举）。
 *
 * 标识当前 [PreviewStreamFrame] 中包含的数据种类。
 */
enum class PreviewStreamType {
    /** 普通视频帧 */
    VIDEO,
    /** 左眼/左侧视频帧（用于全景或 3D 视频） */
    VIDEO_L,
    /** 右眼/右侧视频帧（用于全景或 3D 视频） */
    VIDEO_R,
    /** 音频帧 */
    AUDIO,
    /** 陀螺仪/姿态数据帧 */
    GYRO,
    /** 其他类型数据 */
    OTHER,
    /** 未知类型数据 */
    UNKNOWN;

    /**
     * 判断当前类型是否为视频帧（包含普通视频、左侧视频、右侧视频）。
     */
    val isVideo: Boolean
        get() = this == VIDEO || this == VIDEO_L || this == VIDEO_R
}
