package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class VideoSubMode(override val nativeValue: Int) : BaseEnum {
    NORMAL(0),
    BULLET_TIME(1),
    TIMELAPSE(2),
    HDR(3),
    TIMESHIFT(4),
    SUPER(5),
    LOOP_RECORDING(6),
    FPV(7),
    MOVIE(8),
    SLOW_MOTION(9),
    SELFIE(10),
    PURE(11),

    /**
     * APP直播
     */
    LIVE_VIEW(12),

    /**
     * 机内直播
     */
    CAMERA_LIVE_VIEW(13),

    /**
     * 行车记录仪
     */
    DASH_CAM(14),

    /**
     * 虚拟云台
     */
    PTZ(15),

    /**
     * 蚊子视角
     */
    MOSQUITO(16),

    /**
     * 如果相机当前为拍照模式，则 VideoSubMode 返回 NONE，app据此判断相机当前处于录像还是拍照模式
     */
    NONE(100);

    companion object {
        fun nativeOf(nativeValue: Int?): VideoSubMode {
            return VideoSubMode.entries.firstOrNull { it.nativeValue == nativeValue } ?: NONE
        }
    }
}
