package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class PhotoSubMode(override val nativeValue: Int) : BaseEnum {
    SINGLE(0),
    HDR(1),
    INTERVAL(2),
    BURST(3),
    AEB_NIGHT(4),
    INSTA_PANO(5),
    INSTA_PANO_HDR(6),
    STAR_LAPSE(7),

    /**
     * 如果相机当前为录像模式，则 PhotoSubMode 返回 NONE，app据此判断相机当前处于录像还是拍照模式
     */
    NONE(100);

    companion object {
        fun nativeOf(nativeValue: Int?): PhotoSubMode {
            return PhotoSubMode.entries.firstOrNull { it.nativeValue == nativeValue } ?: NONE
        }
    }
}