package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class OneX2PanoramaSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.NONE
    override val previewStabType = PreviewStabType.STAB_STILL
    override val previewGyroType = PreviewGyroType.ONE_X2

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_960_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_5760_2880_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1440_720_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )
        }
}

class OneX2SingleLenSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode
        get() = if (isFlowStateEnabledForPreview()) PreviewFitMode.FILL else PreviewFitMode.CONTAIN
    override val previewFileType
        get() = if (isFlowStateEnabledForPreview()) PreviewFileType.UNPANORAMA else PreviewFileType.FISH_EYE
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewStabType = PreviewStabType.STAB_FULL_DIRECTIONAL
    override val previewGyroType
        get() = resolveOneX2PreviewGyroType()

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams {
        val flowStateEnabled = isFlowStateEnabledForPreview()
        val secondStream =
            when {
                !flowStateEnabled -> StreamResolution.STREAM_368_368_30FPS
                isVerticalPreview() -> StreamResolution.STREAM_360_640_30FPS
                else -> StreamResolution.STREAM_640_360_30FPS
            }
        return when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_1080_30FPS),
                    secondStream = secondStream,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_2560_1440_30FPS),
                    secondStream = secondStream,
                    previewNum = 1,
                )

            !flowStateEnabled ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1152_1152_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )

            isVerticalPreview() ->
                previewParams(
                    firstStream = StreamResolution.STREAM_720_1280_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1280_720_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )
        }
    }
}
