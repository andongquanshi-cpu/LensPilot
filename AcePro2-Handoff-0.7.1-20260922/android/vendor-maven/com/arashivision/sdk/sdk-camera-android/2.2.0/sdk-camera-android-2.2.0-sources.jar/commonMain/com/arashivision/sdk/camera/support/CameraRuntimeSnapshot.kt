package com.arashivision.sdk.camera.support

import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import insta360.messages.Sensor
import insta360.messages.WindowCropInfo

data class CameraRuntimeSnapshot(
    val cameraType: CameraType,
    val functionMode: FunctionMode,
    val currentRecordResolution: RecordResolution?,
    val mediaOffsetV1: String,
    val mediaOffsetV2: String,
    val mediaOffsetV3: String,
    val mediaOffsetV6: String,
    val stabOffset: String,
    val offsetState: Int,
    val offsetDetectedType: Int,
    val isSelfie: Boolean,
    val isFlowstateOn: Boolean,
    val windowCropInfo: WindowCropInfo?,
    val halfWindowCropInfo: WindowCropInfo?,
    val sensorInfo: Sensor?,
)

/** 依据 mediaOffset 前缀判断当前是否全景（双镜头）模式；"2_" 开头表示双镜头。 */
internal fun CameraRuntimeSnapshot.isPanoramaLens(): Boolean =
    mediaOffsetV6.ifEmpty {
        mediaOffsetV3.ifEmpty {
            mediaOffsetV1
        }
    }.startsWith("2_")
