package com.arashivision.sdk.camera.service.preview

enum class PreviewStatus {
    IDLE, // 预览流处于空闲状态，未开启
    OPENING, // 预览流正在打开中
    OPENED, // 预览流已成功打开
    STOPPING, // 已发出关流命令，等待相机异步确认
    PARAMS_CHANGED, // 预览参数变化
}
