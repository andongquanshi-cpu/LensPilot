package com.arashivision.sdk.camera.core.model.capture

import com.arashivision.sdk.camera.core.model.BaseEnum
import com.arashivision.sdk.camera.core.model.FunctionMode

class CameraCaptureStatus {
    var status = Status.NOT_CAPTURE
    var captureTime: Int = 0
    var subStatus: SubStatus = SubStatus.IDLE

    /**
     * 预录制最大时间，单位：s
     */
    var preRecordMaxTime: Int = 0

    enum class Status(override val nativeValue: Int) : BaseEnum {
        NOT_CAPTURE(0),
        NORMAL_CAPTURE(1),
        TIMELAPSE_CAPTURE(2),

        /**
         * \[2017-09-23\]
         */
        INTERVAL_SHOOTING_CAPTURE(3),

        /**
         * ONEX \[2018-07-24\]
         */
        SINGLE_SHOOTING(4),
        HDR_SHOOTING(5),
        SELF_TIMER_SHOOTING(6),
        BULLET_TIME_CAPTURE(7),
        SETTINGS_NEW_VALUE(8),
        HDR_CAPTURE(9),
        BURST_SHOOTING(10),
        STATIC_TIMELAPSE_SHOOTING(11),
        INTERVAL_VIDEO_CAPTURE(12),
        TIMESHIFT_CAPTURE(13),
        AEB_NIGHT_SHOOTING(14),
        SINGLE_POWER_PANO_SHOOTING(15),
        HDR_POWER_PANO_SHOOTING(16),
        SUPER_NORMAL_CAPTURE(17),
        LOOP_RECORDING_CAPTURE(18),
        STARLAPSE_SHOOTING(19),
        FPV_RECORDING_CAPTURE(20),
        MOVIE_RECORDING_CAPTURE(21),
        SLOW_MOTION_CAPTURE(22),
        SELFIE_RECORDING_CAPTURE(23),
        PURE_RECORDING_CAPTURE(24),
        PRE_RECORD(25),
        TIME_RECORDING(26),
        TIME_INTERVAL_SHOOTING(27),
        PRE_RECORD_STOP(28),
        DASH_CAM(29),
        PTZ_RECORD(30),
        MOSQUITO_SHOOTING(31);

        fun toFunctionMode(): FunctionMode? {
            return when (this) {
                NORMAL_CAPTURE -> FunctionMode.VIDEO_NORMAL
                TIMELAPSE_CAPTURE -> FunctionMode.VIDEO_TIMELAPSE
                INTERVAL_SHOOTING_CAPTURE -> FunctionMode.PHOTO_INTERVAL
                SINGLE_SHOOTING -> FunctionMode.PHOTO_NORMAL
                HDR_SHOOTING -> FunctionMode.PHOTO_HDR
                BULLET_TIME_CAPTURE -> FunctionMode.VIDEO_BULLET_TIME
                HDR_CAPTURE -> FunctionMode.VIDEO_HDR
                BURST_SHOOTING -> FunctionMode.PHOTO_BURST
                TIMESHIFT_CAPTURE -> FunctionMode.VIDEO_TIMESHIFT
                AEB_NIGHT_SHOOTING -> FunctionMode.PHOTO_NIGHT
                SINGLE_POWER_PANO_SHOOTING -> FunctionMode.PHOTO_PANO
                HDR_POWER_PANO_SHOOTING -> FunctionMode.PHOTO_PANO_HDR
                SUPER_NORMAL_CAPTURE -> FunctionMode.VIDEO_SUPER
                LOOP_RECORDING_CAPTURE -> FunctionMode.VIDEO_LOOP_RECORDING
                STARLAPSE_SHOOTING -> FunctionMode.PHOTO_STARLAPSE
                FPV_RECORDING_CAPTURE -> FunctionMode.VIDEO_FPV
                MOVIE_RECORDING_CAPTURE -> FunctionMode.VIDEO_MOVIE
                SLOW_MOTION_CAPTURE -> FunctionMode.VIDEO_SLOW_MOTION
                SELFIE_RECORDING_CAPTURE -> FunctionMode.VIDEO_SELFIE
                PURE_RECORDING_CAPTURE -> FunctionMode.VIDEO_PURE
                DASH_CAM -> FunctionMode.VIDEO_DASHCAM
                MOSQUITO_SHOOTING -> FunctionMode.VIDEO_MOSQUITO
                NOT_CAPTURE -> FunctionMode.NONE
                else -> null
            }
        }

        companion object {
            fun nativeOf(value: Int?): Status {
                return Status.entries.find { it.nativeValue == value } ?: NOT_CAPTURE
            }
        }
    }

    enum class TriggerSource(override val nativeValue: Int) : BaseEnum {
        NULL(0),

        /**
         * 定时录像
         */
        TIMER_REC(1),

        /**
         * 间隔录像
         */
        INTERVAL_REC(2);

        companion object {
            fun nativeOf(code: Int?): TriggerSource {
                return TriggerSource.entries.find { it.nativeValue == code } ?: NULL
            }
        }
    }

    enum class SubStatus(override val nativeValue: Int) : BaseEnum {
        IDLE(0),
        PAUSE(1),
        RECORD_SAVE(2),
        PHOTO_SAVE(3),
        STARTLAPSE_SYNTHESIS(4),

        /**
         * 开始录像但未实际录像
         */
        STARTING(5),
        RUNNING(6),

        /**
         * 开始录像时的录像裁剪状态
         */
        TRIMING_START(7),
        PHOTO_CANCEL(8),
        RECORD_CANCEL(9),
        PRE_RECORDING(10),

        /**
         * 录像运行中状态(表示当前录像状态由预录转正式录像)
         */
        RUNNING_STARTED_WITH_PRE_RECORD(11),

        /**
         * 拍照曝光中
         */
        EXPOSURE(12);

        companion object {
            fun nativeOf(code: Int?): SubStatus {
                return SubStatus.entries.find { it.nativeValue == code } ?: IDLE
            }
        }
    }

    override fun toString(): String {
        return "CameraCaptureStatus(" +
                "captureTime=$captureTime, " +
                "status=$status, " +
                "subStatus=$subStatus, " +
                "preRecordMaxTime=$preRecordMaxTime" +
                ")"
    }
}