package com.arashivision.sdk.camera.core.model

internal enum class LiveType {
    PANO_STITCH,
    PANO_CAPTURE,
    PLANE,
}
