package com.arashivision.sdk.camera.service.capture.param

/**
 * 相机属性键常量，供 CameraCapture/CameraParams 共享。
 */
object CommonAttrKeys {
    const val FUNCTION_MODE = "capture_function_mode"
    const val AEB_CAPTURE_NUM = "aeb_capture_num"
    const val EXPOSURE_BIAS = "exposure_bias"
    const val WHITE_BALANCE = "white_balance"
    const val PHOTOGRAPHY_SELF_TIMER = "photography_self_timer"
    const val SPLICING_BASE_ENABLE = "splicing_base_enable"
    const val VIDEO_ISO_TOP_LIMIT = "video_iso_top_limit"
    const val ACCELERATE_FREQUENCY = "accelerate_frequency"
    const val RECORD_DURATION = "record_duration"
    const val LIVING_BITRATE = "living_bitrate"
    // 连拍参数（JSON: burst_capture_params，格式如 "3/1"）
    const val BURST_CAPTURE_PARAMS = "burst_capture_params"

    // 兼容：历史遗留字段（不推荐直接使用，容易造成 num/time 不一致）
    const val HDR_SWITCH = "hdr_switch"
    const val P3_SWITCH = "p3_switch"
    const val ILOG_SWITCH = "i_log_switch"
    const val PURE_VIDEO_ENHANCE_SWITCH = "pure_video_enhance_switch"
    const val LAPSE_TIME = "lapse_time"
    const val DOUBLE_ZOOM_ENABLE = "undamage_zoom"
    const val LIVEPHOTO_SWITCH = "live_photo_switch"
    const val FILTER_MODE: String = "filter_mode"
    const val COLOR_MODE: String = "color_mode"
    const val VIDEO_SELFIE_TYPE: String = "video_selfie_type"
    const val RECORD_RESOLUTION: String = "record_resolution"
    const val RAW_CAPTURE_TYPE: String = "raw_capture_type"
    const val PHOTO_SIZE: String = "photo_size_id"
    const val PHOTO_RESOLUTION: String = "photo_resolution"
    const val HDR_PHOTO_MODE: String = "hdr_photo_mode"
    const val EXPOSURE_INDIVIDUAL: String = "exposure_individual"
    const val FOV_TYPE: String = "fov_type"
    const val FOCUS_SENSOR: String = "focus_sensor"
    const val FLOWSTATE_LEVEL: String = "flowstate_level"
    const val EXPORT_TYPE: String = "export_type"
    const val EXPOSURE_PROGRAM: String = "exposure_program"
    const val EXPOSURE_ISO = "exposure_iso"
    const val EXPOSURE_SHUTTER_SPEED = "exposure_shutter_speed"
    const val LENS_ACCESSORIES_TYPE = "lens_accessory_type"
    const val IQ_3A_MODE = "iq_3a_mode"
}
