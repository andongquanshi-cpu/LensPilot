package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class Sharpness(override val nativeValue: Int) : BaseEnum {
    LOW(0),
    MEDIUM(1),
    HIGH(2);

    companion object {
        fun nativeOf(nativeValue: Int?): Sharpness {
            return entries.firstOrNull { it.nativeValue == nativeValue } ?: MEDIUM
        }
    }
}
