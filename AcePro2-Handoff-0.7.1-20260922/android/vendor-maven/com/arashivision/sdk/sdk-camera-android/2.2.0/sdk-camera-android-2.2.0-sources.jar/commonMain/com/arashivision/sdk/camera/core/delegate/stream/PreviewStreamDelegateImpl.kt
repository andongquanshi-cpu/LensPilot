package com.arashivision.sdk.camera.core.delegate.stream

import com.arashivision.onecamera.OneDriver
import com.arashivision.sdk.camera.core.DeviceContext
import com.arashivision.sdk.camera.core.delegate.BaseDelegate
import insta360.messages.StartLiveStream

class PreviewStreamDelegateImpl(deviceContext: DeviceContext) :BaseDelegate(deviceContext), PreviewStreamDelegate {

    override fun openPreviewStream(startStreamingParam: StartLiveStream, offset: String) {
        context.transport.previewStream(startStreamingParam, offset)
    }

    override fun closePreviewStream() {
        context.transport.closeStream()

    }

    override fun requestStreamIframe() {
        context.transport.requestStreamIframe()
    }


    override fun setStreamListener(streamListener: OneDriver.OnStreamListener?) {
        context.transport.setStreamListener(streamListener)

    }

    override fun init() {

    }

    override suspend fun release() {

    }
}