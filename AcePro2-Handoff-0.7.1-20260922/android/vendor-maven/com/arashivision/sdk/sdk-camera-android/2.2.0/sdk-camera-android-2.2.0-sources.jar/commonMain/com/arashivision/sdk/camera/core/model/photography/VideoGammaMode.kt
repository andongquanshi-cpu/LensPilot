package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

/**
 * 对应 PhotographyOptionType.VIDEO_GAMMA_MODE（底层字段：PhotographyOptions.gamma_mode）。
 *
 * 注意：该参数在业务/JSON 层使用的 key 为 [ATTR_KEY]（通常叫 filter_mode）。
 * 与 [ColorMode] 概念不同，不要复用同一个枚举类型。
 */
enum class VideoGammaMode(
    override val nativeValue: Int,
    val protoName: String
) : BaseEnum {
    STANDARD(0, "STANDARD"),
    LOG(1, "LOG"),
    VIVID(2, "VIVID"),
    FLAT(3, "FLAT"),
    URBAN_1(4, "URBAN_1"),
    URBAN_2(5, "URBAN_2"),
    OCEANBLUE_1(6, "OCEANBLUE_1"),
    OCEANBLUE_2(7, "OCEANBLUE_2"),
    SNOW_1(8, "SNOW_1"),
    SNOW_2(9, "SNOW_2"),
    BIKING_1(10, "BIKING_1"),
    BIKING_2(11, "BIKING_2"),
    NIGHTLIGHT_1(12, "NIGHTLIGHT_1"),
    NIGHTLIGHT_2(13, "NIGHTLIGHT_2"),
    PORTRAIT(14, "PORTRAIT"),
    LEICA_NAT(15, "LEICA_NAT"),
    LEICA_VIV(16, "LEICA_VIV"),
    FILM(17, "FILM"),
    VINTAGE(18, "VINTAGE"),
    URBAN(19, "URBAN"),
    NIGHT(20, "NIGHT"),
    CLEAR(21, "CLEAR"),
    GLOW(22, "GLOW"),
    SELFIE(23, "SELFIE"),
    NC(24, "NC"),
    NC2(25, "NC2"),
    CC(26, "CC"),
    CC2(27, "CC2"),
    NEON(28, "NEON"),
    VACATION(29, "VACATION"),
    BWHC(30, "BWHC"),
    LEICA_ETN(31, "_LEICA_ETN"),
    LEICA_BW_HC(32, "_LEICA_BW_HC");

    companion object {
        fun nativeOf(value: Int?): VideoGammaMode =
            entries.firstOrNull { it.nativeValue == value } ?: STANDARD

        fun protoOf(name: String?): VideoGammaMode =
            entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: STANDARD
    }
}

