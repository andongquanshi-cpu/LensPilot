package com.arashivision.sdk.camera.api.preview

/**
 * 直播渲染模式，由调用方在 [CameraLiveParams] 中显式指定，与 functionMode 无关。
 */
enum class LiveMode {
    /** 全景拼接直播。 */
    PANO_STITCH,

    /** 全景原始直播（不做拼接，球面渲染）。 */
    PANO_CAPTURE,

    /** 平面直播。 */
    PLANE,
}
