package com.arashivision.sdk.camera.core.config

import com.arashivision.camera.InstaCameraModule
import com.arashivision.common.BleLog
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.ILoggerCallbackCore
import com.arashivision.inskmp.insble.callback.IBleScanProtoDependenceCore
import com.arashivision.sdk.camera.InstaCameraConfig
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.CameraType.Companion.BLE_SCAN_PROTO_UNKNOWN
import com.arashivision.sdk.common.kotlin.allNotNull
import com.arashivision.sdk.common.log.Logger

object DeviceConfigure {

    fun init(app: Any, config: InstaCameraConfig) {
        InstaCameraModule.init(app)
        BleManagerCore.init(app)
        BleManagerCore.setReConnectCount(0).setConnectOverTime(20000).setOperateTimeout(10000)
        BleManagerCore.setBleScanProtoDependence(object : IBleScanProtoDependenceCore {
            override fun getDeviceType(value: Int): String? {
                val unknownPrefix = "${CameraType.UNKNOWN.simpleName} "
                if (BLE_SCAN_PROTO_UNKNOWN == value) return unknownPrefix
                return CameraType.entries.find { it.bleScanProtoValue == value }?.let { "${it.simpleName} " } ?: unknownPrefix
            }

            override fun transformDeviceName(deviceName: String?): String? {
                if (deviceName?.contains("-Find My") == true) {
                    return deviceName.replace("-Find My", "")
                }
                return deviceName
            }

            override fun getScanMode(): Int {
                return config.scanMode
            }
        })
        BleLog.enableLog(true)
        BleLog.setLoggerCallback(object : ILoggerCallbackCore {
            override fun onLogV(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.v(tag!!, msg!!)
                }
            }

            override fun onLogD(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.d(tag!!, msg!!)
                }
            }

            override fun onLogI(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.i(tag!!, msg!!)
                }
            }

            override fun onLogW(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.w(tag!!, msg!!)
                }
            }

            override fun onLogE(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.e(tag!!, msg!!)
                }
            }

            override fun onLogFt(tag: String?, t: Throwable?) {
                allNotNull(tag) {
                    Logger.e(tag!!, t?.message ?: "", t)
                }
            }

        })
    }
}