package com.arashivision.sdk.camera.core.delegate.option

import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.option.BatteryData
import com.arashivision.sdk.camera.core.model.option.ChargeBoxData
import com.arashivision.sdk.camera.core.model.option.ExpectOutputType
import com.arashivision.sdk.camera.core.model.option.FocusSensor
import com.arashivision.sdk.camera.core.model.option.LanguageType
import com.arashivision.sdk.camera.core.model.option.LocalTime
import com.arashivision.sdk.camera.core.model.option.PhotoSubMode
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.VideoEncode
import com.arashivision.sdk.camera.core.model.option.VideoSubMode
import com.arashivision.sdk.camera.core.model.option.WiFiChannel
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.camera.core.model.photography.LensAccessoryType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import insta360.messages.OffsetDetectedType
import insta360.messages.OffsetState
import insta360.messages.OptionType
import insta360.messages.Sensor
import insta360.messages.WindowCropInfo

interface OptionDelegate {

    fun getBatteryData(): Result<BatteryData>
    suspend fun fetchBatteryData(): Result<BatteryData>

    fun getChargeBoxData(): Result<ChargeBoxData>
    suspend fun fetchChargeBoxData(): Result<ChargeBoxData>

    fun getMute(): Result<Boolean>
    suspend fun fetchMute(): Result<Boolean>
    suspend fun setMute(mute: Boolean): Result<Unit>

    fun getSerialNumber(): Result<String>
    suspend fun fetchSerialNumber(): Result<String>

    fun getUuid(): Result<String>
    suspend fun fetchUuid(): Result<String>

    fun getOriginOffset(): Result<String>
    suspend fun fetchOriginOffset(): Result<String>

    fun getActivateTime(): Result<Long>
    suspend fun fetchActivateTime(): Result<Long>
    suspend fun setActivateTime(activeTime: Long): Result<Unit>

    fun getStorageData(): Result<StorageData>
    suspend fun fetchStorageData(): Result<StorageData>

    fun getStorageDataList(): Result<List<StorageData>>
    suspend fun fetchStorageDataList(): Result<List<StorageData>>

    fun getMediaOffset(): Result<String>
    suspend fun fetchMediaOffset(): Result<String>

    fun getFirmwareRevision(): Result<String>
    suspend fun fetchFirmwareRevision(): Result<String>

    fun getWiFiData(): Result<WiFiData>
    suspend fun fetchWiFiData(): Result<WiFiData>

    fun getWiFiChannelList(): Result<WiFiChannel>
    suspend fun fetchWiFiChannelList(): Result<WiFiChannel>

    suspend fun setWiFiCountry(countryCode: String): Result<Unit>

    fun getPhotoSubMode(): Result<PhotoSubMode>
    suspend fun fetchPhotoSubMode(): Result<PhotoSubMode>
    suspend fun setPhotoSubMode(photoSubMode: PhotoSubMode): Result<Unit>

    fun getVideoSubMode(): Result<VideoSubMode>
    suspend fun fetchVideoSubMode(): Result<VideoSubMode>
    suspend fun setVideoSubMode(videoSubMode: VideoSubMode): Result<Unit>

    fun getCameraType(): Result<CameraType>
    suspend fun fetchCameraType(): Result<CameraType>

    fun getVideoEncodeType(): Result<VideoEncode>
    suspend fun fetchVideoEncodeType(): Result<VideoEncode>
    suspend fun setVideoEncodeType(videoEncode: VideoEncode): Result<Unit>

    fun getIsSelfie(): Result<Boolean>
    suspend fun fetchIsSelfie(): Result<Boolean>

    fun getOriginOffsetV2(): Result<String>
    suspend fun fetchOriginOffsetV2(): Result<String>

    fun getOriginOffsetV3(): Result<String>
    suspend fun fetchOriginOffsetV3(): Result<String>

    fun getMediaOffsetV2(): Result<String>
    suspend fun fetchMediaOffsetV2(): Result<String>

    fun getMediaOffsetV3(): Result<String>
    suspend fun fetchMediaOffsetV3(): Result<String>

    fun getMediaOffsetV6(): Result<String>
    suspend fun fetchMediaOffsetV6(): Result<String>

    fun getWindowCropInfo(): Result<WindowCropInfo>

    fun getHalfWindowCropInfo(): Result<WindowCropInfo>

    fun getSensorInfo(): Result<Sensor>
    fun getOffsetState(): Result<OffsetState>
    suspend fun fetchOffsetState(): Result<OffsetState>

    fun getOffsetDetectedType(): Result<OffsetDetectedType>
    suspend fun fetchOffsetDetectedType(): Result<OffsetDetectedType>

    fun getCameraLanguage(): Result<LanguageType>
    suspend fun fetchCameraLanguage(): Result<LanguageType>
    suspend fun setCameraLanguage(languageType: LanguageType): Result<Unit>

    suspend fun setLocalTime(localTime: LocalTime): Result<Unit>

    fun getAssistiveGridEnable(): Result<Boolean>
    suspend fun fetchAssistiveGridEnable(): Result<Boolean>
    suspend fun setAssistiveGridEnable(enable: Boolean): Result<Unit>

    fun getFreeFrameGridEnable(): Result<Boolean>
    suspend fun fetchFreeFrameGridEnable(): Result<Boolean>
    suspend fun setFreeFrameGridEnable(enable: Boolean): Result<Unit>

    fun getVideoResolution(): Result<RecordResolution>
    suspend fun fetchVideoResolution(): Result<RecordResolution>
    suspend fun setVideoResolution(recordResolution: RecordResolution): Result<Unit>

    fun getVideoBitrate(): Result<Int>
    suspend fun fetchVideoBitrate(): Result<Int>
    suspend fun setVideoBitrate(bitrate: Int): Result<Unit>

    fun getInternalSplicingEnable(): Result<Boolean>
    suspend fun fetchInternalSplicingEnable(): Result<Boolean>
    suspend fun setInternalSplicingEnable(enable: Boolean): Result<Unit>

    fun getFocusSensor(): Result<FocusSensor>
    suspend fun fetchFocusSensor(): Result<FocusSensor>
    suspend fun setFocusSensor(focusSensor: FocusSensor): Result<Unit>

    fun getMediaTime(): Result<Long>
    suspend fun fetchMediaTime(): Result<Long>

    fun getExpectOutputType(): Result<ExpectOutputType>
    suspend fun fetchExpectOutputType(): Result<ExpectOutputType>
    suspend fun setExpectOutputType(expectOutputType: ExpectOutputType): Result<Unit>

    fun getDarkEisGlobalEnable(): Result<Boolean>
    suspend fun fetchDarkEisGlobalEnable(): Result<Boolean>
    suspend fun setDarkEisGlobalEnable(enable: Boolean): Result<Unit>

    fun getSharpness(): Result<Int>
    suspend fun fetchSharpness(): Result<Int>
    suspend fun setSharpness(sharpness: Int): Result<Unit>

    fun getRollingShutterTime(): Result<Double>
    suspend fun fetchRollingShutterTime(): Result<Double>

    fun getLensAccessoryInfo(functionMode: FunctionMode): Result<LensAccessoryType>
    suspend fun fetchLensAccessoryInfo(functionMode: FunctionMode): Result<LensAccessoryType>
    suspend fun setLensAccessoryInfo(functionMode: FunctionMode, lensAccessoryType: LensAccessoryType): Result<Unit>


    suspend fun fetchOptions(optionList: List<OptionType>, retryCount: Int = -1, timeoutMs: Int = -1): Result<Unit>
    suspend fun fetchAllOptions(): Result<Unit>
}