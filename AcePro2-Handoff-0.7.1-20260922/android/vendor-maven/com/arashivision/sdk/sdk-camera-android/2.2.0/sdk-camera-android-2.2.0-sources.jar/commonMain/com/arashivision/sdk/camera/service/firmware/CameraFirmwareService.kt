package com.arashivision.sdk.camera.service.firmware

import com.arashivision.sdk.camera.api.CameraFirmware
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.service.CameraService
import com.arashivision.sdk.common.callback.ProgressCallback
import com.arashivision.sdk.common.exception.FirmwareUpgradeCancelException
import com.arashivision.sdk.common.exception.FirmwareUpgradeChargeBoxLowBatteryException
import com.arashivision.sdk.common.exception.FirmwareUpgradeIOException
import com.arashivision.sdk.common.exception.FirmwareUpgradeLowBatteryException
import com.arashivision.sdk.common.exception.FirmwareUpgradeUnknownException
import com.arashivision.sdk.common.kotlin.doUpload
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.getDispatcherProvider
import com.arashivision.sdk.common.kotlin.invokeCallback
import com.arashivision.sdk.common.log.Logger
import io.ktor.utils.io.errors.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CameraFirmwareService(
    camera: DeviceCore, connectType: ConnectType, scope: CoroutineScope, isActive: () -> Boolean
) : CameraService(camera, connectType, scope, isActive), CameraFirmware {

    companion object {
        private const val TAG = "CameraFirmwareService"

        const val FIRMWARE_UPLOAD_PATH = "/upload_fw"
    }

    override fun getVersion(): Result<String> = camera.getFirmwareRevision()

    override suspend fun upgradeFirmware(filePath: String, progress: ((Double) -> Unit)?): Result<Unit> {
        val batteryLevel = camera.getBatteryData().getOrNull()?.level ?: 0
        val minBatteryLevel = camera.getCameraConfig().getOrNull()?.firmwareUpgradeMinBatteryLevel() ?: 0
        if (batteryLevel < minBatteryLevel) {
            return FirmwareUpgradeLowBatteryException(minBatteryLevel).failure()
        }
        if (camera.getCameraConfig().getOrNull()?.hasChargingBox() == true) {
            val chargeBoxBatteryData = camera.getChargeBoxData().getOrNull()?.batteryData?.level ?: 0
            val minChargeBoxBatteryLevel = camera.getCameraConfig().getOrNull()?.firmwareUpgradeMinBatteryLevel() ?: 0
            if (chargeBoxBatteryData < minChargeBoxBatteryLevel) {
                return FirmwareUpgradeChargeBoxLowBatteryException(minChargeBoxBatteryLevel).failure()
            }
        }
        Logger.i(TAG, "upgrade firmware start, filePath=$filePath")
        val result = try {
            doUpload("${camera.getDownloadEndpoint()}$FIRMWARE_UPLOAD_PATH", filePath) {
                progress?.invoke(it)
            }
        } catch (e: CancellationException) {
            FirmwareUpgradeCancelException().failure()
        } catch (e: IOException) {
            Logger.w(TAG, "upgrade firmware io error: ${e.message}")
            FirmwareUpgradeIOException(e.message ?: "").failure()
        } catch (e: okio.IOException) {
            Logger.w(TAG, "upgrade firmware okio error: ${e.message}")
            FirmwareUpgradeIOException(e.message ?: "").failure()
        } catch (e: Exception) {
            FirmwareUpgradeUnknownException(e.message ?: "").failure()
        }
        result.fold(
            onSuccess = { Logger.i(TAG, "upgrade firmware success") },
            onFailure = { Logger.e(TAG, "upgrade firmware failed", it) }
        )

        return withContext(getDispatcherProvider().main) { result }
    }

    override fun upgradeFirmware(filePath: String, callback: ProgressCallback<Unit, Double>) {
        scope.launch {
            upgradeFirmware(filePath) {
                callback.onProgress(it)
            }.invokeCallback(callback)
        }
    }

    override suspend fun destroy() {

    }
}