package com.arashivision.sdk.camera.core.model.notify

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class TempState(override val nativeValue: Int) : BaseEnum {
    LOW(0),
    ALERT(1),
    MIDDLE(2),
    HIGH(3),
    HIGH_SHUTDOWN(4);

    companion object {
        fun nativeOf(value: Int?): TempState = entries.firstOrNull { it.nativeValue == value } ?: LOW
    }
}