# 相机属性模块 – 设计说明

## 1. 架构概览

```
+-----------------------------+
| CameraAttributeManager(API)|
|--------------------------|
| - lensType               |
| - captureMode            |
| - attrValues             |
|--------------------------|
| +setLensType(...)        |
| +setFunctionMode(...)    |
| +supportedAttributes()   |
| +attributeOptions(...)   |
| +setAttrValue(...)       |
| +getAttrValue*(...)      |
| +attributeType(...)      |
+------------+-------------+
             |
             | 依赖
+------------v-------------+      +-------------------------+
| CameraFunctionCatalog    |      | CameraProtoCatalog      |
|--------------------------|      |-------------------------|
| 解析镜头/模式/属性 JSON   |      | 解析 proto 查表         |
| 纯查询，不维护状态       |      | 提供 name/int 双向映射  |
| +lensTypes()             |      | +mapFor(attr)           |
| +functionModes(...)      |      | +intFor(attr,name)      |
| +supportedAttributes()   |      | +nameFor(attr,value)    |
| +dependOnAttributes()    |      | +CameraProtoMap         |
| +attrValues(...)         |      +-------------------------+
| +defaultAttrValues(...)  |
+--------------------------+
```

职责划分：

- **CameraAttributeManager（接口）**：对外暴露纯业务 API；实现类 `CameraAttributeManagerImpl` 维护当前镜头、模式与属性值。
- **CameraFunctionCatalog**：解析属性 JSON，并提供针对镜头/模式/属性的可选项查询。
- **CameraProtoCatalog**：解析 proto JSON，维护枚举、模式值等查表数据。

## 2. 运行流程

1. **初始化**
   ```kotlin
   val manager = CameraAttributeManager.fromJsonStrings(attrJson, protoJson)
   ```
   两份 JSON 字符串被解析成不可变 `JsonObject`。不访问文件与平台 API，直接在 `commonMain` 可运行。

2. **镜头 / 模式选择**
   - `setLensType(lens)` 校验镜头，并清空当前模式与属性缓存。
   - `setFunctionMode(mode)` 校验模式；整型重载通过 `capture_function_mode` proto 表反查模式名。

3. **属性生命周期**
   - `supportedAttributes()`：返回当前镜头 + 模式允许的所有属性。
   - `attributeOptions(attr)`：根据 `depend_on` 描述生成依赖 key（`valueA|valueB`），先查依赖项列表，再回落到 `"default"`。
   - `setAttrValue`/`setEnumValue`：写入各种类型的属性值。
   - `getAttrValueInt/Double/Fraction`、`getEnumValueInt`：读取强类型结果。

4. **Proto 功能**
   - `attributeType(attr)`、`allAttributeTypes()` 读取 `photography_options_type` 表。
   - `currentFunctionModeInt()` 返回当前拍摄模式对应的 proto 数值。

## 3. 状态机

```
[Init]
  |
  | setLensType()
  v
[LensSelected] --setFunctionMode()--> [ModeSelected]
      ^                                     |
      | (切换镜头会清空模式)                | setAttrValue / attributeOptions
      +-------------------------------------+
```

- 在进入 `ModeSelected` 前，任何属性 API 都会返回 `CameraAttrError.InvalidState`。
- `withLens`、`withLensAndMode` 帮助函数确保状态合法，避免遗忘校验。

## 4. Kotlin 化亮点

1. **密封错误 + 类型安全结果**
   - `CameraAttrResult<T>` 与 `CameraAttrError` 替代 C++ 的 `FError*`，支持 `when` 表达式，无需检查 null。

2. **不可变 JSON 目录**
   - C++ 版本依赖 `Json::Value` / `std::map` 可变结构；Kotlin 实现改用 `JsonObject` + 纯函数查询，天然线程安全，可并发读取。

3. **值对象与扩展函数**
   - `Fraction`、`CameraProtoMap` 与 `mapNumber`、`flatMap`、`toFractionOrNull` 等扩展函数，将格式化/解析逻辑封装，避免巨型函数。

4. **依赖解析简化**
   - 取消 `if (error != kFcpNoError)` 链式判断，统一用 `flatMap/map` 串联，业务流程清晰。

5. **可扩展性**
   - 管理器不做任何 I/O，上层可自由以文件、网络、或测试数据方式提供 JSON 字符串；实现类可以按需替换。

