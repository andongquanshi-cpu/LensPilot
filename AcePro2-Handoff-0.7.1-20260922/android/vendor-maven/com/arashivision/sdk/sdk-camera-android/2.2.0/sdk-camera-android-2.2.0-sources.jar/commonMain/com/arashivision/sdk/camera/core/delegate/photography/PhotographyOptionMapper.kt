package com.arashivision.sdk.camera.core.delegate.photography

import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.ExportType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.core.model.photography.FlowStateLevel
import com.arashivision.sdk.camera.core.model.photography.PanoExposureMode
import com.arashivision.sdk.camera.core.model.photography.PhotoHdrType
import com.arashivision.sdk.camera.core.model.photography.PhotoResolution
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.ResolutionRecordLimit
import com.arashivision.sdk.camera.core.model.photography.VideoGammaMode
import com.arashivision.sdk.camera.core.model.photography.VideoSelfieMode
import com.arashivision.sdk.camera.core.model.photography.WB
import insta360.messages.ButtonPressMode
import insta360.messages.CaptureBeautyParams
import insta360.messages.Flicker
import insta360.messages.FovType
import insta360.messages.GammaMode
import insta360.messages.LivePhotoSwitch
import insta360.messages.PhotoSize
import insta360.messages.PhotoSizeId
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.PhotographyOptions.AEMeterMode
import insta360.messages.PhotographyOptions.AudioEncoderType
import insta360.messages.PhotographyOptions.BoolTypeSecure
import insta360.messages.PhotographyOptions.COLOR_MODE
import insta360.messages.PhotographyOptions.ExposureManual
import insta360.messages.PhotographyOptions.ExposureMode
import insta360.messages.PhotographyOptions.ExposureOptions
import insta360.messages.PhotographyOptions.ExposureOptions.Program
import insta360.messages.PhotographyOptions.ExposureParameter
import insta360.messages.PhotographyOptions.ExposureProg
import insta360.messages.PhotographyOptions.FlowStateHorizonType
import insta360.messages.PhotographyOptions.Flow_State_Level
import insta360.messages.PhotographyOptions.Flow_State_Level_By_Cv5
import insta360.messages.PhotographyOptions.Iq3AMode
import insta360.messages.PhotographyOptions.LongExposureManual
import insta360.messages.PhotographyOptions.MACROLENS_SWITCH_TYPE
import insta360.messages.PhotographyOptions.P3_EXTERN_PARAM
import insta360.messages.PhotographyOptions.PHOTO_HDR_TYPE
import insta360.messages.PhotographyOptions.PREVIEW_SPORT_LEVEL
import insta360.messages.PhotographyOptions.Pano_Exposure_Mode
import insta360.messages.PhotographyOptions.PlantformType
import insta360.messages.PhotographyOptions.RENDER_CENTER_POINT
import insta360.messages.PhotographyOptions.RENDER_VLP_EULER
import insta360.messages.PhotographyOptions.RENDER_VLP_FOV
import insta360.messages.PhotographyOptions.RENDER_VLP_QUAT
import insta360.messages.PhotographyOptions.RENDER_VLP_RESOLUTION
import insta360.messages.PhotographyOptions.ResRecLimit
import insta360.messages.PhotographyOptions.StarLapse_Export_Type
import insta360.messages.PhotographyOptions.TimeRecInfo
import insta360.messages.PhotographyOptions.VIDEO_SELFIE_MODE
import insta360.messages.PhotographyOptions.VideoEncoderType
import insta360.messages.PhotographyOptions.WhiteBalance
import insta360.messages.PresetIconType
import insta360.messages.Ptz_Movement_Status
import insta360.messages.RawCaptureType
import insta360.messages.VideoResolution
import com.arashivision.sdk.camera.core.model.photography.FovType as SdkFovType
import com.arashivision.sdk.camera.core.model.photography.Iq3AMode as SdkIq3AMode
import com.arashivision.sdk.camera.core.model.photography.PhotoSize as SdkPhotoSize
import com.arashivision.sdk.camera.core.model.photography.RawType as SdkRawType

object PhotographyOptionMapper {

    fun photographyOptions2Map(photographyOptionList: List<PhotographyOptionType>, photographyOptions: PhotographyOptions): Map<PhotographyOptionType, Any?> {
        val associateWith = photographyOptionList.associateWith {
            when (it) {
                PhotographyOptionType.PHOTOGRAPHY_OPTION_UNKNOWN -> null
                PhotographyOptionType.CHANNEL -> photographyOptions.channel
                PhotographyOptionType.BRIGHTNESS -> photographyOptions.brightness
                PhotographyOptionType.CONTRAST -> photographyOptions.contrast
                PhotographyOptionType.SATURATION -> photographyOptions.saturation
                PhotographyOptionType.HUE -> photographyOptions.hue
                PhotographyOptionType.SHARPNESS -> photographyOptions.sharpness
                PhotographyOptionType.EXPOSURE_BIAS -> photographyOptions.exposure_bias
                PhotographyOptionType.EXPOSURE_MODE -> photographyOptions.exposure_mode
                PhotographyOptionType.EXPOSURE_PROG -> photographyOptions.exposure_prog
                PhotographyOptionType.EXPOSURE_MANUAL -> photographyOptions.exposure_manual
                PhotographyOptionType.AE_METER_MODE -> photographyOptions.meter_mode
                PhotographyOptionType.AE_MANUAL_METER_WEIGHT -> photographyOptions.manual_meter_weights
                PhotographyOptionType.WHITE_BALANCE -> photographyOptions.white_balance
                PhotographyOptionType.FLICKER -> photographyOptions.flicker
                PhotographyOptionType.EV_INDEX -> photographyOptions.ev_index
                PhotographyOptionType.AUTO_MODE_VIDEO_PARAM -> photographyOptions.auto_mode_video_param
                PhotographyOptionType.AUTO_MODE_STILL_PARAM -> photographyOptions.auto_mode_still_param
                PhotographyOptionType.VIDEO_GAMMA_MODE -> photographyOptions.gamma_mode
                PhotographyOptionType.LONG_EXPOSURE_MANUAL -> photographyOptions.long_exposure_manual
                PhotographyOptionType.STILL_EXPOSURE_OPTIONS -> photographyOptions.still_exposure
                PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS -> photographyOptions.video_exposure
                PhotographyOptionType.PREVIEW_MCTF_ENABLE -> photographyOptions.preview_mctf_enable
                PhotographyOptionType.PREVIEW_SPORT_MODE_ENABLE -> photographyOptions.preview_sport_mode_enable
                PhotographyOptionType.VIDEO_ISO_TOP_LIMIT -> photographyOptions.video_iso_top_limit
                PhotographyOptionType.RAW_CAPTURE_TYPE -> photographyOptions.raw_capture_type
                PhotographyOptionType.PHOTOGRAPHY_SELF_TIMER -> photographyOptions.photography_self_timer
                PhotographyOptionType.AEB_CAPTURE_NUM -> photographyOptions.aeb_capture_num
                PhotographyOptionType.PREVIEW_SPORT_LEVEL -> photographyOptions.preview_sport_level
                PhotographyOptionType.RECORD_DURAION -> photographyOptions.record_duration
                PhotographyOptionType.PHOTO_SIZE_ID -> photographyOptions.photo_size_id
                PhotographyOptionType.RECORD_RESOLUTION -> photographyOptions.record_resolution
                PhotographyOptionType.PHOTO_GRAPHY_BITRATE -> photographyOptions.video_bitrate
                PhotographyOptionType.FOV_TYPE -> photographyOptions.fov_type
                PhotographyOptionType.FLOWSTATE_BASE_TYPE -> photographyOptions.flowstate_base_enable
                PhotographyOptionType.COLOR_MODE -> photographyOptions.color_mode
                PhotographyOptionType.RES_REC_LIMIT -> photographyOptions.res_rec_limit
                PhotographyOptionType.ACCELERATE_FREQUENCY -> photographyOptions.accelerate_frequency
                PhotographyOptionType.FOCAL_LENGTH_VALUE -> photographyOptions.focal_length_value
                PhotographyOptionType.WHITE_BALANCE_VALUE -> photographyOptions.white_balance_value
                PhotographyOptionType.PHOTO_RESOLUTION -> photographyOptions.photo_resolution
                PhotographyOptionType.REMAINING_TIME -> photographyOptions.remaining_time
                PhotographyOptionType.DARK_EIS_ENABLE -> photographyOptions.dark_eis_enable
                PhotographyOptionType.BURST_CAPTURE_NUM -> photographyOptions.burst_capture_num
                PhotographyOptionType.CACHE_CAPTURE_NUM -> photographyOptions.cache_capture_num
                PhotographyOptionType.METERING_ENABLE -> photographyOptions.metering_enable
                PhotographyOptionType.TIME_INFO -> photographyOptions.time_rec_info
                PhotographyOptionType.PRESET_MODE -> photographyOptions.preset_mode
                PhotographyOptionType.PRESET_SUB_MODE -> photographyOptions.preset_sub_mode
                PhotographyOptionType.PRESET_NAME -> photographyOptions.preset_name
                PhotographyOptionType.BURST_CAPTURE_TIME -> photographyOptions.burst_capture_time
                PhotographyOptionType.CACHE_CAPTURE_ENABLE -> photographyOptions.cache_capture_enable
                PhotographyOptionType.ZOOM_SCALE -> photographyOptions.zoom_scale
                PhotographyOptionType.MAX_REC_TIME -> photographyOptions.max_rec_time
                PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5 -> photographyOptions.flow_state_level_by_cv5
                PhotographyOptionType.STARLAPSE_EXPORT_TYPE -> photographyOptions.starlapse_export_type
                PhotographyOptionType.TIMESHIFT_NORMAL_SPEED -> photographyOptions.timeshift_normal_speed
                PhotographyOptionType.VIDEO_FLOWSTATE_BASE_TYPE -> photographyOptions.video_flowstate_base_enable
                PhotographyOptionType.DOUBLE_ZOOM -> photographyOptions.double_zoom_enable
                PhotographyOptionType.STROBE_RECOMMEND_FPS -> photographyOptions.strobe_recommend_fps
                PhotographyOptionType.PANO_EXPOSURE_MODE -> photographyOptions.pano_exposure_mode
                PhotographyOptionType.VIDEO_SELFIE_MODE -> photographyOptions.selfie_mode
                PhotographyOptionType.HDR_SWITCH_STATUS -> photographyOptions.hdr_switch_status
                PhotographyOptionType.LIVE_RTMP_ENABLE_AUTO_BITRATE -> photographyOptions.live_rtmp_auto_bitrate
                PhotographyOptionType.LIVE_RTMP_PREFER_VIDEO_BITRATE -> photographyOptions.live_prefer_video_bitrate
                PhotographyOptionType.LIVE_RTMP_PREFER_AUDIO_BITRATE -> photographyOptions.live_prefer_audio_bitrate
                PhotographyOptionType.LIVE_RTMP_VIDEO_ENCODER -> photographyOptions.live_video_encoder
                PhotographyOptionType.LIVE_RTMP_AUDIO_ENCODER -> photographyOptions.live_audio_encoder
                PhotographyOptionType.LIVE_RTMP_PLANTFORM -> photographyOptions.live_plantform
                PhotographyOptionType.FLOWSTATE_HORIZON_ENABLE -> photographyOptions.flowstate_horizon_enable
                PhotographyOptionType.PURE_VIDEO_ENHANC_TYPE -> photographyOptions.purevideo_enhanc_switch
                PhotographyOptionType.I_LOG_SWITCH -> photographyOptions.i_log_switch
                PhotographyOptionType.COLOR_RECOVERY_SWITCH -> photographyOptions.color_recovery_switch
                PhotographyOptionType.RENDER_VLP_EULER -> photographyOptions.render_vlp_euler
                PhotographyOptionType.RENDER_VLP_RES -> photographyOptions.render_vlp_res
                PhotographyOptionType.RENDER_VLP_FOV -> photographyOptions.render_vlp_fov
                PhotographyOptionType.PHOTO_HDR_TYPE -> photographyOptions.hdr_mode
                PhotographyOptionType.RENDER_DISTORTION_CORRECTION -> photographyOptions.render_distortion_correction
                PhotographyOptionType.VIRTUAL_PTZ_MOVEMENT_STATUS -> photographyOptions.ptz_movement_status
                PhotographyOptionType.RENDER_CENTER_POINT -> photographyOptions.center_point
                PhotographyOptionType.PTZ_FOV_FACTOR -> photographyOptions.ptz_fov_factor
                PhotographyOptionType.TRACKING_RESET -> photographyOptions.track_reset
                PhotographyOptionType.FACE_OPTIMIZE_MODE -> photographyOptions.FACE_OPTIMIZE_MODE
                PhotographyOptionType.RENDER_VLP_QUAT -> photographyOptions.render_vlp_quat
                PhotographyOptionType.LIVEPHOTO_MODE -> photographyOptions.livephoto_switch_info
                PhotographyOptionType.P3_SWITCH -> photographyOptions.p3_switch
                PhotographyOptionType.P3_EXTEND_PARAM -> photographyOptions.p3_extern_param
                PhotographyOptionType.MACROLENS_SWITCH -> photographyOptions.macrolens_switch_mode
                PhotographyOptionType.BEAUTY_SWITCH -> photographyOptions.beauty_switch
                PhotographyOptionType.CAPTURE_BEAUTY_PARAM -> photographyOptions.beauty_info
                PhotographyOptionType.FLOWSTATE_LEVEL -> photographyOptions.flow_state_level
                // 当前 SDK 没有在上层使用/映射这两个类型；保持兼容，返回 null（后续会被 filter 掉）
                PhotographyOptionType.GIMBAL_OPTIONS -> null
                PhotographyOptionType.GIMBAL_STATUS -> null
                PhotographyOptionType.PHOTO_GRAPHY_OPTIONS_TYPE_NUM -> null
                PhotographyOptionType.AF_MODE_TYPE -> null
                PhotographyOptionType.AF_TRIGGER_PARAMS -> null
                PhotographyOptionType.AF_LEN_FOCUS_DISTANCE -> null
                PhotographyOptionType.SELFIE_MIRROR_SWITCH -> null
                PhotographyOptionType.AUTO_TRACKING_SWITCH -> null
                PhotographyOptionType.GIMBAL_PANO_TYPE -> null

                // C6新增
                PhotographyOptionType.REMAINING_TIME_LIST -> null
                PhotographyOptionType.IQ_3A_MODE -> photographyOptions.iq_3a_mode
                PhotographyOptionType.FOVC_SWITCH -> null
                PhotographyOptionType.BLUE_LEVEL -> null
                PhotographyOptionType.NOISE_LEVEL -> null
                PhotographyOptionType.AF_SCENE_CHANGE -> null
                PhotographyOptionType.IS_INITIAL_PERSPECTIVE -> null
                PhotographyOptionType.TOUCH_AF_SUBSCRIBE -> null
                PhotographyOptionType.REBUILD_BEFORE_REC -> null
                PhotographyOptionType.ACTIONVIEW_SWITCH -> null

                // c9_beat2.1新增
                PhotographyOptionType.GAMMA_MODE_LEVEL -> null
                PhotographyOptionType.VERSION_NUMBER -> null
                PhotographyOptionType.BORDER_STYLE -> null

                else -> null
            }
        }
        return associateWith.filter { it.value != null }.mapValues { (_, value) -> value!! }
    }

    fun map2PhotographyOptions(photographyOptionMap: Map<PhotographyOptionType, Any>): PhotographyOptions {
        return PhotographyOptions().apply {
            photographyOptionMap.entries.forEach { (key, value) ->
                when (key) {
                    PhotographyOptionType.PHOTOGRAPHY_OPTION_UNKNOWN -> {}
                    PhotographyOptionType.CHANNEL -> channel = (value as? Int) ?: 0
                    PhotographyOptionType.BRIGHTNESS -> brightness = (value as? Int) ?: 0
                    PhotographyOptionType.CONTRAST -> contrast = (value as? Int) ?: 0
                    PhotographyOptionType.SATURATION -> saturation = (value as? Int) ?: 0
                    PhotographyOptionType.HUE -> hue = (value as? Int) ?: 0
                    PhotographyOptionType.SHARPNESS -> sharpness = (value as? Int) ?: 0
                    PhotographyOptionType.EXPOSURE_BIAS -> exposure_bias = (value as? Int) ?: 0
                    PhotographyOptionType.EXPOSURE_MODE -> exposure_mode = (value as? ExposureMode) ?: ExposureMode.EXP_MODE_AUTO
                    PhotographyOptionType.EXPOSURE_PROG -> exposure_prog = value as? ExposureProg
                    PhotographyOptionType.EXPOSURE_MANUAL -> exposure_manual = value as? ExposureManual
                    PhotographyOptionType.AE_METER_MODE -> meter_mode = (value as? AEMeterMode) ?: AEMeterMode.AE_METER_MODE_NORMAL
                    PhotographyOptionType.AE_MANUAL_METER_WEIGHT -> manual_meter_weights = (value as? List<Int>) ?: emptyList()
                    PhotographyOptionType.WHITE_BALANCE -> white_balance = (value as? WhiteBalance) ?: WhiteBalance.WB_AUTO
                    PhotographyOptionType.FLICKER -> flicker = (value as? Flicker) ?: Flicker.FLICKER_AUTO
                    PhotographyOptionType.EV_INDEX -> ev_index = (value as? Int) ?: 0
                    PhotographyOptionType.AUTO_MODE_VIDEO_PARAM -> auto_mode_video_param = value as? ExposureParameter
                    PhotographyOptionType.AUTO_MODE_STILL_PARAM -> auto_mode_still_param = value as? ExposureParameter
                    PhotographyOptionType.VIDEO_GAMMA_MODE -> gamma_mode = (value as? GammaMode) ?: GammaMode.STANDARD
                    PhotographyOptionType.LONG_EXPOSURE_MANUAL -> long_exposure_manual = value as? LongExposureManual
                    PhotographyOptionType.STILL_EXPOSURE_OPTIONS -> still_exposure = value as? ExposureOptions
                    PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS -> video_exposure = value as? ExposureOptions
                    PhotographyOptionType.PREVIEW_MCTF_ENABLE -> preview_mctf_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.PREVIEW_SPORT_MODE_ENABLE -> preview_sport_mode_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.VIDEO_ISO_TOP_LIMIT -> video_iso_top_limit = (value as? Int) ?: 0
                    PhotographyOptionType.RAW_CAPTURE_TYPE -> raw_capture_type = (value as? RawCaptureType) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
                    PhotographyOptionType.PHOTOGRAPHY_SELF_TIMER -> photography_self_timer = (value as? Int) ?: 0
                    PhotographyOptionType.AEB_CAPTURE_NUM -> aeb_capture_num = (value as? Int) ?: 0
                    PhotographyOptionType.PREVIEW_SPORT_LEVEL -> preview_sport_level = (value as? PREVIEW_SPORT_LEVEL) ?: PREVIEW_SPORT_LEVEL.PREVIEW_SPORT_AUTO
                    PhotographyOptionType.RECORD_DURAION -> record_duration = (value as? Int) ?: 0
                    PhotographyOptionType.PHOTO_SIZE_ID -> photo_size_id = (value as? PhotoSizeId) ?: PhotoSizeId.PHOTO_SIZE_16_9
                    PhotographyOptionType.RECORD_RESOLUTION -> record_resolution = (value as? VideoResolution) ?: VideoResolution.RES_3840_1920P30
                    PhotographyOptionType.PHOTO_GRAPHY_BITRATE -> video_bitrate = (value as? Int) ?: 0
                    PhotographyOptionType.FOV_TYPE -> fov_type = (value as? FovType) ?: FovType.FOV_WIDE
                    PhotographyOptionType.FLOWSTATE_BASE_TYPE -> flowstate_base_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.COLOR_MODE -> color_mode = (value as? COLOR_MODE) ?: COLOR_MODE.COLOR_MODE_NORMAL
                    PhotographyOptionType.RES_REC_LIMIT -> res_rec_limit = (value as? List<ResRecLimit>) ?: emptyList()
                    PhotographyOptionType.ACCELERATE_FREQUENCY -> accelerate_frequency = (value as? Int) ?: 0
                    PhotographyOptionType.FOCAL_LENGTH_VALUE -> focal_length_value = (value as? Double) ?: 0.0
                    PhotographyOptionType.WHITE_BALANCE_VALUE -> white_balance_value = (value as? Int) ?: 0
                    PhotographyOptionType.PHOTO_RESOLUTION -> photo_resolution = (value as? PhotoSize) ?: PhotoSize.Size_6912_3456
                    PhotographyOptionType.REMAINING_TIME -> remaining_time = (value as? Int) ?: 0
                    PhotographyOptionType.DARK_EIS_ENABLE -> dark_eis_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.FLOWSTATE_LEVEL -> flow_state_level = (value as? Flow_State_Level) ?: Flow_State_Level.Flow_State_Level_Close
                    PhotographyOptionType.BURST_CAPTURE_NUM -> burst_capture_num = (value as? Int) ?: 0
                    PhotographyOptionType.CACHE_CAPTURE_NUM -> cache_capture_num = (value as? Int) ?: 0
                    PhotographyOptionType.METERING_ENABLE -> metering_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.TIME_INFO -> time_rec_info = value as? TimeRecInfo
                    PhotographyOptionType.PRESET_MODE -> preset_mode = (value as? ButtonPressMode) ?: ButtonPressMode.DO_NOT_CHANGE
                    PhotographyOptionType.PRESET_SUB_MODE -> preset_sub_mode = (value as? PresetIconType) ?: PresetIconType.PRESETICON_UNKNOW
                    PhotographyOptionType.PRESET_NAME -> preset_name = (value as? String) ?: ""
                    PhotographyOptionType.BURST_CAPTURE_TIME -> burst_capture_time = (value as? Int) ?: 0
                    PhotographyOptionType.CACHE_CAPTURE_ENABLE -> cache_capture_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.ZOOM_SCALE -> zoom_scale = (value as? Double) ?: 0.0
                    PhotographyOptionType.MAX_REC_TIME -> max_rec_time = (value as? Int) ?: 0
                    PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5 -> flow_state_level_by_cv5 =
                        (value as? Flow_State_Level_By_Cv5) ?: Flow_State_Level_By_Cv5.Flow_State_Level_CV5_Close

                    PhotographyOptionType.STARLAPSE_EXPORT_TYPE -> starlapse_export_type = (value as? StarLapse_Export_Type) ?: StarLapse_Export_Type.StarLapse_Video
                    PhotographyOptionType.TIMESHIFT_NORMAL_SPEED -> timeshift_normal_speed = (value as? Boolean) ?: false
                    PhotographyOptionType.VIDEO_FLOWSTATE_BASE_TYPE -> video_flowstate_base_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.DOUBLE_ZOOM -> double_zoom_enable = (value as? Boolean) ?: false
                    PhotographyOptionType.STROBE_RECOMMEND_FPS -> strobe_recommend_fps = (value as? Int) ?: 0
                    PhotographyOptionType.PANO_EXPOSURE_MODE -> pano_exposure_mode = (value as? Pano_Exposure_Mode) ?: Pano_Exposure_Mode.Pano_Exposure_Mode_Off
                    PhotographyOptionType.VIDEO_SELFIE_MODE -> selfie_mode = (value as? VIDEO_SELFIE_MODE) ?: VIDEO_SELFIE_MODE.MODE_NONE
                    PhotographyOptionType.HDR_SWITCH_STATUS -> hdr_switch_status = (value as? Boolean) ?: false
                    PhotographyOptionType.LIVE_RTMP_ENABLE_AUTO_BITRATE -> live_rtmp_auto_bitrate = (value as? BoolTypeSecure) ?: BoolTypeSecure.BOOL_UNKNOWN
                    PhotographyOptionType.LIVE_RTMP_PREFER_VIDEO_BITRATE -> live_prefer_video_bitrate = (value as? Int) ?: 0
                    PhotographyOptionType.LIVE_RTMP_PREFER_AUDIO_BITRATE -> live_prefer_audio_bitrate = (value as? Int) ?: 0
                    PhotographyOptionType.LIVE_RTMP_VIDEO_ENCODER -> live_video_encoder = (value as? VideoEncoderType) ?: VideoEncoderType.VIDEO_DEFAULT
                    PhotographyOptionType.LIVE_RTMP_AUDIO_ENCODER -> live_audio_encoder = (value as? AudioEncoderType) ?: AudioEncoderType.AUDIO_DEFAULT
                    PhotographyOptionType.LIVE_RTMP_PLANTFORM -> live_plantform = (value as? PlantformType) ?: PlantformType.PLANTFORM_DEFAULT
                    PhotographyOptionType.FLOWSTATE_HORIZON_ENABLE -> flowstate_horizon_enable = (value as? FlowStateHorizonType) ?: FlowStateHorizonType.FLOW_STATE_HORIZON_DISABLE
                    PhotographyOptionType.PURE_VIDEO_ENHANC_TYPE -> purevideo_enhanc_switch = (value as? Boolean) ?: false
                    PhotographyOptionType.I_LOG_SWITCH -> i_log_switch = (value as? Boolean) ?: false
                    PhotographyOptionType.COLOR_RECOVERY_SWITCH -> color_recovery_switch = (value as? Boolean) ?: false
                    PhotographyOptionType.RENDER_VLP_EULER -> render_vlp_euler = value as? RENDER_VLP_EULER
                    PhotographyOptionType.RENDER_VLP_RES -> render_vlp_res = value as? RENDER_VLP_RESOLUTION
                    PhotographyOptionType.RENDER_VLP_FOV -> render_vlp_fov = value as? RENDER_VLP_FOV
                    PhotographyOptionType.PHOTO_HDR_TYPE -> hdr_mode = (value as? PHOTO_HDR_TYPE) ?: PHOTO_HDR_TYPE.HDR_OFF
                    PhotographyOptionType.RENDER_DISTORTION_CORRECTION -> render_distortion_correction = (value as? Int) ?: 0
                    PhotographyOptionType.VIRTUAL_PTZ_MOVEMENT_STATUS -> ptz_movement_status = value as? Ptz_Movement_Status
                    PhotographyOptionType.RENDER_CENTER_POINT -> center_point = value as? RENDER_CENTER_POINT
                    PhotographyOptionType.PTZ_FOV_FACTOR -> ptz_fov_factor = (value as? Int) ?: 0
                    PhotographyOptionType.TRACKING_RESET -> track_reset = (value as? Boolean) ?: false
                    PhotographyOptionType.FACE_OPTIMIZE_MODE -> FACE_OPTIMIZE_MODE = (value as? Boolean) ?: false
                    PhotographyOptionType.RENDER_VLP_QUAT -> render_vlp_quat = value as? RENDER_VLP_QUAT
                    PhotographyOptionType.LIVEPHOTO_MODE -> livephoto_switch_info = value as? LivePhotoSwitch
                    PhotographyOptionType.P3_SWITCH -> p3_switch = (value as? Int) ?: 0
                    PhotographyOptionType.P3_EXTEND_PARAM -> p3_extern_param = value as? P3_EXTERN_PARAM
                    PhotographyOptionType.MACROLENS_SWITCH -> macrolens_switch_mode = (value as? MACROLENS_SWITCH_TYPE) ?: MACROLENS_SWITCH_TYPE.MACROLENS_SWITCH_NONE
                    PhotographyOptionType.BEAUTY_SWITCH -> beauty_switch = (value as? Boolean) ?: false
                    PhotographyOptionType.CAPTURE_BEAUTY_PARAM -> beauty_info = value as? CaptureBeautyParams
                    // 当前 SDK 未对这两个字段做写入映射，忽略即可
                    PhotographyOptionType.GIMBAL_OPTIONS -> {}
                    PhotographyOptionType.GIMBAL_STATUS -> {}
                    PhotographyOptionType.PHOTO_GRAPHY_OPTIONS_TYPE_NUM -> {}
                    PhotographyOptionType.AF_MODE_TYPE -> {}
                    PhotographyOptionType.AF_TRIGGER_PARAMS -> {}
                    PhotographyOptionType.AF_LEN_FOCUS_DISTANCE -> {}
                    PhotographyOptionType.SELFIE_MIRROR_SWITCH -> {}
                    PhotographyOptionType.AUTO_TRACKING_SWITCH -> {}
                    PhotographyOptionType.GIMBAL_PANO_TYPE -> {}

                    // C9新增
                    PhotographyOptionType.REMAINING_TIME_LIST -> {}
                    PhotographyOptionType.IQ_3A_MODE -> iq_3a_mode = (value as? Iq3AMode) ?: Iq3AMode.IQ_3A_INVALID
                    PhotographyOptionType.FOVC_SWITCH -> {}
                    PhotographyOptionType.BLUE_LEVEL -> {}
                    PhotographyOptionType.NOISE_LEVEL -> {}
                    PhotographyOptionType.AF_SCENE_CHANGE -> {}
                    PhotographyOptionType.IS_INITIAL_PERSPECTIVE -> {}
                    PhotographyOptionType.TOUCH_AF_SUBSCRIBE -> {}
                    PhotographyOptionType.REBUILD_BEFORE_REC -> {}
                    PhotographyOptionType.ACTIONVIEW_SWITCH -> {}

                    // c9_beat2.1新增
                    PhotographyOptionType.GAMMA_MODE_LEVEL -> {}
                    PhotographyOptionType.VERSION_NUMBER -> {}
                    PhotographyOptionType.BORDER_STYLE -> {}

                    else -> {}
                }
            }
        }
    }

    // get transform
    fun photographyOptionTransform(functionMode: FunctionMode, photographyOptionType: PhotographyOptionType, photographyOptionMap: Map<PhotographyOptionType, Any?>): Any? {
        val photographyOption: Any = photographyOptionMap[photographyOptionType] ?: return null
        return when (photographyOptionType) {
            PhotographyOptionType.VIDEO_GAMMA_MODE -> VideoGammaMode.nativeOf((photographyOption as? GammaMode)?.value)

            PhotographyOptionType.STARLAPSE_EXPORT_TYPE -> ExportType.nativeOf((photographyOption as? StarLapse_Export_Type)?.value)
            PhotographyOptionType.STILL_EXPOSURE_OPTIONS,
            PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS -> {
                val exposure = photographyOption as ExposureOptions
                Exposure.fromShutterSpeed(Exposure.ExposureProgram.nativeOf(exposure.program.value), exposure.iso, exposure.shutter_speed)
            }

            PhotographyOptionType.PANO_EXPOSURE_MODE -> PanoExposureMode.nativeOf((photographyOption as? Pano_Exposure_Mode)?.value)
            PhotographyOptionType.FOV_TYPE -> SdkFovType.nativeOf((photographyOption as? FovType)?.value)
            PhotographyOptionType.FLOWSTATE_LEVEL -> FlowStateLevel.nativeOf((photographyOption as? Flow_State_Level)?.value)
            PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5 -> FlowStateLevel.nativeOf((photographyOption as? Flow_State_Level_By_Cv5)?.value)
            PhotographyOptionType.PHOTO_HDR_TYPE -> PhotoHdrType.nativeOf((photographyOption as? PHOTO_HDR_TYPE)?.value)
            PhotographyOptionType.IQ_3A_MODE -> SdkIq3AMode.nativeOf((photographyOption as? Iq3AMode)?.value)
            PhotographyOptionType.PHOTO_RESOLUTION -> PhotoResolution.nativeOf((photographyOption as? PhotoSize)?.value)
            PhotographyOptionType.PHOTO_SIZE_ID -> SdkPhotoSize.nativeOf((photographyOption as? PhotoSizeId)?.value)
            PhotographyOptionType.RAW_CAPTURE_TYPE -> SdkRawType.nativeOf((photographyOption as? RawCaptureType)?.value)
            PhotographyOptionType.RECORD_RESOLUTION -> RecordResolution.nativeOf((photographyOption as? VideoResolution)?.value) {
                if (functionMode == FunctionMode.VIDEO_SUPER) it.width * 2 != it.height && it.width != it.height * 2 else it.width != it.height
            }

            PhotographyOptionType.VIDEO_SELFIE_MODE -> VideoSelfieMode.nativeOf((photographyOption as? VIDEO_SELFIE_MODE)?.value)
            PhotographyOptionType.P3_SWITCH -> (photographyOption as? Int) == 1
            PhotographyOptionType.LIVEPHOTO_MODE -> {
                val livePhoto = photographyOption as? LivePhotoSwitch
                livePhoto?.livephoto_type == LivePhotoSwitch.LivePhotoMode.LIVEPHOTO_ON
            }

            PhotographyOptionType.WHITE_BALANCE -> WB.nativeOf((photographyOption as? WhiteBalance)?.value)
            PhotographyOptionType.WHITE_BALANCE_VALUE -> WB.valueOf(photographyOption as? Int)
            PhotographyOptionType.RES_REC_LIMIT -> {
                val limits = photographyOption as? List<ResRecLimit>
                limits?.map {
                    ResolutionRecordLimit(RecordResolution.nativeOf(it.video_res.value), it.limit_time)
                } ?: emptyList<ResRecLimit>()
            }

            else -> photographyOption
        }
    }

    // set transform
    fun mapTransform(
        photographyOptions: Map<PhotographyOptionType, Any>
    ): Map<PhotographyOptionType, Any> {

        val result = mutableMapOf<PhotographyOptionType, Any>()

        photographyOptions.forEach { (photographyOptionType, data) ->
            val transformedValue: Any? = when (photographyOptionType) {
                PhotographyOptionType.VIDEO_GAMMA_MODE ->
                    (data as? VideoGammaMode)
                        ?.nativeValue
                        ?.let { GammaMode.fromValue(it) }

                PhotographyOptionType.STARLAPSE_EXPORT_TYPE ->
                    (data as? ExportType)
                        ?.nativeValue
                        ?.let { StarLapse_Export_Type.fromValue(it) }

                PhotographyOptionType.STILL_EXPOSURE_OPTIONS,
                PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS -> {
                    val exposure = data as? Exposure
                    exposure?.let {
                        ExposureOptions().apply {
                            program = Program.fromValue(it.program.nativeValue) ?: Program.AUTO
                            iso = it.iso
                            shutter_speed = it.shutterSpeedDoubleValue()
                        }
                    }
                }

                PhotographyOptionType.PANO_EXPOSURE_MODE ->
                    (data as? PanoExposureMode)
                        ?.nativeValue
                        ?.let { Pano_Exposure_Mode.fromValue(it) }

                PhotographyOptionType.FOV_TYPE ->
                    (data as? SdkFovType)
                        ?.nativeValue
                        ?.let { FovType.fromValue(it) }

                PhotographyOptionType.FLOWSTATE_LEVEL -> Flow_State_Level.fromValue((data as? FlowStateLevel)?.nativeValue ?: 0) ?: Flow_State_Level.Flow_State_Level_Close
                PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5 ->
                    (data as? FlowStateLevel)
                        ?.nativeValue
                        ?.let { Flow_State_Level_By_Cv5.fromValue(it) }

                PhotographyOptionType.PHOTO_HDR_TYPE ->
                    (data as? PhotoHdrType)
                        ?.nativeValue
                        ?.let { PHOTO_HDR_TYPE.fromValue(it) }

                PhotographyOptionType.IQ_3A_MODE ->
                    (data as? SdkIq3AMode)
                        ?.nativeValue
                        ?.let { Iq3AMode.fromValue(it) }

                PhotographyOptionType.PHOTO_RESOLUTION ->
                    (data as? PhotoResolution)
                        ?.nativeValue
                        ?.let { PhotoSize.fromValue(it) }

                PhotographyOptionType.PHOTO_SIZE_ID ->
                    (data as? SdkPhotoSize)
                        ?.nativeValue
                        ?.let { PhotoSizeId.fromValue(it) }

                PhotographyOptionType.RAW_CAPTURE_TYPE -> (data as? SdkRawType)?.nativeValue?.let { RawCaptureType.fromValue(it) }
                PhotographyOptionType.RECORD_RESOLUTION -> (data as? RecordResolution)?.nativeValue?.let { VideoResolution.fromValue(it) }
                PhotographyOptionType.VIDEO_SELFIE_MODE -> (data as? VideoSelfieMode)?.nativeValue?.let { VIDEO_SELFIE_MODE.fromValue(it) }
                PhotographyOptionType.P3_SWITCH -> if ((data as? Boolean) == true) 1 else 0
                PhotographyOptionType.LIVEPHOTO_MODE -> {
                    LivePhotoSwitch(
                        livephoto_type = if ((data as? Boolean) == true) {
                            LivePhotoSwitch.LivePhotoMode.LIVEPHOTO_ON
                        } else {
                            LivePhotoSwitch.LivePhotoMode.LIVEPHOTO_OFF
                        }
                    )
                }

                PhotographyOptionType.WHITE_BALANCE -> (data as? WB)?.nativeValue?.let { WhiteBalance.fromValue(it) }
                PhotographyOptionType.WHITE_BALANCE_VALUE -> (data as? WB)?.value

                PhotographyOptionType.RES_REC_LIMIT -> {
                    val limits = data as? List<ResolutionRecordLimit>
                    limits?.map {
                        ResRecLimit().apply {
                            video_res = VideoResolution.fromValue(it.recordResolution.nativeValue) ?: VideoResolution.RES_3840_1920P30
                            limit_time = it.limit
                        }
                    } ?: emptyList<ResRecLimit>()
                }

                else -> data
            }

            // 只有成功转换才放进 map
            if (transformedValue != null) {
                result[photographyOptionType] = transformedValue
            }
        }

        return result
    }
}