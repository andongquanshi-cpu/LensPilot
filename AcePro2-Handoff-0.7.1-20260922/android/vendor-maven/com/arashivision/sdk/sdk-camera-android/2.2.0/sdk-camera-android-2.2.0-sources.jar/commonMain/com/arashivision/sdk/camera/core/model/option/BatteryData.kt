package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

data class BatteryData(val isCharging: Boolean, val level: Int, val scale: Int, val type: Type, val temp: Int) {
    enum class Type(override val nativeValue: Int) : BaseEnum {

        THICK(0), THIN(1), VERTICAL(2),

        /**
         * 未插电池只有USB供电的情况
         */
        NONE(100);

        companion object {
            fun nativeOf(nativeValue: Int?): Type {
                return Type.entries.firstOrNull { it.nativeValue == nativeValue } ?: THICK
            }
        }
    }
}


