package com.arashivision.sdk.camera.core.model.timelapse

data class TimelapseParams(val durationS: Int, val intervalMs: Int, val accelerateFrequency: Int)