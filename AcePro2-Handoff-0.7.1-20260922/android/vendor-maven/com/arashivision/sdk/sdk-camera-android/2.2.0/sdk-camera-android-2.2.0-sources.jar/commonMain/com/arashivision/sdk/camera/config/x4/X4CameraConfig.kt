package com.arashivision.sdk.camera.config.x4

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.common.util.greaterOrEquals
import insta360.messages.MultiPhotographyOptionsType

class X4CameraConfig(override val connectType: ConnectType) : ICameraConfig {

    override fun supportShutdown(): Boolean = false

    override fun supportMultiVideoOptionsList(): List<MultiPhotographyOptionsType> = emptyList()

    override fun captureMinBatteryLevel(): Int = 5

    override fun supportResetCameraWifi(fwVersion: String): Boolean = fwVersion.greaterOrEquals("0.2.4")

    override fun supportFetchCameraSensorMode(): Boolean = true

    override fun syncOptionMaxStep(): Int {
        return if (connectType == ConnectType.BLE) 16 else 60
    }

    override fun hasChargingBox(): Boolean = false


    override fun supportDownloadJsonParams(): Boolean = true

    override fun getLensName(sensorMode: SensorMode): String = if (sensorMode == SensorMode.ALL) "Sphere586" else "Fisheyes586"

    override fun firmwareUpgradeMinBatteryLevel(): Int = 22

    override fun firmwareUpgradeMinChargingBoxBatteryLevel(): Int = 0

    override fun supportNewRecordInterface(): Boolean = true

    override fun needNotifyWhenCameraRecordOverTimeLimit(): Boolean = true

    override fun isMergedIntoRS(version: String): Boolean = false

    override fun supportBleBroadcastWakeUp(): Boolean = true

    override fun supportNewCaptureControlFlow(): Boolean = true

    override fun muteNegate(): Boolean = true
}