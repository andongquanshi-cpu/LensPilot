package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class X4PanoramaSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.NONE
    override val previewStabType: PreviewStabType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewStabType.STAB_FULL_DIRECTIONAL else PreviewStabType.STAB_STILL
    override val previewFileType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewFileType.SPECIAL_SELFIE else PreviewFileType.VR360
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val previewGyroType = PreviewGyroType.X3_FISHEYE
    override val isDynamicAlphaSupported: Boolean = true
    override val isBlendUsingFisheyeMaskSupported: Boolean = true
    override val isSupportUpFlowV2: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1152_1152_30FPS,
            secondStream = StreamResolution.STREAM_368_368_30FPS,
            previewNum = 0,
        )
}

class X4SingleLenSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFitMode.NONE
                isFlowStateEnabledForPreview() -> PreviewFitMode.FILL
                else -> PreviewFitMode.CONTAIN
            }
    override val previewFileType
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFileType.SPECIAL_SELFIE
                isFlowStateEnabledForPreview() -> PreviewFileType.UNPANORAMA
                else -> PreviewFileType.FISH_EYE
            }
    override val previewStabType = PreviewStabType.STAB_FULL_DIRECTIONAL
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val previewGyroType
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewGyroType.X3_FISHEYE
                isFlowStateEnabledForPreview() -> PreviewGyroType.X3_Z180
                else -> PreviewGyroType.X3_FISHEYE
            }
    override val isDynamicAlphaSupported: Boolean = true
    override val isBlendUsingFisheyeMaskSupported: Boolean = true
    override val isSupportUpFlowV2: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1152_1152_30FPS,
            secondStream = StreamResolution.STREAM_368_368_30FPS,
            previewNum = 0,
        )
}
