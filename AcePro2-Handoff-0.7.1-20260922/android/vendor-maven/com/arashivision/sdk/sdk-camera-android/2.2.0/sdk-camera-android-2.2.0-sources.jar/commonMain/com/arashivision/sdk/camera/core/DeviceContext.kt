package com.arashivision.sdk.camera.core

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.native.UnifiedTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow

class DeviceContext(val connectType: ConnectType, val scope: CoroutineScope) {
    val events = MutableSharedFlow<DeviceEvent>(replay = 1, extraBufferCapacity = 128)
    val transport = UnifiedTransport(connectType)
    var cameraConfig: ICameraConfig? = null
    var awarePeerIpv6: String? = null

    private lateinit var _core: DeviceCore

    fun attachCore(core: DeviceCore) {
        if (this::_core.isInitialized) {
            throw IllegalStateException("DeviceCore already attached!")
        }
        _core = core
    }

    val core: DeviceCore
        get() = _core
}