package com.arashivision.sdk.camera.service.system

import com.arashivision.sdk.camera.api.CameraSystem
import com.arashivision.sdk.camera.api.param.listener.BatteryListener
import com.arashivision.sdk.camera.api.param.listener.ChargeBoxStatusListener
import com.arashivision.sdk.camera.api.param.listener.StorageStateListener
import com.arashivision.sdk.camera.api.param.listener.TemperatureListener
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.capture.LockScreenState
import com.arashivision.sdk.camera.core.model.option.BatteryData
import com.arashivision.sdk.camera.core.model.option.ChargeBoxData
import com.arashivision.sdk.camera.core.model.option.LanguageType
import com.arashivision.sdk.camera.core.model.option.LocalTime
import com.arashivision.sdk.camera.core.model.option.Sharpness
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.VideoEncode
import com.arashivision.sdk.camera.core.model.option.WiFiChannel
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.camera.service.CameraService
import com.arashivision.sdk.camera.service.preview.PreviewStatus
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.exception.AlreadyReleasedException
import com.arashivision.sdk.common.exception.CameraActivateException
import com.arashivision.sdk.common.exception.INSTA_OK
import com.arashivision.sdk.common.kotlin.encrypt
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.generateUuid
import com.arashivision.sdk.common.kotlin.getCustomizedDeviceID
import com.arashivision.sdk.common.kotlin.invokeCallback
import com.arashivision.sdk.common.kotlin.nowMs
import com.arashivision.sdk.common.kotlin.post
import com.arashivision.sdk.common.kotlin.sign
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class CameraSystemService(
    camera: DeviceCore,
    connectType: ConnectType,
    scope: CoroutineScope,
    isActive: () -> Boolean,
    private val getPreviewStatus: () -> PreviewStatus
) : CameraService(camera, connectType, scope, isActive), CameraSystem {

    companion object {
        private const val TAG = "CameraSystemService"
        private const val ACTIVE_CAMERA_URL = "https://openapi.insta360.com/device/v2/common/activate"
        private const val ALREADY_ACTIVATED_CODE = 3002
    }

    private val lockScreenMutex = Mutex()

    private val batteryListeners = mutableListOf<BatteryListener>()
    private val batteryMutex = Mutex()

    private val chargeBoxStatusListener = mutableListOf<ChargeBoxStatusListener>()
    private val chargeBoxStatusMutex = Mutex()

    private val temperatureListeners = mutableListOf<TemperatureListener>()
    private val temperatureMutex = Mutex()

    private val storageStatusListeners = mutableListOf<StorageStateListener>()
    private val storageStatusMutex = Mutex()

    init {
        scope.launch {
            camera.events.collect { event ->
                when (event) {
                    DeviceEvent.BatteryLowEvent -> {
                        val snapshot = batteryMutex.withLock { batteryListeners.toList() }
                        snapshot.forEach { it.onLowBatteryWarning() }
                    }

                    is DeviceEvent.BatteryUpdateEvent -> {
                        val snapshot = batteryMutex.withLock { batteryListeners.toList() }
                        snapshot.forEach { it.onBatteryLevelChange(event.batteryData) }
                    }

                    is DeviceEvent.ChargeBoxUpdateEvent -> {
                        val snapshot = chargeBoxStatusMutex.withLock { chargeBoxStatusListener.toList() }
                        snapshot.forEach { it.onChargeBoxStatusChange(event.chargeBoxData) }
                    }

                    is DeviceEvent.StorageUpdateEvent -> {
                        val snapshot = storageStatusMutex.withLock { storageStatusListeners.toList() }
                        snapshot.forEach { listener -> listener.onStorageStateListChanged(event.storageDataList) }
                    }

                    is DeviceEvent.TemperatureEvent -> {
                        val snapshot = temperatureMutex.withLock { temperatureListeners.toList() }
                        snapshot.forEach { listener -> listener.onTemperatureUpdate(event.tempState) }
                    }

                    else -> {}
                }
            }
        }
    }

    // ------------------- 电量监听 -------------------
    override fun registerBatteryListener(listener: BatteryListener) {
        if (isDestroyed()) return
        scope.launch {
            batteryMutex.withLock {
                if (!batteryListeners.contains(listener)) {
                    batteryListeners.add(listener)
                }
            }
        }
    }

    override fun unregisterBatteryListener(listener: BatteryListener) {
        if (isDestroyed()) return
        scope.launch {
            batteryMutex.withLock { batteryListeners.remove(listener) }
        }
    }

    // ------------------- 充电盒状态监听 -------------------
    override fun registerChargeBoxStatusListener(listener: ChargeBoxStatusListener) {
        if (isDestroyed()) return
        scope.launch {
            chargeBoxStatusMutex.withLock {
                if (!chargeBoxStatusListener.contains(listener)) {
                    chargeBoxStatusListener.add(listener)
                }
            }
        }
    }

    override fun unregisterChargeBoxStatusListener(listener: ChargeBoxStatusListener) {
        if (isDestroyed()) return
        scope.launch {
            chargeBoxStatusMutex.withLock { chargeBoxStatusListener.remove(listener) }
        }
    }

    // ------------------- 相机温度过高监听 -------------------
    override fun registerTemperatureListener(listener: TemperatureListener) {
        if (isDestroyed()) return
        scope.launch {
            temperatureMutex.withLock {
                if (!temperatureListeners.contains(listener)) {
                    temperatureListeners.add(listener)
                }
            }
        }
    }

    override fun unregisterTemperatureListener(listener: TemperatureListener) {
        if (isDestroyed()) return
        scope.launch {
            temperatureMutex.withLock { temperatureListeners.remove(listener) }
        }
    }

    // ------------------- 存储状态监听 -------------------
    override fun registerStorageStatusListener(listener: StorageStateListener) {
        if (isDestroyed()) return
        scope.launch {
            storageStatusMutex.withLock {
                if (!storageStatusListeners.contains(listener)) {
                    storageStatusListeners.add(listener)
                }
            }
        }
    }

    override fun unregisterStorageStatusListener(listener: StorageStateListener) {
        if (isDestroyed()) return
        scope.launch {
            storageStatusMutex.withLock { storageStatusListeners.remove(listener) }
        }
    }

    private fun <T> releasedFailure(): Result<T> = Result.failure(AlreadyReleasedException())

    override fun getBatteryData(): Result<BatteryData> = if (isDestroyed()) releasedFailure() else camera.getBatteryData()
    override suspend fun fetchBatteryData(): Result<BatteryData> = if (isDestroyed()) releasedFailure() else camera.fetchBatteryData()
    override fun fetchBatteryData(callback: Callback<BatteryData>) {
        scope.launch {
            fetchBatteryData().invokeCallback(callback)
        }
    }

    override fun getChargeBoxData(): Result<ChargeBoxData> = if (isDestroyed()) releasedFailure() else camera.getChargeBoxData()
    override fun fetchChargeBoxData(callback: Callback<ChargeBoxData>) {
        scope.launch {
            fetchChargeBoxData().invokeCallback(callback)
        }
    }

    override suspend fun fetchChargeBoxData(): Result<ChargeBoxData> = if (isDestroyed()) releasedFailure() else camera.fetchChargeBoxData()

    override fun getMute(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.getMute()
    override suspend fun fetchMute(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.fetchMute()
    override fun fetchMute(callback: Callback<Boolean>) {
        scope.launch {
            fetchMute().invokeCallback(callback)
        }
    }

    override fun setMute(enable: Boolean, callback: Callback<Unit>) {
        scope.launch {
            setMute(enable).invokeCallback(callback)
        }
    }

    override suspend fun setMute(enable: Boolean): Result<Unit> = if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setMute(enable)

    override fun getSerialNumber(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getSerialNumber()
    override suspend fun fetchSerialNumber(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchSerialNumber()
    override fun fetchSerialNumber(callback: Callback<String>) {
        scope.launch {
            fetchSerialNumber().invokeCallback(callback)
        }
    }

    override fun getUuid(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getUuid()
    override suspend fun fetchUuid(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchUuid()
    override fun fetchUuid(callback: Callback<String>) {
        scope.launch {
            fetchUuid().invokeCallback(callback)
        }
    }

    override fun getOriginOffset(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getOriginOffset()
    override suspend fun fetchOriginOffset(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchOriginOffset()
    override fun fetchOriginOffset(callback: Callback<String>) {
        scope.launch {
            fetchOriginOffset().invokeCallback(callback)
        }
    }

    override fun getActivateTime(): Result<Long> = if (isDestroyed()) releasedFailure() else camera.getActivateTime()
    override suspend fun fetchActivateTime(): Result<Long> = if (isDestroyed()) releasedFailure() else camera.fetchActivateTime()
    override fun fetchActivateTime(callback: Callback<Long>) {
        scope.launch {
            fetchActivateTime().invokeCallback(callback)
        }
    }

    override fun setActivateTime(activeTime: Long, callback: Callback<Unit>) {
        scope.launch {
            setActivateTime(activeTime).invokeCallback(callback)
        }
    }

    override suspend fun setActivateTime(activeTime: Long): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setActivateTime(activeTime)

    override fun getStorageData(): Result<StorageData> = if (isDestroyed()) releasedFailure() else camera.getStorageData()
    override suspend fun fetchStorageData(): Result<StorageData> = if (isDestroyed()) releasedFailure() else camera.fetchStorageData()
    override fun fetchStorageData(callback: Callback<StorageData>) {
        scope.launch {
            fetchStorageData().invokeCallback(callback)
        }
    }

    override fun getStorageDataList(): Result<List<StorageData>> = if (isDestroyed()) releasedFailure() else camera.getStorageDataList()
    override suspend fun fetchStorageDataList(): Result<List<StorageData>> = if (isDestroyed()) releasedFailure() else camera.fetchStorageDataList()
    override fun fetchStorageDataList(callback: Callback<List<StorageData>>) {
        scope.launch {
            fetchStorageDataList().invokeCallback(callback)
        }
    }

    override fun getMediaOffset(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getMediaOffset()
    override suspend fun fetchMediaOffset(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchMediaOffset()
    override fun fetchMediaOffset(callback: Callback<String>) {
        scope.launch {
            fetchMediaOffset().invokeCallback(callback)
        }
    }

    override fun getSupportConfig() = if (isDestroyed()) releasedFailure() else camera.getCameraConfig()

    override fun getFirmwareRevision(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getFirmwareRevision()
    override suspend fun fetchFirmwareRevision(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchFirmwareRevision()
    override fun fetchFirmwareRevision(callback: Callback<String>) {
        scope.launch {
            fetchFirmwareRevision().invokeCallback(callback)
        }
    }

    override fun getWifiData(): Result<WiFiData> = if (isDestroyed()) releasedFailure() else camera.getWiFiData()
    override suspend fun fetchWifiData(): Result<WiFiData> = if (isDestroyed()) releasedFailure() else camera.fetchWiFiData()
    override fun fetchWifiData(callback: Callback<WiFiData>) {
        scope.launch {
            fetchWifiData().invokeCallback(callback)
        }
    }

    override fun getWifiChannelList(): Result<WiFiChannel> = if (isDestroyed()) releasedFailure() else camera.getWiFiChannelList()
    override suspend fun fetchWifiChannelList(): Result<WiFiChannel> = if (isDestroyed()) releasedFailure() else camera.fetchWiFiChannelList()
    override fun fetchWifiChannelList(callback: Callback<WiFiChannel>) {
        scope.launch {
            fetchWifiChannelList().invokeCallback(callback)
        }
    }

    override fun openCameraWiFi(channel: Int, callback: Callback<Unit>) {
        scope.launch {
            openCameraWiFi(channel).invokeCallback(callback)
        }
    }

    override suspend fun openCameraWiFi(channel: Int): Result<Unit> = if (isDestroyed()) releasedFailure() else camera.openCameraWiFi(channel)

    override fun closeCameraWiFi(callback: Callback<Unit>) {
        scope.launch {
            closeCameraWiFi().invokeCallback(callback)
        }
    }

    override suspend fun closeCameraWiFi(): Result<Unit> = if (isDestroyed()) releasedFailure() else camera.closeCameraWiFi()

    override fun setWifiMode(mode: WiFiData.Mode, countryCode: String, callback: Callback<Unit>) {
        scope.launch {
            setWifiMode(mode, countryCode).invokeCallback(callback)
        }
    }

    override suspend fun setWifiMode(mode: WiFiData.Mode, countryCode: String): Result<Unit> =
        if (isDestroyed()) releasedFailure() else camera.setWifiMode(mode, countryCode)

    override fun resetCameraWiFi(channel: Int, callback: Callback<Unit>) {
        scope.launch {
            resetCameraWiFi(channel).invokeCallback(callback)
        }
    }

    override suspend fun resetCameraWiFi(channel: Int): Result<Unit> = if (isDestroyed()) releasedFailure() else camera.resetCameraWiFi(channel)

    override fun setWiFiCountry(countryCode: String, callback: Callback<Unit>) {
        scope.launch {
            setWiFiCountry(countryCode).invokeCallback(callback)
        }
    }

    override suspend fun setWiFiCountry(countryCode: String): Result<Unit> =
        if (isDestroyed()) releasedFailure() else camera.setWiFiCountry(countryCode)


    override fun getCameraType(): Result<CameraType> = if (isDestroyed()) releasedFailure() else camera.getCameraType()
    override suspend fun fetchCameraType(): Result<CameraType> = if (isDestroyed()) releasedFailure() else camera.fetchCameraType()
    override fun fetchCameraType(callback: Callback<CameraType>) {
        scope.launch {
            fetchCameraType().invokeCallback(callback)
        }
    }

    override fun getVideoEncodeType(): Result<VideoEncode> = if (isDestroyed()) releasedFailure() else camera.getVideoEncodeType()
    override suspend fun fetchVideoEncodeType(): Result<VideoEncode> = if (isDestroyed()) releasedFailure() else camera.fetchVideoEncodeType()
    override fun fetchVideoEncodeType(callback: Callback<VideoEncode>) {
        scope.launch {
            fetchVideoEncodeType().invokeCallback(callback)
        }
    }

    override fun setVideoEncodeType(videoEncode: VideoEncode, callback: Callback<Unit>) {
        scope.launch {
            setVideoEncodeType(videoEncode).invokeCallback(callback)
        }
    }

    override suspend fun setVideoEncodeType(videoEncode: VideoEncode): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setVideoEncodeType(videoEncode)

    override fun getIsSelfie(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.getIsSelfie()
    override suspend fun fetchIsSelfie(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.fetchIsSelfie()
    override fun fetchIsSelfie(callback: Callback<Boolean>) {
        scope.launch {
            fetchIsSelfie().invokeCallback(callback)
        }
    }

    override fun getOriginOffsetV2(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getOriginOffsetV2()
    override suspend fun fetchOriginOffsetV2(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchOriginOffsetV2()
    override fun fetchOriginOffsetV2(callback: Callback<String>) {
        scope.launch {
            fetchOriginOffsetV2().invokeCallback(callback)
        }
    }

    override fun getOriginOffsetV3(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getOriginOffsetV3()
    override suspend fun fetchOriginOffsetV3(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchOriginOffsetV3()
    override fun fetchOriginOffsetV3(callback: Callback<String>) {
        scope.launch {
            fetchOriginOffsetV3().invokeCallback(callback)
        }
    }

    override fun getMediaOffsetV2(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getMediaOffsetV2()
    override suspend fun fetchMediaOffsetV2(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchMediaOffsetV2()
    override fun fetchMediaOffsetV2(callback: Callback<String>) {
        scope.launch {
            fetchMediaOffsetV2().invokeCallback(callback)
        }
    }

    override fun getMediaOffsetV3(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getMediaOffsetV3()
    override suspend fun fetchMediaOffsetV3(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchMediaOffsetV3()
    override fun fetchMediaOffsetV3(callback: Callback<String>) {
        scope.launch {
            fetchMediaOffsetV3().invokeCallback(callback)
        }
    }

    override fun getMediaOffsetV6(): Result<String> = if (isDestroyed()) releasedFailure() else camera.getMediaOffsetV6()
    override suspend fun fetchMediaOffsetV6(): Result<String> = if (isDestroyed()) releasedFailure() else camera.fetchMediaOffsetV6()
    override fun fetchMediaOffsetV6(callback: Callback<String>) {
        scope.launch {
            fetchMediaOffsetV6().invokeCallback(callback)
        }
    }

    override fun getWindowCropInfo() = if (isDestroyed()) releasedFailure() else camera.getWindowCropInfo()

    override fun getHalfWindowCropInfo() = if (isDestroyed()) releasedFailure() else camera.getHalfWindowCropInfo()

    override fun getSensorInfo() = if (isDestroyed()) releasedFailure() else camera.getSensorInfo()

    override fun getOffsetState(): Result<Int> = if (isDestroyed()) releasedFailure() else camera.getOffsetState().map { it.value }

    override fun getOffsetDetectedType(): Result<Int> =
        if (isDestroyed()) releasedFailure() else camera.getOffsetDetectedType().map { it.value }

    override fun getCameraLanguage(): Result<LanguageType> = if (isDestroyed()) releasedFailure() else camera.getCameraLanguage()
    override suspend fun fetchCameraLanguage(): Result<LanguageType> = if (isDestroyed()) releasedFailure() else camera.fetchCameraLanguage()
    override fun fetchCameraLanguage(callback: Callback<LanguageType>) {
        scope.launch {
            fetchCameraLanguage().invokeCallback(callback)
        }
    }

    override fun setCameraLanguage(languageType: LanguageType, callback: Callback<Unit>) {
        scope.launch {
            setCameraLanguage(languageType).invokeCallback(callback)
        }
    }

    override suspend fun setCameraLanguage(languageType: LanguageType): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setCameraLanguage(languageType)

    override fun setLocalTime(localTime: LocalTime, callback: Callback<Unit>) {
        scope.launch {
            setLocalTime(localTime).invokeCallback(callback)
        }
    }

    override suspend fun setLocalTime(localTime: LocalTime): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setLocalTime(localTime)

    override fun getAssistiveGridEnable(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.getAssistiveGridEnable()
    override suspend fun fetchAssistiveGridEnable(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.fetchAssistiveGridEnable()
    override fun fetchAssistiveGridEnable(callback: Callback<Boolean>) {
        scope.launch {
            fetchAssistiveGridEnable().invokeCallback(callback)
        }
    }

    override fun setAssistiveGridEnable(enable: Boolean, callback: Callback<Unit>) {
        scope.launch {
            setAssistiveGridEnable(enable).invokeCallback(callback)
        }
    }

    override suspend fun setAssistiveGridEnable(enable: Boolean): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setAssistiveGridEnable(enable)

    override fun getFreeFrameGridEnable(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.getFreeFrameGridEnable()
    override suspend fun fetchFreeFrameGridEnable(): Result<Boolean> = if (isDestroyed()) releasedFailure() else camera.fetchFreeFrameGridEnable()
    override fun fetchFreeFrameGridEnable(callback: Callback<Boolean>) {
        scope.launch {
            fetchFreeFrameGridEnable().invokeCallback(callback)
        }
    }

    override fun setFreeFrameGridEnable(enable: Boolean, callback: Callback<Unit>) {
        scope.launch {
            setFreeFrameGridEnable(enable).invokeCallback(callback)
        }
    }

    override suspend fun setFreeFrameGridEnable(enable: Boolean): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setFreeFrameGridEnable(enable)

    override fun getSharpness(): Result<Sharpness> =
        if (isDestroyed()) releasedFailure() else camera.getSharpness().map { Sharpness.nativeOf(it) }

    override suspend fun fetchSharpness(): Result<Sharpness> =
        if (isDestroyed()) releasedFailure() else camera.fetchSharpness().map { Sharpness.nativeOf(it) }

    override fun fetchSharpness(callback: Callback<Sharpness>) {
        scope.launch {
            fetchSharpness().invokeCallback(callback)
        }
    }

    override fun setSharpness(sharpness: Sharpness, callback: Callback<Unit>) {
        scope.launch {
            setSharpness(sharpness).invokeCallback(callback)
        }
    }

    override suspend fun setSharpness(sharpness: Sharpness): Result<Unit> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.setSharpness(sharpness.nativeValue)

    override fun getMediaTime(): Result<Long> = if (isDestroyed()) releasedFailure() else camera.getMediaTime()

    override fun fetchMediaTime(callback: Callback<Long>) {
        scope.launch {
            fetchMediaTime().invokeCallback(callback)
        }
    }

    override suspend fun fetchMediaTime(): Result<Long> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.fetchMediaTime()

    override fun getRollingShutterTime(): Result<Double> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.getRollingShutterTime()

    override suspend fun fetchRollingShutterTime(): Result<Double> =
        if (isDestroyed()) Result.failure(AlreadyReleasedException()) else camera.fetchRollingShutterTime()

    override fun activeCamera(appId: String, secretKey: String, callback: Callback<Unit>) {
        scope.launch {
            activeCamera(appId, secretKey).invokeCallback(callback)
        }
    }

    override suspend fun activeCamera(appId: String, secretKey: String): Result<Unit> {
        return getSerialNumber().flatMap { serial ->
            val buildJsonObject = buildJsonObject {
                put("serial", serial)
            }
            encrypt(buildJsonObject.toString(), secretKey).success()
        }.flatMap {
            val nonce = generateUuid()
            val timestamp = "${nowMs() / 1000}"
            val headers = mapOf(
                "X-Insta360-AppId" to appId,
                "X-Insta360-Nonce" to nonce,
                "X-Insta360-Timestamp" to timestamp,
                "X-Insta360-Sign" to sign("appId=$appId&encrypt=$it&nonce=$nonce&timestamp=$timestamp", secretKey),
                "X-Insta360-Schema" to "1.0",
                "X-Equipment-Code" to getCustomizedDeviceID(),
            )
            post<ActiveCameraBean>(ACTIVE_CAMERA_URL, mapOf("encrypt" to it), headers)
        }.fold(
            onSuccess = { response ->
                val activateTime = getActivateTimeByService(response)
                if (activateTime > 0) {
                    setActivateTime(activateTime)
                } else {
                    CameraActivateException(response.code ?: -1).failure()
                }
            },
            onFailure = { it.failure() }
        )
    }

    private fun getActivateTimeByService(response: ActiveCameraBean): Long {
        val code = response.code
        if (code == INSTA_OK && response.data?.activation != null) {
            return response.data.activation.create_time ?: -1L
        }
        if (code == ALREADY_ACTIVATED_CODE && response.errorData?.activation != null) {
            return response.errorData.activation.create_time ?: -1L
        }
        return -1L
    }


    override fun calibrateGyro(callback: Callback<Unit>) {
        scope.launch {
            calibrateGyro().invokeCallback(callback)
        }
    }

    override suspend fun calibrateGyro(): Result<Unit> = if (isDestroyed()) releasedFailure() else camera.calibrateGyro()


    override fun shutdown() {
        camera.shutdown()
    }

    override fun setLockScreenState(lockScreenState: LockScreenState, callback: Callback<Unit>) {
        scope.launch {
            setLockScreenState(lockScreenState).invokeCallback(callback)
        }
    }

    override suspend fun setLockScreenState(lockScreenState: LockScreenState): Result<Unit> {
        return lockScreenMutex.withLock {
            camera.setAccessCameraFileState(lockScreenState.nativeValue).onSuccess {
                val supportLowPowerMode = camera.getCameraConfig().getOrNull()?.supportLowPowerMode() == true
                if (supportLowPowerMode) {
                    // 最小化开/关流与真实预览流走的是同一条原生通道（transport.previewStream/closeStream）。
                    // 仅当 previewStatus == IDLE（相机已确认无真实预览流）时才操作，避免 STOPPING（关流命令已发出、
                    // 相机尚未异步确认）这个中间态与真实关流指令在同一通道上产生竞态。
                    val previewStatus = getPreviewStatus()
                    when (lockScreenState) {
                        LockScreenState.LOCK -> {
                            if (previewStatus == PreviewStatus.IDLE) {
                                camera.openMinimalPreviewStream()
                            }
                        }

                        LockScreenState.IDLE -> {
                            if (previewStatus == PreviewStatus.IDLE) {
                                camera.closeMinimalPreviewStream()
                            }
                        }
                    }
                }
            }.onFailure {
                Logger.w(TAG, "setLockScreenState state=$lockScreenState failed: ${it.message}")
            }
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override suspend fun formatSdCard(): Result<Unit> = if (isDestroyed()) releasedFailure() else camera.formatSdCard()

    @Suppress("OVERRIDE_DEPRECATION")
    override fun formatSdCard(callback: Callback<Unit>) {
        scope.launch {
            formatSdCard().invokeCallback(callback)
        }
    }

    override fun formatStorage(fileLocation: StorageData.FileLocation, callback: Callback<Unit>) {
        scope.launch {
            formatStorage(fileLocation).invokeCallback(callback)
        }
    }

    override suspend fun formatStorage(fileLocation: StorageData.FileLocation): Result<Unit> {
        if (isDestroyed()) return releasedFailure()
        return if (fileLocation == StorageData.FileLocation.CAMERA) {
            camera.formatSdCard()
        } else {
            camera.formatStorage(fileLocation)
        }
    }

    override fun setMainStorage(fileLocation: StorageData.FileLocation, callback: Callback<Unit>) {
        scope.launch {
            setMainStorage(fileLocation).invokeCallback(callback)
        }
    }

    override suspend fun setMainStorage(fileLocation: StorageData.FileLocation): Result<Unit> =
        if (isDestroyed()) releasedFailure() else camera.setMainStorage(fileLocation)

    override suspend fun destroy() {
        batteryMutex.withLock {
            batteryListeners.clear()
        }
        chargeBoxStatusMutex.withLock {
            chargeBoxStatusListener.clear()
        }
        temperatureMutex.withLock {
            temperatureListeners.clear()
        }
        storageStatusMutex.withLock {
            storageStatusListeners.clear()
        }
    }
}