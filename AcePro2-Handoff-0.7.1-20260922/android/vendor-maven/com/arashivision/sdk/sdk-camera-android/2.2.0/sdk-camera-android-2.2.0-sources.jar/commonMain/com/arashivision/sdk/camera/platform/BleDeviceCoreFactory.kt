package com.arashivision.sdk.camera.platform

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.sdk.common.type.KMPBleDevice

expect fun createBleDeviceCore(kmpBleDevice: KMPBleDevice): BleDeviceCore

// 获取默认的蓝牙扫描模式
expect fun getDefaultBleScanMode():Int