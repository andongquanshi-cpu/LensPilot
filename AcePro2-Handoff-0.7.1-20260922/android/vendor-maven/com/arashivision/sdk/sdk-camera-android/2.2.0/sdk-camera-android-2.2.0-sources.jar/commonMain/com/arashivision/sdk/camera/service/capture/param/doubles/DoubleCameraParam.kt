package com.arashivision.sdk.camera.service.capture.param.doubles

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger

internal abstract class DoubleCameraParam(
    name: String,
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>,
    private val precision: Int = 1
) : CameraParamImpl<Double>(name, managerProvider, deviceCoreProvider) {

    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<Double> {
        return currentFunctionMode().onSuccess {
            Logger.i(TAG, "intParam reader key=$key, mode=${it}")
        }.onFailure {
            Logger.e(TAG, "intParam reader key=$key failed to get mode: ${it.message}")
        }.flatMap { mode ->
            readFormCamera(device, mode)
        }.mapFailure { invalidStateException(it, key) }
    }

    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<Double> {
        return currentFunctionMode().onSuccess {
            Logger.i(TAG, "intParam reader key=$key, mode=${it}")
        }.onFailure {
            Logger.e(TAG, "intParam reader key=$key failed to get mode: ${it.message}")
        }.flatMap { mode ->
            fetchFormCamera(device, mode)
        }.mapFailure { invalidStateException(it, key) }
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: Double): Result<Unit> {
        return currentFunctionMode().flatMap { mode ->
            writeToCamera(device, mode, value)
        }.onSuccess {
            manager.setAttrValue(key, value, precision)
        }.mapFailure {
            InvalidStateException("${it.message}: device error")
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<Double>> {
        return manager.attributeOptions(key).flatMap { opts ->
            opts.mapNotNull { it.toDoubleOrNull() }
                .takeIf { it.isNotEmpty() }
                ?.success()
                ?: NumberConversionException("No valid double options for $key").failure()
        }
    }

}