package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionType
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

internal class Go3SSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFileType
        get() = if (isFlowStateEnabledForPreview()) PreviewFileType.UNPANORAMA else PreviewFileType.WIDE_ANGLE
    override val previewFitMode
        get() =
            when {
                isFlowStateEnabledForPreview() && snapshot.functionMode.functionType == FunctionType.PHOTO -> PreviewFitMode.COVER
                isFlowStateEnabledForPreview() -> PreviewFitMode.FILL
                else -> PreviewFitMode.CONTAIN
            }
    override val previewGyroType = PreviewGyroType.GO3S
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewStabType = PreviewStabType.STAB_FREE_FOOTAGE
    override val isRotateEnabled: Boolean = false
    override val isRotateScreenRatioEnabled: Boolean = true
    override val isGestureEnabledByMode: Boolean = false
    override val isFishEyeEdgePaddingEnabled: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
        isVideo: Boolean
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = currentRecordStream() ?: StreamResolution.STREAM_1280_720_30FPS,
                    secondStream = StreamResolution.STREAM_640_360_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = currentRecordStream() ?: StreamResolution.STREAM_2560_1440_30FPS,
                    secondStream = if (isFlowstateOn) StreamResolution.STREAM_640_360_30FPS else StreamResolution.STREAM_368_368_30FPS,
                    previewNum = 1,
                )

            else -> {
                val firstStream = if (isFlowstateOn) {
                    if (isVideo) {
                        if (previewWidth >= previewHeight) {
                            StreamResolution.STREAM_640_360_30FPS
                        } else {
                            StreamResolution.STREAM_360_640_30FPS
                        }
                    } else {
                        if (previewWidth >= previewHeight) {
                            StreamResolution.STREAM_640_480_30FPS
                        } else {
                            StreamResolution.STREAM_480_640_30FPS
                        }

                    }
                } else {
                    StreamResolution.STREAM_640_480_30FPS
                }
                previewParams(
                    firstStream = firstStream,
                    secondStream = StreamResolution.STREAM_640_480_30FPS,
                    previewNum = 0,
                )
            }
        }
}
