package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class PhotoHdrType(override val nativeValue: Int, val protoName: String) : BaseEnum {
    OFF(0, "OFF"),
    ON(1, "ON"),
    AEB(2, "AEB");

    companion object {
        fun nativeOf(value: Int?): PhotoHdrType = entries.firstOrNull { it.nativeValue == value } ?: OFF
        fun protoOf(name: String?): PhotoHdrType =
            entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: OFF
    }
}