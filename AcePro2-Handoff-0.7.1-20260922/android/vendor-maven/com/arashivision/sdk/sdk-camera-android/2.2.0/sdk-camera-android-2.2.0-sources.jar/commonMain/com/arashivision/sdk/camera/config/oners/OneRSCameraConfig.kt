package com.arashivision.sdk.camera.config.oners

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import insta360.messages.MultiPhotographyOptionsType

class OneRSCameraConfig(override val connectType: ConnectType) : ICameraConfig {

    override fun supportShutdown(): Boolean = false

    override fun supportMultiVideoOptionsList(): List<MultiPhotographyOptionsType> = emptyList()

    override fun captureMinBatteryLevel(): Int = 0

    override fun supportResetCameraWifi(fwVersion: String): Boolean = false

    override fun supportFetchCameraSensorMode(): Boolean = true

    override fun syncOptionMaxStep(): Int =
        if (connectType == ConnectType.BLE) 16 else Int.MAX_VALUE

    override fun hasChargingBox(): Boolean = false

    override fun supportDownloadJsonParams(): Boolean = false

    override fun getLensName(sensorMode: SensorMode): String =
        if (sensorMode == SensorMode.ALL) "Sphere" else "Fisheye"

    override fun firmwareUpgradeMinBatteryLevel(): Int = 23

    override fun firmwareUpgradeMinChargingBoxBatteryLevel(): Int = 0

    override fun supportNewRecordInterface(): Boolean = true

    override fun needNotifyWhenCameraRecordOverTimeLimit(): Boolean = true

    override fun isMergedIntoRS(version: String): Boolean = true

    override fun supportBleBroadcastWakeUp(): Boolean = true
}