package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 曝光参数组合。
 *
 * 注意：部分机型/配置（例如 `go3Ultra.json` 的 `exposure_shutter_speed`）会用 **0** 表示“自动快门”。
 * 为了统一对外表现，这里约定：
 * - `shutterSpeed = 0.0 to 0.0` 表示 **AUTO shutter**（自动快门）
 * - 小于等于1秒：通常为 `1/x`（分子为 1，分母可为整数或小数，如 1/12.5）
 * - 大于1秒：为 `x/1`（分子为秒数，分母为 1，如 10/1 表示10秒）
 */
data class Exposure(
    val program: ExposureProgram,
    val iso: Int = 0,
    var shutterSpeed: Pair<Double, Double> = AUTO_SHUTTER_SPEED
) {

    fun isAutoShutterSpeed(): Boolean = shutterSpeed.first == 0.0 && shutterSpeed.second == 0.0

    /**
     * 以 Double 形式返回当前快门速度：
     * - 自动快门：返回 0.0
     * - 非法分母：返回 -1.0
     */
    fun shutterSpeedDoubleValue(): Double {
        val (numerator, denominator) = shutterSpeed
        if (numerator == 0.0 && denominator == 0.0) return 0.0
        if (denominator == 0.0) return -1.0
        return numerator / denominator
    }

    fun setShutterSpeed(value: Double) {
        // 约定：0 表示自动快门
        shutterSpeed = if (value == 0.0) {
            AUTO_SHUTTER_SPEED
        } else {
            toUnitFraction(value) ?: AUTO_SHUTTER_SPEED
        }
    }

    companion object {
        val AUTO_SHUTTER_SPEED: Pair<Double, Double> = 0.0 to 0.0

        fun nativeOf(value: Int?): ExposureProgram = ExposureProgram.nativeOf(value)
        fun protoOf(name: String?): ExposureProgram = ExposureProgram.protoOf(name)

        /**
         * 从分子为 1 的分数创建 Exposure（快门速度依旧内部用 double 存储）。
         */
        fun fromUnitFraction(
            program: ExposureProgram,
            iso: Int,
            numerator: Int,
            denominator: Int
        ): Exposure? {
            return if (numerator == 1 && denominator != 0) {
                Exposure(program, iso, numerator.toDouble() to denominator.toDouble())
            } else {
                null
            }
        }

        /**
         * 通过 Double 快门速度创建 Exposure。
         * - 小于等于1秒：转换为 1/x 形式
         * - 大于1秒：转换为 x/1 形式
         */
        fun fromShutterSpeed(
            program: ExposureProgram,
            iso: Int,
            shutterSpeed: Double,
            tolerance: Double = 1e-6
        ): Exposure? {
            // 约定：0 表示自动快门（例如 go3Ultra.json 的 supported list）
            if (shutterSpeed == 0.0) return Exposure(program, iso, AUTO_SHUTTER_SPEED)
            val fraction = toUnitFraction(shutterSpeed, tolerance) ?: return null
            return Exposure(program, iso, fraction)
        }

        private fun toUnitFraction(value: Double, tolerance: Double = 1e-6): Pair<Double, Double>? {
            if (value <= 0.0 || value.isNaN() || value.isInfinite()) return null
            
            // 大于1秒时，返回 (value, 1.0) 的形式，如 10秒 -> (10.0, 1.0)
            if (value > 1.0) {
                return value to 1.0
            }
            
            val rawDen = 1.0 / value
            if (rawDen.isInfinite() || rawDen.isNaN() || rawDen == 0.0) return null

            // 若接近整数则归一为整数分母，否则保留小数分母（支持 1/12.5、1/1.25 等）
            val rounded = rawDen.roundToInt().toDouble()
            val den = if (abs(rawDen - rounded) <= tolerance) rounded else rawDen
            return 1.0 to den
        }
    }

    enum class ExposureProgram(override val nativeValue: Int, val protoName: String) : BaseEnum {
        AUTO(0, "AUTO"),
        ISO_PRIORITY(1, "ISO_PRIORITY"),
        SHUTTER_PRIORITY(2, "SHUTTER_PRIORITY"),
        MANUAL(3, "MANUAL"),
        ADAPTIVE(4, "ADAPTIVE"),
        FULL_AUTO(5, "FULL_AUTO"),
        UNKNOWN(-1, "UNKNOWN");

        companion object {
            fun nativeOf(value: Int?): ExposureProgram = entries.firstOrNull { it.nativeValue == value } ?: UNKNOWN
            fun protoOf(name: String?): ExposureProgram = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: UNKNOWN
        }
    }
}