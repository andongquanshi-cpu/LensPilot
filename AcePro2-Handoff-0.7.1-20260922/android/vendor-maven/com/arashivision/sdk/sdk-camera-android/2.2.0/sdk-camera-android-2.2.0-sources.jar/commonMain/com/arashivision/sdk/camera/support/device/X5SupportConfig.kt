package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewRenderModel
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class X5PanoramaSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.FIT_10
    override val previewStabType: PreviewStabType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewStabType.STAB_FULL_DIRECTIONAL else PreviewStabType.STAB_STILL
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val previewFileType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewFileType.SPECIAL_SELFIE else PreviewFileType.VR360
    override val previewGyroType = PreviewGyroType.X3_FISHEYE
    override val isDynamicAlphaSupported: Boolean = true
    override val isBlendUsingFisheyeMaskSupported: Boolean = true
    override val isSupportUpFlowV2: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1152_1152_30FPS,
            secondStream = StreamResolution.STREAM_368_368_30FPS,
            previewNum = 0,
        )
}

class X5SingleLenSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE ||
                    snapshot.functionMode == FunctionMode.PHOTO_NORMAL ||
                    snapshot.functionMode == FunctionMode.VIDEO_SUPER -> PreviewFitMode.FIT_10
                else -> PreviewFitMode.COVER
            }
    override val previewFileType
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFileType.SPECIAL_SELFIE
                snapshot.functionMode == FunctionMode.PHOTO_NORMAL ||
                    snapshot.functionMode == FunctionMode.VIDEO_SUPER -> PreviewFileType.FISH_EYE
                else -> PreviewFileType.UNPANORAMA
            }
    override val previewRenderModelType: PreviewRenderModel
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewRenderModel.SPHERE_STITCH
                isFlowStateEnabledForPreview() -> PreviewRenderModel.PLANE
                else -> PreviewRenderModel.SPHERE_FISHEYE_DEWARP
            }
    override val previewStabType: PreviewStabType
        get() = if (isFlowStateEnabledForPreview()) PreviewStabType.STAB_OFF else PreviewStabType.STAB_FULL_DIRECTIONAL
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val previewGyroType
        get() = resolveX3FamilyPreviewGyroType()
    override val isDynamicAlphaSupported: Boolean = true
    override val isBlendUsingFisheyeMaskSupported: Boolean = true
    override val isSupportUpFlowV2: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1152_1152_30FPS,
            secondStream = StreamResolution.STREAM_368_368_30FPS,
            previewNum = 0,
        )
}
