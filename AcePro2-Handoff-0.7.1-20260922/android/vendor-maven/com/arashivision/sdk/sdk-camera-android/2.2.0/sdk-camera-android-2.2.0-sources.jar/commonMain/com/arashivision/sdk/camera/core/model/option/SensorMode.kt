package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class SensorMode(override val nativeValue: Int) : BaseEnum {
    UNKNOWN(0),
    FRONT(1),
    REAR(2),
    ALL(3);

    companion object {
        fun nativeOf(nativeValue: Int?): SensorMode {
            return SensorMode.entries.firstOrNull { it.nativeValue == nativeValue } ?: UNKNOWN
        }
    }
}