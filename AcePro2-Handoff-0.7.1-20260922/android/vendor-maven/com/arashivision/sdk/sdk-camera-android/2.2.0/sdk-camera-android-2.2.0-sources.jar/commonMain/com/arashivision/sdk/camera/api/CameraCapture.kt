package com.arashivision.sdk.camera.api

import com.arashivision.sdk.camera.api.param.CameraParam
import com.arashivision.sdk.camera.api.param.gps.GpsInfo
import com.arashivision.sdk.camera.api.param.listener.CaptureStatusListener
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.photography.ExportType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.core.model.photography.FlowStateLevel
import com.arashivision.sdk.camera.core.model.photography.FovType
import com.arashivision.sdk.camera.core.model.photography.Iq3AMode
import com.arashivision.sdk.camera.core.model.photography.LensAccessoryType
import com.arashivision.sdk.camera.core.model.photography.PanoExposureMode
import com.arashivision.sdk.camera.core.model.photography.PhotoHdrType
import com.arashivision.sdk.camera.core.model.photography.PhotoResolution
import com.arashivision.sdk.camera.core.model.photography.PhotoSize
import com.arashivision.sdk.camera.core.model.photography.RawType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.VideoGammaMode
import com.arashivision.sdk.camera.core.model.photography.VideoSelfieMode

/**
 * 相机拍摄服务接口。
 *
 * 提供了对相机拍摄（拍照、录像）流程的控制，以及所有拍摄相关参数的获取和设置。
 * 采用属性式参数访问 API：每个参数以 [CameraParam] 形式暴露，消除了重复的 get/set/supported 方法。
 */
interface CameraCapture {

    // ------------------- 录制状态监听 -------------------
    /** 注册拍摄状态监听器，用于监听开始录制、停止录制、拍摄错误等事件。 */
    fun registerCaptureStatusListener(listener: CaptureStatusListener)

    /** 注销拍摄状态监听器。 */
    fun unregisterCaptureStatusListener(listener: CaptureStatusListener)

    // ==========================================
    // 拍摄模式与参数选择
    // ==========================================

    /** 镜头类型参数（如单镜头、双镜头全景等）。 */
    val lensType: CameraParam<SensorMode>

    /** 拍摄功能模式参数（如普通录像、普通拍照、延时摄影等）。 */
    val functionMode: CameraParam<FunctionMode>

    /** 照片分辨率参数。 */
    val photoResolution: CameraParam<PhotoResolution>

    /** 视频分辨率参数。 */
    val videoResolution: CameraParam<RecordResolution>

    /** 照片 HDR 模式参数。 */
    val hdrPhotoMode: CameraParam<PhotoHdrType>

    /** 视频 HDR 开关参数。 */
    val hdrSwitch: CameraParam<Boolean>

    /** 自动包围曝光 (AEB) 参数。 */
    val aeb: CameraParam<Int>

    /** RAW 格式类型参数。 */
    val rawType: CameraParam<RawType>

    /** 曝光程序参数（如自动、手动、快门优先等）。 */
    val exposureProgram: CameraParam<Exposure.ExposureProgram>

    /** 曝光 ISO 参数。 */
    val exposureISO: CameraParam<Int>

    /** 曝光快门速度参数。 */
    val exposureShutterSpeed: CameraParam<Pair<Double, Double>>

    /** 视频 ISO 上限参数。 */
    val videoISOTopLimit: CameraParam<Int>

    /** 曝光补偿 (EV) 参数。 */
    val exposureBias: CameraParam<Double>

    /** 白平衡参数。 */
    val whiteBalance: CameraParam<Int>

    /** 视场角 (FOV) 类型参数（如广角、线性、窄角等）。 */
    val fovType: CameraParam<FovType>

    /** 防抖等级参数。 */
    val flowStateLevel: CameraParam<FlowStateLevel>

    /** 拍照倒计时参数。 */
    val photographySelfTimer: CameraParam<Int>

    /** 拼接基础开关参数。 */
    val splicingBaseEnable: CameraParam<Boolean>

    /** 视频自拍模式参数。 */
    val videoSelfieMode: CameraParam<VideoSelfieMode>

    /** 导出类型参数。 */
    val exportType: CameraParam<ExportType>

    /** 照片尺寸/比例参数。 */
    val photoSizeId: CameraParam<PhotoSize>

    /** 色彩模式参数。 */
    val colorMode: CameraParam<VideoGammaMode>

    /** 滤镜模式参数。 */
    var filterMode: CameraParam<VideoGammaMode>

    /** 加速频率参数（通常用于延时摄影）。 */
    val accelerateFrequency: CameraParam<Int>

    /** 录制时长参数（如循环录制的单段时长）。 */
    val recordDuration: CameraParam<Int>

    /** 独立曝光模式参数。 */
    val exposureIndividual: CameraParam<PanoExposureMode>

    /** 直播码率参数。 */
    val livingBitrate: CameraParam<Int>

    /** 连拍参数（包含连拍张数和时间间隔）。 */
    val burstCaptureParams: CameraParam<Pair<Int, Int>>

    /** P3 色域开关参数。 */
    val p3Switch: CameraParam<Boolean>

    /** i-Log 色彩模式开关参数。 */
    val iLogSwitch: CameraParam<Boolean>

    /** 纯净夜拍增强开关参数。 */
    val pureVideoEnhanceSwitch: CameraParam<Boolean>

    /** 双倍变焦开关参数。 */
    val doubleZoomEnable: CameraParam<Boolean>

    /** 间隔拍摄的时间间隔参数。 */
    var lapseTime: CameraParam<Double>

    /** 实况照片 (Live Photo) 模式参数。 */
    val livePhotoMode: CameraParam<Boolean>

    /** 镜头配件类型参数（如保护镜等）。 */
    val lensAccessory: CameraParam<LensAccessoryType>

    /** 3A 专业模式开关（NORMAL↔PRO）。exposure_iso/exposure_shutter_speed/white_balance/video_iso_top_limit 等参数在各模式下的可选值收窄由相机端 depend_on 声明驱动，SDK 不做自动模式切换。 */
    val iq3AMode: CameraParam<Iq3AMode>

    // ==========================================
    // 参数管理与同步
    // ==========================================

    /**
     * 获取当前相机支持的所有参数名称列表。
     * @return 支持的参数名称列表。如果尚未加载则返回 null。
     */
    @Deprecated(
        message = "已废弃，请使用 getSupportParam()",
        replaceWith = ReplaceWith("getSupportParam()"),
        level = DeprecationLevel.WARNING
    )
    fun getSupportParamNames(): List<String>

    /**
     * 获取当前相机支持的所有参数
     * @return 支持的参数列表。如果尚未加载则返回 null。
     */
    fun getSupportParam(): List<CameraParam<*>>

    /**
     * 获取所有的 [CameraParam] 实例。
     * @return 所有参数实例的列表。如果尚未加载则返回 null。
     */
    @Deprecated(
        message = "已废弃，请使用 getSupportParam()",
        replaceWith = ReplaceWith("getSupportParam()"),
        level = DeprecationLevel.WARNING
    )
    fun getAllParams(): List<CameraParam<*>>?

    /**
     * 同步所有参数。
     * 强制从相机端拉取最新的参数状态并更新本地缓存。
     */
    suspend fun syncAllParams()

    // ==========================================
    // 拍摄控制
    // ==========================================

    /**
     * 开始拍摄（录像或拍照，取决于当前的 [functionMode]）。
     */
    suspend fun startCapture(gpsInfo: GpsInfo? = null)

    /**
     * 停止拍摄。
     */
    suspend fun stopCapture(gpsInfo: GpsInfo? = null)

    /**
     * 设置给相机GpsInfo
     */
    suspend fun setGpsInfo(gpsInfo: GpsInfo)

    /**
     * 检查相机当前是否正在拍摄/工作状态。
     * @return 如果正在拍摄返回 true，否则返回 false。
     */
    suspend fun isWorking(): Boolean

    /**
     * 检查相机是否处于预录制状态。
     * @return 如果处于预录制状态返回 true，否则返回 false。
     */
    fun isPreRecording(): Boolean

    /**
     * 取消预录制。
     */
    fun cancelPreRecord()

    /**
     * 加载相机的参数配置 JSON 文件。
     * 通常在连接相机后调用，用于初始化支持的参数列表。
     * @return 加载结果。
     */
    suspend fun loadJson(): Result<Unit>

    /**
     * 获取连拍时间。
     * @return 获取结果。
     */
    suspend fun getBurstTime(): Result<Unit>

    /**
     * 获取当前模式下的剩余录制时间（秒）或剩余拍摄张数。
     * @return 剩余量。
     */
    suspend fun getRemaining(): Result<Int>

    /**
     * 获取指定拍摄模式下的剩余录制时间或拍摄张数（从本地缓存获取）。
     * @param functionMode 指定的拍摄模式。
     * @return 剩余量。
     */
    fun getRemaining(functionMode: FunctionMode): Result<Int>

    /**
     * 从相机拉取指定拍摄模式下的最新剩余录制时间或拍摄张数。
     * @param functionMode 指定的拍摄模式。
     * @return 剩余量。
     */
    suspend fun fetchRemaining(functionMode: FunctionMode): Result<Int>
}