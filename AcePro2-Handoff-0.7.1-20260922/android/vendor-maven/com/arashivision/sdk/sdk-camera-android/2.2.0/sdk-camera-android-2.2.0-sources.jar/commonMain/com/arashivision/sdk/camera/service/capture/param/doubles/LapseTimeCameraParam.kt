package com.arashivision.sdk.camera.service.capture.param.doubles

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.timelapse.TimelapseParams
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class LapseTimeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : DoubleCameraParam(CommonAttrKeys.LAPSE_TIME, managerProvider, deviceCoreProvider) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Double> {
        return device.getTimelapseOption(functionMode.timelapseMode()).map {
            it.intervalMs.toDouble().div(1000)
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Double> {
        return if (functionMode.timelapseMode() != -1) {
            device.fetchTimelapseOption(functionMode.timelapseMode())
        } else {
            device.getTimelapseOption(functionMode.timelapseMode())
        }.map {
            it.intervalMs.toDouble().div(1000)
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Double): Result<Unit> {
        val timeLapseMs = value * 1000
        val timelapseParam = TimelapseParams(0, timeLapseMs.toInt(), 0)
        return device.setTimelapseOption(functionMode.timelapseMode(), timelapseParam)
    }

}