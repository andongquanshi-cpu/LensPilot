package com.arashivision.sdk.camera.core.model.option

data class LocalTime(val timestamp: Long, val timeZone: Int)
