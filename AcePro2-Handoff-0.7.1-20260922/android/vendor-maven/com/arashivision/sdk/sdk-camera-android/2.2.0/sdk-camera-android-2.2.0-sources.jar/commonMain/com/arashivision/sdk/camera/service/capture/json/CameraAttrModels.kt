package com.arashivision.sdk.camera.service.capture.json

import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * 模块内统一使用的 Json 解析器：
 *  - ignoreUnknownKeys / isLenient / allowTrailingComma 可以兼容厂商扩展字段与宽松格式。
 */
internal val cameraJsonParser: Json = Json {
    ignoreUnknownKeys = true
    isLenient = true
//    allowTrailingComma = true
}

/**
 * 基本分数模型，主要用于快门速度（例如 1/125s）。
 */
data class Fraction(val numerator: Int, val denominator: Int) {
    init {
        require(denominator != 0) { "Denominator cannot be 0" }
    }

    override fun toString(): String = when {
        denominator == numerator -> "1"
        numerator == 1 -> "1/$denominator"
        else -> "${numerator}/${denominator}"
    }
}

/**
 * 将分数格式化为更友好的字符串，例如 1/125 或 1/1.5。
 */
internal fun Fraction.toDisplayString(): String = when {
    numerator == denominator -> "1"
    numerator == 1 -> "1/$denominator"
    else -> {
        val ratio = denominator.toDouble() / numerator.toDouble()
        val rounded = ratio.roundToInt()
        if (abs(ratio - rounded) < 1e-6) {
            "1/$rounded"
        } else {
            "1/${ratio.clean()}"
        }
    }
}

/**
 * 保留固定精度的小数，并移除末尾多余的 0/点。
 */
internal fun Double.clean(precision: Int = 2): String {
    val pow = 10.0.pow(precision)
    val rounded = (this * pow).roundToInt().toDouble() / pow
    val raw = rounded.toString()
    return if (raw.contains(".")) raw.trimEnd('0').trimEnd('.') else raw
}

/**
 * 支持将字符串（"1/125" 或 "1/1.6"）解析为 [Fraction]，失败时返回 null。
 */
internal fun String.toFractionOrNull(): Fraction? {
    if (isEmpty()) return null
    if (this == "1") return Fraction(1, 1)
    val value = removePrefix("1/")
    return if (value.contains(".")) {
        val integerPart = value.substringBefore(".")
        val decimalPart = value.substringAfter(".")
        val denominator = 10.0.pow(decimalPart.length).toInt()
        val numerator = (integerPart + decimalPart).toInt()
        val gcd = numerator.gcd(denominator)
        Fraction(numerator / gcd, denominator / gcd)
    } else {
        val denom = value.toIntOrNull()?.takeIf { it > 0 } ?: return null
        Fraction(1, denom)
    }
}

/**
 * 计算最大公约数，用于约分。
 */
internal fun Int.gcd(other: Int): Int {
    var a = abs(this)
    var b = abs(other)
    while (b != 0) {
        val temp = b
        b = a % b
        a = temp
    }
    return a
}

