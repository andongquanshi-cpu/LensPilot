package com.arashivision.sdk.camera.service.capture.param.ints

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.FunctionType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure

internal class IsoCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : IntCameraParam(CommonAttrKeys.EXPOSURE_ISO, managerProvider, deviceCoreProvider) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.getVideoExposure(functionMode)
        } else {
            device.getStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.map {
            it.iso
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.fetchVideoExposure(functionMode)
        } else {
            device.fetchStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.map {
            it.iso
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Int): Result<Unit> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.getVideoExposure(functionMode)
        } else {
            device.getStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.flatMap {
            val updated = Exposure(it.program, value, it.shutterSpeed)
            device.setStillExposure(functionMode, updated)
            device.setVideoExposure(functionMode, updated).thenMirrorVideoLiveIfNeeded(device, functionMode) {
                device.setVideoExposure(FunctionMode.VIDEO_LIVE, updated)
            }
        }
    }
}