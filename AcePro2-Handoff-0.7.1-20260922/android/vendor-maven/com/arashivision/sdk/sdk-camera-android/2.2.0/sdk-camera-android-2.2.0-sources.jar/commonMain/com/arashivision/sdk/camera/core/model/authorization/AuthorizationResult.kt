package com.arashivision.sdk.camera.core.model.authorization

enum class AuthorizationResult(val value: Int) {
    SUCCESS(0),
    REJECT(1),
    TIMEOUT(2),
    SYSTEM_BUSY(3);

    companion object {
        fun nativeOf(value: Int): AuthorizationResult =
            entries.firstOrNull { it.value == value } ?: SYSTEM_BUSY
    }
}
