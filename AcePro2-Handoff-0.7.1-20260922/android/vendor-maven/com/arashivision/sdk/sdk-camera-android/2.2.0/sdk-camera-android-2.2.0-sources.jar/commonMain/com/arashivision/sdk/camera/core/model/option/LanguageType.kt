package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class LanguageType(override val nativeValue: Int) : BaseEnum {
    EN(0),
    ZH(1),
    JA(2);

    companion object {
        fun nativeOf(nativeValue: Int?): LanguageType {
            return LanguageType.entries.firstOrNull { it.nativeValue == nativeValue } ?: EN
        }
    }
}