package com.arashivision.sdk.camera.service.preview

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

internal class PreviewStreamDispatcher<T>(
    scope: CoroutineScope,
    capacity: Int,
    private val onDispatch: suspend (T) -> Unit,
) {
    private val channel = Channel<T>(capacity = capacity)
    private var droppedCount = 0L
    private val worker: Job =
        scope.launch {
            for (item in channel) {
                onDispatch(item)
            }
        }

    fun tryDispatch(item: T): Boolean {
        val result = channel.trySend(item)
        if (!result.isSuccess) {
            droppedCount += 1
        }
        return result.isSuccess
    }

    fun droppedCount(): Long = droppedCount

    suspend fun close() {
        channel.close()
        worker.join()
    }
}
