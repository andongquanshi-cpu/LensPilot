package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.PhotoHdrType
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class PhotoHdrCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<PhotoHdrType>(CommonAttrKeys.HDR_PHOTO_MODE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): PhotoHdrType? = null

    override fun fromInt(value: Int): PhotoHdrType {
        return PhotoHdrType.nativeOf(value)
    }

    override fun fromName(name: String): PhotoHdrType {
        return PhotoHdrType.protoOf(name)
    }

    override fun toInt(data: PhotoHdrType): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PhotoHdrType> {
        return device.getPhotoHdrType(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PhotoHdrType> {
        return device.fetchPhotoHdrType(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: PhotoHdrType): Result<Unit> {
        return device.setPhotoHdrType(functionMode, value)
    }

}