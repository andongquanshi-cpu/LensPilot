package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.PhotoSize
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class PhotoSizeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<PhotoSize>(CommonAttrKeys.PHOTO_SIZE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): PhotoSize = PhotoSize.UNKNOWN

    override fun fromInt(value: Int): PhotoSize {
        return PhotoSize.nativeOf(value)
    }

    override fun fromName(name: String): PhotoSize {
        return PhotoSize.protoOf(name)
    }

    override fun toInt(data: PhotoSize): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PhotoSize> {
        return device.getPhotoSize(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PhotoSize> {
        return device.fetchPhotoSize(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: PhotoSize): Result<Unit> {
        return device.setPhotoSize(functionMode, value)
    }

}