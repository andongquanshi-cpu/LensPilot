package com.arashivision.sdk.camera.service.preview

import com.arashivision.onecamera.OneDriver
import com.arashivision.onedriver.bean.StreamData
import com.arashivision.onedriver.packet.StreamType
import com.arashivision.sdk.camera.api.CameraPreview
import com.arashivision.sdk.camera.api.param.listener.CameraPostureUpdate
import com.arashivision.sdk.camera.api.preview.CameraLiveListener
import com.arashivision.sdk.camera.api.preview.CameraLiveParams
import com.arashivision.sdk.camera.api.preview.CameraStreamListener
import com.arashivision.sdk.camera.api.preview.LiveMode
import com.arashivision.sdk.camera.api.preview.PreviewStreamFrame
import com.arashivision.sdk.camera.api.preview.PreviewStreamParamsUpdate
import com.arashivision.sdk.camera.api.preview.PreviewStreamType
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.FunctionType
import com.arashivision.sdk.camera.core.model.LiveType
import com.arashivision.sdk.camera.core.model.notify.CameraPosture
import com.arashivision.sdk.camera.core.model.option.VideoEncode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.platform.LiveStreamCallback
import com.arashivision.sdk.camera.service.CameraService
import com.arashivision.sdk.camera.support.resolveCaptureSupportConfig
import com.arashivision.sdk.camera.support.toCameraPreviewParams
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.exception.AlreadyReleasedException
import com.arashivision.sdk.common.kotlin.nowMs
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.common.type.KMPCameraPreviewPipeline
import com.arashivision.sdk.common.type.KMPContext
import insta360.messages.AACBSType
import insta360.messages.StartLiveStream
import insta360.messages.VideoResolution
import insta360.messages.WindowCropInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 相机预览流服务类
 *
 * 主要功能：
 * 1. 管理相机预览流的启动和停止
 * 2. 接收并处理相机发送的视频流数据分片
 * 3. 按时间戳聚合多个分片为完整帧
 * 4. 监控流质量（丢帧、乱序、时间间隔异常等）
 * 5. 将处理后的帧数据通过 Channel 发送给上层
 */
class CameraPreviewService(
    camera: DeviceCore,
    connectType: ConnectType,
    scope: CoroutineScope,
    isActive: () -> Boolean,
) : CameraService(camera, connectType, scope, isActive),
    CameraPreview {
    private var videoPacketCount = 0
    private var gyroPacketCount = 0
    private var audioPacketCount = 0
    private var otherPacketCount = 0
    private var warnedMissingGyro = false
    private var lastVideoCodecLogMs = 0L
    private var lastDetectedVideoCodec: StreamEncodeType? = null
    private var droppedFrameDispatchCount = 0L
    private var currentPreviewStatus: PreviewStatus = PreviewStatus.IDLE

    // ------------------- 相机姿态监听（接口命名沿用历史：registerBatteryListener） -------------------
    private val postureMutex = Mutex()
    private val postureListeners = LinkedHashSet<CameraPostureUpdate>()

    // 预览流状态监听
    private val streamMutex = Mutex()
    private val streamListeners = LinkedHashSet<CameraStreamListener>()

    // 直播推流状态监听
    private val liveMutex = Mutex()
    private val liveListeners = LinkedHashSet<CameraLiveListener>()

    init {
        scope.launch {
            camera.events.collect { event ->
                when (event) {
                    is DeviceEvent.LiveViewBeginRotateEvent -> {
                        val posture =
                            CameraPosture.nativeOf(event.cameraPostureUpdate.camera_posture.value)
                        val snapshot = postureMutex.withLock { postureListeners.toList() }
                        snapshot.forEach { it.updatePosture(posture) }
                    }

                    is DeviceEvent.LiveStreamEvent -> {
                        updatePreviewStatus(event.status, event.obj as? WindowCropInfo)
                    }

                    else -> {}
                }
            }
        }
    }

    private companion object {
        private const val TAG = "CameraPreviewService"
        private const val VIDEO_CODEC_LOG_INTERVAL_MS = 10_000L
        private const val STREAM_DISPATCH_CAPACITY = 128
        private const val STREAM_DISPATCH_DROP_LOG_INTERVAL = 60L
    }

    private val cameraStream: CameraStream = CameraStream(camera, connectType, scope, isActive)
    private val streamDispatcher =
        PreviewStreamDispatcher<PreviewStreamFrame>(
            scope = scope,
            capacity = STREAM_DISPATCH_CAPACITY,
        ) { frame ->
            val snapshot = streamMutex.withLock { streamListeners.toList() }
            snapshot.forEach { it.onStreamDataNotify(frame) }
        }

    private val streamListener =
        object : OneDriver.OnStreamListener {
            override fun onDriverStreamDataNotify(mData: StreamData) {
                val intervalFrame = 60
                when (mData.streamType) {
                    StreamType.VideoStream,
                    StreamType.VideoStreamL,
                    StreamType.VideoStreamR,
                    -> {
                        videoPacketCount += 1
                        if (videoPacketCount >= intervalFrame) {
                            Logger.i(
                                TAG,
                                "streamPacket video type=${mData.streamType} ts=${mData.timestamp} size=${mData.data.size}",
                            )
                            videoPacketCount = 0
                        }
                        if (!warnedMissingGyro && videoPacketCount >= 30 && gyroPacketCount == 0) {
                            warnedMissingGyro = true
                            Logger.w(TAG, "streamPacket missing gyro after $videoPacketCount video packets")
                        }
                        handleVideoCodec(mData)
                    }

                    StreamType.GyroStream -> {
                        gyroPacketCount += 1
                        if (gyroPacketCount >= intervalFrame) {
                            Logger.i(
                                TAG,
                                "streamPacket gyro ts=${mData.timestamp} size=${mData.data.size}",
                            )
                            gyroPacketCount = 0
                        }
                    }

                    StreamType.AudioStream -> {
                        audioPacketCount += 1
                        if (audioPacketCount >= intervalFrame) {
                            Logger.i(
                                TAG,
                                "streamPacket audio ts=${mData.timestamp} size=${mData.data.size}",
                            )
                            audioPacketCount = 0
                        }
                    }

                    else -> {
                        otherPacketCount += 1
                        if (otherPacketCount >= intervalFrame) {
                            Logger.i(
                                TAG,
                                "streamPacket other type=${mData.streamType} raw=${mData.streamType.value} " +
                                    "ts=${mData.timestamp} size=${mData.data.size}",
                            )
                            otherPacketCount = 0
                        }
                    }
                }
                cameraStream.processStreamData(mData.streamType.value, mData.data, mData.timestamp)
                val frame = mData.toPreviewStreamFrame()
                if (!streamDispatcher.tryDispatch(frame)) {
                    droppedFrameDispatchCount += 1
                    if (droppedFrameDispatchCount % STREAM_DISPATCH_DROP_LOG_INTERVAL == 0L) {
                        Logger.w(
                            TAG,
                            "streamDispatch backpressure dropped=$droppedFrameDispatchCount " +
                                "dispatcherDropped=${streamDispatcher.droppedCount()} capacity=$STREAM_DISPATCH_CAPACITY",
                        )
                    }
                }
            }
        }

    override fun init(context: KMPContext) {
        cameraStream.init(context)
    }

    /**
     * 启动预览流
     */
    override fun startStream() {
        videoPacketCount = 0
        gyroPacketCount = 0
        audioPacketCount = 0
        otherPacketCount = 0
        warnedMissingGyro = false
        lastVideoCodecLogMs = 0L
        lastDetectedVideoCodec = null
        droppedFrameDispatchCount = 0L
        val currentMode = camera.functionMode
        val isRecording = resolvePreviewRecordingState(currentMode, camera.isWorking(currentMode))
        val isForLive = currentMode == FunctionMode.VIDEO_LIVE
        val supportConfig = resolveCaptureSupportConfig(camera).getOrNull()
        val previewParams =
            supportConfig?.toCameraPreviewParams(isForLive = isForLive, isForRecord = isRecording, currentMode.functionType == FunctionType.VIDEO)
                ?: defaultPreviewParams()
        val startStreamingParam =
            getStreamParams(
                isForLive = isForLive,
                previewParams = previewParams,
            )
        supportConfig?.let {
            Logger.i(
                TAG,
                "startStreamSupport cameraType=${it.previewCameraType} gyroType=${it.previewGyroType} " +
                    "stabType=${it.previewStabType} stabilize=${it.isStabilizeEnabled} " +
                    "renderModel=${it.previewRenderModelType}",
            )
        }

        val offset: String = camera.getMediaOffset().getOrDefault("")

        Logger.i(
            TAG,
            "startStream mode=$currentMode isForLive=$isForLive isRecording=$isRecording " +
                "preview=${previewParams.firstStream.width}x${previewParams.firstStream.height}@${previewParams.firstStream.fps}" +
                "/${previewParams.secondStream.width}x${previewParams.secondStream.height}@${previewParams.secondStream.fps} " +
                "previewNum=${previewParams.previewNum} startRes=${startStreamingParam.resolution} startRes2=${startStreamingParam.resolution1} " +
                "bitrate=${startStreamingParam.videoBitrate}/${startStreamingParam.videoBitrate1} " +
                "gyro=${startStreamingParam.enableGyro} audio=${startStreamingParam.enableAudio} " +
                "offsetLen=${offset.length} ",
        )

        cameraStream.openStream(previewParams, isForLive, offset)
        syncStreamEncodeWithCameraSetting()
        camera.openPreviewStream(startStreamingParam, offset)
        updatePreviewStatus(PreviewStatus.OPENING)
    }

    /**
     * 停止预览流
     *
     * 步骤：
     * 1. 输出最后一帧的聚合统计信息
     * 2. 关闭预览流
     */
    override fun stopStream() {
        // 步骤2：关闭预览流
        camera.closePreviewStream()

        cameraStream.closeStream()

        updatePreviewStatus(PreviewStatus.STOPPING)
    }

    override fun requestStreamIframe() {
        camera.requestStreamIframe()
    }

    override fun getPreviewParams(): Result<PreviewParams> {
        if (isDestroyed()) {
            return Result.failure(AlreadyReleasedException())
        }
        val currentMode = camera.functionMode
        val isRecording = resolvePreviewRecordingState(currentMode, camera.isWorking(currentMode))
        val isForLive = currentMode == FunctionMode.VIDEO_LIVE
        return resolveCaptureSupportConfig(camera).map {
            it.toCameraPreviewParams(isForLive = isForLive, isForRecord = isRecording, isVideo = currentMode.functionType == FunctionType.VIDEO)
        }
    }

    override fun getCurrentFunctionMode(): Result<FunctionMode> {
        if (isDestroyed()) {
            return Result.failure(AlreadyReleasedException())
        }
        return Result.success(camera.functionMode)
    }

    internal fun getCurrentPreviewStatus(): PreviewStatus = currentPreviewStatus

    @Deprecated("Use registerPostureListener instead")
    override fun registerBatteryListener(listener: CameraPostureUpdate) {
        registerPostureListener(listener)
    }

    override fun registerPostureListener(listener: CameraPostureUpdate) {
        if (isDestroyed()) return
        scope.launch {
            postureMutex.withLock { postureListeners.add(listener) }
        }
    }

    @Deprecated("Use unregisterPostureListener instead")
    override fun unregisterBatteryListener(listener: CameraPostureUpdate) {
        unregisterPostureListener(listener)
    }

    override fun unregisterPostureListener(listener: CameraPostureUpdate) {
        if (isDestroyed()) return
        scope.launch {
            postureMutex.withLock { postureListeners.remove(listener) }
        }
    }

    override fun setStreamEncode(isH265: Boolean) {
        camera.setStreamListener(streamListener)
        cameraStream.setStreamEncode(isH265)
    }

    private fun syncStreamEncodeWithCameraSetting() {
        camera.setStreamListener(streamListener)
        camera
            .getVideoEncodeType()
            .onSuccess { videoEncode ->
                val isH265 = videoEncode == VideoEncode.ENCODE_H265
                cameraStream.setStreamEncode(isH265)
                Logger.i(TAG, "syncStreamEncode videoEncode=$videoEncode isH265=$isH265")
            }.onFailure {
                Logger.w(TAG, "syncStreamEncode skipped: getVideoEncodeType failed: ${it.message}")
            }
    }

    override fun setPipeline(pipeline: KMPCameraPreviewPipeline?) {
        cameraStream.setPipeline(pipeline)
    }

    override fun registerCameraStreamListener(listener: CameraStreamListener) {
        if (isDestroyed()) return
        scope.launch {
            streamMutex.withLock {
                streamListeners.add(listener)
            }
        }
    }

    override fun unregisterCameraStreamListener(listener: CameraStreamListener) {
        if (isDestroyed()) return
        scope.launch {
            streamMutex.withLock {
                streamListeners.remove(listener)
            }
        }
    }

    /**
     * 获取相机预览流参数配置
     *
     * 配置说明：
     * - 开启视频和陀螺仪，供播放器完成实时预览和防抖
     * - 使用设备配置提供的预览分辨率和码率
     * - 设置流来源：根据连接类型（USB/WIFI/BLE）设置
     */
    fun getStreamParams(
        isForLive: Boolean,
        previewParams: PreviewParams,
    ): StartLiveStream {
        val param = StartLiveStream()

        param.enableGyro = true
        if (isForLive) {
            param.enableAudio = true
            param.audioBitrate = 128000
            param.audioSampleRate = 48000
        } else {
            param.enableAudio = false
        }
        param.audioType = if (isForLive) AACBSType.ADTS else AACBSType.RAW
        param.enableVideo = true
        param.videoBitrate = previewParams.firstStream.bitrate
        param.videoBitrate1 = previewParams.secondStream.bitrate
        param.resolution = VideoResolution.fromValue(previewParams.firstStream.valueInCamera)
            ?: VideoResolution.RES_1280_960P30
        param.resolution1 = VideoResolution.fromValue(previewParams.secondStream.valueInCamera)
            ?: VideoResolution.RES_424_240P15
        param.previewStreamNum = previewParams.previewNum
        param.isForLive = isForLive

        // 告知预览流来源（有些机型/固件可能依赖该字段决定通道）
        param.source =
            when (connectType) {
                ConnectType.USB -> StartLiveStream.startLiveViewSource.Start_LiveViewSource_USB
                ConnectType.WIFI, ConnectType.WIFI_AWARE -> StartLiveStream.startLiveViewSource.Start_LiveViewSource_WIFI
                ConnectType.BLE -> StartLiveStream.startLiveViewSource.Start_LiveViewSource_BT
            }

        return param
    }

    private fun isVideoStream(type: StreamType): Boolean =
        type == StreamType.VideoStream || type == StreamType.VideoStreamL || type == StreamType.VideoStreamR

    private fun handleVideoCodec(mData: StreamData) {
        PreviewCodecDetector.detectVideoCodec(mData.data)?.let { detectedCodec ->
            lastDetectedVideoCodec = detectedCodec
            correctStreamEncodeIfNeeded(detectedCodec, mData)
        }

        val now = nowMs()
        if (now - lastVideoCodecLogMs < VIDEO_CODEC_LOG_INTERVAL_MS) return
        lastVideoCodecLogMs = now

        val detectedCodec = lastDetectedVideoCodec?.name ?: "UNKNOWN"
        Logger.i(
            TAG,
            "streamPacket video codec=$detectedCodec configured=${cameraStream.getStreamEncodeType()} " +
                "type=${mData.streamType} ts=${mData.timestamp} size=${mData.data.size}",
        )
    }

    private fun correctStreamEncodeIfNeeded(
        detectedCodec: StreamEncodeType,
        mData: StreamData,
    ) {
        val configuredCodec = cameraStream.getStreamEncodeType()
        if (configuredCodec == detectedCodec) return

        cameraStream.setStreamEncode(detectedCodec == StreamEncodeType.H265)
        Logger.w(
            TAG,
            "streamPacket codec mismatch corrected configured=$configuredCodec detected=$detectedCodec " +
                "newConfigured=${cameraStream.getStreamEncodeType()} type=${mData.streamType} " +
                "ts=${mData.timestamp} size=${mData.data.size}",
        )
    }

    private fun StreamData.toPreviewStreamFrame(): PreviewStreamFrame =
        PreviewStreamFrame(
            data = data,
            timestamp = timestamp,
            type = typeToPublicType(streamType),
        )

    private fun typeToPublicType(type: StreamType): PreviewStreamType =
        when (type) {
            StreamType.VideoStream -> PreviewStreamType.VIDEO
            StreamType.VideoStreamL -> PreviewStreamType.VIDEO_L
            StreamType.VideoStreamR -> PreviewStreamType.VIDEO_R
            StreamType.AudioStream -> PreviewStreamType.AUDIO
            StreamType.GyroStream -> PreviewStreamType.GYRO
            StreamType.Unknown -> PreviewStreamType.UNKNOWN
            else -> PreviewStreamType.OTHER
        }

    override suspend fun destroy() {
        cameraStream.stopLive()
        stopStream()
        streamDispatcher.close()
    }

    override suspend fun startLive(params: CameraLiveParams): Result<Unit> {
        val error = validateLivePrerequisites()
        if (error != null) return Result.failure(error)
        val mode = params.mode ?: resolveDefaultLiveMode()
        val liveType = mode.toLiveType()
        cameraStream.startLive(params, liveType, buildLiveStreamCallback())
        Logger.i(TAG, "startLive accepted rtmp=${params.rtmpUrl.substringBefore("?")} mode=$mode")
        return Result.success(Unit)
    }

    override fun startLive(params: CameraLiveParams, callback: Callback<Unit>) {
        val error = validateLivePrerequisites()
        if (error != null) {
            callback.onThrowable(error)
            return
        }
        val mode = params.mode ?: resolveDefaultLiveMode()
        val liveType = mode.toLiveType()
        cameraStream.startLive(params, liveType, buildLiveStreamCallback())
        Logger.i(TAG, "startLive(callback) accepted rtmp=${params.rtmpUrl.substringBefore("?")} mode=$mode")
        callback.onSuccess(Unit)
    }

    override suspend fun stopLive(): Result<Unit> {
        cameraStream.stopLive()
        return Result.success(Unit)
    }

    override fun stopLive(callback: Callback<Unit>) {
        cameraStream.stopLive()
        callback.onSuccess(Unit)
    }

    override fun registerCameraLiveListener(listener: CameraLiveListener) {
        if (isDestroyed()) return
        scope.launch { liveMutex.withLock { liveListeners.add(listener) } }
    }

    override fun unregisterCameraLiveListener(listener: CameraLiveListener) {
        if (isDestroyed()) return
        scope.launch { liveMutex.withLock { liveListeners.remove(listener) } }
    }

    private fun validateLivePrerequisites(): Exception? {
        if (isDestroyed()) return AlreadyReleasedException()
        val liveModeFunctionModes = setOf(FunctionMode.VIDEO_LIVE, FunctionMode.VIDEO_CAMERA_LIVE)
        if (camera.functionMode !in liveModeFunctionModes) {
            return IllegalStateException("functionMode 必须为直播子模式，当前：${camera.functionMode}")
        }
        if (currentPreviewStatus != PreviewStatus.OPENED && currentPreviewStatus != PreviewStatus.PARAMS_CHANGED) {
            return IllegalStateException("预览流未就绪（当前状态：$currentPreviewStatus），请先调用 startStream()")
        }
        return null
    }

    /** 依据当前 mediaOffset 前缀判定镜头状态：双镜头（"2_" 前缀）取全景拼接，单镜头/广角取全景原始。 */
    private fun resolveDefaultLiveMode(): LiveMode {
        val offset = camera.getMediaOffsetV6().getOrElse { "" }
            .ifEmpty { camera.getMediaOffsetV3().getOrElse { "" } }
            .ifEmpty { camera.getMediaOffset().getOrElse { "" } }
        return if (offset.startsWith("2_")) LiveMode.PANO_STITCH else LiveMode.PANO_CAPTURE
    }

    private fun LiveMode.toLiveType(): LiveType =
        when (this) {
            LiveMode.PANO_STITCH -> LiveType.PANO_STITCH
            LiveMode.PANO_CAPTURE -> LiveType.PANO_CAPTURE
            LiveMode.PLANE -> LiveType.PLANE
        }

    private fun buildLiveStreamCallback(): LiveStreamCallback = object : LiveStreamCallback {
        override fun onStarted() {
            scope.launch {
                val snapshot = liveMutex.withLock { liveListeners.toList() }
                snapshot.forEach { it.onStarted() }
            }
        }

        override fun onFps(fps: Int) {
            scope.launch {
                val snapshot = liveMutex.withLock { liveListeners.toList() }
                snapshot.forEach { it.onFps(fps) }
            }
        }

        override fun onStopped() {
            scope.launch {
                val snapshot = liveMutex.withLock { liveListeners.toList() }
                snapshot.forEach { it.onStopped() }
            }
        }

        override fun onFailed(errorCode: Int, message: String?) {
            scope.launch {
                val snapshot = liveMutex.withLock { liveListeners.toList() }
                snapshot.forEach { it.onFailed(errorCode, message) }
            }
        }
    }

    override fun getVideoBitrate(): Result<Int> = camera.getVideoBitrate()

    override suspend fun setVideoBitrate(bitrate: Int): Result<Unit> = camera.setVideoBitrate(bitrate)

    override suspend fun fetchVideoBitrate(): Result<Int> = camera.fetchVideoBitrate()

    private fun updatePreviewStatus(
        previewStatus: PreviewStatus,
        windowCropInfo: WindowCropInfo? = null,
    ) {
        if (previewStatus == currentPreviewStatus) {
            Logger.i(TAG, "updatePreviewStatus ignored duplicated status=$previewStatus")
            return
        }
        if (!isValidPreviewStatusTransition(currentPreviewStatus, previewStatus)) {
            Logger.w(
                TAG,
                "updatePreviewStatus ignored invalid transition current=$currentPreviewStatus next=$previewStatus",
            )
            return
        }
        val previousStatus = currentPreviewStatus
        currentPreviewStatus = previewStatus
        cameraStream.updatePreviewStatus(previewStatus)
        val paramsUpdate =
            if (previewStatus == PreviewStatus.PARAMS_CHANGED) {
                resolvePreviewParamsUpdate(windowCropInfo)
            } else {
                null
            }
        if (previewStatus != PreviewStatus.PARAMS_CHANGED) {
            Logger.i(TAG, "updatePreviewStatus status=$previousStatus->$previewStatus")
        }
        scope.launch {
            val snapshot = streamMutex.withLock { streamListeners.toList() }
            snapshot.forEach {
                when (previewStatus) {
                    PreviewStatus.OPENED -> it.onOpened()
                    PreviewStatus.IDLE -> it.onIdle()
                    PreviewStatus.OPENING -> it.onOpening()
                    PreviewStatus.STOPPING -> {}
                    PreviewStatus.PARAMS_CHANGED -> paramsUpdate?.let(it::onParamsChanged)
                }
            }
        }
    }

    private fun resolvePreviewParamsUpdate(windowCropInfo: WindowCropInfo?): PreviewStreamParamsUpdate {
        val currentMode = camera.functionMode
        val isRecording = resolvePreviewRecordingState(currentMode, camera.isWorking(currentMode))
        val isForLive = currentMode == FunctionMode.VIDEO_LIVE
        val supportConfig = resolveCaptureSupportConfig(camera).getOrNull()
        val previewParams =
            supportConfig
                ?.toCameraPreviewParams(isForLive = isForLive, isForRecord = isRecording, currentMode.functionType == FunctionType.VIDEO)
                ?: defaultPreviewParams()
        val selectedStream = selectPreviewStream(previewParams)
        return PreviewStreamParamsUpdate(
            windowCropInfo = windowCropInfo,
            offsetData = supportConfig?.mediaOffset,
            stabOffset = supportConfig?.stabOffset,
            previewWidth = selectedStream.width,
            previewHeight = selectedStream.height,
            previewFps = selectedStream.fps,
        )
    }
}

internal fun defaultPreviewParams(): PreviewParams =
    PreviewParams(
        firstStream = StreamResolution.STREAM_1280_960_30FPS,
        secondStream = StreamResolution.STREAM_424_240_15FPS,
        previewNum = 0,
    )

internal fun resolvePreviewRecordingState(
    mode: FunctionMode,
    isWorking: Boolean,
): Boolean = isWorking && mode.functionType == FunctionType.VIDEO && mode != FunctionMode.VIDEO_LIVE

internal fun selectPreviewStream(previewParams: PreviewParams): StreamResolution =
    if (previewParams.previewNum == 0) previewParams.firstStream else previewParams.secondStream

internal fun isValidPreviewStatusTransition(
    current: PreviewStatus,
    next: PreviewStatus,
): Boolean =
    when (next) {
        PreviewStatus.IDLE ->
            current == PreviewStatus.STOPPING || current == PreviewStatus.OPENED
        PreviewStatus.OPENING ->
            current == PreviewStatus.IDLE || current == PreviewStatus.STOPPING
        PreviewStatus.OPENED ->
            current == PreviewStatus.OPENING || current == PreviewStatus.PARAMS_CHANGED
        PreviewStatus.STOPPING ->
            current == PreviewStatus.OPENING ||
            current == PreviewStatus.OPENED ||
            current == PreviewStatus.PARAMS_CHANGED
        PreviewStatus.PARAMS_CHANGED ->
            current == PreviewStatus.OPENED || current == PreviewStatus.PARAMS_CHANGED
    }
