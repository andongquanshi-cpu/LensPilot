package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class LivingPlatform(override val nativeValue: Int, val protoName: String) : BaseEnum {
    DEFAULT(0, "default"),
    FACEBOOK(1, "FACEBOOK"),
    WECHAT(2, "WECHAT"),
    YOUTUBE(6, "YOUTUBE"),
    KUAISHOU(11, "KUAISHOU"),
    DOUYIN(12, "DOUYIN");

    companion object {
        fun nativeOf(value: Int?): LivingPlatform = entries.firstOrNull { it.nativeValue == value } ?: DEFAULT
        fun protoOf(name: String?): LivingPlatform = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: DEFAULT
    }
}