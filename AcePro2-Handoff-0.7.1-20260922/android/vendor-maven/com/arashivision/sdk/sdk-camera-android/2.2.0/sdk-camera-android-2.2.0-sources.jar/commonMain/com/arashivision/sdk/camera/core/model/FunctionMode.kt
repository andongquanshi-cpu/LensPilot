package com.arashivision.sdk.camera.core.model

import com.arashivision.sdk.camera.core.model.FunctionMode.Companion.photoSubOf
import com.arashivision.sdk.camera.core.model.FunctionMode.Companion.videoSubOf
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.AEB_NIGHT_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.BULLET_TIME_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.BURST_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.DASH_CAM
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.FPV_RECORDING_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.HDR_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.HDR_POWER_PANO_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.HDR_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.INTERVAL_SHOOTING_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.LOOP_RECORDING_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.MOSQUITO_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.MOVIE_RECORDING_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.NORMAL_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.NOT_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.PURE_RECORDING_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.SELFIE_RECORDING_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.SINGLE_POWER_PANO_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.SINGLE_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.SLOW_MOTION_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.STARLAPSE_SHOOTING
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.SUPER_NORMAL_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.TIMELAPSE_CAPTURE
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus.Status.TIMESHIFT_CAPTURE
import com.arashivision.sdk.camera.core.model.option.PhotoSubMode
import com.arashivision.sdk.camera.core.model.option.VideoSubMode
import insta360.messages.TimelapseMode

enum class FunctionMode(
    override val nativeValue: Int,
    val subModeValue: Int,
    val functionType: FunctionType = FunctionType.NONE,
    val controlMode: ControlMode = ControlMode.MANUAL_NONE
) : BaseEnum {
    NONE(-1, 100),
    PHOTO_NORMAL(6, 0, FunctionType.PHOTO, ControlMode.MANUAL_START_AUTO_STOP),
    PHOTO_HDR(8, 1, FunctionType.PHOTO, ControlMode.MANUAL_START_AUTO_STOP),
    PHOTO_BURST(5, 3, FunctionType.PHOTO, ControlMode.MANUAL_START_AUTO_STOP),
    PHOTO_INTERVAL(3, 2, FunctionType.PHOTO, ControlMode.MANUAL_START_STOP_COUNT),
    PHOTO_NIGHT(13, 4, FunctionType.PHOTO, ControlMode.MANUAL_START_AUTO_STOP),
    PHOTO_PANO(14, 5, FunctionType.PHOTO, ControlMode.MANUAL_START_AUTO_STOP),
    PHOTO_PANO_HDR(15, 6, FunctionType.PHOTO, ControlMode.MANUAL_START_AUTO_STOP),
    PHOTO_STARLAPSE(18, 7, FunctionType.PHOTO, ControlMode.MANUAL_START_STOP_COUNT),
    VIDEO_NORMAL(7, 0, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_BULLET_TIME(4, 1, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_TIMELAPSE(2, 2, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_HDR(9, 3, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_TIMESHIFT(12, 4, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_SUPER(16, 5, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_LOOP_RECORDING(17, 6, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_FPV(19, 7, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_MOVIE(20, 8, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_SLOW_MOTION(21, 9, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_SELFIE(22, 10, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_PURE(27, 11, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_LIVE(1, 12, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_CAMERA_LIVE(54, 13, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_DASHCAM(63, 14, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED),
    VIDEO_MOSQUITO(65, 16, FunctionType.VIDEO, ControlMode.MANUAL_START_STOP_TIMED);

    companion object {

        /**
         * SDK 当前未实现的拍摄模式：对外的支持列表应过滤掉这些模式，
         * 新增/实现某个模式时，从此集合移除即可同步对外列表。
         */
        val UNSUPPORTED_CAPTURE_MODES: Set<FunctionMode> = setOf(
            PHOTO_NIGHT, PHOTO_PANO, PHOTO_PANO_HDR,
            VIDEO_BULLET_TIME, VIDEO_HDR, VIDEO_FPV,
            VIDEO_MOVIE, VIDEO_SELFIE, VIDEO_LIVE, VIDEO_CAMERA_LIVE, VIDEO_DASHCAM,
        )

        fun nativeOf(code: Int?): FunctionMode {
            return entries.find { it.nativeValue == code } ?: NONE
        }

        fun photoSubOf(code: Int?): FunctionMode {
            return entries.filter { it.functionType == FunctionType.PHOTO }.find { it.subModeValue == code } ?: NONE
        }

        fun videoSubOf(code: Int?): FunctionMode {
            return entries.filter { it.functionType == FunctionType.VIDEO }.find { it.subModeValue == code } ?: NONE
        }

        /**
         * 根据 option 缓存中的照片 / 视频子模式推断当前 [FunctionMode]：视频分支优先；
         * [photoSubOf] / [videoSubOf] 若得到 [NONE] 则忽略该分支，继续尝试另一端。
         */
        fun fromCachedPhotoVideoSubModes(
            photo: PhotoSubMode?,
            video: VideoSubMode?,
        ): FunctionMode {
            val fromVideo =
                video
                    ?.takeIf { it != VideoSubMode.NONE }
                    ?.nativeValue
                    ?.let { videoSubOf(it) }
                    ?.takeIf { it != NONE }
            if (fromVideo != null) {
                return fromVideo
            }
            val fromPhoto =
                photo
                    ?.takeIf { it != PhotoSubMode.NONE }
                    ?.nativeValue
                    ?.let { photoSubOf(it) }
                    ?.takeIf { it != NONE }
            return fromPhoto ?: NONE
        }

        fun timelapseMode(functionMode: FunctionMode): Int {
            return when (functionMode) {
                VIDEO_TIMELAPSE -> TimelapseMode.MOBILE_TIMELAPSE_VIDEO.value
                PHOTO_INTERVAL -> TimelapseMode.TIMELAPSE_INTERVAL_SHOOTING.value
                PHOTO_STARLAPSE -> TimelapseMode.TIMELAPSE_STARLAPSE_SHOOTING.value
                else -> -1
            }
        }
    }

    fun timelapseMode(): Int {
        return timelapseMode(this)
    }

    fun toCaptureStatus(): CameraCaptureStatus.Status {
        return when (this) {
            VIDEO_NORMAL -> NORMAL_CAPTURE
            VIDEO_TIMELAPSE -> TIMELAPSE_CAPTURE
            PHOTO_INTERVAL -> INTERVAL_SHOOTING_CAPTURE
            PHOTO_NORMAL -> SINGLE_SHOOTING
            PHOTO_HDR -> HDR_SHOOTING
            VIDEO_BULLET_TIME -> BULLET_TIME_CAPTURE
            VIDEO_HDR -> HDR_CAPTURE
            PHOTO_BURST -> BURST_SHOOTING
            VIDEO_TIMESHIFT -> TIMESHIFT_CAPTURE
            PHOTO_NIGHT -> AEB_NIGHT_SHOOTING
            PHOTO_PANO -> SINGLE_POWER_PANO_SHOOTING
            PHOTO_PANO_HDR -> HDR_POWER_PANO_SHOOTING
            VIDEO_SUPER -> SUPER_NORMAL_CAPTURE
            VIDEO_LOOP_RECORDING -> LOOP_RECORDING_CAPTURE
            PHOTO_STARLAPSE -> STARLAPSE_SHOOTING
            VIDEO_FPV -> FPV_RECORDING_CAPTURE
            VIDEO_MOVIE -> MOVIE_RECORDING_CAPTURE
            VIDEO_SLOW_MOTION -> SLOW_MOTION_CAPTURE
            VIDEO_SELFIE -> SELFIE_RECORDING_CAPTURE
            VIDEO_PURE -> PURE_RECORDING_CAPTURE
            VIDEO_DASHCAM -> DASH_CAM
            VIDEO_MOSQUITO -> MOSQUITO_SHOOTING
            else -> NOT_CAPTURE
        }
    }

    /** 该模式是否被 SDK 支持（对外列表过滤依据）。 */
    val isCaptureSupported: Boolean
        get() = this != NONE && this !in UNSUPPORTED_CAPTURE_MODES
}

enum class FunctionType {
    NONE,
    VIDEO,
    PHOTO
}

enum class ControlMode {
    MANUAL_NONE,

    /**
     * 开始和结束都需要触发，中间以时间测量
     */
    MANUAL_START_STOP_TIMED,

    /**
     * 开始和结束都需要触发，中间以数量测量
     */
    MANUAL_START_STOP_COUNT,

    /**
     * 开始需要触发，自动结束
     */
    MANUAL_START_AUTO_STOP
}

enum class MeasureType {
    NONE,
    TIMED,
    COUNT
}