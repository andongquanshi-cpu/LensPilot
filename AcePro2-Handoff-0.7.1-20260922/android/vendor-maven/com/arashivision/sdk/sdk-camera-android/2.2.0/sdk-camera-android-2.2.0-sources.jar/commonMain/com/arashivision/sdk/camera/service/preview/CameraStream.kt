package com.arashivision.sdk.camera.service.preview

import com.arashivision.sdk.camera.api.preview.CameraLiveParams
import com.arashivision.sdk.camera.core.model.LiveType
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.platform.LiveStreamCallback
import com.arashivision.sdk.camera.platform.PlatformCameraStream
import com.arashivision.sdk.camera.service.CameraService
import com.arashivision.sdk.common.type.KMPCameraPreviewPipeline
import com.arashivision.sdk.common.type.KMPContext
import kotlinx.coroutines.CoroutineScope

class CameraStream(
    camera: DeviceCore,
    connectType: ConnectType,
    scope: CoroutineScope,
    isActive: () -> Boolean,
) : CameraService(camera, connectType, scope, isActive) {
    private companion object Companion {
        private const val TAG = "CameraStreamImpl"
    }

    val platformCameraStream: PlatformCameraStream = PlatformCameraStream()
    private var previewStatus: PreviewStatus = PreviewStatus.IDLE

    fun init(context: KMPContext) {
        platformCameraStream.init(context)
    }

    fun openStream(
        previewParams: PreviewParams,
        isForLive: Boolean,
        offset: String,
    ) {
//        if (camera.isWorking(FunctionMode.PHOTO_INTERVAL) || camera.isWorking(FunctionMode.PHOTO_STARLAPSE)) {
//            Logger.i(TAG, "间隔拍摄和星空延时拍摄不支持预览")
//            return
//        }

        val isDualStream =
            camera.getCameraConfig().getOrNull()?.isDualStream(
                RecordResolution.of(
                    previewParams.firstStream.width,
                    previewParams.firstStream.height,
                    previewParams.firstStream.fps,
                ),
            ) ?: false

        platformCameraStream.openPreviewStream(
            isForLive = isForLive,
            previewParams,
            isDualStream,
            mediaOffset = offset,
        )
    }

    fun closeStream() {
        platformCameraStream.closePreviewStream()
    }

    fun getPreviewStatus(): Int {
        return previewStatus.ordinal
    }

    fun updatePreviewStatus(status: PreviewStatus) {
        previewStatus = status
    }

    fun setStreamEncode(isH265: Boolean) {
        platformCameraStream.setH265Encode(isH265)
    }

    fun getStreamEncodeType(): StreamEncodeType {
        platformCameraStream
            .isH265Encode()
            .let { return if (it) StreamEncodeType.H265 else StreamEncodeType.H264 }
    }

    fun processStreamData(
        type: Int,
        data: ByteArray,
        timestamp: Long,
    ) {
        platformCameraStream.processStreamData(type, data, timestamp)
    }

    fun setPipeline(pipeline: KMPCameraPreviewPipeline?) {
        platformCameraStream.setPipeline(pipeline)
    }

    internal fun startLive(
        params: CameraLiveParams,
        liveType: LiveType,
        callback: LiveStreamCallback,
    ) {
        platformCameraStream.startLive(
            rtmpUrl = params.rtmpUrl,
            width = params.width,
            height = params.height,
            fps = params.fps,
            bitrate = params.bitrate,
            netId = params.netId,
            liveType = liveType,
            callback = callback,
        )
    }

    fun stopLive() {
        platformCameraStream.stopLive()
    }

    override suspend fun destroy() {
        closeStream()
    }
}
