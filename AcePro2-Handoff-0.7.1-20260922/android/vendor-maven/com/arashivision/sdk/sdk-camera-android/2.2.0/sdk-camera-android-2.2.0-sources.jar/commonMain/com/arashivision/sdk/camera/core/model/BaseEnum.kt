package com.arashivision.sdk.camera.core.model

interface BaseEnum {
    val nativeValue: Int
}