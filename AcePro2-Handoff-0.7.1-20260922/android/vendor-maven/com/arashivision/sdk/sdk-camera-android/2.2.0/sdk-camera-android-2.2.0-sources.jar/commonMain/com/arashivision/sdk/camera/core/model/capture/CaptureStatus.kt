package com.arashivision.sdk.camera.core.model.capture

enum class CaptureStatus {
    IDLE, STARTING, WORKING, STOPPING;
}