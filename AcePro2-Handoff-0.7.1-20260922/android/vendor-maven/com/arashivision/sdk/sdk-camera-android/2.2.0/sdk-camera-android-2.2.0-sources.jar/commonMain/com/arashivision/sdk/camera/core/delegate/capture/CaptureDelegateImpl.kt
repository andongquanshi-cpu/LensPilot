package com.arashivision.sdk.camera.core.delegate.capture

import com.arashivision.onecamera.OneDriverInfo
import com.arashivision.onedriver.bean.OpState
import com.arashivision.sdk.camera.core.DeviceContext
import com.arashivision.sdk.camera.core.delegate.BaseDelegate
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ControlMode
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.FunctionType
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus
import com.arashivision.sdk.camera.core.model.capture.CaptureStatus
import com.arashivision.sdk.camera.core.model.option.PhotoSubMode
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.VideoSubMode
import com.arashivision.sdk.camera.core.model.photography.RawType
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.callback.callback
import com.arashivision.sdk.common.exception.CameraCaptureException
import com.arashivision.sdk.common.exception.CheckBatteryDataException
import com.arashivision.sdk.common.exception.CheckStorageDataException
import com.arashivision.sdk.common.exception.INSTA_OK
import com.arashivision.sdk.common.exception.InstaException
import com.arashivision.sdk.common.exception.LowBatteryException
import com.arashivision.sdk.common.exception.SDCardUnavailableException
import com.arashivision.sdk.common.exception.SwitchFunctionModeException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import insta360.messages.CaptureMode
import insta360.messages.CtrlPreRecord
import insta360.messages.CtrlPreRecord.CtrlOperate
import insta360.messages.ExtraMetadata
import insta360.messages.NotificationCaptureStopped
import insta360.messages.RawCaptureType
import insta360.messages.SensorDevice
import insta360.messages.SensorDevice.SENSOR_DEVICE_ALL
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.TakePicture
import insta360.messages.TakePictureResponse
import insta360.messages.TimelapseMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

/**
 * 相机拍摄结束通知（NOT_CAPTURE）是否应当为该拍摄模式收口。
 *
 * 前提：录像、延时摄影、间隔拍照、星空延时的原生事件分支（RecordVideoEvent/TimelapseEvent）
 * 只在 App 主动调用 stop* 命令得到应答时才会触发（已核实 minicamera 的 handleActionResponse——
 * 相机端自行结束拍摄，如机身按键停止、拍够张数、达到时长上限自动停止，都不会走这些回调，唯一能
 * 收到的只有结束通知）。因此对这四类拍摄，收口权归事件分支这条规则只在本轮拍摄确实是 App 主动
 * 触发（isCurrentCaptureStartedByApi）时才成立；若本轮是相机端自行触发/结束，结束通知是唯一的
 * 收口信号来源，必须无条件收口，否则会彻底漏发——比路径为空更严重。
 *
 * 拍照（普通/HDR/夜景/连拍/全景等，不含间隔拍照与星空延时）不受 isCurrentCaptureStartedByApi
 * 影响：收口权只按 AIPL 开关分流（见下），机身物理快门触发的拍照同样先由本仓的拍照结果事件
 * （StillImageEvent）直接收口，已单独验证过、不依赖本轮是否由 App 触发这一维度。
 *
 * 本轮由 App 主动触发（或拍摄类型为拍照，不含间隔拍照/星空延时）时：
 * - 录像、延时摄影、间隔拍照、星空延时：原生事件分支已经在收口，且路径就在事件对象上；结束
 *   通知若也无条件收口，会抢在事件分支之前把状态置为空闲，导致随后到达的真实路径事件被
 *   onCaptureFinish 的空闲短路挡掉。因此收口权归事件分支，结束通知需跳过。
 * - 拍照仅 AIPL 两段式应答机型（supportAiplPhotoCapture）由结束通知收口——这类机型的拍照结果
 *   事件分两次到达，路径要等第二次结果才有，天然需要跨事件协调，只能靠结束通知统一收口。其余
 *   拍照机型（非 AIPL）一次结果即带路径，与录像/延时同理，收口权归事件分支（StillImageEvent），
 *   不再等待结束通知。
 *
 * 无正在进行的拍摄（NONE）仍由结束通知收口——保守收口以免漏发。
 */
internal fun shouldNotCaptureNotifyFinish(
    functionMode: FunctionMode,
    isAiplPhotoCapture: Boolean,
    isCurrentCaptureStartedByApi: Boolean,
): Boolean {
    if (functionMode == FunctionMode.NONE) return true
    val followsEventBranchOwnership = functionMode.functionType == FunctionType.VIDEO ||
        functionMode == FunctionMode.PHOTO_INTERVAL ||
        functionMode == FunctionMode.PHOTO_STARLAPSE
    if (followsEventBranchOwnership && !isCurrentCaptureStartedByApi) return true
    return when (functionMode) {
        FunctionMode.PHOTO_INTERVAL, FunctionMode.PHOTO_STARLAPSE -> false
        else -> when (functionMode.functionType) {
            FunctionType.VIDEO -> false
            FunctionType.PHOTO -> isAiplPhotoCapture
            FunctionType.NONE -> true
        }
    }
}

/** 从录像事件中提取成片路径。仅应在事件已确认为完成态（COMPLETE/CANCELED/FAILED）时调用。 */
internal fun resolveRecordVideoFilePaths(event: TransportEvent.RecordVideoEvent): List<String> {
    return listOfNotNull(event.video?.uri?.takeIf { it.isNotEmpty() })
}

/** 从延时摄影事件中提取成片路径。仅应在事件已确认为完成态（COMPRESS/WRITE_FILE）时调用。 */
internal fun resolveTimelapseFilePaths(event: TransportEvent.TimelapseEvent): List<String> {
    return listOfNotNull(event.video?.uri?.takeIf { it.isNotEmpty() })
}

class CaptureDelegateImpl(deviceContext: DeviceContext) : BaseDelegate(deviceContext), CaptureDelegate {

    companion object {
        private const val TAG = "CaptureDelegateImpl"
    }

    override var captureStatus: CaptureStatus = CaptureStatus.IDLE
        private set

    private var realCaptureStatus: CameraCaptureStatus.Status = CameraCaptureStatus.Status.NOT_CAPTURE
    private var realSubStatus: CameraCaptureStatus.SubStatus = CameraCaptureStatus.SubStatus.IDLE

    /**
     * 预录制最大时间，单位：s
     */
    private var preRecordMaxTime: Int = 0

    /**
     * 相机工作错误码
     */
    private var workErrorCode: Int = INSTA_OK

    /**
     * 相机录制文件
     */
    private var workFilePath: List<String> = listOf()

    /**
     * 相机录制文件大小
     */
    private var workFileSize: Long = 0

    override var functionMode: FunctionMode = FunctionMode.NONE
        get() {
            // 本地优先，本地没有才去远程拉取
            if (field != FunctionMode.NONE) {
                return field
            }
            // Nanos 只支持普通拍照
            if (context.core.getCameraType().getOrNull() == CameraType.NANO_S) return FunctionMode.PHOTO_NORMAL

            val photo = context.core.getPhotoSubMode().getOrNull()
            val video = context.core.getVideoSubMode().getOrNull()
            return FunctionMode.fromCachedPhotoVideoSubModes(photo, video)
        }
        private set


    private val captureStateMutex = Mutex()
    private var captureStateCallbackMap: MutableMap<Long, Callback<CameraCaptureStatus>> = mutableMapOf()

    private var captureTimerJob: Job? = null

    // StillImageEvent 到达时缓存成片路径；NOT_CAPTURE 通知到达后取出并真正完成 Finished。
    // 用列表承载是因为 HDR / 夜景 / 全景 HDR 会一次产出多张（走 aebImages），普通拍照则为单张。
    private var pendingPhotoFilePaths: List<String>? = null

    // 本轮拍摄是否由 App 主动调用 start* 触发。收口权归属依赖这个维度：只有 App 主动触发的这一轮，
    // 才能确定拍照/录像/延时的原生事件分支会被触发（App 发起的 stop 命令应答会回调它们）；若本轮是
    // 相机端自行结束（机身按键、拍够张数、达到时长上限等），这些事件分支永远不会触发，只有结束通知
    // （NOT_CAPTURE）会到达，此时必须由结束通知收口，否则会漏发——比路径为空更严重。
    // 在 onCaptureStarting 置位，收口（无论是事件分支还是结束通知）后复位，与 basecamera 的
    // mIsOperateCameraByApi 语义对齐。
    private var isCurrentCaptureStartedByApi = false

    override fun init() {
        context.scope.launch {
            context.transport.events.collect {
                when (it) {

                    is TransportEvent.RecordVideoEvent -> {
                        Logger.i(TAG, "[receive event] RecordVideoEvent")
                        when (it.state) {
                            OpState.STARTED.value -> if (captureStatus == CaptureStatus.STARTING && context.cameraConfig?.supportNewRecordInterface() == false) {
                                onCaptureWorking()
                            }

                            OpState.COMPLETE.value, OpState.CANCELED.value, OpState.FAILED.value -> {
                                if (it.error != INSTA_OK) {
                                    onCaptureError(CameraCaptureException("Record video failed, code=${it.error}"))
                                } else {
                                    onCaptureFinish(resolveRecordVideoFilePaths(it).ifEmpty { listOf("") })
                                }
                            }
                        }
                    }

                    is TransportEvent.StillImageEvent -> {
                        Logger.i(TAG, "[receive event] StillImageEvent")
                        if (functionMode.functionType == FunctionType.VIDEO) {
                            // TODO 录像中进行拍照
                        } else if (functionMode in listOf(
                                FunctionMode.PHOTO_NORMAL,
                                FunctionMode.PHOTO_PANO,
                                FunctionMode.PHOTO_HDR,
                                FunctionMode.PHOTO_PANO_HDR,
                                FunctionMode.PHOTO_NIGHT,
                                FunctionMode.PHOTO_BURST
                            )
                        ) {
                            handleStillImageEvent(it)
                        }
                    }

                    is TransportEvent.TimelapseEvent -> {
                        Logger.i(TAG, "[receive event] TimelapseEvent")
                        when (it.state) {
                            OneDriverInfo.Notification.TakePictureState.SHUTTER -> if (captureStatus == CaptureStatus.STARTING) {
                                onCaptureWorking()
                            }

                            OneDriverInfo.Notification.TakePictureState.COMPRESS, OneDriverInfo.Notification.TakePictureState.WRITE_FILE -> {
                                if (it.error != INSTA_OK) {
                                    onCaptureError(CameraCaptureException("Timelapse capture failed, code=${it.error}"))
                                } else {
                                    onCaptureFinish(resolveTimelapseFilePaths(it).ifEmpty { listOf("") })
                                }
                            }
                        }
                    }

                    is TransportEvent.GetCaptureStatusEvent.Success -> {
                        Logger.i(TAG, "[receive event] GetCaptureStatusEvent  Success")
                        captureStateMutex.withLock { captureStateCallbackMap.remove(it.requestId) }?.onSuccess(CameraCaptureStatus().apply {
                            status = CameraCaptureStatus.Status.nativeOf(it.status.state.value)
                            captureTime = it.status.capture_time
                            subStatus = CameraCaptureStatus.SubStatus.nativeOf(it.status.capture_submode.value)
                            preRecordMaxTime = it.status.pre_record_max_time
                        })
                    }

                    is TransportEvent.GetCaptureStatusEvent.Failed -> {
                        Logger.i(TAG, "[receive event] GetCaptureStatusEvent  Failed")
                        captureStateMutex.withLock { captureStateCallbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    is TransportEvent.CameraCaptureStatusNotifyEvent -> {
                        Logger.i(TAG, "[receive event] CameraCaptureStatusNotifyEvent")
                        syncCaptureStatus(CameraCaptureStatus().apply {
                            status = CameraCaptureStatus.Status.nativeOf(it.status.state.value)
                            captureTime = it.status.capture_time
                            subStatus = CameraCaptureStatus.SubStatus.nativeOf(it.status.capture_submode.value)
                            preRecordMaxTime = it.status.pre_record_max_time
                        })
                    }

                    is TransportEvent.CameraCaptureStopedNotifyEvent -> {
                        when (it.notificationCaptureStopped.err_code) {
                            NotificationCaptureStopped.ErrorCode.OVER_TIME_LIMIT -> if (context.cameraConfig?.needNotifyWhenCameraRecordOverTimeLimit() == true) "Exceeding the maximum recording duration limit" else null
                            NotificationCaptureStopped.ErrorCode.STORAGE_FULL -> "Exceeding the maximum storage space limit"
                            NotificationCaptureStopped.ErrorCode.OTHER_SITUATION -> "Other situation"
                            NotificationCaptureStopped.ErrorCode.OVER_FILE_NUMBER_LIMIT -> "Exceeding the maximum file limit"
                            NotificationCaptureStopped.ErrorCode.LOW_CARD_SPEED -> "Storage card write speed is too low"
                            NotificationCaptureStopped.ErrorCode.MUXER_STREAM_ERROR -> "Muxer stream error and recording has been stopped"
                            NotificationCaptureStopped.ErrorCode.DROP_FRAMES -> "Frame loss error occurred and recording has been stopped"
                            NotificationCaptureStopped.ErrorCode.LOW_BATTERY -> "The camera battery is too low and has stopped recording"
                            NotificationCaptureStopped.ErrorCode.STORAGEFRGMT -> "Storage card write speed too low and recording has been stopped"
                            NotificationCaptureStopped.ErrorCode.HIGH_TEMP -> "The camera temperature is too high and recording has been stopped"
                            NotificationCaptureStopped.ErrorCode.LOW_POWER_START -> "The camera battery is too low to start recording"
                            NotificationCaptureStopped.ErrorCode.STORAGE_RUNOUT_START -> "Insufficient storage space to start recording"
                            NotificationCaptureStopped.ErrorCode.HIGH_TEMP_START -> "The camera temperature is too high to start recording"
                            NotificationCaptureStopped.ErrorCode.TASK_CONFLICT_START -> "Task conflict, recording has been stopped"
                            NotificationCaptureStopped.ErrorCode.FW_UPDATE -> "Recording is prohibited during firmware upgrades"
                            NotificationCaptureStopped.ErrorCode.DURING_P2P -> "Recording is prohibited during P2P"
                            else -> "Recording stopped due to an error"
                        }?.let { errorMsg ->
                            onCaptureError(CameraCaptureException(errorMsg))
                        }
                    }

                    is TransportEvent.CameraTimelapseStatusNotifyEvent -> {
                        context.events.tryEmit(DeviceEvent.CaptureCountChanged(functionMode, it.intervalCount))
                    }

                    else -> {}
                }
            }
        }
    }

    override suspend fun release() {
        if (captureTimerJob?.isActive == true) captureTimerJob?.cancel()
        captureTimerJob = null
        // 断连兜底：归属模型下录像/延时摄影的收口权在事件分支，而断连会随实例释放终止事件收集，
        // 若拍摄仍在进行、事件分支的完成事件因此永远不会到达，业务侧的拍摄状态会永久悬挂在工作中。
        // 在释放前主动收口一次，携带当前已知路径（取不到则空串兜底，与既有语义一致）。
        if (captureStatus != CaptureStatus.IDLE) {
            Logger.d(TAG, "release: capture still in progress, finish directly. functionMode=$functionMode")
            onCaptureFinish(pendingPhotoFilePaths ?: listOf(""))
        }
        // 释放时清理缓存路径，避免断连后实例复用时残留陈旧路径上报错误的 Finished
        pendingPhotoFilePaths = null
    }

    fun syncCaptureStatus() {
        Logger.i(TAG, "camera connected, check capture status")
        fetchCaptureState(callback {
            success { state ->
                syncCaptureStatus(state)
            }
        })
    }

    private fun syncCaptureStatus(cameraCaptureStatus: CameraCaptureStatus) {
        Logger.e(TAG, "syncCaptureStatus start $cameraCaptureStatus")
        cameraCaptureStatus.status.toFunctionMode()?.let { func ->
            // 收口权归属判断必须在任何状态复位之前进行：this.functionMode 是本轮拍摄正在进行的模式，
            // 一旦下方的状态复位/子状态事件先执行，就失去了判断"结束的是什么类型"的依据。
            val shouldNotifyFinish = func == FunctionMode.NONE &&
                shouldNotCaptureNotifyFinish(
                    this.functionMode,
                    context.cameraConfig?.supportAiplPhotoCapture() == true,
                    isCurrentCaptureStartedByApi,
                )

            val oldSubStatus = realSubStatus
            realCaptureStatus = cameraCaptureStatus.status
            realSubStatus = cameraCaptureStatus.subStatus
            preRecordMaxTime = cameraCaptureStatus.preRecordMaxTime
            if (oldSubStatus != realSubStatus) {
                Logger.i(TAG, "emit capture sub status event")
                context.events.tryEmit(DeviceEvent.CaptureStatusEvent.SubStatusChanged(func, realSubStatus))
            }
            if (func == FunctionMode.NONE) {
                if (shouldNotifyFinish) {
                    val paths = pendingPhotoFilePaths
                    Logger.d(TAG, "syncCaptureStatus NOT_CAPTURE: pendingPhotoFilePaths=$paths")
                    pendingPhotoFilePaths = null
                    onCaptureFinish(paths ?: listOf(""))
                } else {
                    Logger.d(TAG, "syncCaptureStatus NOT_CAPTURE: skip finish, ownership belongs to event branch. functionMode=${this.functionMode}")
                }
            } else {
                onCaptureWorking(func, cameraCaptureStatus.captureTime)
            }

            when (cameraCaptureStatus.subStatus) {
                CameraCaptureStatus.SubStatus.IDLE, CameraCaptureStatus.SubStatus.RUNNING_STARTED_WITH_PRE_RECORD -> {
                    if (oldSubStatus == CameraCaptureStatus.SubStatus.PAUSE) {
                        startCaptureTimer(cameraCaptureStatus.captureTime)
                    }
                }

                CameraCaptureStatus.SubStatus.PAUSE, CameraCaptureStatus.SubStatus.RECORD_SAVE -> {
                    stopCaptureTimer()
                }

                CameraCaptureStatus.SubStatus.PHOTO_SAVE -> {
                    // TODO 处理照片保存状态
                }

                CameraCaptureStatus.SubStatus.STARTLAPSE_SYNTHESIS -> {
                    // TODO 处理延时摄影合成状态
                }

                CameraCaptureStatus.SubStatus.STARTING -> {}
                CameraCaptureStatus.SubStatus.RUNNING -> {}
                CameraCaptureStatus.SubStatus.TRIMING_START -> {}
                CameraCaptureStatus.SubStatus.PHOTO_CANCEL -> {}
                CameraCaptureStatus.SubStatus.RECORD_CANCEL -> {
                    // TODO 处理照片取消状态
                }

                CameraCaptureStatus.SubStatus.PRE_RECORDING -> {
                    // TODO 处理预录制状态
                }

                CameraCaptureStatus.SubStatus.EXPOSURE -> {

                }
            }

        }
    }

    private fun onCaptureStarting() {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.w(TAG, "notify capture starting, but is already stopping. functionMode: $functionMode")
            return
        }
        if (captureStatus == CaptureStatus.WORKING) {
            Logger.w(TAG, "notify capture starting, but is already working. functionMode: $functionMode")
            return
        }
        captureStatus = CaptureStatus.STARTING
        // 新一轮拍摄开始，清掉上一轮的残留路径，避免本轮未取到路径时误报上一轮的成片
        pendingPhotoFilePaths = null
        // 本轮由 App 主动调用 start* 触发，事件分支才可能收到原生回调
        isCurrentCaptureStartedByApi = true
        Logger.i(TAG, "emit capture starting event")
        context.events.tryEmit(DeviceEvent.CaptureStatusEvent.Starting(functionMode))
    }

    private fun onCaptureWorking(func: FunctionMode = this.functionMode, initialCaptureTime: Int = 0) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.w(TAG, "notify capture working, but is already stopping. functionMode: $func")
            return
        }
        if (captureStatus == CaptureStatus.WORKING) {
            Logger.w(TAG, "notify capture working, but is already working. functionMode: $func")
            return
        }
        captureStatus = CaptureStatus.WORKING
        realCaptureStatus = func.toCaptureStatus()
        // 更新拍摄模式，因为录像时，可能相机会自动改变拍摄模式
        functionMode = func

        Logger.i(TAG, "emit capture working event")
        context.events.tryEmit(DeviceEvent.CaptureStatusEvent.Working(func))

        if (functionMode.controlMode == ControlMode.MANUAL_START_STOP_TIMED) {
            startCaptureTimer(initialCaptureTime)
        }
    }

    private fun startCaptureTimer(initialCaptureTime: Int) {
        Logger.i(TAG, "start capture timing, initialCaptureTime=$initialCaptureTime")
        captureTimerJob?.cancel()
        captureTimerJob = context.scope.launch {
            var seconds = initialCaptureTime
            while (isActive) {
                if (!isPreRecording() || seconds <= preRecordMaxTime) {
                    context.events.tryEmit(DeviceEvent.CaptureTimeChanged(functionMode, seconds.toLong()))
                    seconds++
                } else {
                    Logger.i(TAG, "Exceeding the maximum pre recording time $preRecordMaxTime (s)")
                }
                delay(1_000L)
            }
        }
    }

    private fun stopCaptureTimer() {
        Logger.i(TAG, "stop capture timing")
        captureTimerJob?.cancel()
        captureTimerJob = null
    }

    private fun onCaptureStopping() {
        captureStatus = CaptureStatus.STOPPING
        stopCaptureTimer()
        Logger.i(TAG, "emit capture stopping event")
        context.events.tryEmit(DeviceEvent.CaptureStatusEvent.Stopping(this.functionMode))
    }

    private fun onCaptureFinish(filePaths: List<String>) {
        if (captureStatus == CaptureStatus.IDLE) return
        captureStatus = CaptureStatus.IDLE
        isCurrentCaptureStartedByApi = false
        Logger.i(TAG, "emit capture finish event")
        context.events.tryEmit(DeviceEvent.CaptureStatusEvent.Finished(this.functionMode, filePaths))
        realCaptureStatus = CameraCaptureStatus.Status.NOT_CAPTURE
        realSubStatus = CameraCaptureStatus.SubStatus.IDLE
        stopCaptureTimer()
    }

    /**
     * 处理拍照结果事件。
     *
     * 走 AIPL 链路的机型（由相机配置的 supportAiplPhotoCapture 决定）对一次拍照会回两次结果：
     * 第一次仅表示快门已触发、不含成片路径；待落盘完成后才回第二次，携带真实路径。
     * 两次都会走到这里，故需按「是否已带路径」分流：
     * - 不带路径：仅视为拍摄已启动，保持拍摄中状态，绝不能用空路径提前收口；
     * - 带路径：暂存路径，等 NOT_CAPTURE 通知到达时再统一收口——AIPL 天生需要跨两次应答协调，
     *   只能靠结束通知统一收尾。
     *
     * 非 AIPL 机型一次结果即带路径，不管是否带路径都在此直接收口，不再暂存等待 NOT_CAPTURE：
     * 非 AIPL 的收口权已整体归事件分支（结束通知按归属判断跳过），若空路径时不收口、又指望结束
     * 通知兜底，会因为结束通知已放弃收口权而永久悬挂——比路径为空更严重。接受的代价是：本事件在
     * 非 AIPL 机型上还有另一条触发源（相机主动推送的拍照结果通知，与命令应答共用同一回调），一轮
     * 拍摄理论上可能收到不止一次本事件；若不带路径的那次先到会提前以空路径收口，随后真正带路径的
     * 那次会被 onCaptureFinish 的空闲短路挡掉——退化为路径丢失（与原 bug 表现相同），但不会漏发
     * 完成事件本身。该重复触发场景本轮未实测复现，后续任务如需彻底解决可再引入更精细的判断。
     *
     * 非 AIPL 机型直接在此收口不会重现 SDKAP-203/208（快门完成即收口引发的重复完成事件/虚假
     * 拍摄中事件）：SDKAP-203/208 是 X6 固件的专属时序问题，X6 走 AIPL 链路，不经过这个分支。
     */
    private fun handleStillImageEvent(event: TransportEvent.StillImageEvent) {
        if (event.error != INSTA_OK) {
            onCaptureError(CameraCaptureException("Still Image failed, code=${event.error}"))
            return
        }

        val filePaths = resolvePhotoFilePaths(event.takePictureResponse)
        val isAiplPhotoCapture = context.cameraConfig?.supportAiplPhotoCapture() == true
        if (!isAiplPhotoCapture) {
            Logger.d(TAG, "StillImageEvent: non-AIPL finish directly. filePaths=$filePaths")
            onCaptureFinish(filePaths.ifEmpty { listOf("") })
            return
        }

        if (filePaths.isEmpty()) {
            // AIPL 启动结果：快门已触发但尚未落盘，路径要等第二次结果。此时不收口、不覆盖已有路径。
            Logger.d(TAG, "StillImageEvent: capture started, waiting for file path. functionMode=$functionMode")
            return
        }

        // 走到这里是 AIPL 带路径的第二次结果：暂存路径，等 NOT_CAPTURE 收口。
        pendingPhotoFilePaths = filePaths
        // 预设 realSubStatus，避免 Burst 模式收到真实 PHOTO_SAVE 通知时重复发出 SubStatusChanged
        realSubStatus = CameraCaptureStatus.SubStatus.PHOTO_SAVE
        Logger.d(TAG, "StillImageEvent: filePaths=$filePaths, pendingPhotoFilePaths=$pendingPhotoFilePaths, captureStatus=$captureStatus")
        context.events.tryEmit(DeviceEvent.CaptureStatusEvent.SubStatusChanged(functionMode, CameraCaptureStatus.SubStatus.PHOTO_SAVE))
    }

    /**
     * 从拍照结果中取出成片路径：HDR/夜景走 aebImages，连拍走 burstImages，其余取单张 image。
     * panoImages 字段未处理——basecamera 从未用过它，对应场景不明。
     * 返回空列表表示本次结果尚未携带路径。
     */
    private fun resolvePhotoFilePaths(response: TakePictureResponse?): List<String> {
        if (response == null) return emptyList()
        response.aeb_images.map { it.uri }.filter { it.isNotEmpty() }.takeIf { it.isNotEmpty() }?.let { return it }
        response.burst_images.map { it.uri }.filter { it.isNotEmpty() }.takeIf { it.isNotEmpty() }?.let { return it }
        return listOfNotNull(response.image?.uri?.takeIf { it.isNotEmpty() })
    }

    private fun onCaptureError(captureException: CameraCaptureException) {
        if (pendingPhotoFilePaths != null) {
            Logger.d(TAG, "onCaptureError: clear pendingPhotoFilePaths=$pendingPhotoFilePaths")
            pendingPhotoFilePaths = null
        }
        if (captureStatus == CaptureStatus.IDLE) return
        captureStatus = CaptureStatus.IDLE
        isCurrentCaptureStartedByApi = false
        Logger.i(TAG, "emit capture error event, error=${captureException.message}")
        context.events.tryEmit(DeviceEvent.CaptureStatusEvent.Error(this.functionMode, captureException))
        realCaptureStatus = CameraCaptureStatus.Status.NOT_CAPTURE
        realSubStatus = CameraCaptureStatus.SubStatus.IDLE
        stopCaptureTimer()
    }

    override fun fetchCaptureState(callback: Callback<CameraCaptureStatus>) {
        val id = context.transport.fetchCaptureState()
        context.scope.launch {
            captureStateMutex.withLock { captureStateCallbackMap.put(id, callback) }
        }
    }

    override suspend fun fetchCaptureState(): Result<CameraCaptureStatus> {
        return suspendCancellableCoroutine { continuation ->
            fetchCaptureState(callback {
                success { continuation.resume(Result.success(it)) }
                throwable { continuation.resume(Result.failure(it)) }
            })
        }
    }

    override fun switchFunctionMode(functionMode: FunctionMode, callback: Callback<Unit>) {
        context.scope.launch {
            switchFunctionMode(functionMode).onSuccess {
                callback.onSuccess(Unit)
            }.onFailure { throwable ->
                callback.onThrowable(throwable as InstaException)
            }
        }
    }

    override suspend fun switchFunctionMode(functionMode: FunctionMode): Result<Unit> {
        val result = when (functionMode.functionType) {
            FunctionType.NONE -> Result.failure(SwitchFunctionModeException("Invalid FunctionMode"))
            FunctionType.VIDEO -> context.core.setVideoSubMode(VideoSubMode.nativeOf(functionMode.subModeValue))
            FunctionType.PHOTO -> context.core.setPhotoSubMode(PhotoSubMode.nativeOf(functionMode.subModeValue))
        }
        if (result.isSuccess) {
            this.functionMode = functionMode
            context.core.fetchAllPhotographyOptions(functionMode)
            if (functionMode.timelapseMode() != -1) context.core.fetchTimelapseOption(functionMode.timelapseMode())
            context.core.fetchSensorMode().onSuccess {
                if (it == SensorMode.FRONT || it == SensorMode.REAR) context.core.fetchAllMultiVideoOptions(functionMode)
            }
        }
        return result
    }

    override fun isPreRecording(): Boolean {
        return realSubStatus == CameraCaptureStatus.SubStatus.PRE_RECORDING && isWorking()
    }

    override fun cancelPreRecord() {
        context.transport.setPreRecord(CtrlPreRecord().apply {
            ctrl_operate = CtrlOperate.OPERATE_CANCLE
        })
        stopCaptureTimer()
    }

    override fun isWorking(functionMode: FunctionMode): Boolean {
        if (functionMode == FunctionMode.NONE) return realCaptureStatus != CameraCaptureStatus.Status.NOT_CAPTURE
        return realCaptureStatus != CameraCaptureStatus.Status.NOT_CAPTURE && realCaptureStatus.toFunctionMode() == functionMode
    }

    override fun checkCaptureConditions(functionMode: FunctionMode): Result<Unit> {
        return context.core.getBatteryData().mapFailure {
            CheckBatteryDataException("")
        }.flatMap {
            if (it.level <= (context.cameraConfig?.captureMinBatteryLevel() ?: 0) && !it.isCharging) {
                LowBatteryException().failure()
            } else {
                Unit.success()
            }
        }.flatMap {
            context.core.getStorageData().mapFailure {
                CheckStorageDataException()
            }.flatMap {
                if (it.state != StorageData.State.PASS) {
                    SDCardUnavailableException().failure()
                } else {
                    Unit.success()
                }
            }
        }
    }

    override fun startPhotoNormal(rawType: RawType, extraData: ByteArray?, selfTime: Int?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo normal , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_NORMAL)) {
            Logger.d(TAG, "start photo normal , is working , return")
            return
        }
        Logger.d(TAG, "start photo normal")
        val takePicture = TakePicture()
        takePicture.mode = TakePicture.Mode.NORMAL
        takePicture.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        takePicture.raw_capture_type = RawCaptureType.fromValue(rawType.nativeValue) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
        takePicture.isInstaPanoEnabled = false
        takePicture.focusSensor = SENSOR_DEVICE_ALL
        takePicture.selfTimer = selfTime ?: 0
        context.transport.takePicture(takePicture)
        onCaptureStarting()
    }

    override fun stopPhotoNormal() {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop photo normal , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.PHOTO_NORMAL)) {
            Logger.d(TAG, "stop photo normal , is not working , return")
            return
        }
        Logger.d(TAG, "stop photo normal")
        context.transport.stopTakePicture()
        onCaptureStopping()
    }

    override fun startPhotoNormalPano(sensor: SensorMode, rawType: RawType, extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo pano , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_PANO)) {
            Logger.d(TAG, "start photo pano , is working , return")
            return
        }
        Logger.d(TAG, "start photo pano")
        val takePicture = TakePicture()
        takePicture.mode = TakePicture.Mode.NORMAL
        takePicture.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        takePicture.raw_capture_type = RawCaptureType.fromValue(rawType.nativeValue) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
        takePicture.isInstaPanoEnabled = true
        takePicture.focusSensor = SensorDevice.fromValue(sensor.nativeValue) ?: SENSOR_DEVICE_ALL
        context.transport.takePicture(takePicture)
        onCaptureStarting()
    }

    override fun startPhotoHdr(evBias: List<Int>, rawType: RawType, extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo hdr , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_HDR)) {
            Logger.d(TAG, "start photo hdr , is working , return")
            return
        }
        Logger.d(TAG, "start photo hdr")
        val takePicture = TakePicture()
        takePicture.mode = TakePicture.Mode.AEB
        takePicture.aeb_ev_bias = evBias
        takePicture.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        takePicture.raw_capture_type = RawCaptureType.fromValue(rawType.nativeValue) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
        takePicture.isInstaPanoEnabled = false
        takePicture.focusSensor = SENSOR_DEVICE_ALL
        context.transport.takePicture(takePicture)
        onCaptureStarting()
    }

    override fun startPhotoHdrPano(sensor: SensorMode, evBias: List<Int>, rawType: RawType, extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo pano hdr , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_PANO_HDR)) {
            Logger.d(TAG, "start photo pano hdr , is working , return")
            return
        }
        Logger.d(TAG, "start photo pano hdr")
        val takePicture = TakePicture()
        takePicture.mode = TakePicture.Mode.AEB
        takePicture.aeb_ev_bias = evBias
        takePicture.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        takePicture.raw_capture_type = RawCaptureType.fromValue(rawType.nativeValue) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
        takePicture.isInstaPanoEnabled = true
        takePicture.focusSensor = SensorDevice.fromValue(sensor.nativeValue) ?: SENSOR_DEVICE_ALL
        context.transport.takePicture(takePicture)
        onCaptureStarting()
    }

    override fun startPhotoNight(rawType: RawType, extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo night scene , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_NIGHT)) {
            Logger.d(TAG, "start photo night scene , is working , return")
            return
        }
        Logger.d(TAG, "start photo night scene")
        val takePicture = TakePicture()
        takePicture.mode = TakePicture.Mode.AEB_NIGHT
        takePicture.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        takePicture.raw_capture_type = RawCaptureType.fromValue(rawType.nativeValue) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
        context.transport.takePicture(takePicture)
        onCaptureStarting()
    }

    override fun startPhotoBurst(rawType: RawType, extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo burst , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_BURST)) {
            Logger.d(TAG, "start photo burst , is working , return")
            return
        }
        Logger.d(TAG, "start photo burst")
        val takePicture = TakePicture()
        takePicture.mode = TakePicture.Mode.BURST
        takePicture.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        takePicture.raw_capture_type = RawCaptureType.fromValue(rawType.nativeValue) ?: RawCaptureType.RAW_CAPTURE_TYPE_OFF
        context.transport.takePicture(takePicture)
        onCaptureStarting()
    }

    override fun startPhotoInterval(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo interval , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_INTERVAL)) {
            Logger.d(TAG, "start photo interval , is working , return")
            return
        }
        Logger.d(TAG, "start photo interval")
        val startTimelapse = StartTimelapse()
        startTimelapse.mode = TimelapseMode.TIMELAPSE_INTERVAL_SHOOTING
        startTimelapse.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        context.transport.startTimelapse(startTimelapse)
        onCaptureStarting()
    }

    override fun stopPhotoInterval() {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop photo interval , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.PHOTO_INTERVAL)) {
            Logger.d(TAG, "stop photo interval , is not working , return")
            return
        }
        Logger.d(TAG, "stop photo interval")
        val stopTimelapse = StopTimelapse()
        stopTimelapse.mode = TimelapseMode.TIMELAPSE_INTERVAL_SHOOTING
        context.transport.stopTimelapse(stopTimelapse)
        onCaptureStopping()
    }

    override fun startPhotoStarLapse(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start photo starlapse , is starting , return")
            return
        }
        if (isWorking(FunctionMode.PHOTO_STARLAPSE)) {
            Logger.d(TAG, "start photo starlapse , is working , return")
            return
        }
        Logger.d(TAG, "start photo starlapse")
        val startTimelapse = StartTimelapse()
        startTimelapse.mode = TimelapseMode.TIMELAPSE_STARLAPSE_SHOOTING
        startTimelapse.extra_metadata = extraData?.let { ExtraMetadata.ADAPTER.decode(it) }
        context.transport.startTimelapse(startTimelapse)
        onCaptureStarting()
    }

    override fun stopPhotoStarLapse() {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop photo starlapse , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.PHOTO_STARLAPSE)) {
            Logger.d(TAG, "stop photo starlapse , is not working , return")
            return
        }
        Logger.d(TAG, "stop photo starlapse")
        val stopTimelapse = StopTimelapse()
        stopTimelapse.mode = TimelapseMode.TIMELAPSE_STARLAPSE_SHOOTING
        context.transport.stopTimelapse(stopTimelapse)
        onCaptureStopping()
    }

    override fun startVideoNormal() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video normal , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_NORMAL)) {
            Logger.d(TAG, "start video normal , is working , return")
            return
        }
        Logger.d(TAG, "start video normal")
        context.transport.startRecord(CaptureMode.Capture_MODE_NORMAL)
        onCaptureStarting()
    }

    override fun stopVideoNormal(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video normal , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_NORMAL)) {
            Logger.d(TAG, "stop video normal , is not working , return")
            return
        }
        Logger.d(TAG, "stop video normal")
        context.transport.stopRecord(CaptureMode.Capture_MODE_NORMAL, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoSuper() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video super , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_SUPER)) {
            Logger.d(TAG, "start video super , is working , return")
            return
        }
        Logger.d(TAG, "start video super")
        context.transport.startRecord(CaptureMode.Capture_MODE_SUPER_VIDEO)
        onCaptureStarting()
    }

    override fun stopVideoSuper(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video super , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_SUPER)) {
            Logger.d(TAG, "stop video super , is not working , return")
            return
        }
        Logger.d(TAG, "stop video super")
        context.transport.stopRecord(CaptureMode.Capture_MODE_SUPER_VIDEO, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoBulletTime() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video bullet time , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_BULLET_TIME)) {
            Logger.d(TAG, "start video bullet time , is working , return")
            return
        }
        Logger.d(TAG, "start video bullet time")
        if (context.cameraConfig?.supportNewRecordInterface() == true) {
            context.transport.startRecord(CaptureMode.Capture_MODE_BULLETTIME)
        } else {
            context.transport.startBulletTime()
        }
        onCaptureStarting()
    }

    override fun stopVideoBulletTime(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video bullet time , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_BULLET_TIME)) {
            Logger.d(TAG, "stop video bullet time , is not working , return")
            return
        }
        Logger.d(TAG, "stop video bullet time")
        if (context.cameraConfig?.supportNewRecordInterface() == true) {
            context.transport.stopRecord(CaptureMode.Capture_MODE_BULLETTIME, extraData ?: byteArrayOf())
        } else {
            context.transport.stopBulletTime(extraData ?: byteArrayOf())
        }
        onCaptureStopping()
    }

    override fun startVideoTimelapse() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video timelapse , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_TIMELAPSE)) {
            Logger.d(TAG, "start video timelapse , is working , return")
            return
        }
        Logger.d(TAG, "start video timelapse")
        val startTimelapse = StartTimelapse()
        startTimelapse.mode = TimelapseMode.MOBILE_TIMELAPSE_VIDEO
        context.transport.startTimelapse(startTimelapse)
        onCaptureStarting()
    }

    override fun stopVideoTimelapse(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video timelapse , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_TIMELAPSE)) {
            Logger.d(TAG, "stop video timelapse , is not working , return")
            return
        }
        Logger.d(TAG, "stop video timelapse")
        val stopTimelapse = StopTimelapse(mode = TimelapseMode.MOBILE_TIMELAPSE_VIDEO)
        extraData?.let {
            stopTimelapse.extra_metadata = ExtraMetadata.ADAPTER.decode(it)
        }
        context.transport.stopTimelapse(stopTimelapse)
        onCaptureStopping()
    }

    override fun startVideoHdr() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video hdr , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_HDR)) {
            Logger.d(TAG, "start video hdr , is working , return")
            return
        }
        Logger.d(TAG, "start video hdr")
        if (context.cameraConfig?.supportNewRecordInterface() == true) {
            context.transport.startRecord(CaptureMode.Capture_MODE_HDR)
        } else {
            context.transport.startHdrCapture()
        }
        onCaptureStarting()
    }

    override fun stopVideoHdr(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video hdr , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_HDR)) {
            Logger.d(TAG, "stop video hdr , is not working , return")
            return
        }
        Logger.d(TAG, "stop video hdr")
        if (context.cameraConfig?.supportNewRecordInterface() == true) {
            context.transport.stopRecord(CaptureMode.Capture_MODE_HDR, extraData ?: byteArrayOf())
        } else {
            context.transport.stopHdrCapture(extraData ?: byteArrayOf())
        }
        onCaptureStopping()
    }

    override fun startVideoTimeShift() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video timeshift , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_TIMESHIFT)) {
            Logger.d(TAG, "start video timeshift , is working , return")
            return
        }
        Logger.d(TAG, "start video timeshift")
        context.transport.startRecord(CaptureMode.Capture_MODE_TIMESHIFT)
        onCaptureStarting()
    }

    override fun stopVideoTimeShift(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video timeshift , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_TIMESHIFT)) {
            Logger.d(TAG, "stop video timeshift , is not working , return")
            return
        }
        Logger.d(TAG, "stop video timeshift")
        context.transport.stopRecord(CaptureMode.Capture_MODE_TIMESHIFT, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoLooperRecording() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video looper , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_LOOP_RECORDING)) {
            Logger.d(TAG, "start video looper , is working , return")
            return
        }
        Logger.d(TAG, "start video looper")
        context.transport.startRecord(CaptureMode.Capture_MODE_LOOPRECORDING)
        onCaptureStarting()
    }

    override fun stopVideoLooperRecording(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video looper , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_LOOP_RECORDING)) {
            Logger.d(TAG, "stop video looper , is not working , return")
            return
        }
        Logger.d(TAG, "stop video looper")
        context.transport.stopRecord(CaptureMode.Capture_MODE_LOOPRECORDING, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoFpv() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video fpv , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_FPV)) {
            Logger.d(TAG, "start video fpv , is working , return")
            return
        }
        Logger.d(TAG, "start video fpv")
        context.transport.startRecord(CaptureMode.Capture_MODE_FPV)
        onCaptureStarting()
    }

    override fun stopVideoFpv(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video fpv , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_FPV)) {
            Logger.d(TAG, "stop video fpv , is not working , return")
            return
        }
        Logger.d(TAG, "stop video fpv")
        context.transport.stopRecord(CaptureMode.Capture_MODE_FPV, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoMovie() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video movie , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_MOVIE)) {
            Logger.d(TAG, "start video movie , is working , return")
            return
        }
        Logger.d(TAG, "start video movie")
        context.transport.startRecord(CaptureMode.Capture_MODE_MOVIE)
        onCaptureStarting()
    }

    override fun stopVideoMovie(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video movie , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_MOVIE)) {
            Logger.d(TAG, "stop video movie , is not working , return")
            return
        }
        Logger.d(TAG, "stop video movie")
        context.transport.stopRecord(CaptureMode.Capture_MODE_MOVIE, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoSlowMotion() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video slow motion , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_SLOW_MOTION)) {
            Logger.d(TAG, "start video slow motion , is working , return")
            return
        }
        Logger.d(TAG, "start video slow motion")
        context.transport.startRecord(CaptureMode.Capture_MODE_SLOWMOTION)
        onCaptureStarting()
    }

    override fun stopVideoSlowMotion(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video slow motion , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_SLOW_MOTION)) {
            Logger.d(TAG, "stop video slow motion , is not working , return")
            return
        }
        Logger.d(TAG, "stop video slow motion")
        context.transport.stopRecord(CaptureMode.Capture_MODE_SLOWMOTION, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoSelfie() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video selfie , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_SELFIE)) {
            Logger.d(TAG, "start video selfie , is working , return")
            return
        }
        Logger.d(TAG, "start video selfie")
        context.transport.startRecord(CaptureMode.Capture_MODE_SELFIE)
        onCaptureStarting()
    }

    override fun stopVideoSelfie(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video selfie , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_SELFIE)) {
            Logger.d(TAG, "stop video selfie , is not working , return")
            return
        }
        Logger.d(TAG, "stop video selfie")
        context.transport.stopRecord(CaptureMode.Capture_MODE_SELFIE, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoPure() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video pure , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_PURE)) {
            Logger.d(TAG, "start video pure , is working , return")
            return
        }
        Logger.d(TAG, "start video pure")
        context.transport.startRecord(CaptureMode.Capture_MODE_PURE_VIDEO)
        onCaptureStarting()
    }

    override fun stopVideoPure(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video pure , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_PURE)) {
            Logger.d(TAG, "stop video pure , is not working , return")
            return
        }
        Logger.d(TAG, "stop video pure")
        context.transport.stopRecord(CaptureMode.Capture_MODE_PURE_VIDEO, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoDashCam() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video dash cam , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_DASHCAM)) {
            Logger.d(TAG, "start video dash cam , is working , return")
            return
        }
        Logger.d(TAG, "start video dash cam")
        context.transport.startRecord(CaptureMode.Capture_MODE_DASH_CAM)
        onCaptureStarting()
    }

    override fun stopVideoDashCam(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video dash cam , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_DASHCAM)) {
            Logger.d(TAG, "stop video dash cam , is not working , return")
            return
        }
        Logger.d(TAG, "stop video dash cam")
        context.transport.stopRecord(CaptureMode.Capture_MODE_DASH_CAM, extraData ?: byteArrayOf())
        onCaptureStopping()
    }

    override fun startVideoMosquito() {
        if (captureStatus == CaptureStatus.STARTING) {
            Logger.d(TAG, "start video mosquito , is starting , return")
            return
        }
        if (isWorking(FunctionMode.VIDEO_MOSQUITO)) {
            Logger.d(TAG, "start video mosquito , is working , return")
            return
        }
        Logger.d(TAG, "start video mosquito")
        context.transport.startRecord(CaptureMode.Capture_MODE_MOSQUITO)
        onCaptureStarting()
    }

    override fun stopVideoMosquito(extraData: ByteArray?) {
        if (captureStatus == CaptureStatus.STOPPING) {
            Logger.d(TAG, "stop video mosquito , is stopping , return")
            return
        }
        if (!isWorking(FunctionMode.VIDEO_MOSQUITO)) {
            Logger.d(TAG, "stop video mosquito , is not working , return")
            return
        }
        Logger.d(TAG, "stop video mosquito")
        context.transport.stopRecord(CaptureMode.Capture_MODE_MOSQUITO, extraData ?: byteArrayOf())
        onCaptureStopping()
    }
}