package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.option.FocusSensor
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded
import com.arashivision.sdk.common.kotlin.flatMap

internal class RecordResolutionCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>, deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<RecordResolution>(CommonAttrKeys.RECORD_RESOLUTION, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): RecordResolution {
        return RecordResolution.UNKNOWN
    }

    override fun fromInt(value: Int): RecordResolution {
        return RecordResolution.nativeOf(value)
    }

    override fun fromName(name: String): RecordResolution {
        return RecordResolution.protoOf(name)
    }

    override fun toInt(data: RecordResolution): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<RecordResolution> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.ONE_X -> device.getVideoResolution()
            CameraType.ONE_X2, CameraType.X3 -> {
                device.getFocusSensor().flatMap {
                    if (it in listOf(FocusSensor.FRONT, FocusSensor.REAR)) {
                        device.getMultiVideoResolution(functionMode)
                    } else {
                        device.getRecordResolution(functionMode)
                    }
                }
            }

            else -> {
                device.getRecordResolution(functionMode)
            }
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<RecordResolution> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.ONE_X -> device.fetchVideoResolution()
            CameraType.ONE_X2, CameraType.X3 -> {
                device.fetchFocusSensor().flatMap {
                    if (it in listOf(FocusSensor.FRONT, FocusSensor.REAR)) {
                        device.fetchMultiVideoResolution(functionMode)
                    } else {
                        device.fetchRecordResolution(functionMode)
                    }
                }
            }

            else -> {
                device.fetchRecordResolution(functionMode)
            }
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: RecordResolution): Result<Unit> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.ONE_X -> device.setVideoResolution(value)
            else -> {
                device.setRecordResolution(functionMode, value).thenMirrorVideoLiveIfNeeded(device, functionMode) {
                    device.setRecordResolution(FunctionMode.VIDEO_LIVE, value)
                }
            }
        }
    }


}