package com.arashivision.sdk.camera.core.model.option

data class WiFiChannel(val country: String, val channelList: List<Int>)
