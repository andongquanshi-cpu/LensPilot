package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class NanoSSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.NONE
    override val previewFileType = PreviewFileType.VR360
    override val previewStabType = PreviewStabType.STAB_OFF

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_960_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_5760_2880_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1440_720_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )
        }
}
