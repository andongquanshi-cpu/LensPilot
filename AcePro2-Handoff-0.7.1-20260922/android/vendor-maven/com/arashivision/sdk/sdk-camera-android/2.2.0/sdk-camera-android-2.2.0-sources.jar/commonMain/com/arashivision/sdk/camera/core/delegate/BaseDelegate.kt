package com.arashivision.sdk.camera.core.delegate

import com.arashivision.sdk.camera.core.DeviceContext

abstract class BaseDelegate(protected val context: DeviceContext) {

    abstract fun init()

    abstract suspend fun release()
}