package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.PanoExposureMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class PanoExposureModeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<PanoExposureMode>(CommonAttrKeys.EXPOSURE_INDIVIDUAL, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): PanoExposureMode? = null

    override fun fromInt(value: Int): PanoExposureMode {
        return PanoExposureMode.nativeOf(value)
    }

    override fun fromName(name: String): PanoExposureMode {
        return PanoExposureMode.protoOf(name)
    }

    override fun toInt(data: PanoExposureMode): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PanoExposureMode> {
        return device.getPanoExposureMode(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PanoExposureMode> {
        return device.fetchPanoExposureMode(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: PanoExposureMode): Result<Unit> {
        return device.setPanoExposureMode(functionMode, value)
    }

}