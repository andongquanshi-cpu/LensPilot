package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.option.ChargeBoxData

/**
 * 充电盒状态监听器。
 *
 * 用于监听带有充电盒的相机设备（如 Go 系列）的充电盒状态变化。
 */
interface ChargeBoxStatusListener {
    /**
     * 当充电盒状态（如电量、连接状态等）发生变化时回调。
     *
     * @param chargeBoxData 包含充电盒当前状态信息的对象。
     */
    fun onChargeBoxStatusChange(chargeBoxData: ChargeBoxData)
}
