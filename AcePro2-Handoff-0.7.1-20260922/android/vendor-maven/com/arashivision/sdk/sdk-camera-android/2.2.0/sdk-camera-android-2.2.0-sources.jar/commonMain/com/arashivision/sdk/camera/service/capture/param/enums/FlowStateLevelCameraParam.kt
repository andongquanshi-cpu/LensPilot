package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.FlowStateLevel
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class FlowStateLevelCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<FlowStateLevel>(CommonAttrKeys.FLOWSTATE_LEVEL, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): FlowStateLevel? = null

    override fun fromInt(value: Int): FlowStateLevel {
        return FlowStateLevel.nativeOf(value)
    }

    override fun fromName(name: String): FlowStateLevel {
        return FlowStateLevel.protoOf(name)
    }

    override fun toInt(data: FlowStateLevel): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<FlowStateLevel> {
        return device.getCameraType().fold(
            onSuccess = {
                if (it in listOf(CameraType.ACE, CameraType.ACE_PRO, CameraType.ACE_PRO_2, CameraType.GO_ULTRA)) {
                    device.getFlowStateLevelCv5(functionMode)
                } else {
                    device.getFlowStateLevel(functionMode)
                }
            },
            onFailure = { device.getFlowStateLevelCv5(functionMode) }
        )
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<FlowStateLevel> {
        return device.getCameraType().fold(
            onSuccess = {
                if (it in listOf(CameraType.ACE, CameraType.ACE_PRO, CameraType.ACE_PRO_2, CameraType.GO_ULTRA)) {
                    device.fetchFlowStateLevelCv5(functionMode)
                } else {
                    device.fetchFlowStateLevel(functionMode)
                }
            },
            onFailure = { device.fetchFlowStateLevelCv5(functionMode) }
        )
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: FlowStateLevel): Result<Unit> {
        return device.getCameraType().fold(
            onSuccess = {
                if (it in listOf(CameraType.ACE, CameraType.ACE_PRO, CameraType.ACE_PRO_2, CameraType.GO_ULTRA)) {
                    device.setFlowStateLevelCv5(functionMode, value)
                } else {
                    device.setFlowStateLevel(functionMode, value)
                }
            },
            onFailure = { device.setFlowStateLevelCv5(functionMode, value) }
        )
    }

}