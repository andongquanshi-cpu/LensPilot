package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType

internal class SphereSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFileType = PreviewFileType.VR360
    override val previewFitMode = PreviewFitMode.NONE
    override val isGestureEnabledByMode: Boolean = true
    override val previewGyroType
        get() = resolveOneRFisheyePreviewGyroType()
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewStabType = PreviewStabType.STAB_STILL

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = currentRecordStream() ?: StreamResolution.STREAM_1920_960_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = currentRecordStream() ?: StreamResolution.STREAM_5760_2880_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1440_720_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )
        }
}
