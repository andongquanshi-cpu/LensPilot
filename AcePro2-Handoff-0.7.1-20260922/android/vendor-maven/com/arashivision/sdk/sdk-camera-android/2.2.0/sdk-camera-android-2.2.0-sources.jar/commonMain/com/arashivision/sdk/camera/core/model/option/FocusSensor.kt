package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class FocusSensor(override val nativeValue: Int) : BaseEnum {
    UNKNOWN(0),
    FRONT(1),
    REAR(2),
    ALL(3);

    companion object {
        fun nativeOf(nativeValue: Int?): FocusSensor {
            return FocusSensor.entries.firstOrNull { it.nativeValue == nativeValue } ?: UNKNOWN
        }

        fun protoOf(name: String?): FocusSensor {
            return UNKNOWN
        }
    }
}