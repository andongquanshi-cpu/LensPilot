package com.arashivision.sdk.camera.config.goultra

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import insta360.messages.MultiPhotographyOptionsType

class GoUltraCameraConfig(override val connectType: ConnectType) : ICameraConfig {

    override fun supportShutdown(): Boolean = false

    override fun supportMultiVideoOptionsList(): List<MultiPhotographyOptionsType> = emptyList()

    override fun captureMinBatteryLevel(): Int = 3

    override fun supportResetCameraWifi(fwVersion: String): Boolean = true

    override fun supportFetchCameraSensorMode(): Boolean = false

    override fun syncOptionMaxStep(): Int {
        return if (connectType == ConnectType.BLE) 16 else 60
    }

    override fun hasChargingBox(): Boolean = true

    override fun supportDownloadJsonParams(): Boolean = true

    override fun getLensName(sensorMode: SensorMode): String = "WideAngle06C"

    override fun firmwareUpgradeMinBatteryLevel(): Int = 25

    override fun firmwareUpgradeMinChargingBoxBatteryLevel(): Int = 25

    override fun supportNewRecordInterface(): Boolean = true

    override fun needNotifyWhenCameraRecordOverTimeLimit(): Boolean = false

    override fun isMergedIntoRS(version: String): Boolean = false

    override fun supportNewCaptureControlFlow(): Boolean = true

    override fun supportBleBroadcastWakeUp(): Boolean = false

    override fun needAuthorization(): Boolean = true
}