package com.arashivision.sdk.camera.core.delegate.photography

import com.arashivision.sdk.common.callback.CoroutineCallback
import com.arashivision.sdk.common.callback.coroutineCallback
import com.arashivision.sdk.common.exception.CameraNotConnectedException
import com.arashivision.sdk.common.exception.PhotographyOptionValueNullException
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.camera.core.DeviceContext
import com.arashivision.sdk.camera.core.delegate.BaseDelegate
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.ExportType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.core.model.photography.Iq3AMode
import com.arashivision.sdk.camera.core.model.photography.FlowStateLevel
import com.arashivision.sdk.camera.core.model.photography.FovType
import com.arashivision.sdk.camera.core.model.photography.PanoExposureMode
import com.arashivision.sdk.camera.core.model.photography.PhotoHdrType
import com.arashivision.sdk.camera.core.model.photography.PhotoResolution
import com.arashivision.sdk.camera.core.model.photography.PhotoSize
import com.arashivision.sdk.camera.core.model.photography.RawType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.ResolutionRecordLimit
import com.arashivision.sdk.camera.core.model.photography.VideoGammaMode
import com.arashivision.sdk.camera.core.model.photography.VideoSelfieMode
import com.arashivision.sdk.camera.core.model.photography.WB
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

class PhotographyOptionDelegateImpl(deviceContext: DeviceContext) : BaseDelegate(deviceContext), PhotographyOptionDelegate {

    companion object {
        private const val TAG = "PhotographyOptionDelegateImpl"

        // 与底层协议一致的曝光补偿放大倍数
        private const val EXPOSURE_BIAS_SCALE = 10.0
    }

    private var photographyCallbackMap: MutableMap<Long, CoroutineCallback<PhotographyOptions>> = mutableMapOf()
    private val photographyCallbackMutex = Mutex()
    private var callbackMap: MutableMap<Long, CoroutineCallback<Unit>> = mutableMapOf()
    private val callbackMutex = Mutex()

    private val photographyOptionCacheMutex = Mutex()
    private var photographyOptionCache: MutableMap<FunctionMode, MutableMap<PhotographyOptionType, Any?>> = mutableMapOf()

    override fun init() {
        context.scope.launch {
            context.transport.events.collect {
                when (it) {
                    //get photography option
                    is TransportEvent.GetPhotographyOptionEvent.Success -> {
                        photographyCallbackMutex.withLock { photographyCallbackMap.remove(it.requestId) }?.onSuccess(it.photographyOptions)
                    }

                    is TransportEvent.GetPhotographyOptionEvent.Failed -> {
                        photographyCallbackMutex.withLock { photographyCallbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    //set photography option
                    is TransportEvent.SetPhotographyOptionEvent.Success -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onSuccess(Unit)
                    }

                    is TransportEvent.SetPhotographyOptionEvent.Failed -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    else -> {}
                }
            }
        }
    }

    override fun getRemaining(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.REMAINING_TIME)

    override suspend fun fetchRemaining(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.REMAINING_TIME)

    override fun getAeb(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.AEB_CAPTURE_NUM)

    override suspend fun fetchAeb(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.AEB_CAPTURE_NUM)

    override suspend fun setAeb(functionMode: FunctionMode, aeb: Int): Result<Unit> = setPhotographyOption(functionMode, PhotographyOptionType.AEB_CAPTURE_NUM, aeb)

    override fun getRawType(functionMode: FunctionMode): Result<RawType> = requiredPhotographyOption(functionMode, PhotographyOptionType.RAW_CAPTURE_TYPE)

    override suspend fun fetchRawType(functionMode: FunctionMode): Result<RawType> = fetchPhotographyOption(functionMode, PhotographyOptionType.RAW_CAPTURE_TYPE)

    override suspend fun setRawType(functionMode: FunctionMode, rawType: RawType): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.RAW_CAPTURE_TYPE, rawType)

    override fun getExposureBias(functionMode: FunctionMode): Result<Double> = requiredPhotographyOption<Double>(functionMode, PhotographyOptionType.EXPOSURE_BIAS).map {
        it / EXPOSURE_BIAS_SCALE
    }

    override suspend fun fetchExposureBias(functionMode: FunctionMode): Result<Double> = fetchPhotographyOption(functionMode, PhotographyOptionType.EXPOSURE_BIAS)

    override suspend fun setExposureBias(functionMode: FunctionMode, exposureBias: Double): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.EXPOSURE_BIAS, (exposureBias * EXPOSURE_BIAS_SCALE).toInt())

    override fun getPhotoResolution(functionMode: FunctionMode): Result<PhotoResolution> = requiredPhotographyOption(functionMode, PhotographyOptionType.PHOTO_RESOLUTION)

    override suspend fun fetchPhotoResolution(functionMode: FunctionMode): Result<PhotoResolution> = fetchPhotographyOption(functionMode, PhotographyOptionType.PHOTO_RESOLUTION)

    override suspend fun setPhotoResolution(functionMode: FunctionMode, photoResolution: PhotoResolution): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.PHOTO_RESOLUTION, photoResolution)

    override fun getWhiteBalance(functionMode: FunctionMode): Result<WB> = requiredPhotographyOption(functionMode, PhotographyOptionType.WHITE_BALANCE)

    override suspend fun fetchWhiteBalance(functionMode: FunctionMode): Result<WB> = fetchPhotographyOption(functionMode, PhotographyOptionType.WHITE_BALANCE)

    override suspend fun setWhiteBalance(functionMode: FunctionMode, wb: WB): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.WHITE_BALANCE, wb)

    override fun getWhiteBalanceValue(functionMode: FunctionMode): Result<WB> = requiredPhotographyOption(functionMode, PhotographyOptionType.WHITE_BALANCE_VALUE)

    override suspend fun fetchWhiteBalanceValue(functionMode: FunctionMode): Result<WB> = fetchPhotographyOption(functionMode, PhotographyOptionType.WHITE_BALANCE_VALUE)

    override suspend fun setWhiteBalanceValue(functionMode: FunctionMode, wb: WB): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.WHITE_BALANCE_VALUE, wb)

    override fun getFovType(functionMode: FunctionMode): Result<FovType> = requiredPhotographyOption(functionMode, PhotographyOptionType.FOV_TYPE)

    override suspend fun fetchFovType(functionMode: FunctionMode): Result<FovType> = fetchPhotographyOption(functionMode, PhotographyOptionType.FOV_TYPE)

    override suspend fun setFovType(functionMode: FunctionMode, fovType: FovType): Result<Unit> = setPhotographyOption(functionMode, PhotographyOptionType.FOV_TYPE, fovType)

    override fun getFlowstateBaseEnable(functionMode: FunctionMode): Result<Boolean> =
        requiredPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_BASE_TYPE)

    override suspend fun fetchFlowstateBaseEnable(functionMode: FunctionMode): Result<Boolean> =
        fetchPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_BASE_TYPE)

    override fun getFlowStateLevel(functionMode: FunctionMode): Result<FlowStateLevel> = requiredPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_LEVEL)

    override suspend fun fetchFlowStateLevel(functionMode: FunctionMode): Result<FlowStateLevel> = fetchPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_LEVEL)

    override suspend fun setFlowStateLevel(functionMode: FunctionMode, flowStateLevel: FlowStateLevel): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_LEVEL, flowStateLevel)

    override fun getFlowStateLevelCv5(functionMode: FunctionMode): Result<FlowStateLevel> = requiredPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5)

    override suspend fun fetchFlowStateLevelCv5(functionMode: FunctionMode): Result<FlowStateLevel> =
        fetchPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5)

    override suspend fun setFlowStateLevelCv5(functionMode: FunctionMode, flowStateLevel: FlowStateLevel): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.FLOWSTATE_LEVEL_BY_CV5, flowStateLevel)

    override fun getPhotographySelfTimer(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.PHOTOGRAPHY_SELF_TIMER)

    override suspend fun fetchPhotographySelfTimer(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.PHOTOGRAPHY_SELF_TIMER)

    override suspend fun setPhotographySelfTimer(functionMode: FunctionMode, selfTimer: Int): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.PHOTOGRAPHY_SELF_TIMER, selfTimer)

    override fun getVideoSelfieMode(functionMode: FunctionMode): Result<VideoSelfieMode> = requiredPhotographyOption(functionMode, PhotographyOptionType.VIDEO_SELFIE_MODE)

    override suspend fun fetchVideoSelfieMode(functionMode: FunctionMode): Result<VideoSelfieMode> = fetchPhotographyOption(functionMode, PhotographyOptionType.VIDEO_SELFIE_MODE)

    override suspend fun setVideoSelfieMode(functionMode: FunctionMode, videoSelfieMode: VideoSelfieMode): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.VIDEO_SELFIE_MODE, videoSelfieMode)

    override fun getRecordResolution(functionMode: FunctionMode): Result<RecordResolution> = requiredPhotographyOption(functionMode, PhotographyOptionType.RECORD_RESOLUTION)

    override suspend fun fetchRecordResolution(functionMode: FunctionMode): Result<RecordResolution> = fetchPhotographyOption(functionMode, PhotographyOptionType.RECORD_RESOLUTION)

    override suspend fun setRecordResolution(functionMode: FunctionMode, recordResolution: RecordResolution): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.RECORD_RESOLUTION, recordResolution)

    override fun getVideoIsoTopLimit(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.VIDEO_ISO_TOP_LIMIT)

    override suspend fun fetchVideoIsoTopLimit(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.VIDEO_ISO_TOP_LIMIT)

    override suspend fun setVideoIsoTopLimit(functionMode: FunctionMode, isoTopLimit: Int): Result<Unit> {
        val exposure: Result<Exposure> = requiredPhotographyOption(functionMode, PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS)
        return exposure.flatMap { value ->
            val autoExposure = Exposure(value.program, 0, value.shutterSpeed)
            val photographyOption = mutableMapOf<PhotographyOptionType, Any>()
            photographyOption[PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS] = autoExposure as Any
            photographyOption[PhotographyOptionType.VIDEO_ISO_TOP_LIMIT] = isoTopLimit as Any
            val mapTransform = PhotographyOptionMapper.mapTransform(photographyOption)
            setPhotographyOptions(functionMode, mapTransform)
        }
    }

    override fun getExportType(functionMode: FunctionMode): Result<ExportType> = requiredPhotographyOption(functionMode, PhotographyOptionType.STARLAPSE_EXPORT_TYPE)

    override suspend fun fetchExportType(functionMode: FunctionMode): Result<ExportType> = fetchPhotographyOption(functionMode, PhotographyOptionType.STARLAPSE_EXPORT_TYPE)

    override suspend fun setExportType(functionMode: FunctionMode, exportType: ExportType): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.STARLAPSE_EXPORT_TYPE, exportType)

    override fun getPanoExposureMode(functionMode: FunctionMode): Result<PanoExposureMode> = requiredPhotographyOption(functionMode, PhotographyOptionType.PANO_EXPOSURE_MODE)

    override suspend fun fetchPanoExposureMode(functionMode: FunctionMode): Result<PanoExposureMode> =
        fetchPhotographyOption(functionMode, PhotographyOptionType.PANO_EXPOSURE_MODE)

    override suspend fun setPanoExposureMode(functionMode: FunctionMode, exposureMode: PanoExposureMode): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.PANO_EXPOSURE_MODE, exposureMode)

    override fun getPhotoSize(functionMode: FunctionMode): Result<PhotoSize> = requiredPhotographyOption(functionMode, PhotographyOptionType.PHOTO_SIZE_ID)

    override suspend fun fetchPhotoSize(functionMode: FunctionMode): Result<PhotoSize> = fetchPhotographyOption(functionMode, PhotographyOptionType.PHOTO_SIZE_ID)

    override suspend fun setPhotoSize(functionMode: FunctionMode, photoSize: PhotoSize): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.PHOTO_SIZE_ID, photoSize)

    override fun getAccelerateFrequency(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.ACCELERATE_FREQUENCY)

    override suspend fun fetchAccelerateFrequency(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.ACCELERATE_FREQUENCY)

    override suspend fun setAccelerateFrequency(functionMode: FunctionMode, accelerateFrequency: Int): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.ACCELERATE_FREQUENCY, accelerateFrequency)

    override fun getRecordDuration(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.RECORD_DURAION)

    override suspend fun fetchRecordDuration(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.RECORD_DURAION)

    override suspend fun setRecordDuration(functionMode: FunctionMode, recordDuration: Int): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.RECORD_DURAION, recordDuration)

    override fun getMaxRecordDuration(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.MAX_REC_TIME)

    override suspend fun fetchMaxRecordDuration(functionMode: FunctionMode): Result<Int> =
        fetchPhotographyOption(functionMode, PhotographyOptionType.MAX_REC_TIME)

    override suspend fun setMaxRecordDuration(functionMode: FunctionMode, recordDuration: Int): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.MAX_REC_TIME, recordDuration)

    override fun getResolutionRecordLimits(functionMode: FunctionMode): Result<List<ResolutionRecordLimit>> =
        requiredPhotographyOption(functionMode, PhotographyOptionType.RES_REC_LIMIT)

    override suspend fun fetchResolutionRecordLimits(functionMode: FunctionMode): Result<List<ResolutionRecordLimit>> =
        fetchPhotographyOption(functionMode, PhotographyOptionType.RES_REC_LIMIT)

    override suspend fun setResolutionRecordLimits(functionMode: FunctionMode, resolutionRecordLimits: List<ResolutionRecordLimit>): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.RES_REC_LIMIT, resolutionRecordLimits)

    override fun getStillExposure(functionMode: FunctionMode): Result<Exposure> = requiredPhotographyOption(functionMode, PhotographyOptionType.STILL_EXPOSURE_OPTIONS)

    override suspend fun fetchStillExposure(functionMode: FunctionMode): Result<Exposure> = fetchPhotographyOption(functionMode, PhotographyOptionType.STILL_EXPOSURE_OPTIONS)

    override suspend fun setStillExposure(functionMode: FunctionMode, exposure: Exposure): Result<Unit> {
        val photographyOption = mutableMapOf<PhotographyOptionType, Any>()
        photographyOption[PhotographyOptionType.STILL_EXPOSURE_OPTIONS] = exposure as Any
        photographyOption[PhotographyOptionType.VIDEO_ISO_TOP_LIMIT] = 0 as Any

        val mapTransform = PhotographyOptionMapper.mapTransform(photographyOption)

        return setPhotographyOptions(functionMode, mapTransform)
    }

    override fun getVideoExposure(functionMode: FunctionMode): Result<Exposure> = requiredPhotographyOption(functionMode, PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS)

    override suspend fun fetchVideoExposure(functionMode: FunctionMode): Result<Exposure> = fetchPhotographyOption(functionMode, PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS)

    override suspend fun setVideoExposure(functionMode: FunctionMode, exposure: Exposure): Result<Unit> {
        val photographyOption = mutableMapOf<PhotographyOptionType, Any>()
        photographyOption[PhotographyOptionType.VIDEO_EXPOSURE_OPTIONS] = exposure as Any
        photographyOption[PhotographyOptionType.VIDEO_ISO_TOP_LIMIT] = 0 as Any
        val mapTransform = PhotographyOptionMapper.mapTransform(photographyOption)
        return setPhotographyOptions(functionMode, mapTransform)

    }

    // Burst
    override fun getBurstCaptureNum(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.BURST_CAPTURE_NUM)
    override suspend fun fetchBurstCaptureNum(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.BURST_CAPTURE_NUM)
    override suspend fun setBurstCaptureNum(functionMode: FunctionMode, burstCaptureNum: Int): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.BURST_CAPTURE_NUM, burstCaptureNum)

    override fun getBurstCaptureTime(functionMode: FunctionMode): Result<Int> = requiredPhotographyOption(functionMode, PhotographyOptionType.BURST_CAPTURE_TIME)

    //Burst2
    override suspend fun setBurstCaptureParams(functionMode: FunctionMode, burstCaptureNum: Int, burstCaptureTime: Int): Result<Unit> = setPhotographyOptions(
        functionMode, mapOf(PhotographyOptionType.BURST_CAPTURE_NUM to burstCaptureNum, PhotographyOptionType.BURST_CAPTURE_TIME to burstCaptureTime)
    )

    override suspend fun fetchBurstCaptureTime(functionMode: FunctionMode): Result<Int> = fetchPhotographyOption(functionMode, PhotographyOptionType.BURST_CAPTURE_TIME)

    override suspend fun setBurstCaptureTime(functionMode: FunctionMode, burstCaptureTime: Int): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.BURST_CAPTURE_TIME, burstCaptureTime)

    override fun getVideoGammaMode(functionMode: FunctionMode): Result<VideoGammaMode> = requiredPhotographyOption(functionMode, PhotographyOptionType.VIDEO_GAMMA_MODE)

    override suspend fun fetchVideoGammaMode(functionMode: FunctionMode): Result<VideoGammaMode> = fetchPhotographyOption(functionMode, PhotographyOptionType.VIDEO_GAMMA_MODE)

    override suspend fun setVideoGammaMode(functionMode: FunctionMode, gammaMode: VideoGammaMode): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.VIDEO_GAMMA_MODE, gammaMode)

    override fun getPhotoHdrType(functionMode: FunctionMode): Result<PhotoHdrType> = requiredPhotographyOption(functionMode, PhotographyOptionType.PHOTO_HDR_TYPE)

    override suspend fun fetchPhotoHdrType(functionMode: FunctionMode): Result<PhotoHdrType> = fetchPhotographyOption(functionMode, PhotographyOptionType.PHOTO_HDR_TYPE)

    override suspend fun setPhotoHdrType(functionMode: FunctionMode, photoHdrType: PhotoHdrType): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.PHOTO_HDR_TYPE, photoHdrType)

    override fun getHdrSwitch(functionMode: FunctionMode): Result<Boolean> = requiredPhotographyOption(functionMode, PhotographyOptionType.HDR_SWITCH_STATUS)

    override suspend fun fetchHdrSwitch(functionMode: FunctionMode): Result<Boolean> = fetchPhotographyOption(functionMode, PhotographyOptionType.HDR_SWITCH_STATUS)

    override suspend fun setHdrSwitch(functionMode: FunctionMode, hdrSwitch: Boolean): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.HDR_SWITCH_STATUS, hdrSwitch)

    override fun getP3Switch(functionMode: FunctionMode): Result<Boolean> = requiredPhotographyOption(functionMode, PhotographyOptionType.P3_SWITCH)

    override suspend fun fetchP3Switch(functionMode: FunctionMode): Result<Boolean> = fetchPhotographyOption(functionMode, PhotographyOptionType.P3_SWITCH)

    override suspend fun setP3Switch(functionMode: FunctionMode, hdrSwitch: Boolean): Result<Unit> = setPhotographyOption(functionMode, PhotographyOptionType.P3_SWITCH, hdrSwitch)

    override fun getILogSwitch(functionMode: FunctionMode): Result<Boolean> = requiredPhotographyOption(functionMode, PhotographyOptionType.I_LOG_SWITCH)

    override suspend fun fetchILogSwitch(functionMode: FunctionMode): Result<Boolean> = fetchPhotographyOption(functionMode, PhotographyOptionType.I_LOG_SWITCH)

    override suspend fun setILogSwitch(functionMode: FunctionMode, iLogSwitch: Boolean): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.I_LOG_SWITCH, iLogSwitch)

    override fun getDoubleZoomEnable(functionMode: FunctionMode): Result<Boolean> = requiredPhotographyOption(functionMode, PhotographyOptionType.DOUBLE_ZOOM)

    override suspend fun fetchDoubleZoomEnable(functionMode: FunctionMode): Result<Boolean> = fetchPhotographyOption(functionMode, PhotographyOptionType.DOUBLE_ZOOM)

    override suspend fun setDoubleZoomEnable(functionMode: FunctionMode, enable: Boolean): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.DOUBLE_ZOOM, enable)

    override fun getPureVideoEnhancSwitch(functionMode: FunctionMode): Result<Boolean> = requiredPhotographyOption(functionMode, PhotographyOptionType.PURE_VIDEO_ENHANC_TYPE)

    override suspend fun fetchPureVideoEnhancSwitch(functionMode: FunctionMode): Result<Boolean> =
        fetchPhotographyOption(functionMode, PhotographyOptionType.PURE_VIDEO_ENHANC_TYPE)

    override suspend fun setPureVideoEnhancSwitch(functionMode: FunctionMode, pureVideoEnhancSwitch: Boolean): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.PURE_VIDEO_ENHANC_TYPE, pureVideoEnhancSwitch)

    override fun getLivePhotoMode(functionMode: FunctionMode): Result<Boolean> = requiredPhotographyOption(functionMode, PhotographyOptionType.LIVEPHOTO_MODE)

    override suspend fun fetchLivePhotoMode(functionMode: FunctionMode): Result<Boolean> = fetchPhotographyOption(functionMode, PhotographyOptionType.LIVEPHOTO_MODE)

    override suspend fun setLivePhotoMode(functionMode: FunctionMode, livePhotoMode: Boolean): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.LIVEPHOTO_MODE, livePhotoMode)

    override fun getZoomScale(functionMode: FunctionMode): Result<Double> = requiredPhotographyOption(functionMode, PhotographyOptionType.ZOOM_SCALE)
    override suspend fun fetchZoomScale(functionMode: FunctionMode): Result<Double> = fetchPhotographyOption(functionMode, PhotographyOptionType.ZOOM_SCALE)
    override suspend fun setZoomScale(functionMode: FunctionMode, zoomScale: Double): Result<Unit> = setPhotographyOption(functionMode, PhotographyOptionType.ZOOM_SCALE, zoomScale)

    override fun getIq3AMode(functionMode: FunctionMode): Result<Iq3AMode> = requiredPhotographyOption(functionMode, PhotographyOptionType.IQ_3A_MODE)
    override suspend fun fetchIq3AMode(functionMode: FunctionMode): Result<Iq3AMode> = fetchPhotographyOption(functionMode, PhotographyOptionType.IQ_3A_MODE)
    override suspend fun setIq3AMode(functionMode: FunctionMode, mode: Iq3AMode): Result<Unit> = setPhotographyOption(functionMode, PhotographyOptionType.IQ_3A_MODE, mode)

    override fun getFocalLength(functionMode: FunctionMode): Result<Double> = requiredPhotographyOption(functionMode, PhotographyOptionType.FOCAL_LENGTH_VALUE)
    override suspend fun fetchFocalLength(functionMode: FunctionMode): Result<Double> = fetchPhotographyOption(functionMode, PhotographyOptionType.FOCAL_LENGTH_VALUE)
    override suspend fun setFocalLength(functionMode: FunctionMode, focalLength: Double): Result<Unit> =
        setPhotographyOption(functionMode, PhotographyOptionType.FOCAL_LENGTH_VALUE, focalLength)

    override suspend fun fetchAllPhotographyOptions(functionMode: FunctionMode): Result<Unit> {
        return context.cameraConfig?.getSyncPhotographyOptionsGroups()?.let { groups ->
            groups.asFlow()
                // 遍历每个模式，执行获取操作
                .map { group -> fetchPhotographyOptions(functionMode, group) }
                // 只保留失败的结果
                .filter { it.isFailure }
                // 取最后一个失败结果（无则返回成功）
                .lastOrNull() ?: Result.success(Unit)
        } ?: Result.failure(CameraNotConnectedException())
    }

    override suspend fun fetchMorePhotographyOptions(functionMode: FunctionMode, optionsTypes: List<PhotographyOptionType>): Result<Unit> {
        return fetchPhotographyOptions(functionMode, optionsTypes).fold(
            onSuccess = { Result.success(Unit) },
            onFailure = { Result.failure(CameraNotConnectedException()) }
        )
    }

    override suspend fun fetchAllPhotographyOptions(): Result<Unit> {
        return FunctionMode.entries
            // 过滤掉 NONE 模式
            .filter { it != FunctionMode.NONE }
            // 转为 Flow 流处理
            .asFlow()
            // 遍历每个模式，执行获取操作
            .map { mode -> fetchAllPhotographyOptions(mode) }
            // 只保留失败的结果
            .filter { it.isFailure }
            // 取最后一个失败结果（无则返回成功）
            .lastOrNull() ?: Result.success(Unit)
    }

    override suspend fun fetchPhotographyOptions(functionMode: FunctionMode, photographyOptionList: List<PhotographyOptionType>): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            Logger.d(TAG, "fetchPhotographyOptions, functionMode=$functionMode   photographyOptionList=$photographyOptionList")
            val call = coroutineCallback {
                success {
                    if (continuation.isActive) {
                        val newCache = PhotographyOptionMapper.photographyOptions2Map(photographyOptionList, it).filterValues { v -> v != null }
                        photographyOptionCacheMutex.withLock {
                            Logger.d(TAG, "fetchPhotographyOptions, functionMode=$functionMode  newCache=$newCache")
                            if (photographyOptionCache.contains(functionMode)) {
                                photographyOptionCache[functionMode]?.putAll(newCache)
                            } else {
                                photographyOptionCache.put(functionMode, newCache.toMutableMap())
                            }
                        }
                        continuation.resume(Result.success(Unit))
                    }
                }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.getPhotographyOption(functionMode.nativeValue, photographyOptionList)
                photographyCallbackMutex.withLock {
                    photographyCallbackMap[id] = call
                }
            }
        }
    }

    private suspend fun <T> fetchPhotographyOption(functionMode: FunctionMode, photographyOptionType: PhotographyOptionType): Result<T> {
        return fetchPhotographyOptions(functionMode, listOf(photographyOptionType)).flatMap {
            requiredPhotographyOption(functionMode, photographyOptionType)
        }
    }

    private fun <T> requiredPhotographyOption(functionMode: FunctionMode, photographyOptionType: PhotographyOptionType): Result<T> =
        getPhotographyOption<T>(functionMode, photographyOptionType)?.success() ?: Result.failure(PhotographyOptionValueNullException(photographyOptionType.toString()))

    @Suppress("UNCHECKED_CAST")
    private fun <T> getPhotographyOption(functionMode: FunctionMode, photographyOptionType: PhotographyOptionType): T? =
        photographyOptionCache[functionMode]?.let { PhotographyOptionMapper.photographyOptionTransform(functionMode, photographyOptionType, it) as? T }


    private suspend fun <T> setPhotographyOption(functionMode: FunctionMode, photographyOptionType: PhotographyOptionType, data: T): Result<Unit> {
        val photographyOption = mutableMapOf<PhotographyOptionType, Any>()
        photographyOption[photographyOptionType] = data as Any
        val mapTransform = PhotographyOptionMapper.mapTransform(photographyOption)
        return setPhotographyOptions(functionMode, mapTransform)
    }

    override suspend fun setPhotographyOptions(functionMode: FunctionMode, photographyOptions: Map<PhotographyOptionType, Any>): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = coroutineCallback<Unit> {
                success {
                    if (continuation.isActive) {
                        photographyOptionCacheMutex.withLock { photographyOptionCache[functionMode]?.putAll(photographyOptions) }
                        continuation.resume(Unit.success())
                    }
                }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            val id = context.transport.setPhotographyOption(
                functionMode.nativeValue, photographyOptions.keys.toList(), PhotographyOptionMapper.map2PhotographyOptions(photographyOptions)
            )
            context.scope.launch {
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun release() {
        callbackMutex.withLock { callbackMap.clear() }
        photographyCallbackMutex.withLock { photographyCallbackMap.clear() }
    }
}