package com.arashivision.sdk.camera.platform

import com.arashivision.insta360.camerastream.StreamDelegate
import com.arashivision.insta360.camerastream.bean.AudioCodec
import com.arashivision.insta360.camerastream.listener.ICameraLiveStateListener
import com.arashivision.insta360.camerastream.listener.InfoUpdateListener
import com.arashivision.insta360.camerastream.render.RenderMethod
import com.arashivision.insta360.camerastream.render.RenderMode
import com.arashivision.onestream.CameraFrameRenderMode
import com.arashivision.sdk.camera.core.model.LiveType
import com.arashivision.sdk.camera.service.preview.PreviewParams
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.common.type.KMPCameraPreviewPipeline
import com.arashivision.sdk.common.type.KMPContext

/**
 * 包装 camerastream 库的 CameraDelegate
 */
actual class PlatformCameraStream actual constructor() {
    private var streamDelegate: StreamDelegate? = null

    actual fun init(context: KMPContext?) {
        context?.let {
            streamDelegate =
                StreamDelegate().apply {
                init(it)
            }
        }
    }

    actual fun openPreviewStream(
        isForLive: Boolean,
        previewParams: PreviewParams,
        isDualStream: Boolean,
        mediaOffset: String,
    ) {
        val audioCodec = if (isForLive) AudioCodec.ADTS else AudioCodec.RAW
        val renderMode =
            if (isForLive) RenderMode.withGlRenderer(RenderMethod.PlanarKeep) else RenderMode.directDecoding()
        streamDelegate?.openPreviewStream(
            previewParams.firstStream.toVideoParam(),
            previewParams.secondStream.toVideoParam(),
            audioCodec,
            renderMode,
            isForLive,
            previewParams.previewNum,
            isDualStream,
            mediaOffset,
            false,
        )
    }

    actual fun closePreviewStream() {
        streamDelegate?.closePreviewStream()
    }

    actual fun setH265Encode(isH265: Boolean) {
        streamDelegate?.setStreamEncode(isH265)
    }

    actual fun isH265Encode(): Boolean = streamDelegate?.isH265StreamEncode ?: false

    actual fun processStreamData(type: Int, data: ByteArray, timestamp: Long){
        streamDelegate?.processStreamData(type, data, timestamp)
    }

    actual fun setPipeline(pipeline: KMPCameraPreviewPipeline?) {
        streamDelegate?.setPipeline(pipeline)
    }

    actual internal fun startLive(
        rtmpUrl: String,
        width: Int,
        height: Int,
        fps: Int,
        bitrate: Int,
        netId: Long,
        liveType: LiveType,
        callback: LiveStreamCallback,
    ) {
        val delegate = streamDelegate ?: run {
            Logger.w(TAG, "startLive skipped: streamDelegate not initialized")
            callback.onFailed(-1, "streamDelegate 未初始化")
            return
        }
        val (cameraFrameRenderMode, previewToLive, isSpherical) = when (liveType) {
            LiveType.PANO_STITCH  -> Triple(CameraFrameRenderMode.CAMERA_STREAM_RENDER_PLANE_STITCH,   false, true)
            LiveType.PANO_CAPTURE -> Triple(CameraFrameRenderMode.CAMERA_SCREEN_CAPTURE_SPHERE_RENDER, false, true)
            LiveType.PLANE        -> Triple(CameraFrameRenderMode.CAMERA_SCREEN_CAPTURE_DEWARP_RENDER,  true, false)
        }
        // 推流状态回调桥接到 LiveStreamCallback；终态(onStopped/onFailed)后置空监听
        delegate.setCameraLiveListener(
            object : ICameraLiveStateListener {
                override fun onRecordComplete(path: String?) {
                    Logger.i(TAG, "startLive onRecordComplete path=$path")
                    delegate.setCameraLiveListener(null, null)
                    callback.onStopped()
                }

                override fun onRecordError(err: Int, extra: Int, domain: String?, desc: String?, path: String?) {
                    Logger.w(TAG, "startLive onRecordError err=$err extra=$extra domain=$domain desc=$desc")
                    delegate.setCameraLiveListener(null, null)
                    callback.onFailed(err, desc)
                }
            },
            object : InfoUpdateListener {
                override fun onRecordFpsUpdate(fps: Int) {
                    callback.onFps(fps)
                }

                override fun onLivePushStarted(url: String?) {
                    Logger.i(TAG, "startLive onLivePushStarted url=${url?.substringBefore("?")}")
                    callback.onStarted()
                }

                override fun onCameraInfoNotify(type: Int, error: Int, obj: Any?) {
                    Logger.d(TAG, "startLive onCameraInfoNotify type=$type error=$error")
                }
            },
        )
        delegate.startLive(
            width = width,
            height = height,
            fps = fps,
            bitrate = bitrate,
            path = rtmpUrl,
            cameraFrameRenderMode = cameraFrameRenderMode,
            netId = netId,
            previewToLive = previewToLive,
            isSpherical = isSpherical,
        )
        Logger.i(TAG, "startLive rtmp=${rtmpUrl.substringBefore("?")} ${width}x${height}@${fps} bitrate=${bitrate}Mbps netId=$netId liveType=$liveType")
    }

    actual fun stopLive() {
        streamDelegate?.stopLive()
        Logger.i(TAG, "stopLive")
    }

    private companion object {
        private const val TAG = "PlatformCameraStream"
    }
}
