package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.FunctionType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.core.model.photography.Exposure.ExposureProgram
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.kotlin.toFraction

internal class ExposureCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>, deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<ExposureProgram>(CommonAttrKeys.EXPOSURE_PROGRAM, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): ExposureProgram = ExposureProgram.UNKNOWN

    override fun fromInt(value: Int): ExposureProgram {
        return ExposureProgram.nativeOf(value)
    }

    override fun fromName(name: String): ExposureProgram {
        return ExposureProgram.protoOf(name)
    }

    override fun toInt(data: ExposureProgram): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<ExposureProgram> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.getVideoExposure(functionMode)
        } else {
            device.getStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.map {
            it.program
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<ExposureProgram> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.fetchVideoExposure(functionMode)
        } else {
            device.fetchStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.map {
            it.program
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: ExposureProgram): Result<Unit> {
        val iso = managerProvider().getOrNull()?.getAttrValueInt(CommonAttrKeys.EXPOSURE_ISO)?.getOrNull() ?: 0
        val shutter = managerProvider().getOrNull()?.getAttrValue(CommonAttrKeys.EXPOSURE_SHUTTER_SPEED)?.getOrNull()?.toFraction() ?: (1.0 to 0.0)
        val exposure = Exposure(value, iso, shutter)

        return device.setVideoExposure(functionMode, exposure).flatMap {
            if (functionMode.functionType != FunctionType.VIDEO) {
                device.setStillExposure(functionMode, exposure)
            } else {
                Unit.success()
            }
        }.thenMirrorVideoLiveIfNeeded(device, functionMode) {
            device.setVideoExposure(FunctionMode.VIDEO_LIVE, exposure)
        }
    }

}