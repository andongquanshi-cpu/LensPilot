package com.arashivision.sdk.camera.api

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.sdk.camera.api.param.listener.AuthorizationListener
import com.arashivision.sdk.camera.api.param.listener.BleWakeUpListener
import com.arashivision.sdk.camera.api.param.listener.DisconnectListener
import com.arashivision.sdk.camera.core.callback.BleScanCallback
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationStatus
import com.arashivision.sdk.camera.service.CameraDeviceInternal
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.type.KMPBleDevice

/**
 * 相机设备的核心接口。
 *
 * 提供了对相机设备的连接管理、状态查询以及各个功能模块（系统、拍摄、预览、文件、固件）的访问入口。
 * 外部调用方应通过此接口与相机进行交互。
 */
interface CameraDevice {
    /** 
     * 相机系统服务，提供电量、存储、硬件信息、相机设置等系统级功能。 
     */
    val system: CameraSystem

    /** 
     * 相机拍摄服务，提供拍照、录像、拍摄参数设置等功能。 
     */
    val capture: CameraCapture

    /** 
     * 相机预览服务，提供开启/关闭预览流及获取预览数据等功能。 
     */
    val preview: CameraPreview

    /** 
     * 相机文件服务，提供相机内部媒体文件的列表获取、下载、删除等功能。 
     */
    val file: CameraFile

    /** 
     * 相机固件服务，提供固件版本查询及固件升级功能。 
     */
    val firmware: CameraFirmware

    /**
     * 检查当前是否已连接到相机。
     *
     * @return 如果已连接返回 true，否则返回 false。
     */
    fun isConnected(): Boolean

    /**
     * 扫描附近的相机设备（主要用于蓝牙连接）。
     *
     * @param timeoutMs 扫描超时时间，单位为毫秒。
     * @param bleScanCallback 扫描结果的回调接口。
     */
    fun scan(timeoutMs: Long, bleScanCallback: BleScanCallback)

    /**
     * 停止扫描相机设备。
     */
    fun stopScan()

    /**
     * 唤醒蓝牙设备。
     */
    fun bleWakeUp(cameraType: CameraType, deviceName: String, listener: BleWakeUpListener)

    /**
     * 连接到指定的相机设备（回调的方式）。
     *
     * @param connectHint 连接提示信息（例如 Wi-Fi SSID、蓝牙 MAC 地址或特定的连接配置对象）。
     * @param callback 连接结果的回调。成功时返回 Unit，失败时返回异常。
     */
    fun connect(connectHint: Any? = null, callback: Callback<Unit>)

    /**
     * 连接到指定的相机设备（协程挂起函数的方式）。
     *
     * @param connectHint 连接提示信息（例如 Wi-Fi SSID、蓝牙 MAC 地址或特定的连接配置对象）。
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    suspend fun connect(connectHint: Any? = null, isBleOnly: Boolean = true): Result<Unit>

    /**
     * 通过蓝牙连接到指定的相机设备（协程挂起函数的方式）。
     *
     * @param bleDeviceCore sdk指定的蓝牙对象
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    suspend fun connectBle(bleDeviceCore: BleDeviceCore, isBleOnly: Boolean = true): Result<Unit>

    /**
     * 通过蓝牙连接到指定的相机设备（协程挂起函数的方式）。
     *
     * @param kmpBleDevice 系统蓝牙对象，android：BluetoothDevice, ios:CBPeripheral
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    suspend fun connectBle(kmpBleDevice: KMPBleDevice, isBleOnly: Boolean = true): Result<Unit>

    /**
     * 通过蓝牙连接到指定的相机设备（回调的方式）。
     *
     * @param bleDeviceCore sdk指定的蓝牙对象
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    fun connectBle(bleDeviceCore: BleDeviceCore, isBleOnly: Boolean = true, callback: Callback<Unit>)

    /**
     * 通过蓝牙连接到指定的相机设备（回调的方式）。
     *
     * @param kmpBleDevice 系统蓝牙对象，android：BluetoothDevice, ios:CBPeripheral
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    fun connectBle(kmpBleDevice: KMPBleDevice, isBleOnly: Boolean = true, callback: Callback<Unit>)

    /**
     * 通过Wi-Fi连接到指定的相机设备（协程挂起函数的方式）。
     *
     * @param networkId Wi-Fi的网络ID
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    suspend fun connectWiFi(networkId: Int): Result<Unit>

    /**
     * 通过Wi-Fi连接到指定的相机设备（回调的方式）。
     *
     * @param networkId Wi-Fi的网络ID
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    fun connectWiFi(networkId: Int, callback: Callback<Unit>)

    /**
     * 通过 WiFi Aware（NAN）连接到相机（协程挂起函数的方式）。
     *
     * App 须在外部完成 NAN 握手后，将协商结果传入。
     *
     * @param networkHandle App 侧 NAN 握手成功后从 [android.net.Network.getNetworkHandle] 获取的网络句柄。
     * @param peerIpv6 从 [android.net.wifi.aware.WifiAwareNetworkInfo.getPeerIpv6Addr] 获取的相机 peer IPv6 地址。
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。iOS 平台直接返回失败。
     */
    suspend fun connectWiFiAware(networkHandle: Long, peerIpv6: String): Result<Unit>

    /**
     * 通过 WiFi Aware（NAN）连接到相机（回调的方式）。
     *
     * App 须在外部完成 NAN 握手后，将协商结果传入。
     *
     * @param networkHandle App 侧 NAN 握手成功后从 [android.net.Network.getNetworkHandle] 获取的网络句柄。
     * @param peerIpv6 从 [android.net.wifi.aware.WifiAwareNetworkInfo.getPeerIpv6Addr] 获取的相机 peer IPv6 地址。
     * @param callback 连接结果的回调。成功时返回 Unit，失败时返回异常。
     */
    fun connectWiFiAware(networkHandle: Long, peerIpv6: String, callback: Callback<Unit>)

    /**
     * 通过USB连接到指定的相机设备（协程挂起函数的方式）。
     *
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    suspend fun connectUsb(): Result<Unit>

    /**
     * 通过USB连接到指定的相机设备（回调的方式）。
     *
     * @return 返回连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    fun connectUsb(callback: Callback<Unit>)

    /**
     * 断开与当前相机的连接（协程挂起函数的方式）。
     *
     * @return 返回断开连接结果的 [Result] 对象。成功时包含 Unit，失败时包含异常。
     */
    suspend fun disconnect(): Result<Unit>

    /**
     * 断开与当前相机的连接（回调的方式）。
     *
     * @param callback 断开连接结果的回调。成功时返回 Unit，失败时返回异常。
     */
    fun disconnect(callback: Callback<Unit>)

    /**
     * 获取当前连接类型下支持的相机型号列表。
     *
     * @return 支持的相机型号 [CameraType] 列表。
     */
    fun getSupportCameraType(): List<CameraType>

    /**
     * 释放当前设备对象的所有资源。
     * 调用此方法后，该对象将被标记为已销毁，不能再执行任何操作。
     */
    fun release()

    // ------------------- 断连监听 -------------------

    /**
     * 注册相机断开连接的监听器。
     *
     * @param listener 需要注册的断连监听器 [DisconnectListener]。
     */
    fun registerDisconnectListener(listener: DisconnectListener)

    /**
     * 注销相机断开连接的监听器。
     *
     * @param listener 需要注销的断连监听器 [DisconnectListener]。
     */
    fun unregisterDisconnectListener(listener: DisconnectListener)

    // ------------------- 授权 -------------------

    /**
     * 检查当前设备是否已被相机授权（协程挂起方式）。
     *
     * 返回 [AuthorizationStatus.AUTHORIZED] 表示已授权；
     * 返回 [AuthorizationStatus.UNAUTHORIZED] 表示相机端将显示授权确认弹窗，
     * 用户在相机上确认/拒绝后结果通过 [AuthorizationListener] 回调；
     * 返回 [AuthorizationStatus.SYSTEM_BUSY] 表示相机繁忙。
     */
    suspend fun checkAuthorization(): Result<AuthorizationStatus>

    /**
     * 检查当前设备是否已被相机授权（回调方式）。
     */
    fun checkAuthorization(callback: Callback<AuthorizationStatus>)

    /**
     * 取消当前正在进行的授权校验（协程挂起方式）。
     */
    suspend fun cancelAuthorization(): Result<Unit>

    /**
     * 取消当前正在进行的授权校验（回调方式）。
     */
    fun cancelAuthorization(callback: Callback<Unit>)

    /**
     * 注册相机端授权结果监听器。
     *
     * @param listener 需要注册的授权监听器 [AuthorizationListener]。
     */
    fun registerAuthorizationListener(listener: AuthorizationListener)

    /**
     * 注销相机端授权结果监听器。
     *
     * @param listener 需要注销的授权监听器 [AuthorizationListener]。
     */
    fun unregisterAuthorizationListener(listener: AuthorizationListener)

    companion object {
        /**
         * 获取 [CameraDevice] 实例的工厂方法。
         *
         * @param connectType 期望的连接类型（如 Wi-Fi、蓝牙等）。
         * @return 返回对应连接类型的 [CameraDevice] 实例。
         */
        fun get(connectType: ConnectType): CameraDevice {
            return CameraDeviceInternal(connectType)
        }
    }
}
