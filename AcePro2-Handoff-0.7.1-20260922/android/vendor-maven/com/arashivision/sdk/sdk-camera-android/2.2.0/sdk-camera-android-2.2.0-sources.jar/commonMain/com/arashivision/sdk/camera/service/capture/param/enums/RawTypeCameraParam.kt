package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.RawType
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class RawTypeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<RawType>(CommonAttrKeys.RAW_CAPTURE_TYPE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): RawType? = null

    override fun fromInt(value: Int): RawType {
        return RawType.nativeOf(value)
    }

    override fun fromName(name: String): RawType {
        return RawType.protoOf(name)
    }

    override fun toInt(data: RawType): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<RawType> {
        return device.getRawType(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<RawType> {
        return device.fetchRawType(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: RawType): Result<Unit> {
        return device.setRawType(functionMode, value)
    }

}