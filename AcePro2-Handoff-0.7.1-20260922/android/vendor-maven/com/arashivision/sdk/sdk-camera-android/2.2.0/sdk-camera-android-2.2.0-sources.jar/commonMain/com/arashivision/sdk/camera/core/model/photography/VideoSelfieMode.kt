package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class VideoSelfieMode(override val nativeValue: Int, val protoName: String) : BaseEnum {
    NONE(0, ""),
    ME_MODE(1, "me_mode"),
    TORCH_MODE(2, "torch_mode");

    companion object {
        fun nativeOf(value: Int?): VideoSelfieMode = entries.firstOrNull { it.nativeValue == value } ?: NONE
        fun protoOf(name: String?): VideoSelfieMode =
            entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: NONE
    }
}