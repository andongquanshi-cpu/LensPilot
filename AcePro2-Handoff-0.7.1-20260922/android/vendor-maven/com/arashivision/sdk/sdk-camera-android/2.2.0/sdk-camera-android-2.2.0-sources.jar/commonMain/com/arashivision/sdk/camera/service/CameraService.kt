package com.arashivision.sdk.camera.service

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.ConnectType
import kotlinx.coroutines.CoroutineScope

abstract class CameraService(
    protected val camera: DeviceCore,
    protected val connectType: ConnectType,
    protected val scope: CoroutineScope,
    protected val isDestroyed: () -> Boolean
) {
    abstract suspend fun destroy()
}