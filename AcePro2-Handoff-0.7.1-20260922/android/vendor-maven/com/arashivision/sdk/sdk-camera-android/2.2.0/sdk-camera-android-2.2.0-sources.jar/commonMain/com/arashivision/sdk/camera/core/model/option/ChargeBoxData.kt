package com.arashivision.sdk.camera.core.model.option

class ChargeBoxData(
    /**
     * 主机在位状态，不代表usb一定连接
     */
    val isConnect: Boolean,
    /**
     * 盒子与主机是否usb连接
     */
    val isUsbConnect: Boolean,
    /**
     * 盒子与主机是否蓝牙连接
     */
    val isBleConnect: Boolean,
    /**
     * 盒子是否开机
     */
    val isBoxPowerOn: Boolean,
    /**
     * 盒子电量状态
     */
    val batteryData: BatteryData
)