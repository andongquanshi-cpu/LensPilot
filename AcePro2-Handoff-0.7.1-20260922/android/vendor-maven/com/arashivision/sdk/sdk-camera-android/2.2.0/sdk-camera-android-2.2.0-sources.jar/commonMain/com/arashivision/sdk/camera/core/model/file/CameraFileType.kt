package com.arashivision.sdk.camera.core.model.file

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class CameraFileType(override val nativeValue: Int) : BaseEnum {
    UNKNOWN_FILE(0),
//
//    /**
//     * 相机埋点
//     */
//    ETK_FILE(1),

    /**
     * 相机日志
     */
    LOG_FILE(2),

    /**
     * 相机拍摄参数表
     */
    PARAMS_JSON_FILE(3);

//    /**
//     * 研究院参数表
//     */
//    PARAMS_RI_JSON_FILE(4);

    companion object {
        fun nativeOf(value: Int?): CameraFileType {
            return CameraFileType.entries.find { it.nativeValue == value } ?: UNKNOWN_FILE
        }
    }
}