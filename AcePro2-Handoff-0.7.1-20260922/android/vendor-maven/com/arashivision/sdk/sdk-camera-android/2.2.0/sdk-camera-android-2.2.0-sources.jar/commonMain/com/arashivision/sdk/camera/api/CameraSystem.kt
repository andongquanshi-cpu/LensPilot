package com.arashivision.sdk.camera.api

import com.arashivision.sdk.camera.api.param.listener.BatteryListener
import com.arashivision.sdk.camera.api.param.listener.ChargeBoxStatusListener
import com.arashivision.sdk.camera.api.param.listener.StorageStateListener
import com.arashivision.sdk.camera.api.param.listener.TemperatureListener
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.capture.LockScreenState
import com.arashivision.sdk.camera.core.model.option.BatteryData
import com.arashivision.sdk.camera.core.model.option.ChargeBoxData
import com.arashivision.sdk.camera.core.model.option.LanguageType
import com.arashivision.sdk.camera.core.model.option.LocalTime
import com.arashivision.sdk.camera.core.model.option.Sharpness
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.VideoEncode
import com.arashivision.sdk.camera.core.model.option.WiFiChannel
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.common.callback.Callback
import insta360.messages.Sensor
import insta360.messages.WindowCropInfo

/**
 * 相机系统服务接口。
 *
 * 提供了对相机系统级别状态的监听、硬件信息的获取以及系统设置的修改功能。
 * 包括电量、存储、温度、Wi-Fi 配置、设备激活、关机等。
 */
interface CameraSystem {
    // ------------------- 电量监听 -------------------
    /** 注册电池状态监听器。 */
    fun registerBatteryListener(listener: BatteryListener)

    /** 注销电池状态监听器。 */
    fun unregisterBatteryListener(listener: BatteryListener)

    // ------------------- 充电盒状态监听 -------------------
    /** 注册充电盒状态监听器。 */
    fun registerChargeBoxStatusListener(listener: ChargeBoxStatusListener)

    /** 注销充电盒状态监听器。 */
    fun unregisterChargeBoxStatusListener(listener: ChargeBoxStatusListener)

    // ------------------- 相机温度过高监听 -------------------
    /** 注册相机温度状态监听器。 */
    fun registerTemperatureListener(listener: TemperatureListener)

    /** 注销相机温度状态监听器。 */
    fun unregisterTemperatureListener(listener: TemperatureListener)

    // ------------------- 存储状态监听 -------------------
    /** 注册存储卡状态监听器。 */
    fun registerStorageStatusListener(listener: StorageStateListener)

    /** 注销存储卡状态监听器。 */
    fun unregisterStorageStatusListener(listener: StorageStateListener)

    /** 获取缓存的电池数据。 */
    fun getBatteryData(): Result<BatteryData>

    /** 从相机拉取最新的电池数据（挂起函数）。 */
    suspend fun fetchBatteryData(): Result<BatteryData>

    /** 从相机拉取最新的电池数据（回调方式）。 */
    fun fetchBatteryData(callback: Callback<BatteryData>)

    /** 获取缓存的充电盒数据。 */
    fun getChargeBoxData(): Result<ChargeBoxData>

    /** 从相机拉取最新的充电盒数据（挂起函数）。 */
    suspend fun fetchChargeBoxData(): Result<ChargeBoxData>

    /** 从相机拉取最新的充电盒数据（回调方式）。 */
    fun fetchChargeBoxData(callback: Callback<ChargeBoxData>)

    /** 获取缓存的静音状态。 */
    fun getMute(): Result<Boolean>

    /** 从相机拉取最新的静音状态（挂起函数）。 */
    suspend fun fetchMute(): Result<Boolean>

    /** 从相机拉取最新的静音状态（回调方式）。 */
    fun fetchMute(callback: Callback<Boolean>)

    /** 设置相机静音状态（回调方式）。 */
    fun setMute(enable: Boolean, callback: Callback<Unit>)

    /** 设置相机静音状态（挂起函数）。 */
    suspend fun setMute(enable: Boolean): Result<Unit>

    /** 获取缓存的相机序列号。 */
    fun getSerialNumber(): Result<String>

    /** 从相机拉取最新的序列号（挂起函数）。 */
    suspend fun fetchSerialNumber(): Result<String>

    /** 从相机拉取最新的序列号（回调方式）。 */
    fun fetchSerialNumber(callback: Callback<String>)

    /** 获取缓存的相机 UUID。 */
    fun getUuid(): Result<String>

    /** 从相机拉取最新的 UUID（挂起函数）。 */
    suspend fun fetchUuid(): Result<String>

    /** 从相机拉取最新的 UUID（回调方式）。 */
    fun fetchUuid(callback: Callback<String>)

    /** 获取缓存的原始偏移量。 */
    fun getOriginOffset(): Result<String>

    /** 从相机拉取最新的原始偏移量（挂起函数）。 */
    suspend fun fetchOriginOffset(): Result<String>

    /** 从相机拉取最新的原始偏移量（回调方式）。 */
    fun fetchOriginOffset(callback: Callback<String>)

    /** 获取缓存的相机激活时间。 */
    fun getActivateTime(): Result<Long>

    /** 从相机拉取最新的激活时间（挂起函数）。 */
    suspend fun fetchActivateTime(): Result<Long>

    /** 从相机拉取最新的激活时间（回调方式）。 */
    fun fetchActivateTime(callback: Callback<Long>)

    /** 设置相机激活时间（回调方式）。 */
    fun setActivateTime(activeTime: Long, callback: Callback<Unit>)

    /** 设置相机激活时间（挂起函数）。 */
    suspend fun setActivateTime(activeTime: Long): Result<Unit>

    /** 获取缓存的存储卡数据。 */
    @Deprecated("已废弃，请使用 getStorageDataList()", replaceWith = ReplaceWith("getStorageDataList()"), level = DeprecationLevel.WARNING)
    fun getStorageData(): Result<StorageData>

    /** 从相机拉取最新的存储卡数据（挂起函数）。 */
    @Deprecated("已废弃，请使用 fetchStorageDataList()", replaceWith = ReplaceWith("fetchStorageDataList()"), level = DeprecationLevel.WARNING)
    suspend fun fetchStorageData(): Result<StorageData>

    /** 从相机拉取最新的存储卡数据（回调方式）。 */
    @Deprecated(
        "已废弃，请使用 fetchStorageDataList(Callback<List<StorageData>>)",
        replaceWith = ReplaceWith("fetchStorageDataList(Callback<List<StorageData>>)"),
        level = DeprecationLevel.WARNING
    )
    fun fetchStorageData(callback: Callback<StorageData>)

    /** 获取缓存的存储卡数据。 */
    fun getStorageDataList(): Result<List<StorageData>>

    /** 从相机拉取最新的存储卡数据（挂起函数）。 */
    suspend fun fetchStorageDataList(): Result<List<StorageData>>

    /** 从相机拉取最新的存储卡数据（回调方式）。 */
    fun fetchStorageDataList(callback: Callback<List<StorageData>>)

    /** 获取缓存的媒体偏移量。 */
    fun getMediaOffset(): Result<String>

    /** 从相机拉取最新的媒体偏移量（挂起函数）。 */
    suspend fun fetchMediaOffset(): Result<String>

    /** 从相机拉取最新的媒体偏移量（回调方式）。 */
    fun fetchMediaOffset(callback: Callback<String>)

    /** 获取当前连接相机对应的配置对象。 */
    fun getSupportConfig(): Result<ICameraConfig>

    /** 获取缓存的固件版本号。 */
    fun getFirmwareRevision(): Result<String>

    /** 从相机拉取最新的固件版本号（挂起函数）。 */
    suspend fun fetchFirmwareRevision(): Result<String>

    /** 从相机拉取最新的固件版本号（回调方式）。 */
    fun fetchFirmwareRevision(callback: Callback<String>)

    /** 获取缓存的 Wi-Fi 数据。 */
    fun getWifiData(): Result<WiFiData>

    /** 从相机拉取最新的 Wi-Fi 数据（挂起函数）。 */
    suspend fun fetchWifiData(): Result<WiFiData>

    /** 从相机拉取最新的 Wi-Fi 数据（回调方式）。 */
    fun fetchWifiData(callback: Callback<WiFiData>)

    /**
     * 获取 Wi-Fi 信息（兼容旧命名：早期版本对外暴露为 WifiInfo）。
     * Demo 侧仍在使用 getWifiInfo / fetchWifiInfo，因此这里保留别名。
     */
    fun getWifiInfo(): Result<WiFiData> = getWifiData()

    /** 拉取 Wi-Fi 信息（挂起函数，兼容旧命名）。 */
    suspend fun fetchWifiInfo(): Result<WiFiData> = fetchWifiData()

    /** 拉取 Wi-Fi 信息（回调方式，兼容旧命名）。 */
    fun fetchWifiInfo(callback: Callback<WiFiData>) = fetchWifiData(callback)

    /** 获取缓存的 Wi-Fi 信道列表。 */
    fun getWifiChannelList(): Result<WiFiChannel>

    /** 从相机拉取最新的 Wi-Fi 信道列表（挂起函数）。 */
    suspend fun fetchWifiChannelList(): Result<WiFiChannel>

    /** 从相机拉取最新的 Wi-Fi 信道列表（回调方式）。 */
    fun fetchWifiChannelList(callback: Callback<WiFiChannel>)

    /** 开启相机 Wi-Fi（回调方式）。 @param channel 指定信道，默认为 0。 */
    fun openCameraWiFi(channel: Int = 0, callback: Callback<Unit>)

    /** 开启相机 Wi-Fi（挂起函数）。 @param channel 指定信道，默认为 0。 */
    suspend fun openCameraWiFi(channel: Int = 0): Result<Unit>

    /** 关闭相机 Wi-Fi（回调方式）。 */
    fun closeCameraWiFi(callback: Callback<Unit>)

    /** 关闭相机 Wi-Fi（挂起函数）。 */
    suspend fun closeCameraWiFi(): Result<Unit>

    /**
     * 设置相机 Wi-Fi 模式（回调方式）。
     * 例如把相机切换到 [WiFiData.Mode.Android_Aware] 模式以启用 WiFi Aware 连接。
     * @param mode 目标 Wi-Fi 模式。
     * @param countryCode 国家码，空字符串表示不变更。
     */
    fun setWifiMode(mode: WiFiData.Mode, countryCode: String = "", callback: Callback<Unit>)

    /**
     * 设置相机 Wi-Fi 模式（挂起函数）。
     * 例如把相机切换到 [WiFiData.Mode.Android_Aware] 模式以启用 WiFi Aware 连接。
     * @param mode 目标 Wi-Fi 模式。
     * @param countryCode 国家码，空字符串表示不变更。
     */
    suspend fun setWifiMode(mode: WiFiData.Mode, countryCode: String = ""): Result<Unit>

    /** 重置相机 Wi-Fi（回调方式）。 @param channel 指定信道，默认为 0。 */
    fun resetCameraWiFi(channel: Int = 0, callback: Callback<Unit>)

    /** 重置相机 Wi-Fi（挂起函数）。 @param channel 指定信道，默认为 0。 */
    suspend fun resetCameraWiFi(channel: Int = 0): Result<Unit>

    /** 设置 Wi-Fi 国家代码（回调方式）。 */
    fun setWiFiCountry(countryCode: String, callback: Callback<Unit>)

    /** 设置 Wi-Fi 国家代码（挂起函数）。 */
    suspend fun setWiFiCountry(countryCode: String): Result<Unit>

    /** 获取缓存的相机型号。 */
    fun getCameraType(): Result<CameraType>

    /** 从相机拉取最新的相机型号（挂起函数）。 */
    suspend fun fetchCameraType(): Result<CameraType>

    /** 从相机拉取最新的相机型号（回调方式）。 */
    fun fetchCameraType(callback: Callback<CameraType>)

    /** 获取缓存的视频编码类型。 */
    fun getVideoEncodeType(): Result<VideoEncode>

    /** 从相机拉取最新的视频编码类型（挂起函数）。 */
    suspend fun fetchVideoEncodeType(): Result<VideoEncode>

    /** 从相机拉取最新的视频编码类型（回调方式）。 */
    fun fetchVideoEncodeType(callback: Callback<VideoEncode>)

    /** 设置视频编码类型（回调方式）。 */
    fun setVideoEncodeType(videoEncode: VideoEncode, callback: Callback<Unit>)

    /** 设置视频编码类型（挂起函数）。 */
    suspend fun setVideoEncodeType(videoEncode: VideoEncode): Result<Unit>

    /** 获取缓存的自拍状态。 */
    fun getIsSelfie(): Result<Boolean>

    /** 从相机拉取最新的自拍状态（挂起函数）。 */
    suspend fun fetchIsSelfie(): Result<Boolean>

    /** 从相机拉取最新的自拍状态（回调方式）。 */
    fun fetchIsSelfie(callback: Callback<Boolean>)

    /** 获取缓存的原始偏移量 V2。 */
    fun getOriginOffsetV2(): Result<String>

    /** 从相机拉取最新的原始偏移量 V2（挂起函数）。 */
    suspend fun fetchOriginOffsetV2(): Result<String>

    /** 从相机拉取最新的原始偏移量 V2（回调方式）。 */
    fun fetchOriginOffsetV2(callback: Callback<String>)

    /** 获取缓存的原始偏移量 V3。 */
    fun getOriginOffsetV3(): Result<String>

    /** 从相机拉取最新的原始偏移量 V3（挂起函数）。 */
    suspend fun fetchOriginOffsetV3(): Result<String>

    /** 从相机拉取最新的原始偏移量 V3（回调方式）。 */
    fun fetchOriginOffsetV3(callback: Callback<String>)

    /** 获取缓存的媒体偏移量 V2。 */
    fun getMediaOffsetV2(): Result<String>

    /** 从相机拉取最新的媒体偏移量 V2（挂起函数）。 */
    suspend fun fetchMediaOffsetV2(): Result<String>

    /** 从相机拉取最新的媒体偏移量 V2（回调方式）。 */
    fun fetchMediaOffsetV2(callback: Callback<String>)

    /** 获取缓存的媒体偏移量 V3。 */
    fun getMediaOffsetV3(): Result<String>

    /** 从相机拉取最新的媒体偏移量 V3（挂起函数）。 */
    suspend fun fetchMediaOffsetV3(): Result<String>

    /** 从相机拉取最新的媒体偏移量 V3（回调方式）。 */
    fun fetchMediaOffsetV3(callback: Callback<String>)

    /** 获取缓存的媒体偏移量 V6。 */
    fun getMediaOffsetV6(): Result<String>

    /** 从相机拉取最新的媒体偏移量 V6（挂起函数）。 */
    suspend fun fetchMediaOffsetV6(): Result<String>

    /** 从相机拉取最新的媒体偏移量 V6（回调方式）。 */
    fun fetchMediaOffsetV6(callback: Callback<String>)

    /** 获取缓存的窗口裁剪信息。 */
    fun getWindowCropInfo(): Result<WindowCropInfo>

    /** 获取缓存的半窗口裁剪信息，用于离线防抖 asset info。 */
    fun getHalfWindowCropInfo(): Result<WindowCropInfo>

    fun getSensorInfo(): Result<Sensor>

    /** 获取缓存的 offset 状态。 */
    fun getOffsetState(): Result<Int>

    /** 获取缓存的 offset 检测类型。 */
    fun getOffsetDetectedType(): Result<Int>

    /** 获取缓存的相机语言设置。 */
    fun getCameraLanguage(): Result<LanguageType>

    /** 从相机拉取最新的相机语言设置（挂起函数）。 */
    suspend fun fetchCameraLanguage(): Result<LanguageType>

    /** 从相机拉取最新的相机语言设置（回调方式）。 */
    fun fetchCameraLanguage(callback: Callback<LanguageType>)

    /** 设置相机语言（回调方式）。 */
    fun setCameraLanguage(languageType: LanguageType, callback: Callback<Unit>)

    /** 设置相机语言（挂起函数）。 */
    suspend fun setCameraLanguage(languageType: LanguageType): Result<Unit>

    /** 设置相机本地时间（挂起函数）。 */
    suspend fun setLocalTime(localTime: LocalTime): Result<Unit>

    /** 设置相机本地时间（回调方式）。 */
    fun setLocalTime(localTime: LocalTime, callback: Callback<Unit>)

    /** 获取缓存的辅助网格开启状态。 */
    fun getAssistiveGridEnable(): Result<Boolean>

    /** 从相机拉取最新的辅助网格开启状态（挂起函数）。 */
    suspend fun fetchAssistiveGridEnable(): Result<Boolean>

    /** 从相机拉取最新的辅助网格开启状态（回调方式）。 */
    fun fetchAssistiveGridEnable(callback: Callback<Boolean>)

    /** 设置辅助网格开启状态（回调方式）。 */
    fun setAssistiveGridEnable(enable: Boolean, callback: Callback<Unit>)

    /** 设置辅助网格开启状态（挂起函数）。 */
    suspend fun setAssistiveGridEnable(enable: Boolean): Result<Unit>

    /** 获取缓存的自由比例网格开启状态。 */
    fun getFreeFrameGridEnable(): Result<Boolean>

    /** 从相机拉取最新的自由比例网格开启状态（挂起函数）。 */
    suspend fun fetchFreeFrameGridEnable(): Result<Boolean>

    /** 从相机拉取最新的自由比例网格开启状态（回调方式）。 */
    fun fetchFreeFrameGridEnable(callback: Callback<Boolean>)

    /** 设置自由比例网格开启状态（回调方式）。 */
    fun setFreeFrameGridEnable(enable: Boolean, callback: Callback<Unit>)

    /** 设置自由比例网格开启状态（挂起函数）。 */
    suspend fun setFreeFrameGridEnable(enable: Boolean): Result<Unit>

    /** 获取缓存的全局锐度设置。 */
    fun getSharpness(): Result<Sharpness>

    /** 从相机拉取最新的全局锐度设置（挂起函数）。 */
    suspend fun fetchSharpness(): Result<Sharpness>

    /** 从相机拉取最新的全局锐度设置（回调方式）。 */
    fun fetchSharpness(callback: Callback<Sharpness>)

    /** 设置全局锐度（回调方式）。 */
    fun setSharpness(sharpness: Sharpness, callback: Callback<Unit>)

    /** 设置全局锐度（挂起函数）。 */
    suspend fun setSharpness(sharpness: Sharpness): Result<Unit>

    /** 获取缓存的媒体时间。 */
    fun getMediaTime(): Result<Long>

    /** 从相机拉取最新的媒体时间（挂起函数）。 */
    suspend fun fetchMediaTime(): Result<Long>

    /** 从相机拉取最新的媒体时间（回调方式）。 */
    fun fetchMediaTime(callback: Callback<Long>)

    fun getRollingShutterTime(): Result<Double>
    suspend fun fetchRollingShutterTime(): Result<Double>


    /** 
     * 激活相机（挂起函数）。
     * @param appId 应用程序的 App ID。
     * @param secretKey 用于加密和签名的密钥。
     */
    suspend fun activeCamera(appId: String, secretKey: String): Result<Unit>

    /**
     * 激活相机（回调方式）。
     * @param appId 应用程序的 App ID。
     * @param secretKey 用于加密和签名的密钥。
     */
    fun activeCamera(appId: String, secretKey: String, callback: Callback<Unit>)

    /** 校准相机陀螺仪（挂起函数）。 */
    suspend fun calibrateGyro(): Result<Unit>

    /** 校准相机陀螺仪（回调方式）。 */
    fun calibrateGyro(callback: Callback<Unit>)

    /** 关闭相机电源。 */
    fun shutdown()

    /** 设置相机屏幕锁定状态（挂起函数）。 */
    suspend fun setLockScreenState(lockScreenState: LockScreenState): Result<Unit>

    /** 设置相机屏幕锁定状态（回调方式）。 */
    fun setLockScreenState(lockScreenState: LockScreenState, callback: Callback<Unit>)

    /** 格式化SD卡（挂起函数） */
    @Deprecated("请使用 formatStorage 替代", ReplaceWith("formatStorage()"))
    suspend fun formatSdCard(): Result<Unit>

    /** 格式化相机SD卡（回调方式）。 */
    @Deprecated("请使用 formatStorage 替代", ReplaceWith("formatStorage(callback = callback)"))
    fun formatSdCard(callback: Callback<Unit>)

    /** 格式化存储（挂起函数） */
    suspend fun formatStorage(fileLocation: StorageData.FileLocation = StorageData.FileLocation.CAMERA): Result<Unit>

    /** 格式化存储（回调方式）。 */
    fun formatStorage(fileLocation: StorageData.FileLocation = StorageData.FileLocation.CAMERA, callback: Callback<Unit>)

    /** 设置主存储-仅X6支持（挂起函数） */
    suspend fun setMainStorage(fileLocation: StorageData.FileLocation): Result<Unit>

    /** 格式化存储-仅X6支持（回调方式）。 */
    fun setMainStorage(fileLocation: StorageData.FileLocation, callback: Callback<Unit>)

}