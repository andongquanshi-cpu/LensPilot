package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.Iq3AMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class Iq3AModeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<Iq3AMode>(CommonAttrKeys.IQ_3A_MODE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): Iq3AMode? = null

    override fun fromInt(value: Int): Iq3AMode = Iq3AMode.nativeOf(value)

    override fun fromName(name: String): Iq3AMode = Iq3AMode.entries.firstOrNull { it.name == name } ?: Iq3AMode.NORMAL

    override fun toInt(data: Iq3AMode): Int = data.nativeValue

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Iq3AMode> =
        device.getIq3AMode(functionMode)

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Iq3AMode> =
        device.fetchIq3AMode(functionMode)

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Iq3AMode): Result<Unit> =
        device.setIq3AMode(functionMode, value)
}
