package com.arashivision.sdk.camera.core.delegate.option

import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.option.BatteryData
import com.arashivision.sdk.camera.core.model.option.ChargeBoxData
import com.arashivision.sdk.camera.core.model.option.FocusSensor
import com.arashivision.sdk.camera.core.model.option.LanguageType
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.VideoEncode
import com.arashivision.sdk.camera.core.model.option.WiFiChannel
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.camera.core.model.photography.LensAccessoryType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import insta360.messages.BatteryInfo
import insta360.messages.BatteryInfo.Battery_type
import insta360.messages.BatteryInfo.PowerType
import insta360.messages.ButtonFollowOptions
import insta360.messages.ButtonPressOptions
import insta360.messages.CameraPostureType
import insta360.messages.ChargeboxConnectedStatus
import insta360.messages.ChargeboxConnectedStatus.ChargeboxConnectedType
import insta360.messages.ChargeboxConnectedStatus.ChargeboxOnOffInfo
import insta360.messages.ChargeboxConnectedStatus.ChargeboxUsbBtConnectedType
import insta360.messages.ChildModeInfo
import insta360.messages.DashCamInfo
import insta360.messages.Flicker
import insta360.messages.FovType
import insta360.messages.GammaMode
import insta360.messages.HeatShellType
import insta360.messages.LensAccessoriesInfo
import insta360.messages.LensAccessoriesInfo.Lens_Accessories_Type
import insta360.messages.LiveBroadCastStatus
import insta360.messages.MainMode
import insta360.messages.NotificationP2pTransStatus
import insta360.messages.OffsetDetectedType
import insta360.messages.OffsetState
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.Options.AccFullScaleRange
import insta360.messages.Options.AdoptionSystem
import insta360.messages.Options.Audio_Recoder_Ctrl
import insta360.messages.Options.Audio_Wnr_Type
import insta360.messages.Options.BTCarCmdInfo
import insta360.messages.Options.BTRemoteType
import insta360.messages.Options.Bt_Wakeup_Sw
import insta360.messages.Options.Camera_Bitrate_Type
import insta360.messages.Options.EvoStatusMode
import insta360.messages.Options.ExpectOutputType
import insta360.messages.Options.GyroBias
import insta360.messages.Options.GyroFilterConfig
import insta360.messages.Options.GyroFullScaleRange
import insta360.messages.Options.GyroInfo
import insta360.messages.Options.Gyro_to_Master_HW_State
import insta360.messages.Options.HwType
import insta360.messages.Options.Iperf_Status_Type
import insta360.messages.Options.LANGUAGE_TYPE
import insta360.messages.Options.LenMInfo
import insta360.messages.Options.Long_Battery_Mode_Type
import insta360.messages.Options.Product_Id_Type
import insta360.messages.Options.QualitySetting
import insta360.messages.Options.RcBindInfo
import insta360.messages.Options.RectifyGyroBias
import insta360.messages.Options.SFRCalibrationInfo
import insta360.messages.Options.TelevisionSystem
import insta360.messages.Options.UdiskMode
import insta360.messages.Options.VideoEncodeType
import insta360.messages.Options.Voice_Ctrl_Language
import insta360.messages.Options.WifiChannelList
import insta360.messages.Options.WifiInfo
import insta360.messages.Options.WifiStatus
import insta360.messages.Options.wireless_link_num
import insta360.messages.PhotoSize
import insta360.messages.PhotoSubMode
import insta360.messages.PtzCtrlInfo
import insta360.messages.QButtonCustomActionInfo
import insta360.messages.Sensor
import insta360.messages.SensorDevice
import insta360.messages.StorageState
import insta360.messages.Street_Photo_Type
import insta360.messages.VideoResolution
import insta360.messages.VideoSubMode
import insta360.messages.WindowCropInfo
import okio.ByteString
import com.arashivision.sdk.camera.core.model.option.ExpectOutputType as SdkExpectOutputType
import com.arashivision.sdk.camera.core.model.option.PhotoSubMode as SdkPhotoSubMode
import com.arashivision.sdk.camera.core.model.option.VideoSubMode as SdkVideoSubMode

@Suppress("UNCHECKED_CAST")
object OptionMapper {

    fun options2Map(optionList: List<OptionType>, options: Options): Map<OptionType, Any?> {
        val associateWith = optionList.associateWith {
            when (it) {
                OptionType.OPTION_UNKNOWN -> null
                OptionType.VIDEO_RESOLUTION -> options.video_resolution
                OptionType.PHOTO_SIZE -> options.photo_size
                OptionType.VIDEO_BITRATE -> options.video_bitrate
                OptionType.AUDIO_BITRATE -> options.audio_bitrate
                OptionType.AUDIO_SAMPLERATE -> options.audio_samplerate
                OptionType.ORIGIN_OFFSET -> options.origin_offset
                OptionType.CAPTURE_TIME_LIMIT -> options.capture_time_limit
                OptionType.GPS_TIMEOUT -> options.gps_timeout
                OptionType.REMAINING_CAPTURE_TIME -> options.remaining_capture_time
                OptionType.REMAINING_PICTURES -> options.remaining_pictures
                OptionType.BATTERY_INFO -> options.battery_info
                OptionType.LOCAL_TIME -> options.local_time
                OptionType.TIME_ZONE -> options.time_zone_seconds_from_GMT
                OptionType.MUTE -> options.mute
                OptionType.SERIAL_NUMBER -> options.serial_number
                OptionType.UUID -> options.UUID
                OptionType.BUTTON_PRESS_OPTIONS -> options.pressOptions
                OptionType.ACTIVATE_TIME -> options.activate_time
                OptionType.STORAGE_STATE -> options.storage_state
                OptionType.LENS_INDEX -> options.lens_index
                OptionType.MEDIA_OFFSET -> options.media_offset
                OptionType.SELF_TIMER -> options.self_timer
                OptionType.GYRO_SAMPLE_RATE -> options.gyro_sample_rate
                OptionType.ACC_FULL_SCALE_RANGE -> options.acc_range
                OptionType.GYRO_FULL_SCALE_RANGE -> options.gyro_range
                OptionType.TAKE_RAW_PICTURE -> options.take_raw_picture
                OptionType.GAMMA_MODE -> options.gamma_mode
                OptionType.MEDIA_TIME -> options.media_time
                OptionType.FIRMWAREREVISION -> options.firmwareRevision
                OptionType.SYS_ADOPTION -> options.sys_adoption
                OptionType.CPU_TYPE -> options.cpu_type
                OptionType.GYRO_FILTER -> options.gyro_filter_config
                OptionType.MCTF_ENABLE -> options.mctf_enable
                OptionType.SPORT_MODE_ENABLE -> options.sport_mode_enable
                OptionType.WIFI_INFO -> options.wifi_info
                OptionType.WIFI_CHANNEL_LIST -> options.wifi_channel_list
                OptionType.AUTHORIZATION_ID -> options.authorization_id
                OptionType.CALIBRATION_OFFSET -> options.calibration_offset
                OptionType.PHOTO_SUB_MODE -> options.photo_sub_mode
                OptionType.VIDEO_SUB_MODE -> options.video_sub_mode
                OptionType.SECOND_STREAM_RES -> options.second_stream_res
                OptionType.WIFI_STATUS -> options.wifi_status
                OptionType.EVO_STATUS_MODE -> options.evo_status_mode
                OptionType.ORIGIN_OFFSET_3D -> options.origin_offset_3d
                OptionType.MEDIA_OFFSET_3D -> options.media_offset_3d
                OptionType.CALIBRATION_OFFSET_3D -> options.calibration_offset_3d
                OptionType.CAMERA_TYPE -> options.camera_type
                OptionType.BT_REMOTE_VERSION -> options.bt_remote_version
                OptionType.BT_REMOTE_TYPE -> options.bt_remote_type
                OptionType.QUALITY_SETTING -> options.quality_setting
                OptionType.OVERHEAT_PROTECTION -> options.over_heat_protection
                OptionType.CALIBRATION_ORIENTATION -> options.calibration_orientation
                OptionType.STANDBY_DURATION -> options.standby_duration
                OptionType.QUICK_CAPTURE_ENABLE -> options.quick_capture_enable
                OptionType.BT_MAC_ADDR -> options.bt_mac_addr
                OptionType.TELEVISION_SYSTEM -> options.television_system
                OptionType.SENSOR0_SERIAL_VR360 -> options.sensor0_serial_vr360
                OptionType.SENSOR1_SERIAL_VR360 -> options.sensor1_serial_vr360
                OptionType.SENSOR_SERIAL_VR180 -> options.sensor_serial_vr180
                OptionType.MOBVOI_LICENSE -> options.mobvoi_license
                OptionType.MOBVOI_PUBLIC_KEY -> options.mobvoi_public_key
                OptionType.GYRO_INFO -> options.gyro_info
                OptionType.SENSOR_ID -> options.sensor_id
                OptionType.INTERNAL_FLOWSTATE -> options.enableInternalFlowstate
                OptionType.VIDEO_ENCODE_TYPE -> options.video_encode_type
                OptionType.SENSOR_INFO -> options.sensor
                OptionType.IS_SELFIE -> options.is_selfie
                OptionType.ROLLING_SHUTTER_TIME -> options.rolling_shutter_time
                OptionType.GYRO_TIME_STAMP -> options.gyro_timestamp
                OptionType.VIDEO_FOV -> options.video_fov
                OptionType.STILL_FOV -> options.still_fov
                OptionType.GYRO_POLYFIT_STATE -> options.Gyro_Polyfit_State
                OptionType.GYRO_CALIBRATE_STATE -> options.Gyro_Calibrate_State
                OptionType.MOBVOI_LICENSE_VERITY_STATE -> options.mobvoi_license_verity_state
                OptionType.FLICKER_GLOBAL -> options.flicker
                OptionType.TEMP_VALUE -> options.temp_value
                OptionType.ORIGIN_OFFSET_V2 -> options.origin_offset_v2
                OptionType.ORIGIN_OFFSET_V3 -> options.origin_offset_v3
                OptionType.MEDIA_OFFSET_V2 -> options.media_offset_v2
                OptionType.MEDIA_OFFSET_V3 -> options.media_offset_v3
                OptionType.INSTAPANO_FOCUS_SENSOR -> options.focusSensor
                OptionType.EXPECT_OUTPUT_TYPE -> options.expectOutputType
                OptionType.HW_TYPE -> options.hw_type
                OptionType.CHARGEBOX_CONNECTED_STATUS -> options.insta360_messages_ChargeboxConnectedStatus
                OptionType.BT_CAR_TABLE -> options.btcarcmdinfo
                OptionType.PTZ_CTRL -> options.ptzctrl
                OptionType.CAMERA_LANGUAGE -> options.camera_language
                OptionType.HW_BLE_VERSION -> options.ble_version
                OptionType.FACTORY_CALIBRATION_STATUS -> options.Factory_Calibration_Status
                OptionType.MODULE_TYPE -> options.Module_Type
                OptionType.SFR_CALIBRATION_STATUS -> options.sfrcalibrationinfo
                OptionType.CAMERA_POSTURE -> options.camera_posture
                OptionType.FACTORY_MODE_STATUS -> options.Factory_Mode
                OptionType.UDISK_MODE -> options.udisk_mode
                OptionType.HW_VERSION -> options.HW_Version
                OptionType.BT_WAKEUP_SW -> options.bt_wakeup_sw
                OptionType.FAC_AGEING_STATUS -> options.factory_ageing_status
                OptionType.RAW10BIT_ENABLE -> options.raw_10bit_enable
                OptionType.SENSOR_TEMP_VALUE -> options.sensor_temp_value
                OptionType.GYRO_MASETER_HW_STATE -> options.gyro_to_master_HW_state
                OptionType.OFFSET_STATES -> options.offset_states
                OptionType.SENSOR_283LensType -> options.lenm_info
                OptionType.VOICE_CTRL_LANGUAGE -> options.voice_ctrl_language
                OptionType.VOICE_CTRL_ENABLE -> options.voice_ctrl_enable
                OptionType.MAIN_MODE -> options.main_mode
                OptionType.AUDIO_RECODER_ENABLE -> options.audio_recoder_enable
                OptionType.AUDIO_WNR_TYPE -> options.audio_wnr_type
                OptionType.OTA_PKG_VERSION -> options.ota_pkg_version
                OptionType.AUTO_SHUTDOWN_TIME -> options.auto_shutdown_time
                OptionType.APP_LIVE_VIEW_STATUS -> options.app_liveview_status
                OptionType.CAMERA_BITRATE_TYPE -> options.camera_bitrate_type
                OptionType.BOX_OTA_PKG_VERSION -> options.box_ota_pkg_version
                OptionType.BOX_BT_VERSION -> options.box_bt_version
                OptionType.BOX_VERSION -> options.box_version
                OptionType.GO3_VERSION -> options.go3_version
                OptionType.WIFI_WORKING_STATUS -> options.wifi_working_status
                OptionType.BUTTON_FOLLOW_OPTION -> options.followOptions
                OptionType.LED_SWITCH -> options.led_switch
                OptionType.BEEP_SWITCH -> options.beep_switch
                OptionType.CAMERA_POSTURE_WHEN_CAPTURE_START -> options.camera_posture_when_capture_start
                OptionType.CHARGEBOX_CONNECTED_STATUS_WHEN_CAPTURE_START -> options.chargebox_connected_status_when_capture_start
                OptionType.WINDOW_CROP_INFO -> options.window_crop_info
                OptionType.VERTICAL_FLIP_ENABLE -> options.vertical_flip_enable
                OptionType.GYRO_BIAS -> options.gyro_bias
                OptionType.BUTTON_AUTO_FOLLOW -> options.button_auto_follow
                OptionType.ASSISTIVE_GRID -> options.assistive_grid_enable
                OptionType.FREEFRAME_GRID -> options.freeframe_grid_enable
                OptionType.RC_CONN_INFO -> options.RC_CONN_INFO
                OptionType.AUTHORIZATION_CLEAN -> options.authorization_clean
                OptionType.MAIN_VIDEO_ENCODE_TYPE -> options.main_video_encode_type
                OptionType.DARK_EIS_ENABLE_GLOBAL -> options.dark_eis_enable_global
                OptionType.METERING_ENABLE_GLOBAL -> options.metering_enable_global
                OptionType.INTERNAL_SPLICING -> options.enableInternalSplicing
                OptionType.IPERF_STATUS -> options.iperf_status_type
                OptionType.WIFI_FACTORY -> options.wifi_factory_enable
                OptionType.SHARPNESS_GLOBAL -> options.sharpness_global
                OptionType.LIGHT_REFRESH_RATE -> options.light_refresh_rate
                OptionType.RF_RSSI -> options.rf_rssi
                OptionType.FINDMY_ENABLE -> options.findmy_enable
                OptionType.FINDMY_TOKEN -> options.findmy_token
                OptionType.FINDMY_TOKEN_ID -> options.findmy_token_id
                OptionType.FINDMY_TOKEN_UUID -> options.findmy_token_uuid
                OptionType.CANCEL_CAPTURE_ENABLE -> options.cancel_capture_enable
                OptionType.CANCEL_CAPTURE_GUIDE_FLAG -> options.cancel_capture_guide_flag
                OptionType.QUICK_READER_MOVING_FLAG -> options.quick_reader_moving_flag
                OptionType.HAND_CONTROL_ENABLE -> options.hand_control_enable
                OptionType.HEAT_SHELL_TYPE -> options.heat_shell_type
                OptionType.OFFSET_DETECTED_TYPE -> options.offset_detected_type
                OptionType.CHILD_MODE -> options.child_mode_info
                OptionType.HORIZON_INDICATOR_ENABLE -> options.horizon_indicator_enable
                OptionType.CAMERA_BT_RSSI -> options.bt_rssi
                OptionType.Q_BUTTON_CUSTOM_ACTION_INFO -> options.q_action_info
                OptionType.HAS_CRASH -> options.has_crash
                OptionType.CLOUD_IS_BUSY_STATUS -> options.cloud_is_busy_status
                OptionType.TIME_WATERMARK_SWITCH -> options.time_watermark_switch
                OptionType.DASHCAM_INFO -> options.dashcam_info
                OptionType.CO_BRANDED_PRODUCT_ID -> options.co_branded_product_id
                OptionType.PTZ_PANO_SAVE_SWITCH -> options.ptz_pano_save_switch
                OptionType.CHECK_BIAS_CORRECTED -> options.check_bias_corrected
                OptionType.RECTIFY_GYRO_BIAS -> options.rectify_gyro_bias
                OptionType.USB_STORAGE_PASSWD -> options.usb_storage_passwd
                OptionType.WIRELESS_LINK_NUM -> options.link_num
                OptionType.LIVE_BROADCAST_STATUS -> options.live_broadcast_status
                OptionType.LONG_BATTERY -> options.long_battery_mode_enabled
                OptionType.P2P_TRANS_STATUS -> options.p2p_trans_status
                OptionType.HORIZON_FILP_ENABLE -> options.horizon_filp_enable
                OptionType.LENS_ACCESSORIES_INFO -> options.lens_accessories_info
                OptionType.MEDIA_OFFSET_V6 -> options.media_offset_v6
                OptionType.STREET_PHOTO_TYPE -> options.street_photo_type
                OptionType.OPTIONS_NUM -> null
                OptionType.QC_SINGLE_PRESS_SHOOT_TYPE -> null
                OptionType.NEED_ADAPTIVE_ROTATION -> null
                OptionType.MEDIA_OFFSET_V8 -> null
                OptionType.GEOGRAPHIC_TIME_ZONE -> null

                // C6新增
                OptionType.STORAGE_STATE_LIST -> options.storage_state_list
                OptionType.CARD_LOCATION_LAST_UPDATE -> options.card_location_last_update
                OptionType.FC_FLIGHT_ID -> null
                OptionType.ZOOM_SPEED -> null
                OptionType.DETACHABLE_SCREEN_BATTERY_INFO -> null
                OptionType.IDLE_ANALYZE_SWITCH_ON -> null
                OptionType.CAMERA_OFFSETS -> null
                OptionType.LAST_UPGRADE_SUMMARY -> null
                OptionType.BLUETOOTH_OPERATE -> null
                OptionType.APP_WAKEUP_TYPE -> null
                OptionType.IS_NEED_REBUILD_PIPELINE -> null
                OptionType.AF_LENS_INFO_OPTION -> null
                OptionType.SELFIE_FOLLOW_SWITCH -> null
                OptionType.AI_FEATURE_STATUS_LIST -> null
                OptionType.AI_FEATURE_SWITCH_CTRL -> null
                OptionType.BLUETOOTH_CURR_INFO -> null
                OptionType.BLUETOOTH_MAC_BIND -> null

                //c9_beat2.1新增
                OptionType.UOM_REAL_NAME_STATE -> null
                OptionType.UOM_ACTIVATE_STATE -> null

                else -> null

            }
        }
        return associateWith.filter { it.value != null }.mapValues { (_, value) -> value!! }
    }

    fun map2Options(optionMap: Map<OptionType, Any>): Options {
        return Options().apply {
            optionMap.entries.forEach { (key, value) ->
                when (key) {
                    OptionType.OPTION_UNKNOWN -> Unit
                    OptionType.VIDEO_RESOLUTION -> video_resolution = (value as? VideoResolution) ?: VideoResolution.RES_3840_1920P30
                    OptionType.PHOTO_SIZE -> photo_size = (value as? PhotoSize) ?: PhotoSize.Size_6912_3456
                    OptionType.VIDEO_BITRATE -> video_bitrate = (value as? Int) ?: 0
                    OptionType.AUDIO_BITRATE -> audio_bitrate = (value as? Int) ?: 0
                    OptionType.AUDIO_SAMPLERATE -> audio_samplerate = (value as? Int) ?: 0
                    OptionType.ORIGIN_OFFSET -> origin_offset = (value as? String) ?: ""
                    OptionType.CAPTURE_TIME_LIMIT -> capture_time_limit = (value as? Int) ?: 0
                    OptionType.GPS_TIMEOUT -> gps_timeout = (value as? Int) ?: 0
                    OptionType.REMAINING_CAPTURE_TIME -> remaining_capture_time = (value as? Int) ?: 0
                    OptionType.REMAINING_PICTURES -> remaining_pictures = (value as? Int) ?: 0
                    OptionType.BATTERY_INFO -> battery_info = value as? BatteryInfo
                    OptionType.LOCAL_TIME -> local_time = (value as? Long) ?: 0L
                    OptionType.TIME_ZONE -> time_zone_seconds_from_GMT = (value as? Int) ?: 0
                    OptionType.MUTE -> mute = (value as? Boolean) ?: false
                    OptionType.SERIAL_NUMBER -> serial_number = (value as? String) ?: ""
                    OptionType.UUID -> UUID = (value as? String) ?: ""
                    OptionType.BUTTON_PRESS_OPTIONS -> pressOptions = value as? ButtonPressOptions
                    OptionType.ACTIVATE_TIME -> activate_time = (value as? Long) ?: 0L
                    OptionType.STORAGE_STATE -> storage_state = value as? StorageState
                    OptionType.LENS_INDEX -> lens_index = (value as? Int) ?: 0
                    OptionType.MEDIA_OFFSET -> media_offset = (value as? String) ?: ""
                    OptionType.SELF_TIMER -> self_timer = (value as? Int) ?: 0
                    OptionType.GYRO_SAMPLE_RATE -> gyro_sample_rate = (value as? Int) ?: 0
                    OptionType.ACC_FULL_SCALE_RANGE -> acc_range = (value as? AccFullScaleRange) ?: AccFullScaleRange.RANGE_2G
                    OptionType.GYRO_FULL_SCALE_RANGE -> gyro_range = (value as? GyroFullScaleRange) ?: GyroFullScaleRange.RANGE_250DPS
                    OptionType.TAKE_RAW_PICTURE -> take_raw_picture = (value as? Boolean) ?: false
                    OptionType.GAMMA_MODE -> gamma_mode = (value as? GammaMode) ?: GammaMode.STANDARD
                    OptionType.MEDIA_TIME -> media_time = (value as? Long) ?: 0L
                    OptionType.FIRMWAREREVISION -> firmwareRevision = (value as? String) ?: ""
                    OptionType.SYS_ADOPTION -> sys_adoption = (value as? AdoptionSystem) ?: AdoptionSystem.PHONE_IOS
                    OptionType.CPU_TYPE -> cpu_type = (value as? String) ?: ""
                    OptionType.GYRO_FILTER -> gyro_filter_config = value as? GyroFilterConfig
                    OptionType.MCTF_ENABLE -> mctf_enable = (value as? Boolean) ?: false
                    OptionType.SPORT_MODE_ENABLE -> sport_mode_enable = (value as? Boolean) ?: false
                    OptionType.WIFI_INFO -> wifi_info = value as? WifiInfo
                    OptionType.WIFI_CHANNEL_LIST -> wifi_channel_list = value as? WifiChannelList
                    OptionType.AUTHORIZATION_ID -> authorization_id = (value as? String) ?: ""
                    OptionType.CALIBRATION_OFFSET -> calibration_offset = (value as? String) ?: ""
                    OptionType.PHOTO_SUB_MODE -> photo_sub_mode = (value as? PhotoSubMode) ?: PhotoSubMode.PHOTO_SINGLE
                    OptionType.VIDEO_SUB_MODE -> video_sub_mode = (value as? VideoSubMode) ?: VideoSubMode.VIDEO_NORMAL
                    OptionType.SECOND_STREAM_RES -> second_stream_res = (value as? VideoResolution) ?: VideoResolution.RES_3840_1920P30
                    OptionType.WIFI_STATUS -> wifi_status = (value as? WifiStatus) ?: WifiStatus.AUTO
                    OptionType.EVO_STATUS_MODE -> evo_status_mode = (value as? EvoStatusMode) ?: EvoStatusMode.UNKNOWN_STATUS_MODE
                    OptionType.ORIGIN_OFFSET_3D -> origin_offset_3d = (value as? String) ?: ""
                    OptionType.MEDIA_OFFSET_3D -> media_offset_3d = (value as? String) ?: ""
                    OptionType.CALIBRATION_OFFSET_3D -> calibration_offset_3d = (value as? String) ?: ""
                    OptionType.CAMERA_TYPE -> camera_type = (value as? String) ?: ""
                    OptionType.BT_REMOTE_VERSION -> bt_remote_version = (value as? String) ?: ""
                    OptionType.BT_REMOTE_TYPE -> bt_remote_type = (value as? BTRemoteType) ?: BTRemoteType.UNKNOWN_BT_REMOTE
                    OptionType.QUALITY_SETTING -> quality_setting = (value as? QualitySetting) ?: QualitySetting.HIGH_QUALITY
                    OptionType.OVERHEAT_PROTECTION -> over_heat_protection = (value as? Boolean) ?: false
                    OptionType.CALIBRATION_ORIENTATION -> calibration_orientation = (value as? ByteString) ?: ByteString.EMPTY
                    OptionType.STANDBY_DURATION -> standby_duration = (value as? Int) ?: 0
                    OptionType.QUICK_CAPTURE_ENABLE -> quick_capture_enable = (value as? Boolean) ?: false
                    OptionType.BT_MAC_ADDR -> bt_mac_addr = (value as? String) ?: ""
                    OptionType.TELEVISION_SYSTEM -> television_system = (value as? TelevisionSystem) ?: TelevisionSystem.NTSC
                    OptionType.SENSOR0_SERIAL_VR360 -> sensor0_serial_vr360 = (value as? String) ?: ""
                    OptionType.SENSOR1_SERIAL_VR360 -> sensor1_serial_vr360 = (value as? String) ?: ""
                    OptionType.SENSOR_SERIAL_VR180 -> sensor_serial_vr180 = (value as? String) ?: ""
                    OptionType.MOBVOI_LICENSE -> mobvoi_license = (value as? String) ?: ""
                    OptionType.MOBVOI_PUBLIC_KEY -> mobvoi_public_key = (value as? String) ?: ""
                    OptionType.GYRO_INFO -> gyro_info = value as? GyroInfo
                    OptionType.SENSOR_ID -> sensor_id = (value as? String) ?: ""
                    OptionType.INTERNAL_FLOWSTATE -> enableInternalFlowstate = (value as? Boolean) ?: false
                    OptionType.VIDEO_ENCODE_TYPE -> video_encode_type = (value as? VideoEncodeType) ?: VideoEncodeType.ENCODE_H264
                    OptionType.SENSOR_INFO -> sensor = value as? Sensor
                    OptionType.IS_SELFIE -> is_selfie = (value as? Boolean) ?: false
                    OptionType.ROLLING_SHUTTER_TIME -> rolling_shutter_time = (value as? Double) ?: 0.0
                    OptionType.GYRO_TIME_STAMP -> gyro_timestamp = (value as? Double) ?: 0.0
                    OptionType.VIDEO_FOV -> video_fov = (value as? FovType) ?: FovType.FOV_WIDE
                    OptionType.STILL_FOV -> still_fov = (value as? FovType) ?: FovType.FOV_WIDE
                    OptionType.GYRO_POLYFIT_STATE -> Gyro_Polyfit_State = (value as? Boolean) ?: false
                    OptionType.GYRO_CALIBRATE_STATE -> Gyro_Calibrate_State = (value as? Boolean) ?: false
                    OptionType.MOBVOI_LICENSE_VERITY_STATE -> mobvoi_license_verity_state = (value as? Boolean) ?: false
                    OptionType.FLICKER_GLOBAL -> flicker = (value as? Flicker) ?: Flicker.FLICKER_AUTO
                    OptionType.TEMP_VALUE -> temp_value = (value as? Int) ?: 0
                    OptionType.ORIGIN_OFFSET_V2 -> origin_offset_v2 = (value as? String) ?: ""
                    OptionType.ORIGIN_OFFSET_V3 -> origin_offset_v3 = (value as? String) ?: ""
                    OptionType.MEDIA_OFFSET_V2 -> media_offset_v2 = (value as? String) ?: ""
                    OptionType.MEDIA_OFFSET_V3 -> media_offset_v3 = (value as? String) ?: ""
                    OptionType.INSTAPANO_FOCUS_SENSOR -> focusSensor = (value as? SensorDevice) ?: SensorDevice.SENSOR_DEVICE_UNKNOWN
                    OptionType.EXPECT_OUTPUT_TYPE -> expectOutputType = (value as? ExpectOutputType) ?: ExpectOutputType.DEFAULT
                    OptionType.HW_TYPE -> hw_type = (value as? HwType) ?: HwType.HW_TYPE_UNKNOWN
                    OptionType.CHARGEBOX_CONNECTED_STATUS -> insta360_messages_ChargeboxConnectedStatus = value as? ChargeboxConnectedStatus
                    OptionType.BT_CAR_TABLE -> btcarcmdinfo = value as? BTCarCmdInfo
                    OptionType.PTZ_CTRL -> ptzctrl = value as? PtzCtrlInfo
                    OptionType.CAMERA_LANGUAGE -> camera_language = (value as? LANGUAGE_TYPE) ?: LANGUAGE_TYPE.EN
                    OptionType.HW_BLE_VERSION -> ble_version = (value as? String) ?: ""
                    OptionType.FACTORY_CALIBRATION_STATUS -> Factory_Calibration_Status = (value as? Int) ?: 0
                    OptionType.MODULE_TYPE -> Module_Type = (value as? Int) ?: 0
                    OptionType.SFR_CALIBRATION_STATUS -> sfrcalibrationinfo = value as? SFRCalibrationInfo
                    OptionType.CAMERA_POSTURE -> camera_posture = (value as? CameraPostureType) ?: CameraPostureType.CAMERA_POSTURE_ROTATE_0
                    OptionType.FACTORY_MODE_STATUS -> Factory_Mode = (value as? Boolean) ?: false
                    OptionType.UDISK_MODE -> udisk_mode = (value as? UdiskMode) ?: UdiskMode.UDISK_MODE_PC
                    OptionType.HW_VERSION -> HW_Version = (value as? Int) ?: 0
                    OptionType.BT_WAKEUP_SW -> bt_wakeup_sw = (value as? Bt_Wakeup_Sw) ?: Bt_Wakeup_Sw.Bt_Wakeup_Sw_Off
                    OptionType.FAC_AGEING_STATUS -> factory_ageing_status = (value as? Int) ?: 0
                    OptionType.RAW10BIT_ENABLE -> raw_10bit_enable = (value as? Boolean) ?: false
                    OptionType.SENSOR_TEMP_VALUE -> sensor_temp_value = (value as? Int) ?: 0
                    OptionType.GYRO_MASETER_HW_STATE -> gyro_to_master_HW_state = (value as? Gyro_to_Master_HW_State) ?: Gyro_to_Master_HW_State.GYRO_HW_INTERFACE_STATE_NORMAL
                    OptionType.OFFSET_STATES -> offset_states = (value as? OffsetState) ?: OffsetState.Common
                    OptionType.SENSOR_283LensType -> lenm_info = value as? LenMInfo
                    OptionType.VOICE_CTRL_LANGUAGE -> voice_ctrl_language = (value as? Voice_Ctrl_Language) ?: Voice_Ctrl_Language.VOICE_CTRL_LANGUAGE_EN
                    OptionType.VOICE_CTRL_ENABLE -> voice_ctrl_enable = (value as? Boolean) ?: false
                    OptionType.MAIN_MODE -> main_mode = (value as? MainMode) ?: MainMode.MAIN_MODE_VIDEO
                    OptionType.AUDIO_RECODER_ENABLE -> audio_recoder_enable = (value as? Audio_Recoder_Ctrl) ?: Audio_Recoder_Ctrl.Audio_Recoder_Ctrl_HIDE
                    OptionType.AUDIO_WNR_TYPE -> audio_wnr_type = (value as? Audio_Wnr_Type) ?: Audio_Wnr_Type.Audio_Wnr_Type_Direction_Focus
                    OptionType.OTA_PKG_VERSION -> ota_pkg_version = (value as? String) ?: ""
                    OptionType.AUTO_SHUTDOWN_TIME -> auto_shutdown_time = (value as? Int) ?: 0
                    OptionType.APP_LIVE_VIEW_STATUS -> app_liveview_status = (value as? Boolean) ?: false
                    OptionType.CAMERA_BITRATE_TYPE -> camera_bitrate_type = (value as? Camera_Bitrate_Type) ?: Camera_Bitrate_Type.Camera_Bitrate_Type_High
                    OptionType.BOX_OTA_PKG_VERSION -> box_ota_pkg_version = (value as? String) ?: ""
                    OptionType.BOX_BT_VERSION -> box_bt_version = (value as? String) ?: ""
                    OptionType.BOX_VERSION -> box_version = (value as? String) ?: ""
                    OptionType.GO3_VERSION -> go3_version = (value as? String) ?: ""
                    OptionType.WIFI_WORKING_STATUS -> wifi_working_status = (value as? Boolean) ?: false
                    OptionType.BUTTON_FOLLOW_OPTION -> followOptions = value as? ButtonFollowOptions
                    OptionType.LED_SWITCH -> led_switch = (value as? Int) ?: 0
                    OptionType.BEEP_SWITCH -> beep_switch = (value as? Int) ?: 0
                    OptionType.CAMERA_POSTURE_WHEN_CAPTURE_START -> camera_posture_when_capture_start = (value as? CameraPostureType) ?: CameraPostureType.CAMERA_POSTURE_ROTATE_0
                    OptionType.CHARGEBOX_CONNECTED_STATUS_WHEN_CAPTURE_START -> chargebox_connected_status_when_capture_start = value as? ChargeboxConnectedStatus
                    OptionType.WINDOW_CROP_INFO -> window_crop_info = value as? WindowCropInfo
                    OptionType.VERTICAL_FLIP_ENABLE -> vertical_flip_enable = (value as? Boolean) ?: false
                    OptionType.GYRO_BIAS -> gyro_bias = value as? GyroBias
                    OptionType.BUTTON_AUTO_FOLLOW -> button_auto_follow = (value as? Boolean) ?: false
                    OptionType.ASSISTIVE_GRID -> assistive_grid_enable = (value as? Boolean) ?: false
                    OptionType.FREEFRAME_GRID -> freeframe_grid_enable = (value as? Boolean) ?: false
                    OptionType.RC_CONN_INFO -> RC_CONN_INFO = value as? RcBindInfo
                    OptionType.AUTHORIZATION_CLEAN -> authorization_clean = (value as? Boolean) ?: false
                    OptionType.MAIN_VIDEO_ENCODE_TYPE -> main_video_encode_type = (value as? VideoEncodeType) ?: VideoEncodeType.ENCODE_H264
                    OptionType.DARK_EIS_ENABLE_GLOBAL -> dark_eis_enable_global = (value as? Boolean) ?: false
                    OptionType.METERING_ENABLE_GLOBAL -> metering_enable_global = (value as? Boolean) ?: false
                    OptionType.INTERNAL_SPLICING -> enableInternalSplicing = (value as? Boolean) ?: false
                    OptionType.IPERF_STATUS -> iperf_status_type = (value as? Iperf_Status_Type) ?: Iperf_Status_Type.iperf_status_type_close
                    OptionType.WIFI_FACTORY -> wifi_factory_enable = (value as? Boolean) ?: false
                    OptionType.SHARPNESS_GLOBAL -> sharpness_global = (value as? Int) ?: 0
                    OptionType.LIGHT_REFRESH_RATE -> light_refresh_rate = (value as? Int) ?: 0
                    OptionType.RF_RSSI -> rf_rssi = (value as? Int) ?: 0
                    OptionType.FINDMY_ENABLE -> findmy_enable = (value as? Boolean) ?: false
                    OptionType.FINDMY_TOKEN -> findmy_token = (value as? String) ?: ""
                    OptionType.FINDMY_TOKEN_ID -> findmy_token_id = (value as? String) ?: ""
                    OptionType.FINDMY_TOKEN_UUID -> findmy_token_uuid = (value as? String) ?: ""
                    OptionType.CANCEL_CAPTURE_ENABLE -> cancel_capture_enable = (value as? Boolean) ?: false
                    OptionType.CANCEL_CAPTURE_GUIDE_FLAG -> cancel_capture_guide_flag = (value as? Boolean) ?: false
                    OptionType.QUICK_READER_MOVING_FLAG -> quick_reader_moving_flag = (value as? Boolean) ?: false
                    OptionType.HAND_CONTROL_ENABLE -> hand_control_enable = (value as? Boolean) ?: false
                    OptionType.HEAT_SHELL_TYPE -> heat_shell_type = (value as? HeatShellType) ?: HeatShellType.None
                    OptionType.OFFSET_DETECTED_TYPE -> offset_detected_type = (value as? OffsetDetectedType) ?: OffsetDetectedType.Unkown
                    OptionType.CHILD_MODE -> child_mode_info = value as? ChildModeInfo
                    OptionType.HORIZON_INDICATOR_ENABLE -> horizon_indicator_enable = (value as? Boolean) ?: false
                    OptionType.CAMERA_BT_RSSI -> bt_rssi = (value as? Int) ?: 0
                    OptionType.Q_BUTTON_CUSTOM_ACTION_INFO -> q_action_info = value as? QButtonCustomActionInfo
                    OptionType.HAS_CRASH -> has_crash = (value as? Boolean) ?: false
                    OptionType.CLOUD_IS_BUSY_STATUS -> cloud_is_busy_status = (value as? Boolean) ?: false
                    OptionType.TIME_WATERMARK_SWITCH -> time_watermark_switch = (value as? Boolean) ?: false
                    OptionType.DASHCAM_INFO -> dashcam_info = value as? DashCamInfo
                    OptionType.CO_BRANDED_PRODUCT_ID -> co_branded_product_id = (value as? Product_Id_Type) ?: Product_Id_Type.Product_Common
                    OptionType.PTZ_PANO_SAVE_SWITCH -> ptz_pano_save_switch = (value as? Int) ?: 0
                    OptionType.CHECK_BIAS_CORRECTED -> check_bias_corrected = (value as? Boolean) ?: false
                    OptionType.RECTIFY_GYRO_BIAS -> rectify_gyro_bias = value as? RectifyGyroBias
                    OptionType.USB_STORAGE_PASSWD -> usb_storage_passwd = value as String
                    OptionType.WIRELESS_LINK_NUM -> link_num = value as? wireless_link_num
                    OptionType.LIVE_BROADCAST_STATUS -> live_broadcast_status = value as? LiveBroadCastStatus
                    OptionType.LONG_BATTERY -> long_battery_mode_enabled = (value as? Long_Battery_Mode_Type) ?: Long_Battery_Mode_Type.LONG_BATTERY_NONE
                    OptionType.P2P_TRANS_STATUS -> p2p_trans_status = value as? NotificationP2pTransStatus
                    OptionType.HORIZON_FILP_ENABLE -> horizon_filp_enable = (value as? Boolean) ?: false
                    OptionType.LENS_ACCESSORIES_INFO -> lens_accessories_info = value as? LensAccessoriesInfo
                    OptionType.MEDIA_OFFSET_V6 -> media_offset_v6 = (value as? String) ?: ""
                    OptionType.STREET_PHOTO_TYPE -> street_photo_type = (value as? Street_Photo_Type) ?: Street_Photo_Type.NO_ADORN
                    OptionType.QC_SINGLE_PRESS_SHOOT_TYPE -> Unit
                    OptionType.NEED_ADAPTIVE_ROTATION -> Unit
                    OptionType.OPTIONS_NUM -> Unit
                    OptionType.MEDIA_OFFSET_V8 -> Unit
                    OptionType.GEOGRAPHIC_TIME_ZONE -> Unit

                    // C9新增
                    OptionType.STORAGE_STATE_LIST -> storage_state_list = (value as? List<StorageState>) ?: emptyList()
                    OptionType.CARD_LOCATION_LAST_UPDATE -> Unit
                    OptionType.FC_FLIGHT_ID -> Unit
                    OptionType.ZOOM_SPEED -> Unit
                    OptionType.DETACHABLE_SCREEN_BATTERY_INFO -> Unit
                    OptionType.IDLE_ANALYZE_SWITCH_ON -> Unit
                    OptionType.CAMERA_OFFSETS -> Unit
                    OptionType.LAST_UPGRADE_SUMMARY -> Unit
                    OptionType.BLUETOOTH_OPERATE -> Unit
                    OptionType.APP_WAKEUP_TYPE -> Unit
                    OptionType.IS_NEED_REBUILD_PIPELINE -> Unit
                    OptionType.AF_LENS_INFO_OPTION -> Unit
                    OptionType.SELFIE_FOLLOW_SWITCH -> Unit
                    OptionType.AI_FEATURE_STATUS_LIST -> Unit
                    OptionType.AI_FEATURE_SWITCH_CTRL -> Unit
                    OptionType.BLUETOOTH_CURR_INFO -> Unit
                    OptionType.BLUETOOTH_MAC_BIND -> Unit

                    // c9_beat2.1新增
                    OptionType.UOM_REAL_NAME_STATE -> Unit
                    OptionType.UOM_ACTIVATE_STATE -> Unit

                    else -> Unit
                }
            }
        }
    }


    // get transform
    fun optionTransform(optionType: OptionType, optionMap: Map<OptionType, Any?>): Any? {
        val option: Any = optionMap[optionType] ?: return null
        return when (optionType) {
            OptionType.CAMERA_TYPE -> {
                val cameraType = option as String
                // NanoS相机CameraType和Wifi Ssid均为空，在sdk里遇到此情况强制认为是NanoS
                if (cameraType.isEmpty()) CameraType.NANO_S else CameraType.getForType(cameraType)
            }

            OptionType.VIDEO_RESOLUTION -> {
                val videoResolution = option as VideoResolution
                RecordResolution.nativeOf(videoResolution.value)
            }

            OptionType.BATTERY_INFO -> {
                val batteryInfo = option as BatteryInfo
                BatteryData(
                    batteryInfo.power_type != PowerType.BATTERY,
                    batteryInfo.battery_level,
                    batteryInfo.battery_scale,
                    BatteryData.Type.nativeOf(batteryInfo.battery_type.value),
                    batteryInfo.battery_temp,
                )
            }

            OptionType.CHARGEBOX_CONNECTED_STATUS -> {
                val chargeBox = option as ChargeboxConnectedStatus
                val batteryData = BatteryData(
                    chargeBox.chargingbox_battery_status?.power_type == PowerType.ADAPTER_,
                    chargeBox.chargingbox_battery_status?.battery_level ?: 0,
                    chargeBox.chargingbox_battery_status?.battery_scale ?: 0,
                    BatteryData.Type.nativeOf(chargeBox.chargingbox_battery_status?.battery_type?.value ?: Battery_type.THICK.value),
                    chargeBox.chargingbox_battery_status?.battery_temp ?: 0,
                )
                ChargeBoxData(
                    chargeBox.chargebox_connected_state == ChargeboxConnectedType.connected,
                    chargeBox.chargebox_usb_connected_state == ChargeboxUsbBtConnectedType.usb_bt_status_connected,
                    chargeBox.chargebox_bt_connected_state == ChargeboxUsbBtConnectedType.usb_bt_status_connected,
                    chargeBox.chargebox_onoff_status == ChargeboxOnOffInfo.online,
                    batteryData
                )
            }

            OptionType.STORAGE_STATE -> {
                val storage = option as StorageState
                StorageData(
                    StorageData.State.nativeOf(storage.card_state.value),
                    storage.free_space,
                    storage.total_space,
                    StorageData.FileLocation.nativeOf(storage.location.value),
                    storage.card_spec,
                )
            }

            OptionType.STORAGE_STATE_LIST -> {
                val storageList = option as? List<StorageState> ?: emptyList()
                storageList.map { storage ->
                    StorageData(
                        StorageData.State.nativeOf(storage.card_state.value),
                        storage.free_space,
                        storage.total_space,
                        StorageData.FileLocation.nativeOf(storage.location.value),
                        storage.card_spec,
                    )
                }
            }

            OptionType.WIFI_INFO -> {
                val wifiInfo = option as WifiInfo
                WiFiData(
                    wifiInfo.ssid,
                    wifiInfo.password,
                    wifiInfo.channel,
                    WiFiData.Mode.nativeOf(wifiInfo.mode.value),
                    WiFiData.State.nativeOf(wifiInfo.wifi_state.value),
                    wifiInfo.passwd_version,
                    wifiInfo.mac_addr,
                    wifiInfo.is_busy
                )
            }

            OptionType.WIFI_CHANNEL_LIST -> {
                val channelList = option as WifiChannelList
                WiFiChannel(channelList.country_code, channelList.channel_list.toByteArray().map { it.toUByte().toInt() }.filter { it != 0 })
            }

            OptionType.PHOTO_SUB_MODE -> {
                val subMode = option as PhotoSubMode
                SdkPhotoSubMode.nativeOf(subMode.value)
            }

            OptionType.VIDEO_SUB_MODE -> {
                val subMode = option as VideoSubMode
                SdkVideoSubMode.nativeOf(subMode.value)
            }

            OptionType.VIDEO_ENCODE_TYPE -> {
                val videoEncode = option as VideoEncodeType
                VideoEncode.nativeOf(videoEncode.value)
            }

            OptionType.CAMERA_LANGUAGE -> {
                val language = option as LANGUAGE_TYPE
                LanguageType.nativeOf(language.value)
            }

            OptionType.INSTAPANO_FOCUS_SENSOR -> {
                val sensor = option as SensorDevice
                FocusSensor.nativeOf(sensor.value)
            }

            OptionType.EXPECT_OUTPUT_TYPE -> {
                val expectOutputType = option as ExpectOutputType
                SdkExpectOutputType.nativeOf(expectOutputType.value)
            }

            OptionType.LENS_ACCESSORIES_INFO -> {
                val lensAccessoriesInfo = option as LensAccessoriesInfo
                LensAccessoryType.nativeOf(lensAccessoriesInfo.lens_accessories_type.value)
            }

            else -> option
        }
    }

    // set transform
    fun mapTransform(optionType: OptionType, data: Any): Map<OptionType, Any> {
        return mutableMapOf(
            optionType to when (optionType) {

                OptionType.CAMERA_TYPE -> {
                    val cameraType = data as CameraType
                    cameraType.type
                }

                OptionType.VIDEO_RESOLUTION -> {
                    val resolution = data as RecordResolution
                    VideoResolution.fromValue(resolution.nativeValue) ?: VideoResolution.RES_3840_1920P30
                }


                OptionType.PHOTO_SUB_MODE -> {
                    val subMode = data as SdkPhotoSubMode
                    PhotoSubMode.fromValue(subMode.nativeValue) ?: PhotoSubMode.PHOTO_SINGLE
                }

                OptionType.VIDEO_SUB_MODE -> {
                    val subMode = data as SdkVideoSubMode
                    VideoSubMode.fromValue(subMode.nativeValue) ?: VideoSubMode.VIDEO_NORMAL
                }

                OptionType.VIDEO_ENCODE_TYPE -> {
                    val videoEncode = data as VideoEncode
                    VideoEncodeType.fromValue(videoEncode.nativeValue) ?: VideoEncodeType.ENCODE_H264
                }

                OptionType.CAMERA_LANGUAGE -> {
                    val language = data as LanguageType
                    LANGUAGE_TYPE.fromValue(language.nativeValue) ?: LANGUAGE_TYPE.EN
                }

                OptionType.INSTAPANO_FOCUS_SENSOR -> {
                    val focusSensor = data as FocusSensor
                    SensorDevice.fromValue(focusSensor.nativeValue) ?: SensorDevice.SENSOR_DEVICE_UNKNOWN
                }

                OptionType.EXPECT_OUTPUT_TYPE -> {
                    val expectOutputType = data as SdkExpectOutputType
                    ExpectOutputType.fromValue(expectOutputType.nativeValue) ?: ExpectOutputType.DEFAULT
                }

                OptionType.WIFI_CHANNEL_LIST -> {
                    val wifiChannel = data as WiFiChannel
                    WifiChannelList().apply { country_code = wifiChannel.country }
                }

                OptionType.LENS_ACCESSORIES_INFO -> {
                    val lensAccessoryType = data as LensAccessoryType
                    val lensAccessoriesInfo = LensAccessoriesInfo()
                    lensAccessoriesInfo.lens_accessories_type = Lens_Accessories_Type.fromValue(lensAccessoryType.nativeValue) ?: Lens_Accessories_Type.LENS_ACCESSORIES_TYPE_UNKOWN
                    lensAccessoriesInfo
                }

                else -> data
            }
        )
    }
}