package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.ExportType
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class ExportTypeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<ExportType>(CommonAttrKeys.EXPORT_TYPE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): ExportType = ExportType.UNKNOWN

    override fun fromInt(value: Int): ExportType {
        return ExportType.nativeOf(value)
    }

    override fun fromName(name: String): ExportType {
        return ExportType.protoOf(name)
    }

    override fun toInt(data: ExportType): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<ExportType> {
        return device.getExportType(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<ExportType> {
        return device.fetchExportType(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: ExportType): Result<Unit> {
        return device.setExportType(functionMode, value)
    }

}