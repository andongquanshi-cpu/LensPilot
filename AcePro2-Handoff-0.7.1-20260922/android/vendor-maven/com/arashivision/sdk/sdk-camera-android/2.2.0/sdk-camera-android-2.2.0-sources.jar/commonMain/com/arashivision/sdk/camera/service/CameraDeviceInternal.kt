package com.arashivision.sdk.camera.service

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.sdk.camera.api.CameraDevice
import com.arashivision.sdk.camera.api.param.listener.AuthorizationListener
import com.arashivision.sdk.camera.api.param.listener.BleWakeUpListener
import com.arashivision.sdk.camera.api.param.listener.DisconnectListener
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.DeviceCoreImpl
import com.arashivision.sdk.camera.core.callback.BleScanCallback
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.event.DeviceEvent.AuthorizationResultEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.WiFiAwareConnectHint
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationStatus
import com.arashivision.sdk.camera.provider.CameraModuleProviderImpl
import com.arashivision.sdk.camera.service.capture.CameraCaptureService
import com.arashivision.sdk.camera.service.file.CameraFileService
import com.arashivision.sdk.camera.service.firmware.CameraFirmwareService
import com.arashivision.sdk.camera.service.preview.CameraPreviewService
import com.arashivision.sdk.camera.service.system.CameraSystemService
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.coroutine.BaseCoroutine
import com.arashivision.sdk.common.exception.AlreadyReleasedException
import com.arashivision.sdk.common.kotlin.invokeCallback
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.common.type.KMPBleDevice
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class CameraDeviceInternal(private val connectType: ConnectType) : CameraDevice, BaseCoroutine("CameraDevice") {

    companion object {
        const val TAG = "CameraDeviceInternal"
    }

    private var camera = DeviceCoreImpl(connectType, mainScope)
    internal val deviceCore: DeviceCore
        get() = camera

    private var _system = CameraSystemService(camera, connectType, mainScope, { isDestroyed }) { _preview.getCurrentPreviewStatus() }
    override val system: CameraSystemService
        get() = _system

    private var _capture = CameraCaptureService(camera, connectType, mainScope) { isDestroyed }
    override val capture: CameraCaptureService
        get() = _capture

    private var _preview = CameraPreviewService(camera, connectType, mainScope) { isDestroyed }
    override val preview: CameraPreviewService
        get() = _preview

    private var _file = CameraFileService(camera, connectType, mainScope) { isDestroyed }
    override val file: CameraFileService
        get() = _file

    private var _firmware = CameraFirmwareService(camera, connectType, ioScope) { isDestroyed }
    override val firmware: CameraFirmwareService
        get() = _firmware

    override fun isConnected(): Boolean = camera.isConnected

    private val disconnectListeners = mutableListOf<DisconnectListener>()
    private val disconnectMutex = Mutex()

    private val authorizationListeners = mutableListOf<AuthorizationListener>()
    private val authorizationMutex = Mutex()

    private var eventJob: Job? = null

    init {
        bindCamera()
    }

    private fun bindCamera() {
        Logger.i(TAG, "bind camera")
        camera.init()
        _system = CameraSystemService(camera, connectType, mainScope, { isDestroyed }) { _preview.getCurrentPreviewStatus() }
        _capture = CameraCaptureService(camera, connectType, mainScope) { isDestroyed }
        _preview = CameraPreviewService(camera, connectType, mainScope) { isDestroyed }
        _file = CameraFileService(camera, connectType, mainScope) { isDestroyed }
        _firmware = CameraFirmwareService(camera, connectType, mainScope) { isDestroyed }
        eventJob = mainScope.launch {
            camera.events.collect { event ->
                mainScope.launch {
                    when (event) {
                        is DeviceEvent.DisconnectedEvent -> {
                            Logger.d(TAG, "DisconnectedEvent, event=$event")
                            rebind()
                            val snapshot = disconnectMutex.withLock { disconnectListeners.toList() }
                            snapshot.forEach { it.onDisconnect(event.throwable) }
                        }

                        is AuthorizationResultEvent -> {
                            Logger.i(TAG, "AuthorizationResultEvent: operationType=${event.operationType}  result=${event.result}")
                            val snapshot = authorizationMutex.withLock { authorizationListeners.toList() }
                            snapshot.forEach { it.onAuthorizationResult(event.operationType, event.result) }
                        }

                        else -> {}
                    }
                }
            }
        }
    }

    private suspend fun unbind() {
        Logger.i(TAG, "unbind camera")
        CameraModuleProviderImpl.setCamera(null, connectType)
        camera.release()
        eventJob?.cancel()
    }

    private suspend fun rebind() {
        Logger.i(TAG, "rebind camera")
        unbind()
        camera = DeviceCoreImpl(connectType, mainScope)
        bindCamera()
    }

    override fun scan(timeoutMs: Long, bleScanCallback: BleScanCallback) {
        if (isDestroyed) {
            bleScanCallback.onError(AlreadyReleasedException())
            return
        }
        camera.scan(timeoutMs, bleScanCallback)
    }

    override fun stopScan() {
        if (isDestroyed) return
        camera.stopScan()
    }

    override fun bleWakeUp(cameraType: CameraType, deviceName: String, listener: BleWakeUpListener) {
        camera.bleWakeUp(cameraType, deviceName, listener)
    }

    override fun connect(connectHint: Any?, callback: Callback<Unit>) {
        if (isDestroyed) {
            callback.onThrowable(AlreadyReleasedException())
            return
        }
        mainScope.launch {
            connect(connectHint).invokeCallback(callback)
        }
    }

    override suspend fun connect(connectHint: Any?, isBleOnly: Boolean): Result<Unit> {
        if (isDestroyed) return Result.failure(AlreadyReleasedException())
        return camera.connect(connectHint).onSuccess {
            CameraModuleProviderImpl.setCamera(this, connectType)
            if (connectType == ConnectType.BLE && !isBleOnly) {
                camera.fetchWiFiData()
            } else {
                camera.initAllOptions()
                capture.loadJson()
            }
        }.onFailure {
            camera.disconnect()
            rebind()
        }
    }

    override suspend fun connectBle(bleDeviceCore: BleDeviceCore, isBleOnly: Boolean): Result<Unit> = connect(bleDeviceCore)

    override suspend fun connectBle(kmpBleDevice: KMPBleDevice, isBleOnly: Boolean): Result<Unit> = connect(kmpBleDevice)

    override fun connectBle(bleDeviceCore: BleDeviceCore, isBleOnly: Boolean, callback: Callback<Unit>) = connect(bleDeviceCore, callback)

    override fun connectBle(kmpBleDevice: KMPBleDevice, isBleOnly: Boolean, callback: Callback<Unit>) = connect(kmpBleDevice, callback)

    override fun connectUsb(callback: Callback<Unit>) = connect(callback = callback)

    override suspend fun connectUsb(): Result<Unit> = connect()

    override fun connectWiFi(networkId: Int, callback: Callback<Unit>) = connect(networkId, callback)

    override suspend fun connectWiFi(networkId: Int): Result<Unit> = connect(networkId)

    override suspend fun connectWiFiAware(networkHandle: Long, peerIpv6: String): Result<Unit> =
        connect(WiFiAwareConnectHint(networkHandle, peerIpv6))

    override fun connectWiFiAware(networkHandle: Long, peerIpv6: String, callback: Callback<Unit>) =
        connect(WiFiAwareConnectHint(networkHandle, peerIpv6), callback)

    override suspend fun disconnect(): Result<Unit> {
        if (isDestroyed) return Result.failure(AlreadyReleasedException())
        if (!camera.isConnected) return Result.success(Unit)
        return try {
            camera.disconnect()
            rebind()
            Result.success(Unit)
        } catch (throwable: Throwable) {
            Result.failure(throwable)
        }
    }

    override fun disconnect(callback: Callback<Unit>) {
        if (isDestroyed) {
            callback.onThrowable(AlreadyReleasedException())
            return
        }
        mainScope.launch {
            disconnect().invokeCallback(callback)
        }
    }

    override fun getSupportCameraType(): List<CameraType> {
        return camera.getSupportCameraType()
    }

    // ------------------- 授权 -------------------

    override suspend fun checkAuthorization(): Result<AuthorizationStatus> {
        if (isDestroyed) return Result.failure(AlreadyReleasedException())
        return camera.checkAuthorization()
    }

    override fun checkAuthorization(callback: Callback<AuthorizationStatus>) {
        if (isDestroyed) {
            callback.onThrowable(AlreadyReleasedException())
            return
        }
        mainScope.launch { camera.checkAuthorization().invokeCallback(callback) }
    }

    override suspend fun cancelAuthorization(): Result<Unit> {
        if (isDestroyed) return Result.failure(AlreadyReleasedException())
        return camera.cancelAuthorization()
    }

    override fun cancelAuthorization(callback: Callback<Unit>) {
        if (isDestroyed) {
            callback.onThrowable(AlreadyReleasedException())
            return
        }
        mainScope.launch { camera.cancelAuthorization().invokeCallback(callback) }
    }

    override fun registerAuthorizationListener(listener: AuthorizationListener) {
        if (isDestroyed) return
        mainScope.launch {
            authorizationMutex.withLock {
                if (!authorizationListeners.contains(listener)) {
                    authorizationListeners.add(listener)
                }
            }
        }
    }

    override fun unregisterAuthorizationListener(listener: AuthorizationListener) {
        if (isDestroyed) return
        mainScope.launch {
            authorizationMutex.withLock { authorizationListeners.remove(listener) }
        }
    }

    // ------------------- 断连监听 -------------------
    override fun registerDisconnectListener(listener: DisconnectListener) {
        Logger.i(TAG, "registerDisconnectListener, listener=$listener   isDestroyed=$isDestroyed")
        if (isDestroyed) return
        mainScope.launch {
            disconnectMutex.withLock {
                if (!disconnectListeners.contains(listener)) {
                    disconnectListeners.add(listener)
                }
            }
        }
    }

    override fun unregisterDisconnectListener(listener: DisconnectListener) {
        Logger.i(TAG, "unregisterDisconnectListener, listener=$listener   isDestroyed=$isDestroyed")
        if (isDestroyed) return
        mainScope.launch {
            disconnectMutex.withLock { disconnectListeners.remove(listener) }
        }
    }

    override suspend fun onCoroutineDestroyed() {
        super.onCoroutineDestroyed()
        disconnectMutex.withLock { disconnectListeners.clear() }
        authorizationMutex.withLock { authorizationListeners.clear() }
        system.destroy()
        capture.destroy()
        preview.destroy()
        file.destroy()
        firmware.destroy()
        unbind()
    }

    override fun release() {
        camera.disconnect()
        destroy()
    }

}
