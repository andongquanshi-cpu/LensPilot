package com.arashivision.sdk.camera.service.capture.param.doubles

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded

internal class EvCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : DoubleCameraParam(CommonAttrKeys.EXPOSURE_BIAS, managerProvider, deviceCoreProvider, 1) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Double> {
        return device.getExposureBias(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Double> {
        return device.fetchExposureBias(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Double): Result<Unit> {
        return device.setExposureBias(functionMode, value).thenMirrorVideoLiveIfNeeded(device, functionMode) {
            device.setExposureBias(FunctionMode.VIDEO_LIVE, value)
        }
    }

}