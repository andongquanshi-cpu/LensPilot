package com.arashivision.sdk.camera.service.capture.json

import com.arashivision.sdk.common.exception.InvalidLensException
import com.arashivision.sdk.common.exception.InvalidModeException
import com.arashivision.sdk.common.exception.JsonParseException
import com.arashivision.sdk.common.exception.MissingAttributeException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.success
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject

// 以下均为设备配置 JSON（如 x4_air.json）里的固定字段名，JSON 结构大致为：
// { lensType: { photo_sub_mode/video_sub_mode/live_sub_mode: [...], mode: { support_attrs: [...], attr: { depend_on: [...], list: { default: [...], dependencyKey: [...] } } } } }
private const val PHOTO_KEY = "photo_sub_mode"
private const val VIDEO_KEY = "video_sub_mode"
private const val LIVE_KEY = "live_sub_mode"
private const val SUPPORT_ATTRS = "support_attrs"
private const val DEPEND_ON = "depend_on"
private const val LIST = "list"
private const val DEFAULT = "default"

/**
 * 对应 C++ `CameraFunctionHandle`，负责解析属性配置 JSON 并提供只读查询能力。
 * 本类不维护状态，所有方法均为纯函数，适合多线程共享。
 */
internal class CameraFunctionCatalog private constructor(private val root: JsonObject) {

    companion object {
        /**
         * 将 JSON 字符串解析成 [CameraFunctionCatalog]。
         * 若格式错误会返回 [com.arashivision.sdk.common.exception.JsonParseException]，方便上层统一处理。
         */
        fun fromJson(json: String): Result<CameraFunctionCatalog> = runCatching {
            cameraJsonParser.parseToJsonElement(json).jsonObject
        }.fold(
            onSuccess = { CameraFunctionCatalog(it).success() },
            onFailure = { JsonParseException("Attr JSON parse failed: ${it.message}").failure() }
        )
    }

    /** 返回 JSON 中声明的所有镜头 key。 */
    fun lensTypes(): List<String> = root.keys.sorted()

    /**
     * 整理相机支持的所有模式，包含 photo/video/live 三个分支。
     * @return 去重后的模式名列表。
     */
    fun functionModes(lensType: String): Result<List<String>> {
        val lensNode = lensNode(lensType) ?: return Result.failure(InvalidLensException(lensType))
        val allModes = LinkedHashSet<String>()
        val buckets = arrayOf(PHOTO_KEY, VIDEO_KEY, LIVE_KEY)
        for (bucket in buckets) {
            val modes = lensNode[bucket]?.asStringList()
            if (modes != null) {
                allModes.addAll(modes)
            }
        }
        return Result.success(allModes.toList())
    }

    /**
     * 读取指定分支（如 photo_sub_mode）下的模式。
     */
    fun functionModes(lensType: String, key: String): Result<List<String>> {
        val lensNode = lensNode(lensType) ?: return Result.failure(InvalidLensException(lensType))
        return Result.success(lensNode[key]?.asStringList().orEmpty())
    }

    /**
     * 查询当前镜头 + 模式支持的属性 Key 列表。
     */
    fun supportedAttributes(lensType: String, mode: String): Result<List<String>> {
        val node = modeNode(lensType, mode) ?: return Result.failure(InvalidModeException(mode))
        return Result.success(node[SUPPORT_ATTRS]?.asStringList().orEmpty())
    }

    /**
     * 某些属性存在依赖（例如分辨率依赖镜头或模式），该方法返回所需依赖字段。
     */
    fun dependOnAttributes(lensType: String, mode: String, attr: String): Result<List<String>> {
        val attrNode = attributeNode(lensType, mode, attr) ?: return Result.failure(MissingAttributeException(attr))
        return Result.success(attrNode[DEPEND_ON]?.asStringList().orEmpty())
    }

    /**
     * 根据依赖 key（如 "4K|30fps"）查找对应的可选值。
     * JSON 中结构为：attr -> list -> dependencyKey -> [value ...]
     *
     * 排查提示：dependencyKey 为 null（依赖属性尚未在缓存中取值）或未命中任何具体分支时，
     * 都会 fallback 到 "default" 分支。某些设备/模式下 default 分支被有意配置为更保守的取值集合
     * （例如只允许全自动），并不代表 JSON 里没有定义完整的候选值列表——完整列表实际按 dependencyKey 分开存放。
     */
    fun attrValues(
        lensType: String,
        mode: String,
        attr: String,
        dependencyKey: String?
    ): Result<List<String>> {
        val attrNode = attributeNode(lensType, mode, attr) ?: return Result.failure(MissingAttributeException(attr))
        val listNode = attrNode[LIST]?.jsonObject ?: return Result.success(emptyList<String>())
        val values = listNode[dependencyKey ?: "default"]?.asStringList() ?: listNode["default"]?.asStringList().orEmpty()
        return Result.success(values)
    }

    /**
     * 当特定依赖未命中时，回退到 "default" 所描述的可选值。
     */
    fun defaultAttrValues(lensType: String, mode: String, attr: String): Result<List<String>> {
        val attrNode = attributeNode(lensType, mode, attr) ?: return Result.failure(MissingAttributeException(attr))
        val listNode = attrNode[LIST]?.jsonObject ?: return Result.success(emptyList<String>())
        val defaults = listNode[DEFAULT]?.asStringList() ?: emptyList()
        return Result.success(defaults)
    }

    /** 取镜头像 JSON 节点，即 root 下以 lensType 为 key 的顶层节点。 */
    private fun lensNode(lensType: String): JsonObject? = root[lensType]?.jsonObject

    /** 取模式节点，模式可以是自定义 key（如 photo_single/video_normal），路径为 lens -> mode。 */
    private fun modeNode(lensType: String, mode: String): JsonObject? =
        lensNode(lensType)?.get(mode)?.jsonObject

    /**
     * 取属性节点，路径为 lens -> mode -> attr。
     * 排查某属性取值异常时，这是定位对应 JSON 片段的入口——先按 lensType/mode/attr 三级路径手动核对 JSON。
     */
    private fun attributeNode(lensType: String, mode: String, attr: String): JsonObject? =
        modeNode(lensType, mode)?.get(attr)?.jsonObject

    /**
     * 安全地将 JsonElement 转为字符串列表，忽略非 primitive 元素（静默丢弃，不会抛异常或报错）。
     * 排查提示：若 JSON 里某个数组元素被写成了对象/嵌套数组，会被这里悄悄过滤掉，导致返回的列表比 JSON 视觉上看到的短。
     */
    private fun JsonElement?.asStringList(): List<String>? {
        if (this !is JsonArray) return null
        val result = ArrayList<String>(this.size)
        for (element in this) {
            val value = (element as? JsonPrimitive)?.contentOrNull
            if (value != null) {
                result.add(value)
            }
        }
        return result
    }

}

