package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

// proto: IQ_3A_INVALID=0, IQ_3A_NORMAL=1, IQ_3A_PRO=2
enum class Iq3AMode(override val nativeValue: Int) : BaseEnum {
    NORMAL(1),
    PRO(2);

    companion object {
        fun nativeOf(value: Int?): Iq3AMode = entries.firstOrNull { it.nativeValue == value } ?: NORMAL
    }
}
