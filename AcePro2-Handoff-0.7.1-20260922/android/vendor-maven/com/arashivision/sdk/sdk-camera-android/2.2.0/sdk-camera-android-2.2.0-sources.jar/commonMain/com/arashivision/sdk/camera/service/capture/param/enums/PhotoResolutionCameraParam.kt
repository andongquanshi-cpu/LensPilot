package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.PhotoResolution
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded

internal class PhotoResolutionCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<PhotoResolution>(CommonAttrKeys.PHOTO_RESOLUTION, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): PhotoResolution = PhotoResolution.UNKNOWN

    override fun fromInt(value: Int): PhotoResolution {
        return PhotoResolution.nativeOf(value)
    }

    override fun fromName(name: String): PhotoResolution {
        return PhotoResolution.protoOf(name)
    }

    override fun toInt(data: PhotoResolution): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PhotoResolution> {
        return device.getPhotoResolution(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<PhotoResolution> {
        return device.fetchPhotoResolution(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: PhotoResolution): Result<Unit> {
        return device.setPhotoResolution(functionMode, value).thenMirrorVideoLiveIfNeeded(device, functionMode) {
            device.setPhotoResolution(FunctionMode.VIDEO_LIVE, value)
        }
    }

}