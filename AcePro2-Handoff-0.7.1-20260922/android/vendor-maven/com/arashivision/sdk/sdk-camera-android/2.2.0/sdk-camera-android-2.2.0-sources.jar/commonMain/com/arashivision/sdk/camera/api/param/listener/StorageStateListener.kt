package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.option.StorageData

/**
 * 相机存储状态监听器。
 *
 * 用于监听相机内部存储或 SD 卡的状态变化（如剩余空间、拔插事件、格式化状态等）。
 */
interface StorageStateListener {
    /**
     * 当相机存储状态发生变化时回调。
     *
     * @param storageDataList 包含存储介质当前状态、总容量、可用容量等信息的对象。
     */
    fun onStorageStateListChanged(storageDataList: List<StorageData>)
}
