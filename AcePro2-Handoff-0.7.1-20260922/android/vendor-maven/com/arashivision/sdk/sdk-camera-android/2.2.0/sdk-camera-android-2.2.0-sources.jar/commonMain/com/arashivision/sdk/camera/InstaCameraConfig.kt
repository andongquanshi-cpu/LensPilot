package com.arashivision.sdk.camera

import com.arashivision.sdk.camera.platform.getDefaultBleScanMode
import com.arashivision.sdk.common.log.LogLevel

class InstaCameraConfig {
    var cacheDir: String? = null
    var fileDir: String? = null
    var logLevel: LogLevel = LogLevel.VERBOSE

    /**
     * 蓝牙扫描模式，目前仅车企理想使用
     */
    var scanMode = getDefaultBleScanMode()
}