package com.arashivision.sdk.camera.api.preview

/**
 * 相机直播推流状态监听接口。
 *
 * 通过 [com.arashivision.sdk.camera.api.CameraPreview.registerCameraLiveListener] 注册。
 * 所有回调均在协程 scope 内分发，非主线程，如需更新 UI 请切换到主线程。
 */
interface CameraLiveListener {

    /**
     * 推流成功启动时回调。
     */
    fun onStarted() {}

    /**
     * 推流帧率更新时回调。
     *
     * @param fps 当前实时帧率。
     */
    fun onFps(fps: Int) {}

    /**
     * 推流正常停止时回调。
     */
    fun onStopped() {}

    /**
     * 推流发生错误时回调。
     *
     * @param errorCode 底层错误码。
     * @param message   错误描述，可能为 null。
     */
    fun onFailed(errorCode: Int, message: String?) {}
}
