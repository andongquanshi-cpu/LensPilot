package com.arashivision.sdk.camera.core.delegate.stream

import com.arashivision.onecamera.OneDriver
import insta360.messages.StartLiveStream

interface PreviewStreamDelegate {
    fun openPreviewStream(startStreamingParam: StartLiveStream, offset: String)
    fun closePreviewStream()
    fun requestStreamIframe()
    fun setStreamListener(streamListener: OneDriver.OnStreamListener?)
}