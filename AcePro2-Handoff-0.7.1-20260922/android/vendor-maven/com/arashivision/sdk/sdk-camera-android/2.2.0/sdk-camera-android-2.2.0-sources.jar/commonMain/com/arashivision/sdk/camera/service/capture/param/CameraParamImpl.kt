package com.arashivision.sdk.camera.service.capture.param

import com.arashivision.sdk.camera.api.param.CameraParam
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.success

abstract class CameraParamImpl<T>(
    protected val key: String,
    protected val managerProvider: () -> Result<CameraAttributeManager>,
    protected val deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParam<T> {

    protected val TAG = "CameraParamImpl"

    private val listeners = LinkedHashSet<(T) -> Unit>()

    override suspend fun getValue(): Result<T> {
        return managerProvider().fold(
            onSuccess = { manager -> deviceCoreProvider().map { Pair(manager, it) } },
            onFailure = { it.failure() }
        ).flatMap {
            reader(it.first, it.second)
        }
    }

    override suspend fun fetchValue(): Result<T> {
        return managerProvider().fold(
            onSuccess = { manager -> deviceCoreProvider().map { Pair(manager, it) } },
            onFailure = { it.failure() }
        ).flatMap {
            fetcher(it.first, it.second)
        }
    }

    override suspend fun setValue(value: T): Result<Unit> {
        return managerProvider().fold(
            onSuccess = { manager -> deviceCoreProvider().map { Pair(manager, it) } },
            onFailure = { it.failure() }
        ).flatMap {
            writer(it.first, it.second, value)
        }.onSuccess {
            listeners.forEach { it(value) }
        }
    }

    override suspend fun getSupported(): Result<List<T>> = managerProvider().flatMap { supportedLoader(it) }

    abstract suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<T>
    abstract suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<T>
    abstract suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: T): Result<Unit>
    abstract suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<T>>

    protected fun invalidStateException(throwable: Throwable, key: String) = InvalidStateException("${throwable.message}: Device returned null for $key")

    protected fun currentFunctionMode(): Result<FunctionMode> {
        return managerProvider().flatMap {
            it.currentFunctionModeInt().flatMap { value ->
                FunctionMode.nativeOf(value).success()
            }
        }
    }

    abstract suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode = FunctionMode.NONE): Result<T>
    abstract suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode = FunctionMode.NONE): Result<T>
    abstract suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode = FunctionMode.NONE, value: T): Result<Unit>

    override fun getName(): String {
        return key
    }

    override fun addListener(listener: (T) -> Unit) {
        listeners.add(listener)
    }

    override fun removeListener(listener: (T) -> Unit) {
        listeners.remove(listener)
    }

}
