package com.arashivision.sdk.camera.core.model.photography


// 表示流分辨率的类
class StreamResolution(
    val width: Int, // 宽度
    val height: Int, // 高度
    val fps: Int, // 帧率
    val bitrate: Int, // 比特率
    val valueInCamera: Int // 在相机中的值
) {

    companion object {
        // 4:1
        val STREAM_3840_960_120FPS: StreamResolution = StreamResolution(3840, 960, 120, 40, 137)
        val STREAM_2944_736_180FPS: StreamResolution = StreamResolution(2944, 736, 180, 40, 164)
        val STREAM_2880_720_30FPS: StreamResolution = StreamResolution(2880, 720, 30, 40, 198)

        // 2:1
        val STREAM_7680_3840_30FPS: StreamResolution = StreamResolution(7680, 3840, 30, 40, 167)
        val STREAM_7680_3840_25FPS: StreamResolution = StreamResolution(7680, 3840, 25, 40, 166)
        val STREAM_7680_3840_24FPS: StreamResolution = StreamResolution(7680, 3840, 24, 40, 165)
        val STREAM_6400_3200_30FPS: StreamResolution = StreamResolution(6400, 3200, 30, 40, 118)
        val STREAM_6400_3200_25FPS: StreamResolution = StreamResolution(6400, 3200, 25, 40, 117)
        val STREAM_6400_3200_24FPS: StreamResolution = StreamResolution(6400, 3200, 24, 40, 116)
        val STREAM_6144_3072_30FPS: StreamResolution = StreamResolution(6144, 3072, 30, 40, 121)
        val STREAM_6144_3072_25FPS: StreamResolution = StreamResolution(6144, 3072, 25, 40, 120)
        val STREAM_6144_3072_24FPS: StreamResolution = StreamResolution(6144, 3072, 24, 40, 119)
        val STREAM_6080_3040_30FPS: StreamResolution = StreamResolution(6080, 3040, 30, 40, 96)
        val STREAM_6080_3040_25FPS: StreamResolution = StreamResolution(6080, 3040, 25, 40, 95)
        val STREAM_6080_3040_24FPS: StreamResolution = StreamResolution(6080, 3040, 24, 40, 94)
        val STREAM_5888_2944_30FPS: StreamResolution = StreamResolution(5888, 2944, 30, 40, 188)
        val STREAM_5888_2944_25FPS: StreamResolution = StreamResolution(5888, 2944, 25, 40, 189)
        val STREAM_5888_2944_24FPS: StreamResolution = StreamResolution(5888, 2944, 24, 40, 190)
        val STREAM_5888_2880_30FPS: StreamResolution = StreamResolution(5888, 2880, 30, 40, 142)
        val STREAM_5760_2880_30FPS: StreamResolution = StreamResolution(5760, 2880, 30, 40, 10)
        val STREAM_5760_2880_25FPS: StreamResolution = StreamResolution(5760, 2880, 25, 40, 19)
        val STREAM_5760_2880_24FPS: StreamResolution = StreamResolution(5760, 2880, 24, 40, 20)
        val STREAM_3920_1920_30FPS: StreamResolution = StreamResolution(3920, 1920, 30, 40, 143)
        val STREAM_3840_1920_60FPS: StreamResolution = StreamResolution(3840, 1920, 60, 40, 11)
        val STREAM_3840_1920_50FPS: StreamResolution = StreamResolution(3840, 1920, 50, 40, 12)
        val STREAM_3840_1920_30FPS: StreamResolution = StreamResolution(3840, 1920, 30, 40, 0)
        val STREAM_3840_1920_25FPS: StreamResolution = StreamResolution(3840, 1920, 25, 40, 98)
        val STREAM_3840_1920_24FPS: StreamResolution = StreamResolution(3840, 1920, 24, 40, 97)
        val STREAM_3040_1520_50FPS: StreamResolution = StreamResolution(3040, 1520, 50, 40, 99)
        val STREAM_3040_1520_30FPS: StreamResolution = StreamResolution(3040, 1520, 30, 40, 15)
        val STREAM_3008_1504_100FPS: StreamResolution = StreamResolution(3008, 1504, 100, 40, 13)
        val STREAM_3000_1500_120FPS: StreamResolution = StreamResolution(3000, 1500, 120, 40, 131)
        val STREAM_2880_1440_60FPS: StreamResolution = StreamResolution(2880, 1440, 60, 40, 182)
        val STREAM_2880_1440_50FPS: StreamResolution = StreamResolution(2880, 1440, 50, 40, 181)
        val STREAM_2880_1440_30FPS: StreamResolution = StreamResolution(2880, 1440, 30, 40, 180)
        val STREAM_2880_1440_25FPS: StreamResolution = StreamResolution(2880, 1440, 25, 40, 179)
        val STREAM_2880_1440_24FPS: StreamResolution = StreamResolution(2880, 1440, 24, 40, 178)
        val STREAM_2560_1280_30FPS: StreamResolution = StreamResolution(2560, 1280, 30, 40, 1)
        val STREAM_2176_1088_30FPS: StreamResolution = StreamResolution(2176, 1088, 30, 40, 16)
        val STREAM_1920_960_30FPS: StreamResolution = StreamResolution(1920, 960, 30, 40, 2)
        val STREAM_1440_720_30FPS: StreamResolution = StreamResolution(1440, 720, 30, 40, 9)
        val STREAM_720_360_30FPS: StreamResolution = StreamResolution(720, 360, 30, 40, 17)
        val STREAM_480_240_30FPS: StreamResolution = StreamResolution(480, 240, 30, 40, 18)

        // 1:2
        val STREAM_1440_2880_60FPS: StreamResolution = StreamResolution(1440, 2880, 60, 40, 187)
        val STREAM_1440_2880_50FPS: StreamResolution = StreamResolution(1440, 2880, 50, 40, 186)
        val STREAM_1440_2880_30FPS: StreamResolution = StreamResolution(1440, 2880, 30, 40, 185)
        val STREAM_1440_2880_25FPS: StreamResolution = StreamResolution(1440, 2880, 25, 40, 184)
        val STREAM_1440_2880_24FPS: StreamResolution = StreamResolution(1440, 2880, 24, 40, 183)

        // 16:9
        val STREAM_7680_4320_30FPS: StreamResolution = StreamResolution(7680, 4320, 30, 40, 154)
        val STREAM_7680_4320_25FPS: StreamResolution = StreamResolution(7680, 4320, 25, 40, 211)
        val STREAM_7680_4320_24FPS: StreamResolution = StreamResolution(7680, 4320, 24, 40, 210)
        val STREAM_5312_2988_30FPS: StreamResolution = StreamResolution(5312, 2988, 30, 40, 37)
        val STREAM_5312_2988_25FPS: StreamResolution = StreamResolution(5312, 2988, 25, 40, 46)
        val STREAM_5312_2988_24FPS: StreamResolution = StreamResolution(5312, 2988, 24, 40, 47)
        val STREAM_3840_2160_120FPS: StreamResolution = StreamResolution(3840, 2160, 120, 40, 214)
        val STREAM_3840_2160_100FPS: StreamResolution = StreamResolution(3840, 2160, 100, 40, 220)
        val STREAM_3840_2160_60FPS: StreamResolution = StreamResolution(3840, 2160, 60, 40, 23)
        val STREAM_3840_2160_50FPS: StreamResolution = StreamResolution(3840, 2160, 50, 40, 92)
        val STREAM_3840_2160_30FPS: StreamResolution = StreamResolution(3840, 2160, 30, 40, 24)
        val STREAM_3840_2160_25FPS: StreamResolution = StreamResolution(3840, 2160, 25, 40, 48)
        val STREAM_3840_2160_24FPS: StreamResolution = StreamResolution(3840, 2160, 24, 40, 49)
        val STREAM_3584_2016_60FPS: StreamResolution = StreamResolution(3584, 2016, 60, 40, 200)
        val STREAM_3584_2016_50FPS: StreamResolution = StreamResolution(3584, 2016, 50, 40, 199)
        val STREAM_3584_2016_30FPS: StreamResolution = StreamResolution(3584, 2016, 30, 40, 192)
        val STREAM_3584_2016_25FPS: StreamResolution = StreamResolution(3584, 2016, 25, 40, 193)
        val STREAM_3584_2016_24FPS: StreamResolution = StreamResolution(3584, 2016, 24, 40, 194)
        val STREAM_2720_1530_120FPS: StreamResolution = StreamResolution(2720, 1530, 120, 40, 217)
        val STREAM_2720_1530_100FPS: StreamResolution = StreamResolution(2720, 1530, 100, 40, 25)
        val STREAM_2720_1530_60FPS: StreamResolution = StreamResolution(2720, 1530, 60, 40, 38)
        val STREAM_2720_1530_50FPS: StreamResolution = StreamResolution(2720, 1530, 50, 40, 100)
        val STREAM_2720_1530_30FPS: StreamResolution = StreamResolution(2720, 1530, 30, 40, 39)
        val STREAM_2720_1530_25FPS: StreamResolution = StreamResolution(2720, 1530, 25, 40, 50)
        val STREAM_2720_1530_24FPS: StreamResolution = StreamResolution(2720, 1530, 24, 40, 51)
        val STREAM_2560_1440_60FPS: StreamResolution = StreamResolution(2560, 1440, 60, 40, 61)
        val STREAM_2560_1440_50FPS: StreamResolution = StreamResolution(2560, 1440, 50, 40, 83)
        val STREAM_2560_1440_30FPS: StreamResolution = StreamResolution(2560, 1440, 30, 40, 60)
        val STREAM_2560_1440_25FPS: StreamResolution = StreamResolution(2560, 1440, 25, 40, 69)
        val STREAM_2560_1440_24FPS: StreamResolution = StreamResolution(2560, 1440, 24, 40, 86)
        val STREAM_2560_1440_15FPS: StreamResolution = StreamResolution(2560, 1440, 15, 40, 227)
        val STREAM_1920_1080_240FPS: StreamResolution = StreamResolution(1920, 1080, 240, 40, 27)
        val STREAM_1920_1080_200FPS: StreamResolution = StreamResolution(1920, 1080, 200, 40, 26)
        val STREAM_1920_1080_120FPS: StreamResolution = StreamResolution(1920, 1080, 120, 40, 28)
        val STREAM_1920_1080_100FPS: StreamResolution = StreamResolution(1920, 1080, 100, 40, 150)
        val STREAM_1920_1080_60FPS: StreamResolution = StreamResolution(1920, 1080, 60, 40, 40)
        val STREAM_1920_1080_50FPS: StreamResolution = StreamResolution(1920, 1080, 50, 40, 81)
        val STREAM_1920_1080_30FPS: StreamResolution = StreamResolution(1920, 1080, 30, 40, 29)
        val STREAM_1920_1080_25FPS: StreamResolution = StreamResolution(1920, 1080, 25, 40, 52)
        val STREAM_1920_1080_24FPS: StreamResolution = StreamResolution(1920, 1080, 24, 40, 53)
        val STREAM_1760_990_30FPS: StreamResolution = StreamResolution(1760, 990, 30, 40, 108)
        val STREAM_1600_900_30FPS: StreamResolution = StreamResolution(1600, 900, 30, 40, 107)
        val STREAM_1280_720_30FPS: StreamResolution = StreamResolution(1280, 720, 30, 40, 43)
        val STREAM_1152_648_30FPS: StreamResolution = StreamResolution(1152, 648, 30, 40, 138)
        val STREAM_640_360_30FPS: StreamResolution = StreamResolution(640, 360, 30, 40, 75)
        val STREAM_424_240_15FPS: StreamResolution = StreamResolution(424, 240, 15, 40, 34)

        // 9:16
        val STREAM_2160_3840_60: StreamResolution = StreamResolution(2160, 3840, 60, 40, 122)
        val STREAM_2160_3840_50: StreamResolution = StreamResolution(2160, 3840, 50, 40, 123)
        val STREAM_2160_3840_30: StreamResolution = StreamResolution(2160, 3840, 30, 40, 124)
        val STREAM_2160_3840_25: StreamResolution = StreamResolution(2160, 3840, 25, 40, 125)
        val STREAM_2160_3840_24: StreamResolution = StreamResolution(2160, 3840, 24, 40, 126)
        val STREAM_2016_3584_60FPS: StreamResolution = StreamResolution(2016, 3584, 60, 40, 202)
        val STREAM_2016_3584_50FPS: StreamResolution = StreamResolution(2016, 3584, 50, 40, 201)
        val STREAM_2016_3584_30FPS: StreamResolution = StreamResolution(2016, 3584, 30, 40, 195)
        val STREAM_2016_3584_25FPS: StreamResolution = StreamResolution(2016, 3584, 25, 40, 196)
        val STREAM_2016_3584_24FPS: StreamResolution = StreamResolution(2016, 3584, 24, 40, 197)
        val STREAM_1530_2720_60: StreamResolution = StreamResolution(1530, 2720, 60, 40, 132)
        val STREAM_1530_2720_50: StreamResolution = StreamResolution(1530, 2720, 50, 40, 133)
        val STREAM_1530_2720_30: StreamResolution = StreamResolution(1530, 2720, 30, 40, 134)
        val STREAM_1530_2720_25: StreamResolution = StreamResolution(1530, 2720, 25, 40, 135)
        val STREAM_1530_2720_24: StreamResolution = StreamResolution(1530, 2720, 24, 40, 136)
        val STREAM_1440_2560_60FPS: StreamResolution = StreamResolution(1440, 2560, 60, 40, 66)
        val STREAM_1440_2560_50FPS: StreamResolution = StreamResolution(1440, 2560, 50, 40, 84)
        val STREAM_1440_2560_30FPS: StreamResolution = StreamResolution(1440, 2560, 30, 40, 63)
        val STREAM_1440_2560_25FPS: StreamResolution = StreamResolution(1440, 2560, 25, 40, 70)
        val STREAM_1440_2560_24FPS: StreamResolution = StreamResolution(1440, 2560, 24, 40, 87)
        val STREAM_1440_2560_15FPS: StreamResolution = StreamResolution(1440, 2560, 15, 40, 228)
        val STREAM_1080_1920_120FPS: StreamResolution = StreamResolution(1080, 1920, 120, 40, 88)
        val STREAM_1080_1920_100FPS: StreamResolution = StreamResolution(1080, 1920, 100, 40, 151)
        val STREAM_1080_1920_60FPS: StreamResolution = StreamResolution(1080, 1920, 60, 40, 68)
        val STREAM_1080_1920_50FPS: StreamResolution = StreamResolution(1080, 1920, 50, 40, 82)
        val STREAM_1080_1920_30FPS: StreamResolution = StreamResolution(1080, 1920, 30, 40, 64)
        val STREAM_1080_1920_25FPS: StreamResolution = StreamResolution(1080, 1920, 25, 40, 71)
        val STREAM_1080_1920_24FPS: StreamResolution = StreamResolution(1080, 1920, 24, 40, 85)
        val STREAM_720_1280_30FPS: StreamResolution = StreamResolution(720, 1280, 30, 40, 72)
        val STREAM_648_1152_30FPS: StreamResolution = StreamResolution(648, 1152, 30, 40, 139)
        val STREAM_360_640_30FPS: StreamResolution = StreamResolution(360, 640, 30, 40, 77)

        // 4:3
        val STREAM_4000_3000_60FPS: StreamResolution = StreamResolution(4000, 3000, 60, 40, 153)
        val STREAM_4000_3000_50FPS: StreamResolution = StreamResolution(4000, 3000, 50, 40, 152)
        val STREAM_4000_3000_30FPS: StreamResolution = StreamResolution(4000, 3000, 30, 40, 31)
        val STREAM_4000_3000_25FPS: StreamResolution = StreamResolution(4000, 3000, 25, 40, 54)
        val STREAM_4000_3000_24FPS: StreamResolution = StreamResolution(4000, 3000, 24, 40, 55)
        val STREAM_2720_2040_60FPS: StreamResolution = StreamResolution(2720, 2040, 60, 40, 215)
        val STREAM_2720_2040_50FPS: StreamResolution = StreamResolution(2720, 2040, 50, 40, 216)
        val STREAM_2720_2040_30FPS: StreamResolution = StreamResolution(2720, 2040, 30, 40, 41)
        val STREAM_2720_2040_25FPS: StreamResolution = StreamResolution(2720, 2040, 25, 40, 56)
        val STREAM_2720_2040_24FPS: StreamResolution = StreamResolution(2720, 2040, 24, 40, 57)
        val STREAM_1920_1440_60FPS: StreamResolution = StreamResolution(1920, 1440, 60, 40, 62)
        val STREAM_1920_1440_50FPS: StreamResolution = StreamResolution(1920, 1440, 50, 40, 218)
        val STREAM_1920_1440_30FPS: StreamResolution = StreamResolution(1920, 1440, 30, 40, 42)
        val STREAM_1920_1440_25FPS: StreamResolution = StreamResolution(1920, 1440, 25, 40, 58)
        val STREAM_1920_1440_24FPS: StreamResolution = StreamResolution(1920, 1440, 24, 40, 59)
        val STREAM_1280_960_30FPS: StreamResolution = StreamResolution(1280, 960, 30, 40, 44)
        val STREAM_640_480_30FPS: StreamResolution = StreamResolution(640, 480, 30, 40, 76)

        // 3:4
        val STREAM_1440_1920_60FPS: StreamResolution = StreamResolution(1440, 1920, 60, 40, 67)
        val STREAM_1440_1920_30FPS: StreamResolution = StreamResolution(1440, 1920, 30, 40, 65)
        val STREAM_960_1280_30FPS: StreamResolution = StreamResolution(960, 1280, 30, 40, 73)
        val STREAM_480_640_30FPS: StreamResolution = StreamResolution(480, 640, 30, 40, 78)

        // 1:1
        val STREAM_2880_2880_25FPS: StreamResolution = StreamResolution(2880, 2880, 25, 40, 19)
        val STREAM_2880_2880_24FPS: StreamResolution = StreamResolution(2880, 2880, 24, 40, 20)
        val STREAM_2880_2880_30FPS: StreamResolution = StreamResolution(2880, 2880, 30, 40, 10)
        val STREAM_1152_1152_30FPS: StreamResolution = StreamResolution(1152, 1152, 30, 40, 74)
        val STREAM_854_854_30FPS: StreamResolution = StreamResolution(854, 854, 30, 40, 80)
        val STREAM_640_640_30FPS: StreamResolution = StreamResolution(640, 640, 30, 40, 209)
        val STREAM_368_368_30FPS: StreamResolution = StreamResolution(368, 368, 30, 40, 79)

        // 3:2
        val STREAM_5312_3552_30FPS: StreamResolution = StreamResolution(5312, 3552, 30, 40, 103)
        val STREAM_5312_3552_25FPS: StreamResolution = StreamResolution(5312, 3552, 25, 40, 102)
        val STREAM_5312_3552_24FPS: StreamResolution = StreamResolution(5312, 3552, 24, 40, 101)
        val STREAM_3584_2400_30FPS: StreamResolution = StreamResolution(3584, 2400, 30, 40, 170)
        val STREAM_3584_2400_25FPS: StreamResolution = StreamResolution(3584, 2400, 25, 40, 169)
        val STREAM_3584_2400_24FPS: StreamResolution = StreamResolution(3584, 2400, 24, 40, 168)
        val STREAM_1152_768_30FPS: StreamResolution = StreamResolution(1152, 768, 30, 40, 45)

        // 2:3
        val STREAM_2400_3584_30FPS: StreamResolution = StreamResolution(2400, 3584, 30, 40, 175)
        val STREAM_2400_3584_25FPS: StreamResolution = StreamResolution(2400, 3584, 25, 40, 174)
        val STREAM_2400_3584_24FPS: StreamResolution = StreamResolution(2400, 3584, 24, 40, 173)

        // 2.35:1
        val STREAM_7680_3268_30FPS: StreamResolution = StreamResolution(7680, 3268, 30, 40, 213)
        val STREAM_7680_3268_25FPS: StreamResolution = StreamResolution(7680, 3268, 25, 40, 212)
        val STREAM_7680_3268_24FPS: StreamResolution = StreamResolution(7680, 3268, 24, 40, 219)
        val STREAM_6720_2856_25FPS: StreamResolution = StreamResolution(6720, 2856, 25, 40, 112)
        val STREAM_6720_2856_24FPS: StreamResolution = StreamResolution(6720, 2856, 24, 40, 113)
        val STREAM_6016_2560_25FPS: StreamResolution = StreamResolution(6016, 2560, 25, 40, 114)
        val STREAM_6016_2560_24FPS: StreamResolution = StreamResolution(6016, 2560, 24, 40, 115)
        val STREAM_5472_2328_30FPS: StreamResolution = StreamResolution(5472, 2328, 30, 40, 106)
        val STREAM_5472_2328_25FPS: StreamResolution = StreamResolution(5472, 2328, 25, 40, 105)
        val STREAM_5472_2328_24FPS: StreamResolution = StreamResolution(5472, 2328, 24, 40, 104)

        // oneX4
        val STREAM_2816_1408_30FPS: StreamResolution = StreamResolution(2816, 1408, 30, 40, -1)
        val STREAM_1472_368_30FPS: StreamResolution = StreamResolution(1472, 368, 30, 40, -1)
        val STREAM_1472_736_30FPS: StreamResolution = StreamResolution(1472, 736, 30, 40, -1)
        val STREAM_1664_832_30FPS: StreamResolution = StreamResolution(1664, 832, 30, 40, -1)
        val STREAM_1024_576_30FPS: StreamResolution = StreamResolution(1024, 576, 30, 40, -1)
        val STREAM_832_832_30FPS: StreamResolution = StreamResolution(832, 832, 30, 40, -1)

        // 所有分辨率的列表
        val allResolutions: MutableList<StreamResolution> = mutableListOf<StreamResolution>( // 4:1
            STREAM_3840_960_120FPS,
            STREAM_2944_736_180FPS,
            STREAM_2880_720_30FPS, // 2:1

            STREAM_7680_3840_30FPS,
            STREAM_7680_3840_25FPS,
            STREAM_7680_3840_24FPS,
            STREAM_6400_3200_30FPS,
            STREAM_6400_3200_25FPS,
            STREAM_6400_3200_24FPS,
            STREAM_6144_3072_30FPS,
            STREAM_6144_3072_25FPS,
            STREAM_6144_3072_24FPS,
            STREAM_6080_3040_30FPS,
            STREAM_6080_3040_25FPS,
            STREAM_6080_3040_24FPS,
            STREAM_5888_2944_30FPS,
            STREAM_5888_2944_25FPS,
            STREAM_5888_2944_24FPS,
            STREAM_5888_2880_30FPS,
            STREAM_5760_2880_30FPS,
            STREAM_5760_2880_25FPS,
            STREAM_5760_2880_24FPS,
            STREAM_3920_1920_30FPS,
            STREAM_3840_1920_60FPS,
            STREAM_3840_1920_50FPS,
            STREAM_3840_1920_30FPS,
            STREAM_3840_1920_25FPS,
            STREAM_3840_1920_24FPS,
            STREAM_3040_1520_50FPS,
            STREAM_3040_1520_30FPS,
            STREAM_3008_1504_100FPS,
            STREAM_3000_1500_120FPS,
            STREAM_2880_1440_60FPS,
            STREAM_2880_1440_50FPS,
            STREAM_2880_1440_30FPS,
            STREAM_2880_1440_25FPS,
            STREAM_2880_1440_24FPS,
            STREAM_2560_1280_30FPS,
            STREAM_2176_1088_30FPS,
            STREAM_1920_960_30FPS,
            STREAM_1440_720_30FPS,
            STREAM_720_360_30FPS,
            STREAM_480_240_30FPS, // 1:2

            STREAM_1440_2880_60FPS,
            STREAM_1440_2880_50FPS,
            STREAM_1440_2880_30FPS,
            STREAM_1440_2880_25FPS,
            STREAM_1440_2880_24FPS, // 16:9

            STREAM_7680_4320_30FPS,
            STREAM_7680_4320_25FPS,
            STREAM_7680_4320_24FPS,
            STREAM_5312_2988_30FPS,
            STREAM_5312_2988_25FPS,
            STREAM_5312_2988_24FPS,
            STREAM_3840_2160_120FPS,
            STREAM_3840_2160_100FPS,
            STREAM_3840_2160_60FPS,
            STREAM_3840_2160_50FPS,
            STREAM_3840_2160_30FPS,
            STREAM_3840_2160_25FPS,
            STREAM_3840_2160_24FPS,
            STREAM_3584_2016_60FPS,
            STREAM_3584_2016_50FPS,
            STREAM_3584_2016_30FPS,
            STREAM_3584_2016_25FPS,
            STREAM_3584_2016_24FPS,
            STREAM_2720_1530_120FPS,
            STREAM_2720_1530_100FPS,
            STREAM_2720_1530_60FPS,
            STREAM_2720_1530_50FPS,
            STREAM_2720_1530_30FPS,
            STREAM_2720_1530_25FPS,
            STREAM_2720_1530_24FPS,
            STREAM_2560_1440_60FPS,
            STREAM_2560_1440_50FPS,
            STREAM_2560_1440_30FPS,
            STREAM_2560_1440_25FPS,
            STREAM_2560_1440_24FPS,
            STREAM_2560_1440_15FPS,
            STREAM_1920_1080_240FPS,
            STREAM_1920_1080_200FPS,
            STREAM_1920_1080_120FPS,
            STREAM_1920_1080_100FPS,
            STREAM_1920_1080_60FPS,
            STREAM_1920_1080_50FPS,
            STREAM_1920_1080_30FPS,
            STREAM_1920_1080_25FPS,
            STREAM_1920_1080_24FPS,
            STREAM_1760_990_30FPS,
            STREAM_1600_900_30FPS,
            STREAM_1280_720_30FPS,
            STREAM_1152_648_30FPS,
            STREAM_640_360_30FPS,
            STREAM_424_240_15FPS, // 9:16

            STREAM_2160_3840_60,
            STREAM_2160_3840_50,
            STREAM_2160_3840_30,
            STREAM_2160_3840_25,
            STREAM_2160_3840_24,
            STREAM_2016_3584_60FPS,
            STREAM_2016_3584_50FPS,
            STREAM_2016_3584_30FPS,
            STREAM_2016_3584_25FPS,
            STREAM_2016_3584_24FPS,
            STREAM_1530_2720_60,
            STREAM_1530_2720_50,
            STREAM_1530_2720_30,
            STREAM_1530_2720_25,
            STREAM_1530_2720_24,
            STREAM_1440_2560_60FPS,
            STREAM_1440_2560_50FPS,
            STREAM_1440_2560_30FPS,
            STREAM_1440_2560_25FPS,
            STREAM_1440_2560_24FPS,
            STREAM_1440_2560_15FPS,
            STREAM_1080_1920_120FPS,
            STREAM_1080_1920_100FPS,
            STREAM_1080_1920_60FPS,
            STREAM_1080_1920_50FPS,
            STREAM_1080_1920_30FPS,
            STREAM_1080_1920_25FPS,
            STREAM_1080_1920_24FPS,
            STREAM_720_1280_30FPS,
            STREAM_648_1152_30FPS,
            STREAM_360_640_30FPS, // 4:3

            STREAM_4000_3000_60FPS,
            STREAM_4000_3000_50FPS,
            STREAM_4000_3000_30FPS,
            STREAM_4000_3000_25FPS,
            STREAM_4000_3000_24FPS,
            STREAM_2720_2040_60FPS,
            STREAM_2720_2040_50FPS,
            STREAM_2720_2040_30FPS,
            STREAM_2720_2040_25FPS,
            STREAM_2720_2040_24FPS,
            STREAM_1920_1440_60FPS,
            STREAM_1920_1440_50FPS,
            STREAM_1920_1440_30FPS,
            STREAM_1920_1440_25FPS,
            STREAM_1920_1440_24FPS,
            STREAM_1280_960_30FPS,
            STREAM_640_480_30FPS, // 3:4

            STREAM_1440_1920_60FPS,
            STREAM_1440_1920_30FPS,
            STREAM_960_1280_30FPS,
            STREAM_480_640_30FPS, // 1:1

            STREAM_2880_2880_25FPS,
            STREAM_2880_2880_24FPS,
            STREAM_2880_2880_30FPS,
            STREAM_1152_1152_30FPS,
            STREAM_854_854_30FPS,
            STREAM_640_640_30FPS,
            STREAM_368_368_30FPS, // 3:2

            STREAM_5312_3552_30FPS,
            STREAM_5312_3552_25FPS,
            STREAM_5312_3552_24FPS,
            STREAM_3584_2400_30FPS,
            STREAM_3584_2400_25FPS,
            STREAM_3584_2400_24FPS,
            STREAM_1152_768_30FPS, // 2:3

            STREAM_2400_3584_30FPS,
            STREAM_2400_3584_25FPS,
            STREAM_2400_3584_24FPS, // 2.35:1

            STREAM_7680_3268_30FPS,
            STREAM_7680_3268_25FPS,
            STREAM_7680_3268_24FPS,
            STREAM_6720_2856_25FPS,
            STREAM_6720_2856_24FPS,
            STREAM_6016_2560_25FPS,
            STREAM_6016_2560_24FPS,
            STREAM_5472_2328_30FPS,
            STREAM_5472_2328_25FPS,
            STREAM_5472_2328_24FPS, // oneX4

            STREAM_2816_1408_30FPS,
            STREAM_1472_368_30FPS,
            STREAM_1472_736_30FPS,
            STREAM_1664_832_30FPS,
            STREAM_1024_576_30FPS,
            STREAM_832_832_30FPS
        )

        // 根据相机中的值获取对应的分辨率
        fun getFromCameraValue(valueInCamera: Int): StreamResolution? {
            for (resolution in allResolutions) {
                if (resolution.valueInCamera == valueInCamera) {
                    return resolution
                }
            }
            return null
        }

        // 根据分辨率获取对应的分辨率对象
        fun getFromResolution(width: Int, height: Int, fps: Int): StreamResolution {
            for (resolution in allResolutions) {
                if (resolution.width == width && resolution.height == height && resolution.fps == fps) {
                    return resolution
                }
            }
            return StreamResolution(width, height, fps, 40, -1)
        }
    }

}
