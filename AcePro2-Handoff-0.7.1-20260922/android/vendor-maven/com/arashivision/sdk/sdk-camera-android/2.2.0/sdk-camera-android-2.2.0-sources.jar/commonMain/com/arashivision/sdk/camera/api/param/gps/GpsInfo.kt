package com.arashivision.sdk.camera.api.param.gps

/**
 * 单帧 GPS 信息数据模型（KMP 公共数据模型）。
 *
 * 封装了某一时刻的地理位置信息，用于写入媒体文件。
 *
 * @property latitude 纬度（度）。
 * @property longitude 经度（度）。
 * @property altitude 海拔高度（米）。
 * @property timestampMs 记录此 GPS 数据时的时间戳（毫秒）。
 */
data class GpsInfo(
    val latitude: Double,
    val longitude: Double,
    val altitude: Double,
    val timestampMs: Long
) {
    /**
     * 将 GPS 信息序列化为字节数组（KMP 通用）。
     *
     * 二进制格式（小端序 Little Endian）：
     * [timestampMs: Long] (8 bytes)
     * [latitude: Double] (8 bytes)
     * [longitude: Double] (8 bytes)
     * [altitude: Double] (8 bytes)
     *
     * @return 序列化后的字节数组。
     */
    fun toByteArray(): ByteArray {
        val writer = ByteWriter()
        writer.writeLong(timestampMs)
        writer.writeDouble(latitude)
        writer.writeDouble(longitude)
        writer.writeDouble(altitude)
        return writer.toByteArray()
    }
}

/**
 * KMP 安全的字节写入器（小端序 Little Endian）。
 *
 * 用于在跨平台环境中替代 Java 的 ByteBuffer / ByteOrder，实现基础数据类型到字节数组的转换。
 */
internal class ByteWriter {

    private val buffer = ArrayList<Byte>()

    /** 写入 4 字节整数 */
    fun writeInt(value: Int) {
        buffer.add((value and 0xFF).toByte())
        buffer.add(((value shr 8) and 0xFF).toByte())
        buffer.add(((value shr 16) and 0xFF).toByte())
        buffer.add(((value shr 24) and 0xFF).toByte())
    }

    /** 写入 8 字节长整数 */
    fun writeLong(value: Long) {
        for (i in 0 until 8) {
            buffer.add(((value shr (i * 8)) and 0xFF).toByte())
        }
    }

    /** 写入 8 字节双精度浮点数 */
    fun writeDouble(value: Double) {
        writeLong(value.toBits())
    }

    /** 获取最终的字节数组 */
    fun toByteArray(): ByteArray = buffer.toByteArray()
}

/**
 * GPS 数据封装类。
 *
 * 负责将 [GpsInfo] 对象或列表序列化为二进制数据，以便底层传输或写入文件。
 */
class GpsData private constructor(
    private val info: GpsInfo
) {

    /**
     * 将内部的 GPS 信息序列化为字节数组（KMP 通用，小端序）。
     *
     * @return 序列化后的字节数组。
     */
    fun toByteArray(): ByteArray {
        val writer = ByteWriter()

        writer.writeLong(info.timestampMs)
        writer.writeDouble(info.latitude)
        writer.writeDouble(info.longitude)
        writer.writeDouble(info.altitude)

        return writer.toByteArray()
    }

    companion object {

        /**
         * 工厂方法，从 [GpsInfo] 创建 [GpsData] 实例。
         *
         * @param info 原始 GPS 信息。
         * @return 封装后的 [GpsData] 对象。
         */
        fun from(info: GpsInfo): GpsData {
            return GpsData(info)
        }

        /**
         * 批量序列化多个 GPS 信息对象。
         *
         * @param list 包含多个 [GpsInfo] 的列表。
         * @return 包含所有 GPS 信息的连续字节数组。
         */
        fun toByteArrayList(list: List<GpsInfo>): ByteArray {
            val writer = ByteWriter()
            list.forEach {
                writer.writeLong(it.timestampMs)
                writer.writeDouble(it.latitude)
                writer.writeDouble(it.longitude)
                writer.writeDouble(it.altitude)
            }
            return writer.toByteArray()
        }
    }
}