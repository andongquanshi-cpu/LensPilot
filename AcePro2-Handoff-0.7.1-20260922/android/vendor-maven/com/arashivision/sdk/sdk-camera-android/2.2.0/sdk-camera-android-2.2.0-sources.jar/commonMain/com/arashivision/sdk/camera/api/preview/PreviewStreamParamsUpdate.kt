package com.arashivision.sdk.camera.api.preview

import com.arashivision.sdk.bridge.shared.preview.CameraPreviewOffsetData
import insta360.messages.WindowCropInfo

/**
 * 预览流参数更新数据类。
 *
 * 当预览流的关键参数（如分辨率、帧率、裁剪信息、偏移量）发生变化时，
 * 通过 [CameraStreamListener.onParamsChanged] 回调此对象。
 *
 * @property windowCropInfo 相机窗口裁剪信息，用于全景拼接。
 * @property offsetData 相机预览偏移数据，包含镜头校正参数。
 * @property stabOffset 防抖偏移量字符串。
 * @property previewWidth 当前预览流的宽度（像素）。
 * @property previewHeight 当前预览流的高度（像素）。
 * @property previewFps 当前预览流的帧率。
 */
data class PreviewStreamParamsUpdate(
    val windowCropInfo: WindowCropInfo?,
    val offsetData: CameraPreviewOffsetData?,
    val stabOffset: String?,
    val previewWidth: Int,
    val previewHeight: Int,
    val previewFps: Int,
)
