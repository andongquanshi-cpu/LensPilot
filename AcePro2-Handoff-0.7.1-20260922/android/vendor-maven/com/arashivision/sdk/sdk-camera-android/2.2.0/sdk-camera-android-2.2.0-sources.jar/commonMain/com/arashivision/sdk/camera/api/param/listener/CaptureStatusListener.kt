package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus

/**
 * 相机拍摄状态监听器。
 *
 * 用于监听相机在拍照、录像等过程中的各个生命周期事件及状态变化。
 */
interface CaptureStatusListener {
    /**
     * 拍摄即将开始时回调。
     *
     * @param functionMode 当前的拍摄模式。
     */
    fun onCaptureStarting(functionMode: FunctionMode)

    /**
     * 拍摄正式开始并处于工作状态时回调。
     *
     * @param functionMode 当前的拍摄模式。
     */
    fun onCaptureWorking(functionMode: FunctionMode)

    /**
     * 拍摄即将停止时回调。
     *
     * @param functionMode 当前的拍摄模式。
     */
    fun onCaptureStopping(functionMode: FunctionMode)

    /**
     * 拍摄完成并成功生成文件时回调。
     *
     * @param functionMode 当前的拍摄模式。
     * @param filePaths 生成的媒体文件在相机端的路径或 URI 列表。
     */
    fun onCaptureFinish(functionMode: FunctionMode, filePaths: List<String>)

    /**
     * 拍摄过程中发生错误时回调。
     *
     * @param functionMode 当前的拍摄模式。
     * @param throwable 描述错误原因的异常对象。
     */
    fun onCaptureError(functionMode: FunctionMode, throwable: Throwable)

    /**
     * 录制时长发生变化时回调（仅在录像等持续性拍摄模式下有效）。
     *
     * @param functionMode 当前的拍摄模式。
     * @param captureTime 当前已录制的时长（通常以毫秒或秒为单位，具体视底层实现而定）。
     */
    fun onCaptureTimeChanged(functionMode: FunctionMode, captureTime: Long)

    /**
     * 拍摄张数发生变化时回调（通常用于连拍、间隔拍摄等模式）。
     *
     * @param functionMode 当前的拍摄模式。
     * @param captureCount 当前已拍摄的张数。
     */
    fun onCaptureCountChanged(functionMode: FunctionMode, captureCount: Int)

    /**
     * 拍摄子状态发生变化时回调（如全景拼接进度、HDR 处理等内部状态）。
     *
     * @param functionMode 当前的拍摄模式。
     * @param subStatus 当前的拍摄子状态。
     */
    fun onCaptureSubStatusChanged(functionMode: FunctionMode, subStatus: CameraCaptureStatus.SubStatus)
}
