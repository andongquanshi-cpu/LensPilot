package com.arashivision.sdk.camera.core.model.photography

/**
 * 连拍参数枚举（张数 / 时间）。
 *
 * - JSON 中的格式形如 "3/1"，表示 3 张 / 1 秒。
 * - 对外只暴露固定枚举项，避免第三方随意组合导致相机异常。
 * - 设备/模式不支持的组合，SDK 会通过 supported 列表拦截。
 */
enum class BurstCaptureParams(
    val captureNum: Int,
    val captureTime: Int,
) {
    // 覆盖 go_ultra.json / x5.json / cameraSupport.json 等内置支持组合的并集
    CAPTURE_3_IN_1S(3, 1),
    CAPTURE_5_IN_1S(5, 1),
    CAPTURE_10_IN_1S(10, 1),
    CAPTURE_15_IN_1S(15, 1),
    CAPTURE_30_IN_1S(30, 1),
    CAPTURE_10_IN_3S(10, 3),
    CAPTURE_15_IN_3S(15, 3),
    CAPTURE_30_IN_3S(30, 3),
    CAPTURE_15_IN_6S(15, 6),
    CAPTURE_30_IN_6S(30, 6),
    CAPTURE_15_IN_10S(15, 10),
    CAPTURE_30_IN_10S(30, 10),

    /**
     * 兜底：当设备返回了 SDK 未覆盖的组合时使用。
     * 不建议业务侧主动设置该值；写入时会被拦截。
     */
    UNKNOWN(-1, -1),
    ;

    override fun toString(): String = "${captureNum}/${captureTime}"

    companion object {
        fun from(captureNum: Int, captureTime: Int): BurstCaptureParams =
            entries.firstOrNull { it.captureNum == captureNum && it.captureTime == captureTime } ?: UNKNOWN

        fun fromIntToString(captureNum: Int, captureTime: Int): String {
            return "${captureNum}/${captureTime}"
        }


        fun parse(raw: String): BurstCaptureParams? {
            val parts = raw.trim().split('/').mapNotNull { it.trim().toIntOrNull() }
            if (parts.size != 2) return null
            val (num, time) = parts
            if (num <= 0 || time <= 0) return null
            return from(num, time).takeIf { it != UNKNOWN }
        }

        fun parseToPair(raw: String): Pair<Int, Int>? {
            val parts = raw.trim().split('/').mapNotNull { it.trim().toIntOrNull() }
            if (parts.size != 2) return null
            val (num, time) = parts
            if (num <= 0 || time <= 0) return null
            return  Pair<Int, Int>(num, time)
        }

    }
}

