package com.arashivision.sdk.camera.core.model.file

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class MediaFileType(override val nativeValue: Int) : BaseEnum {
    VIDEO(0),
    PHOTO(1),
    VIDEO_AND_PHOTO(2),
    DNG(3),
    MP4(4),
    JPG(5),
    INS_DATA(6),
    IDLE_ANALYSIS(7),
    PROFILE_DATA(8);

    companion object {
        fun nativeOf(value: Int?): MediaFileType {
            return MediaFileType.entries.find { it.nativeValue == value } ?: VIDEO_AND_PHOTO
        }
    }
}