package com.arashivision.sdk.camera.core

import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.sdk.camera.api.param.listener.BleWakeUpListener
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.callback.BleScanCallback
import com.arashivision.sdk.camera.core.delegate.capture.CaptureDelegate
import com.arashivision.sdk.camera.core.delegate.capture.CaptureDelegateImpl
import com.arashivision.sdk.camera.core.delegate.multivideooption.MultiVideoOptionDelegate
import com.arashivision.sdk.camera.core.delegate.multivideooption.MultiVideoOptionDelegateImpl
import com.arashivision.sdk.camera.core.delegate.option.OptionDelegate
import com.arashivision.sdk.camera.core.delegate.option.OptionDelegateImpl
import com.arashivision.sdk.camera.core.delegate.photography.PhotographyOptionDelegate
import com.arashivision.sdk.camera.core.delegate.photography.PhotographyOptionDelegateImpl
import com.arashivision.sdk.camera.core.delegate.stream.PreviewStreamDelegate
import com.arashivision.sdk.camera.core.delegate.stream.PreviewStreamDelegateImpl
import com.arashivision.sdk.camera.core.delegate.timelapse.TimelapseOptionDelegate
import com.arashivision.sdk.camera.core.delegate.timelapse.TimelapseOptionDelegateImpl
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.WiFiAwareConnectHint
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationOperationType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationStatus
import com.arashivision.sdk.camera.core.model.capture.LockScreenState
import com.arashivision.sdk.camera.core.model.file.CameraFileType
import com.arashivision.sdk.camera.core.model.file.FileInfo
import com.arashivision.sdk.camera.core.model.file.MediaFileType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.camera.platform.createBleDeviceCore
import com.arashivision.sdk.camera.service.preview.PreviewStatus
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.callback.callback
import com.arashivision.sdk.common.exception.BleScanningException
import com.arashivision.sdk.common.exception.CameraConnectingException
import com.arashivision.sdk.common.exception.CameraNotConnectedException
import com.arashivision.sdk.common.exception.CameraNotSupportException
import com.arashivision.sdk.common.exception.CameraOptionFetchException
import com.arashivision.sdk.common.exception.CameraTypeGetFailedException
import com.arashivision.sdk.common.exception.CameraTypeNotSupportException
import com.arashivision.sdk.common.exception.InvalidParameterException
import com.arashivision.sdk.common.kotlin.DynamicHostResolver
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.getCustomizedDeviceID
import com.arashivision.sdk.common.kotlin.nowMs
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.common.system.PlatformType
import com.arashivision.sdk.common.system.getAppName
import com.arashivision.sdk.common.system.getBundleName
import com.arashivision.sdk.common.system.getCurrentWiFiName
import com.arashivision.sdk.common.system.platformType
import com.arashivision.sdk.common.type.KMPBleDevice
import insta360.messages.FileType
import insta360.messages.MediaType
import insta360.messages.OptionType
import insta360.messages.StartLiveStream
import insta360.messages.VideoResolution
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

class DeviceCoreImpl private constructor(
    override val connectType: ConnectType,
    private val context: DeviceContext,
    private val optionDelegate: OptionDelegateImpl,
    private val photographyOptionDelegate: PhotographyOptionDelegateImpl,
    private val timelapseOptionDelegate: TimelapseOptionDelegateImpl,
    private val multiVideoOptionDelegate: MultiVideoOptionDelegateImpl,
    private val captureDelegate: CaptureDelegateImpl,
    private val streamDelegate: PreviewStreamDelegate
) : DeviceCore, OptionDelegate by optionDelegate, PhotographyOptionDelegate by photographyOptionDelegate, TimelapseOptionDelegate by timelapseOptionDelegate,
    CaptureDelegate by captureDelegate, PreviewStreamDelegate by streamDelegate, MultiVideoOptionDelegate by multiVideoOptionDelegate {

    // 主构造函数供外部调用
    constructor(connectType: ConnectType, scope: CoroutineScope) : this(connectType, DeviceContext(connectType, scope))

    private constructor(connectType: ConnectType, ctx: DeviceContext) : this(
        connectType,
        ctx,
        OptionDelegateImpl(ctx),
        PhotographyOptionDelegateImpl(ctx),
        TimelapseOptionDelegateImpl(ctx),
        MultiVideoOptionDelegateImpl(ctx),
        CaptureDelegateImpl(ctx),
        PreviewStreamDelegateImpl(ctx)
    ) {
        ctx.attachCore(this)
    }

    companion object {
        private const val TAG = "DeviceCoreImpl"
        const val CHECK_BATTERY_INTERVAL_TIME = 3_0000L

        // WIFI_AWARE 连接下 SDK 内部下载/上传使用的占位 hostname，由 DynamicHostResolver 动态解析为真实 peer 地址。
        // 固定字符串 key，假设同一进程同一时刻最多一台 WIFI_AWARE 相机在线；若未来需要支持多台同时连接，
        // 这里必须按实例区分 key（如拼接设备唯一标识），否则会互相覆盖解析结果、导致请求串扰
        private const val AWARE_ENDPOINT_HOST = "aware.insta360.camera"

        // 跨实例共享：BLE 与 WIFI 连接对应各自独立的 DeviceCoreImpl 实例，Wi-Fi 名称获取失败时
        // 需要用最近一次 BLE 连接的设备名兜底判断 cameraType，因此不能存成实例字段。
        // 假设同一进程同一时刻最多一台相机在做 BLE→WIFI 的连接切换。
        private var lastConnectedBleDeviceName = ""
    }

    override val events: SharedFlow<DeviceEvent> = context.events.asSharedFlow()
    private var _isConnected: Boolean = false

    private val bleDeviceList: MutableList<BleDeviceCore> = mutableListOf()

    override val isConnected: Boolean
        get() = _isConnected

    private var bleScanCallback: BleScanCallback? = null
    private var connectCallback: Callback<Unit>? = null

    private val callbackMutex = Mutex()
    private var callbackMap: MutableMap<Long, Callback<*>> = mutableMapOf()

    private var batteryCheckJob: Job? = null
    private var lastBatteryUpdateTime = 0L

    @Suppress("UNCHECKED_CAST")
    override fun init() {
        context.transport.init()
        optionDelegate.init()
        photographyOptionDelegate.init()
        timelapseOptionDelegate.init()
        multiVideoOptionDelegate.init()
        captureDelegate.init()
        context.scope.launch {
            context.transport.events.collect {
                Logger.i(TAG, "start handle $it")
                context.scope.launch {
                    when (it) {
                        is TransportEvent.ConnectionEvent.Connected -> {
                            fetchOptions(listOf(OptionType.CAMERA_TYPE))
                            getCameraType().onSuccess { cameraType ->
                                if (cameraType in ICameraConfig.supportCameraType()) {
                                    context.cameraConfig = ICameraConfig.createCameraConfig(cameraType, connectType)
                                    captureDelegate.syncCaptureStatus()
                                    context.transport.setAppid(createAppId())
                                    _isConnected = true
                                    if (context.cameraConfig?.supportLowPowerMode() == true) {
                                        if (connectType == ConnectType.WIFI || connectType == ConnectType.WIFI_AWARE) {
                                            context.scope.launch {
                                                setAccessCameraFileState(LockScreenState.LOCK.nativeValue).onFailure { ex ->
                                                    Logger.w(
                                                        TAG,
                                                        "auto exit low power mode failed: ${ex.message}"
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    // callback回调
                                    connectCallback?.onSuccess(Unit).also { connectCallback = null }
                                    startBatteryCheckTask()
                                } else {
                                    disconnect()
                                    _isConnected = false
                                    connectCallback?.onThrowable(CameraTypeNotSupportException(cameraType.type)).also { connectCallback = null }
                                }
                            }.onFailure {
                                unregisterAwareDnsIfNeeded()
                                _isConnected = false
                                connectCallback?.onThrowable(CameraTypeGetFailedException()).also { connectCallback = null }
                            }
                        }

                        is TransportEvent.ConnectionEvent.Disconnected -> {
                            unregisterAwareDnsIfNeeded()
                            context.cameraConfig = null
                            if (_isConnected) {
                                context.events.emit(DeviceEvent.DisconnectedEvent(it.connectType, it.throwable))
                            } else {
                                connectCallback?.onThrowable(CameraOptionFetchException(it.throwable?.message ?: "")).also { connectCallback = null }
                            }
                            _isConnected = false
                            batteryCheckJob?.cancel()
                            batteryCheckJob = null
                        }

                        is TransportEvent.ConnectionEvent.Failed -> {
                            unregisterAwareDnsIfNeeded()
                            _isConnected = false
                            connectCallback?.onThrowable(it.throwable).also { connectCallback = null }
                        }

                        // scan
                        is TransportEvent.ScanEvent.Started -> bleScanCallback?.onStarted()
                        is TransportEvent.ScanEvent.Scanning -> {
                            //过滤掉不支持的设备以及重复设备
                            it.bleDevice.name?.let { deviceName ->
                                ICameraConfig.supportCameraType().find { cameraType -> deviceName.contains(cameraType.simpleName) }
                            }?.run {
//                                if (bleDeviceList.find { find -> find.name == it.bleDevice.name } == null) {
                                    bleDeviceList.add(it.bleDevice)
                                    bleScanCallback?.onScanning(it.bleDevice)
//                                }
                            }
                        }

                        is TransportEvent.ScanEvent.Finished -> {
                            bleScanCallback?.onFinished(bleDeviceList).also { bleScanCallback = null }
                        }

                        is TransportEvent.ScanEvent.Failed -> {
                            bleScanCallback?.onError(it.throwable).also { bleScanCallback = null }
                        }

                        //switch wifi channel
                        is TransportEvent.SwitchWifiChannelEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.SwitchWifiChannelEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.BatteryLowEvent -> {
                            optionDelegate.fetchOptions(listOf(OptionType.BATTERY_INFO))
                            context.events.emit(DeviceEvent.BatteryLowEvent)
                            // 更新电池信息
                            onBatteryUpdate()
                        }

                        is TransportEvent.BatteryUpdateEvent -> {
                            // 更新电池信息
                            onBatteryUpdate()
                        }

                        is TransportEvent.ChargeBoxConnectStatusUpdateEvent -> {
                            // 更新电池信息
                            onBatteryUpdate()
                        }

                        is TransportEvent.ChargeBoxBatteryUpdateEvent -> {
                            // 更新电池信息
                            onBatteryUpdate()
                        }

                        TransportEvent.StorageEvent.Full, TransportEvent.StorageEvent.Update -> {
                            optionDelegate.fetchStorageDataList().onSuccess { storageDataList ->
                                context.events.tryEmit(DeviceEvent.StorageUpdateEvent(storageDataList))
                            }
                        }

                        is TransportEvent.CameraCaptureStatusNotifyEvent -> {
                            // X6等支持内部存储的相机，录像完成之后收不到OneDriverInfo.Response.InfoType.STORAGE_UPDATE通知，所以需要在拍摄完成时，主动更新存储状态
                            if (context.cameraConfig?.supportInnerStorage() == true) {
                                optionDelegate.fetchStorageDataList().onSuccess { storageDataList ->
                                    context.events.tryEmit(DeviceEvent.StorageUpdateEvent(storageDataList))
                                }
                            }
                        }

                        is TransportEvent.TemperatureEvent -> context.events.emit(DeviceEvent.TemperatureEvent(it.tempState))

                        is TransportEvent.GetSensorModeEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<SensorMode> }?.onSuccess(SensorMode.nativeOf(it.sensorDevice.value))
                        }

                        is TransportEvent.GetSensorModeEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.SetSensorModeEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.SetSensorModeEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.GetMediaFileListEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Pair<List<String>, Int>> }?.onSuccess(Pair(it.uri, it.count))
                        }

                        is TransportEvent.GetMediaFileListEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }


                        is TransportEvent.DeleteMediaFileListEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.DeleteMediaFileListEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.GetCameraFileListEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Pair<String, Int>> }?.onSuccess(Pair(it.filePath, it.version))
                        }

                        is TransportEvent.GetCameraFileListEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.ResetCameraWiFiEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.ResetCameraWiFiEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.OpenCameraWiFiEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.OpenCameraWiFiEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.CloseCameraWiFiEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.CloseCameraWiFiEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.SetWifiModeEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.SetWifiModeEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.PackCameraLogFileEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<String> }?.onSuccess(it.filePath)
                        }

                        is TransportEvent.PackCameraLogFileEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.CalibrateGyroEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.CalibrateGyroEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.LiveViewBeginRotateEvent -> context.events.emit(DeviceEvent.LiveViewBeginRotateEvent(it.cameraPostureUpdate))

                        //set lock screen
                        is TransportEvent.SetLockScreenStateEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.SetLockScreenStateEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.EraseSdCardEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.EraseSdCardEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.FormatStorageEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.FormatStorageEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.SetMainStorageEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.SetMainStorageEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.LiveStreamEvent.Success -> {
                            context.events.emit(DeviceEvent.LiveStreamEvent(PreviewStatus.OPENED))
                        }

                        is TransportEvent.LiveStreamEvent.Failed -> {
                            context.events.emit(DeviceEvent.LiveStreamEvent(PreviewStatus.IDLE))
                        }

                        is TransportEvent.LiveStreamEvent.Stopped -> {
                            context.events.emit(DeviceEvent.LiveStreamEvent(PreviewStatus.IDLE))
                        }

                        is TransportEvent.LiveStreamEvent.ParamsUpdate -> {
                            it.windowCropInfo?.let { windowCropInfo ->
                                optionDelegate.updateOptionCache(OptionType.WINDOW_CROP_INFO, windowCropInfo)
                            }
                            optionDelegate.updateHalfWindowCropInfo(it.halfWindowCropInfo)
                            context.events.emit(DeviceEvent.LiveStreamEvent(PreviewStatus.PARAMS_CHANGED, it.windowCropInfo))
                        }

                        is TransportEvent.GetFileInfoEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<List<FileInfo>> }?.onSuccess(it.fileInfoList)
                        }

                        is TransportEvent.GetFileInfoEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.CheckAuthorizationEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<AuthorizationStatus> }?.onSuccess(it.status)
                        }

                        is TransportEvent.CheckAuthorizationEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.AuthorizationCommandEvent.Success -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) as? Callback<Unit> }?.onSuccess(Unit)
                        }

                        is TransportEvent.AuthorizationCommandEvent.Failed -> {
                            callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                        }

                        is TransportEvent.NotifyAuthorizationEvent -> {
                            Logger.i(TAG, "notify authorization: operationType=${it.operationType}  result=${it.result}")
                            context.events.emit(DeviceEvent.AuthorizationResultEvent(it.operationType, it.result))
                        }

                        else -> {}
                    }
                }
                Logger.i(TAG, "end handle $it")
            }
        }
    }

    override fun getCameraConfig(): Result<ICameraConfig> {
        return context.cameraConfig?.let {
            Result.success(it)
        } ?: CameraNotConnectedException().failure()
    }

    private fun createAppId(): String {
        val appName = getAppName().take(10)
        val bundleName = getBundleName().take(10)
        val platformNameAbbr = when (platformType) {
            PlatformType.ANDROID -> "And"
            PlatformType.IOS -> "iOS"
        }
        val appId = "${platformNameAbbr}_" + appName + "_" + bundleName
        Logger.d(TAG, "create app id \"$appId\"")
        return appId
    }

    override suspend fun initAllOptions() {
        fetchAllOptions()
        fetchAllPhotographyOptions(functionMode)
        if (functionMode.timelapseMode() != -1) fetchTimelapseOption(functionMode.timelapseMode())
        fetchSensorMode().onSuccess {
            if (it == SensorMode.FRONT || it == SensorMode.REAR) fetchAllMultiVideoOptions(functionMode)
        }
    }

    private fun startBatteryCheckTask() {
        batteryCheckJob = context.scope.launch {
            while (isActive) {

                delay(CHECK_BATTERY_INTERVAL_TIME)
                val nowTime = nowMs()
                if (nowTime - lastBatteryUpdateTime > CHECK_BATTERY_INTERVAL_TIME) {
                    onBatteryUpdate(nowTime)
                }
            }
        }
    }

    private suspend fun onBatteryUpdate(nowTime: Long = nowMs()) {
        lastBatteryUpdateTime = nowTime
        optionDelegate.fetchOptions(listOf(OptionType.BATTERY_INFO, OptionType.CHARGEBOX_CONNECTED_STATUS))
        optionDelegate.getBatteryData().onSuccess { context.events.tryEmit(DeviceEvent.BatteryUpdateEvent(it)) }
        optionDelegate.getChargeBoxData().onSuccess { context.events.tryEmit(DeviceEvent.ChargeBoxUpdateEvent(it)) }
    }

    override fun scan(timeoutMs: Long, bleScanCallback: BleScanCallback) {
        if (this.bleScanCallback != null) {
            bleScanCallback.onError(BleScanningException("Ble is currently scanning"))
            return
        }
        bleDeviceList.clear()
        this.bleScanCallback = bleScanCallback
        context.transport.scan(timeoutMs)
    }

    override fun stopScan() {
        context.transport.stopScan()
    }

    override fun bleWakeUp(cameraType: CameraType, deviceName: String, listener: BleWakeUpListener?) {
        val deviceMode = BleManagerCore.DEVICE_AKIKO
        val support = ICameraConfig.createCameraConfig(cameraType, ConnectType.BLE)?.supportBleBroadcastWakeUp() ?: false
        if (!support) {
            Logger.e(TAG, "The camera does not support ble wake up")
            listener?.onWakeUpError(-99)
            return
        }
        context.transport.bleWakeUp(deviceMode, deviceName, -28, listener)
    }

    override suspend fun connect(connectHint: Any?): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            Logger.i(TAG, "start connect function, connectHint=$connectHint")
            if (connectCallback != null) {
                continuation.resume(CameraConnectingException("The camera is currently connecting").failure())
                return@suspendCancellableCoroutine
            }
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            connectCallback = call
            when (connectType) {
                ConnectType.BLE -> {
                    when (connectHint) {
                        is BleDeviceCore -> connectHint
                        is KMPBleDevice -> createBleDeviceCore(connectHint)
                        else -> null
                    }?.let {
                        val cameraType = CameraType.getForSimpleName(it.name)
                        Logger.i(TAG, "cameraType=${cameraType}")
                        val enableHeartBeat = cameraType in listOf(CameraType.GO_3, CameraType.GO_3S)
                        context.transport.connectBle(
                            it,
                            resolveWakeUpAuthorizationUUID(it.name) ?: "",
                            enableHeartBeat,
                            ICameraConfig.isUseUcd2(cameraType)
                        )
                        lastConnectedBleDeviceName = it.name ?: ""
                    } ?: run {
                        connectCallback = null
                        continuation.resume(InvalidParameterException("connect ble need BleDeviceCore object").failure())
                    }
                }

                ConnectType.WIFI -> {
                    (connectHint as? Long)?.let {
                        val wifiName = getCurrentWiFiName()
                        Logger.i(TAG, "wifiName=${wifiName}")
                        var cameraType = CameraType.getForSimpleName(wifiName)
                        if (cameraType == CameraType.UNKNOWN) {
                            Logger.i(TAG, "lastConnectedBleDeviceName=${lastConnectedBleDeviceName}")
                            cameraType = CameraType.getForSimpleName(lastConnectedBleDeviceName)
                        }
                        Logger.i(TAG, "cameraType=${cameraType}")
                        context.transport.connectWiFi(it, ICameraConfig.isUseUcd2(cameraType))
                    } ?: run {
                        connectCallback = null
                        continuation.resume(InvalidParameterException("connect wifi need Long object").failure())
                    }
                }

                ConnectType.USB -> context.transport.connectUsb()

                ConnectType.WIFI_AWARE -> {
                    if (platformType == PlatformType.IOS) {
                        connectCallback = null
                        continuation.resume(CameraNotSupportException("WiFi Aware is not supported on iOS").failure())
                        return@suspendCancellableCoroutine
                    }
                    (connectHint as? WiFiAwareConnectHint)?.let {
                        context.awarePeerIpv6 = it.peerIpv6
                        // 注册占位 hostname 的动态解析，读取的是 context.awarePeerIpv6 的实时值，非本次快照
                        DynamicHostResolver.register(AWARE_ENDPOINT_HOST) { context.awarePeerIpv6 }
                        context.transport.connectWiFiAware(it.networkHandle, it.peerIpv6)
                    } ?: run {
                        connectCallback = null
                        continuation.resume(InvalidParameterException("connect wifi aware need WiFiAwareConnectHint object").failure())
                    }
                }
            }
        }
    }

    override suspend fun connectBle(bleDeviceCore: BleDeviceCore): Result<Unit> = connect(bleDeviceCore)

    override suspend fun connectBle(kmpBleDevice: KMPBleDevice): Result<Unit> = connect(kmpBleDevice)

    override suspend fun connectUsb(): Result<Unit> = connect()

    override suspend fun connectWiFi(networkId: Int): Result<Unit> = connect(networkId)

    override suspend fun connectWiFiAware(networkHandle: Long, peerIpv6: String): Result<Unit> =
        connect(WiFiAwareConnectHint(networkHandle, peerIpv6))

    override fun disconnect() {
        unregisterAwareDnsIfNeeded()
        context.transport.disconnect()
    }

    // WIFI_AWARE 连接结束的路径不止 disconnect() 一处（还包括原生层上报的断连/失败事件、
    // 连接建立后 getCameraType 失败等），必须在所有"转为非连接态"的分支都调用，
    // 否则占位 hostname 会残留一个指向已失效地址的闭包
    private fun unregisterAwareDnsIfNeeded() {
        if (connectType == ConnectType.WIFI_AWARE) {
            DynamicHostResolver.unregister(AWARE_ENDPOINT_HOST)
        }
    }

    override suspend fun switchWiFiChannel(needScan: Boolean, channel: Int): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.switchWiFiChannel(needScan, channel)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun resetCameraWiFi(channel: Int): Result<Unit> {
        return getFirmwareRevision().flatMap {
            if (context.cameraConfig?.supportResetCameraWifi(it) == true) {
                resetWiFi(channel)
            } else {
                closeCameraWiFi()
                openCameraWiFi(channel)
            }
        }
    }

    private suspend fun resetWiFi(channel: Int): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.resetCameraWiFi(channel)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun openCameraWiFi(channel: Int): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.openCameraWifi(channel)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun closeCameraWiFi(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.closeCameraWifi()
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun setWifiMode(mode: WiFiData.Mode, countryCode: String): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.setWifiMode(mode.nativeValue, countryCode)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun setSensorMode(sensorMode: SensorMode): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.setSensorMode(sensorMode.nativeValue)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun fetchSensorMode(): Result<SensorMode> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            if (context.cameraConfig?.supportFetchCameraSensorMode() == true) {
                context.scope.launch {
                    val id = context.transport.getSensorMode()
                    callbackMutex.withLock {
                        callbackMap[id] = call
                    }
                }
            } else {
                continuation.resume(CameraNotSupportException("This type of camera does not support fetch sensor mode").failure())
            }
        }
    }

    override suspend fun listMediaFiles(mediaFileType: MediaFileType, start: Int, limit: Int, includeRecording: Boolean): Result<Pair<List<String>, Int>> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = if (!includeRecording) context.transport.getMediaFileList(MediaType.fromValue(mediaFileType.nativeValue) ?: MediaType.VIDEO_AND_PHOTO, start, limit)
                else context.transport.getMediaFileListIncludeRecording(MediaType.fromValue(mediaFileType.nativeValue) ?: MediaType.VIDEO_AND_PHOTO, start, limit)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun deleteMediaFiles(uris: List<String>): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.deleteMediaFileList(uris)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun getCameraFile(cameraFileType: CameraFileType): Result<Pair<String, Int>> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.getCameraFile(FileType.fromValue(cameraFileType.nativeValue) ?: FileType.UNKNOWN_FILE)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun packLogFile(): Result<String> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.packLogFile()
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override fun getEndpoint(): String {
        return "${getHost()}:${getProt()}"
    }

    override fun getDownloadEndpoint(): String {
        return when (connectType) {
            ConnectType.WIFI_AWARE -> "http://$AWARE_ENDPOINT_HOST:${getProt()}"
            else -> getEndpoint()
        }
    }

    override fun getHost(): String {
        return when (connectType) {
            ConnectType.BLE, ConnectType.WIFI -> "http://192.168.42.1"
            ConnectType.USB -> "http://127.0.0.1"
            ConnectType.WIFI_AWARE -> {
                val ipv6 = context.awarePeerIpv6 ?: ""
                "http://[${ipv6.replace("%", "%25")}]"
            }
        }
    }

    override fun getProt(): Int {
        if (connectType != ConnectType.USB) return 80
        return context.transport.getPort()
    }

    override fun getSupportCameraType(): List<CameraType> {
        return ICameraConfig.supportCameraType()
    }

    override fun setGpsData(gpsData: ByteArray) {
        context.transport.setGpsData(gpsData)
    }

    override suspend fun calibrateGyro(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.calibrateGyro()
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override fun shutdown() {
        if (context.cameraConfig?.supportShutdown() == true) {
            context.transport.shutdown()
            Unit.success()
        }
    }

    override suspend fun formatSdCard(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.formatSdCard()
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun formatStorage(fileLocation: StorageData.FileLocation): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.formatStorage(fileLocation.nativeValue)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun setMainStorage(fileLocation: StorageData.FileLocation): Result<Unit> {
        if (context.cameraConfig?.supportInnerStorage() == false) {
            return CameraNotSupportException("the setMainStorage function is only supported by X6 or cameras after X6").failure()
        }
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.setMainStorage(fileLocation.nativeValue)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun setAccessCameraFileState(accessState: Int): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.setAccessCameraFileState(accessState)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override fun openMinimalPreviewStream() {
        context.transport.previewStream(buildMinimalStartLiveStream(), "")
    }

    override fun closeMinimalPreviewStream() {
        context.transport.closeStream()
    }

    private fun buildMinimalStartLiveStream(): StartLiveStream {
        val param = StartLiveStream()
        param.enableGyro = false
        param.enableAudio = false
        param.enableVideo = true
        param.resolution = VideoResolution.RES_1280_960P30
        param.previewStreamNum = 0
        param.isForLive = false
        param.source = when (connectType) {
            ConnectType.USB -> StartLiveStream.startLiveViewSource.Start_LiveViewSource_USB
            ConnectType.WIFI, ConnectType.WIFI_AWARE -> StartLiveStream.startLiveViewSource.Start_LiveViewSource_WIFI
            ConnectType.BLE -> StartLiveStream.startLiveViewSource.Start_LiveViewSource_BT
        }
        return param
    }

    override suspend fun getFileInfoList(fileLocation: StorageData.FileLocation): Result<List<FileInfo>> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.getFileInfoList(fileLocation.nativeValue)
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun release() {
        callbackMutex.withLock {
            callbackMap.clear()
        }
        optionDelegate.release()
        photographyOptionDelegate.release()
        timelapseOptionDelegate.release()
        multiVideoOptionDelegate.release()
        captureDelegate.release()
        if (batteryCheckJob?.isActive == true) batteryCheckJob?.cancel()
        batteryCheckJob = null
    }

    override suspend fun checkAuthorization(): Result<AuthorizationStatus> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.checkAuthorization()
                Logger.i(TAG, "checkAuthorization, requestId=$id")
                callbackMutex.withLock { callbackMap[id] = call }
            }
        }
    }

    /**
     * 根据 BLE 设备名解析机型，判断是否需要传授权 UUID。
     * 复用扫描阶段的 simpleName 匹配约定。
     */
    private fun resolveWakeUpAuthorizationUUID(deviceName: String?): String? {
        if (deviceName.isNullOrEmpty()) return null
        val cameraType = ICameraConfig.supportCameraType()
            .firstOrNull { deviceName.contains(it.simpleName) }
            ?: return null
        val needAuth = ICameraConfig.createCameraConfig(cameraType, connectType)?.needAuthorization() == true
        return if (needAuth) {
            val uuid = getCustomizedDeviceID()
            Logger.i(TAG, "resolveWakeUpAuthorizationUUID: cameraType=$cameraType  uuid=$uuid")
            uuid
        } else null
    }

    override suspend fun requestAuthorization(operationType: AuthorizationOperationType): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.requestAuthorization(operationType.value)
                Logger.i(TAG, "requestAuthorization, operationType=$operationType  requestId=$id")
                callbackMutex.withLock { callbackMap[id] = call }
            }
        }
    }

    override suspend fun cancelAuthorization(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.cancelAuthorization()
                Logger.i(TAG, "cancelAuthorization, requestId=$id")
                callbackMutex.withLock { callbackMap[id] = call }
            }
        }
    }

    override suspend fun cancelRequestAuthorization(operationType: AuthorizationOperationType): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = callback {
                success { if (continuation.isActive) continuation.resume(Result.success(it)) }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.cancelRequestAuthorization(operationType.value)
                Logger.i(TAG, "cancelRequestAuthorization, operationType=$operationType  requestId=$id")
                callbackMutex.withLock { callbackMap[id] = call }
            }
        }
    }

}