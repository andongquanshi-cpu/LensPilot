package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

data class StorageData(val state: State, val free: Long, val total: Long, val fileLocation: FileLocation, val spec: Long) {

    enum class State(override val nativeValue: Int) : BaseEnum {
        PASS(0),
        NO_CARD(1),
        NO_SPACE(2),
        INVALID_FORMAT(3),
        WP_CARD(4),
        OTHER_ERROR(5);

        companion object {
            fun nativeOf(nativeValue: Int?): State {
                return State.entries.firstOrNull { it.nativeValue == nativeValue } ?: NO_CARD
            }
        }
    }

    enum class FileLocation(override val nativeValue: Int) : BaseEnum {
        /**
         * 相机存储
         * X6之前的相机均使用CAMERA
         */
        CAMERA(0),

        /**
         * 闪存伴侣
         */
        READER(1),

        /**
         * 相机内部存储（X6之后支持）
         */
        INNER(2),

        /**
         * 外置SD卡（X6之后支持）
         */
        SD(3);

        companion object {
            fun nativeOf(nativeValue: Int?): FileLocation {
                return FileLocation.entries.firstOrNull { it.nativeValue == nativeValue } ?: CAMERA
            }
        }
    }
}

