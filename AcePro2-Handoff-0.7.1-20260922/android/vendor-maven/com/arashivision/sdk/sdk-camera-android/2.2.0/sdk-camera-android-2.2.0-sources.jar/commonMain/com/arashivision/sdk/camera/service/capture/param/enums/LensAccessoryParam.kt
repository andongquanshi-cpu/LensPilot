package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.LensAccessoryType
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class LensAccessoryParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : EnumCameraParam<LensAccessoryType>(CommonAttrKeys.LENS_ACCESSORIES_TYPE, managerProvider, deviceCoreProvider) {

    override fun unknowValue(): LensAccessoryType? = null

    override fun fromInt(value: Int): LensAccessoryType {
        return LensAccessoryType.nativeOf(value)
    }

    override fun fromName(name: String): LensAccessoryType {
        return LensAccessoryType.protoOf(name)
    }

    override fun toInt(data: LensAccessoryType): Int {
        return data.nativeValue
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<LensAccessoryType> {
        return device.getLensAccessoryInfo(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<LensAccessoryType> {
        return device.fetchLensAccessoryInfo(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: LensAccessoryType): Result<Unit> {
        return device.setLensAccessoryInfo(functionMode, value)
    }

}