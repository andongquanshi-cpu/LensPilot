package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.notify.TempState

/**
 * 相机温度状态监听器。
 *
 * 用于监听相机机身温度的变化，以便在温度过高时采取相应措施（如降低帧率、停止录制或提示用户）。
 */
interface TemperatureListener {
    /**
     * 当相机温度状态发生变化时回调。
     *
     * @param tempState 包含当前温度等级或具体状态的对象。
     */
    fun onTemperatureUpdate(tempState: TempState)
}
