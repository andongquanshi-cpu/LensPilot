package com.arashivision.sdk.camera.core.model

data class WiFiAwareConnectHint(val networkHandle: Long, val peerIpv6: String)
