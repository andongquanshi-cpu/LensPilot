package com.arashivision.sdk.camera.core.native

import com.arashivision.camera.InstaCamera
import com.arashivision.camera.RequestOptions
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IBleScanListener
import com.arashivision.camera.listener.ICameraConnectionListener
import com.arashivision.camera.listener.ICameraInfoListener
import com.arashivision.camera.listener.ICameraRecordListener
import com.arashivision.camera.listener.IReconnectCallback
import com.arashivision.camera.listener.ITimelapseListener
import com.arashivision.camera.listener.OnStillImageListener
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BleErrorCodeCore
import com.arashivision.inskmp.insble.data.ConnectL2SuccessResultCore
import com.arashivision.inskmp.insble.data.ScanResultCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import com.arashivision.onecamera.OneDriver
import com.arashivision.onecamera.OneDriverInfo
import com.arashivision.sdk.camera.api.param.listener.BleWakeUpListener
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationOperationType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationResult
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationStatus
import com.arashivision.sdk.camera.core.model.file.FileInfo
import com.arashivision.sdk.camera.core.model.notify.TempState
import com.arashivision.sdk.common.exception.BleConnectRejectException
import com.arashivision.sdk.common.exception.BleDeviceNotFoundException
import com.arashivision.sdk.common.exception.BleScanRejectException
import com.arashivision.sdk.common.exception.INSTA_OK
import com.arashivision.sdk.common.exception.INSTA_UNKNOWN
import com.arashivision.sdk.common.exception.NativeException
import com.arashivision.sdk.common.exception.NativeRespNullException
import com.arashivision.sdk.common.kotlin.allNotNull
import com.arashivision.sdk.common.kotlin.fileExtension
import com.arashivision.sdk.common.kotlin.getCustomizedDeviceID
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.common.system.PlatformType
import com.arashivision.sdk.common.system.platformType
import com.arashivision.utils.CLogUtils
import insta360.messages.BatteryInfo
import insta360.messages.CalibrateGyro
import insta360.messages.CaptureMode
import insta360.messages.CaptureStatus
import insta360.messages.CardLocation
import insta360.messages.ChargeboxConnectedStatus
import insta360.messages.CheckAuthorization
import insta360.messages.CheckAuthorizationResp
import insta360.messages.CtrlPreRecord
import insta360.messages.DeleteFiles
import insta360.messages.FileInfo_List
import insta360.messages.FileType
import insta360.messages.FormatStorage
import insta360.messages.GetActiveSensorDeviceResp
import insta360.messages.GetCurrentCaptureStatusResp
import insta360.messages.GetFile
import insta360.messages.GetFileList
import insta360.messages.GetFileListResp
import insta360.messages.GetFileResp
import insta360.messages.GetMultiPhotographyOptionsResp
import insta360.messages.GetOptionsResp
import insta360.messages.GetPhotographyOptionsResp
import insta360.messages.GetTimelapseOptions
import insta360.messages.GetTimelapseOptionsResp
import insta360.messages.LiveStreamParamsUpdate
import insta360.messages.MediaType
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.NotificationAuthorizationResult
import insta360.messages.NotificationCameraPostureUpdate
import insta360.messages.NotificationCaptureStopped
import insta360.messages.NotificationTimeLapseStatusUpdate
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.SetTimelapseOptions
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.TakePicture
import insta360.messages.TakePictureResponse
import insta360.messages.TemperatureState
import insta360.messages.TimelapseMode
import insta360.messages.TimelapseOptions
import insta360.messages.TrackState
import insta360.messages.Video
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.atomicfu.locks.synchronized
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.runBlocking

class UnifiedTransport(private val connectType: ConnectType) {
    companion object {
        private const val TAG = "UnifiedTransport"
        private val releaseLock = SynchronizedObject()

        const val CAMERA_SERVICE_WIFI_AP_IP: String = "192.168.42.1"
        private const val CAMERA_SOCKET_PORT: Short = 6666

        private val SUPPORT_CAMERA_FILE_EXTENSION = mutableListOf<String?>(
            ".insp", ".insv", ".jpg", ".jpeg", ".mp4", ".raw", ".dng", ".lrv", ".insdata"
        )
    }

    private lateinit var instaCamera: InstaCamera

    private val _events = MutableSharedFlow<TransportEvent>(replay = 1, extraBufferCapacity = 16)
    val events: SharedFlow<TransportEvent> = _events.asSharedFlow()

    private var isConnection: Boolean = false

    private var packLogFileId: Long = -1

    private val cameraConnectionListener = object : ICameraConnectionListener {
        override fun onCameraConnect() {
            Logger.i(TAG, "[connection][onCameraConnect]")
            _events.tryEmit(TransportEvent.ConnectionEvent.Connected(connectType))
            isConnection = false
        }

        override fun onCameraStateChange() {
            Logger.i(TAG, "[connection][onCameraStateChange]")
        }

        override fun onCameraError(error: Int) {
            Logger.i(TAG, "[connection][onCameraError]  error=$error")
            if (isConnection) {
                _events.tryEmit(TransportEvent.ConnectionEvent.Failed(connectType, NativeException(error, "camera connect failed $error")))
                isConnection = false
            } else {
                val tryEmit = _events.tryEmit(TransportEvent.ConnectionEvent.Disconnected(connectType, NativeException(error, "Forced to disconnect from camera, error=${error}")))
                Logger.i(TAG, "[connection][onCameraError]  tryEmit=$tryEmit")
                release()
            }
        }
    }

    private val cameraInfoListener = object : ICameraInfoListener {
        override fun onCameraInfo(what: Int, requestId: Long, err: Int, obj: Any?) {
            Logger.i(TAG, "[camera info]    what=$what  requestId=$requestId    err=$err    obj=$obj")
            when (what) {
                OneDriverInfo.Response.InfoType.CAM_WIFI_START -> {

                }

                OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_CLOSE_WIFI -> {
                    if (connectType == ConnectType.WIFI || connectType == ConnectType.WIFI_AWARE) {
                        Logger.i(TAG, "[connection] camera actively closed wifi, treat as disconnected")
                        val tryEmit = _events.tryEmit(TransportEvent.ConnectionEvent.Disconnected(connectType, NativeException(INSTA_OK, "Camera actively closed wifi, notified by CAMERA_NOTIFICATION_CLOSE_WIFI")))
                        Logger.i(TAG, "[connection][onCameraNotificationCloseWifi]  tryEmit=$tryEmit")
                        release()
                    }
                }

                OneDriverInfo.Response.InfoType.SET_ACCESS_CAMERA_FILE_STATE -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetLockScreenStateEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set lock screen state failed, error=$err")
                        _events.tryEmit(TransportEvent.SetLockScreenStateEvent.Failed(requestId, exception))
                    }
                }

                // 该消息是 App 主动查询相机 RTOS 状态的回包，状态值通过 err 参数下发，obj 恒为 null
                OneDriverInfo.Response.InfoType.LINUX_CMD_RTOS_STATUS -> {
                    if (err == OneDriverInfo.LinuxCmd.RtosStatus.NORMAL) {
                        Logger.i(TAG, "Rtos status normal")
                    } else {
                        Logger.e(TAG, "Rtos status error, statusCode=$err")
                    }
                }
                OneDriverInfo.Response.InfoType.CAM_BT_MSG_ANALYZE_FAILED -> Logger.e(TAG, "Camera ble message analyze failed")
                OneDriverInfo.Response.InfoType.GET_OPTIONS -> {
                    if (err == INSTA_OK) {
                        (obj as? GetOptionsResp)?.value_?.let {
                            _events.tryEmit(TransportEvent.GetOptionEvent.Success(requestId, it))
                        } ?: run {
                            val exception = NativeRespNullException("Get option failed, resp is null")
                            _events.tryEmit(TransportEvent.GetOptionEvent.Failed(requestId, exception))
                        }
                    } else {
                        val exception = NativeException(err, "Get option failed, error=$err")
                        _events.tryEmit(TransportEvent.GetOptionEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_OPTIONS -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetOptionEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set option failed, error=$err")
                        _events.tryEmit(TransportEvent.SetOptionEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_PHOTOGRAPHY_OPTIONS -> {
                    if (err == INSTA_OK) {
                        (obj as? GetPhotographyOptionsResp)?.value_?.let {
                            _events.tryEmit(TransportEvent.GetPhotographyOptionEvent.Success(requestId, it))
                        } ?: run {
                            val exception = NativeRespNullException("Get photography option failed, resp is null")
                            _events.tryEmit(TransportEvent.GetPhotographyOptionEvent.Failed(requestId, exception))
                        }
                    } else {
                        val exception = NativeException(err, "Get photography option failed, error=$err")
                        _events.tryEmit(TransportEvent.GetPhotographyOptionEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_PHOTOGRAPHY_OPTIONS -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetPhotographyOptionEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set photography option failed, error=$err")
                        _events.tryEmit(TransportEvent.SetPhotographyOptionEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_SWITCH_WIFI_CHANNEL -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SwitchWifiChannelEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Get switch wifi channel failed, error=$err")
                        _events.tryEmit(TransportEvent.SwitchWifiChannelEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.RESET_CAMERA_WIFI -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.ResetCameraWiFiEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Reset camera WI-FI failed, error=$err")
                        _events.tryEmit(TransportEvent.ResetCameraWiFiEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.OPEN_CAMERA_WIFI -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.OpenCameraWiFiEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Reset camera WI-FI failed, error=$err")
                        _events.tryEmit(TransportEvent.OpenCameraWiFiEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.CLOSE_CAMERA_WIFI -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.CloseCameraWiFiEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Reset camera WI-FI failed, error=$err")
                        _events.tryEmit(TransportEvent.CloseCameraWiFiEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_WIFI_MODE -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetWifiModeEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set wifi mode failed, error=$err")
                        _events.tryEmit(TransportEvent.SetWifiModeEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.BATTERY_UPDATE -> {
                    _events.tryEmit(TransportEvent.BatteryUpdateEvent(obj as? BatteryInfo))
                }

                OneDriverInfo.Response.InfoType.BATTERY_LOW -> {
                    _events.tryEmit(TransportEvent.BatteryLowEvent(obj as? BatteryInfo))
                }

                OneDriverInfo.Response.InfoType.CHARGE_BOX_CONNECT_STATUS_UPDATE -> {
                    (obj as? ChargeboxConnectedStatus)?.let {
                        _events.tryEmit(TransportEvent.ChargeBoxConnectStatusUpdateEvent(it))
                    }
                }

                OneDriverInfo.Response.InfoType.NOTIFY_CHARGE_BOX_BATTERY_UPDATE -> {
                    _events.tryEmit(TransportEvent.ChargeBoxBatteryUpdateEvent(obj as? BatteryInfo))
                }

                OneDriverInfo.Response.InfoType.CAM_TEMPERATURE_VALUE -> {
                    (obj as? TemperatureState)?.let {
                        _events.tryEmit(TransportEvent.TemperatureEvent(TempState.nativeOf(it.value)))
                    }
                }

                OneDriverInfo.Response.InfoType.STORAGE_FULL -> {
                    _events.tryEmit(TransportEvent.StorageEvent.Full)
                }

                OneDriverInfo.Response.InfoType.STORAGE_UPDATE -> {
                    _events.tryEmit(TransportEvent.StorageEvent.Update)
                }

                OneDriverInfo.Response.InfoType.GET_CURRENT_CAPTURE_STATUS -> {
                    if (err == INSTA_OK) {
                        (obj as? GetCurrentCaptureStatusResp)?.status?.let {
                            _events.tryEmit(TransportEvent.GetCaptureStatusEvent.Success(requestId, it))
                        } ?: run {
                            val exception = NativeRespNullException("Get capture status failed, resp is null")
                            _events.tryEmit(TransportEvent.GetCaptureStatusEvent.Failed(requestId, exception))
                        }
                    } else {
                        val exception = NativeException(err, "Get capture status failed, error=$err")
                        _events.tryEmit(TransportEvent.GetCaptureStatusEvent.Failed(requestId, exception))
                    }
                }


                OneDriverInfo.Response.InfoType.CAMERA_STATUS_NOTIFY -> {
                    (obj as? CaptureStatus)?.let {
                        _events.tryEmit(TransportEvent.CameraCaptureStatusNotifyEvent(it))
                    }
                }

                OneDriverInfo.Response.InfoType.RECORD_STOPPED -> {
                    (obj as? NotificationCaptureStopped)?.let {
                        _events.tryEmit(TransportEvent.CameraCaptureStopedNotifyEvent(it))
                    }
                }

                OneDriverInfo.Response.InfoType.NOTIFY_TIMELAPSE_STATUS_UPDATE -> {
                    (obj as? NotificationTimeLapseStatusUpdate)?.interval_count?.let {
                        _events.tryEmit(TransportEvent.CameraTimelapseStatusNotifyEvent(it))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_TIMELAPSE_OPTIONS -> {
                    if (err == INSTA_OK) {
                        (obj as? GetTimelapseOptionsResp)?.timelapse_options?.let {
                            _events.tryEmit(TransportEvent.GetTimelapseOptionsEvent.Success(requestId, it))
                        } ?: run {
                            val exception = NativeRespNullException("Get timelapse option failed, resp is null")
                            _events.tryEmit(TransportEvent.GetTimelapseOptionsEvent.Failed(requestId, exception))
                        }
                    } else {
                        val exception = NativeException(err, "Get timelapse option failed, error=$err")
                        _events.tryEmit(TransportEvent.GetTimelapseOptionsEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_TIMELAPSE_OPTIONS -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetTimelapseOptionsEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set timelapse option failed, error=$err")
                        _events.tryEmit(TransportEvent.SetTimelapseOptionsEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_SINGLE_SENSOR -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetSensorModeEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set sensor mode failed, error=$err")
                        _events.tryEmit(TransportEvent.SetSensorModeEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_SINGLE_SENSOR -> {
                    if (err == INSTA_OK) {
                        (obj as? GetActiveSensorDeviceResp)?.let {
                            _events.tryEmit(TransportEvent.GetSensorModeEvent.Success(requestId, it.device))
                        } ?: run {
                            val exception = NativeRespNullException("Get sensor mode failed, resp is null")
                            _events.tryEmit(TransportEvent.GetTimelapseOptionsEvent.Failed(requestId, exception))
                        }

                    } else {
                        val exception = NativeException(err, "Set sensor mode failed, error=$err")
                        _events.tryEmit(TransportEvent.GetSensorModeEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_FILEINFO_LIST -> {
                    (obj as? FileInfo_List)?.let {
                        val fileInfoList = it.file_info
                            .filter { file -> file.file_path.fileExtension() in SUPPORT_CAMERA_FILE_EXTENSION }
                            .map { file ->
                                FileInfo(file.file_path, file.metadata.toByteArray())
                            }
                        _events.tryEmit(TransportEvent.GetFileInfoEvent.Success(requestId, fileInfoList))
                    } ?: run {
                        val exception = NativeException(-1, "Get file info list failed, resp is null")
                        _events.tryEmit(TransportEvent.GetFileInfoEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_DOWNLOAD_FILE_LIST -> {}
                OneDriverInfo.Response.InfoType.GET_FILE_LIST, OneDriverInfo.Response.InfoType.GET_FILE_LIST_INCLUDE_RECORDING -> {
                    (obj as? GetFileListResp)?.let {
                        val supportedUris = it.uri.filterTo(mutableListOf()) { uri ->
                            SUPPORT_CAMERA_FILE_EXTENSION.contains(getMediaFileExtension(uri))
                        }
                        _events.tryEmit(TransportEvent.GetMediaFileListEvent.Success(requestId, supportedUris, it.total_count))
                    } ?: run {
                        val exception = NativeException(-1, "Get file list failed, resp is null")
                        _events.tryEmit(TransportEvent.GetMediaFileListEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.DELETE_FILES -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.DeleteMediaFileListEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Delete file list failed, error=$err")
                        _events.tryEmit(TransportEvent.DeleteMediaFileListEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.PREPARE_GET_FILE_PACKAGE, OneDriverInfo.Response.InfoType.PREPARE_GET_FILE_SYNC_PACKAGE -> {
                    if (err == INSTA_OK) {
                        if (requestId != packLogFileId) {
                            (obj as? GetFileResp)?.let {
                                _events.tryEmit(TransportEvent.GetCameraFileListEvent.Success(requestId, it.uri, it.version))
                            } ?: run {
                                val exception = NativeRespNullException("Get camera file failed, resp is null")
                                _events.tryEmit(TransportEvent.GetCameraFileListEvent.Failed(requestId, exception))
                            }
                        }
                    } else {
                        if (packLogFileId == -1L) {
                            val exception = NativeException(err, "Get camera file failed, error=$err")
                            _events.tryEmit(TransportEvent.GetCameraFileListEvent.Failed(requestId, exception))
                        } else {
                            val exception = NativeException(err, "Pack camera log file failed, error=$err")
                            _events.tryEmit(TransportEvent.PackCameraLogFileEvent.Failed(packLogFileId, exception))
                        }
                        packLogFileId = -1L
                    }
                }

                OneDriverInfo.Response.InfoType.NOTIFICATION_DATA_EXPORT_STATUS -> {
                    if (packLogFileId != -1L) {
                        if (err == INSTA_OK) {
                            (obj as? TrackState)?.let {
                                _events.tryEmit(TransportEvent.PackCameraLogFileEvent.Success(packLogFileId, it.uri))
                            } ?: run {
                                val exception = NativeRespNullException("Pack camera log file, resp is null")
                                _events.tryEmit(TransportEvent.PackCameraLogFileEvent.Failed(packLogFileId, exception))
                            }
                        } else {
                            val exception = NativeException(err, "Pack camera log file failed, error=$err")
                            _events.tryEmit(TransportEvent.PackCameraLogFileEvent.Failed(packLogFileId, exception))
                        }
                        packLogFileId = -1L
                    }
                }

                OneDriverInfo.Response.InfoType.CALIBRATE_GYRO -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.CalibrateGyroEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Calibrate gyro failed, error=$err")
                        _events.tryEmit(TransportEvent.CalibrateGyroEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.ERASE_SD_CARD -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.EraseSdCardEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Erase sd card failed, error=$err")
                        _events.tryEmit(TransportEvent.EraseSdCardEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.FORMAT_STORAGE -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.FormatStorageEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "format storage failed, error=$err")
                        _events.tryEmit(TransportEvent.FormatStorageEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_MAIN_STORAGE -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetMainStorageEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "set main storage failed, error=$err")
                        _events.tryEmit(TransportEvent.SetMainStorageEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.SET_MULTI_VIDEO_MODE -> {
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.SetMultiVideoModeEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Set multi video mode failed, error=$err")
                        _events.tryEmit(TransportEvent.SetMultiVideoModeEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.GET_MULTI_VIDEO_MODE -> {
                    if (err == INSTA_OK) {
                        (obj as? GetMultiPhotographyOptionsResp)?.value_?.let {
                            _events.tryEmit(TransportEvent.GetMultiVideoModeEvent.Success(requestId, it))
                        } ?: run {
                            val exception = NativeRespNullException("Get multi video mode failed, resp is null")
                            _events.tryEmit(TransportEvent.GetMultiVideoModeEvent.Failed(requestId, exception))
                        }
                    } else {
                        val exception = NativeException(err, "Get multi video mode failed, error=$err")
                        _events.tryEmit(TransportEvent.GetMultiVideoModeEvent.Failed(packLogFileId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.LIVEVIEW_BEGIN_ROTATE -> {
                    Logger.i(TAG, "live view begin rotate notify")
                    _events.tryEmit(TransportEvent.LiveViewBeginRotateEvent(obj as NotificationCameraPostureUpdate))
                }

                OneDriverInfo.Response.InfoType.START_LIVE_STREAM -> {
                    Logger.i(TAG, "live stream start notify")
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.LiveStreamEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Start live stream failed, error=$err")
                        _events.tryEmit(TransportEvent.LiveStreamEvent.Failed(requestId, err))
                    }
                }

                OneDriverInfo.Response.InfoType.STOP_LIVE_STREAM -> {
                    Logger.i(TAG, "live stream stop notify")
                    _events.tryEmit(TransportEvent.LiveStreamEvent.Stopped(requestId))
                }

                OneDriverInfo.Response.InfoType.LIVE_STREAM_PARAMS_UPDATE -> {
                    Logger.i(TAG, "live stream params update notify")
                    val params = obj as LiveStreamParamsUpdate
                    _events.tryEmit(
                        TransportEvent.LiveStreamEvent.ParamsUpdate(
                            requestId = requestId,
                            windowCropInfo = params.window_crop_info,
                            halfWindowCropInfo = params.half_window_crop_info,
                        ),
                    )
                }

                OneDriverInfo.Response.InfoType.CHECK_AUTHORIZATION -> {
                    Logger.i(TAG, "check authorization response, requestId=$requestId  err=$err  obj=$obj")
                    if (err == INSTA_OK) {
                        val status = AuthorizationStatus.nativeOf(
                            (obj as? CheckAuthorizationResp)?.authorization_status?.value ?: -1
                        )
                        _events.tryEmit(TransportEvent.CheckAuthorizationEvent.Success(requestId, status))
                    } else {
                        val exception = NativeException(err, "Check authorization failed, error=$err")
                        _events.tryEmit(TransportEvent.CheckAuthorizationEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.REQUEST_AUTHORIZATION -> {
                    Logger.i(TAG, "request authorization response, requestId=$requestId  err=$err")
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.AuthorizationCommandEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Request authorization failed, error=$err")
                        _events.tryEmit(TransportEvent.AuthorizationCommandEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.CANCEL_AUTHORIZATION -> {
                    Logger.i(TAG, "cancel authorization response, requestId=$requestId  err=$err")
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.AuthorizationCommandEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Cancel authorization failed, error=$err")
                        _events.tryEmit(TransportEvent.AuthorizationCommandEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.CANCEL_REQUEST_AUTHORIZATION -> {
                    Logger.i(TAG, "cancel request authorization response, requestId=$requestId  err=$err")
                    if (err == INSTA_OK) {
                        _events.tryEmit(TransportEvent.AuthorizationCommandEvent.Success(requestId))
                    } else {
                        val exception = NativeException(err, "Cancel request authorization failed, error=$err")
                        _events.tryEmit(TransportEvent.AuthorizationCommandEvent.Failed(requestId, exception))
                    }
                }

                OneDriverInfo.Response.InfoType.NOTIFY_AUTHORIZATION -> {
                    Logger.i(TAG, "notify authorization, requestId=$requestId  err=$err  obj=$obj")
                    (obj as? NotificationAuthorizationResult)?.let {
                        _events.tryEmit(
                            TransportEvent.NotifyAuthorizationEvent(
                                operationType = AuthorizationOperationType.nativeOf(it.authorization_operation_type.value),
                                result = AuthorizationResult.nativeOf(it.authorization_result.value),
                            )
                        )
                    }
                }
            }
        }
    }

    private val cameraRecordListener = object : ICameraRecordListener {
        override fun onDriverRecordVideoStateNotify(state: Int, error: Int, video: Video?) {
            Logger.i(TAG, "record video state notify. state=$state  error=$error  video:$video")
            _events.tryEmit(TransportEvent.RecordVideoEvent(state, error, video))
        }
    }

    private val stillImageListener = object : OnStillImageListener {
        override fun onDriverStillImageNotify(errorCode: Int, mResponse: TakePictureResponse?) {
            Logger.i(TAG, "still image notify. errorCode=$errorCode  response=$mResponse")
            _events.tryEmit(TransportEvent.StillImageEvent(errorCode, mResponse))
        }

        override fun onDriverStillImageWithoutStorageNotify(error: Int, datas: ByteArray?) {
            Logger.i(TAG, "still image without storage notify. error=$error  data=${datas?.toString()}")
        }
    }

    private val timelapseListener = object : ITimelapseListener {
        override fun ononTimelapseRecordNotify(state: Int, error: Int, video: Video?) {
            Logger.i(TAG, "timelapse record notify. state=$state  error=$error  video=$video")
            _events.tryEmit(TransportEvent.TimelapseEvent(state, error, video))
        }
    }

    fun init() {
        instaCamera = InstaCamera.instance
        instaCamera.init()
        instaCamera.setNativeLoggerCallback(object : CLogUtils.ILoggerCallback {
            override fun onLogV(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.v(tag!!, msg!!)
                }
            }

            override fun onLogD(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.d(tag!!, msg!!)
                }
            }

            override fun onLogI(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.i(tag!!, msg!!)
                }
            }

            override fun onLogW(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.w(tag!!, msg!!)
                }
            }

            override fun onLogE(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.e(tag!!, msg!!)
                }
            }

            override fun onLogFt(tag: String?, msg: String?) {
                allNotNull(tag, msg) {
                    Logger.e(tag!!, msg!!)
                }
            }
        })
        instaCamera.addConnectionListener(cameraConnectionListener)
        instaCamera.addCameraInfoListener(cameraInfoListener)
        instaCamera.addCameraRecordListener(cameraRecordListener)
        instaCamera.addStillImageListener(stillImageListener)
        instaCamera.addTimelapseRecordListener(timelapseListener)
        instaCamera.setNeedReconnectCallback(object : IReconnectCallback {
            override fun needReconnectSocket(): Boolean {
                return false
            }

            override fun onReconnectSocketSuccess() {}
        })
        instaCamera.setGlobalRequestTimeoutMs(5_000)
    }

    fun scan(timeout: Long) {
        Logger.i(TAG, "start scan function， connectType = $connectType")
        if (connectType != ConnectType.BLE) return
        instaCamera.scan(timeout, false, object : IBleScanListener {
            override fun onRawScanResult(callbackType: Int, result: ScanResultCore?) {
            }

            override fun onScanning(bleDevice: BleDeviceCore?) {
                if (bleDevice == null || bleDevice.name.isNullOrEmpty() || bleDevice.mac.isNullOrEmpty()) return
                Logger.i(TAG, "[ble scan][onScanning]  deviceName=${bleDevice.name}    deviceMac=${bleDevice.mac}")
                _events.tryEmit(TransportEvent.ScanEvent.Scanning(bleDevice))
            }

            override fun onScanUpdate(bleDevice: List<BleDeviceCore>?) {
            }

            override fun onScanStarted(errorCode: Int) {
                Logger.i(TAG, "[ble scan][onScanStarted]  errorCode=${errorCode}")
                if (errorCode == BleErrorCodeCore.SCAN_SUCCESS) {
                    _events.tryEmit(TransportEvent.ScanEvent.Started)
                } else {
                    _events.tryEmit(TransportEvent.ScanEvent.Failed(NativeException(errorCode, "ble scan failed")))
                }
            }

            override fun onScanFinished(scanResultList: List<BleDeviceCore>?) {
                Logger.i(TAG, "[ble scan][onScanFinished]  scanResultList=${scanResultList?.map { it.name }}")
                scanResultList?.let { _events.tryEmit(TransportEvent.ScanEvent.Finished(scanResultList)) }
            }

            override fun onScanReject() {
                Logger.i(TAG, "[ble scan][onScanReject]")
                _events.tryEmit(TransportEvent.ScanEvent.Failed(BleScanRejectException("ble scan reject")))
            }

        })
    }

    fun stopScan() {
        Logger.i(TAG, "start stop scan function")
        if (connectType != ConnectType.BLE) return
        instaCamera.stopScanBle()
    }

    fun bleWakeUp(mode: Int, deviceName: String, txPower: Byte, listener: BleWakeUpListener?) {
        Logger.i(TAG, "start ble wake up function")
        if (connectType != ConnectType.BLE) return
        instaCamera.setBleWakeupListener(object : BleWakeupCallbackCore {
            override fun wakeupSuccess() {
                Logger.i(TAG, "start ble wake up success")
                listener?.onWakeUpSuccess()
            }

            override fun wakeupError(errorCode: Int) {
                Logger.i(TAG, "start ble wake up error = $errorCode")
                listener?.onWakeUpError(errorCode)
            }
        })
        instaCamera.wakeUpBle(mode, deviceName, txPower)
    }

    fun setBleWakeUpListener(listener: BleWakeUpListener) {

    }

    fun connectUsb() {
        Logger.i(TAG, "start connect usb function")
        isConnection = true
        instaCamera.openUsb()
    }

    fun connectWiFi(networkId: Long, isUseUcd2: Boolean = false) {
        Logger.i(TAG, "start connect wifi function, networkId=$networkId")
        isConnection = true
        instaCamera.openWifi(
            networkId,
            5000,
            CAMERA_SERVICE_WIFI_AP_IP,
            CAMERA_SOCKET_PORT,
            heartBeats = true,
            isUseUcd2 = isUseUcd2,
            processBusyPacketEnable = false
        )
    }

    fun connectWiFiAware(networkHandle: Long, peerIpv6: String) {
        Logger.i(TAG, "start connect wifi aware function, networkHandle=$networkHandle peerIpv6=$peerIpv6")
        isConnection = true
        instaCamera.openWifi(
            networkHandle,
            5000,
            peerIpv6,
            CAMERA_SOCKET_PORT,
            heartBeats = true,
            isUseUcd2 = true,
            processBusyPacketEnable = false
        )
    }

    fun connectBle(bleDeviceCore: BleDeviceCore, wakeUpAuthorizationUUID: String = "", enableHeartBeat: Boolean = false, isUseUcd2: Boolean = false) {
        Logger.i(
            TAG, "start connect ble function, ble device name ${bleDeviceCore.name}  " +
                    "wakeUpAuthorizationUUID=$wakeUpAuthorizationUUID  enableHeartBeat=$enableHeartBeat    isUseUcd2=$isUseUcd2"
        )
        isConnection = true
        instaCamera.connect(
            bleDeviceCore,
            wakeUpAuthorizationUUID,
            enableHeartBeat,
            isUseUcd2,
            object : IBleConnectListener {
                override fun onStartConnect() {
                    Logger.i(TAG, "[connect ble][onStartConnect]")
                }

                override fun onStartFailed() {
                    Logger.i(TAG, "[connect ble][onStartFailed]")
                    _events.tryEmit(TransportEvent.ConnectionEvent.Failed(connectType, BleDeviceNotFoundException("ble device no found")))
                    isConnection = false
                }

                override fun onConnectFail(bleDevice: BleDeviceCore?, exception: BleExceptionCore?) {
                    Logger.e(TAG, "[connect ble][onConnectFail]  device=${bleDevice?.name}   errorCode=${exception?.getCode()}   errorMessage=${exception?.getDescription()}")
                    if (bleDeviceCore.name != bleDevice?.name || bleDeviceCore.mac != bleDevice?.mac) return
                    _events.tryEmit(
                        TransportEvent.ConnectionEvent.Failed(
                            connectType, NativeException(exception?.getCode() ?: INSTA_UNKNOWN, exception?.getDescription() ?: "ble device connect failed")
                        )
                    )
                    isConnection = false
                }

                override fun onConnectSuccess(bleDevice: BleDeviceCore?, gatt: Any?, status: Int) {
                    Logger.i(TAG, "[connect ble][onConnectSuccess]   device=${bleDevice?.name} ")
                    if (bleDeviceCore.name != bleDevice?.name || bleDeviceCore.mac != bleDevice?.mac) return
                    _events.tryEmit(TransportEvent.ConnectionEvent.Connected(connectType))
                    isConnection = false
                }

                override fun onConnectL2Success(bleDevice: BleDeviceCore, gatt: Any?, status: Int): ConnectL2SuccessResultCore {
                    Logger.i(TAG, "[connect ble][onConnectL2Success]  device=${bleDevice.name}   status=$status")
                    return ConnectL2SuccessResultCore()
                }

                override fun onDisConnected(isActiveDisConnected: Boolean, device: BleDeviceCore?, gatt: Any?, status: Int) {
                    Logger.i(TAG, "[connect ble][onDisConnected]  device=${device?.name}   isActiveDisConnected=$isActiveDisConnected   status=$status")
                }

                override fun onBondReject(bleDevice: BleDeviceCore?) {
                    Logger.e(TAG, "[connect ble][onBondReject]  device=${bleDevice?.name}")
                    if (bleDeviceCore.name != bleDevice?.name || bleDeviceCore.mac != bleDevice?.mac) return
                    _events.tryEmit(TransportEvent.ConnectionEvent.Failed(connectType, BleConnectRejectException("ble device connect reject")))
                    isConnection = false
                }

                override fun onWriteFailed(bleDevice: BleDeviceCore?, exception: BleExceptionCore?) {
                    Logger.w(TAG, "[connect ble][onWriteFailed]  device=${bleDevice?.name}   errorCode=${exception?.getCode()}   errorMessage=${exception?.getDescription()}")
                }

                override fun onConnectClassicSuccess(bleDevice: BleDeviceCore?, status: Int) {

                }

                override fun onConnectClassicFail(bleDevice: BleDeviceCore?, exception: BleExceptionCore?) {

                }
            })
    }

    fun disconnect() {
        Logger.i(TAG, "start disconnect function")
        if (connectType == ConnectType.BLE) {
            instaCamera.sendDisconnectBleData()
            try {
                // 写蓝牙消息会被post，此处代码又必须同步跑
                // 使用Kotlin协程替代Thread.sleep
                runBlocking {
                    delay(20)
                }
            } catch (e: Exception) {
                Logger.e(TAG, "disconnect ble failed", e)
            }
        }
        release()
    }

    private fun release() {
        synchronized(releaseLock) {
            // 通过调用close方法，释放instaCamera中的广播，避免无限注册广播的问题
            when (connectType) {
                ConnectType.BLE -> {
                    // BleManagerCore.destroy() 必须在 instaCamera.closeBle()/disConnectBle() 之前调用：
                    // 两者内部都会先执行 BleCloseCmd -> BleManagerCore.disconnectAllDevice()，
                    // 只 disconnect 不 destroy 就把 FastBle 的设备表清空；等 destroy() 再执行时
                    // 表已经空了，遍历不到这台设备，对应的 BluetoothAdapter.ACTION_STATE_CHANGED
                    // receiver 就会永久泄漏（无论是手动断开还是相机自动掉线触发的释放路径）。
                    BleManagerCore.destroy()
                    instaCamera.closeBle()
                }

                ConnectType.WIFI, ConnectType.WIFI_AWARE -> {
                    instaCamera.closeWifi()
                }

                ConnectType.USB -> {

                }
            }
            instaCamera.close()
            instaCamera.release()
            instaCamera.removeConnectionListener(cameraConnectionListener)
            instaCamera.removeCameraInfoListener(cameraInfoListener)
            instaCamera.removeCameraReocrdListener(cameraRecordListener)
            instaCamera.removeStillImageListener(stillImageListener)
            instaCamera.removeTimelapseRecordListener(timelapseListener)
        }
    }

    fun getOptions(optionList: List<OptionType>, retryCount: Int = -1, timeoutMs: Int = -1): Long {
        val id = instaCamera.getOptionsSync(optionList, RequestOptions().apply {
            this.retryCount = retryCount
            this.timeoutMs = timeoutMs
        })
        Logger.i(TAG, "getOptions, id=$id  optionList=$optionList  retryCount=$retryCount  timeoutMs=$timeoutMs")
        return id
    }

    fun setOptions(optionList: List<OptionType>, options: Options): Long {
        Logger.i(TAG, "setOptions,  optionList=$optionList")
        Logger.i(TAG, "setOptions,  options=$options")
        return instaCamera.setOptionAsync(optionList, options)
    }

    fun getPhotographyOption(functionMode: Int, options: List<PhotographyOptionType>): Long {
        val id = instaCamera.getPhotoOptionsAsync(functionMode, options.toMutableList())
        Logger.i(TAG, "getPhotographyOption, id=$id  options=$options")
        return id
    }

    fun setPhotographyOption(functionMode: Int, optionTypes: List<PhotographyOptionType>, options: PhotographyOptions): Long {
        val id = instaCamera.setPhotoOptionsSync(functionMode, optionTypes, options)
        Logger.i(TAG, "setPhotographyOption, request id $id")
        return id
    }

    fun getTimelapseOption(timelapseMode: Int): Long {
        val id = instaCamera.getTimelapseOptionAsync(
            GetTimelapseOptions(
                mode = TimelapseMode.fromValue(timelapseMode)!!
            )
        )
        Logger.i(TAG, "getTimelapseOption, request id $id")
        return id
    }

    fun setTimelapseOption(timelapseMode: Int, timelapseOptions: TimelapseOptions): Long {
        val id = instaCamera.setTimelapseOptionsASync(
            SetTimelapseOptions(mode = TimelapseMode.fromValue(timelapseMode)!!, timelapse_options = timelapseOptions)
        )
        Logger.i(TAG, "setTimelapseOption, request id $id")
        return id
    }

    fun switchWiFiChannel(needScan: Boolean, channel: Int): Long {
        val id = instaCamera.switchWifiChannel(if (needScan) 1 else 2, channel)
        Logger.i(TAG, "switchWiFiChannel, request id $id")
        return id
    }

    fun resetCameraWiFi(channel: Int = 0): Long {
        val id = instaCamera.resetCameraWifi(channel)
        Logger.i(TAG, "resetCameraWiFi, request id $id")
        return id
    }

    fun openCameraWifi(channel: Int = 0): Long {
        val id = instaCamera.openCameraWifi(channel)
        Logger.i(TAG, "openCameraWifi, request id $id")
        return id
    }

    fun closeCameraWifi(): Long {
        val id = instaCamera.closeCameraWifi()
        Logger.i(TAG, "closeCameraWifi, request id $id")
        return id
    }

    fun setWifiMode(mode: Int, countryCode: String): Long {
        val id = instaCamera.setWifiMode(mode, countryCode)
        Logger.i(TAG, "setWifiMode, mode=$mode countryCode=$countryCode request id $id")
        return id
    }

    fun takePicture(takePicture: TakePicture) {
        Logger.i(TAG, "start take picture, takePicture=$takePicture")
        instaCamera.tackPicture(takePicture)
    }

    fun stopTakePicture() {
        Logger.i(TAG, "stop take picture")
        instaCamera.stopTackPicture()
    }

    fun startRecord(captureMode: CaptureMode) {
        Logger.i(TAG, "start record")
        instaCamera.startRecord(recordOriginVideo = true, livePush = false, mode = captureMode.value)
    }

    fun stopRecord(captureMode: CaptureMode, extraData: ByteArray) {
        Logger.i(TAG, "stop record")
        instaCamera.stopRecord(captureMode.value, extraData)
    }

    fun startTimelapse(startTimelapse: StartTimelapse) {
        Logger.i(TAG, "start timelapse")
        instaCamera.startTimelapse(startTimelapse)
    }

    fun stopTimelapse(stopTimelapse: StopTimelapse) {
        Logger.i(TAG, "stop timelapse")
        instaCamera.stopTimelapse(stopTimelapse)
    }

    fun startBulletTime() {
        Logger.i(TAG, "start bullet time")
        instaCamera.startBulletTime()
    }

    fun stopBulletTime(extraData: ByteArray) {
        Logger.i(TAG, "stop bullet time")
        instaCamera.stopBulletTime(extraData)
    }

    fun startHdrCapture() {
        Logger.i(TAG, "start hdr capture")
        instaCamera.startHdrCapture()
    }

    fun stopHdrCapture(extraData: ByteArray) {
        Logger.i(TAG, "stop hdr capture")
        instaCamera.stopHdrCapture(extraData)
    }

    fun fetchCaptureState(): Long {
        val id = instaCamera.getCaptureStatus(RequestOptions())
        Logger.i(TAG, "fetchCaptureState, request id $id")
        return id
    }

    fun getSensorMode(): Long {
        val id = instaCamera.getSensorMode(RequestOptions())
        Logger.i(TAG, "getSensorMode, request id $id")
        return id
    }

    fun setSensorMode(sensorType: Int): Long {
        val id = instaCamera.activeSensor(sensorType)
        Logger.i(TAG, "setSensorMode, request id $id")
        return id
    }

    fun getFileInfoList(location: Int): Long {
        val id = instaCamera.getFileInfoList(CardLocation.fromValue(location) ?: CardLocation.STOR_CL_CAMERA)
        Logger.i(TAG, "getFileInfoList, request id $id")
        return id
    }

    fun getMediaFileList(type: MediaType, start: Int, limit: Int): Long {
        val getFileList = GetFileList(
            media_type = type, limit = limit, start = start
        )
        val id = instaCamera.getFileList(getFileList)
        Logger.i(TAG, "getMediaFileList, request id $id    start=$start   limit=$limit")
        return id
    }

    fun getMediaFileListIncludeRecording(type: MediaType, start: Int, limit: Int): Long {
        val getFileList = GetFileList(
            media_type = type, limit = limit, start = start
        )
        val id = instaCamera.getFileListIncludeRecording(getFileList)
        Logger.i(TAG, "getMediaFileListIncludeRecording, request id $id")
        return id
    }

    fun deleteMediaFileList(deleteFiles: List<String>): Long {
        val id = instaCamera.deleteFileList(DeleteFiles(uri = deleteFiles))
        Logger.i(TAG, "delete media file, request id $id")
        return id
    }

    private fun getMediaFileExtension(fileName: String?): String {
        if (fileName == null) return ""

        val index = fileName.lastIndexOf(".")
        if (index == -1) {
            return ""
        }

        return fileName.substring(index).lowercase()
    }

    fun getPort(): Int {
        return instaCamera.getPort()
    }

    fun previewStream(startStreamingParam: StartLiveStream, offset: String) {
        instaCamera.previewStream(startStreamingParam, offset)
    }

    fun closeStream() {
        instaCamera.closePreviewStream()
    }

    fun requestStreamIframe() {
        instaCamera.requestStreamIframe()
    }

    fun setStreamListener(streamListener: OneDriver.OnStreamListener?) {
        instaCamera.setStreamListener(streamListener)
    }

    fun getCameraFile(fileType: FileType): Long {
        val id = instaCamera.getFile(GetFile().apply {
            file_type = fileType
        })
        Logger.d(TAG, "getCameraFile, request id $id")
        return id
    }

    fun packLogFile(): Long {
        val id = instaCamera.packFile(GetFile().apply {
            file_type = FileType.LOG_FILE
        })
        packLogFileId = id
        Logger.d(TAG, "packLogFile, request id $id")
        return id
    }

    fun setAppid(appid: String): Long {
        return instaCamera.setAppId(appid)
    }

    fun setGpsData(gpsData: ByteArray) {
        instaCamera.setGPSData(gpsData)
    }

    fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long {
        return instaCamera.setPreRecord(ctrlPreRecord)
    }

    fun calibrateGyro(): Long {
        val calibrateGyro = CalibrateGyro()
        calibrateGyro.gyro_count = 100;
        return instaCamera.calibrateGyro(calibrateGyro)
    }

    fun setMultiVideoOptions(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        multiPhotoOptions: MultiPhotographyOptions
    ): Long {
        return instaCamera.setMultiVideoOptions(funcMode, sensorMode, optionList, multiPhotoOptions)
    }

    fun getMultiVideoOptions(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>
    ): Long {
        return instaCamera.getMultiVideoOptions(funcMode, sensorMode, optionList)
    }

    fun setAccessCameraFileState(state: Int): Long {
        return instaCamera.setAccessCameraFileState(state)
    }

    fun formatSdCard(): Long {
        return instaCamera.ersaSDcard()
    }

    fun formatStorage(location: Int): Long {
        return instaCamera.formatStorage(FormatStorage().apply {
            this.location = CardLocation.fromValue(location) ?: CardLocation.STOR_CL_CAMERA
        })
    }

    fun setMainStorage(location: Int): Long {
        return instaCamera.setMainStorage(CardLocation.fromValue(location) ?: CardLocation.STOR_CL_CAMERA_INNER)
    }

    fun shutdown() {
        instaCamera.setShutdown()
    }

    fun checkAuthorization(): Long {
        val initiatorType = when (platformType) {
            PlatformType.IOS -> CheckAuthorization.InitiatorType.PHONE_IOS
            else -> CheckAuthorization.InitiatorType.PHONE_ANDROID
        }
        val param = CheckAuthorization(
            id = getCustomizedDeviceID(),
            initiator_type = initiatorType,
        )
        val id = instaCamera.checkAuthorization(param)
        Logger.i(TAG, "checkAuthorization, id=${param.id}  initiatorType=$initiatorType  requestId=$id")
        return id
    }

    fun requestAuthorization(operationType: Int): Long {
        val id = instaCamera.requestAuthorization(operationType)
        Logger.i(TAG, "requestAuthorization, operationType=$operationType  requestId=$id")
        return id
    }

    fun cancelAuthorization(): Long {
        val id = instaCamera.cancelAuthorization()
        Logger.i(TAG, "cancelAuthorization, requestId=$id")
        return id
    }

    fun cancelRequestAuthorization(operationType: Int): Long {
        val id = instaCamera.cancelRequestAuthorization(operationType)
        Logger.i(TAG, "cancelRequestAuthorization, operationType=$operationType  requestId=$id")
        return id
    }
}