package com.arashivision.sdk.camera.api

import com.arashivision.sdk.common.callback.ProgressCallback

/**
 * 相机固件服务接口。
 *
 * 提供了获取当前相机固件版本以及执行固件升级操作的功能。
 */
interface CameraFirmware {
    /**
     * 获取当前相机的固件版本号。
     *
     * @return 返回包含固件版本号字符串的 [Result] 对象。
     */
    fun getVersion(): Result<String>

    /**
     * 执行相机固件升级（带有进度回调的接口方式）。
     *
     * 将本地的固件文件传输至相机并触发升级流程。
     *
     * @param filePath 本地固件文件的绝对路径。
     * @param callback 升级进度与结果的回调接口。进度值为 0.0 到 1.0 之间的浮点数。
     */
    fun upgradeFirmware(filePath: String, callback: ProgressCallback<Unit, Double>)

    /**
     * 执行相机固件升级（挂起函数）。
     *
     * 将本地的固件文件传输至相机并触发升级流程。
     *
     * @param filePath 本地固件文件的绝对路径。
     * @param progress 可选的升级进度回调函数，进度值为 0.0 到 1.0 之间的浮点数。
     * @return 返回升级结果的 [Result] 对象。
     */
    suspend fun upgradeFirmware(filePath: String, progress: ((Double) -> Unit)? = null): Result<Unit>
}