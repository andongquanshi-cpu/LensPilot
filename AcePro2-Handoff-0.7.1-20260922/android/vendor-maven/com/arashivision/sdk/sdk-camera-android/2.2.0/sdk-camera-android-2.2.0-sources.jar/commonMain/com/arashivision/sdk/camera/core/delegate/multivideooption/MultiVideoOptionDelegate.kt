package com.arashivision.sdk.camera.core.delegate.multivideooption

import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import insta360.messages.MultiPhotographyOptionsType

interface MultiVideoOptionDelegate {

    fun getMultiVideoResolution(functionMode: FunctionMode): Result<RecordResolution>
    suspend fun fetchMultiVideoResolution(functionMode: FunctionMode): Result<RecordResolution>
    suspend fun setMultiVideoResolution(functionMode: FunctionMode, recordResolution: RecordResolution): Result<Unit>

    fun getMultiVideoInternalFlowState(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchMultiVideoInternalFlowState(functionMode: FunctionMode): Result<Boolean>
    suspend fun setMultiVideoInternalFlowState(functionMode: FunctionMode, enable: Boolean): Result<Unit>

    suspend fun fetchMultiVideoOptions(functionMode: FunctionMode, multiVideoOptionsList: List<MultiPhotographyOptionsType>): Result<Unit>
    suspend fun fetchAllMultiVideoOptions(functionMode: FunctionMode): Result<Unit>
    suspend fun fetchAllMultiVideoOptions(): Result<Unit>

}