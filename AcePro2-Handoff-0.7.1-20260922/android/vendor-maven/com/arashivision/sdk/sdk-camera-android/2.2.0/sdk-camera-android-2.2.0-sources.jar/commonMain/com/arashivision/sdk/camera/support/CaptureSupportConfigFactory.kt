package com.arashivision.sdk.camera.support

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.support.device.AcePro2SupportConfig
import com.arashivision.sdk.camera.support.device.AceProSupportConfig
import com.arashivision.sdk.camera.support.device.AceSupportConfig
import com.arashivision.sdk.camera.support.device.Akiko577PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.Akiko577SingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.Go2SupportConfig
import com.arashivision.sdk.camera.support.device.Go3SSupportConfig
import com.arashivision.sdk.camera.support.device.Go3SupportConfig
import com.arashivision.sdk.camera.support.device.GoUltraSupportConfig
import com.arashivision.sdk.camera.support.device.NanoSSupportConfig
import com.arashivision.sdk.camera.support.device.OneRS283PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.OneRS283SingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.OneRS577PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.OneRS577SingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.OneX2PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.OneX2SingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.OneXSupportConfig
import com.arashivision.sdk.camera.support.device.SphereSupportConfig
import com.arashivision.sdk.camera.support.device.X3PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.X3SingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.X4AirPanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.X4AirSingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.X4PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.X4SingleLenSupportConfig
import com.arashivision.sdk.camera.support.device.X5PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.X5SingleLenSupportConfig
import com.arashivision.sdk.bridge.shared.preview.ICaptureSupportConfig
import insta360.messages.Sensor
import com.arashivision.sdk.camera.support.device.X6PanoramaSupportConfig
import com.arashivision.sdk.camera.support.device.X6SingleLenSupportConfig

object CaptureSupportConfigFactory {
    fun create(
        cameraConfig: ICameraConfig,
        snapshot: CameraRuntimeSnapshot,
    ): ICaptureSupportConfig {
        val cameraType = snapshot.cameraType
        return when (cameraType) {
            CameraType.ONE_R -> {
                if (snapshot.isPanoramaLens()) {
                    Akiko577PanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    Akiko577SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.GO_2 -> {
                Go2SupportConfig(cameraConfig, snapshot)
            }

            CameraType.GO_3 -> {
                Go3SupportConfig(cameraConfig, snapshot)
            }

            CameraType.GO_3S -> {
                Go3SSupportConfig(cameraConfig, snapshot)
            }

            CameraType.GO_ULTRA -> {
                GoUltraSupportConfig(cameraConfig, snapshot)
            }

            CameraType.ACE -> {
                AceSupportConfig(cameraConfig, snapshot)
            }

            CameraType.ACE_PRO -> {
                AceProSupportConfig(cameraConfig, snapshot)
            }

            CameraType.ACE_PRO_2 -> {
                AcePro2SupportConfig(cameraConfig, snapshot)
            }

            CameraType.ONE_RS -> {
                val is283 = isOneRs283Lens(snapshot)
                val isPano = snapshot.isPanoramaLens()
                when {
                    is283 && isPano -> OneRS283PanoramaSupportConfig(cameraConfig, snapshot)
                    is283 -> OneRS283SingleLenSupportConfig(cameraConfig, snapshot)
                    isPano -> OneRS577PanoramaSupportConfig(cameraConfig, snapshot)
                    else -> OneRS577SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.ONE_X -> {
                OneXSupportConfig(cameraConfig, snapshot)
            }

            CameraType.SPHERE -> {
                SphereSupportConfig(cameraConfig, snapshot)
            }

            CameraType.ONE_X2 -> {
                if (snapshot.isPanoramaLens()) {
                    OneX2PanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    OneX2SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.X3 -> {
                if (snapshot.isPanoramaLens()) {
                    X3PanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    X3SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.X4 -> {
                if (snapshot.isPanoramaLens()) {
                    X4PanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    X4SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.X4_AIR -> {
                if (snapshot.isPanoramaLens()) {
                    X4AirPanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    X4AirSingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.X5 -> {
                if (snapshot.isPanoramaLens()) {
                    X5PanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    X5SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            CameraType.X6 -> {
                if (snapshot.isPanoramaLens()) {
                    X6PanoramaSupportConfig(cameraConfig, snapshot)
                } else {
                    X6SingleLenSupportConfig(cameraConfig, snapshot)
                }
            }

            else -> {
                NanoSSupportConfig(cameraConfig, snapshot)
            }
        }
    }

    private fun isOneRs283Lens(snapshot: CameraRuntimeSnapshot): Boolean {
        val type = snapshot.sensorInfo?.type ?: return false
        return type == Sensor.Type.PANO_283 || type == Sensor.Type.WIDE_283
    }
}
