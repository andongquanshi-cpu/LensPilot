package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.notify.CameraPosture

/**
 * 相机姿态更新监听器。
 *
 * 用于在预览或拍摄过程中实时接收相机的空间姿态数据（如陀螺仪、加速度计数据）。
 */
interface CameraPostureUpdate {
    /**
     * 当相机姿态数据更新时回调。
     *
     * @param cameraPosture 包含相机当前姿态信息的对象。
     */
    fun updatePosture(cameraPosture: CameraPosture)
}
