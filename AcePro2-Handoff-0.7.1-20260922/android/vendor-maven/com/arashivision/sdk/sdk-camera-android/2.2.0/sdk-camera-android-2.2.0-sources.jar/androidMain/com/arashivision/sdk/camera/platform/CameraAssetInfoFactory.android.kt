package com.arashivision.sdk.camera.platform

import com.arashivision.graphicpath.render.base.LensType
import com.arashivision.graphicpath.render.source.AssetInfo
import com.arashivision.graphicpath.render.util.OffsetUtil
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import insta360.messages.WindowCropInfo

internal actual fun buildPreviewAssetInfo(request: CameraAssetInfoRequest): AssetInfo? =
    AssetInfo().apply {
        val actualOffset =
            request.mediaOffsetV6.ifEmpty { request.mediaOffsetV3.ifEmpty { request.mediaOffset } }
        isInsFormat = true
        isVideo = true
        offset = actualOffset
        isSelfie = request.isSelfie
        captureCameraName = request.cameraType.type
        cameraLensType = OffsetUtil.getLensType(actualOffset)
        isX3Selfie =
            request.functionMode == FunctionMode.VIDEO_BULLET_TIME || request.functionMode == FunctionMode.VIDEO_SELFIE

        when (request.cameraType) {
            CameraType.ONE_X -> applyOneXPanoramaDefaults()

            CameraType.ONE_X2 -> applyOneX2Defaults(request)

            CameraType.ONE_R -> applyAkikoDefaults(request)

            CameraType.ONE_RS -> applyOneRsDefaults(request)

            CameraType.SPHERE -> applyAkikoPanoramaDefaults()

            CameraType.X3 -> applyX3Defaults(request)

            CameraType.X4,
            CameraType.X4_AIR,
            CameraType.X5,
                -> applyModernPanoramaDefaults(request)

            CameraType.GO_2 -> applyGo2Defaults()

            CameraType.GO_3 -> applyGo3Defaults(request)

            CameraType.GO_3S -> applyGo3SDefaults(request)

            CameraType.GO_ULTRA -> applyGoUltraDefaults(request)

            CameraType.ACE,
            CameraType.ACE_PRO,
            CameraType.ACE_PRO_2,
                -> applyWindowCropWideAngleDefaults(request)

            CameraType.NANO_S -> applyNanoSPanoramaDefaults()

            else -> applyFallbackDefaults(request)
        }
    }

internal actual fun buildStabAssetInfo(request: CameraAssetInfoRequest): AssetInfo? =
    buildPreviewAssetInfo(request)?.apply {
        if (shouldUseHalfWindowCropInfoForStab(request)) {
            request.halfWindowCropInfo?.let(::applyCropInfo)
        }
    }

private fun AssetInfo.applyOneXPanoramaDefaults() {
    cropWindowSrcWidth = 3040
    cropWindowSrcHeight = 3040
    cropWindowDstWidth = 2880
    cropWindowDstHeight = 2880
    cameraLensCount = 2
    cameraLensType = LensType.ONEX
}

private fun AssetInfo.applyOneX2Defaults(request: CameraAssetInfoRequest) {
    cropWindowSrcWidth = 3040
    cropWindowSrcHeight = 3040
    cropWindowDstWidth = 2880
    cropWindowDstHeight = 2880
    cameraLensCount = if (looksSingleLens(request) && !request.isSelfie) 1 else 2
    cameraLensType = LensType.ONEX2
}

private fun AssetInfo.applyOneRsDefaults(request: CameraAssetInfoRequest) {
    val srcWidth = request.windowCropInfo?.src_width ?: inferOneRsSourceWidth(request)
    val srcHeight = request.windowCropInfo?.src_height ?: inferOneRsSourceHeight(srcWidth)
    cropWindowSrcWidth = srcWidth
    cropWindowSrcHeight = srcHeight

    when {
        looksSingleLens(request) && srcWidth >= 5000 -> {
            isFisheye3dFormat = true
            cameraLensCount = 1
            cameraLensType = LensType.ONER_WIDEANGLE_283
            applyOneRs283SingleLensCrop(request)
        }

        looksSingleLens(request) -> {
            isFisheye3dFormat = true
            cameraLensCount = 1
            cameraLensType = LensType.ONER_WIDEANGLE_577
            applyOneRs577SingleLensCrop(request)
        }

        srcWidth >= 3200 -> {
            cameraLensCount = 2
            cameraLensType = LensType.ONERS_FISHEYE283
            applyOneRs283PanoramaCrop(request)
        }

        else -> {
            cameraLensCount = 2
            cameraLensType = LensType.ONER_FISHEYE_577
            cropWindowDstWidth = 2880
            cropWindowDstHeight = 2880
        }
    }
}

private fun AssetInfo.applyX3Defaults(request: CameraAssetInfoRequest) {
    if (looksSingleLens(request)) {
        cropWindowSrcWidth = 5952
        cropWindowSrcHeight = 5952
        when {
            isPortraitFourThree(request.previewWidth, request.previewHeight) -> {
                cropWindowDstWidth = 3584
                cropWindowDstHeight = 2400
                cropOffsetX = 0
                cropOffsetY = 1600
            }

            isVerticalOrHorizontalTwoToOne(
                request.previewWidth,
                request.previewHeight,
            ) || isFourToOne(request.previewWidth, request.previewHeight) -> {
                cropWindowDstWidth = 5760
                cropWindowDstHeight = 2880
                cropOffsetX = 0
                cropOffsetY = 1360
            }

            else -> {
                cropWindowDstWidth = 5952
                cropWindowDstHeight = 5952
            }
        }
        cameraLensCount = if (request.functionMode == FunctionMode.VIDEO_SELFIE) 2 else 1
        cameraLensType = LensType.ONERS_FISHEYE283
    } else {
        cropWindowSrcWidth = 5952
        cropWindowSrcHeight = 5952
        cropWindowDstWidth = 5760
        cropWindowDstHeight = 5760
        cameraLensCount = 2
        cameraLensType = LensType.ONERS_FISHEYE283
    }
}

private fun AssetInfo.applyModernPanoramaDefaults(request: CameraAssetInfoRequest) {
    request.windowCropInfo?.let {
        applyCropInfo(it)
    } ?: run {
        applyFallbackCropByPreview(request)
    }
    cameraLensCount =
        if (looksSingleLens(request) && request.functionMode != FunctionMode.VIDEO_SELFIE) 1 else 2
    cameraLensType = LensType.ONERS_FISHEYE283
}

private fun AssetInfo.applyAkikoSingleLensDefaults(request: CameraAssetInfoRequest) {
    cropWindowSrcWidth = 4056
    cropWindowSrcHeight = 3040
    when {
        isFourThree(request.previewWidth, request.previewHeight) -> {
            cropWindowDstWidth = 4000
            cropWindowDstHeight = 3000
        }

        request.previewFps in listOf(24, 25, 30) -> {
            cropWindowDstWidth = 4000
            cropWindowDstHeight = 3000
        }

        request.previewFps == 100 -> {
            cropWindowDstWidth = 3136
            cropWindowDstHeight = 1764
        }

        else -> {
            cropWindowDstWidth = 3840
            cropWindowDstHeight = 2160
        }
    }
    isFisheye3dFormat = true
    cameraLensCount = 1
    cameraLensType = LensType.ONER_WIDEANGLE_577
}

private fun AssetInfo.applyAkikoPanoramaDefaults() {
    cropWindowSrcWidth = 3040
    cropWindowSrcHeight = 3040
    cropWindowDstWidth = 2880
    cropWindowDstHeight = 2880
    cameraLensCount = 2
    cameraLensType = LensType.ONER_FISHEYE_577
}

private fun AssetInfo.applyAkikoDefaults(request: CameraAssetInfoRequest) {
    if (looksSingleLens(request)) {
        applyAkikoSingleLensDefaults(request)
    } else {
        applyAkikoPanoramaDefaults()
    }
}

private fun AssetInfo.applyNanoSPanoramaDefaults() {
    cropWindowSrcWidth = 3040
    cropWindowSrcHeight = 3040
    cropWindowDstWidth = 2880
    cropWindowDstHeight = 2880
    cameraLensCount = 2
    cameraLensType = LensType.ONEX
}

private fun AssetInfo.applyGo2Defaults() {
    cropWindowSrcWidth = 3040
    cropWindowSrcHeight = 3040
    cropWindowDstWidth = 3008
    cropWindowDstHeight = 3008
    isFisheye3dFormat = true
    cameraLensCount = 1
    cameraLensType = LensType.GO2
}

private fun AssetInfo.applyGo3Defaults(request: CameraAssetInfoRequest) {
    cropWindowSrcWidth = 3040
    cropWindowSrcHeight = 3040
    if (request.functionMode == FunctionMode.VIDEO_BULLET_TIME) {
        cropWindowDstWidth = 2304
        cropWindowDstHeight = 1296
    } else {
        cropWindowDstWidth = 2688
        cropWindowDstHeight = 2688
    }
    isFisheye3dFormat = true
    cameraLensCount = 1
    cameraLensType = LensType.TC1
}

private fun AssetInfo.applyGo3SDefaults(request: CameraAssetInfoRequest) {
    request.windowCropInfo?.let(::applyCropInfo) ?: run {
        cropWindowSrcWidth = 4056
        cropWindowSrcHeight = 3040
        when {
            request.functionMode == FunctionMode.VIDEO_BULLET_TIME &&
                    request.previewWidth == 2720 &&
                    request.previewHeight == 1530 &&
                    request.previewFps == 100 -> {
                cropWindowDstWidth = 3008
                cropWindowDstHeight = 1692
            }

            request.functionMode == FunctionMode.VIDEO_BULLET_TIME &&
                    request.previewWidth == 1920 &&
                    request.previewHeight == 1080 &&
                    request.previewFps in listOf(120, 200) -> {
                // Without FOV input, prefer the wider akiko crop branch.
                cropWindowDstWidth = 3840
                cropWindowDstHeight = 2160
            }

            request.previewFps == 50 -> {
                cropWindowDstWidth = 3712
                cropWindowDstHeight = 2784
            }

            else -> {
                cropWindowDstWidth = 3968
                cropWindowDstHeight = 2976
            }
        }
    }
    isFisheye3dFormat = true
    cameraLensCount = 1
}

private fun AssetInfo.applyWindowCropWideAngleDefaults(request: CameraAssetInfoRequest) {
    request.windowCropInfo?.let(::applyCropInfo) ?: applyFallbackCropByPreview(request)
    isFisheye3dFormat = true
    cameraLensCount = 1
}

private fun AssetInfo.applyGoUltraDefaults(request: CameraAssetInfoRequest) {
    applyWindowCropWideAngleDefaults(request)
    cameraLensType = LensType.AKIKO_WIDEANGLE_586
}

private fun AssetInfo.applyFallbackDefaults(request: CameraAssetInfoRequest) {
    applyFallbackCropByPreview(request)
    cameraLensCount =
        if (looksSingleLens(request) && request.functionMode != FunctionMode.VIDEO_SELFIE) 1 else 2
}

private fun AssetInfo.applyFallbackCropByPreview(request: CameraAssetInfoRequest) {
    cropWindowSrcWidth = request.previewWidth.coerceAtLeast(1)
    cropWindowSrcHeight = request.previewHeight.coerceAtLeast(1)
    cropWindowDstWidth = cropWindowSrcWidth
    cropWindowDstHeight = cropWindowSrcHeight
}

private fun AssetInfo.applyOneRs577SingleLensCrop(request: CameraAssetInfoRequest) {
    when {
        isFourThree(request.previewWidth, request.previewHeight) -> {
            cropWindowDstWidth = 4000
            cropWindowDstHeight = 3000
        }

        request.previewFps in listOf(24, 25, 30) -> {
            cropWindowDstWidth = 4000
            cropWindowDstHeight = 3000
        }

        request.previewFps == 100 -> {
            cropWindowDstWidth = 3136
            cropWindowDstHeight = 1764
        }

        else -> {
            cropWindowDstWidth = 3840
            cropWindowDstHeight = 2160
        }
    }
}

private fun AssetInfo.applyOneRs283SingleLensCrop(request: CameraAssetInfoRequest) {
    when {
        isFourThree(request.previewWidth, request.previewHeight) -> {
            cropWindowDstWidth = 5280
            cropWindowDstHeight = 3960
        }

        request.previewFps in listOf(24, 25, 30) -> {
            cropWindowDstWidth = 5312
            cropWindowDstHeight = 2988
        }

        request.previewFps == 100 -> {
            cropWindowDstWidth = 3840
            cropWindowDstHeight = 2160
        }

        else -> {
            cropWindowDstWidth = 3840
            cropWindowDstHeight = 2160
        }
    }
}

private fun AssetInfo.applyOneRs283PanoramaCrop(request: CameraAssetInfoRequest) {
    when {
        request.previewWidth == 1440 && request.previewHeight == 720 -> {
            cropWindowDstWidth = 3264
            cropWindowDstHeight = 3264
        }

        isVerticalOrHorizontalTwoToOne(
            request.previewWidth,
            request.previewHeight,
        ) || request.previewWidth == 3040 && request.previewHeight == 1520 -> {
            cropWindowDstWidth = 3328
            cropWindowDstHeight = 3328
        }

        request.previewWidth == 5888 && request.previewHeight == 2880 -> {
            cropWindowDstWidth = 3136
            cropWindowDstHeight = 3072
        }

        else -> {
            cropWindowDstWidth = 3200
            cropWindowDstHeight = 3200
        }
    }
}

private fun inferOneRsSourceWidth(request: CameraAssetInfoRequest): Int =
    when {
        looksSingleLens(request) && isFourThree(request.previewWidth, request.previewHeight) -> 5312
        looksSingleLens(request) -> 4056
        else -> 3264
    }

private fun inferOneRsSourceHeight(srcWidth: Int): Int =
    when (srcWidth) {
        5312 -> 2988
        4056 -> 3040
        else -> 3264
    }

private fun looksSingleLens(request: CameraAssetInfoRequest): Boolean =
    !isVerticalOrHorizontalTwoToOne(request.previewWidth, request.previewHeight) &&
            !isFourToOne(request.previewWidth, request.previewHeight) &&
            !isSquare(request.previewWidth, request.previewHeight)

private fun isSquare(
    width: Int,
    height: Int,
): Boolean = width > 0 && width == height

private fun isFourToOne(
    width: Int,
    height: Int,
): Boolean = width > 0 && height > 0 && width * 1 == height * 4

private fun isFourThree(
    width: Int,
    height: Int,
): Boolean = width > 0 && height > 0 && width * 3 == height * 4

private fun isPortraitFourThree(
    width: Int,
    height: Int,
): Boolean = width > 0 && height > 0 && width * 4 == height * 3

private fun isVerticalOrHorizontalTwoToOne(
    width: Int,
    height: Int,
): Boolean = width > 0 && height > 0 && (width == height * 2 || height == width * 2)

private fun shouldUseHalfWindowCropInfoForStab(request: CameraAssetInfoRequest): Boolean {
    if (request.cameraType !in listOf(CameraType.X4, CameraType.X4_AIR, CameraType.X5)) {
        return false
    }
    return request.functionMode == FunctionMode.VIDEO_BULLET_TIME ||
            request.functionMode == FunctionMode.VIDEO_SELFIE
}

private fun AssetInfo.applyCropInfo(cropInfo: WindowCropInfo) {
    cropWindowSrcWidth = cropInfo.src_width
    cropWindowSrcHeight = cropInfo.src_height
    cropWindowDstWidth = cropInfo.dst_width
    cropWindowDstHeight = cropInfo.dst_height
    cropOffsetX = cropInfo.crop_offset_x
    cropOffsetY = cropInfo.crop_offset_y
}
