package com.arashivision.sdk.camera.core.delegate.option

import com.arashivision.sdk.camera.core.DeviceContext
import com.arashivision.sdk.camera.core.delegate.BaseDelegate
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.option.BatteryData
import com.arashivision.sdk.camera.core.model.option.ChargeBoxData
import com.arashivision.sdk.camera.core.model.option.ExpectOutputType
import com.arashivision.sdk.camera.core.model.option.FocusSensor
import com.arashivision.sdk.camera.core.model.option.LanguageType
import com.arashivision.sdk.camera.core.model.option.LocalTime
import com.arashivision.sdk.camera.core.model.option.PhotoSubMode
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.VideoEncode
import com.arashivision.sdk.camera.core.model.option.VideoSubMode
import com.arashivision.sdk.camera.core.model.option.WiFiChannel
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.camera.core.model.photography.LensAccessoryType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.common.callback.CoroutineCallback
import com.arashivision.sdk.common.callback.coroutineCallback
import com.arashivision.sdk.common.exception.CameraNotConnectedException
import com.arashivision.sdk.common.exception.OptionValueNullException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import insta360.messages.OffsetDetectedType
import insta360.messages.OffsetState
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.Sensor
import insta360.messages.WindowCropInfo
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

class OptionDelegateImpl(deviceContext: DeviceContext) : BaseDelegate(deviceContext), OptionDelegate {
    companion object {
        private const val TAG = "OptionDelegateImpl"
    }

    private var optionCallbackMap: MutableMap<Long, CoroutineCallback<Options>> = mutableMapOf()
    private val optionCallbackMutex = Mutex()
    private var callbackMap: MutableMap<Long, CoroutineCallback<Unit>> = mutableMapOf()
    private val callbackMutex = Mutex()

    private val optionCacheMutex = Mutex()
    private var optionCache: MutableMap<OptionType, Any?> = mutableMapOf()
    private var halfWindowCropInfo: WindowCropInfo? = null

    override fun init() {
        context.scope.launch {
            context.transport.events.collect {
                when (it) {
                    //get option
                    is TransportEvent.GetOptionEvent.Success -> {
                        optionCallbackMutex.withLock { optionCallbackMap.remove(it.requestId) }?.onSuccess(it.options)
                    }

                    is TransportEvent.GetOptionEvent.Failed -> {
                        optionCallbackMutex.withLock { optionCallbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    //set option
                    is TransportEvent.SetOptionEvent.Success -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onSuccess(Unit)
                    }

                    is TransportEvent.SetOptionEvent.Failed -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    else -> {}
                }
            }
        }
    }

    override suspend fun release() {
        callbackMutex.withLock { callbackMap.clear() }
        optionCallbackMutex.withLock { optionCallbackMap.clear() }
    }

    private fun <T> requiredOption(optionType: OptionType): Result<T> = getOption<T>(optionType)?.success() ?: Result.failure(OptionValueNullException(optionType.toString()))

    override fun getBatteryData(): Result<BatteryData> = requiredOption(OptionType.BATTERY_INFO)
    override suspend fun fetchBatteryData(): Result<BatteryData> = fetchOption(OptionType.BATTERY_INFO)

    override fun getChargeBoxData(): Result<ChargeBoxData> = requiredOption(OptionType.CHARGEBOX_CONNECTED_STATUS)
    override suspend fun fetchChargeBoxData(): Result<ChargeBoxData> = fetchOption(OptionType.CHARGEBOX_CONNECTED_STATUS)

    override fun getMute(): Result<Boolean> {
        val mute: Result<Boolean> = requiredOption(OptionType.MUTE)
        return if (context.cameraConfig?.muteNegate() == true) mute.map { !it } else mute
    }

    override suspend fun fetchMute(): Result<Boolean> {
        val mute: Result<Boolean> = fetchOption(OptionType.MUTE)
        return if (context.cameraConfig?.muteNegate() == true) mute.map { !it } else mute
    }

    override suspend fun setMute(mute: Boolean): Result<Unit> =
        setOption(OptionType.MUTE, if (context.cameraConfig?.muteNegate() == true) !mute else mute)

    override fun getSerialNumber(): Result<String> = requiredOption(OptionType.SERIAL_NUMBER)
    override suspend fun fetchSerialNumber(): Result<String> = fetchOption(OptionType.SERIAL_NUMBER)

    override fun getUuid(): Result<String> = requiredOption(OptionType.UUID)
    override suspend fun fetchUuid(): Result<String> = fetchOption(OptionType.UUID)

    override fun getOriginOffset(): Result<String> = requiredOption(OptionType.ORIGIN_OFFSET)
    override suspend fun fetchOriginOffset(): Result<String> = fetchOption(OptionType.ORIGIN_OFFSET)

    override fun getActivateTime(): Result<Long> = requiredOption(OptionType.ACTIVATE_TIME)
    override suspend fun fetchActivateTime(): Result<Long> = fetchOption(OptionType.ACTIVATE_TIME)
    override suspend fun setActivateTime(activeTime: Long): Result<Unit> = setOption(OptionType.ACTIVATE_TIME, activeTime)

    override fun getStorageData(): Result<StorageData> = requiredOption(OptionType.STORAGE_STATE)
    override suspend fun fetchStorageData(): Result<StorageData> = fetchOption(OptionType.STORAGE_STATE)

    override fun getStorageDataList(): Result<List<StorageData>> {
        return if (context.cameraConfig?.supportInnerStorage() == true) {
            requiredOption(OptionType.STORAGE_STATE_LIST)
        } else {
            val storageDataResult: Result<StorageData> = requiredOption(OptionType.STORAGE_STATE)
            storageDataResult.map { listOf(it) }
        }
    }

    override suspend fun fetchStorageDataList(): Result<List<StorageData>> {
        return if (context.cameraConfig?.supportInnerStorage() == true) {
            fetchOption(OptionType.STORAGE_STATE_LIST)
        } else {
            val storageDataResult: Result<StorageData> = fetchOption(OptionType.STORAGE_STATE)
            storageDataResult.map { listOf(it) }
        }
    }

    override fun getMediaOffset(): Result<String> = requiredOption(OptionType.MEDIA_OFFSET)
    override suspend fun fetchMediaOffset(): Result<String> = fetchOption(OptionType.MEDIA_OFFSET)

    override fun getFirmwareRevision(): Result<String> = requiredOption(OptionType.FIRMWAREREVISION)
    override suspend fun fetchFirmwareRevision(): Result<String> = fetchOption(OptionType.FIRMWAREREVISION)

    override fun getWiFiData(): Result<WiFiData> = requiredOption(OptionType.WIFI_INFO)
    override suspend fun fetchWiFiData(): Result<WiFiData> = fetchOption(OptionType.WIFI_INFO)

    override fun getWiFiChannelList(): Result<WiFiChannel> = requiredOption(OptionType.WIFI_CHANNEL_LIST)
    override suspend fun fetchWiFiChannelList(): Result<WiFiChannel> = fetchOption(OptionType.WIFI_CHANNEL_LIST)

    override suspend fun setWiFiCountry(countryCode: String): Result<Unit> = setOption(OptionType.WIFI_CHANNEL_LIST, WiFiChannel(countryCode, listOf()))

    override fun getPhotoSubMode(): Result<PhotoSubMode> = requiredOption(OptionType.PHOTO_SUB_MODE)
    override suspend fun fetchPhotoSubMode(): Result<PhotoSubMode> = fetchOption(OptionType.PHOTO_SUB_MODE)
    override suspend fun setPhotoSubMode(photoSubMode: PhotoSubMode): Result<Unit> = setOption(OptionType.PHOTO_SUB_MODE, photoSubMode)

    override fun getVideoSubMode(): Result<VideoSubMode> = requiredOption(OptionType.VIDEO_SUB_MODE)
    override suspend fun fetchVideoSubMode(): Result<VideoSubMode> = fetchOption(OptionType.VIDEO_SUB_MODE)
    override suspend fun setVideoSubMode(videoSubMode: VideoSubMode): Result<Unit> = setOption(OptionType.VIDEO_SUB_MODE, videoSubMode)

    override fun getCameraType(): Result<CameraType> = requiredOption(OptionType.CAMERA_TYPE)
    override suspend fun fetchCameraType(): Result<CameraType> = fetchOption(OptionType.CAMERA_TYPE)

    override fun getVideoEncodeType(): Result<VideoEncode> = requiredOption(OptionType.VIDEO_ENCODE_TYPE)
    override suspend fun fetchVideoEncodeType(): Result<VideoEncode> = fetchOption(OptionType.VIDEO_ENCODE_TYPE)
    override suspend fun setVideoEncodeType(videoEncode: VideoEncode): Result<Unit> = setOption(OptionType.VIDEO_ENCODE_TYPE, videoEncode)

    override fun getIsSelfie(): Result<Boolean> = requiredOption(OptionType.IS_SELFIE)
    override suspend fun fetchIsSelfie(): Result<Boolean> = fetchOption(OptionType.IS_SELFIE)

    override fun getOriginOffsetV2(): Result<String> = requiredOption(OptionType.ORIGIN_OFFSET_V2)
    override suspend fun fetchOriginOffsetV2(): Result<String> = fetchOption(OptionType.ORIGIN_OFFSET_V2)

    override fun getOriginOffsetV3(): Result<String> = requiredOption(OptionType.ORIGIN_OFFSET_V3)
    override suspend fun fetchOriginOffsetV3(): Result<String> = fetchOption(OptionType.ORIGIN_OFFSET_V3)

    override fun getMediaOffsetV2(): Result<String> = requiredOption(OptionType.MEDIA_OFFSET_V2)
    override suspend fun fetchMediaOffsetV2(): Result<String> = fetchOption(OptionType.MEDIA_OFFSET_V2)

    override fun getMediaOffsetV3(): Result<String> = requiredOption(OptionType.MEDIA_OFFSET_V3)
    override suspend fun fetchMediaOffsetV3(): Result<String> = fetchOption(OptionType.MEDIA_OFFSET_V3)

    override fun getMediaOffsetV6(): Result<String> = requiredOption(OptionType.MEDIA_OFFSET_V6)
    override suspend fun fetchMediaOffsetV6(): Result<String> = fetchOption(OptionType.MEDIA_OFFSET_V6)
    override fun getWindowCropInfo(): Result<WindowCropInfo> = requiredOption(OptionType.WINDOW_CROP_INFO)

    override fun getSensorInfo(): Result<Sensor> = requiredOption(OptionType.SENSOR_INFO)

    override fun getHalfWindowCropInfo(): Result<WindowCropInfo> =
        halfWindowCropInfo?.success() ?: Result.failure(OptionValueNullException("HALF_WINDOW_CROP_INFO"))

    override fun getOffsetState(): Result<OffsetState> = requiredOption(OptionType.OFFSET_STATES)
    override suspend fun fetchOffsetState(): Result<OffsetState> = fetchOption(OptionType.OFFSET_STATES)

    override fun getOffsetDetectedType(): Result<OffsetDetectedType> = requiredOption(OptionType.OFFSET_DETECTED_TYPE)
    override suspend fun fetchOffsetDetectedType(): Result<OffsetDetectedType> = fetchOption(OptionType.OFFSET_DETECTED_TYPE)

    override fun getCameraLanguage(): Result<LanguageType> = requiredOption(OptionType.CAMERA_LANGUAGE)
    override suspend fun fetchCameraLanguage(): Result<LanguageType> = fetchOption(OptionType.CAMERA_LANGUAGE)
    override suspend fun setCameraLanguage(languageType: LanguageType): Result<Unit> = setOption(OptionType.CAMERA_LANGUAGE, languageType)

    override suspend fun setLocalTime(localTime: LocalTime): Result<Unit> =
        setOptions(mapOf(OptionType.LOCAL_TIME to localTime.timestamp, OptionType.TIME_ZONE to localTime.timeZone))

    override fun getAssistiveGridEnable(): Result<Boolean> = requiredOption(OptionType.ASSISTIVE_GRID)
    override suspend fun fetchAssistiveGridEnable(): Result<Boolean> = fetchOption(OptionType.ASSISTIVE_GRID)
    override suspend fun setAssistiveGridEnable(enable: Boolean): Result<Unit> = setOption(OptionType.ASSISTIVE_GRID, enable)

    override fun getFreeFrameGridEnable(): Result<Boolean> = requiredOption(OptionType.FREEFRAME_GRID)
    override suspend fun fetchFreeFrameGridEnable(): Result<Boolean> = fetchOption(OptionType.FREEFRAME_GRID)
    override suspend fun setFreeFrameGridEnable(enable: Boolean): Result<Unit> = setOption(OptionType.FREEFRAME_GRID, enable)

    override fun getVideoResolution(): Result<RecordResolution> = requiredOption(OptionType.VIDEO_RESOLUTION)
    override suspend fun fetchVideoResolution(): Result<RecordResolution> = fetchOption(OptionType.VIDEO_RESOLUTION)
    override suspend fun setVideoResolution(recordResolution: RecordResolution) = setOption(OptionType.VIDEO_RESOLUTION, recordResolution)

    override fun getVideoBitrate(): Result<Int> = requiredOption(OptionType.VIDEO_BITRATE)
    override suspend fun fetchVideoBitrate(): Result<Int> = fetchOption(OptionType.VIDEO_BITRATE)
    override suspend fun setVideoBitrate(bitrate: Int): Result<Unit> = setOption(OptionType.VIDEO_BITRATE, bitrate)

    override fun getInternalSplicingEnable(): Result<Boolean> = requiredOption(OptionType.INTERNAL_SPLICING)
    override suspend fun fetchInternalSplicingEnable(): Result<Boolean> = fetchOption(OptionType.INTERNAL_SPLICING)
    override suspend fun setInternalSplicingEnable(enable: Boolean): Result<Unit> = setOption(OptionType.INTERNAL_SPLICING, enable)

    override fun getFocusSensor(): Result<FocusSensor> = requiredOption(OptionType.INSTAPANO_FOCUS_SENSOR)
    override suspend fun fetchFocusSensor(): Result<FocusSensor> = fetchOption(OptionType.INSTAPANO_FOCUS_SENSOR)
    override suspend fun setFocusSensor(focusSensor: FocusSensor): Result<Unit> = setOption(OptionType.INSTAPANO_FOCUS_SENSOR, focusSensor)

    override fun getMediaTime(): Result<Long> = requiredOption(OptionType.MEDIA_TIME)
    override suspend fun fetchMediaTime(): Result<Long> = fetchOption(OptionType.MEDIA_TIME)

    override fun getExpectOutputType(): Result<ExpectOutputType> = requiredOption(OptionType.EXPECT_OUTPUT_TYPE)
    override suspend fun fetchExpectOutputType(): Result<ExpectOutputType> = fetchOption(OptionType.EXPECT_OUTPUT_TYPE)
    override suspend fun setExpectOutputType(expectOutputType: ExpectOutputType): Result<Unit> = setOption(OptionType.EXPECT_OUTPUT_TYPE, expectOutputType)

    override fun getDarkEisGlobalEnable(): Result<Boolean> = requiredOption(OptionType.DARK_EIS_ENABLE_GLOBAL)
    override suspend fun fetchDarkEisGlobalEnable(): Result<Boolean> = fetchOption(OptionType.DARK_EIS_ENABLE_GLOBAL)
    override suspend fun setDarkEisGlobalEnable(enable: Boolean): Result<Unit> = setOption(OptionType.DARK_EIS_ENABLE_GLOBAL, enable)

    override fun getSharpness(): Result<Int> = requiredOption(OptionType.SHARPNESS_GLOBAL)
    override suspend fun fetchSharpness(): Result<Int> = fetchOption(OptionType.SHARPNESS_GLOBAL)
    override suspend fun setSharpness(sharpness: Int): Result<Unit> = setOption(OptionType.SHARPNESS_GLOBAL, sharpness)

    override fun getRollingShutterTime(): Result<Double> = requiredOption(OptionType.ROLLING_SHUTTER_TIME)
    override suspend fun fetchRollingShutterTime(): Result<Double> = fetchOption(OptionType.ROLLING_SHUTTER_TIME)

    override fun getLensAccessoryInfo(functionMode: FunctionMode): Result<LensAccessoryType> {
        return requiredOption(OptionType.LENS_ACCESSORIES_INFO)
    }

    override suspend fun fetchLensAccessoryInfo(functionMode: FunctionMode): Result<LensAccessoryType> {
        return fetchOption(OptionType.LENS_ACCESSORIES_INFO)
    }

    override suspend fun setLensAccessoryInfo(
        functionMode: FunctionMode,
        lensAccessoryType: LensAccessoryType
    ): Result<Unit> {
        return setOption(OptionType.LENS_ACCESSORIES_INFO, lensAccessoryType)
    }


    @Suppress("UNCHECKED_CAST")
    private fun <T> getOption(optionType: OptionType): T? {
        return OptionMapper.optionTransform(optionType, optionCache) as? T
    }

    override suspend fun fetchAllOptions(): Result<Unit> {
        return context.cameraConfig?.getSyncOptionsGroups()?.let {
            it.asFlow().map { group -> fetchOptions(group) }.filter { result -> result.isFailure }.lastOrNull() ?: Unit.success()
        } ?: Result.failure(CameraNotConnectedException())
    }

    override suspend fun fetchOptions(optionList: List<OptionType>, retryCount: Int, timeoutMs: Int): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            Logger.d(TAG, "fetchOptions ==>$optionList")
            val call = coroutineCallback {
                success {
                    if (continuation.isActive) {
                        val newCache = OptionMapper.options2Map(optionList, it)
                        optionCacheMutex.withLock { optionCache.putAll(newCache) }
                        continuation.resume(Result.success(Unit))
                    }
                }
                throwable {
                    if (continuation.isActive) {
                        continuation.resume(Result.failure(it))
                    }
                }
            }
            val id = context.transport.getOptions(optionList, retryCount, timeoutMs)
            context.scope.launch {
                optionCallbackMutex.withLock {
                    optionCallbackMap[id] = call
                }
            }
        }
    }

    private suspend fun <T> fetchOption(optionType: OptionType): Result<T> {
        return fetchOptions(listOf(optionType)).flatMap {
            requiredOption(optionType)
        }
    }

    private suspend fun <T> setOption(optionType: OptionType, data: T): Result<Unit> {
        val mapTransform = OptionMapper.mapTransform(optionType, data as Any)
        return setOptions(mapTransform)
    }

    private suspend fun setOptions(options: Map<OptionType, Any>): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = coroutineCallback<Unit> {
                success {
                    if (continuation.isActive) {
                        optionCacheMutex.withLock { optionCache.putAll(options) }
                        continuation.resume(Unit.success())
                    }
                }
                throwable {
                    if (continuation.isActive) {
                        continuation.resume(it.failure())
                    }
                }
            }
            val id = context.transport.setOptions(options.keys.toList(), OptionMapper.map2Options(options))
            context.scope.launch {
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }


    internal suspend fun updateOptionCache(optionType: OptionType, data: Any) {
        optionCacheMutex.withLock {
            optionCache.put(optionType, data)
        }
    }

    internal suspend fun updateHalfWindowCropInfo(windowCropInfo: WindowCropInfo?) {
        optionCacheMutex.withLock {
            halfWindowCropInfo = windowCropInfo
        }
    }
}