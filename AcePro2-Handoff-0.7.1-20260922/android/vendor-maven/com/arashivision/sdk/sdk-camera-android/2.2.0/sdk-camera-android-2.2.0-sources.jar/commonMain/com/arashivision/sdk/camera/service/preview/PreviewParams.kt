package com.arashivision.sdk.camera.service.preview

import com.arashivision.sdk.camera.core.model.photography.StreamResolution

class PreviewParams(
    var firstStream: StreamResolution,
    var secondStream: StreamResolution,
    var previewNum: Int
)


