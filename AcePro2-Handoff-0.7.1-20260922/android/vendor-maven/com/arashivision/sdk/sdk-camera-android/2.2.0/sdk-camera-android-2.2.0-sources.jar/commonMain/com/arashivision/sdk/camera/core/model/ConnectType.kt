package com.arashivision.sdk.camera.core.model

/**
 * 连接类型，统一对齐 BLE / Wi‑Fi / USB 三种通道。
 */
enum class ConnectType {
    BLE,
    WIFI,
    USB,
    WIFI_AWARE
}