package com.arashivision.sdk.camera.core.event

import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.capture.CameraCaptureStatus
import com.arashivision.sdk.camera.core.model.notify.TempState
import com.arashivision.sdk.camera.core.model.option.BatteryData
import com.arashivision.sdk.camera.core.model.option.ChargeBoxData
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.service.preview.PreviewStatus
import insta360.messages.NotificationCameraPostureUpdate
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationOperationType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationResult

sealed interface DeviceEvent {

    /**
     * 断连事件
     */
    data class ConnectedEvent(val connectType: ConnectType) : DeviceEvent

    /**
     * 断连事件
     */
    data class DisconnectedEvent(val connectType: ConnectType, val throwable: Throwable? = null) : DeviceEvent

    /**
     *  低电量事件
     */
    object BatteryLowEvent : DeviceEvent

    /**
     * 电池信息事件
     */
    data class BatteryUpdateEvent(val batteryData: BatteryData) : DeviceEvent

    /**
     * 盒子电池信息更新事件
     */
    data class ChargeBoxUpdateEvent(val chargeBoxData: ChargeBoxData) : DeviceEvent

    /**
     * 温度事件
     */
    data class TemperatureEvent(val tempState: TempState) : DeviceEvent

    /**
     * 存储改变事件
     */
    data class StorageUpdateEvent(val storageDataList: List<StorageData>) : DeviceEvent

    /**
     *  拍摄状态改变事件
     */
    sealed interface CaptureStatusEvent : DeviceEvent {
        data class Starting(val functionMode: FunctionMode) : CaptureStatusEvent
        data class Working(val functionMode: FunctionMode) : CaptureStatusEvent
        data class Stopping(val functionMode: FunctionMode) : CaptureStatusEvent
        data class Error(val functionMode: FunctionMode, val throwable: Throwable) : CaptureStatusEvent
        data class Finished(val functionMode: FunctionMode, val filePaths: List<String>) : CaptureStatusEvent
        data class SubStatusChanged(val functionMode: FunctionMode, val subStatus: CameraCaptureStatus.SubStatus) : CaptureStatusEvent
    }

    /**
     * 路线时长事件
     */
    data class CaptureTimeChanged(val functionMode: FunctionMode, val captureTime: Long) : DeviceEvent

    /**
     * 拍照张数事件
     */
    data class CaptureCountChanged(val functionMode: FunctionMode, val captureCount: Int) : DeviceEvent

    /**
     * 预览开始旋转事件（设备侧通知）。
     */
    data class LiveViewBeginRotateEvent(val cameraPostureUpdate: NotificationCameraPostureUpdate) : DeviceEvent

    data class LiveStreamEvent(val status: PreviewStatus, val obj: Any? = null): DeviceEvent

    /**
     * 相机端授权操作结果事件，由 NOTIFY_AUTHORIZATION 推送触发。
     */
    data class AuthorizationResultEvent(
        val operationType: AuthorizationOperationType,
        val result: AuthorizationResult,
    ) : DeviceEvent
}