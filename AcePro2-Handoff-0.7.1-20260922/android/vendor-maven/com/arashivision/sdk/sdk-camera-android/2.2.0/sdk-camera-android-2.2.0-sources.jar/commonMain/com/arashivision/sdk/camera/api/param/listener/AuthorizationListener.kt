package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.authorization.AuthorizationOperationType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationResult

/**
 * 相机授权结果监听器。
 *
 * 用于监听相机端返回的授权操作结果（如用户在相机上确认或拒绝授权请求）。
 * 通过 [com.arashivision.sdk.camera.api.CameraDevice.registerAuthorizationListener] 注册。
 */
interface AuthorizationListener {

    /**
     * 当相机端返回授权操作结果时回调。
     *
     * @param operationType 触发此授权结果的操作类型。
     * @param result 授权操作的结果。
     */
    fun onAuthorizationResult(operationType: AuthorizationOperationType, result: AuthorizationResult)
}
