package com.arashivision.sdk.camera.core

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.sdk.camera.api.param.listener.BleWakeUpListener
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.callback.BleScanCallback
import com.arashivision.sdk.camera.core.delegate.capture.CaptureDelegate
import com.arashivision.sdk.camera.core.delegate.multivideooption.MultiVideoOptionDelegate
import com.arashivision.sdk.camera.core.delegate.option.OptionDelegate
import com.arashivision.sdk.camera.core.delegate.photography.PhotographyOptionDelegate
import com.arashivision.sdk.camera.core.delegate.stream.PreviewStreamDelegate
import com.arashivision.sdk.camera.core.delegate.timelapse.TimelapseOptionDelegate
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationOperationType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationStatus
import com.arashivision.sdk.camera.core.model.capture.LockScreenState
import com.arashivision.sdk.camera.core.model.file.CameraFileType
import com.arashivision.sdk.camera.core.model.file.FileInfo
import com.arashivision.sdk.camera.core.model.file.MediaFileType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.core.model.option.WiFiData
import com.arashivision.sdk.common.type.KMPBleDevice
import kotlinx.coroutines.flow.SharedFlow

interface DeviceCore : OptionDelegate, PhotographyOptionDelegate, TimelapseOptionDelegate, CaptureDelegate, PreviewStreamDelegate, MultiVideoOptionDelegate {

    val connectType: ConnectType

    val events: SharedFlow<DeviceEvent>

    val isConnected: Boolean

    fun init()

    suspend fun initAllOptions()

    fun scan(timeoutMs: Long, bleScanCallback: BleScanCallback)

    fun stopScan()

    fun bleWakeUp(cameraType: CameraType, deviceName: String, listener: BleWakeUpListener?)

    suspend fun connect(connectHint: Any? = null): Result<Unit>

    suspend fun connectBle(bleDeviceCore: BleDeviceCore): Result<Unit>
    suspend fun connectBle(kmpBleDevice: KMPBleDevice): Result<Unit>

    suspend fun connectWiFi(networkId: Int): Result<Unit>

    suspend fun connectWiFiAware(networkHandle: Long, peerIpv6: String): Result<Unit>

    suspend fun connectUsb(): Result<Unit>

    fun disconnect()

    fun getCameraConfig(): Result<ICameraConfig>

    suspend fun release()


    /**
     * 切换wifi信道
     * @param needScan 是否扫描
     * @param channel wifi信道
     */
    suspend fun switchWiFiChannel(needScan: Boolean, channel: Int): Result<Unit>

    /**
     * 指定信道重启Wi-Fi
     * @param channel wifi信道
     */
    suspend fun resetCameraWiFi(channel: Int = 0): Result<Unit>

    /**
     * 打开指定信道Wi-Fi
     * @param channel wifi信道
     */
    suspend fun openCameraWiFi(channel: Int = 0): Result<Unit>

    /**
     * 关闭相机Wi-Fi
     */
    suspend fun closeCameraWiFi(): Result<Unit>

    /**
     * 设置相机Wi-Fi模式（如切换到 Aware 模式）
     * @param mode 目标Wi-Fi模式
     * @param countryCode 国家码，空字符串表示不变更
     */
    suspend fun setWifiMode(mode: WiFiData.Mode, countryCode: String): Result<Unit>

    /**
     * 切换SensorMode
     */
    suspend fun setSensorMode(sensorMode: SensorMode): Result<Unit>

    /**
     * 获取SensorMode
     */
    suspend fun fetchSensorMode(): Result<SensorMode>

    /**
     * 获取媒体文件列表
     */
    suspend fun listMediaFiles(mediaFileType: MediaFileType, start: Int, limit: Int, includeRecording: Boolean = false): Result<Pair<List<String>, Int>>

    /**
     * 删除媒体文件
     */
    suspend fun deleteMediaFiles(uris: List<String>): Result<Unit>

    /**
     * 获取相机文件
     */
    suspend fun getCameraFile(cameraFileType: CameraFileType): Result<Pair<String, Int>>

    /**
     * 打包相机日志文件
     */
    suspend fun packLogFile(): Result<String>

    /**
     * 获取相机端点
     */
    fun getEndpoint(): String

    /**
     * SDK 内部构造下载/上传 URL 时使用的端点；WIFI_AWARE 连接下返回占位 hostname（配合
     * [com.arashivision.sdk.common.kotlin.DynamicHostResolver] 动态解析真实地址），
     * 其余连接类型与 [getEndpoint] 一致。不用于外部集成方直连场景。
     */
    fun getDownloadEndpoint(): String

    /**
     * 获取相机主机
     */
    fun getHost(): String

    /**
     * 获取相机端口
     */
    fun getProt(): Int

    /**
     * 获取相机端口
     */
    fun getSupportCameraType(): List<CameraType>

    /**
     * 设置GPS数据
     */
    fun setGpsData(gpsData: ByteArray)

    /**
     * 校准陀螺仪
     */
    suspend fun calibrateGyro(): Result<Unit>

    /**
     * 关机
     */
    fun shutdown()

    /**
     * 设置相机页面状态，见 SetAccessCameraFileState
     */
    suspend fun setAccessCameraFileState(accessState: Int): Result<Unit>

    /**
     * 最小化开流：不经过完整预览流程，仅用于锁屏场景下让部分机型（如X6）真正进入锁屏状态
     */
    fun openMinimalPreviewStream()

    /**
     * 关闭最小化开流打开的流
     */
    fun closeMinimalPreviewStream()

    suspend fun formatSdCard(): Result<Unit>

    suspend fun formatStorage(fileLocation: StorageData.FileLocation): Result<Unit>

    /**
     * 设置主存储位置（X6支持）
     */
    suspend fun setMainStorage(fileLocation: StorageData.FileLocation): Result<Unit>

    /**
     * 获取文件信息列表
     */
    suspend fun getFileInfoList(fileLocation: StorageData.FileLocation): Result<List<FileInfo>>

    suspend fun checkAuthorization(): Result<AuthorizationStatus>

    suspend fun requestAuthorization(operationType: AuthorizationOperationType): Result<Unit>

    suspend fun cancelAuthorization(): Result<Unit>

    suspend fun cancelRequestAuthorization(operationType: AuthorizationOperationType): Result<Unit>
}


