package com.arashivision.sdk.camera.config.go3s

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.PhotographyOptionType

class Go3SCameraConfig(override val connectType: ConnectType) : ICameraConfig {

    override fun supportShutdown(): Boolean = false

    override fun supportMultiVideoOptionsList(): List<MultiPhotographyOptionsType> = emptyList()

    override fun captureMinBatteryLevel(): Int = 5

    override fun supportResetCameraWifi(fwVersion: String): Boolean = true

    override fun supportFetchCameraSensorMode(): Boolean = false

    override fun syncOptionMaxStep(): Int {
        return if (connectType == ConnectType.BLE) 16 else Int.MAX_VALUE
    }

    override fun excludePhotographyOptions(): List<PhotographyOptionType> {
        return listOf(PhotographyOptionType.RES_REC_LIMIT)
    }

    override fun hasChargingBox(): Boolean = true

    override fun supportDownloadJsonParams(): Boolean = false

    override fun getLensName(sensorMode: SensorMode): String {
        TODO("Not yet implemented")
    }

    override fun firmwareUpgradeMinBatteryLevel(): Int = 25

    override fun firmwareUpgradeMinChargingBoxBatteryLevel(): Int = 25

    override fun supportNewRecordInterface(): Boolean = true

    override fun needNotifyWhenCameraRecordOverTimeLimit(): Boolean = false

    override fun isMergedIntoRS(version: String): Boolean = false

    override fun supportRepeatOpenStream(): Boolean = true

    override fun supportBleBroadcastWakeUp(): Boolean = false

    override fun needAuthorization(): Boolean = true
}