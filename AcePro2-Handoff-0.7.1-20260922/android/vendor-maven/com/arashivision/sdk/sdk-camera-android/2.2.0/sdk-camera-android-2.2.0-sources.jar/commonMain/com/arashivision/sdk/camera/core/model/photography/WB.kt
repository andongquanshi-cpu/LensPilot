package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

class WB(override val nativeValue: Int, val value: Int) : BaseEnum {
    companion object {
        val WB_AUTO = WB(0, 0)
        val WB_2000K = WB(6, 2000)
        val WB_2200K = WB(7, 2200)
        val WB_2400K = WB(8, 2400)
        val WB_2600K = WB(9, 2600)
        val WB_2700K = WB(1, 2700)
        val WB_2800K = WB(10, 2800)
        val WB_3000K = WB(11, 3000)
        val WB_3200K = WB(12, 3200)
        val WB_3400K = WB(13, 3400)
        val WB_3600K = WB(14, 3600)
        val WB_3800K = WB(15, 3800)
        val WB_4000K = WB(2, 4000)
        val WB_4500K = WB(16, 4500)
        val WB_5000K = WB(3, 5000)
        val WB_5500K = WB(17, 5500)
        val WB_6000K = WB(18, 6000)
        val WB_6500K = WB(4, 6500)
        val WB_7000K = WB(19, 7000)
        val WB_7500K = WB(5, 7500)
        val WB_8000K = WB(20, 8000)
        val WB_8500K = WB(21, 8500)
        val WB_9000K = WB(22, 9000)
        val WB_9500K = WB(23, 9500)
        val WB_10000K = WB(21, 10000)

        fun nativeOf(value: Int?): WB {
            return when (value) {
                1 -> WB_2700K
                2 -> WB_4000K
                3 -> WB_5000K
                4 -> WB_6500K
                5 -> WB_7500K
                6 -> WB_2000K
                7 -> WB_2200K
                8 -> WB_2400K
                9 -> WB_2600K
                10 -> WB_2800K
                11 -> WB_3000K
                12 -> WB_3200K
                13 -> WB_3400K
                14 -> WB_3600K
                15 -> WB_3800K
                16 -> WB_4500K
                17 -> WB_5500K
                18 -> WB_6000K
                19 -> WB_7000K
                20 -> WB_8000K
                21 -> WB_8500K
                22 -> WB_9000K
                23 -> WB_9500K
                24 -> WB_10000K
                else -> WB_AUTO
            }
        }

        fun valueOf(value: Int?): WB {
            return value?.let {
                when (value) {
                    0 -> WB_AUTO
                    2700 -> WB_2700K
                    4000 -> WB_4000K
                    5000 -> WB_5000K
                    6500 -> WB_6500K
                    7500 -> WB_7500K
                    2000 -> WB_2000K
                    2200 -> WB_2200K
                    2400 -> WB_2400K
                    2600 -> WB_2600K
                    2800 -> WB_2800K
                    3000 -> WB_3000K
                    3200 -> WB_3200K
                    3400 -> WB_3400K
                    3600 -> WB_3600K
                    3800 -> WB_3800K
                    4500 -> WB_4500K
                    5500 -> WB_5500K
                    6000 -> WB_6000K
                    7000 -> WB_7000K
                    8000 -> WB_8000K
                    8500 -> WB_8500K
                    9000 -> WB_9000K
                    9500 -> WB_9500K
                    10000 -> WB_10000K
                    else -> WB(-1, value)
                }
            } ?: WB_AUTO
        }
    }

}