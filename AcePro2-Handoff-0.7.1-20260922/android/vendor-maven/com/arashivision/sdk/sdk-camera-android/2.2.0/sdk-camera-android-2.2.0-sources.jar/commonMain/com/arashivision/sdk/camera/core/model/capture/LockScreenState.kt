package com.arashivision.sdk.camera.core.model.capture

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class LockScreenState(override val nativeValue: Int) : BaseEnum {
    IDLE(1),
    LOCK(5);
}