package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.option.ExpectOutputType
import com.arashivision.sdk.camera.core.model.option.FocusSensor
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.common.exception.InvalidParameterException
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger

internal class FocusSensorCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<SensorMode>(CommonAttrKeys.FOCUS_SENSOR, managerProvider, deviceCoreProvider) {

    override suspend fun reader(
        manager: CameraAttributeManager,
        device: DeviceCore
    ): Result<SensorMode> {
        return if (manager.lensTypes().size == 1) {
            manager.setLensType(manager.lensTypes().first())
            if (onlySphere(manager.lensTypes())) {
                SensorMode.ALL.success()
            } else {
                SensorMode.UNKNOWN.success()
            }
        } else {
            readFormCamera(device).flatMap { mode ->
                if (mode == SensorMode.UNKNOWN) {
                    Logger.w("CameraParams", "FocusSensor.UNKNOWN is not supported")
                    InvalidStateException("FocusSensor.UNKNOWN is not supported").failure()
                } else {
                    mode.success()
                }
            }.mapFailure {
                InvalidStateException("${it.message}: Device does not support multiple lens types")
            }.onSuccess {
                setLensNameToManager(manager, device, it)
            }
        }
    }

    override suspend fun fetcher(
        manager: CameraAttributeManager,
        device: DeviceCore
    ): Result<SensorMode> {
        return if (manager.lensTypes().size == 1) {
            manager.setLensType(manager.lensTypes().first())
            if (onlySphere(manager.lensTypes())) {
                SensorMode.ALL.success()
            } else {
                SensorMode.UNKNOWN.success()
            }
        } else {
            fetchFormCamera(device).flatMap { mode ->
                if (mode == SensorMode.UNKNOWN) {
                    Logger.w("CameraParams", "FocusSensor.UNKNOWN is not supported")
                    InvalidStateException("FocusSensor.UNKNOWN is not supported").failure()
                } else {
                    mode.success()
                }
            }.mapFailure {
                InvalidStateException("${it.message}: Device does not support multiple lens types")
            }.onSuccess {
                setLensNameToManager(manager, device, it)
            }
        }
    }

    private fun setLensNameToManager(
        manager: CameraAttributeManager,
        device: DeviceCore,
        sensorMode: SensorMode
    ) {
        val lensName = device.getCameraConfig().getOrNull()?.getLensName(sensorMode) ?: ""
        if (lensName.isNotEmpty() && manager.lensTypes().contains(lensName)) manager.setLensType(
            lensName
        )
    }

    override suspend fun writer(
        manager: CameraAttributeManager,
        device: DeviceCore,
        value: SensorMode
    ): Result<Unit> {
        val sensorList = manager.lensTypes()
        return if (sensorList.size <= 1 && !onlySphere(sensorList)) {
            InvalidStateException("Device does not support multiple lens types").failure()
        } else {
            writeToCamera(
                device,
                value = value
            ).mapFailure { InvalidStateException("${it.message}:device error") }.onSuccess {
                // 根据 FocusSensor 设置对应的 LensType
                if (value != SensorMode.UNKNOWN) {
                    setLensNameToManager(manager, device, value)
                } else {
                    Logger.w("CameraParams", "FocusSensor.UNKNOWN is not supported for setting")
                }
            }
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<SensorMode>> {
        val lensTypes = manager.lensTypes()
        return if (lensTypes.size > 1) {
            listOf(SensorMode.FRONT, SensorMode.REAR, SensorMode.ALL).success()
        } else if (onlySphere(lensTypes)) {
            listOf(SensorMode.ALL).success()
        } else {
            NumberConversionException("No valid options for ${CommonAttrKeys.FOCUS_SENSOR}").failure()
        }
    }

    override suspend fun readFormCamera(
        device: DeviceCore,
        functionMode: FunctionMode
    ): Result<SensorMode> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.ONE_X -> {
                device.fetchSensorMode()

                managerProvider().flatMap {
                    it.setLensType("Sphere")
                }
                SensorMode.ALL.success()
            }

            else -> device.fetchSensorMode()
        }
    }

    override suspend fun fetchFormCamera(
        device: DeviceCore,
        functionMode: FunctionMode
    ): Result<SensorMode> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.ONE_X -> {
                device.fetchSensorMode()

                managerProvider().flatMap {
                    it.setLensType("Sphere")
                }
                SensorMode.ALL.success()
            }

            else -> device.fetchSensorMode()
        }
    }

    override suspend fun writeToCamera(
        device: DeviceCore,
        functionMode: FunctionMode,
        value: SensorMode
    ): Result<Unit> {
        if (value == SensorMode.UNKNOWN) {
            return InvalidParameterException("The sensorMode value cannot be SensorMode.UNKNOWN").failure()
        }
        // TODO 此处isPano暂时定为false，后续需要根据pano业务需求修改
        val isPano = false
        return device.setExpectOutputType(
            when (value) {
                SensorMode.FRONT, SensorMode.REAR -> if (isPano) ExpectOutputType.INSTA_PANO else ExpectOutputType.DEFAULT
                else -> ExpectOutputType.DEFAULT
            }
        ).flatMap {
            device.setFocusSensor(
                when (value) {
                    SensorMode.FRONT -> FocusSensor.FRONT
                    SensorMode.REAR -> FocusSensor.REAR
                    else -> FocusSensor.ALL
                }
            ).flatMap {
                device.setSensorMode(value)
            }
        }.onSuccess {
            // 镜头切换需要全量同步参数
            device.initAllOptions()
        }
    }

    // 全景相机仅支持全镜头
    private fun onlySphere(lensTypes: List<String>): Boolean =
        lensTypes.size == 1 && lensTypes.first() == "Sphere"

}