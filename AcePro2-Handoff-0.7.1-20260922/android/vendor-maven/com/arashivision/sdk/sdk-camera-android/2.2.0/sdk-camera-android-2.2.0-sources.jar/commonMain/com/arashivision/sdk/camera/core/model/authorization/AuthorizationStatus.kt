package com.arashivision.sdk.camera.core.model.authorization

enum class AuthorizationStatus(val value: Int) {
    /** 已授权，无需用户操作。 */
    AUTHORIZED(0),

    /** 未授权，相机端将显示授权确认弹窗，结果通过 AuthorizationListener 回调。 */
    UNAUTHORIZED(1),

    /** 相机当前繁忙，无法处理授权请求。 */
    SYSTEM_BUSY(2);

    companion object {
        fun nativeOf(value: Int): AuthorizationStatus =
            entries.firstOrNull { it.value == value } ?: SYSTEM_BUSY
    }
}
