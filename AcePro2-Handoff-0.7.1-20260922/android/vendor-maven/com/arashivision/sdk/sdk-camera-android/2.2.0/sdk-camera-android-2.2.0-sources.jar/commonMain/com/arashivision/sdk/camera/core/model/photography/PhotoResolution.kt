package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class PhotoResolution(override val nativeValue: Int, val protoName: String) : BaseEnum {
    RES_6912_3456(0, "6912_3456"),
    RES_6272_3136(1, "6272_3136"),
    RES_6080_3040(2, "6080_3040"),
    RES_4000_3000(3, "4000_3000"),
    RES_4000_2250(4, "4000_2250"),
    RES_5212_3542(5, "5212_3542"),
    RES_5312_2988(6, "5312_2988"),
    RES_8000_6000(7, "8000_6000"),
    RES_8000_4500(8, "8000_4500"),
    RES_2976_2976(9, "2976_2976"),
    RES_5984_5984(10, "5984_5984"),
    RES_11968_5984(11, "11968_5984"),
    RES_5952_2976(12, "5952_2976"),
    RES_8064_6048(13, "8064_6048"),
    RES_8064_4536(14, "8064_4536"),
    RES_4032_3024(15, "4032_3024"),
    RES_4032_2264(16, "4032_2264"),
    RES_8192_6144(17, "8192_6144"),
    RES_8192_4608(18, "8192_4608"),
    RES_4096_3072(19, "4096_3072"),
    RES_4096_2304(20, "4096_2304"),
    RES_7680_3840(21, "7680_3840"),
    RES_3840_3840(22, "3840_3840"),
    RES_8192_3488(23, "8192_3488"),
    RES_4096_1744(24, "4096_1744"),
    RES_15520_7760(25, "15520_7760"),
    RES_7760_7760(26, "7760_7760"),
    RES_7776_3888(27, "7776_3888"),
    RES_3888_3888(28, "3888_3888"),
    RES_3840_2160(29, "3840_2160"),
    RES_3072_3072(30, "3072_3072"),
    RES_7680_4320(31, "7680_4320"),
    RES_6144_6144(32, "6144_6144"),
    RES_7040_5288(33, "7040_5288"),
    RES_3520_2644(34, "3520_2644"),
    RES_7680_3264(35, "7680_3264"),
    RES_3840_1632(36, "3840_1632"),
    UNKNOWN(-1, "UNKNOWN");

    companion object {
        fun nativeOf(value: Int?): PhotoResolution = entries.firstOrNull { it.nativeValue == value } ?: UNKNOWN
        fun protoOf(name: String?): PhotoResolution = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: UNKNOWN
    }
}