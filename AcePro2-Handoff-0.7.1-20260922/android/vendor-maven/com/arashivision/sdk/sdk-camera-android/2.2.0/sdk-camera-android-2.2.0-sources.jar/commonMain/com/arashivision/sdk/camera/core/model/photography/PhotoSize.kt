package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class PhotoSize(override val nativeValue: Int, val protoName: String) : BaseEnum {
    SIZE_16_9(0, "16:9"),
    SIZE_1_1(1, "1:1"),
    SIZE_9_16(2, "9:16"),
    SIZE_27_10(3, "27:10"),
    SIZE_4_3(4, "4:3"),
    UNKNOWN(-1, "UNKNOWN");

    companion object {
        fun nativeOf(value: Int?): PhotoSize = entries.firstOrNull { it.nativeValue == value } ?: UNKNOWN
        fun protoOf(name: String?): PhotoSize = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: UNKNOWN
    }
}