package com.arashivision.sdk.camera.service.capture.param

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode

/**
 * 旧拍摄链路下，是否需要在写当前 [functionMode] 成功后，再镜像一份到 [FunctionMode.VIDEO_LIVE]。
 *
 * - 当前已是 [FunctionMode.VIDEO_LIVE]：无需镜像（避免重复下发）。
 * - [ICameraConfig.supportNewCaptureControlFlow] 为 **true**（如 X4/X5 新链路）：由固件/新流程自行同步，SDK 不再双写。
 * - 其余情况（默认 **false** 的机型配置）：需要双写，保证 liveview 预览参数与当前可调档位一致。
 */
internal fun DeviceCore.shouldWriteVideoLiveMirror(functionMode: FunctionMode): Boolean {
    if (functionMode == FunctionMode.VIDEO_LIVE) return false
    if (getCameraConfig().getOrNull()?.supportNewCaptureControlFlow() == true) return false
    return true
}

/**
 * 主写入 [Result] 成功后，按 [shouldWriteVideoLiveMirror] 决定是否对 [FunctionMode.VIDEO_LIVE] 执行 [mirrorWrite]。
 *
 * - 主写入失败：原样返回失败，不触发镜像。
 * - 主写入成功且无需镜像：返回成功。
 * - 主写入成功且需要镜像：执行 [mirrorWrite]；镜像失败用 [Result.recover] 忽略（仍返回成功），
 *   避免部分机型/参数不支持 VIDEO_LIVE 档位时影响用户正常的参数设置。
 */
internal suspend fun Result<Unit>.thenMirrorVideoLiveIfNeeded(
    device: DeviceCore,
    currentFunctionMode: FunctionMode,
    mirrorWrite: suspend () -> Result<Unit>,
): Result<Unit> {
    if (isFailure) return this
    if (!device.shouldWriteVideoLiveMirror(currentFunctionMode)) return Result.success(Unit)
    return mirrorWrite().recover { Unit }
}
