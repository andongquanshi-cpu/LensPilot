package com.arashivision.sdk.camera.core.callback

import com.arashivision.inskmp.insble.data.BleDeviceCore

interface BleScanCallback {
    fun onStarted()
    fun onScanning(bleDevice: BleDeviceCore)
    fun onFinished(bleDeviceList: List<BleDeviceCore>)
    fun onError(throwable: Throwable)
}

class BleScanCallbackBuilder : BleScanCallback {

    private var startedBlock: (() -> Unit)? = null
    private var scanningBlock: ((BleDeviceCore) -> Unit)? = null
    private var finishedBlock: ((List<BleDeviceCore>) -> Unit)? = null
    private var throwableBlock: ((Throwable) -> Unit)? = null

    override fun onStarted() {
        startedBlock?.invoke()
    }

    override fun onError(throwable: Throwable) {
        throwableBlock?.invoke(throwable)
    }

    override fun onScanning(bleDevice: BleDeviceCore) {
        scanningBlock?.invoke(bleDevice)
    }

    override fun onFinished(bleDeviceList: List<BleDeviceCore>) {
        finishedBlock?.invoke(bleDeviceList)
    }

    fun started(block: () -> Unit): BleScanCallback {
        this.startedBlock = block
        return this
    }

    fun scanning(block: (BleDeviceCore) -> Unit): BleScanCallback {
        this.scanningBlock = block
        return this
    }

    fun finished(block: (List<BleDeviceCore>) -> Unit): BleScanCallback {
        this.finishedBlock = block
        return this
    }

    fun error(block: (Throwable) -> Unit): BleScanCallback {
        this.throwableBlock = block
        return this
    }
}

fun bleScanCallback(block: BleScanCallbackBuilder.() -> Unit): BleScanCallback {
    return BleScanCallbackBuilder().apply(block)
}