package com.arashivision.sdk.camera.core.delegate.multivideooption

import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import insta360.messages.FovType
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptions.DimensionType
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.VideoResolution

object MultiVideoOptionMapper {

    fun multiVideoOption2Map(multiVideoOptionList: List<MultiPhotographyOptionsType>, multiPhotographyOptions: MultiPhotographyOptions): Map<MultiPhotographyOptionsType, Any?> {
        val associateWith = multiVideoOptionList.associateWith {
            when (it) {
                MultiPhotographyOptionsType.RESOLUTION -> multiPhotographyOptions.recordResolution
                MultiPhotographyOptionsType.PHOTOGRAPHY_INTERNAL_FLOWSTATE -> multiPhotographyOptions.enableInternalFlowstate
                MultiPhotographyOptionsType.DIMENSION_TYPE -> multiPhotographyOptions.dimentsionType
                MultiPhotographyOptionsType.VISION_TYPE -> multiPhotographyOptions.visionType
                else -> null
            }
        }
        return associateWith.filter { it.value != null }.mapValues { (_, value) -> value!! }
    }


    fun map2MultiVideoOptions(multiVideoOptionMap: Map<MultiPhotographyOptionsType, Any>): MultiPhotographyOptions {
        return MultiPhotographyOptions().apply {
            multiVideoOptionMap.entries.forEach { (key, value) ->
                when (key) {
                    MultiPhotographyOptionsType.RESOLUTION -> recordResolution = (value as? VideoResolution) ?: VideoResolution.RES_3840_1920P30
                    MultiPhotographyOptionsType.PHOTOGRAPHY_INTERNAL_FLOWSTATE -> enableInternalFlowstate = (value as? Boolean) ?: false
                    MultiPhotographyOptionsType.DIMENSION_TYPE -> dimentsionType = (value as? DimensionType) ?: DimensionType.DIMENSION_TYPE_HORIZONTAL
                    MultiPhotographyOptionsType.VISION_TYPE -> visionType = (value as? FovType) ?: FovType.FOV_WIDE
                    else -> Unit
                }
            }
        }
    }


    // get transform
    fun multiVideoOptionTransform(multiVideoOptionType: MultiPhotographyOptionsType, multiVideoOptionMap: Map<MultiPhotographyOptionsType, Any?>): Any? {
        val option: Any = multiVideoOptionMap[multiVideoOptionType] ?: return null
        return when (multiVideoOptionType) {

            MultiPhotographyOptionsType.RESOLUTION -> {
                val videoResolution = option as VideoResolution
                RecordResolution.nativeOf(videoResolution.value)
            }

            else -> option
        }
    }

    // set transform
    fun mapTransform(multiVideoOptionType: MultiPhotographyOptionsType, data: Any): Map<MultiPhotographyOptionsType, Any> {
        return mutableMapOf(
            multiVideoOptionType to when (multiVideoOptionType) {

                MultiPhotographyOptionsType.RESOLUTION -> {
                    val recordResolution = data as RecordResolution
                    VideoResolution.fromValue(recordResolution.nativeValue) ?: VideoResolution.RES_3840_1920P30
                }

                else -> data
            }
        )
    }
}