package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class ExportType(override val nativeValue: Int, val protoName: String) : BaseEnum {
    STARLAPSE_VIDEO(0, "STARLAPSE_VIDEO"),
    STAR_TRAILS_VIDEO(1, "STAR_TRAILS_VIDEO"),
    STAR_TRAILS_PHOTO(2, "STAR_TRAILS_PHOTO"),
    UNKNOWN(-1, "UNKNOWN");

    companion object {
        fun nativeOf(value: Int?): ExportType = entries.firstOrNull { it.nativeValue == value } ?: UNKNOWN
        fun protoOf(name: String?): ExportType = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: UNKNOWN
    }
}