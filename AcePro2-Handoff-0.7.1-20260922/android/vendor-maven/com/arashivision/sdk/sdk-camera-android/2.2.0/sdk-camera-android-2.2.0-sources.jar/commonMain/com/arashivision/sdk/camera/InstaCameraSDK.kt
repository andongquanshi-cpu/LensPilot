package com.arashivision.sdk.camera

import com.arashivision.sdk.bridge.ModuleRegistry
import com.arashivision.sdk.camera.InstaCameraSDK.init
import com.arashivision.sdk.camera.core.config.DeviceConfigure
import com.arashivision.sdk.camera.provider.CameraModuleProviderImpl
import com.arashivision.sdk.common.InstaSDK
import com.arashivision.sdk.common.file.InstaFileManager
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.common.type.KMPContext

/**
 * 相机 SDK 的核心入口类。
 *
 * 负责整个相机 SDK 的初始化工作，包括配置缓存目录、日志级别以及底层设备配置等。
 * 在使用任何相机相关功能之前，必须先调用此类的 [init] 方法进行初始化。
 */
object InstaCameraSDK {

    /**
     * 初始化相机 SDK（已废弃）。
     *
     * @param app 应用程序上下文对象。在 Android 平台上通常传入 Application 实例；在 iOS 平台上根据具体实现传入相应的上下文对象。
     * @param cacheDir SDK 内部使用的缓存目录路径。用于存放临时文件、日志等。
     * @deprecated 请使用带有配置闭包的 [init] 方法替代，以便支持更多配置项。
     */
    @Deprecated(
        message = "Use init(app: KMPContext, configure: (InstaCameraConfig.() -> Unit)?) instead",
        replaceWith = ReplaceWith("InstaCameraSDK.init(app) { this.cacheDir = cacheDir }")
    )
    fun init(app: KMPContext, cacheDir: String) {
        init(app) {
            this.cacheDir = cacheDir
        }
    }

    /**
     * 初始化相机 SDK（推荐使用）。
     *
     * 允许通过 DSL 方式灵活配置 SDK 的各项参数（如缓存路径、日志级别等）。
     *
     * @param app 应用程序上下文对象。在 Android 平台上通常传入 Application 实例；在 iOS 平台上根据具体实现传入相应的上下文对象。
     * @param configure 可选的配置闭包。在闭包内可以修改 [InstaCameraConfig] 的属性。如果不传，则使用默认配置。
     */
    fun init(app: KMPContext, configure: (InstaCameraConfig.() -> Unit)? = null) {
        ModuleRegistry.install(CameraModuleProviderImpl)
        val config = InstaCameraConfig()
        configure?.invoke(config)
        initWithConfig(app, config)
    }

    /**
     * 根据提供的配置对象执行实际的 SDK 初始化流程。
     *
     * 依次初始化通用 SDK 上下文、文件管理器、日志系统以及设备核心配置。
     *
     * @param app 应用程序上下文对象。
     * @param config 包含 SDK 运行所需各项参数的配置对象。
     */
    private fun initWithConfig(app: KMPContext, config: InstaCameraConfig) {
        InstaSDK.setContext(app)
        InstaFileManager.init(config.fileDir, config.cacheDir)
        Logger.setLogLevel(config.logLevel)
        DeviceConfigure.init(app, config)
    }
}
