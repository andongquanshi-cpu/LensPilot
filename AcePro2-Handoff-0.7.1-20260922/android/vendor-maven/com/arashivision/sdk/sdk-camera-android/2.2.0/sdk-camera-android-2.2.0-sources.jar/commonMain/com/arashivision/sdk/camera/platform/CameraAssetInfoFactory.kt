package com.arashivision.sdk.camera.platform

import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.common.type.KMPAssetInfo
import insta360.messages.WindowCropInfo

internal data class CameraAssetInfoRequest(
    val cameraType: CameraType,
    val functionMode: FunctionMode,
    val previewWidth: Int,
    val previewHeight: Int,
    val previewFps: Int,
    val mediaOffset: String,
    val mediaOffsetV3: String,
    val mediaOffsetV6: String,
    val isSelfie: Boolean,
    val windowCropInfo: WindowCropInfo?,
    val halfWindowCropInfo: WindowCropInfo?,
)

internal expect fun buildPreviewAssetInfo(request: CameraAssetInfoRequest): KMPAssetInfo?

internal expect fun buildStabAssetInfo(request: CameraAssetInfoRequest): KMPAssetInfo?
