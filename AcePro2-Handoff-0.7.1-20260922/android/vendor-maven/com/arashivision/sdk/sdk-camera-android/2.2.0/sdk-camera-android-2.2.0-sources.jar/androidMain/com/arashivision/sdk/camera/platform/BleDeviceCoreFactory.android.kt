package com.arashivision.sdk.camera.platform

import android.bluetooth.le.ScanSettings.SCAN_MODE_LOW_LATENCY
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.clj.fastble.data.BleDevice
import com.arashivision.sdk.common.type.KMPBleDevice

actual fun createBleDeviceCore(kmpBleDevice: KMPBleDevice): BleDeviceCore {
    return BleDeviceCore(BleDevice(kmpBleDevice, null, 0, null, 0, null, null))
}

actual fun getDefaultBleScanMode(): Int {
    return SCAN_MODE_LOW_LATENCY
}