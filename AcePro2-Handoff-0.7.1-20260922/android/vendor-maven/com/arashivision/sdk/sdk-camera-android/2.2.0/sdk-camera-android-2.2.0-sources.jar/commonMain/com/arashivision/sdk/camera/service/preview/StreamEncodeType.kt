package com.arashivision.sdk.camera.service.preview

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class StreamEncodeType(
    override val nativeValue: Int,
) : BaseEnum {
    H264(0),
    H265(1),
    ;

    companion object {
        fun nativeOf(value: Int): StreamEncodeType = entries.firstOrNull { it.nativeValue == value } ?: H264
    }
}
