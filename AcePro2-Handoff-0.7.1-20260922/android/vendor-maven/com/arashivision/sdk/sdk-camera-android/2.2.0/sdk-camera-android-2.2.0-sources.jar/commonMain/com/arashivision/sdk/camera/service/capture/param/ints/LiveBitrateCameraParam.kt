package com.arashivision.sdk.camera.service.capture.param.ints

import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class LiveBitrateCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : IntCameraParam(CommonAttrKeys.LIVING_BITRATE, managerProvider, deviceCoreProvider) {

    private var bitrate = 8

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return bitrate.success()
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return bitrate.success()
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Int): Result<Unit> {
        bitrate = value
        return Unit.success()
    }


}