package com.arashivision.sdk.camera.core.delegate.photography

import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.ExportType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.core.model.photography.Iq3AMode
import com.arashivision.sdk.camera.core.model.photography.FlowStateLevel
import com.arashivision.sdk.camera.core.model.photography.FovType
import com.arashivision.sdk.camera.core.model.photography.PanoExposureMode
import com.arashivision.sdk.camera.core.model.photography.PhotoHdrType
import com.arashivision.sdk.camera.core.model.photography.PhotoResolution
import com.arashivision.sdk.camera.core.model.photography.PhotoSize
import com.arashivision.sdk.camera.core.model.photography.RawType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.ResolutionRecordLimit
import com.arashivision.sdk.camera.core.model.photography.VideoGammaMode
import com.arashivision.sdk.camera.core.model.photography.VideoSelfieMode
import com.arashivision.sdk.camera.core.model.photography.WB
import insta360.messages.PhotographyOptionType

interface PhotographyOptionDelegate {

    fun getRemaining(functionMode: FunctionMode): Result<Int>
    suspend fun fetchRemaining(functionMode: FunctionMode): Result<Int>

    fun getAeb(functionMode: FunctionMode): Result<Int>
    suspend fun fetchAeb(functionMode: FunctionMode): Result<Int>
    suspend fun setAeb(functionMode: FunctionMode, aeb: Int): Result<Unit>

    fun getRawType(functionMode: FunctionMode): Result<RawType>
    suspend fun fetchRawType(functionMode: FunctionMode): Result<RawType>
    suspend fun setRawType(functionMode: FunctionMode, rawType: RawType): Result<Unit>

    fun getExposureBias(functionMode: FunctionMode): Result<Double>
    suspend fun fetchExposureBias(functionMode: FunctionMode): Result<Double>
    suspend fun setExposureBias(functionMode: FunctionMode, exposureBias: Double): Result<Unit>


    fun getPhotoResolution(functionMode: FunctionMode): Result<PhotoResolution>
    suspend fun fetchPhotoResolution(functionMode: FunctionMode): Result<PhotoResolution>
    suspend fun setPhotoResolution(functionMode: FunctionMode, photoResolution: PhotoResolution): Result<Unit>

    fun getWhiteBalance(functionMode: FunctionMode): Result<WB>
    suspend fun fetchWhiteBalance(functionMode: FunctionMode): Result<WB>
    suspend fun setWhiteBalance(functionMode: FunctionMode, wb: WB): Result<Unit>

    fun getWhiteBalanceValue(functionMode: FunctionMode): Result<WB>
    suspend fun fetchWhiteBalanceValue(functionMode: FunctionMode): Result<WB>
    suspend fun setWhiteBalanceValue(functionMode: FunctionMode, wb: WB): Result<Unit>

    fun getFovType(functionMode: FunctionMode): Result<FovType>
    suspend fun fetchFovType(functionMode: FunctionMode): Result<FovType>
    suspend fun setFovType(functionMode: FunctionMode, fovType: FovType): Result<Unit>

    fun getFlowstateBaseEnable(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchFlowstateBaseEnable(functionMode: FunctionMode): Result<Boolean>

    fun getFlowStateLevelCv5(functionMode: FunctionMode): Result<FlowStateLevel>
    suspend fun fetchFlowStateLevelCv5(functionMode: FunctionMode): Result<FlowStateLevel>
    suspend fun setFlowStateLevelCv5(functionMode: FunctionMode, flowStateLevel: FlowStateLevel): Result<Unit>

    fun getFlowStateLevel(functionMode: FunctionMode): Result<FlowStateLevel>
    suspend fun fetchFlowStateLevel(functionMode: FunctionMode): Result<FlowStateLevel>
    suspend fun setFlowStateLevel(functionMode: FunctionMode, flowStateLevel: FlowStateLevel): Result<Unit>

    fun getPhotographySelfTimer(functionMode: FunctionMode): Result<Int>
    suspend fun fetchPhotographySelfTimer(functionMode: FunctionMode): Result<Int>
    suspend fun setPhotographySelfTimer(functionMode: FunctionMode, selfTimer: Int): Result<Unit>

    fun getVideoSelfieMode(functionMode: FunctionMode): Result<VideoSelfieMode>
    suspend fun fetchVideoSelfieMode(functionMode: FunctionMode): Result<VideoSelfieMode>
    suspend fun setVideoSelfieMode(functionMode: FunctionMode, videoSelfieMode: VideoSelfieMode): Result<Unit>

    fun getRecordResolution(functionMode: FunctionMode): Result<RecordResolution>
    suspend fun fetchRecordResolution(functionMode: FunctionMode): Result<RecordResolution>
    suspend fun setRecordResolution(functionMode: FunctionMode, recordResolution: RecordResolution): Result<Unit>

    fun getVideoIsoTopLimit(functionMode: FunctionMode): Result<Int>
    suspend fun fetchVideoIsoTopLimit(functionMode: FunctionMode): Result<Int>
    suspend fun setVideoIsoTopLimit(functionMode: FunctionMode, isoTopLimit: Int): Result<Unit>

    fun getExportType(functionMode: FunctionMode): Result<ExportType>
    suspend fun fetchExportType(functionMode: FunctionMode): Result<ExportType>
    suspend fun setExportType(functionMode: FunctionMode, exportType: ExportType): Result<Unit>

    fun getPanoExposureMode(functionMode: FunctionMode): Result<PanoExposureMode>
    suspend fun fetchPanoExposureMode(functionMode: FunctionMode): Result<PanoExposureMode>
    suspend fun setPanoExposureMode(functionMode: FunctionMode, exposureMode: PanoExposureMode): Result<Unit>

    fun getPhotoSize(functionMode: FunctionMode): Result<PhotoSize>
    suspend fun fetchPhotoSize(functionMode: FunctionMode): Result<PhotoSize>
    suspend fun setPhotoSize(functionMode: FunctionMode, photoSize: PhotoSize): Result<Unit>

    fun getAccelerateFrequency(functionMode: FunctionMode): Result<Int>
    suspend fun fetchAccelerateFrequency(functionMode: FunctionMode): Result<Int>
    suspend fun setAccelerateFrequency(functionMode: FunctionMode, accelerateFrequency: Int): Result<Unit>

    fun getRecordDuration(functionMode: FunctionMode): Result<Int>
    suspend fun fetchRecordDuration(functionMode: FunctionMode): Result<Int>
    suspend fun setRecordDuration(functionMode: FunctionMode, recordDuration: Int): Result<Unit>

    fun getMaxRecordDuration(functionMode: FunctionMode): Result<Int>
    suspend fun fetchMaxRecordDuration(functionMode: FunctionMode): Result<Int>
    suspend fun setMaxRecordDuration(functionMode: FunctionMode, recordDuration: Int): Result<Unit>

    fun getResolutionRecordLimits(functionMode: FunctionMode): Result<List<ResolutionRecordLimit>>
    suspend fun fetchResolutionRecordLimits(functionMode: FunctionMode): Result<List<ResolutionRecordLimit>>
    suspend fun setResolutionRecordLimits(functionMode: FunctionMode, resolutionRecordLimits: List<ResolutionRecordLimit>): Result<Unit>

    fun getStillExposure(functionMode: FunctionMode): Result<Exposure>
    suspend fun fetchStillExposure(functionMode: FunctionMode): Result<Exposure>
    suspend fun setStillExposure(functionMode: FunctionMode, exposure: Exposure): Result<Unit>

    fun getVideoExposure(functionMode: FunctionMode): Result<Exposure>
    suspend fun fetchVideoExposure(functionMode: FunctionMode): Result<Exposure>
    suspend fun setVideoExposure(functionMode: FunctionMode, exposure: Exposure): Result<Unit>

    fun getBurstCaptureNum(functionMode: FunctionMode): Result<Int>
    suspend fun fetchBurstCaptureNum(functionMode: FunctionMode): Result<Int>
    suspend fun setBurstCaptureNum(functionMode: FunctionMode, burstCaptureNum: Int): Result<Unit>

    suspend fun setBurstCaptureParams(functionMode: FunctionMode, burstCaptureNum: Int, burstCaptureTime: Int): Result<Unit>
    fun getBurstCaptureTime(functionMode: FunctionMode): Result<Int>
    suspend fun fetchBurstCaptureTime(functionMode: FunctionMode): Result<Int>
    suspend fun setBurstCaptureTime(functionMode: FunctionMode, burstCaptureTime: Int): Result<Unit>

    fun getVideoGammaMode(functionMode: FunctionMode): Result<VideoGammaMode>
    suspend fun fetchVideoGammaMode(functionMode: FunctionMode): Result<VideoGammaMode>
    suspend fun setVideoGammaMode(functionMode: FunctionMode, gammaMode: VideoGammaMode): Result<Unit>

    fun getPhotoHdrType(functionMode: FunctionMode): Result<PhotoHdrType>
    suspend fun fetchPhotoHdrType(functionMode: FunctionMode): Result<PhotoHdrType>
    suspend fun setPhotoHdrType(functionMode: FunctionMode, photoHdrType: PhotoHdrType): Result<Unit>

    fun getHdrSwitch(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchHdrSwitch(functionMode: FunctionMode): Result<Boolean>
    suspend fun setHdrSwitch(functionMode: FunctionMode, hdrSwitch: Boolean): Result<Unit>

    fun getP3Switch(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchP3Switch(functionMode: FunctionMode): Result<Boolean>
    suspend fun setP3Switch(functionMode: FunctionMode, hdrSwitch: Boolean): Result<Unit>

    fun getILogSwitch(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchILogSwitch(functionMode: FunctionMode): Result<Boolean>
    suspend fun setILogSwitch(functionMode: FunctionMode, iLogSwitch: Boolean): Result<Unit>

    fun getDoubleZoomEnable(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchDoubleZoomEnable(functionMode: FunctionMode): Result<Boolean>
    suspend fun setDoubleZoomEnable(functionMode: FunctionMode, enable: Boolean): Result<Unit>

    fun getPureVideoEnhancSwitch(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchPureVideoEnhancSwitch(functionMode: FunctionMode): Result<Boolean>
    suspend fun setPureVideoEnhancSwitch(functionMode: FunctionMode, pureVideoEnhancSwitch: Boolean): Result<Unit>

    fun getLivePhotoMode(functionMode: FunctionMode): Result<Boolean>
    suspend fun fetchLivePhotoMode(functionMode: FunctionMode): Result<Boolean>
    suspend fun setLivePhotoMode(functionMode: FunctionMode, livePhotoMode: Boolean): Result<Unit>

    fun getFocalLength(functionMode: FunctionMode): Result<Double>
    suspend fun fetchFocalLength(functionMode: FunctionMode): Result<Double>
    suspend fun setFocalLength(functionMode: FunctionMode, focalLength: Double): Result<Unit>

    fun getZoomScale(functionMode: FunctionMode): Result<Double>
    suspend fun fetchZoomScale(functionMode: FunctionMode): Result<Double>
    suspend fun setZoomScale(functionMode: FunctionMode, zoomScale: Double): Result<Unit>

    fun getIq3AMode(functionMode: FunctionMode): Result<Iq3AMode>
    suspend fun fetchIq3AMode(functionMode: FunctionMode): Result<Iq3AMode>
    suspend fun setIq3AMode(functionMode: FunctionMode, mode: Iq3AMode): Result<Unit>

    suspend fun setPhotographyOptions(functionMode: FunctionMode, photographyOptions: Map<PhotographyOptionType, Any>): Result<Unit>

    suspend fun fetchPhotographyOptions(functionMode: FunctionMode, photographyOptionList: List<PhotographyOptionType>): Result<Unit>
    suspend fun fetchAllPhotographyOptions(): Result<Unit>
    suspend fun fetchAllPhotographyOptions(functionMode: FunctionMode): Result<Unit>
    suspend fun fetchMorePhotographyOptions(functionMode: FunctionMode, optionsTypes:List<PhotographyOptionType>): Result<Unit>

}