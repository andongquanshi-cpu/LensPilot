package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class PanoExposureMode(override val nativeValue: Int, val protoName: String) : BaseEnum {
    OFF(0, "off"),
    LIGHT_INDIVIDUAL(1, "light_individual"),
    INDIVIDUAL(2, "individual");

    companion object {
        fun nativeOf(value: Int?): PanoExposureMode = entries.firstOrNull { it.nativeValue == value } ?: OFF
        fun protoOf(name: String?): PanoExposureMode = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: OFF
    }
}