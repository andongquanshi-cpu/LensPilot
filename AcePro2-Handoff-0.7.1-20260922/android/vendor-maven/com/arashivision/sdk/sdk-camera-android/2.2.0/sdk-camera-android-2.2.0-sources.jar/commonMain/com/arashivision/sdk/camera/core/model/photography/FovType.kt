package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class FovType(override val nativeValue: Int, val protoName: String) : BaseEnum {
    WIDE(0, "WIDE"),
    LINEAR(1, "LINEAR"),
    ULTRAWIDE(2, "ULTRAWIDE"),
    NARROW(3, "NARROW"),
    ACTION_VIEW(4, "ACTION_VIEW"),
    LINEAR_PLUS(5, "LINEAR_PLUS"),
    LINEAR_HORIZON_45(6, "LINEARHORIZON_45"),
    FPV(7, "FPV"),
    SUPER(8, "SUPER"),
    TINY_PLANET(9, "TINYPLANET"),
    MAX_VIEW(10, "MAX_VIEW"),
    LINEAR_HORIZON_360(11, "LINEARHORIZON_360"),
    LINEAR_HORIZON(12, "LINEARHORIZON"),
    DE_WARP(13, "DEWARP"),
    MEGA_VIEW(14, "MEGA_VIEW");


    companion object {
        fun nativeOf(value: Int?): FovType = entries.firstOrNull { it.nativeValue == value } ?: WIDE
        fun protoOf(name: String?): FovType =
            entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: WIDE
    }
}