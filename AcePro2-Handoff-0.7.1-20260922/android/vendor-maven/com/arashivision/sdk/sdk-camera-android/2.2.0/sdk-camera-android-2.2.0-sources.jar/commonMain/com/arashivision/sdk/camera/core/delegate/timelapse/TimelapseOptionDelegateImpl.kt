package com.arashivision.sdk.camera.core.delegate.timelapse

import com.arashivision.sdk.camera.core.DeviceContext
import com.arashivision.sdk.camera.core.delegate.BaseDelegate
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.timelapse.TimelapseParams
import com.arashivision.sdk.common.callback.CoroutineCallback
import com.arashivision.sdk.common.callback.coroutineCallback
import com.arashivision.sdk.common.exception.TimelapseOptionValueNullException
import com.arashivision.sdk.common.kotlin.success
import insta360.messages.TimelapseOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

class TimelapseOptionDelegateImpl(deviceContext: DeviceContext) : BaseDelegate(deviceContext), TimelapseOptionDelegate {

    companion object {
        private const val TAG = "TimelapseOptionDelegateImpl"
    }

    private var timelapseCallbackMap: MutableMap<Long, CoroutineCallback<TimelapseOptions>> = mutableMapOf()
    private val timelapseCallbackMutex = Mutex()
    private var callbackMap: MutableMap<Long, CoroutineCallback<Unit>> = mutableMapOf()
    private val callbackMutex = Mutex()

    private val timelapseOptionCacheMutex = Mutex()
    private var timelapseOptionCache: MutableMap<Int, TimelapseOptions?> = mutableMapOf()


    override fun init() {
        context.scope.launch {
            context.transport.events.collect {
                when (it) {
                    //get timelapse option
                    is TransportEvent.GetTimelapseOptionsEvent.Success -> {
                        timelapseCallbackMutex.withLock { timelapseCallbackMap.remove(it.requestId) }?.onSuccess(it.timelapseOptions)
                    }

                    is TransportEvent.GetTimelapseOptionsEvent.Failed -> {
                        timelapseCallbackMutex.withLock { timelapseCallbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    //set timelapse option
                    is TransportEvent.SetTimelapseOptionsEvent.Success -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onSuccess(Unit)
                    }

                    is TransportEvent.SetTimelapseOptionsEvent.Failed -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    else -> {}
                }
            }
        }
    }

    override fun getTimelapseOption(timelapseMode: Int): Result<TimelapseParams> =
        timelapseOptionCache[timelapseMode]?.let {
            TimelapseParams(it.duration, it.lapseTime, it.accelerate_fequency).success()
        } ?: Result.failure(TimelapseOptionValueNullException(timelapseMode.toString()))

    override suspend fun setTimelapseOption(timelapseMode: Int, timelapseParams: TimelapseParams): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val timelapseOptions = TimelapseOptions(
                accelerate_fequency = timelapseParams.accelerateFrequency,
                duration = timelapseParams.durationS,
                lapseTime = timelapseParams.intervalMs,
            )
            val call = coroutineCallback<Unit> {
                success {
                    if (continuation.isActive) {
                        timelapseOptionCacheMutex.withLock { timelapseOptionCache[timelapseMode] = timelapseOptions }
                        continuation.resume(Result.success(Unit))
                    }
                }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }

            val id = context.transport.setTimelapseOption(timelapseMode, timelapseOptions)
            context.scope.launch {
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun fetchTimelapseOption(timelapseMode: Int): Result<TimelapseParams> {
        return suspendCancellableCoroutine { continuation ->
            val call = coroutineCallback<TimelapseOptions> {
                success {
                    if (continuation.isActive) {
                        timelapseOptionCacheMutex.withLock { timelapseOptionCache.put(timelapseMode, it) }
                        continuation.resume(TimelapseParams(it.duration, it.lapseTime, it.accelerate_fequency).success())
                    }
                }
                throwable { if (continuation.isActive) continuation.resume(Result.failure(it)) }
            }
            context.scope.launch {
                val id = context.transport.getTimelapseOption(timelapseMode)
                timelapseCallbackMutex.withLock {
                    timelapseCallbackMap[id] = call
                }
            }
        }
    }

    override suspend fun release() {
        callbackMutex.withLock { callbackMap.clear() }
        timelapseCallbackMutex.withLock { timelapseCallbackMap.clear() }
    }
}