package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import insta360.messages.OptionType

internal class FunctionModeCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<FunctionMode>(CommonAttrKeys.FUNCTION_MODE, managerProvider, deviceCoreProvider) {

    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<FunctionMode> {
        // 先尝试缓存；若无则同步子模式再尝试一次，保证首次进入也能拿到当前模式。
        var functionMode = device.functionMode
        when (device.getCameraType().getOrNull()) {
            CameraType.ONE_X -> {
                val modeInt = manager.currentFunctionModeInt().getOrNull()
                functionMode = if (modeInt != null) {
                    FunctionMode.nativeOf(modeInt)
                } else {
                    manager.setFunctionMode(FunctionMode.VIDEO_NORMAL.nativeValue)
                    FunctionMode.VIDEO_NORMAL
                }
            }

            else -> {
                if (functionMode == FunctionMode.NONE) {
                    device.fetchAllOptions().onSuccess {
                        functionMode = device.functionMode
                    }
                }

                if (functionMode == FunctionMode.NONE) {
                    manager.currentFunctionModeInt().onSuccess {
                        functionMode = FunctionMode.nativeOf(it)
                    }
                }
            }
        }
        return if (functionMode != FunctionMode.NONE) {
            manager.setFunctionMode(functionMode.nativeValue)
            Logger.i("CameraParamFactory", "reader Current FunctionMode: $functionMode")
            functionMode.success()
        } else {
            Logger.e("CameraParamFactory", "reader Cannot infer function mode from device")
            InvalidStateException("Cannot infer function mode from device").failure()
        }
    }

    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<FunctionMode> {
        return reader(manager, device)
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: FunctionMode): Result<Unit> {
        return device.switchFunctionMode(value).mapFailure {
            InvalidStateException("${it.message}: Cannot infer function mode from device")
        }.flatMap {
            manager.setFunctionMode(value.nativeValue)
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<FunctionMode>> {
        return manager.functionModeIds().flatMap { modes ->
            modes.mapNotNull { value ->
                runCatching { FunctionMode.nativeOf(value) }.getOrNull()
            }.filter { it.isCaptureSupported }.success()
        }
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<FunctionMode> {
        TODO("Not yet implemented")
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<FunctionMode> {
        TODO("Not yet implemented")
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: FunctionMode): Result<Unit> {
        TODO("Not yet implemented")
    }


}