package com.arashivision.sdk.camera.core.event

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationOperationType
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationResult
import com.arashivision.sdk.camera.core.model.authorization.AuthorizationStatus
import com.arashivision.sdk.camera.core.model.file.FileInfo
import com.arashivision.sdk.camera.core.model.notify.TempState
import insta360.messages.BatteryInfo
import insta360.messages.CameraCaptureStatus
import insta360.messages.CaptureStatus
import insta360.messages.ChargeboxConnectedStatus
import insta360.messages.MultiPhotographyOptions
import insta360.messages.NotificationCameraPostureUpdate
import insta360.messages.NotificationCaptureStopped
import insta360.messages.Options
import insta360.messages.PhotographyOptions
import insta360.messages.SensorDevice
import insta360.messages.TakePictureResponse
import insta360.messages.TimelapseOptions
import insta360.messages.Video
import insta360.messages.WindowCropInfo

/**
 * 对外的统一事件模型，面向 UI / 业务层。
 */
sealed interface TransportEvent {
    /**
     * 连接事件（推荐使用，替代粗粒度的状态事件）。
     */
    sealed interface ConnectionEvent : TransportEvent {
        data class Connected(val connectType: ConnectType) : ConnectionEvent
        data class Disconnected(val connectType: ConnectType, val throwable: Throwable? = null) : ConnectionEvent
        data class Failed(val connectType: ConnectType, val throwable: Throwable) : ConnectionEvent
    }

    /**
     *  蓝牙扫描事件
     */
    sealed interface ScanEvent : TransportEvent {
        object Started : ScanEvent
        data class Scanning(val bleDevice: BleDeviceCore) : ScanEvent
        data class Finished(val bleDeviceList: List<BleDeviceCore>) : ScanEvent
        data class Failed(val throwable: Throwable) : ScanEvent
    }

    /**
     *  获取Option
     */
    sealed interface GetOptionEvent : TransportEvent {
        data class Success(val requestId: Long, val options: Options) : GetOptionEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetOptionEvent
    }


    /**
     *  设置Option
     */
    sealed interface SetOptionEvent : TransportEvent {
        data class Success(val requestId: Long) : SetOptionEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetOptionEvent
    }

    /**
     *  获取Photography Option
     */
    sealed interface GetPhotographyOptionEvent : TransportEvent {
        data class Success(val requestId: Long, val photographyOptions: PhotographyOptions) : GetPhotographyOptionEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetPhotographyOptionEvent
    }

    /**
     *  设置Photography Option
     */
    sealed interface SetPhotographyOptionEvent : TransportEvent {
        data class Success(val requestId: Long) : SetPhotographyOptionEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetPhotographyOptionEvent
    }

    /**
     *  设置Option
     */
    sealed interface SwitchWifiChannelEvent : TransportEvent {
        data class Success(val requestId: Long) : SwitchWifiChannelEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SwitchWifiChannelEvent
    }

    /**
     *  低电量事件
     */
    data class BatteryLowEvent(val batteryInfo: BatteryInfo?) : TransportEvent

    /**
     * 温度事件
     */
    data class TemperatureEvent(val tempState: TempState) : TransportEvent

    /**
     *  存储事件
     */
    sealed interface StorageEvent : TransportEvent {
        object Update : StorageEvent
        object Full : StorageEvent
    }

    /**
     *  视频录制事件
     */
    data class RecordVideoEvent(val state: Int, val error: Int, val video: Video?) : TransportEvent

    /**
     *  拍摄张数通知事件
     */
    data class CameraTimelapseStatusNotifyEvent(val intervalCount: Int) : TransportEvent

    /**
     *  静态图像事件
     */
    data class StillImageEvent(val error: Int, val takePictureResponse: TakePictureResponse?) : TransportEvent

    /**
     *  Timelapse事件
     */
    data class TimelapseEvent(val state: Int, val error: Int, val video: Video?) : TransportEvent

    /**
     *  获取拍摄状态事件
     */
    sealed interface GetCaptureStatusEvent : TransportEvent {
        data class Success(val requestId: Long, val status: CameraCaptureStatus) : GetCaptureStatusEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetCaptureStatusEvent
    }

    /**
     *  拍摄中断通知
     */
    data class CameraCaptureStopedNotifyEvent(val notificationCaptureStopped: NotificationCaptureStopped) : TransportEvent

    /**
     *  拍摄状态通知事件
     */
    data class CameraCaptureStatusNotifyEvent(val status: CaptureStatus) : TransportEvent


    /**
     *  获取TimelapseOptions
     */
    sealed interface GetTimelapseOptionsEvent : TransportEvent {
        data class Success(val requestId: Long, val timelapseOptions: TimelapseOptions) : GetTimelapseOptionsEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetTimelapseOptionsEvent
    }

    /**
     *  设置TimelapseOptions
     */
    sealed interface SetTimelapseOptionsEvent : TransportEvent {
        data class Success(val requestId: Long) : SetTimelapseOptionsEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetTimelapseOptionsEvent
    }

    /**
     *  获取Sensor Mode
     */
    sealed interface GetSensorModeEvent : TransportEvent {
        data class Success(val requestId: Long, val sensorDevice: SensorDevice) : GetSensorModeEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetSensorModeEvent
    }

    /**
     *  设置Sensor Mode
     */
    sealed interface SetSensorModeEvent : TransportEvent {
        data class Success(val requestId: Long) : SetSensorModeEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetSensorModeEvent
    }

    /**
     *  获取文件列表信息事件
     */
    sealed interface GetFileInfoEvent : TransportEvent {
        data class Success(val requestId: Long, val fileInfoList: List<FileInfo>) : GetMediaFileListEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetMediaFileListEvent
    }

    /**
     *  获取文件列表事件
     */
    sealed interface GetMediaFileListEvent : TransportEvent {
        data class Success(val requestId: Long, val uri: List<String>, val count: Int) : GetMediaFileListEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetMediaFileListEvent
    }

    /**
     *  删除文件列表事件
     */
    sealed interface DeleteMediaFileListEvent : TransportEvent {
        data class Success(val requestId: Long) : DeleteMediaFileListEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : DeleteMediaFileListEvent
    }

    /**
     *  获取相机文件事件
     */
    sealed interface GetCameraFileListEvent : TransportEvent {
        data class Success(val requestId: Long, val filePath: String, val version: Int) : GetCameraFileListEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetCameraFileListEvent
    }

    /**
     *  打包相机日志文件
     */
    sealed interface PackCameraLogFileEvent : TransportEvent {
        data class Success(val requestId: Long, val filePath: String) : PackCameraLogFileEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : PackCameraLogFileEvent
    }

    /**
     *  盒子连接状态更新事件
     */
    data class ChargeBoxConnectStatusUpdateEvent(val chargeBoxConnectedStatus: ChargeboxConnectedStatus) : TransportEvent

    /**
     *  盒子充电状态更新事件
     */
    data class ChargeBoxBatteryUpdateEvent(val batteryInfo: BatteryInfo?) : TransportEvent

    /**
     *  充电状态更新事件
     */
    data class BatteryUpdateEvent(val batteryInfo: BatteryInfo?) : TransportEvent

    /**
     * Wi-Fi重启事件
     */
    sealed interface ResetCameraWiFiEvent : TransportEvent {
        data class Success(val requestId: Long) : ResetCameraWiFiEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : ResetCameraWiFiEvent
    }

    /**
     * Wi-Fi开启事件
     */
    sealed interface OpenCameraWiFiEvent : TransportEvent {
        data class Success(val requestId: Long) : OpenCameraWiFiEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : OpenCameraWiFiEvent
    }

    /**
     * Wi-Fi关闭事件
     */
    sealed interface CloseCameraWiFiEvent : TransportEvent {
        data class Success(val requestId: Long) : CloseCameraWiFiEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : CloseCameraWiFiEvent
    }

    /**
     * 设置Wi-Fi模式事件（AP / Aware 等）
     */
    sealed interface SetWifiModeEvent : TransportEvent {
        data class Success(val requestId: Long) : SetWifiModeEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetWifiModeEvent
    }

    /**
     * 校准陀螺仪事件
     */
    sealed interface CalibrateGyroEvent : TransportEvent {
        data class Success(val requestId: Long) : CalibrateGyroEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : CalibrateGyroEvent
    }

    /**
     * 格式化SD卡事件
     */
    sealed interface EraseSdCardEvent : TransportEvent {
        data class Success(val requestId: Long) : EraseSdCardEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : EraseSdCardEvent
    }

    /**
     * 格式化存储事件
     */
    sealed interface FormatStorageEvent : TransportEvent {
        data class Success(val requestId: Long) : FormatStorageEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : FormatStorageEvent
    }

    /**
     * 设置主存储
     */
    sealed interface SetMainStorageEvent : TransportEvent {
        data class Success(val requestId: Long) : SetMainStorageEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetMainStorageEvent
    }

    sealed interface SetMultiVideoModeEvent : TransportEvent {
        data class Success(val requestId: Long) : SetMultiVideoModeEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetMultiVideoModeEvent
    }

    sealed interface GetMultiVideoModeEvent : TransportEvent {
        data class Success(val requestId: Long, val options: MultiPhotographyOptions) : GetMultiVideoModeEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : GetMultiVideoModeEvent
    }

    sealed interface SetLockScreenStateEvent : TransportEvent {
        data class Success(val requestId: Long) : SetLockScreenStateEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : SetLockScreenStateEvent
    }

    /**
     * 预览开始旋转事件
     */
    data class LiveViewBeginRotateEvent(val cameraPostureUpdate: NotificationCameraPostureUpdate) : TransportEvent

    sealed interface LiveStreamEvent : TransportEvent {
        data class Success(val requestId: Long) : LiveStreamEvent
        data class Failed(val requestId: Long, val errorCode: Int) : LiveStreamEvent
        data class Stopped(val requestId: Long) : LiveStreamEvent
        data class ParamsUpdate(
            val requestId: Long,
            val windowCropInfo: WindowCropInfo?,
            val halfWindowCropInfo: WindowCropInfo?,
        ) : LiveStreamEvent
    }

    /**
     * checkAuthorization 命令应答事件。
     */
    sealed interface CheckAuthorizationEvent : TransportEvent {
        data class Success(val requestId: Long, val status: AuthorizationStatus) : CheckAuthorizationEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : CheckAuthorizationEvent
    }

    /**
     * 授权命令应答事件（requestAuthorization / cancelAuthorization / cancelRequestAuthorization）。
     */
    sealed interface AuthorizationCommandEvent : TransportEvent {
        data class Success(val requestId: Long) : AuthorizationCommandEvent
        data class Failed(val requestId: Long, val throwable: Throwable) : AuthorizationCommandEvent
    }

    /**
     * 相机端主动推送的授权结果通知（NOTIFY_AUTHORIZATION）。
     */
    data class NotifyAuthorizationEvent(
        val operationType: AuthorizationOperationType,
        val result: AuthorizationResult,
    ) : TransportEvent
}

