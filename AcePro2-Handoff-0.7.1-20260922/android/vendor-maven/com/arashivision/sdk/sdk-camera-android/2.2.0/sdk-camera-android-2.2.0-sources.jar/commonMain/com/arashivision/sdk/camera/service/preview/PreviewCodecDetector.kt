package com.arashivision.sdk.camera.service.preview

internal object PreviewCodecDetector {
    fun detectVideoCodec(data: ByteArray): StreamEncodeType? {
        var offset = 0
        var nalCount = 0
        while (offset < data.size && nalCount < 4) {
            val startCodeOffset = findStartCodeOffset(data, offset) ?: return null
            val nalOffset = startCodeOffset + startCodeSize(data, startCodeOffset)
            if (nalOffset >= data.size) return null

            detectVideoCodecByNal(data, nalOffset)?.let { return it }
            offset = nalOffset + 1
            nalCount += 1
        }
        return null
    }

    private fun detectVideoCodecByNal(
        data: ByteArray,
        nalOffset: Int,
    ): StreamEncodeType? {
        val h264NalType = data[nalOffset].toInt() and 0x1F
        if (h264NalType == 5 || h264NalType == 7 || h264NalType == 8) {
            return StreamEncodeType.H264
        }

        if (nalOffset + 1 < data.size) {
            val h265NalType = (data[nalOffset].toInt() and 0x7E) shr 1
            val h265TemporalIdPlus1 = data[nalOffset + 1].toInt() and 0x07
            if (h265TemporalIdPlus1 != 0 && (h265NalType == 32 || h265NalType == 33 || h265NalType == 34)) {
                return StreamEncodeType.H265
            }
        }

        return null
    }

    private fun findStartCodeOffset(
        data: ByteArray,
        startOffset: Int,
    ): Int? {
        var index = startOffset
        while (index + 3 < data.size) {
            if (data[index] == 0.toByte() && data[index + 1] == 0.toByte()) {
                val isThreeByteStartCode = data[index + 2] == 1.toByte()
                val isFourByteStartCode =
                    index + 4 < data.size && data[index + 2] == 0.toByte() && data[index + 3] == 1.toByte()
                if (isThreeByteStartCode || isFourByteStartCode) {
                    return index
                }
            }
            index += 1
        }
        return null
    }

    private fun startCodeSize(
        data: ByteArray,
        startCodeOffset: Int,
    ): Int = if (data[startCodeOffset + 2] == 1.toByte()) 3 else 4
}
