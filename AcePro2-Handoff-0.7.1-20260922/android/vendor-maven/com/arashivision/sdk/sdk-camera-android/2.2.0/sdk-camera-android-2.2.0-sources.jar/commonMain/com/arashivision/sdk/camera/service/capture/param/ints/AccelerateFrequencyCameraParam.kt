package com.arashivision.sdk.camera.service.capture.param.ints

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class AccelerateFrequencyCameraParam(managerProvider: () -> Result<CameraAttributeManager>, deviceCoreProvider: () -> Result<DeviceCore>) :
    IntCameraParam(CommonAttrKeys.ACCELERATE_FREQUENCY, managerProvider, deviceCoreProvider) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return device.getAccelerateFrequency(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return device.fetchAccelerateFrequency(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Int): Result<Unit> {
        return device.setAccelerateFrequency(functionMode, value)
    }

}