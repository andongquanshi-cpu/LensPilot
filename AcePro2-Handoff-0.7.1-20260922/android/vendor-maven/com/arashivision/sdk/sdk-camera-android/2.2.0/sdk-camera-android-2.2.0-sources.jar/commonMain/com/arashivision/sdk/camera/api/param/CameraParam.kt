package com.arashivision.sdk.camera.api.param

/**
 * 通用相机参数接口。
 *
 * 提供了对相机各项参数（如分辨率、白平衡、ISO 等）进行读取、写入、获取支持列表以及监听参数变化的功能。
 * 采用挂起函数设计，确保在 Kotlin Multiplatform (KMP) 两端具有一致的异步调用体验。
 *
 * @param T 参数值的具体类型（如 Int, Boolean, 枚举等）。
 */
interface CameraParam<T> {

    /**
     * 读取当前参数的值。
     *
     * @return 包含当前参数值的 [Result] 对象。
     */
    suspend fun getValue(): Result<T>

    /**
     * 从相机读取当前参数的值。
     *
     * @return 包含当前参数值的 [Result] 对象。
     */
    suspend fun fetchValue(): Result<T>

    /**
     * 写入（设置）新的参数值。
     *
     * 成功写入后，会自动触发已注册的本地监听器。
     *
     * @param value 要设置的新参数值。
     * @return 包含写入结果的 [Result] 对象。
     */
    suspend fun setValue(value: T): Result<Unit>

    /**
     * 获取当前相机模式下该参数支持的所有可选值列表。
     *
     * @return 包含支持值列表的 [Result] 对象。
     */
    suspend fun getSupported(): Result<List<T>>

    /**
     * 获取当前参数的名称标识。
     *
     * @return 参数的字符串名称。
     */
    fun getName(): String

    /**
     * 订阅参数变化回调。
     *
     * 注意：该回调仅在通过本 SDK 成功写入参数后触发，用于通知 UI 或其他模块参数已更新。
     *
     * @param listener 参数变化时的回调函数。
     */
    fun addListener(listener: (T) -> Unit)

    /**
     * 取消订阅参数变化回调。
     *
     * @param listener 需要移除的回调函数。
     */
    fun removeListener(listener: (T) -> Unit)

// TODO:() 新增内部比较
}
