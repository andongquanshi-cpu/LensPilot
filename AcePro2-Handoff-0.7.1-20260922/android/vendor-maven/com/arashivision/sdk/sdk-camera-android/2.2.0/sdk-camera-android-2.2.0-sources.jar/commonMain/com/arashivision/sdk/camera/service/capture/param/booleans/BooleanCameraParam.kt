package com.arashivision.sdk.camera.service.capture.param.booleans

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success

internal abstract class BooleanCameraParam(
    name: String,
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<Boolean>(name, managerProvider, deviceCoreProvider) {

    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<Boolean> {
        fun parseLocal(): Result<Boolean> = manager.getAttrValue(key).flatMap { raw ->
            raw.toBooleanStrictOrNull()?.success()
                ?: raw.toIntOrNull()?.let { (it != 0).success() }
                ?: NumberConversionException("Attribute '$key' cannot be parsed as Boolean").failure()
        }
        return currentFunctionMode()
            .flatMap { mode ->
                readFormCamera(device, mode)
            }.mapFailure { invalidStateException(it, key) }
            .onSuccess {
                manager.setAttrValue(key, it.toString())
            }.takeIf { it.isSuccess } ?: parseLocal()
    }

    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<Boolean> {
        fun parseLocal(): Result<Boolean> = manager.getAttrValue(key).flatMap { raw ->
            raw.toBooleanStrictOrNull()?.success()
                ?: raw.toIntOrNull()?.let { (it != 0).success() }
                ?: NumberConversionException("Attribute '$key' cannot be parsed as Boolean").failure()
        }
        return currentFunctionMode()
            .flatMap { mode ->
                fetchFormCamera(device, mode)
            }.mapFailure { invalidStateException(it, key) }
            .onSuccess {
                manager.setAttrValue(key, it.toString())
            }.takeIf { it.isSuccess } ?: parseLocal()
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: Boolean): Result<Unit> {
        return currentFunctionMode()
            .flatMap {
                writeToCamera(device, it, value)
            }.onSuccess {
                manager.setAttrValue(key, value.toString())
            }.mapFailure { ex ->
                InvalidStateException("${ex.message}: device error")
            }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<Boolean>> {
        return manager.attributeOptions(key).flatMap { opts ->
            opts.mapNotNull { it.toBooleanStrictOrNull() ?: it.toIntOrNull()?.let { num -> num != 0 } }
                .takeIf { it.isNotEmpty() }
                ?.success()
                ?: NumberConversionException("No valid boolean options for $key").failure()
        }
    }


}