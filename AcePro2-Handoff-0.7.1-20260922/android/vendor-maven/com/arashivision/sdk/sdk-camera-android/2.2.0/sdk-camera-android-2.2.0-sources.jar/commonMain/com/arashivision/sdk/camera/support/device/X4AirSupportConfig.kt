package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewRenderModel
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class X4AirPanoramaSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewRenderModelType = PreviewRenderModel.SPHERE_STITCH
    override val previewFitMode = PreviewFitMode.FIT_10
    override val previewGyroType = PreviewGyroType.X3_FISHEYE
    override val previewStabType: PreviewStabType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewStabType.STAB_FULL_DIRECTIONAL else PreviewStabType.STAB_STILL
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val previewFileType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewFileType.SPECIAL_SELFIE else PreviewFileType.VR360
    override val isDynamicAlphaSupported: Boolean = true
    override val isBlendUsingFisheyeMaskSupported: Boolean = true
    override val isSupportUpFlowV2: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1280_960_30FPS,
            secondStream = StreamResolution.STREAM_424_240_15FPS,
            previewNum = 0,
        )
}

class X4AirSingleLenSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val isRotateScreenRatioEnabled: Boolean = snapshot.functionMode != FunctionMode.VIDEO_SELFIE
    override val previewGyroType
        get() = resolveX3FamilyPreviewGyroType()
    override val isDynamicAlphaSupported: Boolean = true
    override val isBlendUsingFisheyeMaskSupported: Boolean = true
    override val isSupportUpFlowV2: Boolean = true

    override val previewFitMode
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFitMode.FIT_10
                snapshot.functionMode == FunctionMode.PHOTO_NORMAL ||
                    snapshot.functionMode == FunctionMode.VIDEO_SUPER -> PreviewFitMode.FIT_10
                else -> PreviewFitMode.COVER
            }

    override val previewStabType: PreviewStabType
        get() = if (isFlowStateEnabledForPreview()) PreviewStabType.STAB_OFF else PreviewStabType.STAB_FULL_DIRECTIONAL

    override val previewFileType
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFileType.SPECIAL_SELFIE
                snapshot.functionMode == FunctionMode.PHOTO_NORMAL ||
                    snapshot.functionMode == FunctionMode.VIDEO_SUPER -> PreviewFileType.FISH_EYE
                else -> PreviewFileType.UNPANORAMA
            }
    override val previewRenderModelType: PreviewRenderModel
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewRenderModel.SPHERE_STITCH
                isFlowStateEnabledForPreview() -> PreviewRenderModel.PLANE
                else -> PreviewRenderModel.SPHERE_FISHEYE_DEWARP
            }

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1280_960_30FPS,
            secondStream = StreamResolution.STREAM_424_240_15FPS,
            previewNum = 0,
        )
}
