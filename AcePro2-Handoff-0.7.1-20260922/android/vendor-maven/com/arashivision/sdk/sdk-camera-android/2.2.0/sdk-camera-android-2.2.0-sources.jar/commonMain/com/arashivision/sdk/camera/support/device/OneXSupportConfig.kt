package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class OneXSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.NONE
    override val previewFileType = PreviewFileType.VR360
    override val previewGyroType = PreviewGyroType.ONE_X

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_960_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_5760_2880_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_2176_1088_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )
        }
}
