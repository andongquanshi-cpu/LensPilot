package com.arashivision.sdk.camera.support

import com.arashivision.sdk.bridge.shared.preview.CameraPreviewConstraintData
import com.arashivision.sdk.bridge.shared.preview.CameraPreviewOffsetData
import com.arashivision.sdk.bridge.shared.preview.CaptureSupportPreviewParams
import com.arashivision.sdk.bridge.shared.preview.CaptureSupportPreviewStream
import com.arashivision.sdk.bridge.shared.preview.ICaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewRenderModel
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.platform.CameraAssetInfoRequest
import com.arashivision.sdk.camera.platform.buildPreviewAssetInfo
import com.arashivision.sdk.camera.platform.buildStabAssetInfo
import com.arashivision.sdk.common.type.KMPAssetInfo
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

abstract class CaptureSupportConfig(
    protected val cameraConfig: ICameraConfig,
    protected val snapshot: CameraRuntimeSnapshot,
) : ICaptureSupportConfig {

    private val resolvedCameraType = snapshot.cameraType
    private val defaultPreviewParams by lazy {
        buildPreviewParams(
            isForLive = false,
            isForRecord = false
        )
    }
    private val defaultPreviewStream by lazy { defaultPreviewParams.selectedStream() }
    private val previewMediaOffset: String = snapshot.mediaOffsetV1
    override val previewWidth: Int = defaultPreviewStream.width
    override val previewHeight: Int = defaultPreviewStream.height
    override val previewFps: Int = defaultPreviewStream.fps
    override val previewCameraType: String =
        snapshot.cameraType.type.ifBlank { snapshot.cameraType.simpleName }

    override val mediaOffset: CameraPreviewOffsetData =
        CameraPreviewOffsetData(
            offsetV1 = snapshot.mediaOffsetV1,
            offsetV2 = snapshot.mediaOffsetV2,
            offsetV3 = snapshot.mediaOffsetV3,
            offsetState = snapshot.offsetState,
            offsetDetectedType = snapshot.offsetDetectedType,
            offsetV6 = snapshot.mediaOffsetV6,
        )

    override fun getPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
        isVideo: Boolean
    ): CaptureSupportPreviewParams =
        buildPreviewParams(isForLive, isForRecord, isVideo).toCommonPreviewParams()

    override val previewScreenRatio: Pair<Int, Int> = normalizeRatio(previewWidth, previewHeight)

    override val previewFileType: PreviewFileType
        get() = resolveFileType(resolvedCameraType, isSelfie)

    override val previewFitMode: PreviewFitMode
        get() = if (resolvedCameraType.isPanoramaCamera()) PreviewFitMode.NONE else PreviewFitMode.CONTAIN

    // 平台组可以自己知道GyroType，不再需要app配置
    // 设置了具体GyroType的底层会直接用，传 UNKNOWN 底层就会自己分析
    override val previewGyroType: PreviewGyroType = PreviewGyroType.UNKNOWN

    override val previewStitchType: PreviewStitchType
        get() = resolveStitchType(resolvedCameraType)

    override val previewStabType: PreviewStabType
        get() = if (resolvedCameraType.isPanoramaCamera()) PreviewStabType.STAB_STILL else PreviewStabType.STAB_FREE_FOOTAGE

    override val previewRenderModelType: PreviewRenderModel
        get() = resolvePreviewRenderModelType(previewFileType, snapshot.functionMode)
    override val isRotateEnabled: Boolean = false
    override val isRotateScreenRatioEnabled: Boolean = false
    override val isFlowstateOn: Boolean = snapshot.isFlowstateOn
    override val isStabilizeEnabled: Boolean
        get() = !isFlowStateEnabledForPreview()

    override val isGestureEnabledByMode: Boolean
        get() =
            resolveGestureEnabledByMode(
                resolvedCameraType,
                snapshot.functionMode,
                snapshot.isPanoramaLens(),
            )

    override val isImageFusionEnabled: Boolean = false
    override val isDualStream: Boolean =
        cameraConfig.isDualStream(
            RecordResolution.of(
                defaultPreviewParams.firstStream.width,
                defaultPreviewParams.firstStream.height,
                defaultPreviewParams.firstStream.fps,
            ),
        )
    override val isFishEyeEdgePaddingEnabled: Boolean = false
    override val isBlendAngleOptimizeEnabled: Boolean = false
    override val isPowerPanoEnabled: Boolean = false

    override val isDynamicAlphaSupported: Boolean
        get() = resolvedCameraType in DYNAMIC_ALPHA_SUPPORTED_TYPES

    override val isBlendUsingFisheyeMaskSupported: Boolean
        get() = resolvedCameraType in DYNAMIC_ALPHA_SUPPORTED_TYPES

    override val isSupportUpFlowV2: Boolean
        get() = resolvedCameraType in DYNAMIC_ALPHA_SUPPORTED_TYPES

    override val isSelfie: Boolean = snapshot.isSelfie
    override val previewDeltaNs: Long = 0L
    override val frameDurationMs: Int = if (previewFps > 0) 1000 / minOf(previewFps, 30) else 33
    override val stabOffset: String = snapshot.stabOffset.ifBlank { "" }

    override val constraintData: CameraPreviewConstraintData =
        CameraPreviewConstraintData(
            widthRatio = previewScreenRatio.first,
            heightRatio = previewScreenRatio.second,
            minFov = 20f,
            maxFov = 120f,
            defaultFov = 54f,
            minDistance = 100f,
            maxDistance = 800f,
            defaultDistance = 800f,
        )

    private val assetInfoRequest by lazy {
        CameraAssetInfoRequest(
            cameraType = snapshot.cameraType,
            functionMode = snapshot.functionMode,
            previewWidth = defaultPreviewStream.width,
            previewHeight = defaultPreviewStream.height,
            previewFps = defaultPreviewStream.fps,
            mediaOffset = previewMediaOffset,
            mediaOffsetV3 = snapshot.mediaOffsetV3,
            mediaOffsetV6 = snapshot.mediaOffsetV6,
            isSelfie = snapshot.isSelfie,
            windowCropInfo = snapshot.windowCropInfo,
            halfWindowCropInfo = snapshot.halfWindowCropInfo,
        )
    }

    override val previewAssetInfo: KMPAssetInfo? by lazy {
        buildPreviewAssetInfo(assetInfoRequest)
    }

    override val stabAssetInfo: KMPAssetInfo? by lazy {
        buildStabAssetInfo(assetInfoRequest)
    }

    // 目前仅 go3s 视频和图片不一样
    protected open fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
        isVideo: Boolean = false
    ): CameraPreviewParams = buildPreviewParams(isForLive, isForRecord)

    protected open fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        previewParams(
            firstStream = StreamResolution.STREAM_1280_960_30FPS,
            secondStream = StreamResolution.STREAM_424_240_15FPS,
            previewNum = 0,
        )

    protected fun previewParams(
        firstStream: StreamResolution,
        secondStream: StreamResolution,
        previewNum: Int,
    ): CameraPreviewParams = CameraPreviewParams(firstStream, secondStream, previewNum)

    protected fun configuredFirstStream(
        isForLive: Boolean,
        isForRecord: Boolean,
        fallback: StreamResolution,
    ): StreamResolution = fallback

    protected fun currentRecordStream(): StreamResolution? =
        snapshot.currentRecordResolution?.let {
            StreamResolution.getFromResolution(it.width, it.height, it.fps)
        }

    protected fun resolveFileType(cameraType: CameraType, isSelfie: Boolean): PreviewFileType =
        when {
            isSelfie && !cameraType.isPanoramaCamera() -> PreviewFileType.SPECIAL_SELFIE
            cameraType.isPanoramaCamera() -> PreviewFileType.VR360
            cameraType.isWideAngleCamera() -> PreviewFileType.WIDE_ANGLE
            else -> PreviewFileType.UNPANORAMA
        }

    protected fun resolveStitchType(cameraType: CameraType): PreviewStitchType =
        when (cameraType) {
            // 行业不支持 ai 拼接
//            CameraType.X4,
//            CameraType.X4_AIR,
//            CameraType.X5,
//            -> PreviewStitchType.AI_FLOW

            CameraType.UNKNOWN -> PreviewStitchType.NORMAL
            else -> PreviewStitchType.OPTICAL_FLOW
        }

    protected fun resolvePreviewRenderModelType(
        previewFileType: PreviewFileType,
        functionMode: FunctionMode,
    ): PreviewRenderModel =
        when {
            functionMode == FunctionMode.VIDEO_SELFIE -> PreviewRenderModel.SPHERE_STITCH
            previewFileType == PreviewFileType.VR360 -> PreviewRenderModel.SPHERE_STITCH
            previewFileType == PreviewFileType.UNPANORAMA -> PreviewRenderModel.PLANE
            else -> PreviewRenderModel.SPHERE_FISHEYE_DEWARP
        }

    protected fun resolveOneX2PreviewGyroType(): PreviewGyroType =
        when {
            snapshot.isSelfie && isFlowStateEnabledForPreview() -> PreviewGyroType.ONE_X2_REVERSE
            snapshot.isSelfie -> PreviewGyroType.ONE_X2_Z180
            else -> PreviewGyroType.ONE_X2
        }

    protected fun resolveX3FamilyPreviewGyroType(): PreviewGyroType =
        if (snapshot.functionMode == FunctionMode.VIDEO_SELFIE) {
            PreviewGyroType.X3_Z180
        } else {
            PreviewGyroType.X3_FISHEYE
        }

    protected fun resolveOneRFisheyePreviewGyroType(): PreviewGyroType =
        if (snapshot.isSelfie) {
            PreviewGyroType.ONE_R_FISHEYE_REVERSE
        } else {
            PreviewGyroType.ONE_R_FISHEYE
        }

    protected fun resolveOneRs283PanoramaPreviewGyroType(): PreviewGyroType =
        if (snapshot.isSelfie) {
            PreviewGyroType.ONE_RS_PANO_283_REVERSE
        } else {
            PreviewGyroType.ONE_RS_PANO_283
        }

    protected fun isVerticalPreview(): Boolean =
        defaultPreviewStream.height > defaultPreviewStream.width

    protected fun isFlowStateEnabledForPreview(): Boolean =
        snapshot.isFlowstateOn

    private fun CameraPreviewParams.toCommonPreviewParams(): CaptureSupportPreviewParams =
        CaptureSupportPreviewParams(
            firstStream =
                CaptureSupportPreviewStream(
                    width = firstStream.width,
                    height = firstStream.height,
                    fps = firstStream.fps,
                ),
            secondStream =
                CaptureSupportPreviewStream(
                    width = secondStream.width,
                    height = secondStream.height,
                    fps = secondStream.fps,
                ),
            previewNum = previewNum,
        )

    private fun CameraPreviewParams.selectedStream(): StreamResolution =
        if (previewNum == 0) firstStream else secondStream

    companion object {
        protected val DYNAMIC_ALPHA_SUPPORTED_TYPES =
            setOf(
                CameraType.X4,
                CameraType.X4_AIR,
                CameraType.X5,
            )

        protected fun normalizeRatio(width: Int, height: Int): Pair<Int, Int> {
            if (width <= 0 || height <= 0) {
                return 16 to 9
            }
            val divisor = gcd(width, height)
            return (width / divisor) to (height / divisor)
        }

        private tailrec fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

        protected fun resolveGestureEnabledByMode(
            cameraType: CameraType,
            functionMode: FunctionMode,
            isPanoramaLens: Boolean,
        ): Boolean {
            if (!cameraType.isPanoramaCamera()) return false
            return when (functionMode) {
                // 无模式 / 子弹时间不支持手势
                FunctionMode.NONE,
                FunctionMode.VIDEO_BULLET_TIME -> false
                // 自拍走球面拼接渲染，单镜头下也可拖动
                FunctionMode.VIDEO_SELFIE -> true
                // 其余模式仅全景镜头可拖动，单镜头为鱼眼/平面画面
                else -> isPanoramaLens
            }
        }
    }
}
