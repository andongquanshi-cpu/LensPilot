package com.arashivision.sdk.camera.api.param.listener

import com.arashivision.sdk.camera.core.model.option.BatteryData

/**
 * 相机电池状态监听器。
 *
 * 用于监听相机电池电量的变化以及低电量警告。
 */
interface BatteryListener {
    /**
     * 当相机电池电量发生变化时回调。
     *
     * @param batteryData 包含当前电量百分比、是否正在充电等信息的电池数据对象。
     */
    fun onBatteryLevelChange(batteryData: BatteryData)

    /**
     * 当相机电池电量过低时回调。
     * 收到此回调时，建议提示用户及时充电。
     */
    fun onLowBatteryWarning()
}
