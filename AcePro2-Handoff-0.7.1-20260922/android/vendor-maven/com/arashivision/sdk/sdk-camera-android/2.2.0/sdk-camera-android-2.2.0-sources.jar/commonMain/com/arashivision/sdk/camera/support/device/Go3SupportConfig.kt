package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewRenderModel
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType

internal class Go3SupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFileType: PreviewFileType
        get() =
            when {
                isFlowStateEnabledForPreview() -> PreviewFileType.UNPANORAMA
                snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME -> PreviewFileType.UNPANORAMA
                else -> PreviewFileType.FISH_EYE
            }
    override val previewFitMode
        get() = if (isFlowStateEnabledForPreview()) PreviewFitMode.FILL else PreviewFitMode.CONTAIN
    override val previewGyroType = PreviewGyroType.GO2
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewRenderModelType: PreviewRenderModel
        get() = if (isFlowStateEnabledForPreview()) PreviewRenderModel.PLANE else PreviewRenderModel.SPHERE_FISHEYE_DEWARP
    override val previewStabType: PreviewStabType
        get() = if (snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME) PreviewStabType.STAB_FREE_FOOTAGE else PreviewStabType.STAB_FULL_DIRECTIONAL
    override val isRotateEnabled: Boolean = false
    override val isRotateScreenRatioEnabled: Boolean = snapshot.functionMode == FunctionMode.VIDEO_BULLET_TIME
    override val isGestureEnabledByMode: Boolean = false
    override val isFishEyeEdgePaddingEnabled: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = currentRecordStream() ?: StreamResolution.STREAM_1280_720_30FPS,
                    secondStream = StreamResolution.STREAM_640_360_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = currentRecordStream() ?: StreamResolution.STREAM_2560_1440_30FPS,
                    secondStream = StreamResolution.STREAM_368_368_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_640_640_30FPS,
                    secondStream = StreamResolution.STREAM_368_368_30FPS,
                    previewNum = 0,
                )
        }
}
