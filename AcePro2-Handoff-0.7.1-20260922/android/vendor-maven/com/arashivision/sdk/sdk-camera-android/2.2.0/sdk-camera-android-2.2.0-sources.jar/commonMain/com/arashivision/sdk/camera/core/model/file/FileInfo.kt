package com.arashivision.sdk.camera.core.model.file

data class FileInfo(val url: String, val extraData: ByteArray)