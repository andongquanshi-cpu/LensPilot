package com.arashivision.sdk.camera.service.capture.param.other

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.common.exception.InvalidParameterException
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.pairToString
import com.arashivision.sdk.common.kotlin.parseToBurst
import com.arashivision.sdk.common.kotlin.success


internal class BurstCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<Pair<Int, Int>>(CommonAttrKeys.BURST_CAPTURE_PARAMS, managerProvider, deviceCoreProvider) {

    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<Pair<Int, Int>> {
        return currentFunctionMode().flatMap { mode ->
            // 优先从设备同步 num/time，再写回 manager 为 "num/time"
            readFormCamera(device, mode).flatMap { value ->
                manager.setAttrValue(key, value.pairToString())
                value.success()
            }
        }.takeIf { it.isSuccess } ?: manager.getAttrValue(key).flatMap { raw ->
            raw.parseToBurst()?.success()
                ?: NumberConversionException("Attribute '${key}' cannot be parsed").failure()
        }
    }

    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<Pair<Int, Int>> {
        return currentFunctionMode().flatMap { mode ->
            // 优先从设备同步 num/time，再写回 manager 为 "num/time"
            fetchFormCamera(device, mode).flatMap { value ->
                manager.setAttrValue(key, value.pairToString())
                value.success()
            }
        }.takeIf { it.isSuccess } ?: manager.getAttrValue(key).flatMap { raw ->
            raw.parseToBurst()?.success()
                ?: NumberConversionException("Attribute '${key}' cannot be parsed").failure()
        }
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: Pair<Int, Int>): Result<Unit> {
        return currentFunctionMode().flatMap { mode ->
            writeToCamera(device, mode, value)
        }.onSuccess {
            manager.setAttrValue(key, value.pairToString())
        }.mapFailure {
            InvalidStateException("${it.message}: device error")
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<Pair<Int, Int>>> {
        return manager.attributeOptions(key).flatMap { opts ->
            opts.mapNotNull { it.parseToBurst() }
                .takeIf { it.isNotEmpty() }
                ?.success()
                ?: NumberConversionException("No valid burst capture params options").failure()
        }
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Pair<Int, Int>> {
        return device.getBurstCaptureNum(functionMode).flatMap { num ->
            device.getBurstCaptureTime(functionMode).flatMap { time ->
                Pair(num, time).success()
            }
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Pair<Int, Int>> {
        return device.fetchBurstCaptureNum(functionMode).flatMap { num ->
            device.fetchBurstCaptureTime(functionMode).flatMap { time ->
                Pair(num, time).success()
            }
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Pair<Int, Int>): Result<Unit> {
        if (value.first == 0 || value.second == 0) {
            return InvalidParameterException(
                "BurstCaptureParams.UNKNOWN cannot be set"
            ).failure()
        }

        return device.setBurstCaptureParams(
            functionMode,
            value.first,
            value.second
        )
    }

}