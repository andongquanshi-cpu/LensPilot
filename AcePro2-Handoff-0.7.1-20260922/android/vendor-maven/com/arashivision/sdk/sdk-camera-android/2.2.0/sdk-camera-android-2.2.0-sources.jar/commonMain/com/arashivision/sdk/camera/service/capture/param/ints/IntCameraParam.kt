package com.arashivision.sdk.camera.service.capture.param.ints

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger

internal abstract class IntCameraParam(
    name: String,
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<Int>(name, managerProvider, deviceCoreProvider) {

    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<Int> {
        return currentFunctionMode().onSuccess {
            Logger.i(TAG, "intParam reader key=$key, mode=${it}")
        }.onFailure {
            Logger.e(TAG, "intParam reader key=$key failed to get mode: ${it.message}")
        }.flatMap { mode ->
            readFormCamera(device, mode).mapFailure { invalidStateException(it, key) }.onSuccess {
                manager.setAttrValue(key, it)
            }.flatMap {
                manager.getAttrValueInt(key)
            }
        }
    }

    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<Int> {
        return currentFunctionMode().onSuccess {
            Logger.i(TAG, "intParam reader key=$key, mode=${it}")
        }.onFailure {
            Logger.e(TAG, "intParam reader key=$key failed to get mode: ${it.message}")
        }.flatMap { mode ->
            fetchFormCamera(device, mode).mapFailure { invalidStateException(it, key) }.onSuccess {
                manager.setAttrValue(key, it)
            }.flatMap {
                manager.getAttrValueInt(key)
            }
        }
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: Int): Result<Unit> {
        return currentFunctionMode().onSuccess {
            Logger.i(TAG, "intParam writer key=$key, mode=${it}, value=$value")
        }.onFailure {
            Logger.e(TAG, "intParam writer key=$key failed to get mode: ${it.message}")
        }.flatMap { mode ->
            writeToCamera(device, mode, value).onSuccess {
                manager.setAttrValue(key, value)
                Logger.i(TAG, "intParam writer key=$key success, value=$value")
            }.mapFailure {
                InvalidStateException(it.message ?: "device error")
            }
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<Int>> {
        return manager.attributeOptions(key).flatMap { opts ->
            opts.mapNotNull { it.toIntOrNull() }
                .takeIf { it.isNotEmpty() }
                ?.success()
                ?: NumberConversionException("No valid int options for $key").failure()
        }
    }
}