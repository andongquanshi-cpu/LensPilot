package com.arashivision.sdk.camera.core.model.photography

data class ResolutionRecordLimit(var recordResolution: RecordResolution, var limit: Int)