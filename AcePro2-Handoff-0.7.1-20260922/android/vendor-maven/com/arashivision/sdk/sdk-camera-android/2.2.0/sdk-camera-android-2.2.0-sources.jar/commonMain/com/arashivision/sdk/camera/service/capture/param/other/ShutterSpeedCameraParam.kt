package com.arashivision.sdk.camera.service.capture.param.other

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.FunctionType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.fractionToString
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.kotlin.toFraction
import com.arashivision.sdk.common.log.Logger

internal class ShutterSpeedCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<Pair<Double, Double>>(CommonAttrKeys.EXPOSURE_SHUTTER_SPEED, managerProvider, deviceCoreProvider) {

    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<Pair<Double, Double>> {
        return currentFunctionMode().flatMap { mode ->
            readFormCamera(device, mode)
        }.onFailure {
            Logger.e(TAG, "exposureShutterParam reader failed: ${it.message}")
        }.onSuccess { it: Pair<Double, Double> ->
            // 缓存当前曝光到 manager
            manager.setAttrValue(CommonAttrKeys.EXPOSURE_SHUTTER_SPEED, it.fractionToString())
        }
    }

    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<Pair<Double, Double>> {
        return currentFunctionMode().flatMap { mode ->
            fetchFormCamera(device, mode)
        }.onFailure {
            Logger.e(TAG, "exposureShutterParam reader failed: ${it.message}")
        }.onSuccess { it: Pair<Double, Double> ->
            // 缓存当前曝光到 manager
            manager.setAttrValue(CommonAttrKeys.EXPOSURE_SHUTTER_SPEED, it.fractionToString())
        }
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: Pair<Double, Double>): Result<Unit> {
        return currentFunctionMode().onFailure {
            Logger.e(TAG, "exposureShutterParam writer failed to g et mode: ${it.message}")
        }.flatMap { mode ->
            writeToCamera(device, mode, value)
        }.mapFailure {
            InvalidStateException("${it.message}: device error")
        }.onSuccess {
            manager.setAttrValue(CommonAttrKeys.EXPOSURE_SHUTTER_SPEED, value.fractionToString())
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<Pair<Double, Double>>> {
        return manager.attributeOptions(CommonAttrKeys.EXPOSURE_SHUTTER_SPEED).flatMap { opts ->
            val parsed = opts.mapNotNull { value -> value.toFraction() }
            parsed.takeIf { it.isNotEmpty() }
                ?.success()
                ?: NumberConversionException("No valid shutter options for ${CommonAttrKeys.EXPOSURE_SHUTTER_SPEED}").failure()
        }.onSuccess {
            Logger.i("CameraParamFactory", "Current FunctionMode Success: $it")
        }.onFailure {
            Logger.e("CameraParamFactory", "Current FunctionMode Failure: $it")
        }
    }

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Pair<Double, Double>> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.getVideoExposure(functionMode)
        } else {
            device.getStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.map {
            it.shutterSpeed
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Pair<Double, Double>> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.fetchVideoExposure(functionMode)
        } else {
            device.fetchStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.map {
            it.shutterSpeed
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Pair<Double, Double>): Result<Unit> {
        return if (functionMode.functionType == FunctionType.VIDEO) {
            device.getVideoExposure(functionMode)
        } else {
            device.getStillExposure(functionMode)
        }.mapFailure {
            InvalidStateException("${it.message}: Exposure is null")
        }.flatMap {
            val updated = Exposure(it.program, it.iso, value)
            device.setStillExposure(functionMode, updated)
            device.setVideoExposure(functionMode, updated).thenMirrorVideoLiveIfNeeded(device, functionMode) {
                device.setVideoExposure(FunctionMode.VIDEO_LIVE, updated)
            }
        }
    }
}