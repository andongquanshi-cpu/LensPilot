package com.arashivision.sdk.camera.service.capture.json

import com.arashivision.sdk.common.exception.InvalidModeException
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.MissingAttributeException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.roundTo
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import kotlin.math.roundToInt

/**
 * CameraAttributeManager 的具体实现，负责维护镜头/模式和属性值状态。
 */
internal class CameraAttributeManagerImpl private constructor(
    private val functionCatalog: CameraFunctionCatalog,
    private val protoCatalog: CameraProtoCatalog
) : CameraAttributeManager {
    /** 当前镜头，未选择时为 null。 */
    private var lensType: String? = null

    /** 当前拍摄模式，依赖镜头，未选择时为 null。 */
    private var captureMode: String? = null

    /** 属性值缓存，仅存储字符串表示，读取时再根据需求转换。 */
    private val attrValues: MutableMap<String, String> = mutableMapOf()

    /**
     * 统一工厂：负责解析 JSON，并在成功后构建实现类。
     * 由于 [CameraAttributeManager] 只暴露接口，实际初始化入口也放在 companion 内，避免外部直接 new。
     */
    companion object {
        fun fromJsonStrings(attrJson: String, protoJson: String): Result<CameraAttributeManager> = buildManager(attrJson, protoJson)

        private fun buildManager(attrJson: String, protoJson: String): Result<CameraAttributeManager> {
            val functionResult = CameraFunctionCatalog.fromJson(attrJson)
            val protoResult = CameraProtoCatalog.fromJson(protoJson)
            return functionResult.flatMap { function ->
                protoResult.flatMap { proto ->
                    CameraAttributeManagerImpl(function, proto).success()
                }
            }
        }
    }

    // region Lens & Mode

    override fun currentLensType(): Result<String> = lensType?.let {
        Result.success(it)
    } ?: Result.failure(InvalidStateException("Lens type not selected"))

    override fun currentFunctionMode(): Result<String> = captureMode?.let {
        Result.success(it)
    } ?: Result.failure(InvalidStateException("Capture mode not selected"))


    override fun currentAttributeValues(): Result<Map<String, String>> = Result.success(attrValues.toMap())

    /**
     * 直接从 FunctionCatalog 读取镜头枚举，无状态依赖。
     */
    override fun lensTypes(): List<String> = functionCatalog.lensTypes()

    /**
     * 选择镜头后，会清空模式与属性缓存，确保不会混用不同镜头下的旧值。
     */
    override fun setLensType(lens: String): Result<Unit> {
        return functionCatalog.functionModes(lens).map {
            if (lensType != lens) {
                lensType = lens
                captureMode = null
                attrValues.clear()
            }
            Unit.success()
        }
    }

    /**
     * 读取当前镜头像下的模式列表；通过 [withLens] 保证已选镜头。
     */
    override fun functionModes(): Result<List<String>> = withLens { lens ->
        functionCatalog.functionModes(lens)
    }

    /**
     * 读取当前镜头像下的模式 ID 列表；与 functionModes 对应的 proto 数值。
     */
    override fun functionModeIds(): Result<List<Int>> = withLens { lens ->
        functionCatalog.functionModes(lens).flatMap {
            // 3. 遍历模式名称，逐个转换为Int，失败则立即返回
            val ids = mutableListOf<Int>()
            for (name in it) {
                protoCatalog.intFor(CAPTURE_FUNCTION_MODE, name).fold(
                    onSuccess = { id -> ids.add(id) },
                    onFailure = { t ->
                        Logger.e("CameraAttributeManagerImpl", "Not Find functionModeIds for name: $name")
                        return@flatMap t.failure<List<Int>>()
                    }
                )
            }
            // 4. 全部转换成功，返回Int列表的Success Result
            ids.success()
        }
    }

    /**
     * 根据模式名切换，先校验该模式是否存在于镜头像的配置，再写入状态。
     */
    override fun setFunctionMode(mode: String): Result<Unit> = withLens { lens ->
        functionCatalog.functionModes(lens).flatMap {
            if (mode !in it) {
                InvalidModeException(mode).failure()
            } else {
                captureMode = mode
                Unit.success()
            }
        }
    }

    /**
     * 通过 proto 数值切换模式，内部先反查到模式名后复用 [setFunctionMode]。
     */
    override fun setFunctionMode(modeValue: Int): Result<Unit> = withLens { lens ->
        functionCatalog.functionModes(lens).flatMap { modeNames ->
            val matched = modeNames.firstOrNull { name ->
                protoCatalog.intFor(CAPTURE_FUNCTION_MODE, name).getOrNull() == modeValue
            }
            matched?.let { setFunctionMode(it) }
                ?: InvalidModeException(modeValue.toString()).failure()
        }
    }


    /**
     * 将当前模式映射成 proto 数值，如果尚未设置模式会返回 InvalidState。
     */
    override fun currentFunctionModeInt(): Result<Int> {
        return currentFunctionMode().flatMap {
            protoCatalog.intFor(CAPTURE_FUNCTION_MODE, it)
        }
    }

    // endregion

    // region Attribute Options

    /**
     * 获取当前镜头+模式支持的属性集合。
     */
    override fun supportedAttributes(): Result<List<String>> = withLensAndMode { lens, mode ->
        functionCatalog.supportedAttributes(lens, mode)
    }

    /**
     * 计算属性可选项，优先根据依赖组合查询，若无结果则回落 default。
     *
     * 排查提示：dependencyKey 取自 [attrValues] 缓存里依赖属性“当前已知”的值，而不是重新去读相机实时状态。
     * 若调用方在查询某个带 depend_on 的属性（例如 exposure_program 依赖 hdr_photo_mode / p3_switch）之前，
     * 还没调用过依赖属性的 getValue()/setEnumValue() 把值写入缓存，dependencyKey 就会是 null，
     * 从而直接命中 JSON 里 attr.list.default 分支——而部分设备的 default 分支被有意配置成保守的单一取值
     * （如 x4_air.json 中 SphereA0B 镜头下 exposure_program 的 default 只有 FULL_AUTO）。
     * 遇到“supported 列表比 JSON 里定义的少”时，先确认依赖属性是否已被读取/写入过，再判断是否真的是相机状态限制。
     */
    override fun attributeOptions(attr: String): Result<List<String>> = withLensAndMode { lens, mode ->
        functionCatalog.dependOnAttributes(lens, mode, attr).flatMap { dependencies ->
            val dependencyKey = dependencies
                .mapNotNull { dependency -> attrValues[dependency] }
                .takeIf { it.isNotEmpty() }
                ?.joinToString("|")
            val defaultValues = functionCatalog.defaultAttrValues(lens, mode, attr).getOrDefault(emptyList())
            functionCatalog.attrValues(lens, mode, attr, dependencyKey).getOrDefault(defaultValues).success()
        }
    }

    // endregion

    // region Attribute Value mutations

    /** 以原样字符串存储属性值。 */
    override fun setAttrValue(attr: String, value: String) {
        attrValues[attr] = value
    }

    /** 存储整数，内部转换成字符串统一管理。 */
    override fun setAttrValue(attr: String, value: Int) {
        attrValues[attr] = value.toString()
    }

    /** 存储浮点数，使用可配置精度格式化后保存，避免二进制误差。 */
    override fun setAttrValue(attr: String, value: Double, precision: Int) {
        attrValues[attr] = value.roundTo(precision).toString().trimEnd('0').trimEnd('.')
    }

    /** 存储分数值，格式如 1/125。 */
    override fun setAttrValue(attr: String, fraction: Fraction) {
        attrValues[attr] = fraction.toDisplayString()
    }

    /**
     * 根据分子/分母写入快门值；若任何参数非法则回落到 "0"。
     * 这里将物理时间转换成 1/x 的形式，便于 UI 展示。
     */
    override fun setAttrValue(attr: String, numerator: Double, denominator: Double) {
        if (denominator == 0.0) {
            attrValues[attr] = "0"
            return
        }
        val seconds = numerator / denominator
        if (seconds == 0.0) {
            attrValues[attr] = "0"
            return
        }
        val inverse = 1.0 / seconds
        attrValues[attr] = Fraction(1, inverse.roundToIntSafe()).toDisplayString()
    }

    /** 直接写入枚举名，用于已知字符串值的场景。 */
    override fun setEnumValue(attr: String, valueName: String) {
        attrValues[attr] = valueName
    }

    /**
     * 通过枚举数值写入，内部先映射到名称以保持统一存储格式。
     */
    override fun setEnumValue(attr: String, numericValue: Int): Result<Unit> {
        // 兼容：部分 protoMap 里只有 color_mode（无 filter_mode），因此 filter_mode 复用 color_mode 的映射表。
        val lookupAttr = if (attr == CommonAttrKeys.FILTER_MODE) CommonAttrKeys.COLOR_MODE else attr
        return protoCatalog.nameFor(lookupAttr, numericValue).map { name ->
            attrValues[attr] = name
            Unit
        }
    }


    // endregion

    // region Attribute Value queries

    /**
     * 读取原始字符串值，若尚未设置则返回 MissingAttribute。
     */
    override fun getAttrValue(attr: String): Result<String> =
        attrValues[attr]?.success() ?: MissingAttributeException(attr).failure()

    /** 在 [getAttrValue] 基础上转 Int；若缓存的字符串不是合法数字会抛 NumberFormatException。 */
    override fun getAttrValueInt(attr: String): Result<Int> = getAttrValue(attr).map { it.toInt() }


    /** 在 [getAttrValue] 基础上转 Double；若缓存的字符串不是合法数字会抛 NumberFormatException。 */
    override fun getAttrValueDouble(attr: String): Result<Double> = getAttrValue(attr).map { it.toDouble() }

    /** 尝试按 "分子/分母" 解析；解析失败时退化为整数分母（分子固定为 1）而不是报错，兼容非分数格式的历史数据。 */
    override fun getAttrValueFraction(attr: String): Result<Fraction> = getAttrValue(attr).map {
        it.toFractionOrNull() ?: Fraction(1, it.toIntOrNull() ?: 1)
    }

    override fun getEnumValue(attr: String): Result<String> = getAttrValue(attr)

    /** 与 [setEnumValue] 的 filter_mode/color_mode 兼容逻辑对称：查数值时同样借用 color_mode 的 proto 映射表。 */
    override fun getEnumValueInt(attr: String): Result<Int> {
        val lookupAttr = if (attr == CommonAttrKeys.FILTER_MODE) CommonAttrKeys.COLOR_MODE else attr
        return getAttrValue(attr).flatMap { protoCatalog.intFor(lookupAttr, it) }
    }

    // endregion

    // region Attribute types

    /**
     * 查询属性类型，用于构建 UI 控件（如滑杆/下拉/文本输入）。
     */
    override fun attributeType(attr: String): Result<Int> =
        protoCatalog.mapFor(PHOTOGRAPHY_OPTION_TYPE).flatMap { map ->
            map.intValue(attr)
        }

    /**
     * 返回所有属性类型 ID，方便调试或一次性渲染。
     */
    override fun allAttributeTypes(): Result<List<Int>> =
        protoCatalog.mapFor(PHOTOGRAPHY_OPTION_TYPE).map { it.allIntValues() }


    /**
     * 包装器：在调用需要镜头的逻辑前先校验状态。
     */
    private fun <T> withLens(block: (lens: String) -> Result<T>): Result<T> {
        return currentLensType().flatMap {
            block(it)
        }
    }

    /**
     * 包装器：在调用需要镜头+模式的逻辑前统一做校验。
     */
    private fun <T> withLensAndMode(block: (lens: String, mode: String) -> Result<T>): Result<T> {
        return currentLensType().flatMap { lens ->
            currentFunctionMode().flatMap { mode ->
                block(lens, mode)
            }
        }
    }

    /** 将 double 转成 Int，避免负数或 0 导致异常。 */
    private fun Double.roundToIntSafe(): Int = if (this <= 0.0) 0 else roundToInt()

    // endregion
}

private const val CAPTURE_FUNCTION_MODE = "capture_function_mode"
private const val PHOTOGRAPHY_OPTION_TYPE = "photography_options_type"

