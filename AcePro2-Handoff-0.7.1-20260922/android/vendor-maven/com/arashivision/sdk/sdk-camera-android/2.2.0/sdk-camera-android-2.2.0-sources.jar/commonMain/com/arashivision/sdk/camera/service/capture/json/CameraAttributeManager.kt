package com.arashivision.sdk.camera.service.capture.json


/**
 * 对外暴露的相机属性管理接口，仅依赖 JSON 字符串输入，所有方法均为纯业务逻辑。
 *
 * 整体数据流：先 [setLensType] 选镜头 -> 再 [setFunctionMode] 选拍摄模式 -> 之后才能查询
 * [supportedAttributes] / [attributeOptions]，或用 setAttrValue* / setEnumValue 写入、
 * getAttrValue* / getEnumValue* 读出具体属性值。镜头/模式未选择时相关方法会返回
 * InvalidStateException 的失败 Result（具体实现见 [CameraAttributeManagerImpl]）。
 *
 * 排查提示：[attributeOptions] 对存在 depend_on 的属性（如 exposure_program 依赖
 * hdr_photo_mode/p3_switch）依赖“当前已写入的属性值缓存”，而不是主动去读相机实时状态。
 * 若发现某个属性的可选项比 JSON 里定义的少，先确认其依赖属性是否已经 setAttrValue/setEnumValue 过。
 */
interface CameraAttributeManager {

    /**
     * LensType（镜头类型，如 fisheye/sphere）。
     * 切换镜头会级联清空已选模式与属性缓存，详见实现类注释。
     */
    fun currentLensType(): Result<String>
    fun lensTypes(): List<String>
    fun setLensType(lens: String): Result<Unit>

    /**
     * FunctionMode（拍摄模式，如 photo_single/video_normal）。
     * 必须在 [setLensType] 之后调用，否则会失败。
     */
    fun currentFunctionModeInt(): Result<Int>
    fun currentFunctionMode(): Result<String>

    fun functionModes(): Result<List<String>>
    fun functionModeIds(): Result<List<Int>>
    fun setFunctionMode(modeValue: Int): Result<Unit>
    fun setFunctionMode(mode: String): Result<Unit>

    /**
     * 返回当前所有属性值的拷贝，key 为属性名，value 为字符串形式。
     */
    fun currentAttributeValues(): Result<Map<String, String>>


    /**
     * 当前镜头 + 模式支持的所有属性 Key（来自 JSON 的 support_attrs 字段）。
     */
    fun supportedAttributes(): Result<List<String>>

    /**
     * 指定参数支持的取值范围。
     *
     * 注意：若该属性存在 depend_on（依赖其他属性，如曝光模式依赖 HDR 开关），返回结果会随依赖属性
     * 当前缓存值变化；依赖属性尚未写入时会回落到 JSON 的 default 分支，取值可能明显偏少。
     * */
    fun attributeOptions(attr: String): Result<List<String>>

    /** 以原始字符串写入属性值，供无需类型转换的场景使用。 */
    fun setAttrValue(attr: String, value: String)
    /** 以整型写入属性值，内部会转换为字符串统一存储。 */
    fun setAttrValue(attr: String, value: Int)

    /**
     * 以浮点数写入属性值，并指定格式化精度。
     */
    fun setAttrValue(attr: String, value: Double, precision: Int = 1)

    /**
     * 以分数（分子/分母）形式写入，例如快门速度 1/125。
     */
    fun setAttrValue(attr: String, fraction: Fraction)

    /**
     * 快捷 API：提供分子/分母，内部自动化简为分数字符串。
     */
    fun setAttrValue(attr: String, numerator: Double, denominator: Double)

    /**
     * 直接写入枚举名。
     */
    fun setEnumValue(attr: String, valueName: String)

    /**
     * 通过 proto 数值写入枚举，会做反查与校验。
     */
    fun setEnumValue(attr: String, numericValue: Int): Result<Unit>

    /**
     * 读取属性的原始字符串值。
     *
     * 注意：只读取内存缓存，若从未 setAttrValue/setEnumValue 写入过（例如尚未从相机同步过该值），
     * 会返回 MissingAttributeException 的失败 Result，而不是去读取相机当前实际状态。
     */
    fun getAttrValue(attr: String): Result<String>
    fun getAttrValueInt(attr: String): Result<Int>
    fun getAttrValueDouble(attr: String): Result<Double>
    fun getAttrValueFraction(attr: String): Result<Fraction>
    fun getEnumValue(attr: String): Result<String>
    fun getEnumValueInt(attr: String): Result<Int>

    /**
     * 查询属性对应的 proto 类型（例如 Int、Double、Enum）。
     */
    fun attributeType(attr: String): Result<Int>

    /**
     * 返回 proto 声明的所有属性类型 ID，便于列表展示。
     */
    fun allAttributeTypes(): Result<List<Int>>

    companion object
}

/**
 * 工厂函数：从属性/Proto JSON 字符串创建管理器实例（主要用于测试）。
 */
fun CameraAttributeManager.Companion.fromJsonStrings(
    attrJson: String,
    protoJson: String
): Result<CameraAttributeManager> =
    CameraAttributeManagerImpl.fromJsonStrings(attrJson, protoJson)

