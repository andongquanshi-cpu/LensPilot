package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType

internal class AcePro2SupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFileType
        get() = if (isFlowStateEnabledForPreview()) PreviewFileType.UNPANORAMA else PreviewFileType.WIDE_ANGLE
    override val previewFitMode
        get() = if (isFlowStateEnabledForPreview()) PreviewFitMode.FILL else PreviewFitMode.CONTAIN
    override val previewGyroType = PreviewGyroType.ONE_RS_WIDEANGLE
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewStabType = PreviewStabType.STAB_FREE_FOOTAGE
    override val isRotateEnabled: Boolean = false
    override val isRotateScreenRatioEnabled: Boolean = true
    override val isGestureEnabledByMode: Boolean = false
    override val isFishEyeEdgePaddingEnabled: Boolean = snapshot.functionMode == FunctionMode.VIDEO_SUPER

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        // IAC firmware owns the actual preview stream selection.
        // Reusing record resolution here can desync the player from the real stream and cause black frames.
        previewParams(
            firstStream = StreamResolution.STREAM_1280_960_30FPS,
            secondStream = StreamResolution.STREAM_424_240_15FPS,
            previewNum = 0,
        )
}
