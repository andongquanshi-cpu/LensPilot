package com.arashivision.sdk.camera.service.capture

import com.arashivision.sdk.camera.api.CameraCapture
import com.arashivision.sdk.camera.api.param.CameraParam
import com.arashivision.sdk.camera.api.param.gps.GpsInfo
import com.arashivision.sdk.camera.api.param.listener.CaptureStatusListener
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.event.DeviceEvent
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.file.CameraFileType
import com.arashivision.sdk.camera.core.model.option.SensorMode
import com.arashivision.sdk.camera.core.model.photography.ExportType
import com.arashivision.sdk.camera.core.model.photography.Exposure
import com.arashivision.sdk.camera.core.model.photography.Exposure.ExposureProgram
import com.arashivision.sdk.camera.core.model.photography.FlowStateLevel
import com.arashivision.sdk.camera.core.model.photography.FovType
import com.arashivision.sdk.camera.core.model.photography.Iq3AMode
import com.arashivision.sdk.camera.core.model.photography.LensAccessoryType
import com.arashivision.sdk.camera.core.model.photography.PanoExposureMode
import com.arashivision.sdk.camera.core.model.photography.PhotoHdrType
import com.arashivision.sdk.camera.core.model.photography.PhotoResolution
import com.arashivision.sdk.camera.core.model.photography.PhotoSize
import com.arashivision.sdk.camera.core.model.photography.RawType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.VideoGammaMode
import com.arashivision.sdk.camera.core.model.photography.VideoSelfieMode
import com.arashivision.sdk.camera.service.CameraService
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.json.fromJsonStrings
import com.arashivision.sdk.camera.service.capture.param.booleans.EnhanceSwitchCameraParam
import com.arashivision.sdk.camera.service.capture.param.booleans.HdrSwitchCameraParam
import com.arashivision.sdk.camera.service.capture.param.booleans.ILogSwitchCameraParam
import com.arashivision.sdk.camera.service.capture.param.booleans.InternalSplicingCameraParam
import com.arashivision.sdk.camera.service.capture.param.booleans.LivePhotoSwitchCameraParam
import com.arashivision.sdk.camera.service.capture.param.booleans.P3SwitchCameraParam
import com.arashivision.sdk.camera.service.capture.param.booleans.ZoomEnableCameraParam
import com.arashivision.sdk.camera.service.capture.param.doubles.EvCameraParam
import com.arashivision.sdk.camera.service.capture.param.doubles.LapseTimeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.ExportTypeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.ExposureCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.FilterModeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.FlowStateLevelCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.FocusSensorCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.FovTypeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.FunctionModeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.Iq3AModeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.LensAccessoryParam
import com.arashivision.sdk.camera.service.capture.param.enums.PanoExposureModeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.PhotoHdrCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.PhotoResolutionCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.PhotoSizeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.RawTypeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.RecordResolutionCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.VideoGammaModeCameraParam
import com.arashivision.sdk.camera.service.capture.param.enums.VideoSelfieModeCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.AccelerateFrequencyCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.AebCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.IsoCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.IsoTopLimitCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.LiveBitrateCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.RecordDurationCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.SelfTimerCameraParam
import com.arashivision.sdk.camera.service.capture.param.ints.WhiteBalanceCameraParam
import com.arashivision.sdk.camera.service.capture.param.other.BurstCameraParam
import com.arashivision.sdk.camera.service.capture.param.other.ShutterSpeedCameraParam
import com.arashivision.sdk.common.assets.assetsReadTextSuspend
import com.arashivision.sdk.common.exception.CameraCaptureImplInitException
import com.arashivision.sdk.common.exception.CameraNotSupportException
import com.arashivision.sdk.common.exception.CaptureGetSupportListException
import com.arashivision.sdk.common.exception.InstaVoidException
import com.arashivision.sdk.common.exception.UnknownException
import com.arashivision.sdk.common.file.InstaFileManager
import com.arashivision.sdk.common.kotlin.download
import com.arashivision.sdk.common.kotlin.exists
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.readText
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import insta360.messages.Sensor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock


class CameraCaptureService(
    camera: DeviceCore, connectType: ConnectType, scope: CoroutineScope, isDestroy: () -> Boolean
) : CameraService(camera, connectType, scope, isDestroy), CameraCapture {

    companion object {
        private const val TAG = "CameraCaptureService"
        private const val EXPOSURE_BIAS_NATIVE_SCALE = 10.0
    }

    // CameraCapture 参数属性
    override lateinit var lensType: CameraParam<SensorMode>

    override lateinit var functionMode: CameraParam<FunctionMode>

    override lateinit var aeb: CameraParam<Int>
    override lateinit var rawType: CameraParam<RawType>
    override lateinit var exposureBias: CameraParam<Double>
    override lateinit var photoResolution: CameraParam<PhotoResolution>
    override lateinit var whiteBalance: CameraParam<Int>
    override lateinit var fovType: CameraParam<FovType>
    override lateinit var flowStateLevel: CameraParam<FlowStateLevel>
    override lateinit var photographySelfTimer: CameraParam<Int>
    override lateinit var splicingBaseEnable: CameraParam<Boolean>
    override lateinit var videoSelfieMode: CameraParam<VideoSelfieMode>
    override lateinit var videoResolution: CameraParam<RecordResolution>
    override lateinit var videoISOTopLimit: CameraParam<Int>
    override lateinit var exportType: CameraParam<ExportType>
    override lateinit var photoSizeId: CameraParam<PhotoSize>
    override lateinit var colorMode: CameraParam<VideoGammaMode>
    override lateinit var filterMode: CameraParam<VideoGammaMode>
    override lateinit var accelerateFrequency: CameraParam<Int>
    override lateinit var recordDuration: CameraParam<Int>
    override lateinit var exposureIndividual: CameraParam<PanoExposureMode>
    override lateinit var livingBitrate: CameraParam<Int>
    override lateinit var exposureISO: CameraParam<Int>
    override lateinit var exposureShutterSpeed: CameraParam<Pair<Double, Double>>
    override lateinit var exposureProgram: CameraParam<ExposureProgram>
    override lateinit var burstCaptureParams: CameraParam<Pair<Int, Int>>
    override lateinit var hdrPhotoMode: CameraParam<PhotoHdrType>
    override lateinit var hdrSwitch: CameraParam<Boolean>
    override lateinit var p3Switch: CameraParam<Boolean>
    override lateinit var iLogSwitch: CameraParam<Boolean>
    override lateinit var pureVideoEnhanceSwitch: CameraParam<Boolean>
    override lateinit var doubleZoomEnable: CameraParam<Boolean>
    override lateinit var lapseTime: CameraParam<Double>
    override lateinit var livePhotoMode: CameraParam<Boolean>
    override lateinit var lensAccessory: CameraParam<LensAccessoryType>
    override lateinit var iq3AMode: CameraParam<Iq3AMode>

    private val captureStatusListeners = mutableListOf<CaptureStatusListener>()
    private val captureStatusMutex = Mutex()
    private var eventsJob: Job? = null

    private var cameraAttributeManager: CameraAttributeManager? = null
    private var initialized: Boolean = false
    private val syncJob = SupervisorJob()
    private val syncScope = CoroutineScope(syncJob + Dispatchers.Default)
    private val syncMutex = Mutex()

    val isInitialized: Boolean
        get() = initialized

    init {
        bindParams()
        eventsJob = scope.launch {
            camera.events.collect { event ->
                when (event) {
                    is DeviceEvent.CaptureCountChanged -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureCountChanged(event.functionMode, event.captureCount) }
                    }

                    is DeviceEvent.CaptureStatusEvent.Error -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureError(event.functionMode, event.throwable) }
                    }

                    is DeviceEvent.CaptureStatusEvent.Finished -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureFinish(event.functionMode, event.filePaths) }
                    }

                    is DeviceEvent.CaptureStatusEvent.SubStatusChanged -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureSubStatusChanged(event.functionMode, event.subStatus) }
                    }

                    is DeviceEvent.CaptureStatusEvent.Starting -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureStarting(event.functionMode) }
                    }

                    is DeviceEvent.CaptureStatusEvent.Stopping -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureStopping(event.functionMode) }
                    }

                    is DeviceEvent.CaptureStatusEvent.Working -> {
                        // 相机工作时发生了FunctionMode的改变，则需要同步到拍摄参数管理中
                        requireManager().onSuccess {
                            it.setFunctionMode(event.functionMode.nativeValue)
                        }
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureWorking(event.functionMode) }
                    }

                    is DeviceEvent.CaptureTimeChanged -> {
                        val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
                        snapshot.forEach { it.onCaptureTimeChanged(event.functionMode, event.captureTime) }
                    }

                    else -> {}
                }
            }
        }
    }


    // ------------------- 录制状态监听 -------------------
    override fun registerCaptureStatusListener(listener: CaptureStatusListener) {
        if (isDestroyed()) return
        scope.launch {
            captureStatusMutex.withLock {
                if (!captureStatusListeners.contains(listener)) {
                    captureStatusListeners.add(listener)
                }
            }
        }
    }

    override fun unregisterCaptureStatusListener(listener: CaptureStatusListener) {
        if (isDestroyed()) return
        scope.launch {
            captureStatusMutex.withLock { captureStatusListeners.remove(listener) }
        }
    }

    override suspend fun loadJson(): Result<Unit> {
        return loadSupportConfigJson().flatMap { supportConfig ->
            loadProtoJson().flatMap { proto ->
                CameraAttributeManager.fromJsonStrings(supportConfig, proto).onSuccess {
                    Logger.i(TAG, "CameraAttributeManager created: $cameraAttributeManager")
                    cameraAttributeManager = it

                    // 提前标记已初始化，避免同步阶段 requireManager 拦截
                    initialized = true
                    syncScope.launch { syncAllParams() }
                }.onFailure {
                    Logger.i(TAG, it.message ?: "")
                }
            }
        }.map { }
    }

    private suspend fun loadSupportConfigJson(): Result<String> {
        return if (camera.getCameraConfig().getOrNull()?.supportDownloadJsonParams() == true) {
            camera.getCameraFile(CameraFileType.PARAMS_JSON_FILE).flatMap { jsonFile ->
                camera.getSerialNumber().flatMap { Pair(it, jsonFile).success() }
            }.flatMap {
                val serial = it.first
                val jsonFile = it.second
                val localJsonPath = InstaFileManager.paramsDir().resolve(serial).resolve("${jsonFile.second}.json")
                Logger.i(TAG, "[loadSupportConfigJson]  localJsonPath=$localJsonPath")
                if (localJsonPath.exists()) {
                    Logger.i(TAG, "[loadSupportConfigJson]  localJsonPath exists")
                    readText(localJsonPath)
                } else if (connectType != ConnectType.BLE) {
                    Logger.i(TAG, "[loadSupportConfigJson]  localJsonPath not exists and connect type is not ble")
                    download("${camera.getDownloadEndpoint()}${jsonFile.first}", localJsonPath).flatMap { downloadFile ->
                        readText(downloadFile)
                    }
                } else {
                    Logger.i(TAG, "[loadSupportConfigJson]  localJsonPath not exists and connect type is ble")
                    InstaVoidException().failure()
                }
            }
        } else {
            InstaVoidException().failure()
        }.fold(
            onSuccess = { it.success() },
            onFailure = {
                Logger.i(TAG, "[loadSupportConfigJson]  failed  message=${it.message}")
                Logger.i(TAG, "[loadSupportConfigJson]  start read local support config")
                loadSupportConfigJson(camera.getCameraType().getOrDefault(CameraType.UNKNOWN))
            }
        ).onSuccess {
            Logger.i(TAG, "[loadSupportConfigJson]  read support config success")
        }.onFailure {
            Logger.i(TAG, "[loadSupportConfigJson]  read local support config failed,   message=${it.message}")
        }
    }

    private suspend fun loadProtoJson(): Result<String> {
        return assetsReadTextSuspend("insta/json/proto/protoMap.json")
    }

    suspend fun loadSupportConfigJson(cameraType: CameraType): Result<String> {
        if (cameraType == CameraType.UNKNOWN) {
            return IllegalArgumentException("Parameter error when reading assets").failure()
        }
        val fileName = when (cameraType) {
            CameraType.NANO_S -> "nanos"
            CameraType.SPHERE -> ""
            CameraType.ONE_X -> "oneX"
            CameraType.ONE_X2 -> "x2"
            CameraType.ONE_R -> "oner"
            CameraType.ONE_RS -> resolveOneRSJsonFileName()
            CameraType.GO -> ""
            CameraType.GO_2 -> ""
            CameraType.GO_3 -> ""
            CameraType.GO_3S -> "go_3s"
            CameraType.GO_ULTRA -> "go_ultra"
            CameraType.X3 -> "x3"
            CameraType.X4 -> "x4"
            CameraType.X5 -> "x5"
            CameraType.X4_AIR -> "x4_air"
            CameraType.X6 -> "x6"
            CameraType.ACE -> "ace"
            CameraType.ACE_PRO -> "ace_pro"
            CameraType.ACE_PRO_2 -> "ace_pro_2"
            CameraType.UNKNOWN -> ""
        }
        return assetsReadTextSuspend("insta/json/params/$fileName.json")
    }

    private fun resolveOneRSJsonFileName(): String {
        val type = camera.getSensorInfo().getOrNull()?.type
        val is283 = type == Sensor.Type.PANO_283 || type == Sensor.Type.WIDE_283
        return if (is283) "oners_283" else "oners_577"
    }

    private fun bindParams() {
        lensType = FocusSensorCameraParam(::requireManager) { camera.success() }
        functionMode = FunctionModeCameraParam(::requireManager) { camera.success() }

        aeb = AebCameraParam(::requireManager) { camera.success() }
        rawType = RawTypeCameraParam(::requireManager) { camera.success() }
        exposureBias = EvCameraParam(::requireManager) { camera.success() }
        photoResolution = PhotoResolutionCameraParam(::requireManager) { camera.success() }
        fovType = FovTypeCameraParam(::requireManager) { camera.success() }
        flowStateLevel = FlowStateLevelCameraParam(::requireManager) { camera.success() }
        photographySelfTimer = SelfTimerCameraParam(::requireManager) { camera.success() }
        splicingBaseEnable = InternalSplicingCameraParam(::requireManager) { camera.success() }
        videoSelfieMode = VideoSelfieModeCameraParam(::requireManager) { camera.success() }
        videoResolution = RecordResolutionCameraParam(::requireManager) { camera.success() }
        exportType = ExportTypeCameraParam(::requireManager) { camera.success() }
        photoSizeId = PhotoSizeCameraParam(::requireManager) { camera.success() }
        colorMode = VideoGammaModeCameraParam(::requireManager) { camera.success() }
        filterMode = FilterModeCameraParam(::requireManager) { camera.success() }
        accelerateFrequency = AccelerateFrequencyCameraParam(::requireManager) { camera.success() }
        recordDuration = RecordDurationCameraParam({ videoResolution.getValue() }, ::requireManager) { camera.success() }
        exposureIndividual = PanoExposureModeCameraParam(::requireManager) { camera.success() }
        livingBitrate = LiveBitrateCameraParam(::requireManager) { camera.success() }
        hdrPhotoMode = PhotoHdrCameraParam(::requireManager) { camera.success() }
        exposureProgram = ExposureCameraParam(::requireManager) { camera.success() }

        burstCaptureParams = BurstCameraParam(::requireManager) { camera.success() }

        hdrSwitch = HdrSwitchCameraParam(::requireManager) { camera.success() }
        p3Switch = P3SwitchCameraParam(::requireManager) { camera.success() }
        iLogSwitch = ILogSwitchCameraParam(::requireManager) { camera.success() }
        pureVideoEnhanceSwitch = EnhanceSwitchCameraParam(::requireManager) { camera.success() }
        doubleZoomEnable = ZoomEnableCameraParam(::requireManager) { camera.success() }
        lapseTime = LapseTimeCameraParam(::requireManager) { camera.success() }
        livePhotoMode = LivePhotoSwitchCameraParam(::requireManager) { camera.success() }
        lensAccessory = LensAccessoryParam(::requireManager) { camera.success() }

        exposureISO = IsoCameraParam(::requireManager) { camera.success() }
        exposureShutterSpeed = ShutterSpeedCameraParam(::requireManager) { camera.success() }
        whiteBalance = WhiteBalanceCameraParam(::requireManager) { camera.success() }
        videoISOTopLimit = IsoTopLimitCameraParam(::requireManager) { camera.success() }
        iq3AMode = Iq3AModeCameraParam(::requireManager) { camera.success() }
    }

    private fun requireManager(): Result<CameraAttributeManager> = cameraAttributeManager?.takeIf { initialized }?.success() ?: CameraCaptureImplInitException().failure()

    override suspend fun destroy() {
        captureStatusMutex.withLock {
            captureStatusListeners.clear()
        }
        cameraAttributeManager = null
        initialized = false
        // 取消后台同步协程，避免泄漏
        syncJob.cancel()
    }

    /**
     * 同步一次所有参数的当前值，初始化后调用。
     * 失败不抛出，只记录日志。
     */
    override suspend fun syncAllParams() {
        // 从相机拉取数据
        camera.initAllOptions()
        // 从 optionsMapper 中获取数据并更新 CameraAttributeManager
        getAllParams().forEach { param ->
            runCatching { param.getValue() }.onFailure { t ->
                val name = runCatching { param.getName() }.getOrNull() ?: "unknown"
                Logger.e(TAG, "sync param failed: $name", t)
            }
        }
    }

    @Deprecated("已废弃，请使用 getSupportParam()", replaceWith = ReplaceWith("getSupportParam()"), level = DeprecationLevel.WARNING)
    override fun getSupportParamNames(): List<String> {
        val supportedNames = cameraAttributeManager?.supportedAttributes()?.getOrNull().orEmpty().toSet()
        val collected = mutableListOf<String>()

        getAllParams().orEmpty().forEach { param ->
            val name = runCatching { param.getName() }.getOrNull()
            if (name != null && supportedNames.contains(name)) {
                collected.add(name)
                Logger.i(TAG, "support param found: $name")
            } else {
                Logger.i(TAG, "support param missing: $name")
            }
        }

        if (camera.getCameraType().getOrDefault(CameraType.UNKNOWN).isPanoramaCamera()) {
            collected.add(lensType.getName())
        }

        return collected
    }

    override fun getSupportParam(): List<CameraParam<*>> {
        val supportedNames = cameraAttributeManager?.supportedAttributes()?.getOrNull().orEmpty().toSet()
        val collected = mutableListOf<CameraParam<*>>()
        getAllParams().forEach { param ->
            val name = runCatching { param.getName() }.getOrNull()
            if (name != null && supportedNames.contains(name)) {
                collected.add(param)
                Logger.i(TAG, "support param found: $name")
            } else {
                Logger.i(TAG, "support param missing: $name")
            }
        }

        if (camera.getCameraType().getOrDefault(CameraType.UNKNOWN).isPanoramaCamera()) {
            collected.add(lensType)
        }
        return collected
    }

    @Deprecated("已废弃，请使用 getSupportParam()", replaceWith = ReplaceWith("getSupportParam()"), level = DeprecationLevel.WARNING)
    override fun getAllParams(): List<CameraParam<*>> {
        val params = mutableListOf(
            lensType,
            functionMode,
            photoResolution,
            videoResolution,
            hdrPhotoMode,
            aeb,
            rawType,
            exposureBias,
            whiteBalance,
            lensAccessory,
            fovType,
            flowStateLevel,
            photographySelfTimer,
            splicingBaseEnable,
            videoSelfieMode,
            videoISOTopLimit,
            exportType,
            photoSizeId,
            colorMode,
            filterMode,
            accelerateFrequency,
            recordDuration,
            exposureIndividual,
            livingBitrate,
            exposureISO,
            exposureShutterSpeed,
            exposureProgram,
            burstCaptureParams,
            hdrSwitch,
            iLogSwitch,
            p3Switch,
            pureVideoEnhanceSwitch,
            doubleZoomEnable,
            lapseTime,
            livePhotoMode,
            iq3AMode
        )
        return params
    }

    override suspend fun startCapture(gpsInfo: GpsInfo?) {
        val value = functionMode.getValue()
        if (value.isFailure) {
            val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
            snapshot.forEach { it.onCaptureError(FunctionMode.NONE, CaptureGetSupportListException("currentFunctionMode is empty!")) }
            return
        }
        val checkCaptureConditions = camera.checkCaptureConditions(value.getOrThrow())
        if (checkCaptureConditions.isFailure) {
            val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
            snapshot.forEach { it.onCaptureError(value.getOrThrow(), checkCaptureConditions.exceptionOrNull() ?: UnknownException()) }
            return
        }
        val result = when (value.getOrThrow()) {
            FunctionMode.NONE -> CaptureGetSupportListException("currentFunctionMode is empty!").failure()
            FunctionMode.PHOTO_NORMAL -> {
                val raw = rawType.getValue().getOrNull() ?: RawType.OFF
                camera.startPhotoNormal(raw, gpsInfo?.toByteArray(), photographySelfTimer.getValue().getOrNull())
                Unit.success()
            }

            FunctionMode.PHOTO_HDR -> {
                val aebNumbers = when (val n = aeb.getValue().getOrNull() ?: 3) {
                    in listOf(3, 5, 7, 9) -> n
                    else -> {
                        Logger.w(TAG, "PHOTO_HDR unsupported aebNumbers=$n, fallback to 3")
                        3
                    }
                }
                val stepNative = exposureBias.getValue().getOrNull()?.let { (it * EXPOSURE_BIAS_NATIVE_SCALE).toInt() } ?: 0
                val evValues = buildAebEvBias(aebNumbers, stepNative)
                Logger.i(TAG, "aeb = ${aebNumbers}, step = ${stepNative}, evValues = $evValues")
                if (camera.getCameraType().getOrNull() == CameraType.ONE_X2) {
                    exposureProgram.setValue(ExposureProgram.AUTO)
                }
                val raw = rawType.getValue().getOrNull() ?: RawType.OFF
                camera.startPhotoHdr(evValues, raw, gpsInfo?.toByteArray())
                Unit.success()
            }

            FunctionMode.PHOTO_BURST -> {
                val raw = rawType.getValue().getOrNull() ?: RawType.OFF
                camera.startPhotoBurst(raw, gpsInfo?.toByteArray())
                Unit.success()
            }

            FunctionMode.PHOTO_INTERVAL -> {
                camera.startPhotoInterval(gpsInfo?.toByteArray())
                Unit.success()
            }

            FunctionMode.PHOTO_NIGHT -> Result.failure(CameraNotSupportException("PHOTO_NIGHT mode is not supported"))
            FunctionMode.PHOTO_PANO -> Result.failure(CameraNotSupportException("PHOTO_PANO mode is not supported"))
            FunctionMode.PHOTO_PANO_HDR -> Result.failure(CameraNotSupportException("PHOTO_PANO_HDR mode is not supported"))
            FunctionMode.PHOTO_STARLAPSE -> {
                camera.startPhotoStarLapse(gpsInfo?.toByteArray())
                Unit.success()
            }

            FunctionMode.VIDEO_NORMAL -> {
                camera.startVideoNormal()
                Unit.success()
            }

            FunctionMode.VIDEO_BULLET_TIME -> Result.failure(CameraNotSupportException("VIDEO_BULLET_TIME mode is not supported"))
            FunctionMode.VIDEO_TIMELAPSE -> {
                camera.startVideoTimelapse()
                Unit.success()
            }

            FunctionMode.VIDEO_HDR -> Result.failure(CameraNotSupportException("VIDEO_HDR mode is not supported"))
            FunctionMode.VIDEO_TIMESHIFT -> {
                camera.startVideoTimeShift()
                Unit.success()
            }

            FunctionMode.VIDEO_SUPER -> {
                camera.startVideoSuper()
                Unit.success()
            }

            FunctionMode.VIDEO_LOOP_RECORDING -> {
                camera.startVideoLooperRecording()
                Unit.success()
            }

            FunctionMode.VIDEO_FPV -> Result.failure(CameraNotSupportException("VIDEO_FPV mode is not supported"))
            FunctionMode.VIDEO_MOVIE -> Result.failure(CameraNotSupportException("VIDEO_MOVIE mode is not supported"))
            FunctionMode.VIDEO_SLOW_MOTION -> {
                camera.startVideoSlowMotion()
                Unit.success()
            }

            FunctionMode.VIDEO_SELFIE -> Result.failure(CameraNotSupportException("VIDEO_SELFIE mode is not supported"))
            FunctionMode.VIDEO_PURE -> {
                camera.startVideoPure()
                Unit.success()
            }

            FunctionMode.VIDEO_LIVE -> Result.failure(CameraNotSupportException("VIDEO_LIVE mode is not supported"))
            FunctionMode.VIDEO_CAMERA_LIVE -> Result.failure(CameraNotSupportException("VIDEO_CAMERA_LIVE mode is not supported"))
            FunctionMode.VIDEO_DASHCAM -> Result.failure(CameraNotSupportException("VIDEO_DASHCAM mode is not supported"))
            FunctionMode.VIDEO_MOSQUITO -> {
                camera.startVideoMosquito()
                Unit.success()
            }
        }

        if (result.isFailure) {
            val snapshot = captureStatusMutex.withLock { captureStatusListeners.toList() }
            snapshot.forEach { it.onCaptureError(value.getOrThrow(), result.exceptionOrNull() ?: UnknownException()) }
        }
    }

    override suspend fun stopCapture(gpsInfo: GpsInfo?) {
        // 当前什么模式在工作，就用什么模式结束拍摄
        FunctionMode.entries.find { it != FunctionMode.NONE && camera.isWorking(it) }?.let {
            when (it) {
                FunctionMode.NONE -> {
                    Logger.w(TAG, "stopCapture: FunctionMode is NONE")
                }

                FunctionMode.PHOTO_NORMAL -> {
                    Logger.w(TAG, "stopCapture: PHOTO_NORMAL mode does not support manual stop")
                }

                FunctionMode.PHOTO_HDR -> {
                    Logger.w(TAG, "stopCapture: PHOTO_HDR mode is not supported")
                }

                FunctionMode.PHOTO_BURST -> {
                    Logger.w(TAG, "stopCapture: PHOTO_BURST mode does not support manual stop")
                }

                FunctionMode.PHOTO_INTERVAL -> {
                    camera.stopPhotoInterval()
                }

                FunctionMode.PHOTO_NIGHT -> {
                    Logger.w(TAG, "stopCapture: PHOTO_NIGHT mode is not supported")
                }

                FunctionMode.PHOTO_PANO -> {
                    Logger.w(TAG, "stopCapture: PHOTO_PANO mode is not supported")
                }

                FunctionMode.PHOTO_PANO_HDR -> {
                    Logger.w(TAG, "stopCapture: PHOTO_PANO_HDR mode is not supported")
                }

                FunctionMode.PHOTO_STARLAPSE -> {
                    camera.stopPhotoStarLapse()
                }

                FunctionMode.VIDEO_NORMAL -> {
                    camera.stopVideoNormal(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_BULLET_TIME -> {
                    camera.stopVideoBulletTime(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_TIMELAPSE -> {
                    camera.stopVideoTimelapse(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_HDR -> {
                    camera.stopVideoHdr(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_TIMESHIFT -> {
                    camera.stopVideoTimeShift(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_SUPER -> {
                    camera.stopVideoSuper(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_LOOP_RECORDING -> {
                    camera.stopVideoLooperRecording(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_FPV -> {
                    camera.stopVideoFpv(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_MOVIE -> {
                    camera.stopVideoMovie(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_SLOW_MOTION -> {
                    camera.stopVideoSlowMotion(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_SELFIE -> {
                    camera.stopVideoSelfie(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_PURE -> {
                    camera.stopVideoPure(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_LIVE -> {
                    Logger.w(TAG, "stopCapture: VIDEO_LIVE mode is not supported")
                }

                FunctionMode.VIDEO_CAMERA_LIVE -> {
                    Logger.w(TAG, "stopCapture: VIDEO_CAMERA_LIVE mode is not supported")
                }

                FunctionMode.VIDEO_DASHCAM -> {
                    camera.stopVideoDashCam(gpsInfo?.toByteArray())
                }

                FunctionMode.VIDEO_MOSQUITO -> {
                    camera.stopVideoMosquito(gpsInfo?.toByteArray())
                }
            }
        }
    }

    override suspend fun isWorking(): Boolean {
        return functionMode.getValue().getOrNull()?.let { camera.isWorking(it) } ?: false
    }

    override fun isPreRecording(): Boolean {
        return if (camera.isConnected && !isDestroyed()) camera.isPreRecording() else false
    }

    override fun cancelPreRecord() {
        if (camera.isConnected && !isDestroyed()) camera.cancelPreRecord()
    }

    override suspend fun getBurstTime(): Result<Unit> {
        // 兼容旧接口：触发一次 burstCaptureParams 的同步/读取即可
        return burstCaptureParams.getValue().map { Unit }
    }

    override suspend fun setGpsInfo(gpsInfo: GpsInfo) = camera.setGpsData(gpsInfo.toByteArray())

    override suspend fun getRemaining(): Result<Int> {
        return this.functionMode.getValue().flatMap {
            getRemaining(it)
        }
    }

    override fun getRemaining(functionMode: FunctionMode): Result<Int> = camera.getRemaining(functionMode)

    override suspend fun fetchRemaining(functionMode: FunctionMode): Result<Int> = camera.fetchRemaining(functionMode)

    private fun buildAebEvBias(aebCount: Int, stepNative: Int): List<Int> {
        val result = IntArray(aebCount)
        result[0] = 0
        for (i in 1..(aebCount - 1) / 2) {
            val factor = (aebCount - 1) / 2 - i + 1
            result[i] = -stepNative * factor
            result[aebCount - i] = stepNative * factor
        }
        return result.toList()
    }

}


