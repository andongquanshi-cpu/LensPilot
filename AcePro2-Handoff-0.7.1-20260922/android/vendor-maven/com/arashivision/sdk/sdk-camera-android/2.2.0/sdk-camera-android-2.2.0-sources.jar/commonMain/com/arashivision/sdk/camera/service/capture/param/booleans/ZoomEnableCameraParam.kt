package com.arashivision.sdk.camera.service.capture.param.booleans

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys

internal class ZoomEnableCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : BooleanCameraParam(CommonAttrKeys.DOUBLE_ZOOM_ENABLE, managerProvider, deviceCoreProvider) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Boolean> {
        return device.getDoubleZoomEnable(functionMode)
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Boolean> {
        return device.fetchDoubleZoomEnable(functionMode)
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Boolean): Result<Unit> {
        return device.setDoubleZoomEnable(functionMode, value)
    }

}