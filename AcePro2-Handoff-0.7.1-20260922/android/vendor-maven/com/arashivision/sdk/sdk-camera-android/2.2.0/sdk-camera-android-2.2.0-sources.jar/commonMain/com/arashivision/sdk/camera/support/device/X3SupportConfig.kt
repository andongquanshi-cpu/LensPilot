package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class X3PanoramaSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.NONE
    override val previewStabType = PreviewStabType.STAB_STILL
    override val previewFileType = PreviewFileType.VR360
    override val previewGyroType = PreviewGyroType.X3_FISHEYE
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val isStabilizeEnabled: Boolean = true

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_960_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_5760_2880_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1440_720_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )
        }
}

class X3SingleLenSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFitMode.NONE
                isFlowStateEnabledForPreview() -> PreviewFitMode.FILL
                else -> PreviewFitMode.CONTAIN
            }
    override val previewFileType
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewFileType.SPECIAL_SELFIE
                isFlowStateEnabledForPreview() -> PreviewFileType.UNPANORAMA
                else -> PreviewFileType.FISH_EYE
            }
    override val previewStitchType = PreviewStitchType.OPTICAL_FLOW
    override val previewStabType = PreviewStabType.STAB_FULL_DIRECTIONAL
    override val previewGyroType
        get() =
            when {
                snapshot.functionMode == FunctionMode.VIDEO_SELFIE -> PreviewGyroType.X3_FISHEYE
                snapshot.isSelfie -> PreviewGyroType.X3_Z180
                else -> PreviewGyroType.X3_FISHEYE
            }

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams {
        val flowStateEnabled = isFlowStateEnabledForPreview()
        val runtimeRecordStream = currentRecordStream()
        val runtimeResolution = snapshot.currentRecordResolution
        val isVerticalPreview = runtimeResolution?.let { it.width < it.height } ?: false
        val secondStream =
            when {
                !flowStateEnabled -> StreamResolution.STREAM_368_368_30FPS
                isVerticalPreview -> StreamResolution.STREAM_360_640_30FPS
                else -> StreamResolution.STREAM_640_360_30FPS
            }
        return when {
            isForLive ->
                previewParams(
                    firstStream = runtimeRecordStream ?: StreamResolution.STREAM_1920_1080_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = runtimeRecordStream ?: StreamResolution.STREAM_3840_2160_30FPS,
                    secondStream = secondStream,
                    previewNum = 1,
                )

            snapshot.functionMode == FunctionMode.VIDEO_SELFIE ->
                previewParams(
                    firstStream = StreamResolution.STREAM_2880_720_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            !flowStateEnabled ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1152_1152_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )

            isVerticalPreview ->
                previewParams(
                    firstStream = StreamResolution.STREAM_648_1152_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1152_648_30FPS,
                    secondStream = secondStream,
                    previewNum = 0,
                )
        }
    }
}
