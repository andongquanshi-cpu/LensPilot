package com.arashivision.sdk.camera.platform

import com.arashivision.insta360.camerastream.bean.VideoParam
import com.arashivision.sdk.camera.core.model.photography.StreamResolution

fun StreamResolution.toVideoParam(): VideoParam {
    val videoParam = VideoParam()
    videoParam.bitrate = 40
    videoParam.fps = fps
    videoParam.height = height
    videoParam.width = width
    videoParam.enableGyro = true
    return videoParam
}