package com.arashivision.sdk.camera.core.model.option

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class VideoEncode(override val nativeValue: Int) : BaseEnum {
    ENCODE_H264(0),
    ENCODE_H265(1);

    companion object {
        fun nativeOf(nativeValue: Int?): VideoEncode {
            return VideoEncode.entries.firstOrNull { it.nativeValue == nativeValue } ?: ENCODE_H264
        }
    }
}