package com.arashivision.sdk.camera.provider

import com.arashivision.sdk.bridge.camera.CameraModuleProvider
import com.arashivision.sdk.bridge.shared.preview.ICaptureSupportConfig
import com.arashivision.sdk.camera.api.CameraDevice
import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.file.MediaFileType
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.service.CameraDeviceInternal
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfigFactory
import com.arashivision.sdk.camera.support.resolveRuntimeRecordResolutionOrNull
import com.arashivision.sdk.common.exception.CameraNotConnectedException
import com.arashivision.sdk.common.file.InstaFileManager
import com.arashivision.sdk.common.kotlin.delete
import com.arashivision.sdk.common.kotlin.ensureDirectory
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.nowMs
import com.arashivision.sdk.common.kotlin.renameTo
import com.arashivision.sdk.common.kotlin.success
import insta360.messages.Sensor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okio.Path.Companion.toPath

object CameraModuleProviderImpl : CameraModuleProvider {

    // 多文件下载的最大并发数。
    // 下载走 HTTP(:80)，与控制通道(:6666)是不同 TCP 连接但共用同一条 Wi-Fi 链路；
    // 并发过高会占满链路使控制通道收不到相机入向包，连续 30 秒后触发原生看门狗
    // ERR_TIMEOUT(-19)，进而被判定为断连。
    private const val MAX_CONCURRENT_DOWNLOADS = 2

    // 进度聚合协程使用的内部进度事件。
    private data class ProgressUpdate(val index: Int, val progress: Long, val total: Long)

    private var bleCamera: CameraDevice? = null
    private var wifiCamera: CameraDevice? = null
    private var usbCamera: CameraDevice? = null
    private var awareCamera: CameraDevice? = null

    internal fun setCamera(camera: CameraDevice?, connectType: ConnectType) {
        when (connectType) {
            ConnectType.BLE -> bleCamera = camera
            ConnectType.WIFI -> wifiCamera = camera
            ConnectType.USB -> usbCamera = camera
            ConnectType.WIFI_AWARE -> awareCamera = camera
        }
    }

    private fun getCamera(): Result<CameraDevice> =
        awareCamera?.success() ?: wifiCamera?.success() ?: usbCamera?.success() ?: bleCamera?.success() ?: CameraNotConnectedException().failure()

    override fun getHttpPrefix(): Result<String> = getCamera().map {
        it.file.getEndpoint()
    }

    override fun getDownloadHttpPrefix(): Result<String> = getCamera().map {
        (it as? CameraDeviceInternal)?.deviceCore?.getDownloadEndpoint() ?: it.file.getEndpoint()
    }

    override fun getHttpPrefixPair(): Result<Pair<String, String>> = getCamera().map {
        val httpPrefix = it.file.getEndpoint()
        val downloadHttpPrefix = (it as? CameraDeviceInternal)?.deviceCore?.getDownloadEndpoint() ?: httpPrefix
        httpPrefix to downloadHttpPrefix
    }

    override fun getCaptureSupportConfig(): Result<ICaptureSupportConfig> =
        getCamera().flatMap { camera ->
            camera.system.getSupportConfig().flatMap { cameraConfig ->
                val currentFunctionModeResult = camera.preview.getCurrentFunctionMode()
                val cameraTypeResult = camera.system.getCameraType()
                createCameraSupportConfig(
                    cameraConfig = cameraConfig,
                    currentFunctionModeResult = currentFunctionModeResult,
                    cameraTypeResult = cameraTypeResult,
                    isFlowstateOnResult =
                        currentFunctionModeResult.map { runtimeFunctionMode ->
                            (camera as? CameraDeviceInternal)
                                ?.deviceCore
                                ?.getFlowstateBaseEnable(runtimeFunctionMode)
                                ?.getOrElse { false }
                                ?: false
                        },
                    currentRecordResolution =
                        currentFunctionModeResult.getOrNull()?.let { runtimeFunctionMode ->
                            cameraTypeResult.getOrNull()?.let { cameraType ->
                                (camera as? CameraDeviceInternal)?.deviceCore?.let { deviceCore ->
                                    resolveRuntimeRecordResolutionOrNull(deviceCore, cameraType, runtimeFunctionMode)
                                }
                            }
                        },
                    mediaOffsetV1Result = camera.system.getMediaOffset(),
                    mediaOffsetV2Result = camera.system.getMediaOffsetV2(),
                    mediaOffsetV3Result = camera.system.getMediaOffsetV3(),
                    mediaOffsetV6Result = camera.system.getMediaOffsetV6(),
                    stabOffsetV1Result = camera.system.getOriginOffset(),
                    stabOffsetV2Result = camera.system.getOriginOffsetV2(),
                    stabOffsetV3Result = camera.system.getOriginOffsetV3(),
                    offsetStateResult = camera.system.getOffsetState(),
                    offsetDetectedTypeResult = camera.system.getOffsetDetectedType(),
                    isSelfieResult = camera.system.getIsSelfie(),
                    windowCropInfoResult = camera.system.getWindowCropInfo(),
                    halfWindowCropInfoResult = camera.system.getHalfWindowCropInfo(),
                    sensorInfoResult = camera.system.getSensorInfo(),
                )
            }
        }

    override suspend fun getCameraInfoMap(): Result<Map<String, ByteArray>> = getCamera().flatMap { camera ->
        camera.file.getFileInfoList().map { fileInfos ->
            fileInfos.associate { it.url to it.extraData }
        }
    }

    override suspend fun getAllUrlList(): Result<List<String>> = getCamera().flatMap {
        it.file.listMediaFiles(MediaFileType.VIDEO_AND_PHOTO)
    }

    override suspend fun getRawUrlList(): Result<List<String>> = getCamera().flatMap {
        it.file.listMediaFiles(MediaFileType.DNG)
    }

    override suspend fun getAllInsDataList(): Result<List<String>> = getCamera().flatMap {
        it.file.listMediaFiles(MediaFileType.INS_DATA)
    }

    override suspend fun downloadCameraFile(url: String, progressCallback: ((progress: Long, total: Long) -> Unit)?): Result<String> {
        return downloadCameraFiles(arrayOf(url)) { totalSize, downloadedSize ->
            progressCallback?.invoke(downloadedSize, totalSize)
        }.map { it[0] }
    }

    private suspend fun downloadMediaFile(url: String, targetDri: String, progressCallback: ((progress: Long, total: Long) -> Unit)? = null): Result<String> = getCamera().flatMap {
        it.file.downloadMediaFile(url, targetDri, progressCallback)
    }

    // 将单文件进度聚合为全局进度并统一回调。
    private fun CoroutineScope.launchProgressCollector(
        progressChannel: Channel<ProgressUpdate>,
        fileTotals: LongArray,
        fileProgresses: LongArray,
        progressCallback: ((totalSize: Long, downloadedSize: Long) -> Unit)?
    ) = launch {
        for (update in progressChannel) {
            val safeProgress = update.progress.coerceAtLeast(0L)
            if (fileTotals[update.index] < 0L && update.total >= 0L) {
                fileTotals[update.index] = update.total
            }
            fileProgresses[update.index] = if (fileTotals[update.index] >= 0L) {
                safeProgress.coerceAtMost(fileTotals[update.index])
            } else {
                safeProgress
            }
            val currentTotalRaw = fileTotals.filter { it >= 0L }.sum()
            val currentTotal = if (fileTotals.any { it >= 0L }) currentTotalRaw else -1L
            val downloadedSizeRaw = fileProgresses.sum()
            val downloadedSize = if (currentTotal >= 0L && fileTotals.all { it >= 0L }) {
                downloadedSizeRaw.coerceAtMost(currentTotal)
            } else {
                downloadedSizeRaw
            }
            progressCallback?.invoke(currentTotal, downloadedSize)
        }
    }

    // 并发下载文件，并按原始索引顺序输出结果。
    private suspend fun downloadFiles(
        urls: Array<String>,
        target: String,
        progressChannel: Channel<ProgressUpdate>
    ): List<String> = coroutineScope {
        val downloadSemaphore = Semaphore(urls.size.coerceIn(1, MAX_CONCURRENT_DOWNLOADS))
        val cacheFilesByIndex = MutableList<String?>(urls.size) { null }
        urls.indices.map { index ->
            async {
                downloadSemaphore.withPermit {
                    val filePath = downloadMediaFile(urls[index], target) { progress, total ->
                        progressChannel.trySend(ProgressUpdate(index, progress, total))
                    }.getOrElse { throw it }
                    cacheFilesByIndex[index] = filePath
                }
            }
        }.awaitAll()
        cacheFilesByIndex.mapIndexed { index, path ->
            path ?: throw IllegalStateException("Download result missing for index=$index")
        }
    }

    // 将临时下载文件移动到工作目录，并返回最终路径。
    private fun finalizeDownloadedFiles(cacheFiles: List<String>): List<String> {
        ensureDirectory(InstaFileManager.workDir())
        return cacheFiles.map {
            val newPath = "${InstaFileManager.workDir()}/${it.toPath().name}"
            it.toPath().renameTo(newPath.toPath())
            newPath
        }
    }

    /**
     * 下载多文件
     * 1.按顺序并发下载文件，一个文件一个协程，同时进行的下载数不超过 MAX_CONCURRENT_DOWNLOADS
     * 2.下载中根据回调逐步补齐总文件大小并聚合整体进度
     * 3.将文件移动到目标目录，并返回最终路径
     */
    override suspend fun downloadCameraFiles(urls: Array<String>, progressCallback: ((totalSize: Long, downloadedSize: Long) -> Unit)?): Result<List<String>> {
        val target = "${InstaFileManager.downloadDir()}/${nowMs()}"
        return try {
            val cacheFiles = coroutineScope {
                val fileProgresses = LongArray(urls.size)
                val fileTotals = LongArray(urls.size) { -1L }
                progressCallback?.invoke(-1L, 0L)
                val progressChannel = Channel<ProgressUpdate>(capacity = Channel.UNLIMITED)
                val progressCollector = launchProgressCollector(progressChannel, fileTotals, fileProgresses, progressCallback)
                try {
                    downloadFiles(urls, target, progressChannel)
                } finally {
                    progressChannel.close()
                    progressCollector.join()
                }
            }
            val downloadFiles = finalizeDownloadedFiles(cacheFiles)
            Result.success(downloadFiles)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            target.toPath().delete()
        }
    }


    override suspend fun deleteCameraFile(urls: Array<String>): Result<Unit> {
        return getCamera().flatMap {
            it.file.deleteMediaFiles(*urls)
        }
    }

    override fun requestStreamIframe(): Result<Unit> =
        getCamera().map { it.preview.requestStreamIframe() }

    override fun getRollingShutterTime(): Result<Double> =
        getCamera().flatMap { it.system.getRollingShutterTime() }

}

internal fun createCameraSupportConfig(
    cameraConfig: ICameraConfig,
    currentFunctionModeResult: Result<FunctionMode>,
    cameraTypeResult: Result<CameraType>,
    isFlowstateOnResult: Result<Boolean>,
    currentRecordResolution: RecordResolution?,
    mediaOffsetV1Result: Result<String>,
    mediaOffsetV2Result: Result<String>,
    mediaOffsetV3Result: Result<String>,
    mediaOffsetV6Result: Result<String>,
    stabOffsetV1Result: Result<String>,
    stabOffsetV2Result: Result<String>,
    stabOffsetV3Result: Result<String>,
    offsetStateResult: Result<Int>,
    offsetDetectedTypeResult: Result<Int>,
    isSelfieResult: Result<Boolean>,
    windowCropInfoResult: Result<insta360.messages.WindowCropInfo>,
    halfWindowCropInfoResult: Result<insta360.messages.WindowCropInfo>,
    sensorInfoResult: Result<Sensor>
): Result<ICaptureSupportConfig> =
    currentFunctionModeResult.flatMap { runtimeFunctionMode ->
        cameraTypeResult.flatMap { cameraType ->
            isSelfieResult.flatMap { isSelfie ->
                isFlowstateOnResult.map { isFlowstateOn ->
                    val snapshot =
                        CameraRuntimeSnapshot(
                            cameraType = cameraType,
                            functionMode = runtimeFunctionMode,
                            currentRecordResolution = currentRecordResolution,
                            mediaOffsetV1 = mediaOffsetV1Result.getOrElse { "" },
                            mediaOffsetV2 = mediaOffsetV2Result.getOrElse { "" },
                            mediaOffsetV3 = mediaOffsetV3Result.getOrElse { "" },
                            mediaOffsetV6 = mediaOffsetV6Result.getOrElse { "" },
                            stabOffset = stabOffsetV1Result.getOrElse { "" },
                            offsetState = offsetStateResult.getOrElse { 0 },
                            offsetDetectedType = offsetDetectedTypeResult.getOrElse { 0 },
                            isSelfie = isSelfie,
                            isFlowstateOn = isFlowstateOn,
                            windowCropInfo = windowCropInfoResult.getOrNull(),
                            halfWindowCropInfo = halfWindowCropInfoResult.getOrNull(),
                            sensorInfo = sensorInfoResult.getOrNull()
                        )
                    CaptureSupportConfigFactory.create(cameraConfig, snapshot)
                }
            }
        }
    }