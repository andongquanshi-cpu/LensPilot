package com.arashivision.sdk.camera.core.delegate.multivideooption

import com.arashivision.sdk.common.callback.CoroutineCallback
import com.arashivision.sdk.common.callback.coroutineCallback
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import com.arashivision.sdk.camera.core.DeviceContext
import com.arashivision.sdk.camera.core.delegate.BaseDelegate
import com.arashivision.sdk.camera.core.event.TransportEvent
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.common.exception.MultiVideoOptionValueNullException
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

class MultiVideoOptionDelegateImpl(deviceContext: DeviceContext) : BaseDelegate(deviceContext), MultiVideoOptionDelegate {

    companion object {
        private const val TAG = "MultiVideoOptionsDelegateImpl"
    }

    private var multiVideoOptionCallbackMap: MutableMap<Long, CoroutineCallback<MultiPhotographyOptions>> = mutableMapOf()
    private val multiVideoOptionCallbackMutex = Mutex()
    private var callbackMap: MutableMap<Long, CoroutineCallback<Unit>> = mutableMapOf()
    private val callbackMutex = Mutex()

    private val multiVideoOptionCacheMutex = Mutex()
    private var multiVideoOptionCache: MutableMap<FunctionMode, MutableMap<MultiPhotographyOptionsType, Any?>> = mutableMapOf()


    override fun init() {
        context.scope.launch {
            context.transport.events.collect {
                when (it) {
                    //get timelapse option
                    is TransportEvent.GetMultiVideoModeEvent.Success -> {
                        multiVideoOptionCallbackMutex.withLock { multiVideoOptionCallbackMap.remove(it.requestId) }?.onSuccess(it.options)
                    }

                    is TransportEvent.GetMultiVideoModeEvent.Failed -> {
                        multiVideoOptionCallbackMutex.withLock { multiVideoOptionCallbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    //set timelapse option
                    is TransportEvent.SetMultiVideoModeEvent.Success -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onSuccess(Unit)
                    }

                    is TransportEvent.SetMultiVideoModeEvent.Failed -> {
                        callbackMutex.withLock { callbackMap.remove(it.requestId) }?.onThrowable(it.throwable)
                    }

                    else -> {}
                }
            }
        }
    }


    override suspend fun release() {
        callbackMutex.withLock { callbackMap.clear() }
        multiVideoOptionCallbackMutex.withLock { multiVideoOptionCallbackMap.clear() }
        multiVideoOptionCacheMutex.withLock { multiVideoOptionCache.clear() }
    }

    private fun <T> requiredMultiVideoOption(functionMode: FunctionMode, multiPhotographyOptionsType: MultiPhotographyOptionsType): Result<T> =
        getMultiVideoOption<T>(functionMode, multiPhotographyOptionsType)?.success() ?: Result.failure(MultiVideoOptionValueNullException(multiPhotographyOptionsType.toString()))

    @Suppress("UNCHECKED_CAST")
    private fun <T> getMultiVideoOption(functionMode: FunctionMode, multiPhotographyOptionsType: MultiPhotographyOptionsType): T? =
        multiVideoOptionCache[functionMode]?.let { MultiVideoOptionMapper.multiVideoOptionTransform(multiPhotographyOptionsType, it) as? T }


    override fun getMultiVideoResolution(functionMode: FunctionMode): Result<RecordResolution> = requiredMultiVideoOption(functionMode, MultiPhotographyOptionsType.RESOLUTION)

    private suspend fun <T> fetchMultiVideoOption(functionMode: FunctionMode, multiPhotographyOptionsType: MultiPhotographyOptionsType): Result<T> {
        return fetchMultiVideoOptions(functionMode, listOf(multiPhotographyOptionsType)).flatMap {
            requiredMultiVideoOption(functionMode, multiPhotographyOptionsType)
        }
    }

    override suspend fun fetchMultiVideoOptions(functionMode: FunctionMode, multiVideoOptionsList: List<MultiPhotographyOptionsType>): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            Logger.d(TAG, "fetchMultiPhotographyOptions ==>$multiVideoOptionsList")
            val call = coroutineCallback {
                success {
                    if (continuation.isActive) {
                        val newCache = MultiVideoOptionMapper.multiVideoOption2Map(multiVideoOptionsList, it)
                        multiVideoOptionCacheMutex.withLock {
                            if (multiVideoOptionCache.contains(functionMode)) {
                                multiVideoOptionCache[functionMode]?.putAll(newCache)
                            } else {
                                multiVideoOptionCache.put(functionMode, newCache.toMutableMap())
                            }
                        }
                        continuation.resume(Result.success(Unit))
                    }
                }
                throwable {
                    if (continuation.isActive) {
                        continuation.resume(Result.failure(it))
                    }
                }
            }
            val id = context.transport.getMultiVideoOptions(functionMode.nativeValue, 1, multiVideoOptionsList)
            context.scope.launch {
                multiVideoOptionCallbackMutex.withLock {
                    multiVideoOptionCallbackMap[id] = call
                }
            }
        }
    }

    override suspend fun fetchAllMultiVideoOptions(): Result<Unit> {
        return FunctionMode.entries
            // 过滤掉 NONE 模式
            .filter { it != FunctionMode.NONE }
            // 转为 Flow 流处理
            .asFlow()
            // 遍历每个模式，执行获取操作
            .map { mode -> fetchAllMultiVideoOptions(mode) }
            // 只保留失败的结果
            .filter { it.isFailure }
            // 取最后一个失败结果（无则返回成功）
            .lastOrNull() ?: Result.success(Unit)
    }

    override suspend fun fetchAllMultiVideoOptions(functionMode: FunctionMode): Result<Unit> {
        return context.cameraConfig?.supportMultiVideoOptionsList()?.takeIf { it.isNotEmpty() }?.let {
            fetchMultiVideoOptions(functionMode, it)
        } ?: Unit.success()
    }

    private suspend fun <T> setMultiVideoOption(functionMode: FunctionMode, multiPhotographyOptionsType: MultiPhotographyOptionsType, data: T): Result<Unit> {
        val mapTransform = MultiVideoOptionMapper.mapTransform(multiPhotographyOptionsType, data as Any)
        return setMultiVideoOptions(functionMode, mapTransform)
    }

    private suspend fun setMultiVideoOptions(functionMode: FunctionMode, multiVideoOptions: Map<MultiPhotographyOptionsType, Any>): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            val call = coroutineCallback<Unit> {
                success {
                    if (continuation.isActive) {
                        multiVideoOptionCacheMutex.withLock { multiVideoOptionCache[functionMode]?.putAll(multiVideoOptions) }
                        continuation.resume(Unit.success())
                    }
                }
                throwable {
                    if (continuation.isActive) {
                        continuation.resume(it.failure())
                    }
                }
            }
            val id = context.transport.setMultiVideoOptions(
                functionMode.nativeValue,
                1,
                multiVideoOptions.keys.toList(),
                MultiVideoOptionMapper.map2MultiVideoOptions(multiVideoOptions)
            )
            context.scope.launch {
                callbackMutex.withLock {
                    callbackMap[id] = call
                }
            }
        }
    }

    override suspend fun fetchMultiVideoResolution(functionMode: FunctionMode): Result<RecordResolution> =
        fetchMultiVideoOption(functionMode, MultiPhotographyOptionsType.RESOLUTION)

    override suspend fun setMultiVideoResolution(functionMode: FunctionMode, recordResolution: RecordResolution): Result<Unit> =
        setMultiVideoOption(functionMode, MultiPhotographyOptionsType.RESOLUTION, recordResolution)

    override fun getMultiVideoInternalFlowState(functionMode: FunctionMode): Result<Boolean> =
        requiredMultiVideoOption(functionMode, MultiPhotographyOptionsType.PHOTOGRAPHY_INTERNAL_FLOWSTATE)

    override suspend fun fetchMultiVideoInternalFlowState(functionMode: FunctionMode): Result<Boolean> =
        fetchMultiVideoOption(functionMode, MultiPhotographyOptionsType.PHOTOGRAPHY_INTERNAL_FLOWSTATE)

    override suspend fun setMultiVideoInternalFlowState(functionMode: FunctionMode, enable: Boolean): Result<Unit> =
        setMultiVideoOption(functionMode, MultiPhotographyOptionsType.PHOTOGRAPHY_INTERNAL_FLOWSTATE, enable)
}