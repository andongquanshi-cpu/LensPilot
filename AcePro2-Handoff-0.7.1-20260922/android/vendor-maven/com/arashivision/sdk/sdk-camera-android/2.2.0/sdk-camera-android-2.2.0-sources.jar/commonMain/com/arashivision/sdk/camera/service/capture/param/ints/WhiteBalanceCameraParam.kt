package com.arashivision.sdk.camera.service.capture.param.ints

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.WB
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.camera.service.capture.param.thenMirrorVideoLiveIfNeeded

internal class WhiteBalanceCameraParam(
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : IntCameraParam(CommonAttrKeys.WHITE_BALANCE, managerProvider, deviceCoreProvider) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        val cameraType = device.getCameraType().getOrNull()
        return when (cameraType) {
            CameraType.ONE_R if device.getCameraConfig().getOrNull()?.isMergedIntoRS(device.getFirmwareRevision().getOrDefault("1.0.0")) == true -> {
                device.getWhiteBalanceValue(functionMode)
            }

            in listOf(CameraType.ONE_R, CameraType.SPHERE, CameraType.GO_2, CameraType.ONE_X, CameraType.ONE_X2) -> {
                device.getWhiteBalance(functionMode)
            }

            else -> device.getWhiteBalanceValue(functionMode)
        }.map { it.value }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        val cameraType = device.getCameraType().getOrNull()
        return when (cameraType) {
            CameraType.ONE_R if device.getCameraConfig().getOrNull()?.isMergedIntoRS(device.getFirmwareRevision().getOrDefault("1.0.0")) == true -> {
                device.fetchWhiteBalanceValue(functionMode)
            }

            in listOf(CameraType.ONE_R, CameraType.SPHERE, CameraType.GO_2, CameraType.ONE_X, CameraType.ONE_X2) -> {
                device.fetchWhiteBalance(functionMode)
            }

            else -> device.fetchWhiteBalanceValue(functionMode)
        }.map { it.value }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Int): Result<Unit> {
        val wb = WB.valueOf(value)
        val cameraType = device.getCameraType().getOrNull()
        val mergedIntoRs = device.getCameraConfig().getOrNull()?.isMergedIntoRS(device.getFirmwareRevision().getOrDefault("1.0.0")) == true
        return writeWbFor(device, functionMode, wb, cameraType, mergedIntoRs)
            .thenMirrorVideoLiveIfNeeded(device, functionMode) {
                writeWbFor(device, FunctionMode.VIDEO_LIVE, wb, cameraType, mergedIntoRs)
            }
    }

    private suspend fun writeWbFor(
        device: DeviceCore,
        mode: FunctionMode,
        wb: WB,
        cameraType: CameraType?,
        mergedIntoRs: Boolean,
    ): Result<Unit> = when (cameraType) {
        CameraType.ONE_R if mergedIntoRs -> device.setWhiteBalanceValue(mode, wb)
        in listOf(CameraType.ONE_R, CameraType.SPHERE, CameraType.GO_2, CameraType.ONE_X, CameraType.ONE_X2) -> {
            device.setWhiteBalance(mode, wb)
        }
        else -> device.setWhiteBalanceValue(mode, wb)
    }

}