package com.arashivision.sdk.camera.service.capture.param.enums

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CameraParamImpl
import com.arashivision.sdk.common.exception.InvalidStateException
import com.arashivision.sdk.common.exception.NumberConversionException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.mapFailure
import com.arashivision.sdk.common.kotlin.success

@Suppress("UNCHECKED_CAST")
internal abstract class EnumCameraParam<T>(
    name: String,
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : CameraParamImpl<T>(name, managerProvider, deviceCoreProvider) {

    @Suppress("UNCHECKED_CAST")
    override suspend fun reader(manager: CameraAttributeManager, device: DeviceCore): Result<T> {
        fun mapEnum(parsed: T): Result<T> = if (parsed == unknowValue()) {
            NumberConversionException("Attribute '$key' cannot be parsed as enum").failure()
        } else {
            parsed.success()
        }

        val local = manager.getEnumValueInt(key).fold(
            onSuccess = { mapEnum(fromInt(it)) },
            onFailure = { manager.getEnumValue(key).flatMap { mapEnum(fromName(it)) } }
        )
        return currentFunctionMode()
            .flatMap { mode -> readFormCamera(device, mode) }
            .mapFailure { invalidStateException(it, key) }
            .flatMap { value ->
                mapEnum(value).onSuccess {
                    manager.setEnumValue(key, toInt(it))
                }
            }.takeIf { it.isSuccess } ?: local
    }

    @Suppress("UNCHECKED_CAST")
    override suspend fun fetcher(manager: CameraAttributeManager, device: DeviceCore): Result<T> {
        fun mapEnum(parsed: T): Result<T> = if (parsed == unknowValue()) {
            NumberConversionException("Attribute '$key' cannot be parsed as enum").failure()
        } else {
            parsed.success()
        }

        val local = manager.getEnumValueInt(key).fold(
            onSuccess = { mapEnum(fromInt(it)) },
            onFailure = { manager.getEnumValue(key).flatMap { mapEnum(fromName(it)) } }
        )
        return currentFunctionMode()
            .flatMap { mode -> fetchFormCamera(device, mode) }
            .mapFailure { invalidStateException(it, key) }
            .flatMap { value ->
                mapEnum(value).onSuccess {
                    manager.setEnumValue(key, toInt(it))
                }
            }.takeIf { it.isSuccess } ?: local
    }

    override suspend fun writer(manager: CameraAttributeManager, device: DeviceCore, value: T): Result<Unit> {
        return currentFunctionMode().flatMap { mode ->
            writeToCamera(device, mode, value).mapFailure {
                InvalidStateException(it.message ?: "device error")
            }.flatMap {
                manager.setEnumValue(key, toInt(value))
            }
        }
    }

    override suspend fun supportedLoader(manager: CameraAttributeManager): Result<List<T>> {
        return manager.attributeOptions(key).flatMap { opts ->
            val mapped = opts.mapNotNull { option ->
                option.toIntOrNull()?.let(::fromInt)?.takeUnless { it == unknowValue() } ?: fromName(option).takeUnless { it == unknowValue() }
            }
            mapped.takeIf { it.isNotEmpty() }?.success() ?: NumberConversionException("No valid enum options for $key").failure()
        }
    }

    abstract fun unknowValue(): T?
    abstract fun fromInt(value: Int): T
    abstract fun fromName(name: String): T
    abstract fun toInt(data: T): Int
}