package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class FlowStateLevel(
    override val nativeValue: Int,
    val protoName: String
) : BaseEnum {
    CLOSE(0, "FLOW_STATE_LEVEL_CV5_CLOSE"),
    LOW(1, "FLOW_STATE_LEVEL_CV5_SLIGHT|FLOW_STATE_LEVEL_LOW"),
    STANDARD(2, "FLOW_STATE_LEVEL_CV5_GENERAL|FLOW_STATE_LEVEL_STANDARD"),
    HIGH(3, "FLOW_STATE_LEVEL_CV5_STRONG|FLOW_STATE_LEVEL_HIGH");

    companion object {
        fun nativeOf(value: Int?): FlowStateLevel =
            entries.firstOrNull { it.nativeValue == value } ?: CLOSE

        fun protoOf(name: String?): FlowStateLevel =
            entries.firstOrNull { name?.let { n -> it.protoName.contains(n) } ?: false } ?: CLOSE
    }
}

