package com.arashivision.sdk.camera.support.device

import com.arashivision.sdk.camera.config.ICameraConfig
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.support.CameraRuntimeSnapshot
import com.arashivision.sdk.camera.support.CaptureSupportConfig
import com.arashivision.sdk.bridge.shared.preview.PreviewFileType
import com.arashivision.sdk.bridge.shared.preview.PreviewFitMode
import com.arashivision.sdk.bridge.shared.preview.PreviewGyroType
import com.arashivision.sdk.bridge.shared.preview.PreviewStabType
import com.arashivision.sdk.bridge.shared.preview.PreviewStitchType
import com.arashivision.sdk.camera.service.preview.PreviewParams as CameraPreviewParams

class Akiko577PanoramaSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode = PreviewFitMode.NONE
    override val previewStabType = PreviewStabType.STAB_STILL
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewGyroType
        get() = resolveOneRFisheyePreviewGyroType()

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_960_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_5760_2880_30FPS),
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 1,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1440_720_30FPS,
                    secondStream = StreamResolution.STREAM_480_240_30FPS,
                    previewNum = 0,
                )
        }
}

class Akiko577SingleLenSupportConfig(
    cameraConfig: ICameraConfig,
    snapshot: CameraRuntimeSnapshot,
) : CaptureSupportConfig(cameraConfig, snapshot) {
    override val previewFitMode
        get() = if (isFlowStateEnabledForPreview()) PreviewFitMode.FILL else PreviewFitMode.CONTAIN
    override val previewFileType
        get() = if (isFlowStateEnabledForPreview()) PreviewFileType.UNPANORAMA else PreviewFileType.WIDE_ANGLE
    override val previewStitchType = PreviewStitchType.NORMAL
    override val previewStabType = PreviewStabType.STAB_FREE_FOOTAGE
    override val previewGyroType = PreviewGyroType.ONE_R_WIDE

    override fun buildPreviewParams(
        isForLive: Boolean,
        isForRecord: Boolean,
    ): CameraPreviewParams =
        when {
            isForLive ->
                previewParams(
                    firstStream = configuredFirstStream(true, false, StreamResolution.STREAM_1920_1080_30FPS),
                    secondStream = StreamResolution.STREAM_424_240_15FPS,
                    previewNum = 0,
                )

            isForRecord ->
                previewParams(
                    firstStream = configuredFirstStream(false, true, StreamResolution.STREAM_3840_2160_30FPS),
                    secondStream = StreamResolution.STREAM_424_240_15FPS,
                    previewNum = 1,
                )

            isFlowStateEnabledForPreview() ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1280_720_30FPS,
                    secondStream = StreamResolution.STREAM_424_240_15FPS,
                    previewNum = 0,
                )

            else ->
                previewParams(
                    firstStream = StreamResolution.STREAM_1280_960_30FPS,
                    secondStream = StreamResolution.STREAM_424_240_15FPS,
                    previewNum = 0,
                )
        }
}
