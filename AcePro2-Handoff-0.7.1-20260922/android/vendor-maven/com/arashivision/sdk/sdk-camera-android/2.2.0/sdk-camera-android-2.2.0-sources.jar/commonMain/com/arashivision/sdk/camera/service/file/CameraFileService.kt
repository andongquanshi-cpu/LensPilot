package com.arashivision.sdk.camera.service.file

import com.arashivision.sdk.camera.api.CameraFile
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.ConnectType
import com.arashivision.sdk.camera.core.model.file.FileInfo
import com.arashivision.sdk.camera.core.model.file.MediaFileType
import com.arashivision.sdk.camera.core.model.option.StorageData
import com.arashivision.sdk.camera.service.CameraService
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.callback.ProgressCallback
import com.arashivision.sdk.common.callback.callback
import com.arashivision.sdk.common.exception.AlreadyReleasedException
import com.arashivision.sdk.common.exception.CameraLogFileDownloadingException
import com.arashivision.sdk.common.exception.CameraNotConnectedException
import com.arashivision.sdk.common.exception.DownloadCameraFileException
import com.arashivision.sdk.common.exception.SDCardUnavailableException
import com.arashivision.sdk.common.kotlin.download
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.getDispatcherProvider
import com.arashivision.sdk.common.kotlin.getFilenameFromUrl
import com.arashivision.sdk.common.kotlin.invokeCallback
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okio.Path.Companion.toPath
import kotlin.coroutines.resume

class CameraFileService(
    camera: DeviceCore, connectType: ConnectType, scope: CoroutineScope, isActive: () -> Boolean
) : CameraService(camera, connectType, scope, isActive), CameraFile {

    companion object {
        private const val TAG = "CameraFileService"
    }

    private var isCameraLogFileDownloading = false


    override fun getEndpoint(): String {
        return camera.getEndpoint()
    }

    override fun getHost(): String {
        return camera.getHost()
    }

    override fun getProt(): Int {
        return camera.getProt()
    }

    override suspend fun listMediaFiles(mediaFileType: MediaFileType, includeRecording: Boolean): Result<List<String>> {
        return suspendCancellableCoroutine { continuation ->
            listMediaFiles(mediaFileType, includeRecording, callback {
                success { continuation.resume(Result.success(it)) }
                throwable { continuation.resume(Result.failure(it)) }
            })
        }
    }

    override fun listMediaFiles(mediaFileType: MediaFileType, includeRecording: Boolean, callback: Callback<List<String>>) {
        if (isDestroyed()) {
            callback.onThrowable(AlreadyReleasedException())
            return
        }
        if (!camera.isConnected) {
            callback.onThrowable(CameraNotConnectedException())
            return
        }
        if (camera.getStorageData().getOrNull()?.state == StorageData.State.NO_CARD) {
            callback.onThrowable(SDCardUnavailableException())
            return
        }
        scope.launch {
            var start = 0
            val limit = 100
            val result: MutableList<String> = mutableListOf()
            while (start >= 0 && isActive) {
                camera.listMediaFiles(mediaFileType, start, limit, includeRecording).onSuccess {
                    result.addAll(it.first)
                    start = if (result.size >= it.second || it.first.isEmpty()) -1 else result.size
                }.onFailure {
                    start = -1
                    callback.onThrowable(it)
                }
            }
            callback.onSuccess(result)
        }
    }

    override suspend fun listMediaFiles(mediaFileType: MediaFileType, start: Int, limit: Int, includeRecording: Boolean): Result<Pair<List<String>, Int>> {
        if (isDestroyed()) {
            return AlreadyReleasedException().failure()
        }
        if (!camera.isConnected) {
            return CameraNotConnectedException().failure()
        }
        if (camera.getStorageData().getOrNull()?.state == StorageData.State.NO_CARD) {
            return SDCardUnavailableException().failure()
        }
        return camera.listMediaFiles(mediaFileType, start, limit, includeRecording)
    }

    override fun listMediaFiles(mediaFileType: MediaFileType, start: Int, limit: Int, includeRecording: Boolean, callback: Callback<Pair<List<String>, Int>>) {
        scope.launch {
            listMediaFiles(mediaFileType, start, limit, includeRecording).invokeCallback(callback)
        }
    }

    override suspend fun deleteMediaFiles(vararg uris: String): Result<Unit> {
        if (isDestroyed()) {
            return Result.failure(AlreadyReleasedException())
        }
        if (!camera.isConnected) {
            return Result.failure(CameraNotConnectedException())

        }
        return camera.deleteMediaFiles(uris.toList())
    }

    override fun deleteMediaFiles(vararg uris: String, callback: Callback<Unit>) {
        scope.launch {
            deleteMediaFiles().invokeCallback(callback)
        }
    }

    override suspend fun downloadMediaFile(url: String, targetDir: String, progressCallback: ((Long, Long) -> Unit)?): Result<String> {
        if (isDestroyed()) {
            return Result.failure(AlreadyReleasedException())
        }
        if (!camera.isConnected) {
            return Result.failure(CameraNotConnectedException())
        }
        Logger.i(TAG, "downloadMediaFile start, url=$url")
        val result = url.getFilenameFromUrl()?.let {
            val targetPath = "$targetDir/${it}"
            download(url, targetPath.toPath()) { progress, total ->
                progressCallback?.invoke(progress, total)
            }
        } ?: run {
            Result.failure(DownloadCameraFileException("Invalid URL"))
        }
        result.fold(
            onSuccess = { Logger.i(TAG, "downloadMediaFile success, url=$url, path=$it") },
            onFailure = { Logger.e(TAG, "downloadMediaFile failed, url=$url", it) }
        )
        return withContext(getDispatcherProvider().main) { result.map { it.toString() } }
    }

    override fun downloadMediaFile(url: String, targetDir: String, progressCallback: ProgressCallback<String, Pair<Long, Long>>) {
        scope.launch {
            downloadMediaFile(url, targetDir) { progress, total ->
                progressCallback.onProgress(Pair(progress, total))
            }.invokeCallback(progressCallback)
        }
    }

    override suspend fun downloadCameraLogFile(targetDir: String, progressCallback: ((Long, Long) -> Unit)?): Result<String> {
        if (isDestroyed()) {
            return Result.failure(AlreadyReleasedException())
        }
        if (!camera.isConnected) {
            return Result.failure(CameraNotConnectedException())
        }
        if (isCameraLogFileDownloading) {
            return Result.failure(CameraLogFileDownloadingException())
        }
        isCameraLogFileDownloading = true
        Logger.i(TAG, "downloadCameraLogFile start")
        val result = camera.packLogFile().flatMap { uri ->
            val url = "${camera.getDownloadEndpoint()}$uri"
            url.getFilenameFromUrl()?.let {
                val targetPath = "$targetDir/${it}"
                download(url, targetPath.toPath()) { progress, total ->
                    progressCallback?.invoke(progress, total)
                }
            } ?: run { Result.failure(DownloadCameraFileException("Invalid URL")) }
        }
        isCameraLogFileDownloading = false
        result.fold(
            onSuccess = { Logger.i(TAG, "downloadCameraLogFile success, path=$it") },
            onFailure = { Logger.e(TAG, "downloadCameraLogFile failed", it) }
        )
        return withContext(getDispatcherProvider().main) { result.map { it.toString() } }
    }

    override fun downloadCameraLogFile(targetDir: String, progressCallback: ProgressCallback<String, Pair<Long, Long>>) {
        scope.launch {
            downloadCameraLogFile(targetDir) { progress, total ->
                progressCallback.onProgress(Pair(progress, total))
            }.invokeCallback(progressCallback)
        }
    }

    override fun getFileInfoList(callback: Callback<List<FileInfo>>) {
        scope.launch {
            getFileInfoList().invokeCallback(callback)
        }
    }

    override suspend fun getFileInfoList(): Result<List<FileInfo>> {
        return camera.fetchStorageDataList().flatMap { storageDataList ->
            val list = mutableListOf<FileInfo>()
            for (storage in storageDataList) {
                camera.getFileInfoList(storage.fileLocation).fold(
                    onSuccess = { list.addAll(it) },
                    onFailure = { return@flatMap Result.failure(it) }
                )
            }
            list.success()
        }
    }

    override suspend fun destroy() {

    }
}