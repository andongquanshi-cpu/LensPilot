package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class LensAccessoryType(
    override val nativeValue: Int,
    val protoName: String
) : BaseEnum {

    UNKNOWN(0, "UNKNOWN"),
    STANDARD(1, "STANDARD"),
    BLACK_MIST_FILTER(2, "BLACK_MIST_FILTER"),
    WIDE_ANGLE_LENS(3, "WIDE_ANGLE_LENS"),
    ADJUSTABLE_MACRO_LENS(4, "ADJUSTABLE_MACRO_LENS"),
    ANAMORPHIC_LENS(5, "ANAMORPHIC_LENS"),
    STAR_FILTER(6, "STAR_FILTER"),
    ND_FILTER(7, "ND_FILTER"),
    MICRO_LENS(8, "MICRO_LENS"),
    MICRO_LENS_5(9, "MICRO_LENS_5"),
    MICRO_LENS_11P6(10, "MICRO_LENS_11P6"),
    MICRO_LENS_21P5(11, "MICRO_LENS_21P5"),
    MICRO_LENS_38(12, "MICRO_LENS_38");

    companion object {

        // 和 FovType 保持一致：找不到就兜底 UNKNOWN
        fun nativeOf(value: Int?): LensAccessoryType =
            entries.firstOrNull { it.nativeValue == value } ?: UNKNOWN

        fun protoOf(name: String?): LensAccessoryType =
            entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: UNKNOWN
    }
}