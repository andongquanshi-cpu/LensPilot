package com.arashivision.sdk.camera.service.capture.json

import com.arashivision.sdk.common.exception.JsonParseException
import com.arashivision.sdk.common.exception.ProtoLookupException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.success
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * 描述单张 proto 表（如 capture_function_mode），提供双向映射能力。
 * nameToValue 的 key 是枚举名（字符串），value 是对应的整型 proto 值（也以字符串存储）。
 */
internal data class CameraProtoMap(val name: String, val nameToValue: Map<String, String>) {
    /** 反向缓存（value -> name），避免每次 [nameOf] 查询都遍历整张表。 */
    private val valueToName: Map<String, String> = nameToValue.entries.associate { it.value to it.key }

    /**
     * 根据枚举名称取整型值。
     *
     * 特例：proto 表里没有单独定义 VIDEO_LIVING_MODE_WIDE 的数值，直播宽视野模式复用
     * VIDEO_LIVING_MODE_PANO 的数值，这里做名称重写以命中同一条目。排查直播模式相关取值异常时注意此处。
     */
    fun intValue(entryName: String): Result<Int> {
        val valueName = if (entryName == "VIDEO_LIVING_MODE_WIDE") {
            "VIDEO_LIVING_MODE_PANO"
        } else {
            entryName
        }

        return nameToValue[valueName]?.toIntOrNull()?.success() ?: ProtoLookupException("$name/$entryName").failure()
    }

    /**
     * 根据整型值反查枚举名称。
     * 注意：由于 VIDEO_LIVING_MODE_WIDE 与 VIDEO_LIVING_MODE_PANO 共享同一个数值，
     * 反查时只能取到 valueToName 里实际写入的那个名字（取决于 JSON 声明顺序），不保证反查回 WIDE。
     */
    fun nameOf(value: Int): Result<String> = valueToName[value.toString()]?.success() ?: ProtoLookupException("$name/$value").failure()

    /** 返回该表所有整型值，便于一次性渲染（如枚举下拉列表）。 */
    fun allIntValues(): List<Int> = nameToValue.values.mapNotNull { it.toIntOrNull() }
}

/**
 * Kotlin 化的 proto 目录，等价于 C++ `CameraProtoHandle`。
 * 解析后存入不可变 Map，可安全跨线程共享。
 */
internal class CameraProtoCatalog private constructor(private val protoMap: Map<String, CameraProtoMap>) {
    companion object {
        /**
         * JSON -> Catalog 的入口。每个顶层 key 对应一张表。
         */
        fun fromJson(json: String): Result<CameraProtoCatalog> = runCatching {
            cameraJsonParser.parseToJsonElement(json).jsonObject
        }.mapCatching { jsonObject ->
            jsonObject.entries.associate { (key, value) ->
                key to CameraProtoMap(
                    name = key, nameToValue = buildMap {
                        value.jsonObject.forEach { (entryKey, element) ->
                            val entryValue = element.jsonPrimitive.content
                            put(entryKey, entryValue)
                        }
                    })
            }
        }.fold(
            onSuccess = { CameraProtoCatalog(it).success() },
            onFailure = { JsonParseException("Proto JSON parse failed: ${it.message}").failure() }
        )
    }

    /** 根据属性名（即 proto JSON 里的顶层 key，如 capture_function_mode）拿到其映射关系。 */
    fun mapFor(attr: String): Result<CameraProtoMap> = protoMap[attr]?.success() ?: ProtoLookupException(attr).failure()

    /** 将属性名 + 枚举名称映射为整数；属性名不存在或枚举名未声明都会返回 ProtoLookupException。 */
    fun intFor(attr: String, name: String): Result<Int> = mapFor(attr).map { it.intValue(name) }.fold(onSuccess = { it }, onFailure = { it.failure() })

    /** 将属性名 + 整数值映射回枚举名称；用于将底层数值型回调转换成上层可读的枚举字符串。 */
    fun nameFor(attr: String, value: Int): Result<String> = mapFor(attr).map { it.nameOf(value) }.fold(onSuccess = { it }, onFailure = { it.failure() })
}

