package com.arashivision.sdk.camera.service.system

import kotlinx.serialization.Serializable

@Serializable
data class ActiveCameraBean(val code: Int? = 0, val error: String? = null, val msg: String? = "", val errorData: DataBean? = null, val data: DataBean? = null)

@Serializable
data class DataBean(val activation: ActivateBean? = null)

@Serializable
data class ActivateBean(val create_time: Long? = 0, val device_type: String? = "", val serial: String? = "")