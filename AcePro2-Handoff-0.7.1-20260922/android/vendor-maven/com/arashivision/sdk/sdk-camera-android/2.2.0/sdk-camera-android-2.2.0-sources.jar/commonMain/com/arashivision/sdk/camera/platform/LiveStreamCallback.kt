package com.arashivision.sdk.camera.platform

/**
 * 直播推流内部回调接口。
 *
 * 作为 platform 层向 service 层传递推流状态的中立通道，
 * 避免 platform 反向依赖公开 API 层。
 */
interface LiveStreamCallback {
    fun onStarted()
    fun onFps(fps: Int)
    fun onStopped()
    fun onFailed(errorCode: Int, message: String?)
}
