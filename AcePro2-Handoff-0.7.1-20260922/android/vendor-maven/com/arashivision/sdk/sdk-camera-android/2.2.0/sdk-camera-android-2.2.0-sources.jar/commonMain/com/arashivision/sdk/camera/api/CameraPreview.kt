package com.arashivision.sdk.camera.api

import com.arashivision.sdk.camera.api.param.listener.CameraPostureUpdate
import com.arashivision.sdk.camera.api.preview.CameraLiveListener
import com.arashivision.sdk.camera.api.preview.CameraLiveParams
import com.arashivision.sdk.camera.api.preview.CameraStreamListener
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.service.preview.PreviewParams
import com.arashivision.sdk.common.callback.Callback
import com.arashivision.sdk.common.type.KMPCameraPreviewPipeline
import com.arashivision.sdk.common.type.KMPContext

/**
 * 相机预览服务接口。
 *
 * 提供了对相机实时预览流的控制，包括开启/关闭流、请求关键帧、获取流数据通道，
 * 以及监听相机姿态（如陀螺仪数据）的更新。
 */
interface CameraPreview {
    fun init(context: KMPContext)

    /**
     * 开启相机实时预览流。
     * 启动前会自动根据当前相机视频编码配置同步预览流解码配置。
     * 调用此方法后，相机将开始推送预览数据帧。
     */
    fun startStream()

    /**
     * 停止相机实时预览流。
     */
    fun stopStream()

    /**
     * 请求相机立即发送一个 I 帧（关键帧）。
     * 通常在解码器初始化或出现画面花屏时调用，以快速恢复正常画面。
     */
    fun requestStreamIframe()

    /**
     * 获取当前会用于打开预览流的参数快照。
     *
     * 该值结合当前 function mode、录制状态和相机配置计算得到，
     * 可供上层桥接模块生成媒体侧 preview contract。
     */
    fun getPreviewParams(): Result<PreviewParams>

    /**
     * 获取当前预览会话对应的 function mode 快照。
     */
    fun getCurrentFunctionMode(): Result<FunctionMode>

    /**
     * 注册相机姿态更新监听器。
     *
     * 用于接收相机在预览过程中实时传输的姿态（如陀螺仪、加速度计）数据。
     * 注意：方法名虽然是 `registerBatteryListener`，但参数类型为 [CameraPostureUpdate]，这可能是历史遗留命名，实际用于姿态监听。
     *
     * @param listener 姿态更新监听器。
     */
    @Deprecated("Use registerPostureListener instead")
    fun registerBatteryListener(listener: CameraPostureUpdate)

    /** 注册相机姿态更新监听器。 */
    fun registerPostureListener(listener: CameraPostureUpdate)

    /**
     * 注销相机姿态更新监听器。
     *
     * @param listener 需要注销的姿态更新监听器。
     */
    @Deprecated("Use unregisterPostureListener instead")
    fun unregisterBatteryListener(listener: CameraPostureUpdate)

    /** 注销相机姿态更新监听器。 */
    fun unregisterPostureListener(listener: CameraPostureUpdate)

    /** 获取缓存的视频码率（bps）。 */
    fun getVideoBitrate(): Result<Int>

    /** 从相机拉取最新的视频码率（挂起函数）。 */
    suspend fun fetchVideoBitrate(): Result<Int>

    /**
     * 设置视频码率（挂起函数）。
     *
     * @param bitrate 目标码率（bps）。
     */
    suspend fun setVideoBitrate(bitrate: Int): Result<Unit>

    /**
     * 手动覆盖预览流解码配置。
     * 一般情况下无需调用，`startStream()` 会自动同步当前相机的视频编码类型。
     */
    fun setStreamEncode(isH265: Boolean)

    /**
     * 设置预览流渲染管线。
     *
     * @param pipeline 渲染管线实例，传 null 表示清除当前管线。
     */
    fun setPipeline(pipeline: KMPCameraPreviewPipeline?)

    /** 注册相机预览流状态监听器。 */
    fun registerCameraStreamListener(listener: CameraStreamListener)

    /** 注销相机预览流状态监听器。 */
    fun unregisterCameraStreamListener(listener: CameraStreamListener)

    /**
     * 发起 RTMP 直播推流（挂起函数）。
     *
     * 前置条件：必须先将 functionMode 设为 [FunctionMode.VIDEO_LIVE]，并调用 [startStream] 使预览流处于已打开状态
     * （OPENED 或打开后的参数变化态 PARAMS_CHANGED），否则返回 [Result.failure]。
     * 全景拼接/全景原始/平面的具体渲染方式由 [CameraLiveParams.mode] 指定；不传时 SDK 依据相机当前
     * 镜头状态自动判定（双镜头 -> 全景拼接，单镜头/广角 -> 全景原始）。
     * 返回成功仅表示推流请求已受理，实际推流状态通过 [CameraLiveListener] 异步回调。
     *
     * @param params 直播参数（rtmpUrl/直播模式/分辨率/码率；netId 可选，默认 -1）。
     */
    suspend fun startLive(params: CameraLiveParams): Result<Unit>

    /**
     * 发起 RTMP 直播推流（callback 风味）。
     *
     * @see startLive
     */
    fun startLive(params: CameraLiveParams, callback: Callback<Unit>)

    /**
     * 停止直播推流（挂起函数）。
     */
    suspend fun stopLive(): Result<Unit>

    /**
     * 停止直播推流（callback 风味）。
     */
    fun stopLive(callback: Callback<Unit>)

    /** 注册直播推流状态监听器。 */
    fun registerCameraLiveListener(listener: CameraLiveListener)

    /** 注销直播推流状态监听器。 */
    fun unregisterCameraLiveListener(listener: CameraLiveListener)
}
