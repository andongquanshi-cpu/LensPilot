package com.arashivision.sdk.camera.core.model.photography

import com.arashivision.sdk.camera.core.model.BaseEnum

enum class RawType(override val nativeValue: Int, val protoName: String) : BaseEnum {
    OFF(0, "OFF"),
    RAW(1, "RAW"),
    PURE_SHOT(3, "PURESHOT"),
    PURE_SHOT_RAW(4, "PURESHOT_RAW"),
    INSP(5, "INSP"),
    INSP_RAW(6, "INSP_RAW");

    companion object {
        fun nativeOf(value: Int?): RawType = entries.firstOrNull { it.nativeValue == value } ?: OFF
        fun protoOf(name: String?): RawType = entries.firstOrNull { it.protoName.equals(name, ignoreCase = true) } ?: OFF
    }
}