package com.arashivision.sdk.camera.api.param.listener

/**
 * 蓝牙唤醒监听器。
 *
 * 用于监听通过蓝牙唤醒相机的操作结果。
 */
interface BleWakeUpListener {
    /** 蓝牙唤醒成功时回调。 */
    fun onWakeUpSuccess()

    /**
     * 蓝牙唤醒失败时回调。
     *
     * @param errCode 错误码。
     */
    fun onWakeUpError(errCode: Int)
}
