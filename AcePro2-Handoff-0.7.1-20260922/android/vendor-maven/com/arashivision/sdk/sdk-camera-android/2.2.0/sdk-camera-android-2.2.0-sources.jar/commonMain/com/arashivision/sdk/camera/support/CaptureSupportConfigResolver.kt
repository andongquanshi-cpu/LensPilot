package com.arashivision.sdk.camera.support

import com.arashivision.common.Log
import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.option.FocusSensor
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.photography.StreamResolution
import com.arashivision.sdk.camera.service.preview.PreviewParams
import com.arashivision.sdk.bridge.shared.preview.ICaptureSupportConfig
import com.arashivision.sdk.common.kotlin.flatMap

internal fun resolveCaptureSupportConfig(camera: DeviceCore): Result<com.arashivision.sdk.bridge.shared.preview.ICaptureSupportConfig> =
    camera.getCameraConfig().flatMap { cameraConfig ->
        camera.getCameraType().flatMap { cameraType ->
            val functionMode = camera.functionMode
            val snapshot = CameraRuntimeSnapshot(
                cameraType = cameraType,
                functionMode = functionMode,
                currentRecordResolution = resolveRuntimeRecordResolutionOrNull(camera, cameraType, functionMode),
                mediaOffsetV1 = camera.getMediaOffset().getOrElse { "" },
                mediaOffsetV2 = camera.getMediaOffsetV2().getOrElse { "" },
                mediaOffsetV3 = camera.getMediaOffsetV3().getOrElse { "" },
                mediaOffsetV6 = camera.getMediaOffsetV6().getOrElse { "" },
                stabOffset = camera.getOriginOffset().getOrElse { "" },
                offsetState = camera.getOffsetState().map { it.value }.getOrElse { 0 },
                offsetDetectedType = camera.getOffsetDetectedType().map { it.value }.getOrElse { 0 },
                isSelfie = camera.getIsSelfie().getOrElse { false },
                isFlowstateOn = camera.getFlowstateBaseEnable(functionMode).getOrElse { false },
                windowCropInfo = camera.getWindowCropInfo().getOrNull(),
                halfWindowCropInfo = camera.getHalfWindowCropInfo().getOrNull(),
                sensorInfo = camera.getSensorInfo().getOrNull(),
            )
            Result.success(CaptureSupportConfigFactory.create(cameraConfig, snapshot))
        }
    }

internal fun resolveRuntimeRecordResolutionOrNull(
    camera: DeviceCore,
    cameraType: CameraType,
    functionMode: FunctionMode,
): RecordResolution? {
    if (functionMode == FunctionMode.NONE) {
        return null
    }
    val resolution =
        when (cameraType) {
            CameraType.ONE_X -> camera.getVideoResolution().getOrNull()
            CameraType.ONE_X2,
            CameraType.X3,
            -> {
                when (camera.getFocusSensor().getOrNull()) {
                    FocusSensor.FRONT,
                    FocusSensor.REAR,
                    -> camera.getMultiVideoResolution(functionMode).getOrNull()

                    else -> camera.getRecordResolution(functionMode).getOrNull()
                }
            }

            else -> camera.getRecordResolution(functionMode).getOrNull()
        }
    return resolution?.takeUnless { it == RecordResolution.UNKNOWN }
}

internal fun ICaptureSupportConfig.toCameraPreviewParams(
    isForLive: Boolean,
    isForRecord: Boolean,
    isVideo: Boolean = false
): PreviewParams {
//    Log.d("WDebug", "isForLive = $isForLive, isForRecord = $isForRecord, isVideo = $isVideo")
    val params = getPreviewParams(isForLive = isForLive, isForRecord = isForRecord, isVideo)
//    Log.d("WDebug", "params = ${params.firstStream.width}x${params.firstStream.height}_${params.firstStream.fps}")
    return PreviewParams(
        firstStream =
            StreamResolution.getFromResolution(
                params.firstStream.width,
                params.firstStream.height,
                params.firstStream.fps,
            ),
        secondStream =
            StreamResolution.getFromResolution(
                params.secondStream.width,
                params.secondStream.height,
                params.secondStream.fps,
            ),
        previewNum = params.previewNum,
    )
}
