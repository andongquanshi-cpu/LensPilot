package com.arashivision.sdk.camera.service.capture.param.ints

import com.arashivision.sdk.camera.core.DeviceCore
import com.arashivision.sdk.camera.core.model.CameraType
import com.arashivision.sdk.camera.core.model.FunctionMode
import com.arashivision.sdk.camera.core.model.photography.RecordResolution
import com.arashivision.sdk.camera.core.model.timelapse.TimelapseParams
import com.arashivision.sdk.camera.service.capture.json.CameraAttributeManager
import com.arashivision.sdk.camera.service.capture.param.CommonAttrKeys
import com.arashivision.sdk.common.exception.RecordDurationNotFoundException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.success

internal class RecordDurationCameraParam(
    private val recordResolutionProvider: suspend () -> Result<RecordResolution>,
    managerProvider: () -> Result<CameraAttributeManager>,
    deviceCoreProvider: () -> Result<DeviceCore>
) : IntCameraParam(CommonAttrKeys.RECORD_DURATION, managerProvider, deviceCoreProvider) {

    override suspend fun readFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.GO_2 -> {
                device.getResolutionRecordLimits(functionMode).flatMap { limits ->
                    limits.find { recordResolutionProvider().getOrNull() == it.recordResolution }?.limit?.success() ?: RecordDurationNotFoundException().failure()
                }
            }

            CameraType.ACE, CameraType.ACE_PRO, CameraType.ACE_PRO_2, CameraType.X4_AIR, CameraType.X4, CameraType.X5, CameraType.X6, CameraType.GO_ULTRA -> {
                if (functionMode == FunctionMode.VIDEO_LOOP_RECORDING) {
                    device.getRecordDuration(functionMode)
                } else {
                    device.getMaxRecordDuration(functionMode)
                }
            }

            else -> {
                val timelapseMode = functionMode.timelapseMode()
                if (timelapseMode != -1) {
                    device.getTimelapseOption(timelapseMode).map { it.durationS }
                } else {
                    device.getRecordDuration(functionMode)
                }
            }
        }
    }

    override suspend fun fetchFormCamera(device: DeviceCore, functionMode: FunctionMode): Result<Int> {
        return when (device.getCameraType().getOrNull()) {
            CameraType.GO_2 -> {
                device.fetchResolutionRecordLimits(functionMode).flatMap { limits ->
                    limits.find { recordResolutionProvider().getOrNull() == it.recordResolution }?.limit?.success() ?: RecordDurationNotFoundException().failure()
                }
            }

            CameraType.ACE, CameraType.ACE_PRO, CameraType.ACE_PRO_2, CameraType.X4_AIR, CameraType.X4, CameraType.X5, CameraType.X6, CameraType.GO_ULTRA -> {
                if (functionMode == FunctionMode.VIDEO_LOOP_RECORDING) {
                    device.fetchRecordDuration(functionMode)
                } else {
                    device.fetchMaxRecordDuration(functionMode)
                }
            }

            else -> {
                val timelapseMode = functionMode.timelapseMode()
                if (timelapseMode != -1) {
                    device.fetchTimelapseOption(timelapseMode).map { it.durationS }
                } else {
                    device.fetchRecordDuration(functionMode)
                }
            }
        }
    }

    override suspend fun writeToCamera(device: DeviceCore, functionMode: FunctionMode, value: Int): Result<Unit> {
        return when (device.getCameraType().getOrNull()) {
//            CameraType.GO_2 -> {
//                device.getResolutionRecordLimits(functionMode).map { limits ->
//                    limits.find { recordResolutionProvider().getOrNull() == it.recordResolution }?.let {
//                        it.limit = value
//                    }
//                    device.setResolutionRecordLimits(functionMode, limits)
//                }
//            }

            CameraType.ACE, CameraType.ACE_PRO, CameraType.ACE_PRO_2, CameraType.X4_AIR, CameraType.X4, CameraType.X5, CameraType.X6, CameraType.GO_ULTRA -> {
                if (functionMode == FunctionMode.VIDEO_LOOP_RECORDING) {
                    device.setRecordDuration(functionMode, value)
                } else {
                    device.setMaxRecordDuration(functionMode, value)
                }
            }

            else -> {
                val timelapseMode = functionMode.timelapseMode()
                if (timelapseMode != -1) {
                    device.getTimelapseOption(timelapseMode).flatMap {
                        device.setTimelapseOption(
                            functionMode.timelapseMode(),
                            TimelapseParams(value, it.intervalMs, it.accelerateFrequency)
                        )
                    }
                } else {
                    device.setRecordDuration(functionMode, value)
                }
            }
        }
    }
}