package com.arashivision.sdk.camera.api.param.listener

/**
 * 相机断开连接监听器。
 *
 * 用于监听设备与相机之间连接意外断开或主动断开的事件。
 */
interface DisconnectListener {
    /**
     * 当相机断开连接时回调。
     *
     * @param throwable 导致断开连接的异常信息。如果是正常主动断开，此参数可能为 null。
     */
    fun onDisconnect(throwable: Throwable?)
}
