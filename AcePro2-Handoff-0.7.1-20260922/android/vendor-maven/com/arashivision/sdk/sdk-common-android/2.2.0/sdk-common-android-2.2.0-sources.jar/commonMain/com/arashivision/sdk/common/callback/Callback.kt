package com.arashivision.sdk.common.callback

interface Callback<T> {
    fun onSuccess(result: T)
    fun onThrowable(throwable: Throwable)
}

open class CallbackBuilder<T> : Callback<T> {

    private var successBlock: ((T) -> Unit)? = null
    private var throwableBlock: ((Throwable) -> Unit)? = null

    override fun onSuccess(result: T) {
        successBlock?.invoke(result)
    }

    override fun onThrowable(throwable: Throwable) {
        throwableBlock?.invoke(throwable)
    }

    fun success(block: (T) -> Unit): Callback<T> {
        this.successBlock = block
        return this
    }


    fun throwable(block: (Throwable) -> Unit): Callback<T> {
        this.throwableBlock = block
        return this
    }
}

fun <T> callback(block: CallbackBuilder<T>.() -> Unit): Callback<T> {
    return CallbackBuilder<T>().apply(block)
}