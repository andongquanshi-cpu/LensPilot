package com.arashivision.sdk.common.kotlin

import okio.FileSystem

actual val fs: FileSystem = FileSystem.SYSTEM