package com.arashivision.sdk.common.util

import kotlin.concurrent.atomics.AtomicInt
import kotlin.concurrent.atomics.ExperimentalAtomicApi

object EventIdUtils {
    // 原子自增，线程安全，纯 KMP
    @OptIn(ExperimentalAtomicApi::class)
    private val eventId = AtomicInt(0)

    @OptIn(ExperimentalAtomicApi::class)
    fun getEventId(): Int {
        return eventId.addAndFetch(1)
    }
}