package com.arashivision.sdk.common.kotlin

import kotlinx.coroutines.withContext
import okio.FileNotFoundException
import okio.FileSystem
import okio.HashingSink
import okio.Path
import okio.Sink
import okio.blackholeSink
import okio.buffer
import okio.use

expect val fs: FileSystem

/**
 * 预创建目录
 */
fun ensureDirectory(path: Path): Path {
    if (!fs.exists(path)) {
        fs.createDirectories(path, mustCreate = false)
    }
    return path
}

/**
 * 创建空文件
 */
internal fun createFileIfAbsent(path: Path) {
    if (!fs.exists(path)) {
        fs.createDirectories(path.parent!!, mustCreate = false)
        fs.sink(path, mustCreate = true).use { }   // 创建空文件
    }
}

fun Path.exists(): Boolean {
    return fs.exists(this)
}

fun Path.listFiles(): List<Path> {
    if (!fs.exists(this)) return emptyList()
    return fs.list(this)
}

suspend fun writeText(path: Path, text: String, append: Boolean = true): Result<Unit> = withContext(getDispatcherProvider().io) {
    return@withContext try {
        fs.createDirectories(path.parent!!, mustCreate = false)
        val sink = if (append) fs.appendingSink(path, mustExist = false) else fs.sink(path)
        sink.buffer().use { buffer ->
            buffer.writeUtf8(text)
        }
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }
}

suspend fun writeBytes(path: Path, data: ByteArray, append: Boolean = true): Result<Unit> = withContext(getDispatcherProvider().io) {
    return@withContext try {
        fs.createDirectories(path.parent!!, mustCreate = false)
        val sink = if (append) fs.appendingSink(path, mustExist = false) else fs.sink(path)
        sink.buffer().use { buffer ->
            buffer.write(data)
        }
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }
}

suspend fun readText(path: Path): Result<String> = withContext(getDispatcherProvider().io) {
    return@withContext try {
        if (!fs.exists(path)) {
            Result.failure(FileNotFoundException("$path is not found"))
        } else {
            Result.success(fs.source(path).buffer().use { source -> source.readUtf8() })
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}

suspend fun readBytes(path: Path): Result<ByteArray> = withContext(getDispatcherProvider().io) {
    return@withContext try {
        if (!fs.exists(path)) {
            Result.failure(FileNotFoundException("$path is not found"))
        } else {
            Result.success(fs.source(path).buffer().use { source -> source.readByteArray() })
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}

/**
 * 扩展函数：获取当前 Path 对应文件的 MD5 值
 * @return 32位小写 MD5 字符串
 */
fun Path.md5(): String {
    val hashingSink = HashingSink.md5(blackholeSink())
    fs.source(this).buffer().use { source ->
        val sink: Sink = hashingSink.buffer()
        source.readAll(sink)
        sink.close()
    }
    return hashingSink.hash.hex()
}

fun Path.delete(): Result<Unit> {
    return runCatching {
        if (!fs.exists(this)) return@runCatching

        // 如果是文件夹，先删里面所有内容
        if (fs.metadata(this).isDirectory) {
            // 列出所有子项
            fs.list(this).forEach { child ->
                child.delete()
            }
        }
        // 删除自己（文件或空文件夹）
        fs.delete(this)
    }
}

fun Path.clearDirectory(): Result<Unit> {
    return runCatching {
        if (fs.exists(this)) {
            val metadata = fs.metadata(this)
            if (metadata.isDirectory) {
                fs.deleteRecursively(this)
            }
        }
    }
}

/**
 * 扩展 Path：自动创建【所有父目录】
 */
fun Path.makeDirectories(isFile: Boolean = false): Result<Unit> {
    return try {
        // 第一步：先判断路径是否存在
        if (fs.exists(this)) {
            Result.success(Unit)
        } else {
            // 不存在：统一创建**父目录**（完美满足你的需求）
            val targetDir = if (isFile) {
                this.parent ?: return Result.success(Unit)
            } else {
                this
            }
            fs.createDirectories(targetDir)
            Result.success(Unit)
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}

/**
 * Path 扩展：重命名 / 移动 文件或文件夹
 * @param newPath 新的路径
 * @return Result<Unit> 成功/失败
 */
fun Path.renameTo(newPath: Path): Result<Unit> {
    return try {
        // 1. 必须先存在才能重命名
        if (!fs.exists(this)) {
            return Result.failure(IllegalArgumentException("源文件不存在: $this"))
        }

        // 2. 目标已存在则不能覆盖（安全策略）
        if (fs.exists(newPath)) {
            return Result.failure(IllegalStateException("目标文件已存在: $newPath"))
        }

        fs.copy(this, newPath)

        fs.delete(this)

        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }
}

/**
 * String 扩展：获取文件扩展名
 * @return String 扩展名
 */
fun String.fileExtension(): String {
    // 1. 提取文件名（处理路径分隔符：支持 / 和 \）
    val fileName = this.substringAfterLast('/', this).substringAfterLast('\\', this)

    // 2. 找到最后一个 .
    val dotIndex = fileName.lastIndexOf('.')

    // 3. 只有 . 不在第一位（排除隐藏文件）且存在时返回扩展名
    return if (dotIndex > 0) fileName.substring(dotIndex) else ""
}
