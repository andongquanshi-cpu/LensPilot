package com.arashivision.sdk.common.type

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import android.view.MotionEvent
import android.view.Surface
import com.arashivision.graphicpath.render.source.AssetInfo
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline

actual typealias KMPImage = Bitmap

actual typealias KMPAssetInfo = AssetInfo

actual typealias KMPContext = Application

actual typealias KMPTouchEvent = MotionEvent

actual typealias KMPCameraPreviewPipeline = ICameraPreviewPipeline

actual typealias KMPSurface = Surface

actual typealias KMPBleDevice = BluetoothDevice