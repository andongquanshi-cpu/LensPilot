package com.arashivision.sdk.common.exception

const val INSTA_OK = 0
const val INSTA_UNKNOWN = -999999
const val INSTA_NATIVE_RESP_NULL = -1100101

open class InstaException : Exception()

open class NativeException(val nativeErrorCode: Int, override val message: String? = "Exception from native: $nativeErrorCode") : InstaException()
open class NativeRespNullException(override val message: String = "The response returned by Native is null") : NativeException(INSTA_NATIVE_RESP_NULL)
open class UnknownException(override val message: String = "Unknown exception") : InstaException()

open class HttpStatusException(val url: String, val code: Int, override val message: String = "[$url] request failed, status:$code") : InstaException()

open class SdkNotInitializedException(override val message: String = "SDK not initialized") : InstaException()
open class InvalidParameterException(override val message: String = "Invalid parameter") : InstaException()
open class AlreadyReleasedException(override val message: String = "The object has been released and cannot be called") : InstaException()

// 连接异常
open class CameraNotConnectedException(override val message: String = "Camera not connected") : InstaException()
open class BleScanRejectException(override val message: String = "Bluetooth scan rejected, please check if Bluetooth is turned on or if scanning is frequent") : InstaException()
open class BleDeviceNotFoundException(override val message: String = "There are no available camera Bluetooth devices nearby") : InstaException()
open class BleConnectRejectException(override val message: String = "Bluetooth connection rejected, please check if Bluetooth is abnormal") : InstaException()
open class BleScanningException(override val message: String = "Bluetooth scan abnormal, please check Bluetooth permissions or scan frequently") : InstaException()
open class CameraConnectingException(override val message: String = "The camera is currently connecting, please do not initiate the connection again") : InstaException()
open class CameraTypeGetFailedException(override val message: String = "Unable to obtain camera type") : InstaException()
open class CameraOptionFetchException(override val message: String = "Unable to obtain option") : InstaException()
open class CameraTypeNotSupportException(val cameraType: String, override val message: String = "Unsupported camera type: $cameraType") : InstaException()

// 相机相关异常
open class CameraNotSupportException(override val message: String = "The current feature is not supported by this camera") : InstaException()

// 拍摄相关异常
open class CameraCaptureImplInitException(override val message: String = "CameraAttributeManager is not initialized") : InstaException()
open class CameraAttrManagerException(override val message: String = "") : InstaException()
open class CameraCaptureException(override val message: String = "") : InstaException()
open class SwitchFunctionModeException(override val message: String = "Switch function mode exception") : InstaException()
open class SDCardUnavailableException(override val message: String = "SD card not available") : InstaException()
open class SDCardFullException(override val message: String = "SD card full") : InstaException()
open class LowBatteryException(override val message: String = "Low battery level, unable to take photos and videos") : InstaException()
open class CheckBatteryDataException(override val message: String = "check battery data failed,no battery data") : InstaException()
open class CheckStorageDataException(override val message: String = "check storage data failed,no storage data") : InstaException()
open class CheckRemainingException(override val message: String = "check remaining failed,no remaining data") : InstaException()

// json配置异常
open class InvalidLensException(val lens: String, override val message: String = "Lens '$lens' is not defined in attributes JSON") : InstaException()
open class InvalidModeException(val mode: String, override val message: String = "Capture mode '$mode' is not defined for current lens") : InstaException()
open class MissingAttributeException(val attribute: String, override val message: String = "Attribute '$attribute' has not been configured") : InstaException()
open class JsonParseException(override val message: String = "Json parse exception") : InstaException()
open class InvalidStateException(override val message: String = "Invalid state exception") : InstaException()
open class NumberConversionException(override val message: String = "Number conversion exception") : InstaException()
open class ProtoLookupException(val attribute: String, override val message: String = "Proto table does not contain '$attribute'") : InstaException()
open class RecordDurationNotFoundException(override val message: String = "Record duration parameter not found") : InstaException()

// 参数错误异常
open class CaptureGetSupportListException(override val message: String = "") : InstaException()

// 下载文件异常
open class DownloadCameraFileException(override val message: String?) : InstaException()
open class CameraLogFileDownloadingException(override val message: String = "The camera log file is currently being downloaded") : InstaException()

open class MultiVideoOptionValueNullException(val optionKey: String, override val message: String = "Multi video option '$optionKey' is null") : InstaException()
open class PhotographyOptionValueNullException(val optionKey: String, override val message: String = "Photography option '$optionKey' is null") : InstaException()
open class OptionValueNullException(val optionKey: String, override val message: String = "Option '$optionKey' is null") : InstaException()
open class TimelapseOptionValueNullException(val optionKey: String, override val message: String = " Timelapse option '$optionKey' is null") : InstaException()

// 相机激活失败
open class CameraActivateException(val code: Int, override val message: String = "Camera activation failed with error code $code") : InstaException()

// 固件升级错误
open class FirmwareUpgradingException(override val message: String = "The firmware upgrade task is running") : InstaException()
open class FirmwareUpgradeIOException(override val message: String = "Firmware upgrade IO exception") : InstaException()
open class FirmwareUpgradeLowBatteryException(
    val minBatteryLevel: Int,
    override val message: String = "The minimum battery required for firmware upgrade of the camera is $minBatteryLevel%"
) : InstaException()

open class FirmwareUpgradeChargeBoxLowBatteryException(
    val minChargeBoxBatteryLevel: Int,
    override val message: String = "The minimum power required for firmware upgrade in the charging box is $minChargeBoxBatteryLevel%"
) : InstaException()

open class FirmwareUpgradeCancelException(override val message: String = "Firmware upgrade canceled") : InstaException()
open class FirmwareUpgradeUnknownException(override val message: String) : InstaException()
open class FirmwareFileNotFoundException(val filePath: String, override val message: String = "Unable to find firmware file:$filePath") : InstaException()
open class FirmwareUpgradeHttpException(val code: Int, override val message: String = "HTTP error occurred during firmware upgrade:$code") : InstaException()

open class ModuleNotRegisteredException(val moduleName: String, override val message: String = "The $moduleName module not registered") : InstaException()

// 默认异常
class InstaVoidException() : InstaException()


// media部分
open class WorkNotLoadExtraDataException(
    override val message: String = "Work not loaded extra data,Please call the WorkWrapper.loadExtraData() method first"
) : InstaException()

open class PlayerNotPrepareException(
    override val message: String = "Player not prepared"
) : InstaException()

open class LocalFilesNotSupportDownload(
    override val message: String = "Local files do not support download"
) : InstaException()

open class ImageNotSupportExportVideoException(
    override val message: String = "The image does not support exporting videos"
) : InstaException()

open class TemplateInvalidFileTypeException(
    override val message: String = "Template invalid file type"
) : InstaException()

open class TemplateDownloadFailedException(
    override val message: String = "download failed"
) : InstaException()

open class TemplateParseFailedException(
    override val message: String = "Template imageAsset parse failed"
) : InstaException()

open class TemplateInvalidOffsetException(
    override val message: String = "Template invalid offset"
) : InstaException()

open class TemplateInitFailedException(
    override val message: String = "Template init failed"
) : InstaException()

open class TemplateBlenderFailedException(
    override val message: String = "Blend image failed"
) : InstaException()

open class TargetPathEmptyException(
    override val message: String? = "Target path is empty"
) : InstaException()

open class TemplateOtherException(
    errorCode: Int,
    override val message: String? = "Template other exception"
) : NativeException(errorCode)

open class StitchSeparatedFisheyeException(
    errorCode: Int,
    override val message: String? = "Stitch separated fisheye failed"
) : NativeException(errorCode)

open class StitchSeparatedFisheyeParamsException(
    override val message: String? = "Stitch separated fisheye failed, There are less than 2 URL in WorkWrapper"
) : InstaException()

open class GenerateHDRException(
    errorCode: Int,
    override val message: String? = "Generate HDR failed"
) : NativeException(errorCode)

open class GeneratePureShotNotSupportException(
    override val message: String? = "This WorkWrapper does not support PureShot"
) : InstaException()

open class GeneratePureShotModelFileMissingException(
    fileType: String,
    override val message: String? = "$fileType file is missing"
) : InstaException()

open class GeneratePureShotFailedException(
    errorCode: Int,
    override val message: String? = "PureShot generate failed: $errorCode"
) : NativeException(errorCode)
