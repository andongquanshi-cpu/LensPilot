package com.arashivision.sdk.common.util

/**
 * KMP 跨平台版本号对比工具（commonMain 专属，无平台依赖）
 * 支持特性：
 * 1. 正确处理数值对比（1.9.2 < 1.9.10）
 * 2. 兼容段数不一致的版本号（1.9 == 1.9.0 == 1.9.0.0）
 * 3. 忽略版本号后缀（1.9.2-beta == 1.9.2）
 * 4. 跨平台支持（Android、iOS 等，无 JVM/JS/Native 专属 API）
 * 5. 提供直观的比较API和扩展函数
 */
object VersionComparator {
    // Kotlin 跨平台正则：提取版本号中的纯数字段（忽略后缀，如-beta、.RC1等）
    private val VERSION_NUMBER_REGEX = Regex("^\\d+(\\.\\d+)*")

    /**
     * 核心对比方法（跨平台通用）
     * @param version1 第一个版本号（如"1.9.2"）
     * @param version2 第二个版本号（如"1.9.10"）
     * @return Int 对比结果：
     *         -1：version1 < version2
     *          0：version1 == version2
     *          1：version1 > version2
     */
    fun compare(version1: String, version2: String): Int {
        // 步骤1：预处理版本号，提取纯数字段（跨平台实现）
        val cleanVersion1 = cleanVersion(version1)
        val cleanVersion2 = cleanVersion(version2)

        // 步骤2：拆分版本号为数字字符串数组（跨平台 split 方法）
        val versionSegments1 = cleanVersion1.split(".").map { it.trim() }
        val versionSegments2 = cleanVersion2.split(".").map { it.trim() }

        // 步骤3：获取最大段数，补位对齐
        val maxSegmentCount = maxOf(versionSegments1.size, versionSegments2.size)

        // 步骤4：逐段对比数值大小（跨平台 Int 转换）
        for (i in 0 until maxSegmentCount) {
            // 不足的段补0，容错非法数字段
            val segment1 = versionSegments1.getOrElse(i) { "0" }.toIntOrNull() ?: 0
            val segment2 = versionSegments2.getOrElse(i) { "0" }.toIntOrNull() ?: 0

            when {
                segment1 > segment2 -> return 1
                segment1 < segment2 -> return -1
                else -> continue // 该段相等，继续对比下一段
            }
        }

        // 所有段都相等
        return 0
    }

    /**
     * 版本号预处理：提取纯数字段，忽略后缀，处理空值（跨平台实现）
     */
    private fun cleanVersion(version: String): String {
        if (version.isBlank()) return "0"

        // 跨平台正则匹配：find() 方法全平台支持
        val matchResult = VERSION_NUMBER_REGEX.find(version)
        return matchResult?.value ?: "0"
    }
}

// --------------- 跨平台扩展函数（commonMain 可用，无平台依赖） ---------------
/**
 * 版本号大于另一个版本号
 */
fun String.greaterThan(anotherVersion: String): Boolean {
    return VersionComparator.compare(this, anotherVersion) == 1
}

/**
 * 版本号小于另一个版本号
 */
fun String.lessThan(anotherVersion: String): Boolean {
    return VersionComparator.compare(this, anotherVersion) == -1
}

/**
 * 版本号等于另一个版本号
 */
fun String.equalsTo(anotherVersion: String): Boolean {
    return VersionComparator.compare(this, anotherVersion) == 0
}

/**
 * 版本号大于等于另一个版本号
 */
fun String.greaterOrEquals(anotherVersion: String): Boolean {
    val result = VersionComparator.compare(this, anotherVersion)
    return result == 1 || result == 0
}

/**
 * 版本号小于等于另一个版本号
 */
fun String.lessOrEquals(anotherVersion: String): Boolean {
    val result = VersionComparator.compare(this, anotherVersion)
    return result == -1 || result == 0
}