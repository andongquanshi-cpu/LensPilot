package com.arashivision.sdk.common.kotlin

import com.arashivision.sdk.common.callback.Callback


inline fun allNotNull(vararg objects: Any?, crossinline callback: () -> Unit) {
    if (objects.filterNotNull().size == objects.size) callback()
}

/** 扩展函数：将任意值包装为成功结果。 */
fun <T> T.success(): Result<T> = Result.success(this)

/** 扩展函数：将错误转成失败结果。 */
fun <T> Throwable.failure(): Result<T> = Result.failure(this)

/**
 * Result的扁平映射扩展函数：转换函数返回Result<R>，直接返回该Result<R>（展平嵌套）
 * @param transform 转换函数，输入T，返回Result<R>
 * @return 展平后的Result<R>
 */
inline fun <T, R> Result<T>.flatMap(transform: (T) -> Result<R>): Result<R> {
    // fold 处理原Result的成功/失败分支
    return this.fold(
        onSuccess = { transform(it) }, // 原Result成功：执行转换函数，直接返回Result<R>
        onFailure = { Result.failure(it) } // 原Result失败：直接返回失败的Result<R>
    )
}

// 自定义 mapFailure 扩展函数（兼容所有 Kotlin 版本）
inline fun <T> Result<T>.mapFailure(transform: (Throwable) -> Throwable): Result<T> {
    return this.fold(
        onSuccess = { Result.success(it) },
        onFailure = { originalEx -> Result.failure(transform(originalEx)) }
    )
}

// Result转Callback调用
fun <T> Result<T>.invokeCallback(callback: Callback<T>): Result<T> {
    return this.onSuccess {
        callback.onSuccess(it)
    }.onFailure {
        callback.onThrowable(it)
    }
}

/**
 * 扩展函数：分类函数
 */
fun <T> Iterable<T>.classifyPair(
    firstFactors: (T) -> Boolean,
    secondFactors: (T) -> Boolean
): Pair<List<T>, List<T>> {
    val firstList = mutableListOf<T>()
    val secondList = mutableListOf<T>()
    for (item in this) {
        when {
            firstFactors(item) -> firstList.add(item)
            secondFactors(item) -> secondList.add(item)
        }
    }
    return Pair(firstList, secondList)
}

/**
 * 扩展函数：分类函数
 */
fun <T> Iterable<T>.classifyTriple(
    firstFactors: (T) -> Boolean,
    secondFactors: (T) -> Boolean,
    thirdFactors: (T) -> Boolean,
): Triple<List<T>, List<T>, List<T>> {
    val firstList = mutableListOf<T>()
    val secondList = mutableListOf<T>()
    val thirdList = mutableListOf<T>()
    for (item in this) {
        when {
            firstFactors(item) -> firstList.add(item)
            secondFactors(item) -> secondList.add(item)
            thirdFactors(item) -> thirdList.add(item)
        }
    }
    return Triple(firstList, secondList, thirdList)
}

/**
 * 扩展函数：分类函数
 */
fun <T> Iterable<T>.classify(vararg itemFactors: (T) -> Boolean): List<List<T>> {
    val list: MutableList<MutableList<T>> = mutableListOf()
    itemFactors.forEach { _ ->
        list.add(mutableListOf())
    }
    for (item in this) {
        itemFactors.forEachIndexed { index, itemFactor ->
            if (itemFactor(item)) list[index].add(item)
        }
    }
    return list
}




