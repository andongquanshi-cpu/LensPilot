package com.arashivision.sdk.common.log

import com.arashivision.sdk.common.file.InstaFileManager
import com.arashivision.sdk.common.kotlin.getDispatcherProvider
import com.arashivision.sdk.common.kotlin.nowMs
import com.arashivision.sdk.common.kotlin.writeText
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.atomicfu.locks.synchronized
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import kotlin.concurrent.Volatile

// 日志等级
enum class LogLevel { VERBOSE, DEBUG, INFO, WARN, ERROR }

object Logger : Logcat {
    private val callbackLock = SynchronizedObject()
    private val loggerCallbacks: MutableList<LoggerCallback> = mutableListOf()

    private val bufferLock = SynchronizedObject()
    private const val LOG_BUFFER_LIMIT = 20
    private const val FLUSH_INTERVAL_MILLIS = 30_000L
    private val logBuffer = mutableListOf<CachedLog>()

    @Volatile
    private var lastFlushTimestampMillis: Long = 0L

    @Volatile
    private var minLogLevel: LogLevel = LogLevel.VERBOSE


    override fun v(tag: String, message: String) {
        if (!shouldLog(LogLevel.VERBOSE)) return
        logCache(LogLevel.VERBOSE, tag, message, null)
        if (!dispatchToCallbacks { it.onLogD(tag, message) }) {
            getPlatformLogcat().v(tag, message)
        }
    }

    override fun d(tag: String, message: String) {
        if (!shouldLog(LogLevel.DEBUG)) return
        logCache(LogLevel.DEBUG, tag, message, null)
        if (!dispatchToCallbacks { it.onLogD(tag, message) }) {
            getPlatformLogcat().d(tag, message)
        }
    }

    override fun i(tag: String, message: String) {
        if (!shouldLog(LogLevel.INFO)) return
        logCache(LogLevel.INFO, tag, message, null)
        if (!dispatchToCallbacks { it.onLogI(tag, message) }) {
            getPlatformLogcat().i(tag, message)
        }
    }

    override fun w(tag: String, message: String) {
        if (!shouldLog(LogLevel.WARN)) return
        logCache(LogLevel.WARN, tag, message, null)
        if (!dispatchToCallbacks { it.onLogW(tag, message) }) {
            getPlatformLogcat().w(tag, message)
        }
    }

    override fun e(tag: String, message: String, throwable: Throwable?) {
        if (!shouldLog(LogLevel.ERROR)) return
        logCache(LogLevel.ERROR, tag, message, throwable)
        if (!dispatchToCallbacks { it.onLogE(tag, message, throwable) }) {
            getPlatformLogcat().e(tag, message, throwable)
        }
    }

    // 回调管理
    fun registerCallback(callback: LoggerCallback) {
        synchronized(callbackLock) {
            if (!loggerCallbacks.contains(callback)) {
                loggerCallbacks += callback
            }
        }
    }

    fun unregisterCallback(callback: LoggerCallback) {
        synchronized(callbackLock) {
            loggerCallbacks.remove(callback)
        }
    }

    fun clearCallbacks() {
        synchronized(callbackLock) {
            loggerCallbacks.clear()
        }
    }

    fun flushLogs() {
        val flushTime = nowMs()
        val pending = synchronized(bufferLock) {
            if (logBuffer.isEmpty()) {
                null
            } else {
                logBuffer.toList().also { logBuffer.clear() }
            }
        }
        pending?.let { flushEntries(it, flushTime) }
    }

    fun setLogLevel(level: LogLevel) {
        minLogLevel = level
    }

    fun getLogLevel(): LogLevel = minLogLevel

    private fun dispatchToCallbacks(block: (LoggerCallback) -> Unit): Boolean {
        val snapshot = synchronized(callbackLock) { loggerCallbacks.toList() }
        if (snapshot.isEmpty()) {
            return false
        }
        snapshot.forEach(block)
        return true
    }

    private fun logCache(logLevel: LogLevel, tag: String, message: String, throwable: Throwable?) {
        runCatching {
            val now = Clock.System.now()
            val nowDateTime = now.toLocalDateTime(TimeZone.currentSystemDefault())
            val entry = CachedLog(
                date = nowDateTime.date.toString(),
                content = buildString {
                    append(nowDateTime.toString())
                    append(" ${logLevel.name.first()} ")
                    append(tag)
                    append(": ")
                    append(message)
                    throwable?.let {
                        append('\n')
                        append(it.stackTraceToString())
                    }
                    append('\n')
                }
            )

            val nowMillis = now.toEpochMilliseconds()
            if (logLevel == LogLevel.ERROR || logLevel == LogLevel.WARN) {
                flushEntries(listOf(entry), nowMillis)
                return@runCatching
            }

            val pending = synchronized(bufferLock) {
                logBuffer += entry
                val shouldFlushByTime = lastFlushTimestampMillis != 0L &&
                        nowMillis - lastFlushTimestampMillis >= FLUSH_INTERVAL_MILLIS
                if (logBuffer.size >= LOG_BUFFER_LIMIT || shouldFlushByTime) {
                    logBuffer.toList().also { logBuffer.clear() }
                } else {
                    null
                }
            }
            pending?.let { flushEntries(it, nowMillis) }
        }
    }

    private fun flushEntries(entries: List<CachedLog>, flushTimeMillis: Long) {
        CoroutineScope(getDispatcherProvider().io + SupervisorJob() + CoroutineName("Logger-IO")).launch {
            entries
                .groupBy { it.date }
                .forEach { (date, logs) ->
                    val logFile = InstaFileManager.logFile(date)
                    val payload = buildString {
                        logs.forEach { append(it.content) }
                    }
                    writeText(logFile, payload, append = true)
                }
            lastFlushTimestampMillis = flushTimeMillis
        }
    }

    private fun shouldLog(level: LogLevel): Boolean = level.ordinal >= minLogLevel.ordinal

    private data class CachedLog(val date: String, val content: String)
}