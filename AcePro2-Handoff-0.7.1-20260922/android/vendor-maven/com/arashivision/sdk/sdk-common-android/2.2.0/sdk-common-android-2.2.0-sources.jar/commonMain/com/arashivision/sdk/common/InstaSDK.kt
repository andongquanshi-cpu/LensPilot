package com.arashivision.sdk.common

import com.arashivision.sdk.common.exception.SdkNotInitializedException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.type.KMPContext

object InstaSDK {

    private var context: KMPContext? = null

    fun requireContext(): Result<KMPContext> {
        return context?.let {
            Result.success(it)
        } ?: SdkNotInitializedException().failure()
    }

    fun setContext(ctx: KMPContext) {
        if (context != null) return
        context = ctx
    }
}