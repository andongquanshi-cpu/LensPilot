package com.arashivision.sdk.common.kotlin

import android.annotation.SuppressLint
import android.os.Build
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import okhttp3.Dns
import java.net.InetAddress
import java.util.Base64
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 消费 [DynamicHostResolver] 的自定义 DNS：命中占位 hostname 时返回实时解析出的地址，
 * 未命中（含取值为空）时 fallback 系统 DNS，不改变非占位 hostname 的既有解析行为。
 */
private object DynamicCapableDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val dynamic = DynamicHostResolver.resolve(hostname)
        return if (!dynamic.isNullOrBlank()) {
            listOf(InetAddress.getByName(dynamic))
        } else {
            Dns.SYSTEM.lookup(hostname)
        }
    }
}

internal actual val downloadClient: HttpClient by lazy {
    HttpClient(OkHttp) {
        install(HttpTimeout) {
            connectTimeoutMillis = 30_000L
            // 大文件总耗时；过短会表现为「能连上但只下了一部分、文件大小不对」
            requestTimeoutMillis = 3_600_000L
            socketTimeoutMillis = 3_600_000L
        }
        engine {
            config {
                dns(DynamicCapableDns)
            }
        }
    }
}

internal actual val uploadClient: HttpClient by lazy {
    HttpClient(OkHttp) {
        install(HttpTimeout) {
            connectTimeoutMillis = 30_000L
            requestTimeoutMillis = 3_600_000L
            socketTimeoutMillis = 3_600_000L
        }
        engine {
            config {
                dns(DynamicCapableDns)
            }
        }
    }
}

actual fun sign(message: String, secret: String): String {
    try {
        val sha256_HMAC = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(secret.toByteArray(charset("utf-8")), "HmacSHA256")
        sha256_HMAC.init(secretKey)
        val hash = sha256_HMAC.doFinal(message.toByteArray(charset("utf-8")))
        val encode = Base64.getEncoder().encode(hash)
        return String(encode)
    } catch (e: Exception) {
        return ""
    }
}

actual fun encrypt(data: String, secret: String): String {
    // 偏移量
    val ivString: String = generateShortUuid()
    val iv = ivString.toByteArray()
    try {
        val cipher = Cipher.getInstance("AES/CBC/NoPadding")
        val blockSize = cipher.blockSize
        val dataBytes = data.toByteArray()
        var length = dataBytes.size
        // 计算需填充长度
        if (length % blockSize != 0) {
            length += (blockSize - (length % blockSize))
        }

        //这个数组的默认全是O
        val plaintext = ByteArray(length)
        // 填充
        System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.size)
        val keySpec = SecretKeySpec(secret.toByteArray(), "AES")
        // 设置偏移量参数
        val ivSpec = IvParameterSpec(iv)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
        val encryped = cipher.doFinal(plaintext)
        val encode: ByteArray = Base64.getEncoder().encode(join(iv, encryped))
        val utf8 = String(encode, charset("utf8"))
        return utf8
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        return ""
    }
}

fun join(bs1: ByteArray, bs2: ByteArray): ByteArray {
    val r = ByteArray(bs1.size + bs2.size)
    System.arraycopy(bs1, 0, r, 0, bs1.size)
    System.arraycopy(bs2, 0, r, bs1.size, bs2.size)
    return r
}

actual fun generateUuid(): String {
    return UUID.randomUUID().toString().replace("-", "").substring(0, 32)
}

actual fun generateShortUuid(): String {
    return UUID.randomUUID().toString().replace("-", "").substring(0, 16)
}

@SuppressLint("HardwareIds")
actual fun getCustomizedDeviceID(): String {
    var serial: String
    val hardwareId =
        "35" + Build.BOARD.length % 10 + Build.BRAND.length % 10 + Build.CPU_ABI.length % 10 + Build.DEVICE.length % 10 + Build.DISPLAY.length % 10 + Build.HOST.length % 10 + Build.ID.length % 10 + Build.MANUFACTURER.length % 10 + Build.MODEL.length % 10 + Build.PRODUCT.length % 10 + Build.TAGS.length % 10 + Build.TYPE.length % 10 + Build.USER.length % 10 //13 位
    try {
        serial = Build.SERIAL
        //API>=9 使用serial号
        return UUID(hardwareId.hashCode().toLong(), serial.hashCode().toLong()).toString()
    } catch (exception: Exception) {
        //serial需要一个初始化s
        serial = "serial"
    }

    //使用硬件信息拼凑出来的15位号码
    return UUID(hardwareId.hashCode().toLong(), serial.hashCode().toLong()).toString()
}