package com.arashivision.sdk.common.file

import com.arashivision.sdk.common.kotlin.ensureDirectory
import com.arashivision.sdk.common.kotlin.makeDirectories
import okio.Path
import okio.Path.Companion.toPath
import kotlin.concurrent.Volatile

object InstaFileManager {

    @Volatile
    private var fileDir: Path? = null

    @Volatile
    private var cacheDir: Path? = null

    fun init(fileDir: String? = null, cacheDir: String? = null) {
        this.fileDir = (fileDir ?: "${getDefaultFilePath()}/insta").toPath()
        this.cacheDir = (cacheDir ?: "${getDefaultCachePath()}/insta").toPath()
        ensureDirectory(this.fileDir!!)
        ensureDirectory(this.cacheDir!!)
        // 预创建所有目录，规避没有父目录导致的写文件异常

        logDir().makeDirectories()
        cameraLogDir().makeDirectories()
        paramsDir().makeDirectories()
        workDir().makeDirectories()
        downloadDir().makeDirectories()
        stitchFileDir().makeDirectories()
        stitchCacheDir().makeDirectories()
        modelDir().makeDirectories()
        exportDir().makeDirectories()
        stabilizerCacheDir().makeDirectories()
        cutSceneCacheDir().makeDirectories()
        thumbnailCacheDir().makeDirectories()
        templateBlenderCacheDir().makeDirectories()
        editorFileDir().makeDirectories()
        editorCacheDir().makeDirectories()
        mediaFileDir().makeDirectories()
        mediaCacheDir().makeDirectories()
    }


    /**
     * 日志目录
     */
    fun logDir(): Path = resolvePath(requireFiles(), "log")

    /**
     * 日志文件
     */
    fun logFile(date: String): Path = resolvePath(requireFiles(), "log", "logcat-$date.log")

    /**
     * 相机日志目录
     */
    fun cameraLogDir(): Path = resolvePath(requireFiles(), "camera", "log")

    /**
     * json配置参数目录
     */
    fun paramsDir(): Path = resolvePath(requireFiles(), "camera", "params")


    /**
     * work存放目录
     */
    fun workDir(): Path = resolvePath(requireFiles(), "work")

    /**
     * 下载缓存目录
     */
    fun downloadDir(): Path = resolvePath(requireCaches(), "download")

    /**
     * 默认拼接路径
     */
    fun stitchFileDir(): Path = resolvePath(requireFiles(), "stitch")
    fun stitchCacheDir(): Path = resolvePath(requireCaches(), "stitch")

    /**
     * 模型文件目录
     */
    fun modelDir(): Path = resolvePath(requireFiles(), "model")

    /**
     * 默认导出路径
     */
    fun exportDir(): Path = resolvePath(requireFiles(), "export")

    /**
     * 防抖数据缓存路径
     */
    fun stabilizerCacheDir(): Path = resolvePath(requireCaches(), "stabilizer")

    /**
     * 星空模式图片缓存路径
     */
    fun cutSceneCacheDir(): Path = resolvePath(requireCaches(), "cutScene")

    /**
     * work缩略图缓存路径
     */
    fun thumbnailCacheDir(): Path = resolvePath(requireCaches(), "thumbnail")

    /**
     * 模板混合器缓存路径
     */
    fun templateBlenderCacheDir(): Path = resolvePath(requireCaches(), "templateBlender")

    /**
     *  editor专用路径
     */
    fun editorFileDir(): Path = resolvePath(requireFiles(), "editor")
    fun editorCacheDir(): Path = resolvePath(requireCaches(), "editor")

    /**
     *  media 相关路径
     */
    fun mediaFileDir(): Path = resolvePath(requireFiles(), "media")
    fun mediaCacheDir(): Path = resolvePath(requireCaches(), "media")


    private fun requireFiles(): Path = fileDir ?: error("InstaFileManager not configured. Call configure() first.")
    private fun requireCaches(): Path = cacheDir ?: error("InstaFileManager not configured. Call configure() first.")

    private fun resolvePath(root: Path, vararg segments: String): Path = segments.fold(root) { acc, segment ->
        if (segment.isBlank()) acc else acc / segment
    }

    fun getLogDir(): String {
        return logDir().toString()
    }

    fun getCameraLogDir(): String {
        return cameraLogDir().toString()
    }
}