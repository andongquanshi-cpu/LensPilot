package com.arashivision.sdk.common.file

import com.arashivision.sdk.common.InstaSDK

actual fun getDefaultFilePath(): String {
    val ctx = InstaSDK.requireContext().getOrThrow()
    return ctx.getExternalFilesDir(null)?.absolutePath
        ?: "/storage/emulated/0/Android/data/${ctx.packageName}/files"
}

actual fun getDefaultCachePath(): String {
    val ctx = InstaSDK.requireContext().getOrThrow()
    return ctx.externalCacheDir?.absolutePath
        ?: "/storage/emulated/0/Android/data/${ctx.packageName}/cache"
}