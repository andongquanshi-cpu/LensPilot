package com.arashivision.sdk.common.file

/**
 * 获取各平台默认的根目录路径
 */
expect fun getDefaultFilePath(): String

/**
 * 获取各平台默认的根目录路径
 */
expect fun getDefaultCachePath(): String
