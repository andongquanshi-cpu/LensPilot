package com.arashivision.sdk.common.coroutine

import com.arashivision.sdk.common.kotlin.getDispatcherProvider
import com.arashivision.sdk.common.log.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.concurrent.Volatile

open class BaseCoroutine(val baseName: String) {

    private val TAG = "BaseCoroutine"

    @Volatile
    protected var isDestroyed = false

    // 保证状态修改的原子性
    private val mutex = Mutex()

    private val parentJob = SupervisorJob()
    protected val ioScope: CoroutineScope by lazy {
        CoroutineScope(parentJob + getDispatcherProvider().io + CoroutineName("$baseName-IO"))
    }

    protected val mainScope: CoroutineScope by lazy {
        CoroutineScope(parentJob + getDispatcherProvider().main + CoroutineName("$baseName-Main"))
    }

    // ==================== 4. 钩子方法：子类扩展自定义清理 ====================
    /**
     * 子类重写此方法实现自定义资源清理（如清空弱引用、关闭文件流等）
     * 执行时机：父Job已取消，isDestroyed已标记为true
     */
    protected open suspend fun onCoroutineDestroyed() {}

    protected fun destroy() {
        // 用独立Scope执行销毁逻辑，避免依赖被取消的Scope
        CoroutineScope(getDispatcherProvider().default).launch {
            mutex.withLock {
                if (isDestroyed) return@launch
                // 步骤1：取消父Job，终止所有Scope的协程
                parentJob.cancel(CancellationException("${baseName}已销毁"))
                // 步骤2：标记销毁状态
                isDestroyed = true
                // 步骤3：调用子类自定义清理钩子
                onCoroutineDestroyed()
                Logger.d(TAG, "$baseName 协程资源已销毁 | mainScope活跃：${mainScope.isActive} | ioScope活跃：${ioScope.isActive}")
            }
        }
    }

    /**
     * 判断当前是否处于活跃状态（未销毁）
     */
    fun isActive(): Boolean = !isDestroyed && parentJob.isActive
}