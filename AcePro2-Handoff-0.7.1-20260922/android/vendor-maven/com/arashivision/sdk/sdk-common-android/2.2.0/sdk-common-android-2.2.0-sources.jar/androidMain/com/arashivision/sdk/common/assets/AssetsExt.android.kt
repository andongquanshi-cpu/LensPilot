package com.arashivision.sdk.common.assets

import com.arashivision.sdk.common.InstaSDK
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.flatMap
import com.arashivision.sdk.common.kotlin.fs
import com.arashivision.sdk.common.kotlin.success
import com.arashivision.sdk.common.log.Logger
import okio.HashingSink
import okio.Path
import okio.blackholeSink
import okio.buffer
import okio.source
import java.io.IOException


actual fun assetsExistsImpl(assetPath: String): Result<Unit> {
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.open(assetPath).close()
            Unit.success()
        } catch (e: IOException) {
            Logger.e("assetsExistsImpl", e.message ?: "", e)
            e.failure()
        }
    }
}

actual fun assetsReadTextImpl(assetPath: String): Result<String> {
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.open(assetPath).use { input ->
                input.source().buffer().readUtf8()
            }.success()
        } catch (e: IOException) {
            Logger.e("assetsReadTextImpl", e.message ?: "", e)
            e.failure()
        }
    }
}

actual fun assetsReadBytesImpl(assetPath: String): Result<ByteArray> {
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.open(assetPath).use { input ->
                input.source().buffer().readByteArray()
            }.success()
        } catch (e: IOException) {
            Logger.e("assetsReadBytesImpl", e.message ?: "", e)
            e.failure()
        }
    }
}

actual fun assetsCopyToImpl(assetPath: String, targetPath: Path): Result<Unit> {
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.open(assetPath).use { input ->
                input.source().buffer().use { source ->
                    fs.sink(targetPath).buffer().use { sink ->
                        sink.writeAll(source)
                    }
                }
            }
            Unit.success()
        } catch (e: IOException) {
            Logger.e("assetsCopyToImpl", e.message ?: "", e)
            e.failure()
        }
    }
}

actual fun assetsFileSizeImpl(assetPath: String): Result<Long> {
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.openFd(assetPath).use { fd ->
                fd.startOffset
            }.success()
        } catch (e: IOException) {
            Logger.e("assetsFileSizeImpl", e.message ?: "", e)
            e.failure()
        }
    }
}

actual fun assetsMd5Impl(assetPath: String): Result<String> {
    val sink = HashingSink.md5(blackholeSink())
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.open(assetPath).use { input ->
                input.source().buffer().use { source ->
                    source.readAll(sink)
                }
            }
            sink.hash.hex().success()
        } catch (e: IOException) {
            Logger.e("assetsMd5Impl", e.message ?: "", e)
            e.failure()
        }
    }
}

actual fun assetsReadLinesImpl(assetPath: String): Result<List<String>> {
    return InstaSDK.requireContext().flatMap {
        try {
            it.assets.open(assetPath).use { input ->
                input.source().buffer().use { source ->
                    source.readUtf8().lines()
                }
            }.success()
        } catch (e: IOException) {
            Logger.e("assetsReadLinesImpl", e.message ?: "", e)
            e.failure()
        }
    }
}