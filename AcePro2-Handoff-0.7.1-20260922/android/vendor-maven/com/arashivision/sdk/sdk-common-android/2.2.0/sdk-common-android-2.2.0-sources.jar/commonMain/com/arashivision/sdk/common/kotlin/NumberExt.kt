package com.arashivision.sdk.common.kotlin

import kotlin.math.abs
import kotlin.math.round
import kotlin.math.roundToInt

/**
 * Double值四舍五入格式化
 */
fun Double.roundTo(decimals: Int): Double {
    val d = decimals.coerceAtLeast(0)
    var factor = 1.0
    repeat(d) { factor *= 10.0 }
    return round(this * factor) / factor
}

/**
 * 将 Double 转为分子为 1 的分数（1/den），允许一定误差
 */
fun Double.toUnitFraction(tolerance: Double = 1e-6): Pair<Double, Double>? {
    if (this <= 0.0) return null
    val denominator = (1.0 / this).roundToInt().toDouble()
    if (denominator == 0.0) return null
    val restored = 1.0 / denominator
    return if (abs(restored - this) <= tolerance) 1.0 to denominator else null
}

/**
 * 将 Double 转为分子为 1 的分数字符串，无法转换则返回 null
 */
fun Double.toUnitFractionString(tolerance: Double = 1e-6): String? {
    return toUnitFraction(tolerance)?.fractionToString()
}

/**
 * 将形如 "1/3200" 的字符串转为分数 (分子, 分母)，非法时返回 null
 */
fun String.toFraction(): Pair<Double, Double>? {
    val trimmed = trim()
    // 兼容：部分机型/配置用 "0" 表示自动快门（AUTO）
    if (trimmed == "0" || trimmed == "0.0") return 0.0 to 0.0

    // 兼容：当输入是单个数字且 > 1.0 时，按 n/1 处理（如 "10" -> 10/1）
    if (!trimmed.contains('/') && !trimmed.contains('|') && !trimmed.contains(':')) {
        val n = trimmed.toDoubleOrNull()
        if (n != null && n > 1.0) return n to 1.0
    }

    val parts = trimmed.split('/', '|', ':').mapNotNull { it.trim().toDoubleOrNull() }
    if (parts.size != 2) return null
    val (num, den) = parts
    if (den == 0.0) return null
    return num to den
}

/**
 * 将分数字符串（如 "1/3200"）转为 Double，非法返回 null
 */
fun String.fractionToDouble(): Double? {
    return toFraction()?.let { (num, den) ->
        // 自动快门（0/0）按约定返回 0.0
        if (num == 0.0 && den == 0.0) 0.0 else if (den == 0.0) null else num / den
    }
}

fun Pair<Double, Double>.fractionToString(): String {
    // 约定：0（包含 0/0 自动快门场景）统一展示为 "0"
    if (first == 0.0) return "0"

    // 当分数值 > 1 时（如 10/1、10/0.1），仅返回分子展示（如 "10.0"）
    // 分母为 0 时不做该优化，避免除零
    val den = second
    return if (den != 0.0 && (first / den) >= 1.0) {
        first.cleanFractionPart()
    } else {
        "${first.cleanFractionPart()}/${second.cleanFractionPart()}"
    }
}

fun Double.cleanFractionPart(): String =
    if (this % 1.0 == 0.0) this.toInt().toString() else this.toString()


fun String.toIntPairOrNull(): Pair<Int, Int>? {
    val parts = split(',', '|', ':', '/').mapNotNull { it.trim().toIntOrNull() }
    return if (parts.size == 2) parts[0] to parts[1] else null
}

/**
 * 将 Pair<Int, Int> 转换为 "num/time" 格式的字符串
 */
fun Pair<Int, Int>.pairToString(): String {
    return "${first}/${second}"
}

fun String.parseToBurst(): Pair<Int, Int>? {
    val trimmed = trim()
    val parts = trimmed.split('/').mapNotNull { it.trim().toIntOrNull() }
    if (parts.size != 2) return null
    val (num, time) = parts
    if (num <= 0 || time <= 0) return null
    return num to time
}

/**
 * 分数约分
 * @param numerator 分子
 * @param denominator 分母
 */
fun fractionSimplify(numerator: Int, denominator: Int): IntArray {
    require(denominator != 0) { "分母不能为0" }

    var numeratorTemp = numerator
    var denominatorTemp = denominator

    val gcd: Int = gcd(abs(numeratorTemp), abs(denominatorTemp))
    numeratorTemp /= gcd
    denominatorTemp /= gcd

    if (denominator < 0) {
        numeratorTemp = -numeratorTemp
        denominatorTemp = -denominatorTemp
    }

    return intArrayOf(numeratorTemp, denominatorTemp)
}

/**
 * 计算最大公约数
 */
private fun gcd(a: Int, b: Int): Int {
    var a = a
    var b = b
    while (b != 0) {
        val temp = b
        b = a % b
        a = temp
    }
    return a
}

