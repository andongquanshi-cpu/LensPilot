package com.arashivision.sdk.common.callback

interface CoroutineCallback<T> {
    suspend fun onSuccess(result: T)
    suspend fun onThrowable(throwable: Throwable)
}

class CoroutineCallbackBuilder<T> : CoroutineCallback<T> {

    private var successBlock: (suspend (T) -> Unit)? = null
    private var throwableBlock: (suspend (Throwable) -> Unit)? = null

    override suspend fun onSuccess(result: T) {
        successBlock?.invoke(result)
    }

    override suspend fun onThrowable(throwable: Throwable) {
        throwableBlock?.invoke(throwable)
    }

    fun success(block: suspend (T) -> Unit): CoroutineCallback<T> {
        this.successBlock = block
        return this
    }


    fun throwable(block: suspend (Throwable) -> Unit): CoroutineCallback<T> {
        this.throwableBlock = block
        return this
    }
}

fun <T> coroutineCallback(block: CoroutineCallbackBuilder<T>.() -> Unit): CoroutineCallback<T> {
    return CoroutineCallbackBuilder<T>().apply(block)
}