package com.arashivision.sdk.common.kotlin

import com.arashivision.sdk.common.kotlin.DispatcherProvider
import kotlinx.coroutines.Dispatchers

actual fun getDispatcherProvider(): DispatcherProvider {
    return object : DispatcherProvider {
        override val main = Dispatchers.Main
        override val io = Dispatchers.IO
        override val default = Dispatchers.Default
    }
}
