package com.arashivision.sdk.common.kotlin

import kotlinx.coroutines.CoroutineDispatcher

interface DispatcherProvider {
    // 主线程/UI 线程
    val main: CoroutineDispatcher

    // IO 线程（磁盘/网络）
    val io: CoroutineDispatcher

    // 计算型线程（CPU 密集）
    val default: CoroutineDispatcher
}

// 提供默认实现（方便测试）
expect fun getDispatcherProvider(): DispatcherProvider

