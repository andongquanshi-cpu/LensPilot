package com.arashivision.sdk.common.system

const val DEFAULT_BUNDLE_NAME = "com.arashivision.sdk"
const val DEFAULT_APP_NAME = "Unknown"

enum class PlatformType {
    ANDROID, IOS
}

expect val platformType: PlatformType

expect fun getBundleName(): String

expect fun getAppName(): String

expect fun getThreadName(): String

expect fun getCurrentWiFiName(): String



