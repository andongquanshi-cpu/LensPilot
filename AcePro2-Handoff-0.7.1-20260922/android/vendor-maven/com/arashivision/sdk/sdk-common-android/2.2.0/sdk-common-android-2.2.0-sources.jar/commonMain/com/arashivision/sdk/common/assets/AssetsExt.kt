package com.arashivision.sdk.common.assets

import com.arashivision.sdk.common.kotlin.getDispatcherProvider
import kotlinx.coroutines.withContext
import okio.Path

// ==============================
// 公共入口函数（非协程）
// ==============================

fun assetsExists(assetPath: String): Result<Unit> = assetsExistsImpl(assetPath)

fun assetsReadText(assetPath: String): Result<String> = assetsReadTextImpl(assetPath)

fun assetsReadBytes(assetPath: String): Result<ByteArray> = assetsReadBytesImpl(assetPath)

fun assetsCopyTo(assetPath: String, targetPath: Path): Result<Unit> = assetsCopyToImpl(assetPath, targetPath)

fun assetsFileSize(assetPath: String): Result<Long> = assetsFileSizeImpl(assetPath)

fun assetsMd5(assetPath: String): Result<String> = assetsMd5Impl(assetPath)

fun assetsReadLines(assetPath: String): Result<List<String>> = assetsReadLinesImpl(assetPath)

// ==============================
// 公共入口函数（协程包装，切到IO线程）
// ==============================

suspend fun assetsExistsSuspend(assetPath: String): Result<Unit> = withContext(getDispatcherProvider().io) {
    assetsExists(assetPath)
}

suspend fun assetsReadTextSuspend(assetPath: String): Result<String> = withContext(getDispatcherProvider().io) {
    assetsReadText(assetPath)
}

suspend fun assetsReadBytesSuspend(assetPath: String): Result<ByteArray> = withContext(getDispatcherProvider().io) {
    assetsReadBytes(assetPath)
}

suspend fun assetsCopyToSuspend(assetPath: String, targetPath: Path): Result<Unit> = withContext(getDispatcherProvider().io) {
    assetsCopyTo(assetPath, targetPath)
}

suspend fun assetsFileSizeSuspend(assetPath: String): Result<Long> = withContext(getDispatcherProvider().io) {
    assetsFileSize(assetPath)
}

suspend fun assetsMd5Suspend(assetPath: String): Result<String> = withContext(getDispatcherProvider().io) {
    assetsMd5(assetPath)
}

suspend fun assetsReadLinesSuspend(assetPath: String): Result<List<String>> = withContext(getDispatcherProvider().io) {
    assetsReadLines(assetPath)
}

// ==============================
// 平台实现
// ==============================
expect fun assetsExistsImpl(assetPath: String): Result<Unit>
expect fun assetsReadTextImpl(assetPath: String): Result<String>
expect fun assetsReadBytesImpl(assetPath: String): Result<ByteArray>
expect fun assetsCopyToImpl(assetPath: String, targetPath: Path): Result<Unit>
expect fun assetsFileSizeImpl(assetPath: String): Result<Long>
expect fun assetsMd5Impl(assetPath: String): Result<String>
expect fun assetsReadLinesImpl(assetPath: String): Result<List<String>>