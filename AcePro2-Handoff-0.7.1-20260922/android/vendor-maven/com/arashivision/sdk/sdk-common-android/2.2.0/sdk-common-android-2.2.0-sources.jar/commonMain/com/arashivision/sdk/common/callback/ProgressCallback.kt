package com.arashivision.sdk.common.callback

interface ProgressCallback<T, K> : Callback<T> {
    fun onProgress(progress: K)
}

class ProgressCallbackBuilder<T, K> : ProgressCallback<T, K> {

    private var successBlock: ((T) -> Unit)? = null
    private var throwableBlock: ((Throwable) -> Unit)? = null
    private var progressBlock: ((K) -> Unit)? = null

    override fun onSuccess(result: T) {
        successBlock?.invoke(result)
    }

    override fun onProgress(progress: K) {
        progressBlock?.invoke(progress)
    }

    override fun onThrowable(throwable: Throwable) {
        throwableBlock?.invoke(throwable)
    }

    fun success(block: (T) -> Unit): Callback<T> {
        this.successBlock = block
        return this
    }

    fun progress(block: (K) -> Unit): Callback<T> {
        this.progressBlock = block
        return this
    }

    fun throwable(block: (Throwable) -> Unit): Callback<T> {
        this.throwableBlock = block
        return this
    }
}

fun <T, K> progressCallback(block: ProgressCallbackBuilder<T, K>.() -> Unit): ProgressCallback<T, K> {
    return ProgressCallbackBuilder<T, K>().apply(block)
}