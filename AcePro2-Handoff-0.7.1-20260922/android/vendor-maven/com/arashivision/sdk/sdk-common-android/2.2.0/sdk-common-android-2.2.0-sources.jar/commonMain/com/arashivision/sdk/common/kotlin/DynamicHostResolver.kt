package com.arashivision.sdk.common.kotlin

import kotlinx.atomicfu.atomic

/**
 * 通用的"hostname -> 动态解析函数"注册表，供自定义 DNS 实现在请求时消费。
 * 纯字符串键值机制，不感知业务概念；调用方可注册任意占位 hostname 对应的实时取值 lambda。
 */
object DynamicHostResolver {
    private val resolvers = atomic<Map<String, () -> String?>>(emptyMap())

    fun register(hostname: String, resolve: () -> String?) {
        while (true) {
            val current = resolvers.value
            if (resolvers.compareAndSet(current, current + (hostname to resolve))) return
        }
    }

    fun unregister(hostname: String) {
        while (true) {
            val current = resolvers.value
            if (resolvers.compareAndSet(current, current - hostname)) return
        }
    }

    fun resolve(hostname: String): String? = resolvers.value[hostname]?.invoke()
}
