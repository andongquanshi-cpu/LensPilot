package com.arashivision.sdk.common.kotlin

import com.arashivision.sdk.common.exception.DownloadCameraFileException
import com.arashivision.sdk.common.exception.FirmwareFileNotFoundException
import com.arashivision.sdk.common.exception.FirmwareUpgradeHttpException
import com.arashivision.sdk.common.exception.HttpStatusException
import com.arashivision.sdk.common.log.Logger
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.timeout
import io.ktor.client.request.headers
import io.ktor.client.request.post
import io.ktor.client.request.prepareGet
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsChannel
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.content.OutgoingContent
import io.ktor.http.contentLength
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.http.withCharset
import io.ktor.serialization.kotlinx.json.json
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.charsets.Charsets
import io.ktor.utils.io.core.toByteArray
import io.ktor.utils.io.writeStringUtf8
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okio.Buffer
import okio.Path
import okio.Path.Companion.toPath
import okio.buffer
import okio.use
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid


expect fun sign(message: String, secret: String): String

expect fun encrypt(data: String, secret: String): String

private const val TAG = "HttpExt"

val httpClient = HttpClient {
    // 超时配置（避免请求卡死；JSON/短接口用）
    install(HttpTimeout) {
        requestTimeoutMillis = 15_000L // 请求超时15秒
        connectTimeoutMillis = 10_000L // 连接超时10秒
    }

    // JSON序列化（自动解析请求体/响应）
    install(ContentNegotiation) {
        json(Json {
            prettyPrint = true
            ignoreUnknownKeys = true // 忽略未定义字段，提升容错性
            coerceInputValues = true // 兼容空值/类型不匹配（如接口返回"age":"18"转为Int）
        })
    }

    // 日志配置（调试阶段开启，发布时可关闭）
//    install(Logging) {
//        level = LogLevel.NONE
//        // 大文件上传日志屏蔽,否则oom
//        filter { request -> !request.url.encodedPath.endsWith("") }
//        logger = object : Logger {
//            override fun log(message: String) {
//                com.arashivision.sdk.common.log.Logger.i("http", message)
//            }
//        }
//    }
}

/**
 * 专用于大文件/二进制流下载的客户端：不装 ContentNegotiation，避免与 JSON 管线交互；
 * 请求/套接字超时应显著长于 [httpClient]，否则流式读 body 会在中途触发 HttpRequestTimeout，得到不完整文件。
 * 按平台提供实现：Android 端接入自定义 DNS（消费 [DynamicHostResolver]），iOS 端行为与改造前一致。
 */
internal expect val downloadClient: HttpClient

/**
 * 专用于大文件上传的客户端：不装 ContentNegotiation，避免与二进制流式 body 冲突；
 * 超时配置需显著长于 [httpClient]，否则固件上传中途会断开（Broken pipe）。
 * 按平台提供实现：Android 端接入自定义 DNS（消费 [DynamicHostResolver]），iOS 端行为与改造前一致。
 */
internal expect val uploadClient: HttpClient

private const val DOWNLOAD_BUFFER_SIZE = 64 * 1024
private const val DOWNLOAD_PROGRESS_MIN_INTERVAL_MS = 100L
private const val DOWNLOAD_PROGRESS_MIN_BYTES = 256 * 1024L

private const val MAX_BUFFER_SIZE = 256 * 1024

// 与历史 CameraUpgradeTask 保持一致，writeTo 与 calculateTotalLength 必须共用同一格式
private const val CONTENT_TYPE_PART = "Content-Type:application/octet-stream \r\n"

suspend fun download(
    url: String,
    target: Path,
    progress: ((progress: Long, total: Long) -> Unit)? = null
): Result<Path> = withContext(getDispatcherProvider().io) {
    try {
        downloadClient.prepareGet(url).execute { response ->
            if (!response.status.isSuccess()) {
                return@execute HttpStatusException(url, response.status.value).failure()
            }
            val totalBytes = response.contentLength() ?: -1L
            var currentBytes = 0L
            var lastCallbackBytes = 0L
            var lastCallbackTime = 0L
            val parentDir = target.parent
                ?: return@execute DownloadCameraFileException("Target path has no parent directory").failure()
            if (!fs.exists(parentDir)) fs.createDirectories(parentDir)
            if (fs.exists(target)) fs.delete(target)
            val channel: ByteReadChannel = response.bodyAsChannel()
            val buffer = ByteArray(DOWNLOAD_BUFFER_SIZE)
            fs.sink(target).use { sink ->
                // readAvailable 在已关闭且无剩余数据时可能为 0；在通道未关时 0 需继续等下一帧，不能当作 EOF
                while (true) {
                    val readCount = channel.readAvailable(buffer, 0, buffer.size)
                    if (readCount < 0) break
                    if (readCount == 0) {
                        if (channel.isClosedForRead) break
                        continue
                    }
                    val okioBuffer = Buffer()
                    okioBuffer.write(buffer, 0, readCount)
                    sink.write(okioBuffer, readCount.toLong())
                    currentBytes += readCount
                    if (progress != null) {
                        val now = nowMs()
                        val reachEnd = totalBytes in 0L..currentBytes
                        val bytesEnough = currentBytes - lastCallbackBytes >= DOWNLOAD_PROGRESS_MIN_BYTES
                        val timeEnough = now - lastCallbackTime >= DOWNLOAD_PROGRESS_MIN_INTERVAL_MS
                        if (reachEnd || bytesEnough || timeEnough) {
                            lastCallbackBytes = currentBytes
                            lastCallbackTime = now
                            withContext(getDispatcherProvider().main) {
                                progress.invoke(currentBytes, totalBytes)
                            }
                        }
                    }
                }
                if (progress != null && currentBytes != lastCallbackBytes) {
                    withContext(getDispatcherProvider().main) {
                        progress.invoke(currentBytes, totalBytes)
                    }
                }
            }
            target.success()
        }
    } catch (e: Exception) {
        e.failure()
    }
}

fun downloadBlocking(
    url: String,
    target: Path
): Result<Path> = runBlocking { download(url, target, null) }


suspend inline fun <reified T> post(url: String, params: Map<String, String> = emptyMap(), header: Map<String, String>): Result<T> =
    withContext(getDispatcherProvider().io) {
        try {
            val response = httpClient.post(url) {

                headers.append(HttpHeaders.Accept, "application/json")
                header.forEach {
                    headers.append(it.key, it.value)
                }

                contentType(ContentType.Application.Json.withCharset(Charsets.UTF_8))

                setBody(params)
            }

            // 校验响应状态码
            if (response.status.isSuccess()) {
                val result: T = response.body()
                Result.success(result)
            } else {
                Result.failure(HttpStatusException(url, response.status.value))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

@OptIn(ExperimentalUuidApi::class)
suspend fun doUpload(uploadUrl: String, filePath: String, progressCallback: (Double) -> Unit): Result<Unit> = withContext(getDispatcherProvider().io) {
    val boundary = Uuid.random().toString()

    // 发布初始进度（0%）
    progressCallback.invoke(0.0)

    // 校验文件存在性
    val file = filePath.toPath()
    if (!fs.exists(file)) {
        FirmwareFileNotFoundException(filePath).failure()
    } else {
        val fileLength = fs.metadata(file).size ?: 0

        // 计算总长度（同原代码的totalLength）
        val totalLength = calculateTotalLength(boundary, file.name, fileLength)
        Logger.i(TAG, "upgrade firmware upload url=$uploadUrl fileLength=$fileLength totalLength=$totalLength")

        // 执行HTTP上传
        val response = uploadClient.post(uploadUrl) {
            method = HttpMethod.Post
            timeout {
                connectTimeoutMillis = 30 * 1000
                requestTimeoutMillis = 10 * 60 * 1000
                socketTimeoutMillis = 10 * 60 * 1000
            }
            headers {
                append(HttpHeaders.Connection, "Close")
            }

            // 自定义上传内容（实现multipart/form-data和进度回调）
            setBody(object : OutgoingContent.WriteChannelContent() {
                // 必须在这里（而非 headers { append(ContentType, ...) }）携带 boundary：
                // ktor 引擎发请求时以 OutgoingContent.contentType 为准合并请求头（mergeHeaders），
                // headers 里手动 append 的 Content-Type 会被丢弃，导致服务端收到缺 boundary 的
                // "multipart/form-data"，解析失败
                override val contentType: ContentType = ContentType.parse("multipart/form-data;boundary=$boundary")
                override val contentLength: Long = totalLength

                override suspend fun writeTo(channel: ByteWriteChannel) {
                    // 写入multipart头部
                    channel.writeStringUtf8("--$boundary\r\n")
                    channel.writeStringUtf8("Content-Disposition: form-data; name=\"file\"; filename=\"${file.name}\"\r\n")
                    channel.writeStringUtf8(CONTENT_TYPE_PART)
                    channel.writeStringUtf8("\r\n")

                    // 分块读取文件并写入通道（同原代码的while循环）
                    val source = fs.source(file).buffer()
                    var uploadedLength = 0L

                    try {
                        val buffer = ByteArray(MAX_BUFFER_SIZE)
                        var bytesRead = source.read(buffer)

                        while (bytesRead != -1 && currentCoroutineContext().isActive) {
                            channel.writeFully(buffer, 0, bytesRead)
                            uploadedLength += bytesRead
                            if (fileLength > 0) {
                                val progress = uploadedLength.toDouble() / fileLength
                                progressCallback.invoke(progress)
                            }
                            bytesRead = source.read(buffer)
                        }

                        if (!currentCoroutineContext().isActive) {
                            throw CancellationException("Upload cancelled", Exception())
                        }

                        channel.writeStringUtf8("\r\n")
                        channel.writeStringUtf8("--$boundary--\r\n")
                        progressCallback.invoke(1.0)
                    } finally {
                        source.close()
                    }
                }
            })
        }

        // 处理响应结果（同原代码的responseCode判断）
        when (response.status.value) {
            200 -> Result.success(Unit)
            else -> FirmwareUpgradeHttpException(response.status.value).failure()
        }
    }
}

private fun calculateTotalLength(boundary: String, fileName: String, fileLength: Long): Long {
    val headerLength = (
            "--$boundary\r\n" +
                    "Content-Disposition: form-data; name=\"file\"; filename=\"$fileName\"\r\n" +
                    CONTENT_TYPE_PART +
                    "\r\n"
            ).toByteArray(Charsets.UTF_8).size.toLong()
    val footerLength = "\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8).size.toLong()
    return headerLength + fileLength + footerLength
}


fun String.getFilenameFromUrl(): String? {
    if (!this.isStartWithProtocol()) return null

    // 2. 步骤1：剥离查询参数（? 及之后）和锚点（# 及之后）
    val urlWithoutQueryAndAnchor = trim().split("?", "#") // 按 ? 或 # 分割，取第一部分
        .first()

    // 3. 步骤2：移除路径末尾的 /（避免如 "path/" 导致截取空字符串）
    val urlWithoutTrailingSlash = urlWithoutQueryAndAnchor.removeSuffix("/")

    // 4. 步骤3：找最后一个 / 的位置，截取其后的字符串（文件名）
    val lastSlashIndex = urlWithoutTrailingSlash.lastIndexOf("/")
    // 无 / 或 / 是最后一个字符（已移除）→ 无文件名
    if (lastSlashIndex == -1 || lastSlashIndex == urlWithoutTrailingSlash.length - 1) {
        return null
    }

    // 5. 截取文件名并校验（空则返回 null）
    val filename = urlWithoutTrailingSlash.substring(lastSlashIndex + 1)
    return filename.ifBlank { null }
}

/**
 * 判断字符串是否以网络协议开头

 * @return 是否以网络协议开头
 */
fun String.isStartWithProtocol(): Boolean {
    if (isEmpty()) {
        return false
    }
    val regex = "^((https|http|ftp|rtsp|mms)?://).*".toRegex()
    return regex.matches(lowercase())
}

expect fun generateUuid(): String

expect fun generateShortUuid(): String

expect fun getCustomizedDeviceID(): String