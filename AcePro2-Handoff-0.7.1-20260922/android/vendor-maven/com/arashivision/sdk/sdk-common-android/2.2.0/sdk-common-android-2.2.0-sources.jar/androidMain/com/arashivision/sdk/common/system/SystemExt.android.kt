package com.arashivision.sdk.common.system

import android.content.Context
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.net.wifi.WifiManager.UNKNOWN_SSID
import com.arashivision.sdk.common.InstaSDK
import com.arashivision.sdk.common.log.Logger

private const val TAG = "SystemExt"

actual fun getBundleName(): String {
    return (InstaSDK.requireContext().getOrNull())?.packageName ?: DEFAULT_BUNDLE_NAME
}

actual val platformType: PlatformType = PlatformType.ANDROID

actual fun getAppName(): String {
    return (InstaSDK.requireContext().getOrNull())?.let {
        try {
            val applicationInfo = it.packageManager.getApplicationInfo(it.packageName, 0)
            applicationInfo.loadLabel(it.packageManager).toString().trim()
        } catch (e: Exception) {
            DEFAULT_APP_NAME
        }
    } ?: DEFAULT_APP_NAME
}

actual fun getThreadName(): String {
    return Thread.currentThread().name
}

actual fun getCurrentWiFiName(): String {
    return (InstaSDK.requireContext().getOrNull())?.let {
        try {
            val wifiManager = it.getSystemService(Context.WIFI_SERVICE) as WifiManager
            getWiFiNameByWiFiInfo(wifiManager.connectionInfo)
        } catch (t: Throwable) {
            Logger.w(TAG, "get wifi name failed:${t.message}")
            ""
        }
    } ?: ""
}

private fun getWiFiNameByWiFiInfo(wifiInfo: WifiInfo?): String {
    return wifiInfo?.ssid?.let {
        if (it.isEmpty() || it == UNKNOWN_SSID) return ""
        val lastPos = it.length - 1
        if (lastPos > 0 && it[0] == '"' && it[lastPos] == '"') {
            it.substring(1, lastPos)
        } else {
            ""
        }
    } ?: ""
}