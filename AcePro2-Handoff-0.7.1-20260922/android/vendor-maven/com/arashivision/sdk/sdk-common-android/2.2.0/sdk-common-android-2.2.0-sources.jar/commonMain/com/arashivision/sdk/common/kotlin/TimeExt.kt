package com.arashivision.sdk.common.kotlin


import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.TimeZone
import kotlinx.datetime.format
import kotlinx.datetime.format.DateTimeFormat
import kotlinx.datetime.format.Padding
import kotlinx.datetime.format.char
import kotlinx.datetime.toLocalDateTime

fun nowMs(): Long = Clock.System.now().toEpochMilliseconds()

/**
 * 格式化【秒级时间戳】Long 扩展函数
 * @param pattern 格式：yyyy-MM-dd HH:mm:ss
 * @param timeZone 时区，默认当前系统时区
 */
fun Long.formatTimestamp(
    pattern: String = "yyyy-MM-dd HH:mm:ss",
    timeZone: TimeZone = TimeZone.currentSystemDefault()
): String {
    val instant = Instant.fromEpochSeconds(this)
    return formatInternal(instant, pattern, timeZone)
}

/**
 * 格式化【毫秒级时间戳】Long 扩展函数
 * @param pattern 格式：yyyy-MM-dd HH:mm:ss
 * @param timeZone 时区，默认当前系统时区
 */
fun Long.formatMilliTimestamp(
    pattern: String = "yyyy-MM-dd HH:mm:ss",
    timeZone: TimeZone = TimeZone.currentSystemDefault()
): String {
    val instant = Instant.fromEpochMilliseconds(this)
    return formatInternal(instant, pattern, timeZone)
}

private fun formatInternal(
    instant: Instant,
    pattern: String,
    timeZone: TimeZone
): String {
    val dateTime: LocalDateTime = instant.toLocalDateTime(timeZone)
    val format = createLocalDateTimeFormat(pattern)
    return dateTime.format(format)
}

/**
 * 直接生成 LocalDateTime 支持的格式，解决类型不匹配
 */
private fun createLocalDateTimeFormat(pattern: String): DateTimeFormat<LocalDateTime> {
    return LocalDateTime.Format {
        var i = 0
        while (i < pattern.length) {
            val c = pattern[i]
            when {
                // 年
                c == 'y' && pattern.startsWith("yyyy", i) -> {
                    year()
                    i += 4
                }
                // 月（补零）
                c == 'M' && pattern.startsWith("MM", i) -> {
                    monthNumber(Padding.ZERO)
                    i += 2
                }
                // 日（补零）
                c == 'd' && pattern.startsWith("dd", i) -> {
                    dayOfMonth(Padding.ZERO)
                    i += 2
                }
                // 24小时制
                c == 'H' && pattern.startsWith("HH", i) -> {
                    hour(Padding.ZERO)
                    i += 2
                }
                // 分钟
                c == 'm' && pattern.startsWith("mm", i) -> {
                    minute(Padding.ZERO)
                    i += 2
                }
                // 秒
                c == 's' && pattern.startsWith("ss", i) -> {
                    second(Padding.ZERO)
                    i += 2
                }
                // 普通字符
                else -> {
                    char(c)
                    i++
                }
            }
        }
    }
}
