package com.arashivision.sdk.common.log

interface LoggerCallback {
    fun onLogD(tag: String, message: String)
    fun onLogI(tag: String, message: String)
    fun onLogW(tag: String, message: String)
    fun onLogE(tag: String, message: String, throwable: Throwable? = null)
}

class LoggerCallbackBuilder : LoggerCallback {

    private var onLogDBlock: ((String, String) -> Unit)? = null
    private var onLogIBlock: ((String, String) -> Unit)? = null
    private var onLogWBlock: ((String, String) -> Unit)? = null
    private var onLogEBlock: ((String, String, Throwable?) -> Unit)? = null

    override fun onLogD(tag: String, message: String) {
        onLogDBlock?.invoke(tag, message)
    }

    override fun onLogI(tag: String, message: String) {
        onLogIBlock?.invoke(tag, message)
    }

    override fun onLogW(tag: String, message: String) {
        onLogWBlock?.invoke(tag, message)
    }

    override fun onLogE(tag: String, message: String, throwable: Throwable?) {
        onLogEBlock?.invoke(tag, message, throwable)
    }

    fun logD(block: (String, String) -> Unit): LoggerCallback {
        this.onLogDBlock = block
        return this
    }

    fun logI(block: (String, String) -> Unit): LoggerCallback {
        this.onLogIBlock = block
        return this
    }

    fun logW(block: (String, String) -> Unit): LoggerCallback {
        this.onLogWBlock = block
        return this
    }

    fun logE(block: (String, String, Throwable?) -> Unit): LoggerCallback {
        this.onLogEBlock = block
        return this
    }

}

fun <T> logCallback(block: LoggerCallbackBuilder.() -> Unit): LoggerCallback {
    return LoggerCallbackBuilder().apply(block)
}

