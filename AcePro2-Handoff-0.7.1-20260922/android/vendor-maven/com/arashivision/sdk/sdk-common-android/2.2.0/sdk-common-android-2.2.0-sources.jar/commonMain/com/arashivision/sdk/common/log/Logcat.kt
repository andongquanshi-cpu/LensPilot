package com.arashivision.sdk.common.log

interface Logcat {
    fun v(tag: String, message: String)
    fun d(tag: String, message: String)
    fun i(tag: String, message: String)
    fun w(tag: String, message: String)
    fun e(tag: String, message: String, throwable: Throwable? = null)
}

expect fun getPlatformLogcat(): Logcat