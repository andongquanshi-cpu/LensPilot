package com.arashivision.sdk.bridge.shared.preview

enum class PreviewFileType {
    UNPANORAMA,
    VR360,
    FISH_EYE,
    WIDE_ANGLE,
    SPECIAL_SELFIE,
}
