package com.arashivision.sdk.bridge

interface ModuleProvider