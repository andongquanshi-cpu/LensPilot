package com.arashivision.sdk.bridge.shared.preview

enum class PreviewFitMode(val nativeValue: Int) {
    NONE(0),
    CONTAIN(1),
    FILL(2),
    COVER(3),
    FIT_10(10),
}
