package com.arashivision.sdk.bridge.shared.preview

data class CaptureSupportPreviewStream(
    val width: Int,
    val height: Int,
    val fps: Int,
)

data class CaptureSupportPreviewParams(
    val firstStream: CaptureSupportPreviewStream,
    val secondStream: CaptureSupportPreviewStream,
    val previewNum: Int,
)
