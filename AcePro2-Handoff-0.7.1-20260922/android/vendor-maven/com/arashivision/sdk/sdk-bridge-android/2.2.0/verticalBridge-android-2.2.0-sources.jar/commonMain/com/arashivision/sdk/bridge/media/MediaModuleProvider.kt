package com.arashivision.sdk.bridge.media

import com.arashivision.sdk.bridge.ModuleProvider

interface MediaModuleProvider : ModuleProvider {
}