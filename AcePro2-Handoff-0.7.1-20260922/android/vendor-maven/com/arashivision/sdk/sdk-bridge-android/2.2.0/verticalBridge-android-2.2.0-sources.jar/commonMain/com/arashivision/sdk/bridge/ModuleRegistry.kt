package com.arashivision.sdk.bridge

import com.arashivision.sdk.bridge.camera.CameraModuleProvider
import com.arashivision.sdk.bridge.media.MediaModuleProvider
import com.arashivision.sdk.common.exception.ModuleNotRegisteredException
import com.arashivision.sdk.common.kotlin.failure
import com.arashivision.sdk.common.kotlin.success

object ModuleRegistry {
    private var cameraModule: CameraModuleProvider? = null
    private var mediaModule: MediaModuleProvider? = null

    fun install(moduleProvider: ModuleProvider) {
        when (moduleProvider) {
            is CameraModuleProvider -> cameraModule = moduleProvider
            is MediaModuleProvider -> mediaModule = moduleProvider
        }
    }

    fun getCameraModule(): Result<CameraModuleProvider> =
        cameraModule?.success() ?: ModuleNotRegisteredException("camera").failure()

    fun getMediaModule(): Result<MediaModuleProvider> =
        mediaModule?.success() ?: ModuleNotRegisteredException("media").failure()
}