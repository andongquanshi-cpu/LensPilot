package com.arashivision.sdk.bridge.shared.preview

data class CameraPreviewConstraintData(
    val widthRatio: Int,
    val heightRatio: Int,
    val minFov: Float,
    val maxFov: Float,
    val defaultFov: Float,
    val minDistance: Float,
    val maxDistance: Float,
    val defaultDistance: Float,
)
