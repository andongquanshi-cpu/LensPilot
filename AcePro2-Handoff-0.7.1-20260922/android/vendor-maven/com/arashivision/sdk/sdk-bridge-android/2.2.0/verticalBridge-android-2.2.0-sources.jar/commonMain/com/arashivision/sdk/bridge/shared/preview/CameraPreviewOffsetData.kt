package com.arashivision.sdk.bridge.shared.preview

data class CameraPreviewOffsetData(
    val offsetV1: String,
    val offsetV2: String,
    val offsetV3: String,
    val offsetState: Int,
    val offsetDetectedType: Int,
    val offsetV6: String = "",
)
