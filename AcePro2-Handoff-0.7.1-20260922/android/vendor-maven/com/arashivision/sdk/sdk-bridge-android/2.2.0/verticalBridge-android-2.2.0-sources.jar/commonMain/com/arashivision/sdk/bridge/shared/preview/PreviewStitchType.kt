package com.arashivision.sdk.bridge.shared.preview

enum class PreviewStitchType(val nativeValue: Int) {
    NORMAL(0),
    DYNAMIC(1),
    OPTICAL_FLOW(2),
    AI_FLOW(3),
}
