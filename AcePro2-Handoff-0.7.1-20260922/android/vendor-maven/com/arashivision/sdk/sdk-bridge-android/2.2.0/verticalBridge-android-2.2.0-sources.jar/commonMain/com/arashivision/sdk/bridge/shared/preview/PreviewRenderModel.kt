package com.arashivision.sdk.bridge.shared.preview

enum class PreviewRenderModel(val nativeValue: Int) {
    AUTO(0),
    SPHERE_STITCH(2),
    SPHERE_FISHEYE_DEWARP(4),
    PLANE_STITCH(11),
    PLANE(20),
}
