package com.arashivision.sdk.bridge.camera

import com.arashivision.sdk.bridge.ModuleProvider
import com.arashivision.sdk.bridge.shared.preview.ICaptureSupportConfig

interface CameraModuleProvider : ModuleProvider {

    fun getHttpPrefix(): Result<String>

    /**
     * 供 SDK 内部下载器专用的 HTTP 前缀。Wi-Fi Aware 场景下返回占位 hostname（配合动态 DNS resolver），
     * 与 [getHttpPrefix] 返回的裸 IPv6 地址不同——后者供原生编辑 SDK 等外部消费方直接使用，
     * 不能替换为占位 hostname（占位 hostname 无法被系统级 DNS 解析）。
     *
     * 内部跨模块契约方法，不面向外部 SDK 集成方；返回值（如占位 hostname 字符串）不应外泄到日志/UI。
     */
    fun getDownloadHttpPrefix(): Result<String>

    /**
     * 同一时刻、同一相机实例下的 [getHttpPrefix] 与 [getDownloadHttpPrefix] 组合值（[Pair.first]/[Pair.second]）。
     * 分别调用 [getHttpPrefix] 与 [getDownloadHttpPrefix] 之间如果发生连接切换（如 Wi-Fi Aware 断开退回 BLE），
     * 两次调用可能取到不同连接实例的值，导致把一个相机的前缀替换成另一个相机的前缀；
     * 需要"两个前缀配对一致"的调用方（如按前缀替换 URL）必须使用本方法而非分别调用。
     */
    fun getHttpPrefixPair(): Result<Pair<String, String>>

    fun getCaptureSupportConfig(): Result<ICaptureSupportConfig>

    suspend fun getCameraInfoMap(): Result<Map<String, ByteArray>>

    suspend fun getAllUrlList(): Result<List<String>>

    suspend fun getRawUrlList(): Result<List<String>>

    suspend fun getAllInsDataList(): Result<List<String>>

    suspend fun downloadCameraFile(url: String, progressCallback: ((progress: Long, total: Long) -> Unit)? = null): Result<String>

    suspend fun downloadCameraFiles(urls: Array<String>, progressCallback: ((totalSize: Long, downloadedSize: Long) -> Unit)? = null): Result<List<String>>

    suspend fun deleteCameraFile(urls: Array<String>): Result<Unit>

    fun requestStreamIframe(): Result<Unit>

    fun getRollingShutterTime(): Result<Double>
}