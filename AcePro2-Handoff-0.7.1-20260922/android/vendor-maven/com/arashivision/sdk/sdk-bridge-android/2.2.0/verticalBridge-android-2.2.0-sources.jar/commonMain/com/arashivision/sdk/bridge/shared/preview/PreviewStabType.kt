package com.arashivision.sdk.bridge.shared.preview

enum class PreviewStabType(val nativeValue: Int) {
    STAB_OFF(-1),
    STAB_STILL(0),
    STAB_Z_DIRECTIONAL(1),
    STAB_FULL_DIRECTIONAL(2),
    STAB_FREE_FOOTAGE(4),
}
