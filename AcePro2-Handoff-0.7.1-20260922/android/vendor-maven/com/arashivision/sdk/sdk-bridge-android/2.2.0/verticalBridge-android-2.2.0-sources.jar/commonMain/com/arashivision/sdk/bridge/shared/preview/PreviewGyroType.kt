package com.arashivision.sdk.bridge.shared.preview

enum class PreviewGyroType(val nativeValue: Int) {
    UNKNOWN(-1),
    ONE_X(16),
    GO2(50),
    GO3S(156),
    GO_ULTRA(153),
    ONE_X2(26),
    ONE_X2_REVERSE(27),
    ONE_X2_Z180(28),
    X3_FISHEYE(145),
    X3_Z180(147),
    ONE_R_WIDE(18),
    ONE_R_FISHEYE(17),
    ONE_R_FISHEYE_REVERSE(19),
    ONE_RS_WIDEANGLE(32),
    ONE_RS_PANO_283(36),
    ONE_RS_PANO_283_REVERSE(37),
}
