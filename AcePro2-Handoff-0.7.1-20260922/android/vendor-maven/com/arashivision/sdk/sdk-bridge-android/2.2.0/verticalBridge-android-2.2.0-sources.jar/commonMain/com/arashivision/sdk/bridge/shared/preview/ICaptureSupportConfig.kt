package com.arashivision.sdk.bridge.shared.preview

import com.arashivision.sdk.common.type.KMPAssetInfo

interface ICaptureSupportConfig {
    val previewAssetInfo: KMPAssetInfo?
    val stabAssetInfo: KMPAssetInfo?
    fun getPreviewParams(
        isForLive: Boolean = false,
        isForRecord: Boolean = false,
        isVideo: Boolean = false
    ): CaptureSupportPreviewParams
    val previewWidth: Int
    val previewHeight: Int
    val previewFps: Int
    val previewScreenRatio: Pair<Int, Int>
    val previewFileType: PreviewFileType
    val previewFitMode: PreviewFitMode
    val previewGyroType: PreviewGyroType
    val previewStitchType: PreviewStitchType
    val previewStabType: PreviewStabType
    val previewCameraType: String
    val previewRenderModelType: PreviewRenderModel
    val isRotateEnabled: Boolean
    val isRotateScreenRatioEnabled: Boolean
    val isFlowstateOn: Boolean
    val isStabilizeEnabled: Boolean
    val isGestureEnabledByMode: Boolean
    val isImageFusionEnabled: Boolean
    val isDualStream: Boolean
    val isFishEyeEdgePaddingEnabled: Boolean
    val isBlendAngleOptimizeEnabled: Boolean
    val isPowerPanoEnabled: Boolean
    val isDynamicAlphaSupported: Boolean
    val isBlendUsingFisheyeMaskSupported: Boolean
    val isSupportUpFlowV2: Boolean
    val isSelfie: Boolean
    val previewDeltaNs: Long
    val frameDurationMs: Int
    val stabOffset: String
    val mediaOffset: CameraPreviewOffsetData
    val constraintData: CameraPreviewConstraintData
}