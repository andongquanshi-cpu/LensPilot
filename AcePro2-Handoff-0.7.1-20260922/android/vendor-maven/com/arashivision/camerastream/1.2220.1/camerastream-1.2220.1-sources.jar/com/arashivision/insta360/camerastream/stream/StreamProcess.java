package com.arashivision.insta360.camerastream.stream;

import static com.arashivision.insta360.camerastream.strategy.TraceUtil.TRACE;
import static com.arashivision.insta360.camerastream.stream.NumberUtil.bytes2Double;
import static com.arashivision.insta360.camerastream.stream.NumberUtil.bytesToHex;

import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.arashivision.insta360.camerastream.bean.AudioParam;
import com.arashivision.insta360.camerastream.bean.StartStreamingParam;
import com.arashivision.insta360.camerastream.bean.StreamType;
import com.arashivision.insta360.camerastream.bean.VideoParam;
import com.arashivision.insta360.camerastream.listener.ICameraPreviewListener;
import com.arashivision.insta360.camerastream.util.H2645Parser;
import com.arashivision.insta360.camerastream.util.H264Parser;
import com.arashivision.insta360.camerastream.util.H265Parser;
import com.arashivision.onestream.AbstractPlayer;
import com.arashivision.onestream.AudioData;
import com.arashivision.onestream.Gyro.OneGyroField;
import com.arashivision.onestream.ImageData;
import com.arashivision.onestream.OneStreamPipeline;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;


/**
 * 处理相机stream
 * <p>
 * 如果想要显示图像，就需要设置这个参数
 */
public class StreamProcess {

    private static final String TAG = StreamProcess.class.getName();
    private final Object mSyncExtraData = new Object();

    private H2645Parser mParser;
    private H2645Parser mParserR;
    private H2645Parser.H2645Frame mLastFrame;
    private H2645Parser.H2645Frame mLastFrameR;
    private long mLastOrgFrameTsMs = -1;
    private long mLastOrgFrameTsMsR = -1;

    private long timeDeltaNs = 1000000000;


    private VideoQueue mVideoQueue;

    private boolean mReleased;
    private Handler mHandler;
    private volatile byte[] mAudioExtradata;

    private boolean mGyroStabilizerApplied;
    private long originLastGyroTsMs;

    public int codec;
    private boolean mWriteH264;
    private boolean mWriteGyro;
    private File mFileOriginalVideoData;
    private File mFileH264;
    private File mFileGyro;
    private boolean mH265;
    private long frameCount = 0;
    private long startTime;

    private OneStreamPipeline mStreamPipeline;
    private PreviewImageNotify mPreviewImageNotify;
    private Handler mPreviewImageNotifyHandler;
    private ICameraPreviewPipeline mICameraPreviewPipeline;
    private ICameraPreviewListener mICameraPreviewListener;
    private StartStreamingParam mStartStreamingParam;
    private AudioParam mAudioParam;
    private VideoParam mVideoParam;
    private Context mContext;


    public StreamProcess(Handler handler, OneStreamPipeline imagePipeline, StartStreamingParam startStreamingParam, boolean isH265, Context context, ICameraPreviewListener cameraPreviewListener) {
        this.mHandler = handler;
        this.mH265 = isH265;
        this.mStreamPipeline = imagePipeline;
        this.mStartStreamingParam = startStreamingParam;
        this.mContext = context;
        this.mICameraPreviewListener = cameraPreviewListener;
        changeStreamProcess(startStreamingParam.isDualStream(), isH265);
    }

    public void changeStreamProcess(boolean dual, boolean isH265) {
        if (dual) {
            mVideoQueue = new DualVideoQueue(30, mStreamPipeline, mHandler);
        } else {
            mVideoQueue = new SingleVideoQueue(30, mStreamPipeline, mHandler);
        }
        VideoParam videoParam = null;
        switch (mStartStreamingParam.getPreviewNum()) {
            case 0:
                videoParam = mStartStreamingParam.getFirstVideoParam();
                break;
            case 1:
                videoParam = mStartStreamingParam.getSecVideoParam();
                break;
        }
        mVideoParam = videoParam;
        mAudioParam = mStartStreamingParam.getAudioParam();
        h264Parser(dual, isH265, videoParam);
        Log.i(TAG, "init stream process, dual = " + dual);
    }

    //设置parser
    private void h264Parser(boolean dual, boolean isH265, final VideoParam mVideoParam) {
        if (isH265) {
            if (dual) {
                mParser = new H265Parser();
                mParserR = new H265Parser();
            } else {
                mParser = new H265Parser();
            }
        } else {
            if (dual) {
                mParser = new H264Parser();
                mParserR = new H264Parser();
            } else {
                mParser = new H264Parser();
            }
        }
        if (dual) {
            mParser.setSpsCallback(new H2645Parser.SPSCallback() {
                @Override
                public void onSpsUpdate(int width, int height, int fps, float fpsFloat) {
                    if (mVideoParam != null) {
                        if (TRACE)
                            Log.i(TAG, "dual left sps parse video resolution (" + width
                                    + "x" + height + ") fps " + fps + " fpsFloat " + fpsFloat + "");
                        boolean hasChanged = false;
                        if (mVideoParam.width / 2 != width || mVideoParam.height != height) {
                            Log.e(TAG, "dual left video resolution update from (" + mVideoParam.width
                                    + "x" + mVideoParam.height + ") to (" + width * 2 + "x" + height * 2 + ")");
                            mVideoParam.width = width * 2;
                            mVideoParam.height = height;
                            hasChanged = true;
                        }
                        if (fps > 0 && Math.abs(mVideoParam.fps - fps) > 1) {
                            Log.e(TAG, "dual left video fps (" + mVideoParam.fps + ") mismatch (" + fps + ")");
                            mVideoParam.fps = fps;
                            hasChanged = true;
                        }
                        if (hasChanged && mICameraPreviewListener != null) {
                            mICameraPreviewListener.onResolutionUpdate(mVideoParam.width, mVideoParam.height, mVideoParam.fps);
                        }
                    }
                }
            });

            mParserR.setSpsCallback(new H2645Parser.SPSCallback() {
                @Override
                public void onSpsUpdate(int width, int height, int fps, float fpsFloat) {
                    if (mVideoParam != null) {
                        if (TRACE)
                            Log.i(TAG, "dual right sps parse video resolution (" + width
                                    + "x" + height + ") fps " + fps + " fpsFloat " + fpsFloat + "");
                        boolean hasChanged = false;
                        if (mVideoParam.width / 2 != width || mVideoParam.height != height) {
                            Log.e(TAG, "dual right video resolution update from (" + mVideoParam.width
                                    + "x" + mVideoParam.height + ") to (" + width + "x" + height + ")");
                            mVideoParam.width = width * 2;
                            mVideoParam.height = height;
                            hasChanged = true;
                        }
                        if (fps > 0 && Math.abs(mVideoParam.fps - fps) > 1) {
                            Log.e(TAG, "update dual right video fps (" + mVideoParam.fps + ") mismatch (" + fps + ")");
                            mVideoParam.fps = fps;
                            hasChanged = true;
                        }
                        if (hasChanged && mICameraPreviewListener != null) {
                            mICameraPreviewListener.onResolutionUpdate(mVideoParam.width, mVideoParam.height, mVideoParam.fps);
                        }
                    }
                }
            });
        } else {
            mParser.setSpsCallback(new H2645Parser.SPSCallback() {
                @Override
                public void onSpsUpdate(int width, int height, int fps, float fpsFloat) {
                    if (mVideoParam != null) {
                        if (TRACE)
                            Log.i(TAG, "single sps parse video resolution (" + width
                                    + "x" + height + ") fps " + fps + " fpsFloat " + fpsFloat + "");
                        boolean hasChanged = false;
                        if (mVideoParam.width != width || mVideoParam.height != height) {
                            Log.e(TAG, "single video resolution update from (" + mVideoParam.width
                                    + "x" + mVideoParam.height + ") to (" + width + "x" + height + ")");
                            mVideoParam.width = width;
                            mVideoParam.height = height;
                            hasChanged = true;
                        }
                        if (fps > 0 && Math.abs(mVideoParam.fps - fps) > 1) {
                            Log.e(TAG, "update single video fps (" + mVideoParam.fps + ") mismatch (" + fps + ")");
                            mVideoParam.fps = fps;
                            hasChanged = true;
                        }
                        if (hasChanged && mICameraPreviewListener != null) {
                            mICameraPreviewListener.onResolutionUpdate(mVideoParam.width, mVideoParam.height, mVideoParam.fps);
                        }
                    }
                }
            });
        }

        setParams();
    }


    /**
     * 设置参数
     */
    public void setParams() {
        mWriteH264 = mStartStreamingParam.isRecordOriginH264();
        mWriteGyro = mStartStreamingParam.ismRecordOriginGyro();
        mGyroStabilizerApplied = mVideoParam.enableGyro;
        this.codec = mAudioParam.codec;
        mVideoQueue.setGyroStabilizerApplied(mVideoParam.enableGyro);
        mVideoQueue.setVideoParam(mVideoParam);
        mVideoQueue.setParser(mParser, mParserR);
        mVideoQueue.setH265(mH265);
        if (mICameraPreviewPipeline != null) {
            mVideoQueue.updatePipleline(mICameraPreviewPipeline);
        }
        if (mPreviewImageNotify != null && mPreviewImageNotifyHandler != null) {
            mVideoQueue.updatePreviewImageNotify(mPreviewImageNotify, mPreviewImageNotifyHandler);
        }
        Log.i(TAG, " stream setParams");
    }

    public void release() {
        mReleased = true;
        Log.i(TAG, "camera source released");
    }

    public boolean isH265() {
        return mH265;
    }

    //在主线程执行
    public void onDriverStreamDataNotify(int streamType, byte[] data, long timestamp) {
        if (TRACE)
            Log.d(TAG, "onDriverStreamDataNotify type" + streamType);
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                precoss(streamType, data, timestamp);
            }
        });
    }


    private void precoss(int streamType, byte[] data, long timestamp) {
        try {
            switch (streamType) {
                case StreamType.AUDIO_STREAM:
                    processAudioFrame(data, timestamp);
                    break;
                case StreamType.VIDEO_STREAM_L:
                    processVideoFrame(data, timestamp);
                    break;
                /**
                 * front imaged stithced in the middle
                 */
                case StreamType.VIDEO_STREAM_R:
                    processSecVideoFrame(data, timestamp);
                    break;
                case StreamType.VIDEO_STREAM:
                    processVideoFrame(data, timestamp);
                    break;
                case StreamType.GYRO_STREAM:
                    processGyro(data, timestamp);
                    break;
                case StreamType.VIDEO_EXPOSURE_TIME:
                    processExposureTime(data, timestamp);
                    break;
                case StreamType.VIDEO_PTZ:
                    // TODO: 2025/9/26 需要保留在minicamera中
//                    processPtz(data, timestamp);
                    break;
                case StreamType.P3_ALGORITHM:
                    processP3Algorithm(data, timestamp);
                    break;
                //fuck camera left/right audio
                case 0x11:
                case 0x12:
                    break;
                default:
                    Log.e(TAG, "error stream type " + streamType);
                    break;
            }
        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
        }
    }

    /*private void putStream(AudioData audioData) {
        if (mICameraPreviewPipeline != null) {
            mICameraPreviewPipeline.onAudioStream(audioData);
        } else {
            mStreamPipeline.putAudio(audioData);
        }
    }*/


    public void processAudioFrame(byte[] data, long timestamp) {

        if (mAudioParam == null) {
            if (mStartStreamingParam != null) {
                mAudioParam = mStartStreamingParam.getAudioParam();
            }
        }

        if (mAudioParam == null) {
            return;
        }

        AudioData audioData = new AudioData();
        audioData.data = data;
        audioData.dataSize = data.length;
        audioData.dataOffset = 0;
        audioData.timestampNsSysClock = getFixTimestap(timestamp * 1000000);
        if (mAudioParam.enable) {
            if (mICameraPreviewPipeline != null) {
                mICameraPreviewPipeline.onAudioStream(audioData.timestampNsSysClock, data);
            }
        }

        //while record with audio
           /* mADTSParser.feedData(mAudioData.data, 0, mAudioData.data.length);
            long frameSysTimeNs = getFixTimestap(mAudioData.timestamp * 1000000);
            while (true) {
                if (mAudioExtradata == null) {
                    mAudioExtradata = mADTSParser.csd();
                }
                if (mAudioExtradata != null && mAudioExtradata.length > 0) {
                    AdtsParser.Frame mAudioFrame = mADTSParser.readFrame();
                    if (mAudioFrame != null) {
                        //use audio from camera
                        AudioData audioData = new AudioData();
                        audioData.data = mAudioFrame.data;
                        audioData.dataSize = mAudioFrame.size;
                        audioData.dataOffset = mAudioFrame.offset;
                        audioData.timestampNsSysClock = frameSysTimeNs;
                        if (TRACE)
                            Log.i(TAG,
                                    "put audio packet: offset: " +
                                            audioData.dataOffset + ", size: " +
                                            audioData.dataSize);
                        putStream(audioData);
                    } else {
                        break;
                    }
                } else {
                    break;
                }
            }*/

    }


    private long getFixTimestap(long frameTimeNs) {
        return frameTimeNs;
    }

    public void debugFPS(int testCount) {
        long gotFrameTime = System.nanoTime();
        ++frameCount;
        if (frameCount % testCount == 0) {
            double costMs = (gotFrameTime - startTime) / 1000000.;
            double fps = testCount * 1000 / costMs;
            Log.i(TAG, "camera input fps: " + fps);
            startTime = gotFrameTime;
        }
    }

    public void processVideoFrame(byte[] data, long timestamp) {
        if (mWriteH264) {
            writeOriginalVideoData(data);
        }
        if (mParser == null) {
            return;
        }
//        debugFPS(300);
        // stabilizer
        long frameSysTimeNs;
        if (TRACE) {
            Log.i(TAG, "process " + (mH265 ? "h265" : "h264") + "  frame, size: " + data.length +
                    ", start bytes: " + bytesToHex(data, 0, 8));
            debugFPS(300);
        }

        if (data[0] == 0 && data[1] == 0) {
            /**
             * first h265 slice
             */
            if (data[2] == 0 && data[3] == 1) {
                frameSysTimeNs = getFixTimestap(timestamp * 1000000);
                if (TRACE)
                    Log.i(TAG, "received one video frame, size: " + data.length +
                            " frameSysTimeNs " + frameSysTimeNs);
                if (mLastFrame != null) {
                    if (mLastFrame.size == 0) {
                        Log.e(TAG, "frame size 0");
                    } else if (mParser.getCsdData() == null) {
                        if (mLastFrame.type != H2645Parser.FrameType.IDR) {
                            Log.w(TAG, "sps and pps data not received, " +
                                    "drop frame: " + mLastFrame.type);
                        } else {
                            Log.e(TAG, "iframe but no video extra");
                        }
                    } else {
                        mVideoQueue.enqueVideo(mLastFrame, getFixTimestap(mLastOrgFrameTsMs * 1000000));
                    }
                    if (mICameraPreviewListener != null) {
                        mICameraPreviewListener.onVideoData(mLastFrame.data, mLastFrame.offset, mLastFrame.size, mLastOrgFrameTsMs);
                    }
                    // post data to recorder if recording
                    if (mWriteH264) {
                        writeH264Data(mLastFrame.data, mLastFrame.offset, mLastFrame.size);
                    }
                    mLastFrame = null;
                }
                if (mParser == null) {
                    return;
                }
                mParser.feedData(data, 0, data.length);
                H2645Parser.H2645Frame mFrame = new H2645Parser.H2645Frame();
                while (mParser.readFrame(mFrame)) {
                    /**
                     * find one frame,set foundHeader error to require new h2645 header
                     */
                    if (mLastFrame != null) {
                        Log.e(TAG, " mLastFrame not null ,skip crash for xuege said,force null");
//                            throw new IllegalArgumentException("mLastFrame not null during readFrame");
                        mLastFrame = null;
                    }
                    mLastFrame = mFrame;
                    if (mFrame.type == H2645Parser.FrameType.IDR) {
                        Log.i(TAG, "receive iframe, frameSysTimeNs " + frameSysTimeNs);
                    }
                }

                if (mLastFrame == null) {
                    Log.e(TAG, " mLastFrame null after readFrame ,skip crash for xuege said");
//                        throw new IllegalArgumentException("mLastFrame null after readFrame");
                    /**
                     * force -1 to skip next 00, 00, 01 for h265 if meet,for it not concat with 3 slice
                     * although it should never happen
                     */
                    mLastOrgFrameTsMs = -1;
                } else {
                    mLastOrgFrameTsMs = timestamp;
                }

                return;
            } else if (data[2] == 1) {
                if (mH265) {
                    if (mLastOrgFrameTsMs != -1) {
                        if (mLastFrame == null) {
                            throw new IllegalArgumentException(" concat but mLastFrame null");
                        }
                        frameSysTimeNs = getFixTimestap(timestamp * 1000000);
                        if (TRACE)
                            Log.i(TAG, "concat received one video frame, size: " + data.length +
                                    " frameSysTimeNs " + frameSysTimeNs);

                        if (mLastOrgFrameTsMs != timestamp) {
                            Log.e(TAG, "mismatch last frame ts (" + mLastOrgFrameTsMs + " != " + timestamp
                                    + ") delta " + (mLastOrgFrameTsMs - timestamp));
                        }
                        if (TRACE)
                            Log.i(TAG, "go on received one video frame, size: " + data.length +
                                    " frameSysTimeNs " + frameSysTimeNs);

                        byte[] newData = new byte[mLastFrame.size + data.length];
                        System.arraycopy(mLastFrame.data, mLastFrame.offset, newData, 0, mLastFrame.size);
                        /**
                         * concat 2,3 packet directly ,not exclude 0x00,0x00,0x01
                         */
                        System.arraycopy(data, 0, newData, mLastFrame.size, data.length);
                        mLastFrame.offset = 0;
                        mLastFrame.data = newData;
                        mLastFrame.size = mLastFrame.data.length;
                    } else {
                        Log.e(TAG, " skip non-first h265 slice");
                    }
                } else {
                    Log.e(TAG, " h264 meet begin with 00 00 01");
                }
                return;
            }
        }
        Log.e(TAG, " process invalid " + (mH265 ? "h265" : "h264") + " frame, size: " + data.length +
                ", start bytes: " + bytesToHex(data, 0, 8));
    }

    private void writeOriginalVideoData(byte[] data) {
        try {
            if (mFileOriginalVideoData == null) {
                File externalFilesDir = new File(mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "original_video_data");
                if (!externalFilesDir.exists()) {
                    externalFilesDir.mkdirs();
                }
                mFileOriginalVideoData = new File(externalFilesDir, "original_insv_" +
                        new SimpleDateFormat("MM_dd_HH_mm_ss_SSS", Locale.getDefault()).format(new Date()) + ".h264");
                Log.d(TAG, "mFileOriginalVideoData is " + mFileOriginalVideoData.getAbsolutePath());
                if (!mFileOriginalVideoData.exists()) {
                    mFileOriginalVideoData.createNewFile();
                }
            }
            RandomAccessFile raf = new RandomAccessFile(mFileOriginalVideoData, "rw");
            raf.seek(raf.length());
            raf.write(data);
            Log.d(TAG, " " + mFileOriginalVideoData.getAbsoluteFile() +
                    " input size " + data.length +
                    " file size " + mFileOriginalVideoData.length());
            raf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeH264Data(byte[] data, int offset, int size) {
        try {
            if (mFileH264 == null) {
                File externalFilesDir = mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                mFileH264 = new File(externalFilesDir, "decode_insv_" +
                        new SimpleDateFormat("MM_dd_HH_mm_ss_SSS", Locale.getDefault()).format(new Date()) + ".h264");
                Log.d(TAG, "mFileH264 is " + mFileH264.getAbsolutePath());
                if (!mFileH264.exists()) {
                    mFileH264.createNewFile();
                }
            }
            RandomAccessFile raf = new RandomAccessFile(mFileH264, "rw");
            raf.seek(raf.length());
            raf.write(data, offset, size);
            Log.d(TAG, " " + mFileH264.getAbsoluteFile() +
                    " input size " + size +
                    " file size " + mFileH264.length());
            raf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeGyroData(OneGyroField gyroField) {
        try {
            if (mFileGyro == null) {
                File externalFilesDir = mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                mFileGyro = new File(externalFilesDir,
                        new SimpleDateFormat("MM_dd_HH_mm_ss_SSS", Locale.getDefault()).format(new Date()) + ".bin");
                Log.d(TAG, "mFileGyro is " + mFileGyro.getAbsolutePath());
                if (!mFileGyro.exists()) {
                    mFileGyro.createNewFile();
                }
            }
            RandomAccessFile raf = new RandomAccessFile(mFileGyro, "rw");
            raf.seek(raf.length());
            raf.writeLong(gyroField.timestampMs);
            for (double accel :
                    gyroField.accels) {
                raf.writeDouble(accel);
            }
            for (double gyro :
                    gyroField.gyros) {
                raf.writeDouble(gyro);
            }
//            raf.writeByte('\n');
            Log.d(TAG, " " + mFileGyro.getAbsoluteFile() +
                    " file size " + mFileGyro.length());
            raf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void processSecVideoFrame(byte[] data, long timestamp) {
        if (mParserR == null) {
            return;
        }
        long frameSysTimeNs;
//            Log.i(TAG, "sec process h2645 frame, size: " + frame.data.length +
//                    ", start bytes: " + bytesToHex(frame.data, 0, 8));

        if (data[0] == 0 && data[1] == 0) {
            /**
             * first h265 slice
             */
            if (data[2] == 0 && data[3] == 1) {
                frameSysTimeNs = getFixTimestap(timestamp * 1000000);
                if (TRACE)
                    Log.i(TAG, "sec first received one video frame, size: " + data.length +
                            " frameSysTimeNs " + frameSysTimeNs);
                if (mLastFrameR != null) {
                    if (mLastFrameR.size == 0) {
                        Log.e(TAG, "frame size 0");
                    } else if (mParserR.getCsdData() == null) {
                        if (mLastFrameR.type != H2645Parser.FrameType.IDR) {
                            Log.w(TAG, "sec sps and pps data not received, " +
                                    "drop frame: " + mLastFrameR.type);
                        } else {
                            Log.e(TAG, "sec iframe but no video extra");
                        }
                    } else {
                        mVideoQueue.enqueSecVideo(mLastFrameR, getFixTimestap(mLastOrgFrameTsMsR * 1000000));
                    }
                    mLastFrameR = null;
                }
                if (mParserR == null) {
                    return;
                }
                mParserR.feedData(data, 0, data.length);
                H2645Parser.H2645Frame mFrame = new H2645Parser.H2645Frame();
                while (mParserR.readFrame(mFrame)) {
                    if (mLastFrameR != null) {
                        Log.e(TAG, " mLastFrameR not null,skip crash for xuege said,force null");
//                            throw new IllegalArgumentException("mLastFrameR not null during readFrame");
                        mLastFrameR = null;
                    }
                    mLastFrameR = mFrame;
                }

                if (mLastFrameR == null) {
                    Log.e(TAG, "mLastFrameR null after readFrame,skip crash for xuege said");
//                        throw new IllegalArgumentException("mLastFrameR null after readFrame,skip crash for xuege said");
                    /**
                     * force -1 to skip next 00, 00, 01 for h265 if meet,for it not concat with 3 slice
                     * although it should never happen
                     */
                    mLastOrgFrameTsMsR = -1;
                } else {
                    mLastOrgFrameTsMsR = timestamp;
                }
                return;
            } else if (data[2] == 1) {
                if (mH265) {
                    if (mLastOrgFrameTsMsR != -1) {
                        frameSysTimeNs = getFixTimestap(timestamp * 1000000);
                        if (TRACE)
                            Log.i(TAG, "concat received one video frame, size: " + data.length +
                                    " frameSysTimeNs " + frameSysTimeNs);
                        if (mLastFrame == null) {
                            throw new IllegalArgumentException("sec concat but mLastFrame null");
                        }
                        if (mLastOrgFrameTsMsR != timestamp) {
                            Log.e(TAG, "sec mismatch last frame ts (" + mLastOrgFrameTsMsR + " != " + timestamp
                                    + ") delta " + (mLastOrgFrameTsMsR - timestamp));
                        }

                        if (TRACE)
                            Log.i(TAG, "go on received one video frame, size: " + data.length +
                                    " frameSysTimeNs " + frameSysTimeNs);
                        byte[] newData = new byte[mLastFrameR.size + data.length];
                        System.arraycopy(mLastFrameR.data, mLastFrameR.offset, newData, 0, mLastFrameR.size);
                        /**
                         * concat 2,3 packet directly ,not exclude 0x00,0x00,0x01
                         */
                        System.arraycopy(data, 0, newData, mLastFrameR.size, data.length);
                        mLastFrameR.offset = 0;
                        mLastFrameR.data = newData;
                        mLastFrameR.size = mLastFrameR.data.length;
                    } else {
                        Log.e(TAG, "sec skip non-first h265 slice");
                    }
                } else {
                    Log.e(TAG, "sec h264 meet begin with 00 00 01");
                }

                return;
            }
        }
        Log.e(TAG, "sec process invalid " + (mH265 ? "h265" : "h264") + "  frame, size: " + data.length +
                ", start bytes: " + bytesToHex(data, 0, 8));
    }


    public void processGyro(byte[] data, long timestamp) {
        if (data == null) {
            return;
        }
        if (mGyroStabilizerApplied) {
            final ICameraPreviewPipeline pipeline = mICameraPreviewPipeline;
            int gyro_num = data.length / OneGyroField.ONE_GYRO_LEN;
            if (pipeline != null) {
                OneGyroField obj = new OneGyroField(data, (gyro_num - 1) * OneGyroField.ONE_GYRO_LEN, 0);
                long lastGyroTimeMs = obj.originTsMs;
                pipeline.onGyroStream(data, lastGyroTimeMs);

                if (mWriteGyro) {
                    writeGyroData(obj);
                }
            } else {

                LinkedList<OneGyroField> gyroFields = new LinkedList<>();

                int i = 0;
                OneGyroField obj = new OneGyroField(data, i * OneGyroField.ONE_GYRO_LEN, timeDeltaNs);
                /**
                 * remove duplicate gyro (sometimes camera send duplicate gyro that is useless,so remove earlier timestamp gyro data)
                 */
                if (originLastGyroTsMs >= obj.originTsMs) {
                    i = gyro_num - 1;
                    while (i > 0) {
                        obj = new OneGyroField(data, i * OneGyroField.ONE_GYRO_LEN, timeDeltaNs);
                        if (originLastGyroTsMs < obj.originTsMs) {
                            gyroFields.add(obj);
                            i--;
                        } else {
                            break;
                        }
                    }
                    Log.e(TAG, "remove duplicate gyro:last gyro ts " + originLastGyroTsMs + " >= new " +
                            obj.originTsMs
                            + " delta " + (originLastGyroTsMs - obj.originTsMs)
                            + " reset gyroFields size " + gyroFields.size());
                    if (gyroFields.size() > 0) {
                        putGyro(gyroFields);
                        originLastGyroTsMs = gyroFields.get(gyroFields.size() - 1).originTsMs;
                    }
                } else {
                    i = 1;
                    gyroFields.add(obj);
                    while (i < gyro_num) {
                        obj = new OneGyroField(data, i * OneGyroField.ONE_GYRO_LEN, timeDeltaNs);
                        gyroFields.add(obj);
                        i++;
                    }
                    putGyro(gyroFields);
                    originLastGyroTsMs = gyroFields.get(gyroFields.size() - 1).originTsMs;
                }
            }
            if (mICameraPreviewListener != null) {
                LinkedList<OneGyroField> gyroFields = new LinkedList<>();
                for (int i = 0; i < gyro_num; i++) {
                    OneGyroField obj = new OneGyroField(data, i * OneGyroField.ONE_GYRO_LEN, 0);
                    gyroFields.add(obj);
                }
                mICameraPreviewListener.onGyroData(gyroFields);
            }
        }
    }

    private void putGyro(LinkedList<OneGyroField> gyroFields) {
        if (mICameraPreviewPipeline != null) {
            Log.e(TAG, "putGyro but mICameraPreviewPipeline not null error");
        } else {
            mStreamPipeline.putGyro(gyroFields);
        }
    }


    public void processExposureTime(byte[] data, long timestamp) {
        if (mGyroStabilizerApplied) {
            final ICameraPreviewPipeline pipeline = mICameraPreviewPipeline;
            if (pipeline != null) {
//                AbstractPlayer.StreamExposureInfo info = new AbstractPlayer.StreamExposureInfo();
                // convert ts from ms to ns
                long timestampMs = timestamp;
                double shutterSpeeds = bytes2Double(data, 0);
                // convert exposure time from s to ns
                pipeline.onExposureStream(timestampMs, shutterSpeeds);
            } else {
                AbstractPlayer.StreamExposureInfo info = new AbstractPlayer.StreamExposureInfo();
                // convert ts from ms to ns
                info.timestampNs = getFixTimestap(timestamp * 1000000);
                // convert exposure time from s to ns
                info.exposureTimeNs = (long) (bytes2Double(data, 0) * 1000000000);

//                if(TRACE)
//                    Log.d(TAG,"enqueExposureTime timestamp "
//                        + info.timestampNs + " exposure " + info.exposureTimeNs
//                         + " s " + bytes2Double(mData.data,0));
                putExposureTime(info);
            }
            if (mICameraPreviewListener != null) {
                mICameraPreviewListener.onExposureData(bytes2Double(data, 0), timestamp);
            }
        }
    }

    private void putExposureTime(AbstractPlayer.StreamExposureInfo info) {
        if (mICameraPreviewPipeline != null) {
//                mICameraPreviewPipeline.onExposureStream(info.timestampNs,info.exposureTimeNs);
            Log.e(TAG, "putExposureTime meet mICameraPreviewPipeline null");
        } else {
            /**
             * not used yet
             */
//                mImagePipeline.putExposureTime(info);
        }
    }

    private void processP3Algorithm(byte[] data, long timestamp) {
        if (data == null  || data.length == 0) return;
        Log.i(TAG, "processP3Algorithm stream data.data length = " + data.length);
        Log.i(TAG, "processP3Algorithm stream data.data: " + Arrays.toString(data));
        if (mICameraPreviewPipeline != null) {
            mICameraPreviewPipeline.onP3Algorithm(data, getFixTimestap(timestamp * 1000000));
        }
    }

    @Override
    protected void finalize() throws Throwable {
        if (!mReleased)
            release();
        super.finalize();
    }

    public void updatePiple(ICameraPreviewPipeline cameraPreviewPipeline) {
        this.mICameraPreviewPipeline = cameraPreviewPipeline;
        if (mVideoQueue != null) {
            mVideoQueue.updatePipleline(cameraPreviewPipeline);
        }
    }

    public void updatePreviewImageNotify(PreviewImageNotify previewImageNotify, Handler threadHandler) {
        this.mPreviewImageNotify = previewImageNotify;
        this.mPreviewImageNotifyHandler = threadHandler;
        if (mVideoQueue != null) {
            mVideoQueue.updatePreviewImageNotify(previewImageNotify, threadHandler);
        }
    }

    private void runOnHandlerThread(Runnable runnable) {
        if (Looper.myLooper() == mHandler.getLooper()) {
            runnable.run();
        } else {
            mHandler.post(runnable);
        }
    }

    public void forcePutImage(final ImageData[] imageDatas) {
        runOnHandlerThread(new Runnable() {
            @Override
            public void run() {
                if (mLastFrame != null) {
                    Log.i(TAG, " mLastFrame not null? flag = " + mLastFrame.type);
                    Log.i(TAG, " force to null pts " + getFixTimestap(mLastOrgFrameTsMs * 1000000));
                    Log.i(TAG, "skip force image pts " + imageDatas[0].timestampNs);

                    if (mVideoQueue instanceof SingleVideoQueue) {
                        boolean forcePut = mLastFrame.type != H2645Parser.FrameType.IDR;
                        ((SingleVideoQueue) mVideoQueue).feedPipelineVideo(mLastFrame, getFixTimestap(mLastOrgFrameTsMs * 1000000), forcePut);
                        mLastFrame = null;
                        return;
                    } else {
                        Log.e(TAG, " dual queue meet force ???");
                    }
                }
                if (mVideoQueue != null) {
                    mVideoQueue.forcePutImage(imageDatas);
                }
            }
        });
    }

}
