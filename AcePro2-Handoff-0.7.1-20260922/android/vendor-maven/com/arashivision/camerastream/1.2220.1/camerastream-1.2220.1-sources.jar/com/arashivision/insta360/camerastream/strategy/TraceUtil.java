package com.arashivision.insta360.camerastream.strategy;


public class TraceUtil {
    public static boolean TRACE = false;
}
