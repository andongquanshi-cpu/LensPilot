package com.arashivision.insta360.camerastream.command;

import com.arashivision.onestream.OneStreamPipeline;

public class StopRecordOriginDataCmd {
    private OneStreamPipeline mStreamPipeline;

    public StopRecordOriginDataCmd(OneStreamPipeline streamPiple) {
        this.mStreamPipeline = streamPiple;
    }


    public Object exeCmd() {
        //否则停止ImagePipeline
        mStreamPipeline.stopRecordVideo();
        return 0;
    }
}
