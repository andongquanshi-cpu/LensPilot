package com.arashivision.insta360.camerastream.bean;

/**
 * Created by vans on 16/10/17.
 * AudioParam for camera streaming, normally no need to set
 */

public class AudioParam {
    public boolean enable = true;
    /**
     * audio sample rate,support  44100/48000
     */
    public int sampleRate = 0;

    /**
     * audio bitrate Mbits/s
     */
    public int bitrate = 0;
    /**
     * {@link com.arashivision.onecamera.OneDriverInfo.AudioCodec}
     */
    public int codec;

    private boolean getEnable()
    {
        return enable;
    }

    private int getSampleRate()
    {
        return sampleRate;
    }

    private int getBitrate()
    {
        return bitrate;
    }

    private int getCodec()
    {
        return codec;
    }
}


