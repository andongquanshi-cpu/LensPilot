package com.arashivision.insta360.camerastream.listener;

import com.arashivision.onestream.Gyro.OneGyroField;

import java.util.List;

/**
 * 预览中的参数回调
 */
public interface ICameraPreviewListener {

    void onVideoData(byte[] data, int offset, int size, long timestamp);

    void onGyroData(List<OneGyroField> gyroFields);

    void onExposureData(double exposureTime, long timestamp);

    void onResolutionUpdate(int width, int height, int fps);

}
