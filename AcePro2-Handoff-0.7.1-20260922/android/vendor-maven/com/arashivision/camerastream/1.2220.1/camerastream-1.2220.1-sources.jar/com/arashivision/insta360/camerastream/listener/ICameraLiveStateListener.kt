package com.arashivision.insta360.camerastream.listener


interface ICameraLiveStateListener {
    fun onRecordComplete(path: String?)

    fun onRecordError(
        err: Int,
        extra: Int,
        domain: String?,
        desc: String?,
        path: String?,
    )
}
