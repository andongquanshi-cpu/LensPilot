package com.arashivision.insta360.camerastream.strategy;

import android.util.Log;

import com.arashivision.onestream.OneStreamPipeline;

public class OneStreamPipleImpl implements OneStreamPipeline.Callbacks {
    private static final String TAG = OneStreamPipleImpl.class.getName();

    @Override
    public void onPipelineError(OneStreamPipeline pipeline, int error, int data, String description) {
        Log.d(TAG, "onPipelineError = " + description);
    }

    @Override
    public void onPipelineRecordComplete(OneStreamPipeline pipeline) {
        Log.d(TAG, "onPipelineRecordComplete = " + pipeline);

    }

    @Override
    public void onPipelineRecordError(OneStreamPipeline pipeline, int err) {
        Log.d(TAG, "onPipelineRecordError = " + err);
    }

    @Override
    public void onPipelineImageCaptured(OneStreamPipeline pipeline, int width, int height, int quality, String path) {
        Log.d(TAG, "onPipelineImageCaptured = " + pipeline);

    }

    @Override
    public void onPipelineInfo(int infoType, int data, Object obj) {
        Log.d(TAG, "onPipelineInfo = " + infoType);

    }
}
