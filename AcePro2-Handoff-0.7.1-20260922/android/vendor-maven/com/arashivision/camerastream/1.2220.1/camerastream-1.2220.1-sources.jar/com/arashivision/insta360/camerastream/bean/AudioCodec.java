package com.arashivision.insta360.camerastream.bean;

/**
 * Audio Codec when streaming
 */
public class AudioCodec {
    public static final int RAW = 0;
    public static final int ADTS = 1;
}