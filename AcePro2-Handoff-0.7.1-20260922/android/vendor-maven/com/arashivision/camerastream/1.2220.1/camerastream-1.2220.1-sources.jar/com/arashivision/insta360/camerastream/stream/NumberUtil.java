package com.arashivision.insta360.camerastream.stream;

public class NumberUtil {


    final private static char[] hexArray = "0123456789ABCDEF".toCharArray();


    public static double bytes2Double(byte[] arr, int offset) {
        long value = 0;
        for (int i = 0; i < 8; i++) {
            value |= ((long) (arr[i + offset] & 0xff)) << (8 * i);
        }
        return Double.longBitsToDouble(value);
    }


    public static String bytesToHex(byte[] bytes, int offset, int size) {
        if (offset + size > bytes.length)
            size = bytes.length - offset;
        char[] hexChars = new char[size * 2];
        for (int j = 0; j < size; j++) {
            int v = bytes[j + offset] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }


}
