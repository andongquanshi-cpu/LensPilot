package com.arashivision.insta360.camerastream.listener;

public interface IScreenCaptureListener {
    void onScreenCapture(int code,String outPath);
}
