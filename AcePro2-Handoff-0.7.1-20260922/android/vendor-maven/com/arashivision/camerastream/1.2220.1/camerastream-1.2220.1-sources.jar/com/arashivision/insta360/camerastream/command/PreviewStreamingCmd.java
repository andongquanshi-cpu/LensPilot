package com.arashivision.insta360.camerastream.command;

import android.util.Log;

import com.arashivision.insta360.camerastream.bean.AudioParam;
import com.arashivision.insta360.camerastream.bean.AudioSource;
import com.arashivision.insta360.camerastream.bean.StartStreamingParam;
import com.arashivision.insta360.camerastream.bean.VideoParam;
import com.arashivision.onestream.Gyro.GyroType;
import com.arashivision.onestream.OneStreamPipeline;

/**
 * 预览的cmd
 */
public class PreviewStreamingCmd {

    private static final String TAG = PreviewStreamingCmd.class.getName();

    private float[] mGyroRebaseMatrix;
    private StartStreamingParam mStreamingParam;
    private OneStreamPipeline mOneStreamPipeline;
    private String mOffest;
    private AudioSource mAudioSource;
    private Object mSurface;

    public PreviewStreamingCmd(StartStreamingParam startStreamingParam, OneStreamPipeline streamPiple, float[] mGyroMatrix, AudioSource audioSource, Object firstSurface, String offest) {
        this.mOneStreamPipeline = streamPiple;
        this.mGyroRebaseMatrix = mGyroMatrix;
        this.mStreamingParam = startStreamingParam;
        this.mOffest = offest;
        this.mAudioSource = audioSource;
        this.mSurface = firstSurface;
    }

    public void exeCmd() {
        setImagePipleStream(mStreamingParam);
    }


    private void setImagePipleStream(StartStreamingParam startStreamingParam) {
        VideoParam videoParam;
        //设置流
        switch (startStreamingParam.getPreviewNum()) {
            case 0:
                videoParam = startStreamingParam.getFirstVideoParam();
                break;
            case 1:
                videoParam = startStreamingParam.getSecVideoParam();
                break;
            default:
                throw new IllegalArgumentException("error param.getPreviewNum() " + startStreamingParam.getPreviewNum());
        }

        AudioParam audioParam = startStreamingParam.getAudioParam();
        if (audioParam == null) {
            throw new IllegalArgumentException("error param.getAudioParam(),must set AudioParam");

        }
        if (mAudioSource != null) {
            if (AudioSource.AUDIO_CAMERA == mAudioSource) {
                audioParam.enable = true;
            } else {
                audioParam.enable = false;
            }
        }
        //设置陀螺仪和防抖
        GyroType gyroType = startStreamingParam.getGyroType();

        mOneStreamPipeline.setInputWideoResolution(videoParam.width, videoParam.height);
        mOneStreamPipeline.setInputFps(videoParam.fps);
        if (videoParam.enableGyro) {
            mOneStreamPipeline.setGyroType(gyroType, mGyroRebaseMatrix, false);
        }

        Log.i(TAG, " start streaming gyroType "
                + gyroType +
                " dual " + startStreamingParam.isDualStream() +
                " first " + startStreamingParam.getFirstVideoParam().toString() +
                " sec " + startStreamingParam.getSecVideoParam().toString()
                + " previewNum " + startStreamingParam.getPreviewNum()
                + " zdirectional " + startStreamingParam.isDiretionalZ()
                + " mWriteH264 " + startStreamingParam.isRecordOriginH264());

        Log.d(TAG, "width = " + videoParam.width + ",height = " + videoParam.height + ",fps = " + videoParam.fps + ",mSurface = " + mSurface + ",enable gyro = " + videoParam.enableGyro);
        mOneStreamPipeline.open(mOffest);
        if (mSurface != null) {
            mOneStreamPipeline.setSurface(mSurface);
        }
    }
}
