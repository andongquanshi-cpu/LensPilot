package com.arashivision.insta360.camerastream.stream;

import com.arashivision.onestream.ImageData;

public interface PreviewImageNotify {
    /**
     * live fps update notify
     * @param imageDatas ImageData
     */
    boolean onImageNotify(ImageData[] imageDatas);
}
