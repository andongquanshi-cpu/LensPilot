package com.arashivision.insta360.camerastream.listener

import com.arashivision.onestream.Gyro.OneGyroField

interface IPreviewStatusChangedListener {
    fun onVideoData(data: ByteArray?, offset: Int, size: Int, timestamp: Long) {
    }

    fun onGyroData(list: MutableList<OneGyroField?>?) {
    }

    fun onExposureData(exposureTime: Double, timestamp: Long) {
    }

    fun onResolutionUpdate(width: Int, height: Int, fps: Int) {
    }
}