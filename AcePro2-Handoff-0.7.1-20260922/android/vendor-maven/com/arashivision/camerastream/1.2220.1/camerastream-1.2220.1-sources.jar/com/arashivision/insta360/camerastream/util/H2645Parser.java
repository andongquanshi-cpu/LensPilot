package com.arashivision.insta360.camerastream.util;

import java.util.LinkedList;

/**
 * Created by vans on 3/1/20.
 */

public abstract class H2645Parser {
    private static final String TAG = "OneH2645Parser";
    protected SPSCallback mSPSCallback;

    public static class Payload {
        byte[] buf;
        int offset;
        int size;
        boolean oneNaluFound;
    }

    public enum NaluType { UNKNOWN, VPS,SPS, PPS, SEI, DELIMITER, CODED_NON_IDR_SLICE, CODED_IDR_SLICE }

    public static class Nalu {
        public byte[] buf;
        public int offset;
        public int size;
        public NaluType type;
    }

    public enum FrameType { IDR, IFrame, Other }
    public static class H2645Frame {
        public byte[] data;
        public int offset;
        public int size;
        public FrameType type;

        public boolean isIDR()
        {
            return type == FrameType.IDR;
        }
    }

    protected LinkedList<Payload> mParseBufQueue = new LinkedList<>();
    protected byte[] mVps;
    protected byte[] mSps;
    protected byte[] mPps;
    protected byte[] mCsd;

    public void setOriginalCSD(byte[] csdData) {
        mCsd = csdData;
    }

    public byte[] getCsdData() {
        return mCsd;
    }

    public void feedData(byte[] buf, int offset, int size) {
        Payload payload = new Payload();
        payload.buf = buf;
        payload.offset = offset;
        payload.size = size;
        payload.oneNaluFound = false;
        mParseBufQueue.add(payload);
    }

    protected static byte[] dupBytes(byte[] data, int offset, int size) {
        byte[] d = new byte[size];
        System.arraycopy(data, offset, d, 0, size);
        return d;
    }

    protected void parseSps()
    {
        if(mSPSCallback != null)
        {
            int[] resolution = new int[2];
            int[] fps = new int[1];
            /**
             * h265 not parse fps
             */
            fps[0] = -1;
            float[] fpsFloat = new float[1];
            if(spsParse(mSps,resolution,fps,fpsFloat) == 0)
            {
                mSPSCallback.onSpsUpdate(resolution[0],resolution[1],fps[0],fpsFloat[0]);
            }
        }
    }

    protected abstract int spsParse(byte[] sps,int[] outResolution,int[] outFps,float[] outFpsFloat);

    public abstract boolean readFrame(H2645Frame h2645Frame);

    protected abstract boolean readNalu(Nalu nalu);

    public void reset(boolean clearParseBufQueue) {
        if (clearParseBufQueue) {
            mParseBufQueue.clear();
        }
        mVps = null;
        mSps = null;
        mPps = null;
        mCsd = null;
    }

    public static class NalPos {
        int start;
        int end;
    }

    protected abstract boolean findNalUnit(byte[] buffer, int bufferOffset, int bufferSize,
                                           NalPos nalPos, boolean bufferEndCouldAsNalEnd);

    protected abstract NaluType naluType(byte[] buffer, int naluStartPos);

    public void setSpsCallback(SPSCallback callback)
    {
        mSPSCallback = callback;
    }

    public interface SPSCallback
    {
        void onSpsUpdate(int width, int height, int fps, float fpsFloat);
    }
}
