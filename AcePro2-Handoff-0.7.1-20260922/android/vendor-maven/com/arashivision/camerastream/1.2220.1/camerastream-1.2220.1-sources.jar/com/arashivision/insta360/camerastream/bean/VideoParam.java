package com.arashivision.insta360.camerastream.bean;

/**
 * Created by vans on 16/10/17.
 */

public class VideoParam {
    public int width;
    public int height;
    public int fps; //normally 30
    //Mbits/s
    public int bitrate;
    public boolean enableGyro;

    private boolean getEnableGyro()
    {
        return enableGyro;
    }

    private int getVideoWidth()
    {
        return width;
    }

    private int getVideoHeight()
    {
        return height;
    }

    private int getFPS()
    {
        return fps;
    }

    private int getBitrate()
    {
        return bitrate;
    }

    public String toString()
    {
        return " w " + width + " h "
                        + height + " fps " + fps +
                        " br " + bitrate;
    }

}
