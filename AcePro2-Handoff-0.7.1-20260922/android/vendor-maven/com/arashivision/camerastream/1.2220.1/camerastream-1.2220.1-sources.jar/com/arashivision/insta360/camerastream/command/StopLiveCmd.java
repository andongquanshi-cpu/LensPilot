package com.arashivision.insta360.camerastream.command;

import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;

public class StopLiveCmd{
    private ICameraPreviewPipeline mCameraPreviewPipeline;

    public StopLiveCmd(ICameraPreviewPipeline mICameraPreviewPipeline) {
        mCameraPreviewPipeline = mICameraPreviewPipeline;
    }

    public Object exeCmd() {
        if(mCameraPreviewPipeline != null)
        {
            mCameraPreviewPipeline.onStopLive();
        }
        return null;
    }
}
