package com.arashivision.insta360.camerastream.command;

import android.util.Log;

import com.arashivision.onestream.OneStreamPipeline;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;

public class ResetRecord {
    private static final String TAG = "RestRecord";

    private ICameraPreviewPipeline mICameraPreviewPipeline;
    private OneStreamPipeline mStreamPiple;

    public ResetRecord(ICameraPreviewPipeline cameraPreviewPipeline, OneStreamPipeline streamPiple){
        mICameraPreviewPipeline = cameraPreviewPipeline;
        mStreamPiple = streamPiple;
    }

    public Object exeCmd() {
        if(mICameraPreviewPipeline != null){
            Log.i(TAG,"resetRecord while live");
            mICameraPreviewPipeline.onStopLive();
        }else {
            mStreamPiple.resetRecord();
        }

        return null;
    }
}
