package com.arashivision.insta360.camerastream

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.arashivision.insta360.camerastream.bean.AudioParam
import com.arashivision.insta360.camerastream.bean.AudioSource
import com.arashivision.insta360.camerastream.bean.StartCaptureWithoutStorage
import com.arashivision.insta360.camerastream.bean.StartStreamingParam
import com.arashivision.insta360.camerastream.bean.VideoParam
import com.arashivision.insta360.camerastream.listener.ICameraLiveStateListener
import com.arashivision.insta360.camerastream.listener.InfoUpdateListener
import com.arashivision.insta360.camerastream.render.RenderMethod
import com.arashivision.insta360.camerastream.render.RenderMode
import com.arashivision.insta360.camerastream.strategy.TraceUtil
import com.arashivision.insta360.camerastream.stream.PreviewImageNotify
import com.arashivision.onestream.CameraFrameRenderMode
import com.arashivision.onestream.Gyro.GyroType
import com.arashivision.onestream.ImageData
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline

/**
 * Stream管理器，负责管理相机流处理功能
 * 将stream相关功能从camera中分离出来
 */
class StreamDelegate {

    companion object {
        fun shouldSavePreviewStreamAndGyroData(enable: Boolean) {
            TraceUtil.TRACE = enable
            savePreviewStreamAndGyroData = enable
        }

        private var savePreviewStreamAndGyroData: Boolean = false
    }

    private var mInfoUpdateListener: InfoUpdateListener? = null
    private var mCameraLiveStateListener: ICameraLiveStateListener? = null
    private val instaStreamStrategy: InstaStreamStrategy = InstaStreamStrategy()
    private val mMainHandler = Handler(Looper.getMainLooper())
    var renderMode: RenderMode? = null
        private set
    var audioCodec = -1
        private set
    var previewNum = -1
        private set

    fun init(context: Context) {
        instaStreamStrategy.init(context)
    }

    fun setCameraLiveListener(
        liveListener: ICameraLiveStateListener?,
        infoUpdateListener: InfoUpdateListener?,
    ) {
        mCameraLiveStateListener = liveListener
        mInfoUpdateListener = infoUpdateListener
    }

    fun openPreviewStream(
        firstVideoParam: VideoParam,
        secondVideoParam: VideoParam,
        audioCodec: Int,
        renderMode: RenderMode,
        isLive: Boolean,
        previewNum: Int,
        isDualStream: Boolean,
        offset: String,
        enableRotate: Boolean,
    ) {
        this@StreamDelegate.audioCodec = audioCodec
        this@StreamDelegate.previewNum = previewNum
        this@StreamDelegate.renderMode = renderMode
        if (isLive) {
            instaStreamStrategy.setAudioSource(AudioSource.AUDIO_CAMERA)
        } else {
            instaStreamStrategy.setAudioSource(AudioSource.AUDIO_NONE)
        }
        val startStreamingParam: StartStreamingParam = StartStreamingParam()
        startStreamingParam.setFirstVideoParam(firstVideoParam)
        startStreamingParam.setSecVideoParam(secondVideoParam)
        startStreamingParam.setDualStream(isDualStream)
        startStreamingParam.setRecordOriginH264(savePreviewStreamAndGyroData)
        startStreamingParam.setmRecordOriginGyro(false)
        val audioParam: AudioParam = AudioParam()
        audioParam.codec = audioCodec
        if (isLive) {
            audioParam.enable = true
            audioParam.sampleRate = 48000
            audioParam.bitrate = 128000
        } else {
            audioParam.enable = false
        }
        startStreamingParam.setAudioParam(audioParam)
        startStreamingParam.setPreviewNum(previewNum)
        startStreamingParam.setGyroType(GyroType.Unknown)
        startStreamingParam.setPreviewNum(previewNum)
        startStreamingParam.setRotateEnabled(enableRotate)
        startStreamingParam.setIsForLive(isLive)
        instaStreamStrategy.previewStream(startStreamingParam, offset)
    }

    fun closePreviewStream() {
        instaStreamStrategy.closePreviewStream()
    }

    fun reopenPreviewStream(
        firstVideoParam: VideoParam,
        secondVideoParam: VideoParam,
        audioCodec: Int,
        renderMode: RenderMode?,
        isLive: Boolean,
        previewNum: Int,
        isDualStream: Boolean,
        offset: String,
        enableRotate: Boolean,
        supportRepeatOpenStream: Boolean,
    ) {
        if (!supportRepeatOpenStream) {
            closePreviewStream()
        }
        openPreviewStream(
            firstVideoParam, secondVideoParam, audioCodec,
            renderMode!!, isLive, previewNum, isDualStream, offset, enableRotate
        )
    }

    /************************* live  */
    private var mIsLiving = false

    fun startLive(
        width: Int,
        height: Int,
        fps: Int,
        bitrate: Int,
        path: String?,
        cameraFrameRenderMode: Int,
        netId: Long,
        previewToLive: Boolean,
        isSpherical: Boolean,
    ) {
        if (mIsLiving) {
            return
        }
        mIsLiving = true
        startLiveInner(
            width,
            height,
            fps,
            bitrate,
            path,
            cameraFrameRenderMode,
            netId,
            previewToLive,
            isSpherical,
            false
        )
    }

    private fun startLiveInner(
        width: Int,
        height: Int,
        fps: Int,
        bitrate: Int,
        path: String?,
        cameraFrameRenderMode: Int,
        netId: Long,
        previewToLive: Boolean,
        isSpherical: Boolean,
        enableSoftEncode: Boolean,
    ) {
        val startCaptureWithoutStorage = StartCaptureWithoutStorage()
        startCaptureWithoutStorage.width = width
        startCaptureWithoutStorage.height = height
        startCaptureWithoutStorage.fps = fps.toDouble()
        startCaptureWithoutStorage.bitrate = bitrate * 1024 * 1024
        startCaptureWithoutStorage.path = path
        startCaptureWithoutStorage.format = "flv"
        startCaptureWithoutStorage.cameraLiveRenderMode = cameraFrameRenderMode
        startCaptureWithoutStorage.enableX264Encoder = enableSoftEncode
        startCaptureWithoutStorage.x264Preset = "veryfast"
        startCaptureWithoutStorage.networkId = netId
        if (cameraFrameRenderMode == CameraFrameRenderMode.CAMERA_STREAM_RENDER_PLANE) {
            startCaptureWithoutStorage.renderMode =
                RenderMode.withGlRenderer(RenderMethod.PlanarKeep)
        } else {
            startCaptureWithoutStorage.renderMode =
                RenderMode.withGlRenderer(RenderMethod.DualFishEyeStitchingPlanar)
        }
        startCaptureWithoutStorage.isSpherical = isSpherical
        startCaptureWithoutStorage.mPreviewToLive = previewToLive
        startCaptureWithoutStorage.rtmpTcpTimeoutUs = 60 * 1000 * 1000
        instaStreamStrategy.setCameraLiveStateListener(object : ICameraLiveStateListener {
            private var invokeRecordComplete = true

            override fun onRecordComplete(s: String?) {
                if (invokeRecordComplete) {
                    mIsLiving = false
                    val listener = mCameraLiveStateListener
                    if (listener != null) {
                        listener.onRecordComplete(s)
                    }
                }
            }

            override fun onRecordError(
                i: Int,
                i1: Int,
                s: String?,
                s1: String?,
                s2: String?,
            ) {
                if (i == -57011103 && !enableSoftEncode) {
                    // 硬编开启失败尝试开一次软编
                    invokeRecordComplete = false
                    instaStreamStrategy.resetRecord()
                    startLiveInner(
                        width,
                        height,
                        fps,
                        bitrate,
                        path,
                        cameraFrameRenderMode,
                        netId,
                        previewToLive,
                        isSpherical,
                        true
                    )
                } else {
                    mIsLiving = false
                    instaStreamStrategy.resetRecord()
                    val listener = mCameraLiveStateListener
                    if (listener != null) {
                        listener.onRecordError(i, i1, s, s1, s2)
                    }
                }
            }
        })
        instaStreamStrategy.setInfoUpdateListener(mMainHandler, object : InfoUpdateListener {
            override fun onRecordFpsUpdate(i: Int) {
                val listener = mInfoUpdateListener
                if (listener != null) {
                    listener.onRecordFpsUpdate(i)
                }
            }

            override fun onLivePushStarted(s: String?) {
                val listener = mInfoUpdateListener
                if (listener != null) {
                    listener.onLivePushStarted(s)
                }
            }

            override fun onCameraInfoNotify(i: Int, i1: Int, o: Any?) {
                val listener = mInfoUpdateListener
                if (listener != null) {
                    listener.onCameraInfoNotify(i, i1, o)
                }
            }
        })
        instaStreamStrategy?.startLive(
            true,
            1,
            startCaptureWithoutStorage
        )
    }

    fun stopLive() {
        instaStreamStrategy?.stopLive()
    }

    val isStreamProcessing: Boolean
        get() = instaStreamStrategy.isStreamProcessing


    val isH265StreamEncode: Boolean
        get() = instaStreamStrategy.isH265StreamEncode


    fun setStreamEncode(isH265: Boolean) {
        instaStreamStrategy.setStreamEncode(isH265)
    }

    fun setPipeline(pipeline: ICameraPreviewPipeline?) {
        instaStreamStrategy.setPipeline(pipeline)
    }

    fun setPreviewImageNotify(
        previewImageNotify: PreviewImageNotify?, threadHandler: Handler?,
    ) {
        instaStreamStrategy.setPreviewImageNotify(previewImageNotify, threadHandler)
    }

    fun forcePutPreviewImage(imageDatas: Array<ImageData>?) {
        instaStreamStrategy.forcePutImage(imageDatas)
    }

    fun processStreamData(type: Int, data: ByteArray, timestamp: Long) {
        instaStreamStrategy.processStreamData(type, data, timestamp)
    }
}
