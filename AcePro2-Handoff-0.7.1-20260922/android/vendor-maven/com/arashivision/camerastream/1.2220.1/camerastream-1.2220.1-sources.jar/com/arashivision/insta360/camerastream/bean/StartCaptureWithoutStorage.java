package com.arashivision.insta360.camerastream.bean;

import com.arashivision.insta360.camerastream.render.RenderMode;
import com.arashivision.onestream.OneStreamPipeline;

/**
 * Created by vans on 23/10/17.
 * start capture without tf card in camera,or start live
 */
// record without storage
public class StartCaptureWithoutStorage {
    /**
     * record video width
     */
    public int width;
    /**
     * record video height
     */
    public int height;
    /**
     * frame rate
     */
    public double fps;
    /**
     * bit/s
     */
    public int bitrate;
    /**
     * video format ,{@link OneDriverInfo.VideoFormat}
     */
    public String format;
    /**
     */
    public RenderMode renderMode;
    /**
     * record path
     */
    public String path;

    /**
     * new camera live with bmg
     * {@link com.arashivision.onestream.CameraFrameRenderMode}
     */
    public int cameraLiveRenderMode;
    /**
     * set false for hard encode, true for soft encode
     */
    public boolean enableX264Encoder = false;
    /**
     * set x264Preset: "veryfast"...
     * when enableX264Encoder is true
     */
    public String x264Preset;

    /**
     * live networkid
     *  -1 --> use app process bind network id
     * others --> android network id
     */
    public long networkId;

    /**
     * set timeout (in microseconds) of socket I/O operations
     * default is 15s
     *
     */
    public int rtmpTcpTimeoutUs = 15 * 1000 * 1000;
    /**
     * maximum cache live pending video count(sometimes live fps too slow(eg: 1))
     * if exceed ,discard
     */
    public int mCameraLivePendingVideoCount = 60;
    /**
     * start live with preview stream without render
     */
    public boolean mPreviewToLive;
    // preview to live
    /**
     * only support when {@link OneStreamPipeline.RecordParam#mPreviewToLive is true}
     */
    public boolean mH265;
    /**
     * whether output video is spherical video
     */
    public boolean isSpherical;
}
