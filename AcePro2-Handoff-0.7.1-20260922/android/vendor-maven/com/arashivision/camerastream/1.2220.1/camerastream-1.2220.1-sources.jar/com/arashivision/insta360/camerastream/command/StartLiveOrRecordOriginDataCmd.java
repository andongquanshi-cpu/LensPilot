package com.arashivision.insta360.camerastream.command;

import android.os.Handler;
import android.util.Log;

import com.arashivision.insta360.camerastream.bean.AudioParam;
import com.arashivision.insta360.camerastream.bean.AudioSource;
import com.arashivision.insta360.camerastream.bean.StartCaptureWithoutStorage;
import com.arashivision.insta360.camerastream.bean.StartStreamingParam;
import com.arashivision.insta360.camerastream.listener.ICameraLiveStateListener;
import com.arashivision.insta360.camerastream.listener.InfoUpdateListener;
import com.arashivision.insta360.camerastream.render.RenderMethod;
import com.arashivision.insta360.camerastream.render.RenderMode;
import com.arashivision.onestream.OneStreamPipeline;
import com.arashivision.onestream.RenderWay;
import com.arashivision.onestream.pipeline.CameraLiveNotify;
import com.arashivision.onestream.pipeline.ICameraLivePipline;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;

public class StartLiveOrRecordOriginDataCmd implements ICameraLivePipline {

    private static final String TAG = StartLiveOrRecordOriginDataCmd.class.getName();

    private static final int AUDIO_CHANNEL = 1;
    private final boolean mLivePush;
    private StartCaptureWithoutStorage mCaptureWithoutStorage;
    private OneStreamPipeline mStreamPipeline;
    private ICameraPreviewPipeline mICameraPreviewPipeline;
    private StartStreamingParam mStreamingParam;
    private AudioSource mAudioSource;
    private InfoUpdateListener mInfoUpdateListener;
    private ICameraLiveStateListener mCameraLiveStateListener;
    private String mRecordPath;
    private Handler mInfoHandler;
    private int mMode;

    public StartLiveOrRecordOriginDataCmd(boolean livePush, int mode, StartStreamingParam startStreamingParam, OneStreamPipeline mStreamPiple, StartCaptureWithoutStorage storage, ICameraPreviewPipeline iCameraPreviewPipeline, AudioSource mAudioSource, InfoUpdateListener mInfoUpdateListener, Handler mInfoHandler, ICameraLiveStateListener mCameraLiveStateListener) {
        this.mLivePush = livePush;
        this.mCaptureWithoutStorage = storage;
        this.mStreamPipeline = mStreamPiple;
        this.mICameraPreviewPipeline = iCameraPreviewPipeline;
        this.mStreamingParam = startStreamingParam;
        this.mAudioSource = mAudioSource;
        this.mMode = mode;
        this.mInfoUpdateListener = mInfoUpdateListener;
        this.mInfoHandler = mInfoHandler;
        this.mCameraLiveStateListener = mCameraLiveStateListener;
    }

    public Object exeCmd() {

        startCaptureWithoutStorage(mCaptureWithoutStorage);
        return -1;
    }

    private void startCaptureWithoutStorage(StartCaptureWithoutStorage mReq) {

        mRecordPath = mReq.path;
        Log.i(TAG, "startCaptureWithoutStorage mRecordStatus " + ", RenderWay = " +
                mReq.renderMode.renderMethod + ", bmg live render mode = " + mReq.cameraLiveRenderMode +
                ", enableX264Encoder = " + mReq.enableX264Encoder + ", x264Preset = " + mReq.x264Preset);

        OneStreamPipeline.RecordParam streamParam = new OneStreamPipeline.RecordParam();
        //如果ICameraPreviewPiple不为空
        if (mICameraPreviewPipeline != null && mStreamingParam != null) {
            Log.i(TAG, " onStartLive ");

            if (mReq.width % 16 != 0) {
                int newWidth = (mReq.width / 16 + 1) * 16;
                Log.e(TAG, " change live width from (" + mReq.width + ") to (" + newWidth + ")");
                mReq.width = newWidth;
            }
            if (mReq.height % 2 != 0) {
                int newHeight = (mReq.height / 2 + 1) * 2;
                Log.e(TAG, " change live height from (" + mReq.height + ") to (" + newHeight + ")");
                mReq.height = newHeight;
            }

            AudioParam audioParam = mStreamingParam.getAudioParam();
            streamParam.setAudioParam(false, AUDIO_CHANNEL, audioParam.sampleRate, audioParam.bitrate, null);
            streamParam.hasAudio = audioParam.enable;
            streamParam.setVideoParam(mReq.width, mReq.height, mReq.fps, mReq.bitrate, mReq.path, mReq.format, renderMode2RenderWay(mReq.renderMode), mReq.cameraLiveRenderMode);
            streamParam.networkid = mReq.networkId;
            streamParam.rtmpTcpTimeoutUs = mReq.rtmpTcpTimeoutUs;
            streamParam.mCameraLivePendingVideoCount = mReq.mCameraLivePendingVideoCount;
            streamParam.mPreviewToLive = mReq.mPreviewToLive;
            streamParam.mH265 = mReq.mH265;
            streamParam.isSpherical = mReq.isSpherical;
            streamParam.enableX264Encoder = mReq.enableX264Encoder;
            streamParam.x264Preset = mReq.x264Preset;
            mICameraPreviewPipeline.onStartLive(streamParam, this);

        } else {
            if (AudioSource.AUDIO_MOBILE == mAudioSource && mStreamingParam != null) {
                AudioParam audioParam = mStreamingParam.getAudioParam();
                streamParam.setAudioParam(false, AUDIO_CHANNEL, audioParam.sampleRate, audioParam.bitrate, null);
            } else {
//                    if (mAudioExtradata != null && mStreamingParam != null) {
//                        AudioParam audioParam = mStreamingParam.getAudioParam();
//                        streamParam.setAudioParam(true, AUDIO_CHANNEL, audioParam.sampleRate, audioParam.bitrate, mAudioExtradata);
//                    }
            }
            mStreamPipeline.startRecordVideo(streamParam);
        }

    }


    private static RenderWay renderMode2RenderWay(RenderMode renderMode) {
        return renderMode.type == RenderMode.Type.DirectDecoding ?
                RenderWay.DirectDecoding :
                renderMode.renderMethod == RenderMethod.PlanarKeep ?
                        RenderWay.PlanarKeep : RenderWay.DualFishEyeStitchingPlanar;
    }


    @Override
    public void onCameraLiveStop() {
        if (mCameraLiveStateListener != null) {
            mCameraLiveStateListener.onRecordComplete(mRecordPath);
        }
    }

    @Override
    public void onCameraLiveNotify(int notifyType, int value, int extra, String domain, String desc) {
        Log.i(TAG, "onCameraLiveNotify notifyType " + notifyType + " value " + value + " extra " + extra);
        switch (notifyType) {
            case CameraLiveNotify.NotifyType.FPS:
                notifyFps(value);
                break;
            case CameraLiveNotify.NotifyType.FAIL:
                onRecordError(value, extra, domain, desc);
                break;
            case CameraLiveNotify.NotifyType.START:
                notifyLivePushStart();
                break;
            default:
                break;
        }
    }

    private void onRecordError(int value, int extra, String domain, String desc) {
        if (mCameraLiveStateListener != null) {
            mCameraLiveStateListener.onRecordError(value, extra, domain, desc, mRecordPath);
        }
    }

    private void notifyFps(final int fps) {
        if (mInfoHandler != null) {
            mInfoHandler.post(new Runnable() {
                @Override
                public void run() {
                    mInfoUpdateListener.onRecordFpsUpdate(fps);
                }
            });
        } else {
            mInfoUpdateListener.onRecordFpsUpdate(fps);
        }
    }

    private void notifyLivePushStart() {
        if (mInfoHandler != null) {
            mInfoHandler.post(new Runnable() {
                @Override
                public void run() {
                    mInfoUpdateListener.onLivePushStarted(mRecordPath);
                }
            });
        } else {
            mInfoUpdateListener.onLivePushStarted(mRecordPath);
        }
    }
}
