package com.arashivision.insta360.camerastream;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import com.arashivision.insta360.camerastream.bean.AudioParam;
import com.arashivision.insta360.camerastream.bean.AudioSource;
import com.arashivision.insta360.camerastream.bean.StartCaptureWithoutStorage;
import com.arashivision.insta360.camerastream.bean.StartStreamingParam;
import com.arashivision.insta360.camerastream.command.PreviewStreamingCmd;
import com.arashivision.insta360.camerastream.command.ResetRecord;
import com.arashivision.insta360.camerastream.command.StartLiveOrRecordOriginDataCmd;
import com.arashivision.insta360.camerastream.command.StopLiveCmd;
import com.arashivision.insta360.camerastream.command.StopStreamingCmd;
import com.arashivision.insta360.camerastream.listener.ICameraLiveStateListener;
import com.arashivision.insta360.camerastream.listener.ICameraPreviewListener;
import com.arashivision.insta360.camerastream.listener.IScreenCaptureListener;
import com.arashivision.insta360.camerastream.listener.InfoUpdateListener;
import com.arashivision.insta360.camerastream.strategy.OneStreamPipleImpl;
import com.arashivision.insta360.camerastream.stream.PreviewImageNotify;
import com.arashivision.insta360.camerastream.stream.StreamProcess;
import com.arashivision.onestream.Gyro.OneGyroField;
import com.arashivision.onestream.ImageData;
import com.arashivision.onestream.OneStreamPipeline;
import com.arashivision.onestream.PlayerBackend;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;
import com.arashivision.onestream.pipeline.ICameraPreviewScreenCaptureCallback;

import java.util.ArrayList;
import java.util.List;

public class InstaStreamStrategy implements ICameraPreviewListener {
    protected static final String TAG = InstaStreamStrategy.class.getName();
    public OneStreamPipeline mStreamPiple;
    protected AudioSource mAudioSource;
    protected StartStreamingParam mStartStreamingParam;
    protected float[] mGyroMatrix;
    private ArrayList<ICameraPreviewListener> mCameraPreviewListeners;
    protected InfoUpdateListener mInfoUpdateListener;
    protected ICameraLiveStateListener mCameraLiveStateListener;
    protected IScreenCaptureListener mScreenCaptureListener;
    protected ICameraPreviewPipeline mICameraPreviewPipeline;
    protected PreviewImageNotify mPreviewImageNotify;
    protected Handler mPreviewImageNotifyHandler;
    protected Handler mInfoHandler;
    private boolean isStreamTraget;
    protected Object firstSurface;
    protected Object secoundSurface;
    public StreamProcess mStreamProcess;
    protected HandlerThread mDriverHandlerThread;
    protected Handler mThreadHandler;
    protected Handler mMainHandler;
    public Context mContext;

    public void init(Context context) {
        mContext = context;
        mDriverHandlerThread = new HandlerThread("InstaStream");
        mDriverHandlerThread.start();
        mThreadHandler = new Handler(mDriverHandlerThread.getLooper());
        mMainHandler = new Handler(Looper.getMainLooper());
        mStreamPiple = new OneStreamPipeline(context, new OneStreamPipleImpl(), mThreadHandler.getLooper(), mThreadHandler);
        mStreamPiple.setPlayerBackend(PlayerBackend.NativePlayer);
        mCameraPreviewListeners = new ArrayList<>();
    }


    public void setAudioSource(AudioSource audioSource) {
        this.mAudioSource = audioSource;
    }

    public void setGyroRebaseMatrix(float[] matrix3) {
        this.mGyroMatrix = matrix3;
    }

    public void updateOffset(String offset) {
        if (mStreamPiple != null) {
            mStreamPiple.updatePanoOffset(offset);
        }
    }

    public void setPlayerBackend(PlayerBackend playerBackend) {
        if (mStreamPiple != null) {
            mStreamPiple.setPlayerBackend(playerBackend);
        }
    }

    public boolean isStreamProcessing() {
        return mStreamProcess != null;
    }

    public boolean isH265StreamEncode() {
        if (mStreamProcess != null) {
            return mStreamProcess.isH265();
        } else {
            return false;
        }
    }

    /**
     * 设置预览encode模式
     *
     * @param isH265 是否支持h265
     */
    public void setStreamEncode(boolean isH265) {
        if (mStreamPiple == null) {
            return;
        }

        if (mStreamProcess != null) {
            mStreamProcess.release();
            mStreamProcess = null;
        }
        Log.i(TAG, " mDualStreaming " + mStartStreamingParam.isDualStream() + " isH265 " + isH265);
        if (isH265) {
            mStreamPiple.setInputFormat("h265");
        } else {
            mStreamPiple.setInputFormat("h264");
        }
        mStreamProcess = new StreamProcess(mThreadHandler, mStreamPiple, mStartStreamingParam, isH265, mContext, this);
        if (mICameraPreviewPipeline != null) {
            mStreamProcess.updatePiple(mICameraPreviewPipeline);
        }
        if (mPreviewImageNotify != null && mPreviewImageNotifyHandler != null) {
            mStreamProcess.updatePreviewImageNotify(mPreviewImageNotify, mPreviewImageNotifyHandler);
        }
    }

    public void setSurface(Object firstSurface, Object secondSurface, boolean isStreamTraget) {
        this.isStreamTraget = isStreamTraget;
        //设置surface
        this.firstSurface = firstSurface;
        this.secoundSurface = secondSurface;
        /**
         * set surface null or mCameraProcess not null(setStreamingEncode above) already set
         * we need to set surface to update player
         */
        if (firstSurface != null) {
            /**
             * set camera preview pipeline null,for it should not work if app call setSurface with surface not null
             */
            Log.i(TAG, " mSurface is " + firstSurface);
            mICameraPreviewPipeline = null;
        }
        mStreamPiple.setSurface(firstSurface);
    }

    public Object getSurface() {
        return firstSurface;
    }

    public void addCameraPreviewListener(ICameraPreviewListener cameraPreviewListener) {
        if (!mCameraPreviewListeners.contains(cameraPreviewListener)) {
            mCameraPreviewListeners.add(cameraPreviewListener);
        }
    }

    public void removeCameraPreviewListener(ICameraPreviewListener cameraPreviewListener) {
        mCameraPreviewListeners.remove(cameraPreviewListener);
    }

    public void setPipeline(ICameraPreviewPipeline cameraPreviewPipeline) {
        mICameraPreviewPipeline = cameraPreviewPipeline;
        Log.d(TAG, "mStreamProcess = " + mStreamProcess + ",cameraPreviewPipeline = " + cameraPreviewPipeline);
        if (mStreamProcess != null) {
            mStreamProcess.updatePiple(cameraPreviewPipeline);
        }
    }

    public void setPreviewImageNotify(PreviewImageNotify previewImageNotify, Handler threadHandler) {
        mPreviewImageNotify = previewImageNotify;
        mPreviewImageNotifyHandler = threadHandler;
        Log.d(TAG, "mStreamProcess = " + mStreamProcess + ",previewImageNotify = " + previewImageNotify);
        if (mStreamProcess != null) {
            mStreamProcess.updatePreviewImageNotify(previewImageNotify, threadHandler);
        }
    }

    public void forcePutImage(ImageData[] imageDatas) {
        if (mStreamProcess != null) {
            mStreamProcess.forcePutImage(imageDatas);
        }
    }

    public void setPreviewDelta(long previewDeltaNs) {
        if (mICameraPreviewPipeline != null) {
            mICameraPreviewPipeline.onUpdatePreviewDelta(previewDeltaNs);
        } else {
            mStreamPiple.setPreviewDeltaNs(previewDeltaNs);
        }
    }

    public void startScreenCapture(int width, int height, String ouPath) {
        if (mICameraPreviewPipeline != null) {
            mICameraPreviewPipeline.onScreenCapture(width, height, ouPath, new ICameraPreviewScreenCaptureCallback() {
                @Override
                public void onCameraPreviewScreenCaptureNotify(int errorCode, String path) {
                    if (mScreenCaptureListener != null) {
                        mScreenCaptureListener.onScreenCapture(errorCode, path);
                    }
                }
            });
        }

    }

    public void setScreenScptureListener(IScreenCaptureListener iScreenCaptureListener) {
        mScreenCaptureListener = iScreenCaptureListener;
    }

    public void setInfoUpdateListener(Handler handler, InfoUpdateListener infoUpdateListener) {
        this.mInfoHandler = handler;
        mInfoUpdateListener = infoUpdateListener;
    }

    public void setCameraLiveStateListener(ICameraLiveStateListener cameraLiveStateListener) {
        mCameraLiveStateListener = cameraLiveStateListener;
    }

    public void reset() {
        //如果正在预览
//        closePreviewStream();
        if (mStreamProcess != null) {
            mStreamProcess.release();
            mStreamProcess = null;
        }

        if (mStreamPiple != null) {
            mStreamPiple.release();
            mStreamPiple = null;
        }
        if (mDriverHandlerThread != null) {
            mThreadHandler.removeCallbacksAndMessages(null);
        }
    }

    public void release() {
        reset();
        if (mDriverHandlerThread != null) {
            mDriverHandlerThread.quitSafely();

            try {
                mDriverHandlerThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                Log.i(TAG, "reset driver handler thread");
                mDriverHandlerThread = null;
            }
        }
    }

    @Override
    public void onVideoData(final byte[] data, final int offset, final int size, final long timestamp) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (ICameraPreviewListener listener : mCameraPreviewListeners) {
                    listener.onVideoData(data, offset, size, timestamp);
                }
            }
        });
    }

    @Override
    public void onGyroData(final List<OneGyroField> gyroFields) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (ICameraPreviewListener listener : mCameraPreviewListeners) {
                    listener.onGyroData(gyroFields);
                }
            }
        });
    }

    @Override
    public void onExposureData(final double exposureTime, final long timestamp) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (ICameraPreviewListener listener : mCameraPreviewListeners) {
                    listener.onExposureData(exposureTime, timestamp);
                }
            }
        });
    }

    @Override
    public void onResolutionUpdate(int width, int height, int fps) {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (ICameraPreviewListener listener : mCameraPreviewListeners) {
                    listener.onResolutionUpdate(width, height, fps);
                }
            }
        });
    }


    public void previewStream(StartStreamingParam startStreamingParam, String offset) {
        mStartStreamingParam = startStreamingParam;
        new PreviewStreamingCmd(startStreamingParam, mStreamPiple, mGyroMatrix, mAudioSource, firstSurface, offset).exeCmd();
    }

    public void closePreviewStream() {
        new StopStreamingCmd(mStreamPiple, mStreamProcess).exeCmd();
    }

    public void startLive(boolean livePush, int mode, StartCaptureWithoutStorage captureWithoutStorage) {
        updateStartStreamingParam(true);
        new StartLiveOrRecordOriginDataCmd(livePush, mode, mStartStreamingParam, mStreamPiple, captureWithoutStorage, mICameraPreviewPipeline, mAudioSource, mInfoUpdateListener, mInfoHandler, mCameraLiveStateListener).exeCmd();
    }

    public void resetRecord() {
        new ResetRecord(mICameraPreviewPipeline, mStreamPiple).exeCmd();
    }


    public void stopLive() {
        new StopLiveCmd(mICameraPreviewPipeline).exeCmd();
    }

    private void updateStartStreamingParam(boolean isLive) {
        if (mStartStreamingParam != null && mStartStreamingParam.isForLive() != isLive) {
            mStartStreamingParam.setIsForLive(isLive);
            AudioParam audioParam = mStartStreamingParam.getAudioParam();
            if (audioParam == null) {
                audioParam = new AudioParam();
            }
            audioParam.enable = isLive;
            if (isLive) {
                if (audioParam.sampleRate == 0) {
                    audioParam.sampleRate = 48000;
                }
                if (audioParam.bitrate == 0) {
                    audioParam.bitrate = 128000;
                }
            } else {
                audioParam.sampleRate = 0;
                audioParam.bitrate = 0;
            }
            if (mStreamProcess != null) {
                mStreamProcess.changeStreamProcess(mStartStreamingParam.isDualStream(), mStreamProcess.isH265());
            }
        }
    }

    public void releaseSurface() {
        setSurface(null, null, false);
    }

    public void processStreamData(int streamType, byte[] data, long timestamp) {
        if (mStreamProcess != null) {
            mStreamProcess.onDriverStreamDataNotify(streamType, data, timestamp);
        }
    }
}
