package com.arashivision.insta360.camerastream.command;

import com.arashivision.insta360.camerastream.stream.StreamProcess;
import com.arashivision.onestream.OneStreamPipeline;

public class StopStreamingCmd {


    private OneStreamPipeline mStreamPipeline;
    private StreamProcess mStreamProcess;

    public StopStreamingCmd(OneStreamPipeline streamPiple, StreamProcess mStreamProcess) {
        this.mStreamPipeline = streamPiple;
        this.mStreamProcess = mStreamProcess;
    }


    public Object exeCmd() {
        // TODO: 2025/9/26 外部关闭流
//        oneDrvier.setStreamListener(null);
        if (mStreamProcess != null) {
            mStreamProcess.release();
            mStreamProcess = null;
        }
        if (mStreamPipeline != null) {
            mStreamPipeline.close();
            mStreamPipeline.release();
            mStreamPipeline = null;
        }

        return 0;
    }
}
