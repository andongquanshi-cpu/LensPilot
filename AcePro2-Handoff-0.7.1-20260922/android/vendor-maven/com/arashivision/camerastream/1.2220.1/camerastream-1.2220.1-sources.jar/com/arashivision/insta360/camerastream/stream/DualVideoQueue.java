package com.arashivision.insta360.camerastream.stream;

import static com.arashivision.insta360.camerastream.strategy.TraceUtil.TRACE;

import android.os.Handler;
import android.util.Log;
import android.util.LongSparseArray;

import com.arashivision.insta360.camerastream.util.H2645Parser;
import com.arashivision.onestream.ImageData;
import com.arashivision.onestream.OneStreamPipeline;


public class DualVideoQueue extends VideoQueue {

    private LongSparseArray<DualImageInfo> mQueue;

    public DualVideoQueue(int capacity, OneStreamPipeline imagePipeline, Handler processHandler) {
        super(capacity, imagePipeline, processHandler);
        mQueue = new LongSparseArray<>();
    }


    private void dropImage(String key) {
        if (isQueueExceed(key)) {
            int i = 0;
            while (i < mQueue.size()) {
                DualImageInfo info = mQueue.valueAt(i);
                /**
                 * not drop iframe
                 */
                if (info.mLeftFrame != null) {
                    if (info.mLeftFrame.type == H2645Parser.FrameType.Other) {
                        Log.d(TAG, "drop left ts " + mQueue.keyAt(i));
                        mQueue.removeAt(i);
                    } else {
                        i++;
                    }
                    continue;
                } else if (info.mRightFrame != null) {
                    if (info.mRightFrame.type == H2645Parser.FrameType.Other) {
                        Log.d(TAG, "drop right ts " + mQueue.keyAt(i));
                        mQueue.removeAt(i);
                    } else {
                        i++;
                    }
                    continue;
                } else {
                    i++;
                }
            }
            Log.e(TAG, key + " after drop mQueue.size() "
                    + mQueue.size());
        }
    }

    private boolean isQueueExceed(String key) {
        if (mQueue.size() >= mCapacity) {
            Log.e(TAG, key + " mQueue size " + mQueue.size());
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void clear() {

    }

    @Override
    public void enqueVideo(H2645Parser.H2645Frame mFrame, long timestamp) {
        if (TRACE)
            Log.d(TAG, "enqueVideo timestamp " + timestamp);

        /**
         * remove early ts Frame that left is null ,
         * for early ts left frame missed ,which is camera bug
         */
        int i = 0;
        while (i < mQueue.size() && mQueue.keyAt(i) < timestamp) {
            DualImageInfo info = mQueue.valueAt(i);
            if (info.mLeftFrame == null) {
                Log.e(TAG, "remove early ts (" +
                        mQueue.keyAt(i) + ","
                        + timestamp + ")");
                mQueue.removeAt(i);
                if (info.mRightFrame != null) {
                    Log.e(TAG, " type " + info.mRightFrame.type);
                }
            } else {
                i++;
            }
        }

        DualImageInfo dualImageInfo = mQueue.get(timestamp);
        if (dualImageInfo != null) {
            if (dualImageInfo.mRightFrame == null) {
                throw new RuntimeException("dual enqueVideo null");
            }
            dualImageInfo.mLeftFrame = mFrame;

            if(timestamp > mQueue.keyAt(0)){
                int index = mQueue.indexOfKey(timestamp);
                removeAtRange(0,index -1);
            }

            mQueue.remove(timestamp);
            feedPipelineVideo(dualImageInfo.mLeftFrame, dualImageInfo.mRightFrame, timestamp);
        } else {
            dualImageInfo = new DualImageInfo();
            dualImageInfo.mLeftFrame = mFrame;
            mQueue.append(timestamp, dualImageInfo);
            dropImage("left");
        }
    }

    private void removeAtRange(int index, int size) {
        final int end = Math.min(mQueue.size(), index + size);
        for (int i = index; i < end; i++) {
            mQueue.removeAt(i);
        }
    }

    @Override
    public void enqueSecVideo(H2645Parser.H2645Frame mFrame, long timestamp) {
        if (TRACE)
            Log.d(TAG, "enqueSecVideo timestamp " + timestamp);
        /**
         * remove early ts Frame that right is null ,
         * for early ts right frame missed ,which is camera bug
         */
        int i = 0;
        while (i < mQueue.size() && mQueue.keyAt(i) < timestamp) {
            DualImageInfo info = mQueue.valueAt(i);
            if (info.mRightFrame == null) {
                Log.e(TAG, "sec remove early ts (" +
                        mQueue.keyAt(i) + "," +
                        timestamp + ")");
                if (info.mLeftFrame != null) {
                    Log.e(TAG, " type " + info.mLeftFrame.type);
                }
                mQueue.removeAt(i);
            } else {
                i++;
            }
        }

        DualImageInfo dualImageInfo = mQueue.get(timestamp);
        if (dualImageInfo != null) {
            if (dualImageInfo.mLeftFrame == null) {
                throw new RuntimeException("dual enqueSecVideo null");
            }
            dualImageInfo.mRightFrame = mFrame;
            if(timestamp > mQueue.keyAt(0)){
                int index = mQueue.indexOfKey(timestamp);
                removeAtRange(0,index -1);
            }
            mQueue.remove(timestamp);
            feedPipelineVideo(dualImageInfo.mLeftFrame, dualImageInfo.mRightFrame, timestamp);
        } else {
            dualImageInfo = new DualImageInfo();
            dualImageInfo.mRightFrame = mFrame;
            mQueue.append(timestamp, dualImageInfo);
            dropImage("right");
        }
    }


    private static class DualImageInfo {
        public H2645Parser.H2645Frame mLeftFrame;
        public H2645Parser.H2645Frame mRightFrame;


        public boolean isIDRReady() {
            return isReady() && mLeftFrame.isIDR();
        }

        public boolean isReady() {
            if (mLeftFrame != null && mRightFrame != null) {
                return true;
            } else {
                return false;
            }
        }
    }

    public void feedPipelineVideo(H2645Parser.H2645Frame mFrame,
                                  H2645Parser.H2645Frame mSecH264Frame,
                                  long frameSysTimeNs) {
        ImageData imageData = new ImageData();
        imageData.data = mFrame.data;
        imageData.data_offset = mFrame.offset;
        imageData.data_size = mFrame.size;
        imageData.csd = mParser.getCsdData();
        imageData.flags |= (mFrame.type == H2645Parser.FrameType.IDR ||
                mFrame.type == H2645Parser.FrameType.IFrame) ? 1 : 0;
        imageData.timestampNs = frameSysTimeNs;
        imageData.width = getPreviewWidth();
        imageData.height = getPreviewHeight();
        imageData.fps = getPreviewFps();
        imageData.mH265 = mH265;
//            imageData.gyroMatrix = stabilizerMatrix;
//            if(TRACE)
//                Log.i(TAG, "put video packet: offset: " + imageData.data_offset + ", size: " + imageData.data_size + ", type: " +
//                        mFrame.type +
//                        ", start bytes: " +
//                        imageData.data[imageData.data_offset] + ", " + imageData.data[imageData.data_offset + 1] + ", " + imageData.data[imageData.data_offset + 2]
//                        + " frameSysTimeNs " + frameSysTimeNs);


        ImageData imageData2 = new ImageData();
        imageData2.data = mSecH264Frame.data;
        imageData2.data_offset = mSecH264Frame.offset;
        imageData2.data_size = mSecH264Frame.size;
        imageData2.csd = mParserR.getCsdData();
        imageData2.flags |= (mSecH264Frame.type == H2645Parser.FrameType.IDR ||
                mSecH264Frame.type == H2645Parser.FrameType.IFrame) ? 1 : 0;
        imageData2.timestampNs = frameSysTimeNs;
        imageData2.width = getPreviewWidth();
        imageData2.height = getPreviewHeight();
        imageData2.fps = getPreviewFps();
        imageData2.mH265 = mH265;
//            if(TRACE)
//                Log.i(TAG, "put video packet: offset: " +
//                        imageData2.data_offset + ", size: " + imageData2.data_size + ", type: " +
//                        mFrame.type +
//                        ", start bytes: " +
//                        imageData2.data[imageData2.data_offset] + ", " +
//                        imageData2.data[imageData2.data_offset + 1] + ", "
//                        + imageData2.data[imageData2.data_offset + 2] +
//                        " frameSysTimeNs " + frameSysTimeNs);

        ImageData[] imageDatas = {imageData,imageData2};
        putImage(imageDatas);

    }


    private int getPreviewWidth() {
        return mVideoParam.width / 2;
    }

    private int getPreviewHeight() {
        return mVideoParam.height;
    }

    public int getPreviewFps() {
        return mVideoParam.fps;
    }

    @Override
    public void putImage(final ImageData[] imageDatas) {
        if (mICameraPreviewPipeline != null) {
            if (mPreviewImageNotify != null && mPreviewImageNotifyHandler != null) {
                mPreviewImageNotifyHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (mPreviewImageNotify != null && mPreviewImageNotify.onImageNotify(imageDatas)) {
                            mProcessHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (mICameraPreviewPipeline != null) {
                                        mICameraPreviewPipeline.onVideoStream(imageDatas);
                                    }
                                }
                            });
                        }
                    }
                });
            } else {
                mICameraPreviewPipeline.onVideoStream(imageDatas);
            }
        } else {
            if (imageDatas.length == 2) {
                mImagePipeline.putImage(imageDatas[0], imageDatas[1]);
            }
        }
    }

}
