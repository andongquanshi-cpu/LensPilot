package com.arashivision.insta360.camerastream.stream;

import android.os.Handler;
import android.util.Log;

import com.arashivision.insta360.camerastream.bean.VideoParam;
import com.arashivision.insta360.camerastream.util.H2645Parser;
import com.arashivision.onestream.ImageData;
import com.arashivision.onestream.OneStreamPipeline;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;

import java.util.LinkedList;

public abstract class VideoQueue {

    protected static final String TAG = VideoQueue.class.getName();

    protected int mCapacity;

    protected boolean mTrace;

    private long mPreviewDeltaNs;
    protected Handler mProcessHandler;
    protected OneStreamPipeline mImagePipeline;
    protected VideoParam mVideoParam;

    protected boolean mGyroStabilizerApplied;

    protected ICameraPreviewPipeline mICameraPreviewPipeline;
    protected H2645Parser mParser;
    protected H2645Parser mParserR;
    protected boolean mH265;

    protected PreviewImageNotify mPreviewImageNotify;
    protected Handler mPreviewImageNotifyHandler;

    /**
     * one frame ,one exposure
     */
    private LinkedList<ExposureInfo> mListExposureQueue;

    public VideoQueue(int capacity, OneStreamPipeline oneStreamPipeline, Handler processHandler) {
        this.mImagePipeline = oneStreamPipeline;
        this.mProcessHandler = processHandler;
        mCapacity = capacity;
        mListExposureQueue = new LinkedList<>();
    }

    public void setTrace(boolean trace) {
        mTrace = trace;
    }

    public void setGyroStabilizerApplied(boolean gyroStabilizerApplied) {
        mGyroStabilizerApplied = gyroStabilizerApplied;
    }

    public void setVideoParam(VideoParam videoParam) {
        mVideoParam = videoParam;
    }

    public void setParser(H2645Parser mParser, H2645Parser mParserR) {
        this.mParser = mParser;
        this.mParserR = mParserR;
    }

    public void setH265(boolean isH265) {
        mH265 = isH265;
    }

    protected long getExactTimestamp(long frameTsNs, long exposureNS) {
        long ts = frameTsNs - exposureNS / 2 + mPreviewDeltaNs;

        return ts;
    }

    protected boolean enqueExposureTime(ExposureInfo info) {
        mListExposureQueue.add(info);
        if (mListExposureQueue.size() > mCapacity) {
            mListExposureQueue.removeFirst();
        }
        if (mListExposureQueue.size() == 1) {
            return true;
        } else {
            return false;
        }
    }

    protected void removeExposure(int pos) {
        /**
         *
         * next frame ts surely bigger the the exposure list that before pos
         * for mListExposureQueue is ascending order
         * so we remove the useless exposure time
         */
        int i = 0;
        while (i++ < pos) {
            mListExposureQueue.remove(0);
        }
    }

    protected long getExposureTime(int index) {
        return mListExposureQueue.get(index).exposureTimeNs;
    }

    protected int getExposureTimeIdx(long frameTsNs) {
        int index = -1;

        if (mListExposureQueue.size() > 0) {
            int i = 0;
            if (frameTsNs < mListExposureQueue.get(0).timestampNs) {
                if (mTrace)
                    Log.e(TAG, "early exposure frameTsNs " + frameTsNs + "<" +
                            mListExposureQueue.get(0).timestampNs
                            + " size " + mListExposureQueue.size());
                /**
                 * early exposure time might lost,so ,force use first one
                 */
                return 0;
            } else if (frameTsNs > mListExposureQueue.get(mListExposureQueue.size() - 1).timestampNs) {
                if (mTrace)
                    Log.w(TAG, "late exposure frameTsNs " + frameTsNs + ">" + mListExposureQueue.get(mListExposureQueue.size() - 1).timestampNs
                            + " size " + mListExposureQueue.size());
                /**
                 * force use latest expoure time if frame is earlier than expousre
                 * for exposure time is not important as gyro,we don't need wait for avoiding render dealy
                 * which is said by ios
                 */
                return mListExposureQueue.size() - 1;
            }
            int limit = mListExposureQueue.size() - 1;
            while (i < limit) {
                if (frameTsNs >= mListExposureQueue.get(i).timestampNs
                        && frameTsNs <= mListExposureQueue.get(i + 1).timestampNs) {
                    if (mTrace)
                        Log.i(TAG, "find (" + mListExposureQueue.get(i).timestampNs + "," +
                                frameTsNs + "," + mListExposureQueue.get(i + 1).timestampNs +
                                ") time " + mListExposureQueue.get(i).exposureTimeNs + " i " + i + " size "
                                + mListExposureQueue.size());
                    index = i;
                    break;
                }
                i++;
            }
            if (index == -1) {
                Log.w(TAG, "exposure not found frameTsNs " +
                        frameTsNs + " size " +
                        mListExposureQueue.size());
                /**
                 * force to idx0 if not found
                 */
                return 0;
            }
        } else {
            Log.e(TAG, " no exposure");
        }
        return index;
    }


    public abstract void clear();

    public abstract void enqueVideo(H2645Parser.H2645Frame mFrame, long timestamp);

    public abstract void enqueSecVideo(H2645Parser.H2645Frame mFrame, long timestamp);

    public abstract void putImage(ImageData[] imageDatas);


    public void updatePipleline(ICameraPreviewPipeline cameraPreviewPipeline) {
        this.mICameraPreviewPipeline = cameraPreviewPipeline;
    }

    public void updatePreviewImageNotify(PreviewImageNotify previewImageNotify, Handler threadHandler) {
        this.mPreviewImageNotify = previewImageNotify;
        this.mPreviewImageNotifyHandler = threadHandler;
    }

    public void forcePutImage(final ImageData[] imageDatas) {
        ImageData imageData = imageDatas[0];
        if (imageData.flags != 1) {
            Log.e(TAG, " forcePutImage not i-frame");
        }
        Log.i(TAG, "forcePutImage: offset: " + imageData.data_offset + ", size: " + imageData.data_size + ", type: " +
                ", start bytes: " +
                imageData.data[imageData.data_offset] + ", " + imageData.data[imageData.data_offset + 1] + ", " + imageData.data[imageData.data_offset + 2]
                + " timestampNs " + imageData.timestampNs);
        if (mICameraPreviewPipeline != null) {
            mICameraPreviewPipeline.onVideoStream(imageDatas);
        }
    }

    public static class ExposureInfo {
        public long exposureTimeNs;
        public long timestampNs;
    }

}
