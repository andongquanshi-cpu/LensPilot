package com.arashivision.insta360.camerastream;

import com.arashivision.insta360.camerastream.bean.StartStreamingParam;
import com.arashivision.onestream.ImageData;
import com.arashivision.onestream.PlayerBackend;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;

/**
 * 相机流处理接口
 * 定义了相机与stream处理相关的接口
 */
public interface ICameraStream {
    
    /**
     * 开始预览流
     */
    void startPreviewStream(StartStreamingParam param, String offset);
    
    /**
     * 停止预览流
     */
    void stopPreviewStream();
    
    /**
     * 设置预览管道
     */
    void setPreviewPipeline(ICameraPreviewPipeline pipeline);
    
    /**
     * 设置播放器后端
     */
    void setPlayerBackend(PlayerBackend playerBackend);
    
    /**
     * 设置流编码格式
     */
    void setStreamEncode(boolean isH265);
    
    /**
     * 强制推送图像
     */
    void forcePutImage(ImageData[] imageDatas);
    
    /**
     * 设置预览延迟
     */
    void setPreviewDelta(long delta);
    
    /**
     * 更新偏移量
     */
    void updateOffset(String offset);
    
    /**
     * 请求流I帧
     */
    void requestStreamIframe();
    
    /**
     * 检查是否正在流处理
     */
    boolean isStreamProcessing();
    
    /**
     * 检查是否使用H265编码
     */
    boolean isH265StreamEncode();
}
