package com.arashivision.insta360.camerastream.bean

/**
 * Created by vans on 25/10/17.
 * Stream Audio Source,Default is [.AUDIO_CAMERA]
 *
 *  * Method [.AUDIO_MOBILE]: audio from mobile
 *  * Method [.AUDIO_CAMERA]: audio from camera
 *  * Method [.AUDIO_NONE]: no audio
 *
 */
enum class AudioSource {
    AUDIO_MOBILE, AUDIO_CAMERA, AUDIO_NONE
}
