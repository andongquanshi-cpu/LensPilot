package com.arashivision.insta360.camerastream.render;

/**
 * Render Mode
 * <p>${@link #directDecoding()}</p>
 */
public class RenderMode {
    public enum Type { DirectDecoding, WithGLRenderer }

    public Type type;
    public RenderMethod renderMethod;

    /**
     * Create DirectDecoding Render Mode
     * @return RenderMode of DirectDecoding mode
     */
    public static RenderMode directDecoding() {
        return new RenderMode(Type.DirectDecoding, null);
    }

    /**
     * Create WithGLRenderer Render Mode
     * @param renderMethod Use witch GL Render Method to process input frames. see {@link RenderMethod}
     * @return RenderMoe of WithGlRenderer mode
     */
    public static RenderMode withGlRenderer(RenderMethod renderMethod) {
        return new RenderMode(Type.WithGLRenderer, renderMethod);
    }

    private RenderMode(Type type, RenderMethod renderMethod) {
        this.type = type;
        this.renderMethod = renderMethod;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null)
            return false;
        if(this == obj)
            return true;
        if (getClass() != obj.getClass())
            return false;
        RenderMode other = (RenderMode)obj;
        switch (this.type) {
            case DirectDecoding:
                return other.type == Type.DirectDecoding;
            case WithGLRenderer:
                return other.type == Type.WithGLRenderer && other.renderMethod == this.renderMethod;
        }
        return false;
    }

    @Override
    public String toString() {
        switch (this.type) {
            case DirectDecoding:
                return "{DirectDecoding}";
            case WithGLRenderer:
                return "{WithGLRenderer" + ", method: " + renderMethod + "}";
        }
        return super.toString();
    }
}
