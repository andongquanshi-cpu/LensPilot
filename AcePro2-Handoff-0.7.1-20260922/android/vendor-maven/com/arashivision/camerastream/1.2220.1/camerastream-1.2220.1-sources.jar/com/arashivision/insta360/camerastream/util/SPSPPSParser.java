package com.arashivision.insta360.camerastream.util;

/**
 * Created by vans on 20/9/19.
 */

public class SPSPPSParser {

    static {
        System.loadLibrary("camerastream");
    }

    static int parse(byte[] sps,int[] outResolution,int[] outFps,float[] outFpsFloat)
    {
        return nativeParse(sps,outResolution,outFps,outFpsFloat);
    }

    public static native int nativeParse(byte[] sps,int[] outResolution,int[] outFps,float[] outFpsFloat);

    public static native int nativeParseH265(byte[] sps,int[] outResolution,int[] outFps,float[] outFpsFloat);
}
