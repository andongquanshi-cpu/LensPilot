package com.arashivision.insta360.camerastream.stream;

import static com.arashivision.insta360.camerastream.strategy.TraceUtil.TRACE;

import android.os.Handler;
import android.util.Log;

import com.arashivision.insta360.camerastream.util.H2645Parser;
import com.arashivision.onestream.ImageData;
import com.arashivision.onestream.OneStreamPipeline;
import com.arashivision.onestream.pipeline.ICameraPreviewPipeline;


public class SingleVideoQueue extends VideoQueue {


    public SingleVideoQueue(int capacity, OneStreamPipeline pipeline, Handler processHandler) {
        super(capacity, pipeline, processHandler);
    }


    @Override
    public void clear() {
    }

    @Override
    public void enqueVideo(H2645Parser.H2645Frame mFrame, long timestamp) {
        feedPipelineVideo(mFrame, timestamp, false);
    }

    @Override
    public void enqueSecVideo(H2645Parser.H2645Frame mFrame, long timestamp) {

    }

    public void feedPipelineVideo(H2645Parser.H2645Frame mFrame,
                                  long frameSysTimeNs,
                                  boolean forcePut) {
        // post data to image pipeline
        ImageData imageData = new ImageData();
        imageData.data = mFrame.data;
        imageData.data_offset = mFrame.offset;
        imageData.data_size = mFrame.size;
        if (mParser != null) {
            imageData.csd = mParser.getCsdData();
        }
        imageData.flags |= (mFrame.type == H2645Parser.FrameType.IDR ||
                mFrame.type == H2645Parser.FrameType.IFrame) ? 1 : 0;
        imageData.timestampNs = frameSysTimeNs;
        imageData.width = getPreviewWidth();
        imageData.height = getPreviewHeight();
        imageData.fps = getPreviewFps();
        imageData.mH265 = mH265;
//            imageData.gyroMatrix = stabilizerMatrix;
        if (TRACE)
            Log.i(TAG, "put video packet: offset: " +
                    imageData.data_offset + ", size: " + imageData.data_size + ", type: " +
                    mFrame.type +
                    " , flags " + imageData.flags + " imageData.mH265 " + imageData.mH265 +
                    ", start bytes: " +
                    imageData.data[imageData.data_offset] + ", " +
                    imageData.data[imageData.data_offset + 1] + ", "
                    + imageData.data[imageData.data_offset + 2] + " frameSysTimeNs " + frameSysTimeNs +
                    ", forcePut " + forcePut);
        ImageData[] imageDatas = {imageData};
        if (forcePut) {
            if (mICameraPreviewPipeline != null) {
                mICameraPreviewPipeline.onVideoStream(imageDatas);
            } else {
                mImagePipeline.putImage(imageDatas[0]);
            }
        } else {
            putImage(imageDatas);
        }
    }

    @Override
    public void putImage(final ImageData[] imageDatas) {
        final ICameraPreviewPipeline pipeline = mICameraPreviewPipeline;
        final PreviewImageNotify imageNotify = mPreviewImageNotify;
        final Handler imageNotifyHandler = mPreviewImageNotifyHandler;
        if (pipeline != null) {
            if (imageNotify != null && imageNotifyHandler != null) {
                imageNotifyHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (imageNotify.onImageNotify(imageDatas)) {
                            mProcessHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    pipeline.onVideoStream(imageDatas);
                                }
                            });
                        }
                    }
                });
            } else {
                pipeline.onVideoStream(imageDatas);
            }
        } else {
            mImagePipeline.putImage(imageDatas[0]);
        }
    }

    public int getPreviewWidth() {
        return mVideoParam.width;
    }

    public int getPreviewHeight() {
        return mVideoParam.height;
    }

    public int getPreviewFps() {
        return mVideoParam != null ? mVideoParam.fps : 0;
    }
}
