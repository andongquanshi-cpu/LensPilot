package com.arashivision.insta360.camerastream.util;

import static com.arashivision.insta360.camerastream.strategy.TraceUtil.TRACE;

import android.util.Log;

import java.util.ListIterator;

public class H264Parser extends H2645Parser {
    private static final String TAG = "OneH264Parser";

    @Override
    protected int spsParse(byte[] sps,int[] outResolution,int[] outFps,float[] outFpsFloat)
    {
        return SPSPPSParser.nativeParse(mSps,outResolution,outFps,outFpsFloat);
    }

    @Override
    public boolean readFrame(H2645Frame h264Frame) {
        Nalu nalu = new Nalu();
        while(readNalu(nalu)) {
            if (TRACE) {
                Log.i(TAG, "readNalu, type = " + nalu.type);
            }
            if((nalu.type == NaluType.SPS || nalu.type == NaluType.PPS)) {
                /**
                 * TC1/IAC开始有预览自动切sensor的情况，所以每次收到 sps/pps 后都要刷新
                 */
                if (nalu.type == NaluType.SPS) {
                    reset(false);
                }
                /**
                 * normally csd data not change,so we only get sps/pps once
                 */
                if(mCsd == null)
                {
                    if(nalu.type == NaluType.SPS) {
                        mSps = dupBytes(nalu.buf, nalu.offset, nalu.size);
                        parseSps();
                    } else if(nalu.type == NaluType.PPS) {
                        mPps = dupBytes(nalu.buf, nalu.offset , nalu.size );
                    }

                    if(mSps != null && mPps != null) {
                        byte[] csd = new byte[mSps.length + mPps.length];
                        System.arraycopy(mSps, 0, csd, 0, mSps.length);
                        System.arraycopy(mPps, 0, csd, mSps.length, mPps.length);
                        mCsd = csd;
                    }
                }
                continue;
            }
            if(nalu.type == NaluType.CODED_IDR_SLICE) {
                if(mCsd != null) {
                    h264Frame.data = new byte[mCsd.length + nalu.size];
                    System.arraycopy(mCsd, 0, h264Frame.data, 0, mCsd.length);
                    System.arraycopy(nalu.buf, nalu.offset, h264Frame.data, mCsd.length, nalu.size);
                    h264Frame.offset = 0;
                    h264Frame.size = mCsd.length + nalu.size;
                    h264Frame.type = FrameType.IDR;
                    return true;
                }
                else {
                    /**
                     * new data and then copy, so nal will free
                     */
                    Log.e(TAG," mCsd null, iframe?");
                    h264Frame.data = new byte[nalu.size];
                    System.arraycopy(nalu.buf, nalu.offset, h264Frame.data, 0, nalu.size);
                    h264Frame.offset = 0;
                    h264Frame.size = nalu.size;
                    h264Frame.type = FrameType.IFrame;
                    return true;
                }
            }
            else if(nalu.type == NaluType.DELIMITER) {
                // drop it
                continue;
            }
            else if(nalu.type == NaluType.SEI) {
                continue;
            }
            else {
                /**
                 * new data and then copy, so nal will free
                 */
                h264Frame.data = new byte[nalu.size];
                System.arraycopy(nalu.buf, nalu.offset, h264Frame.data, 0, nalu.size);
                h264Frame.offset = 0;
                h264Frame.size = nalu.size;
                h264Frame.type = FrameType.Other;
                return true;
            }
        }
        return false;
    }
    @Override
    protected boolean readNalu(Nalu nalu) {
        ListIterator<Payload> itr = mParseBufQueue.listIterator();
        NalPos naluPos = new NalPos();
        while(itr.hasNext()) {
            Payload payload = itr.next();
            if(!findNalUnit(payload.buf, payload.offset, payload.size, naluPos, true)) {
                if(!payload.oneNaluFound)
                    Log.w(TAG, "payload is not NAL unit, dropped");
                itr.remove();
                continue;
            }

            nalu.buf = payload.buf;
            nalu.offset = naluPos.start;
            nalu.size = naluPos.end - naluPos.start;
            nalu.type = naluType(payload.buf, naluPos.start);

            payload.size = payload.offset + payload.size - naluPos.end;
            payload.offset = naluPos.end;
            payload.oneNaluFound = true;
            return true;
        }
        return false;
    }

    @Override
    protected boolean findNalUnit(byte[] buffer, int bufferOffset, int bufferSize,
                                  NalPos nalPos, boolean bufferEndCouldAsNalEnd) {
        int i = bufferOffset;
        int limit = bufferOffset + bufferSize;

        if(i + 4 >= limit)
            return false;
        while((buffer[i] != 0  || buffer[i+1] != 0 || buffer[i+2] != 0x1) &&
                (buffer[i] != 0 || buffer[i+1] != 0 || buffer[i+2] != 0 || buffer[i+3] != 0x1)) {
            ++i;
            if(i + 4 >= limit)
                return false;
        }
        nalPos.start = i;
        if(buffer[i+2] != 0x1)
            ++i;
        i += 3;
        NaluType naluType = naluType(buffer, nalPos.start);
        if(naluType != NaluType.DELIMITER && naluType != NaluType.SEI && naluType != NaluType.SPS &&
                naluType != NaluType.PPS) {
            // not those special nalu, won't has other nalu after this nalu, no need to scan to the buffer end
//            if(bufferEndCouldAsNalEnd)
//            {
            nalPos.end = limit;
//                return true;
//            }
        }

        for(;;) {
            if(i + 2 >= limit) {
                if(bufferEndCouldAsNalEnd) {
                    nalPos.end = limit;
                    return true;
                }
                return false;
            }
            /**
             * sps & pps in one video packet but still with segment for 0x00,0x00,0x01 or 0x00,0x00,0x00,0x01
             */
            if((buffer[i] != 0  || buffer[i+1] != 0 || buffer[i+2] != 0x1) &&
                    (buffer[i] != 0 || buffer[i+1] != 0 || buffer[i+2] != 0))
                ++i;
            else
                break;
        }
        nalPos.end = i;
        return true;
    }

    protected NaluType naluType(byte[] buffer, int naluStartPos) {
        int naluDataOffset;
        if(buffer[naluStartPos + 2] == 0)
            naluDataOffset = naluStartPos + 4;
        else
            naluDataOffset = naluStartPos + 3;
        int nalUnitType = buffer[naluDataOffset] & 0x1F;
        if(nalUnitType == 9)
            return NaluType.DELIMITER;
        if(nalUnitType == 6)
            return NaluType.SEI;
        if(nalUnitType == 7)
            return NaluType.SPS;
        if(nalUnitType == 8)
            return NaluType.PPS;
        if(nalUnitType == 1)
            return NaluType.CODED_NON_IDR_SLICE;
        if(nalUnitType == 5)
            return NaluType.CODED_IDR_SLICE;
        return NaluType.UNKNOWN;
    }
}
