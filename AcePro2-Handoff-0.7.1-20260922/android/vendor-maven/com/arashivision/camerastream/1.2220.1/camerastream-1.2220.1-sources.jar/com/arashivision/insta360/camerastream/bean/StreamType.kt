package com.arashivision.insta360.camerastream.bean

object StreamType {
    const val AUDIO_STREAM: Int = 0x10
    const val VIDEO_STREAM: Int = 0x20
    const val VIDEO_STREAM_L: Int = 0x21
    const val VIDEO_STREAM_R: Int = 0x22
    const val GYRO_STREAM: Int = 0x30
    const val VIDEO_EXPOSURE_TIME: Int = 0x40

    const val VIDEO_PTZ: Int = 0x83
    const val P3_ALGORITHM: Int = 0x84
    const val UNKNOWN: Int = 0xFF
}