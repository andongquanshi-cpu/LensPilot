package com.arashivision.insta360.camerastream.bean;

import com.arashivision.onestream.Gyro.GyroType;

/**
 * Created by vans on 9/7/18.
 */

public class StartStreamingParam
{
    private boolean dualStream;
    private GyroType mGyroType;
    /**
     * major stream (eg 5760x2880@30fps)
     */
    private VideoParam firstVideoParam;
    /**
     * minor stream (eg 960x480@30fps)
     */
    private VideoParam secVideoParam;
    /**
     * preview audio stream {@link AudioParam}
     */
    private AudioParam mAudioParam;

    /**
     * 0: use {@link StartStreamingParam#firstVideoParam as preview param
     * 1: use {@link StartStreamingParam#secVideoParam as preview param
     */
    private int previewNum;

    private boolean enableRotate;

    private boolean isForLive;

    private boolean diretionalZ;

    private boolean mRecordOriginH264;

    private boolean mRecordOriginGyro;

    public boolean isDualStream()
    {
        return dualStream;
    }

    public void setDualStream(boolean dualStream)
    {
        this.dualStream = dualStream;
    }

    public GyroType getGyroType()
    {
        return mGyroType;
    }

    public void setGyroType(GyroType gyroType)
    {
        mGyroType = gyroType;
    }

    public VideoParam getFirstVideoParam()
    {
        return firstVideoParam;
    }

    public void setFirstVideoParam(VideoParam firstVideoParam)
    {
        this.firstVideoParam = firstVideoParam;
    }

    public VideoParam getSecVideoParam()
    {
        return secVideoParam;
    }

    public void setSecVideoParam(VideoParam secVideoParam)
    {
        this.secVideoParam = secVideoParam;
    }

    public int getPreviewNum()
    {
        return previewNum;
    }

    public void setPreviewNum(int previewNum)
    {
        this.previewNum = previewNum;
    }

    public AudioParam getAudioParam()
    {
        return mAudioParam;
    }

    public void setAudioParam(AudioParam audioParam)
    {
        mAudioParam = audioParam;
    }

    public boolean isDiretionalZ() {
        return diretionalZ;
    }

    public void setDiretionalZ(boolean diretionalZ) {
        this.diretionalZ = diretionalZ;
    }

    public boolean isRecordOriginH264() {
        return mRecordOriginH264;
    }

    public void setRecordOriginH264(boolean recordOriginH264) {
        mRecordOriginH264 = recordOriginH264;
    }

    public boolean ismRecordOriginGyro() {
        return mRecordOriginGyro;
    }

    public void setmRecordOriginGyro(boolean mRecordOriginGyro) {
        this.mRecordOriginGyro = mRecordOriginGyro;
    }

    public void setRotateEnabled(boolean enableRotate) {
        this.enableRotate = enableRotate;
    }

    public boolean isRotateEnabled() {
        return enableRotate;
    }

    public void setIsForLive(boolean isForLive) {
        this.isForLive = isForLive;
    }

    public boolean isForLive() {
        return isForLive;
    }
}
