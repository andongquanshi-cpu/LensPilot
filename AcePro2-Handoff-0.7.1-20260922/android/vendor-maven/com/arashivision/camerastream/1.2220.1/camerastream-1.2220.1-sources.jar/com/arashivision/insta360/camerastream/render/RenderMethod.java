package com.arashivision.insta360.camerastream.render;


/**
 * GL Render Method
 * <ul>
 * <li>Method {@link #PlanarKeep}: keep the output the same with original frames</li>
 * <li>Method {@link #DualFishEyeStitchingPlanar}: stitch the dual fisheye frames to planar stitched frames</li>
 * </ul>
 */
public enum RenderMethod {
    PlanarKeep,
    DualFishEyeStitchingPlanar,
}
