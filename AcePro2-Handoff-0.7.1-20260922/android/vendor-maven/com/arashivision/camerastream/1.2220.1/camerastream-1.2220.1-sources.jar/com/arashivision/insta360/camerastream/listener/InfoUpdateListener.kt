package com.arashivision.insta360.camerastream.listener

interface InfoUpdateListener {
    /**
     * live fps update notify
     * @param fps fps num
     */
    fun onRecordFpsUpdate(fps: Int)

    /**
     * live url notify
     * @param url live url
     */
    fun onLivePushStarted(url: String?)

    /**
     * camera info notify,new add for one
     * @param type info type [OneDriverInfo.Response.InfoType]
     * @param error 0 if no error, error num if error happen
     * @param obj info detail,see package com.arashivision.onecamera.cameranotification
     */
    fun onCameraInfoNotify(type: Int, error: Int, obj: Any?)
}