package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 重新开启预览的h264/5模式
 */
class SetPreviewEncodeCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return null
    }
}
