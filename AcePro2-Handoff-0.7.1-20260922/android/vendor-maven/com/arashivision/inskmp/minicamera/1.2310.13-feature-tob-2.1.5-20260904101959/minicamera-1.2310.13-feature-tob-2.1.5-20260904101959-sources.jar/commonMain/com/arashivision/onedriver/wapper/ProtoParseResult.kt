package com.arashivision.onedriver.wapper

import com.arashivision.common.Log
import com.arashivision.minicamera.DEBUG
import com.arashivision.onecamera.Error
import insta360.messages.CalibrateGyroResp
import insta360.messages.CancelCaptureResp
import insta360.messages.ChargingBoxDataResp
import insta360.messages.CheckAuthorizationResp
import insta360.messages.DataTransPort
import insta360.messages.DeleteFilesResp
import insta360.messages.DeleteWifiConnectListResp
import insta360.messages.EditFileInfoList
import insta360.messages.EncryptCapabilityResp
import insta360.messages.EncryptKeyExchangeResp
import insta360.messages.FileInfo_List
import insta360.messages.FirmwareVersions
import insta360.messages.GetActiveSensorDeviceResp
import insta360.messages.GetButtonParamsResp
import insta360.messages.GetCloudStorageBindStatusResp
import insta360.messages.GetCloudStorageUploadStatusResp
import insta360.messages.GetConnectedBTPeripheralResp
import insta360.messages.GetCurrentButtonStatusResp
import insta360.messages.GetCurrentCaptureStatusResp
import insta360.messages.GetFileListResp
import insta360.messages.GetFileResp
import insta360.messages.GetFlowstateEnableResp
import insta360.messages.GetGyroResp
import insta360.messages.GetLiveOptionsResp
import insta360.messages.GetMultiPhotographyOptionsResp
import insta360.messages.GetOptionsResp
import insta360.messages.GetPhotographyOptionsResp
import insta360.messages.GetPresetCompositionResp
import insta360.messages.GetSfrResult
import insta360.messages.GetSfrStatus
import insta360.messages.GetSyncCaptureModeResp
import insta360.messages.GetTimelapseOptionsResp
import insta360.messages.GetWhiteblanceStatus
import insta360.messages.GetWifiConnectListResp
import insta360.messages.GetWifiConnectionInfoResp
import insta360.messages.GetWifiModeResp
import insta360.messages.GetWifiScanInfoResp
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecSceneInfoResp
import insta360.messages.IntervalRecStatus
import insta360.messages.MessageCode
import insta360.messages.NotificationDarkEisStatus
import insta360.messages.PtzTrackStateReport
import insta360.messages.SetActiveSensorDeviceResp
import insta360.messages.SetButtonParamsResp
import insta360.messages.SetCameraLiveInfoResp
import insta360.messages.SetCloudStorageUploadStatusResp
import insta360.messages.SetFlowstateEnableResp
import insta360.messages.SetMultiPhotographyOptionsResp
import insta360.messages.SetNetworkConfigEnableResp
import insta360.messages.SetOptionsResp
import insta360.messages.SetPhotographyOptionsResp
import insta360.messages.SetPromptIntervalResp
import insta360.messages.SetTimelapseOptionsResp
import insta360.messages.SetWifiConnectionInfoResp
import insta360.messages.StartBulletTimeResp
import insta360.messages.StartCaptureResp
import insta360.messages.StartHdrResp
import insta360.messages.StartLiveStreamResp
import insta360.messages.StartTimelapseResp
import insta360.messages.StopBulletTimeResp
import insta360.messages.StopCaptureResp
import insta360.messages.StopHdrResp
import insta360.messages.StopLiveStreamResp
import insta360.messages.StopTimeShiftResp
import insta360.messages.StopTimelapseResp
import insta360.messages.SyncTimeAccurateResp
import insta360.messages.TakePictureResponse
import insta360.messages.TestSDCardSpeedResp
import insta360.messages.TranslateConfig
import insta360.messages.UsbCardStatus

/**
 * Protobuf解析结果 - 对应C++版本的ProtoParseResult
 */
data class ProtoParseResult(
    val message: com.squareup.wire.Message<*, *>?,
    val errorCode: Int,
)

/**
 * 解析Protobuf响应 - 对应C++版本的ParseProtoResponse
 */
@OptIn(ExperimentalStdlibApi::class)
fun parseProtoResponse(messageCode: MessageCode, buf: ByteArray): ProtoParseResult {
    return try {
        when (messageCode) {
            MessageCode.PHONE_COMMAND_START_LIVE_STREAM -> {
                ProtoParseResult(StartLiveStreamResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_STOP_LIVE_STREAM -> {
                ProtoParseResult(StopLiveStreamResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_TAKE_PICTURE -> {
                ProtoParseResult(TakePictureResponse.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_START_CAPTURE -> {
                ProtoParseResult(StartCaptureResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_START_BULLETTIME_CAPTURE -> {
                ProtoParseResult(StartBulletTimeResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_STOP_CAPTURE -> {
                ProtoParseResult(StopCaptureResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_STOP_BULLETTIME_CAPTURE -> {
                ProtoParseResult(StopBulletTimeResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_CANCEL_CAPTURE -> {
                ProtoParseResult(CancelCaptureResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_OPTIONS -> {
                ProtoParseResult(SetOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_OPTIONS -> {
                ProtoParseResult(GetOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_PHOTOGRAPHY_OPTIONS -> {
                ProtoParseResult(SetPhotographyOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_PHOTOGRAPHY_OPTIONS -> {
                ProtoParseResult(GetPhotographyOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_BUTTON_PRESS_PARAM -> {
                ProtoParseResult(GetButtonParamsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_BUTTON_PRESS_PARAM -> {
                ProtoParseResult(SetButtonParamsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_FILE_EXTRA -> {
                // 对应C++版本：CHECK_MSG(false, "PHONE_COMMAND_GET_FILE_EXTRA response should be binary data");
                throw IllegalStateException("PHONE_COMMAND_GET_FILE_EXTRA response should be binary data")
            }

            MessageCode.PHONE_COMMAND_GET_IPERF_AVERAGE -> {
                // 对应C++版本：CHECK_MSG(false, "PHONE_COMMAND_GET_IPERF_AVERAGE response should be binary data");
                throw IllegalStateException("PHONE_COMMAND_GET_IPERF_AVERAGE response should be binary data")
            }

            MessageCode.PHONE_COMMAND_DELETE_FILES -> {
                ProtoParseResult(DeleteFilesResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_DOWNLOAD_FILE_LIST,
            MessageCode.PHONE_COMMAND_GET_FILE_LIST,
            MessageCode.PHONE_COMMAND_GET_RECORDING_FILE,
                -> {
                ProtoParseResult(GetFileListResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_FILEINFO_LIST -> {
                ProtoParseResult(FileInfo_List.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_EDITINFO_LIST -> {
                ProtoParseResult(EditFileInfoList.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_PREPARE_GET_FILE_SYNC_PACKAGE,
            MessageCode.PHONE_COMMAND_PREPARE_GET_FILE_PACKAGE,
                -> {
                ProtoParseResult(GetFileResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_TAKE_PICTURE_WITHOUT_STORING -> {
                // 对应C++版本：CHECK_MSG(false, "PHONE_COMMAND_TAKE_PICTURE_WITHOUT_STORING response should be binary data");
                throw IllegalStateException("PHONE_COMMAND_TAKE_PICTURE_WITHOUT_STORING response should be binary data")
            }

            MessageCode.PHONE_COMMAND_GET_CURRENT_CAPTURE_STATUS -> {
                ProtoParseResult(GetCurrentCaptureStatusResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_TIMELAPSE_OPTIONS -> {
                ProtoParseResult(GetTimelapseOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_TIMELAPSE_OPTIONS -> {
                ProtoParseResult(SetTimelapseOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_GYRO -> {
                ProtoParseResult(GetGyroResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_START_TIMELAPSE -> {
                ProtoParseResult(StartTimelapseResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_STOP_TIMELAPSE -> {
                ProtoParseResult(StopTimelapseResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_CAMERA_LIVE_INFO -> {
                ProtoParseResult(SetCameraLiveInfoResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_CAMERA_LIVE_INFO -> {
                ProtoParseResult(GetLiveOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_CONNECTED_BT_PERIPHERALS -> {
                ProtoParseResult(GetConnectedBTPeripheralResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_MINI_THUMBNAIL -> {
                // 对应C++版本：CHECK_MSG(false, "PHONE_COMMAND_GET_MINI_THUMBNAIL response should be binary data");
                throw IllegalStateException("PHONE_COMMAND_GET_MINI_THUMBNAIL response should be binary data")
            }

            MessageCode.PHONE_COMMAND_TEST_SD_CARD_SPEED -> {
                ProtoParseResult(TestSDCardSpeedResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_WIFI_CONNECTION_INFO -> {
                ProtoParseResult(SetWifiConnectionInfoResp.ADAPTER.decode(buf), 0)

            }

            MessageCode.PHONE_COMMAND_GET_WIFI_CONNECTION_INFO -> {
                ProtoParseResult(GetWifiConnectionInfoResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_CHECK_AUTHORIZATION -> {
                ProtoParseResult(CheckAuthorizationResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_START_HDR_CAPTURE -> {
                ProtoParseResult(StartHdrResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_STOP_HDR_CAPTURE -> {
                ProtoParseResult(StopHdrResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_START_TIMESHIFT_CAPTURE -> {
                ProtoParseResult(StartTimelapseResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_STOP_TIMESHIFT_CAPTURE -> {
                ProtoParseResult(StopTimeShiftResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.FACTORY_COMMAND_BUTTON_STATUS_TEST -> {
                ProtoParseResult(GetCurrentButtonStatusResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_SYNC_CAPTURE_MODE -> {
                ProtoParseResult(GetSyncCaptureModeResp.ADAPTER.decode(buf), 0)

            }

            MessageCode.PHONE_COMMAND_SET_FLOWSTATE_ENABLE -> {
                ProtoParseResult(SetFlowstateEnableResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_FLOWSTATE_ENABLE -> {
                ProtoParseResult(GetFlowstateEnableResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_ACTIVE_SENSOR -> {
                ProtoParseResult(SetActiveSensorDeviceResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_ACTIVE_SENSOR -> {
                ProtoParseResult(GetActiveSensorDeviceResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_MULTI_PHOTOGRAPHY_OPTIONS -> {
                ProtoParseResult(SetMultiPhotographyOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_MULTI_PHOTOGRAPHY_OPTIONS -> {
                ProtoParseResult(GetMultiPhotographyOptionsResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_WIFI_MODE -> {
                ProtoParseResult(GetWifiModeResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_CONNECTED_WIFI_LIST -> {
                ProtoParseResult(GetWifiConnectListResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_WIFI_SCAN_LIST -> {
                ProtoParseResult(GetWifiScanInfoResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.FACTORY_COMMAND_CHARGINGBOX,
            MessageCode.FACTORY_COMMAND_CHARGINGBOX_BUTTON_TEST,
            MessageCode.FACTORY_COMMAND_CHARGINGBOX_HALL_TEST,
                -> {
                ProtoParseResult(ChargingBoxDataResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.FACTORY_COMMAND_GET_WHITEBLANCE_STATUS -> {
                ProtoParseResult(GetWhiteblanceStatus.ADAPTER.decode(buf), 0)
            }

            MessageCode.FACTORY_COMMAND_GET_SFR_STATUS -> {
                ProtoParseResult(GetSfrStatus.ADAPTER.decode(buf), 0)
            }

            MessageCode.FACTORY_COMMAND_GET_SFR_RESULT -> {
                ProtoParseResult(GetSfrResult.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_DARK_EIS_STATUS -> {
                ProtoParseResult(NotificationDarkEisStatus.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_QUICKREADER_GET_STATUS -> {
                ProtoParseResult(UsbCardStatus.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_CLOUD_STORAGE_UPLOAD_STATUS -> {
                ProtoParseResult(GetCloudStorageUploadStatusResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_CLOUD_STORAGE_BIND_STATUS -> {
                ProtoParseResult(GetCloudStorageBindStatusResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_DEL_WIFI_HISTORY_INFO -> {
                ProtoParseResult(DeleteWifiConnectListResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SYNCTIME_ACCURATE -> {
                ProtoParseResult(SyncTimeAccurateResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_NETWORK_CONFIG_ENABLE -> {
                ProtoParseResult(SetNetworkConfigEnableResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_CLOUD_STORAGE_UPLOAD_STATUS -> {
                ProtoParseResult(SetCloudStorageUploadStatusResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_SET_CLOUD_PROMPT_INTERVAL -> {
                ProtoParseResult(SetPromptIntervalResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_CALIBRATE_GYRO -> {
                ProtoParseResult(CalibrateGyroResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_PTZ_TRACK_STATE -> {
                ProtoParseResult(PtzTrackStateReport.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_INTERVALREC_CFG -> {
                ProtoParseResult(IntervalRecInfo.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_INTERVAL_RECORD_STATUS -> {
                ProtoParseResult(IntervalRecStatus.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_INTERVALREC_SCENE_CFG -> {
                ProtoParseResult(IntervalRecSceneInfoResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_INTERVALREC_FEEDBACK_CFG -> {
                ProtoParseResult(IntervalRecFeedback.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_TRANSLATE_CONFIG -> {
                ProtoParseResult(TranslateConfig.ADAPTER.decode(buf), 0)
            }
            MessageCode.PHONE_COMMAND_REQUEST_DATA,  /*-> {
                ProtoParseResult(DataTransPort.ADAPTER.decode(buf), 0)
            }*/

            // 以下命令响应内容为空，不需要解析
            MessageCode.PHONE_COMMAND__IFRAME_REQUEST,
            MessageCode.PHONE_COMMAND_SET_FAVORITE,
            MessageCode.PHONE_COMMAND_GET_FILE_PACKAGE_SYNC_FINISH,
            MessageCode.PHONE_COMMAND_GET_FILE_PACKAGE_FINISH,
            MessageCode.PHONE_COMMAND_SET_FILE_EXTRA,
            MessageCode.PHONE_COMMAND_ERASE_SD_CARD,
            MessageCode.PHONE_COMMAND_REBOOT_CAMERA,
            MessageCode.PHONE_COMMAND_SCAN_BT_PERIPHERAL,
            MessageCode.PHONE_COMMAND_CONNECT_TO_BT_PERIPHERAL,
            MessageCode.PHONE_COMMAND_DISCONNECT_BT_PERIPHERAL,
            MessageCode.PHONE_COMMAND_OPEN_CAMERA_WIFI,
            MessageCode.PHONE_COMMAND_CLOSE_CAMERA_WIFI,
            MessageCode.PHONE_COMMAND_RESET_WIFI,
            MessageCode.PHONE_COMMAND_SET_WIFI_SEIZE_ENABLE,
            MessageCode.PHONE_COMMAND_SET_ACCESS_CAMERA_FILE_STATE,
            MessageCode.PHONE_COMMAND_SET_APPID,
            MessageCode.PHONE_COMMAND_SET_SHUTDOWN,
            MessageCode.PHONE_COMMAND_CANCEL_AUTHORIZATION,
            MessageCode.PHONE_COMMAND_REQUEST_AUTHORIZATION,
            MessageCode.PHONE_COMMAND_CANCEL_REQUEST_AUTHORIZATION,
            MessageCode.PHONE_COMMAND_OPEN_OLED,
            MessageCode.PHONE_COMMAND_CLOSE_OLED,
            MessageCode.PHONE_COMMAND_NOTIFY_OTA_ERROR,
            MessageCode.PHONE_COMMAND_UPLOAD_GPS,
            MessageCode.PHONE_COMMAND_ADD_DOWNLOAD_LIST_RESULT_SYNC,
            MessageCode.PHONE_COMMAND_DOWNLOAD_INFO,
            MessageCode.PHONE_COMMAND_STOP_USBCARD_BACKUP,
            MessageCode.PHONE_COMMAND_PAUSE_RECORDING,
            MessageCode.PHONE_COMMAND_OPEN_IPERF,
            MessageCode.PHONE_COMMAND_CLOSE_IPERF,
            MessageCode.FACTORY_COMMAND_LED_TEST,
            MessageCode.FACTORY_COMMAND_MOTOR_TEST,
            MessageCode.FACTORY_COMMAND_MOTOR_TEST_STOP,
            MessageCode.FACTORY_COMMAND_SPEAKER_TEST,
            MessageCode.FACTORY_COMMAND_WIFI_STATUS_TEST,
            MessageCode.FACTORY_COMMAND_BLUETOOTH_STATUS_TEST,
            MessageCode.PHONE_COMMAND_SET_SYNC_CAPTURE_MODE,
            MessageCode.PHONE_COMMAND_SET_WIFI_STATE,
            MessageCode.PHONE_COMMAND_SET_CLOUD_TAB_SHOW,
            MessageCode.PHONE_COMMAND_PHONE_INFO,
            MessageCode.PHONE_COMMAND_SET_WIFI_MODE,
            MessageCode.PHONE_COMMAND_START_CAMERA_LIVE,
            MessageCode.PHONE_COMMAND_SET_CAMERA_LIVE_PREPARE,
            MessageCode.PHONE_COMMAND_STOP_CAMERA_LIVE,
            MessageCode.PHONE_COMMAND_STOP_TAKE_PICTURE,
            MessageCode.PHONE_COMMAND_GET_P3_STATIC_HDR_PARAMS,
            MessageCode.FACTORY_COMMAND_TP_JIUGONGGE_TEST,
            MessageCode.FACTORY_COMMAND_USB_LCD_TP_CLOSE_TEST,
            MessageCode.FACTORY_COMMAND_USB_SPEED_TEST,
            MessageCode.FACTORY_COMMAND_GET_AGEINGTEST_STATUS,
            MessageCode.FACTORY_COMMAND_DEVLINK_TEST,
            MessageCode.FACTORY_COMMAND_VIGNETTE_DATA_SAVE,
            MessageCode.FACTORY_COMMAND_BLC_DATA_SAVE,
            MessageCode.FACTORY_COMMAND_BPC_DATA_SAVE,
            MessageCode.FACTORY_COMMAND_GYROSCOPE_TEST,
            MessageCode.FACTORY_COMMAND_SCRIPT_REFRESH,
            MessageCode.FACTORY_COMMAND_SCRIPT_CMD_RUN,
            MessageCode.FACTORY_COMMAND_SCRIPT_JSON_UPLOAD,
            MessageCode.FACTORY_COMMAND_SCRIPT_CMD_UPLOAD,
            MessageCode.FACTORY_COMMAND_SET_AAA_FACTORYMODE,
            MessageCode.FACTORY_COMMAND_SET_AAA_NORMALMODE,
            MessageCode.FACTORY_COMMAND_LCD_COLOR_TEST,
            MessageCode.PHONE_COMMAND_SET_AVAILABLE_WIFI,
            MessageCode.PHONE_COMMAND_SET_CLOUD_STORAGE_BIND_STATUS,
            MessageCode.PHONE_COMMAND_CTRL_PRE_RECORD,
            MessageCode.PHONE_COMMAND_SET_STANDBY_MODE,
            MessageCode.PHONE_COMMAND_SET_KEY_TIME_POINT,
            MessageCode.PHONE_COMMAND_SWITCH_WIFI_CHANNEL,
            MessageCode.PHONE_COMMAND_GET_WIFI_INTERFERENCE_STATUS,
            MessageCode.PHONE_COMMAND_GIMBAL_CONTROL,
            MessageCode.PHONE_COMMAND_SET_MAIN_STORAGE,
            MessageCode.PHONE_COMMAND_FORMAT_STORAGE,
            MessageCode.PHONE_COMMAND_RESTORE_FACTORY_SETTINGS,
            MessageCode.PHONE_COMMAND_SINGLE_HOST_CTRL_INFO,
            MessageCode.PHONE_COMMAND_SET_INTERVALREC_CFG,
            MessageCode.PHONE_COMMAND_INTERVALREC_REC_START_STOP,
            MessageCode.PHONE_COMMAND_INTERVALREC_REC_CANCEL_CMD,
            MessageCode.PHONE_COMMAND_SET_INTERVALREC_FEEDBACK_CFG,
            MessageCode.PHONE_COMMAND_RECIPE_SHARE_STATUS,
            MessageCode.PHONE_COMMAND_CANCEL_TRACKING,
            MessageCode.PHONE_COMMAND_SET_PRESET_COMPOSITION,
            MessageCode.PHONE_COMMAND_OPEN_TRACKING_WITH_RECT,
            MessageCode.PHONE_COMMAND_NOTIFY_PHOTO_SETTING_PAGE,
            MessageCode.PHONE_COMMAND_FEATURE_BLUETOOTHMAC_BIND,
            MessageCode.PHONE_COMMAND_SET_AUDIO_STREAM,
            MessageCode.PHONE_COMMAND_AI_INTENT,
            MessageCode.PHONE_COMMAND_SET_USER_REGION,
            MessageCode.PHONE_COMMAND_SET_ASSISTANT_LANGUAGE,
            MessageCode.PHONE_COMMAND_DATA_TRANSPORT_FEEDBACK,
            MessageCode.PHONE_COMMAND_GIMBAL_CONTROL,
            MessageCode.PHONE_COMMAND_SET_MAIN_STORAGE,
            MessageCode.PHONE_COMMAND_CANCEL_ANGLE_FIXED,
                -> {
                // 响应内容为空，不需要解析
                ProtoParseResult(null, 0)
            }

            MessageCode.PHONE_COMMAND_ENCRYPT_CAPABILITY_QUERY -> {
                ProtoParseResult(EncryptCapabilityResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_ENCRYPT_KEY_EXCHANGE -> {
                ProtoParseResult(EncryptKeyExchangeResp.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_PTZ_TRACK_STATE -> {
                ProtoParseResult(PtzTrackStateReport.ADAPTER.decode(buf), 0)
            }

            MessageCode.PHONE_COMMAND_GET_PRESET_COMPOSITION -> {
                ProtoParseResult(GetPresetCompositionResp.ADAPTER.decode(buf), 0)
            }


            MessageCode.PHONE_COMMAND_GET_FIRMWARE_VERSIONS -> {
                ProtoParseResult(FirmwareVersions.ADAPTER.decode(buf), 0)
            }

            else -> {
                // 对应C++版本：CHECK_MSG(false, "response of message %d ?", messageCode);
                if (DEBUG) {
                    throw IllegalStateException("Unknown response message code: ${messageCode.value}")
                } else {
                    ProtoParseResult(null, Error.ERR_CAMERA_RESPONSE_ERROR)
                }
            }
        }
    } catch (e: Exception) {
        Log.t("parseProtoResponse", "parseProtoResponse messageCode $messageCode ${e.printStackTrace()} hex ${buf.toHexString().take(100)} ")
        if (DEBUG) {
            throw e
        } else {
            ProtoParseResult(null, Error.ERR_CAMERA_RESPONSE_ERROR)
        }
    }
}