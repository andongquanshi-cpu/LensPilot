package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.common.BleLog

class PtzGetEtdPowerOffEventRespMsg : PtzDataRespMessage() {
    var powerOffEventParamsArray: Array<PowerOffEventParams>? = null

    @OptIn(ExperimentalStdlibApi::class)
    override fun unpack(data: ByteArray?) {
        val list: MutableList<PowerOffEventParams> = ArrayList()
        try {
            val eventCountSignByteLength = 2
            if (data == null || data.size <= eventCountSignByteLength) {
                Log.d("unpack", "PtzGetEtdPowerOffEventRespMsg data error!!!!")
            } else {
                val eventCount = FmgByteUtils.uint16BytesToInt(data[0], data[1])
                if (eventCount > 0) {
                    val eventDataLength = (data.size - eventCountSignByteLength) / eventCount
                    var i = eventCountSignByteLength
                    while (i < data.size) {
                        val powerOffEventParams = PowerOffEventParams()
                        if (eventDataLength >= 2) {
                            powerOffEventParams.serial_number = FmgByteUtils.uint16BytesToInt(
                                data[i],
                                data[i + 1]
                            )
                        }
                        if (eventDataLength >= 4) {
                            powerOffEventParams.running_times = FmgByteUtils.uint16BytesToInt(
                                data[i + 2],
                                data[i + 3]
                            )
                        }
                        list.add(powerOffEventParams)
                        i += eventDataLength
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // 固件经常返回异常数据
            BleLog.e(
                "PtzGetEtdPowerOffEventRespMsg data invalid, throw exception! data = " + data?.toHexString(HexFormat.Default)
            )
        }
        powerOffEventParamsArray = list.toTypedArray<PowerOffEventParams>()
    }

    override fun toString(): String {
        return "powerOffEventParamsArray length = " + (if (powerOffEventParamsArray != null) powerOffEventParamsArray!!.size else 0)
    }

    override fun name(): String {
        return "CMD_GET_ETD - PowerOffEvent"
    }

    class PowerOffEventParams {
        var serial_number: Int = 0
        var running_times: Int = 0
    }
}
