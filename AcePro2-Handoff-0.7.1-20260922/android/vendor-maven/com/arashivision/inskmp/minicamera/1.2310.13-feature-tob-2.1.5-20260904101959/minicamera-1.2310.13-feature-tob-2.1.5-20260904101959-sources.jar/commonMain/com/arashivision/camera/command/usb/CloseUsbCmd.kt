package com.arashivision.camera.command.usb

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insusb.AppUsbServiceCore
import com.arashivision.onecamera.OneDriver

class CloseUsbCmd(private val mAppUsbService: AppUsbServiceCore?) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.close()
        mAppUsbService?.release()
        return null
    }
}
