package com.arashivision.onedriver.bean// ==================== 消息类型定义 ====================

/**
 * 消息类型枚举
 */
enum class MessageType(val value: Int) {
    START(1),
    USB_IO(2),
    ACTION_STATE_UPDATE(3),
    TUNNEL_RADABLE(4),
    SOCKET_IO(5),
    HEAT_BEAT(19),
    REQUEST(20),
    QUIT(21),
    WIFI_HEART_BEAT(22),
    BLE_ERROR(23),
    OBTAIN_ROTS_STATUS(24),
    REQUEST_TIMEOUT(25),
    WAKE_UP_AUTHORIZATION(26),
    STREAM(27)
}

/**
 * 消息数据结构
 */
data class Message(
    val type: MessageType,
    val data: Map<String, Any>? = null,
)
