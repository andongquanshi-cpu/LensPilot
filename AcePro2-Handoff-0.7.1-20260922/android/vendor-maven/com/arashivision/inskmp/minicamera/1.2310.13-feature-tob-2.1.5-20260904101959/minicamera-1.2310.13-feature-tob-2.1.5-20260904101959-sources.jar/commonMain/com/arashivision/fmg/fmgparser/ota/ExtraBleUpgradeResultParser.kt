package com.arashivision.fmg.fmgparser.ota

object ExtraBleUpgradeResultParser {
    fun parse(data: ByteArray?, parseCallback: IOtaParseCallback) {
        if (data == null || data.size < 3) {
            parseCallback.onParserError()
            return
        }

        if ((data[0] != 0x06.toByte()) || (data[1] != 0xFF.toByte())) {
            parseCallback.onParserError()
            return
        }

        if (data[2].toInt() == 0x00) {
            parseCallback.onUpdateSuccess()
        } else {
            parseCallback.onUpdateFail(data[2].toShort())
        }
    }

    interface IOtaParseCallback {
        fun onUpdateSuccess() //升级成功，蓝牙自动重启

        fun onUpdateFail(errorCode: Short) //升级失败,errorCode为错误码

        fun onParserError() //本地解析失败
    }
}
