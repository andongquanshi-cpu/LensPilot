package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.onecamera.OneDriver

class SetFmgTargetFollowCmd(
    private val mTfState: Int,
    private val mFollowParams: FmgTargetFollowParams?
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        if (mTfState == TF_NORMAL) {
            mFollowParams?.let { oneDrvier?.ptzStartOrUpdateTargetFollow(it) }
        } else if (mTfState == TF_LOST) {
            oneDrvier?.ptzLostTargetFollow()
        } else if (mTfState == TF_EXIT) {
            oneDrvier?.ptzExitTargetFollow()
        } else if (mTfState == TF_SPECULATE) {
            mFollowParams?.let { oneDrvier?.ptzSpeculateTargetFollow(it) }
        } else if (mTfState == TF_COMPOSITION) {
            oneDrvier?.ptzCompositionTargetFollow()
        }
        return null
    }

    companion object {
        const val TF_NORMAL: Int = 0
        const val TF_LOST: Int = 1
        const val TF_EXIT: Int = 2
        const val TF_SPECULATE: Int = 3
        const val TF_COMPOSITION: Int = 4
    }
}
