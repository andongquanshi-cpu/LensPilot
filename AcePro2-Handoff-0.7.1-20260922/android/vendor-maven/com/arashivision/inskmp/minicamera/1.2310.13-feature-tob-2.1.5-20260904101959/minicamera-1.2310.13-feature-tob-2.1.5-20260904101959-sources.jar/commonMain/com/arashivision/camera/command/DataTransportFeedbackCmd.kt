package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.DataTransportResult

class DataTransportFeedbackCmd(private val dataTransportResult: DataTransportResult) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.dataTransportFeedback(dataTransportResult)
    }
}
