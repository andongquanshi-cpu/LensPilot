package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class ResetCameraWifiCmd(private val countryChannel: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.resetCameraWifi(countryChannel)
    }
}
