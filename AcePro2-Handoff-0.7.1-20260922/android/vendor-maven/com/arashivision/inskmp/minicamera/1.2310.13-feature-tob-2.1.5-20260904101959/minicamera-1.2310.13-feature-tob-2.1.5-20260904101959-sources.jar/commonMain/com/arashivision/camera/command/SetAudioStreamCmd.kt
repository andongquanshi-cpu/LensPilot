package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.AudioStreamCtrl

internal class SetAudioStreamCmd(private val request: AudioStreamCtrl, private val timeoutMs: Int = -1) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.setAudioStream(request, timeoutMs)
    }
}
