package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzAppImuInfoReqMsg(floats: FloatArray) : PtzDataReqMessage() {
    var floats: FloatArray = FloatArray(4)

    init {
        this.floats = floats
    }

    override fun packData(): ByteArray? {
        val data = ByteArray(16)
        val wByteArray = FmgByteUtils.floatToUint32ByteArray(floats[0])
        val xByteArray = FmgByteUtils.floatToUint32ByteArray(floats[1])
        val yByteArray = FmgByteUtils.floatToUint32ByteArray(floats[2])
        val zByteArray = FmgByteUtils.floatToUint32ByteArray(floats[3])
        wByteArray.copyInto(data, 0, 0, wByteArray.size)
        xByteArray.copyInto(data, 4, 0, xByteArray.size)
        yByteArray.copyInto(data, 8, 0, yByteArray.size)
        zByteArray.copyInto(data, 12, 0, zByteArray.size)
        return data
    }

    override fun toString(): String {
        return floats.contentToString()
    }

    override fun name(): String {
        return "CMD_APP_IMU_INFO"
    }
}
