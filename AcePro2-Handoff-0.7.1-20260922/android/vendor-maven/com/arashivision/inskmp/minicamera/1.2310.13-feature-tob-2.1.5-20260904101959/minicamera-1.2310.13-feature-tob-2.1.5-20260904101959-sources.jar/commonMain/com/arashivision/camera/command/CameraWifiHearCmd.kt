package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class CameraWifiHearCmd(private val isDebug: Boolean) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setWifiHeartDebug(isDebug)
    }
}
