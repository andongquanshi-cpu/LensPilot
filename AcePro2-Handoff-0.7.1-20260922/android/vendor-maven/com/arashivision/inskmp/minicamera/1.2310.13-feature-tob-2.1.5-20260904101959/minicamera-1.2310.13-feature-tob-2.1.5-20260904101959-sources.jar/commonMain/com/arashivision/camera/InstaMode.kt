package com.arashivision.camera

enum class InstaMode {
    ONE,
    ONE2,
    ONEX,
    EVO,
    GO,
    AKIKO
}
