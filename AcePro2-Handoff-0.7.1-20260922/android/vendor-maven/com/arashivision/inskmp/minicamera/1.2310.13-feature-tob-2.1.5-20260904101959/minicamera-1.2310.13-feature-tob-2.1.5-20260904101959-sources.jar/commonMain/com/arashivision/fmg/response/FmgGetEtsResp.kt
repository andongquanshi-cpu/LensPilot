package com.arashivision.fmg.response

import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode

class FmgGetEtsResp(var requestID: Long) {
    var mode: PtzTrackSensitivityMode? = null

    override fun toString(): String {
        return "FmgGetEtsResp{" +
                "requestID=" + requestID +
                ", mode=" + mode +
                '}'
    }
}
