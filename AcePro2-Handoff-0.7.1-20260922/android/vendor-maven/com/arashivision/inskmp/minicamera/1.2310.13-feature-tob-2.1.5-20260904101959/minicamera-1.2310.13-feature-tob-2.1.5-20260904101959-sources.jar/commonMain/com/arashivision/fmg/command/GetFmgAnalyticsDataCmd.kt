package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * 获取 FMG 主板存储的埋点信息，与 FMG 蓝牙应用埋点信息区分开来{@link GetFmgBleAnalyticsDataCmd}
 */
class GetFmgAnalyticsDataCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzGetAnalyticsData()
    }
}
