package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetAppIdCmd(private val mAppId: String) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setAppId(mAppId)
    }
}
