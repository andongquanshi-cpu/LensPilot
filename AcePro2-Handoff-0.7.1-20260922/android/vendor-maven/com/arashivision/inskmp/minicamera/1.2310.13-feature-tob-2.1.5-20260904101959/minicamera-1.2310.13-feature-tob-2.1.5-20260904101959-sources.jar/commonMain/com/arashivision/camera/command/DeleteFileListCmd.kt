package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.DeleteFiles

/**
 * 删除文件列表
 */
class DeleteFileListCmd(private val mDeleteFiles: DeleteFiles) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.deleteFiles(mDeleteFiles)
    }
}
