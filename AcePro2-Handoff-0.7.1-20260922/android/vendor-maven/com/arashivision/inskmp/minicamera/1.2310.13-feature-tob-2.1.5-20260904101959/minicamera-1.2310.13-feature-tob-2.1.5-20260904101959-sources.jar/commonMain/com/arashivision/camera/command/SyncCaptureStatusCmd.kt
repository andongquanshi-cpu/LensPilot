package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SyncCaptureStatusCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.resumeInitialState()
    }
}
