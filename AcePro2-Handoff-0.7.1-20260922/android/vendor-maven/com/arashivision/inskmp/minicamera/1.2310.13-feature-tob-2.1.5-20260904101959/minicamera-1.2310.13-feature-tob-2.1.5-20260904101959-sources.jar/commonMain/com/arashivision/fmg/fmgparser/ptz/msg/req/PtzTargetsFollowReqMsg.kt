package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzTargetsFollowReqMsg(
    private val pos_x: Short,
    private val pos_y: Short,
    private val scale: Short,
    private val width: Short,
    private val height: Short,
    what: Byte,
    is_front: Boolean,
    private val app_millis: Long,
    private val packet_id: Int,
    composition: Boolean
) :
    PtzDataReqMessage() {
    private val is_obj = FmgByteUtils.combineBits(
        (if (composition) 1 else 0).toByte(),
        (if (is_front) 0 else 1).toByte(),
        what
    ).toShort()

    override fun packData(): ByteArray? {
        val data = ByteArray(14)
        val pos_xArray = FmgByteUtils.shortToInt16ByteArray(pos_x)
        val pos_yArray = FmgByteUtils.shortToInt16ByteArray(pos_y)
        pos_xArray.copyInto(data, 0, 0, pos_xArray.size)
        pos_yArray.copyInto(data, 2, 0, pos_yArray.size)
        data[4] = scale.toByte()
        data[5] = width.toByte()
        data[6] = height.toByte()
        data[7] = is_obj.toByte()
        val timeArray = FmgByteUtils.longToUint32ByteArray(app_millis)
        val packetIdArray = FmgByteUtils.intToUint16ByteArray(packet_id)
        timeArray.copyInto(data, 8, 0, timeArray.size)
        packetIdArray.copyInto(data, 12, 0, packetIdArray.size)
        return data
    }

    override fun toString(): String {
        return ("pos_x: " + pos_x + " pos_y: " + pos_y + " scale: " + scale + " width: " + width + " height: " + height + " is_obj: " + is_obj + " app_millis: " + app_millis
                + " packet_id: " + packet_id)
    }

    override fun name(): String {
        return "CMD_TARGETS_FOLLOW"
    }
}
