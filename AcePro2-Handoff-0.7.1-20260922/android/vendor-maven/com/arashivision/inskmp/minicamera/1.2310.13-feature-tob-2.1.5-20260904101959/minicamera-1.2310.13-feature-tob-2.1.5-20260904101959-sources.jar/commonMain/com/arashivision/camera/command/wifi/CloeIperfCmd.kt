package com.arashivision.camera.command.wifi

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * 关闭iperf
 */
class CloeIperfCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.closeIperf()
        return null
    }
}
