package com.arashivision.fmg.response

class FmgSetAiTrackerSettingsResp(var requestID: Long)
