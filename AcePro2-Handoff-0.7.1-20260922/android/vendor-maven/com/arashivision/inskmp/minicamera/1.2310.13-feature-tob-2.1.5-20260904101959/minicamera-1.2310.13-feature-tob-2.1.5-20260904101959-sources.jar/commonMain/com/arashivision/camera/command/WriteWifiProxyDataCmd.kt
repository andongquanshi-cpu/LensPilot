package com.arashivision.camera.command

import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.onecamera.OneDriver

class WriteWifiProxyDataCmd(private val mWifiProxyData: IWifiProxyData) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.writeRawData(mWifiProxyData.toBytes())
        return null
    }
}
