package com.arashivision.onedriver.bean

/**
 * 操作状态枚举
 */
enum class OpState(val value: Int) {
    STARTED(0),
    COMPLETE(1),
    FAILED(2),
    CANCELED(3),
    NOT_START(4)
}