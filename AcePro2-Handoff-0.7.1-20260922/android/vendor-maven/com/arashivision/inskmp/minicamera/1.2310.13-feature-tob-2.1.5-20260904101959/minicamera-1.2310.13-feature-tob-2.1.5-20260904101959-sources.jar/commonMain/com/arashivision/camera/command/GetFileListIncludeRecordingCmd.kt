package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetFileList

class GetFileListIncludeRecordingCmd(private val mGetFileList: GetFileList) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getFileListIncludeRecording(mGetFileList)
    }
}
