package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzDeviceInfoRespMsg : PtzDataRespMessage() {
    var sn: String = ""
    var type: String = ""
    var version: String = ""
    var reserved: ByteArray = ByteArray(4)

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 54) {
            Log.d("unpack", "error!!!!")
            return
        }
        sn = FmgByteUtils.byteArrayToStringOnUS_ASCII(data.copyOfRange(0, 14))
        type = FmgByteUtils.byteArrayToStringOnUS_ASCII(data.copyOfRange(14, 40))
        version = FmgByteUtils.byteArrayToStringOnUS_ASCII(data.copyOfRange(40, 50))
        reserved = data.copyOfRange(50, data.size)
    }

    override fun toString(): String {
        return "sn:$sn type:$type"
    }

    override fun name(): String {
        return "CMD_DEVICE_INFO"
    }
}
