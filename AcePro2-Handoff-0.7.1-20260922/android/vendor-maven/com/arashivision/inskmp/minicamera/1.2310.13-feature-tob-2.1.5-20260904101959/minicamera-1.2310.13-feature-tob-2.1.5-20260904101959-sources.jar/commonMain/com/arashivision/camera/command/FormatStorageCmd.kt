package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.FormatStorage

class FormatStorageCmd(private val formatStorage: FormatStorage) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.formatStorage(formatStorage)
    }
}
