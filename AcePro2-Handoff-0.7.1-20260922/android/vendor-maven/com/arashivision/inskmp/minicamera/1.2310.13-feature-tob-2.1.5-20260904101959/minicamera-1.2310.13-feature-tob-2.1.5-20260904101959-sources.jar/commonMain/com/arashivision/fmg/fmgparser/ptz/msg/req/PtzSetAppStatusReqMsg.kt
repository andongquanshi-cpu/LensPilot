package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzSetAppStatusReqMsg(
//uint8_t
    private val recording: Short, private val touch: Short
) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(4)
        data[0] = recording.toByte()
        data[1] = touch.toByte()
        return data
    }

    override fun toString(): String {
        return "index: $recording"
    }

    override fun name(): String {
        return "CMD_PANO_INDEX"
    }
}
