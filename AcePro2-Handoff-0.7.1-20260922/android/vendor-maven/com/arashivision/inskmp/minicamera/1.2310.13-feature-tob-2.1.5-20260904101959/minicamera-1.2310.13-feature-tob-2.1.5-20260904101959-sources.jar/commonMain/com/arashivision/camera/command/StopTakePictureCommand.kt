package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 拍照的command
 */
class StopTakePictureCommand : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.stopTakePicture()
    }
}
