package com.arashivision.camera

class RequestOptions {
    var timeoutMs: Int = -1
    var retryCount: Int = -1
}
