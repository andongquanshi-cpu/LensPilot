package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StopRecordCmd(
    private val mode: Int,
    private val mExtraData: ByteArray,
) :
    InstaCmdExe {


    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.stopRecordWithCameraStorage(mode, mExtraData)

        return 0
    }
}
