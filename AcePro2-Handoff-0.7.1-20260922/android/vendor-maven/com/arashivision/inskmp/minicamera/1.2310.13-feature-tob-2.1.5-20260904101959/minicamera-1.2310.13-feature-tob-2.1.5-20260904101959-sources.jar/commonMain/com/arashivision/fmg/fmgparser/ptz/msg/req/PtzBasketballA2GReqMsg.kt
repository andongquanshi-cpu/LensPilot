package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzBasketballA2GReqMsg(
    private val mode: Short,
    private val state: Short,
    private val transition: Byte
) :
    PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(3)
        data[0] = mode.toByte()
        data[1] = state.toByte()
        data[2] = transition
        return data
    }

    override fun toString(): String {
        return "PtzBasketballA2GReqMsg{" +
                "mode=" + mode +
                ", state=" + state +
                ", transition=" + transition +
                '}'
    }

    override fun name(): String {
        return "CMD_BASKETBALL_A2G"
    }
}
