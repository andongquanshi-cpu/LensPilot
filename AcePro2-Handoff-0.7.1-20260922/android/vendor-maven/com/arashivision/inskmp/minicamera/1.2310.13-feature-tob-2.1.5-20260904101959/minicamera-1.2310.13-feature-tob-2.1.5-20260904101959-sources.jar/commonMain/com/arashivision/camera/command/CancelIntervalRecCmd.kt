package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.IntervalRecCancel

internal class CancelIntervalRecCmd(private val intervalRecCancel: IntervalRecCancel) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.cancelIntervalRec(intervalRecCancel)
    }
}
