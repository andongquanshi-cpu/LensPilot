package com.arashivision.camera.command

import com.arashivision.camera.listener.ICameraConnectionListener
import com.arashivision.common.Log
import com.arashivision.inskmp.insusb.AppUsbServiceCore
import com.arashivision.inskmp.insusb.DeviceFilter
import com.arashivision.inskmp.insusb.UsbDeviceConnectionCore
import com.arashivision.inskmp.insusb.UsbObserver
import com.arashivision.inskmp.insusb.data.UsbDeviceCore
import com.arashivision.onecamera.OneDriver
import com.arashivision.onecamera.OneDriverInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.launch

class OpenUsbCmd(
    private val mUsbService: AppUsbServiceCore,
    cameraConnectionListener: ArrayList<ICameraConnectionListener>,
) :
    UsbObserver(), InstaCmdExe {
    private var mDriver: OneDriver? = null
    private val mCameraConnectionListener: ArrayList<ICameraConnectionListener>

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        val device = mUsbService.getDevice(mDeviceFilter)
        if (device == null) {
            Log.e(TAG, "no device found")
            return null
        }
        Log.d(TAG, "device opening : $device")
        mDriver = oneDrvier
        mUsbService.openDevice(device)
        return null
    }


    private val mDeviceFilter =
        object : DeviceFilter {
            override fun filter(device: UsbDeviceCore?): Boolean {
                return device?.let { isDeviceSupport(it) } == true
            }

        }


    init {
        mUsbService.addObserver(mDeviceFilter, this)
        mCameraConnectionListener = cameraConnectionListener
    }

    private fun isDeviceSupport(device: UsbDeviceCore): Boolean {
        var support = false
        val vendor = device.getVendorId()
        if (vendor == VENDOR_ID_ONE_UB || vendor == VENDOR_ID_ONE2_UB) support = true
        //        else if (device.getInterfaceCount() > 0 && device.getInterface(0).getInterfaceClass() == 14)
//            support = true;
        Log.i(
            TAG, "device support ? " + (if (support) "yes" else "no") +
                    ", vendor id: " + vendor + "(" + vendor + ")"
        )
        Log.i(TAG, "device.getInterfaceCount() " + (device.getInterfaceCount()))
        if (device.getInterfaceCount() > 0) {
//            Log.i(
//                TAG, "device.getInterface(0).getInterfaceClass(): "
//                        + device.getInterface(0).interfaceClass
//            )
        }
        return support
    }


    override fun onDeviceOpenComplete(
        device: UsbDeviceCore?,
        con: UsbDeviceConnectionCore?,
        filter: DeviceFilter?,
        err: Int,
    ) {
        super.onDeviceOpenComplete(device, con, filter, err)
        Log.d(TAG, "device open complete :$err")
        //设置相机参数
        if (err != 0) {
            for (listener in mCameraConnectionListener) {
                listener.onCameraError(err)
            }
            return
        }

        if (mDriver != null) {
            if (mUsbService.getUsbSysPath().isEmpty()) {
                Log.i(TAG, "error connect usb due path is empty")
                for (listener in mCameraConnectionListener) {
                    listener.onCameraError(OneDriverInfo.Notification.UsbError.ERR_USB)
                }
            } else {
                // 使用协程调用 suspend 函数
                CoroutineScope(Dispatchers.IO).launch {
                    val open = mDriver!!.open(mUsbService.getUsbSysPath())
                    if (open != 0) {
                        for (listener in mCameraConnectionListener) {
                            listener.onCameraError(OneDriverInfo.Notification.UsbError.ERR_USB)
                        }
                    } else {
                        for (listener in mCameraConnectionListener) {
                            listener.onCameraConnect()
                        }
                    }
                }

            }
        }
        //        if (mUsbConnect != null) {
//            mUsbConnect.getOptionsSync(null);
//            mUsbConnect.syncCaptureStatus();
//        }
    }

    companion object {
        private val TAG: String = OpenUsbCmd::class.simpleName.toString()


        private const val VENDOR_ID_ONE_UB = 0x4255
        private const val VENDOR_ID_ONE2_UB = 0x2e1a
    }
}
