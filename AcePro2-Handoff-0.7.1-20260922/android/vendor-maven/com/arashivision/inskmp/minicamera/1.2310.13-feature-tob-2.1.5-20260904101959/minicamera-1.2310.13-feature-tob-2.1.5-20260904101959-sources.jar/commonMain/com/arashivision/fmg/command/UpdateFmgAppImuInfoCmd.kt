package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

class UpdateFmgAppImuInfoCmd(private val floats: FloatArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzUpdateAppImuInfo(floats)
        return null
    }
}
