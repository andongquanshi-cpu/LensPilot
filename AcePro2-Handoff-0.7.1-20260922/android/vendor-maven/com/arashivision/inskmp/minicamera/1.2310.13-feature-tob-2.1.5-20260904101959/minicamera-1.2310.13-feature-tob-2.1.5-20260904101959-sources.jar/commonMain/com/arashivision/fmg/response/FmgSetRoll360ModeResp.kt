package com.arashivision.fmg.response

class FmgSetRoll360ModeResp(var requestID: Long)
