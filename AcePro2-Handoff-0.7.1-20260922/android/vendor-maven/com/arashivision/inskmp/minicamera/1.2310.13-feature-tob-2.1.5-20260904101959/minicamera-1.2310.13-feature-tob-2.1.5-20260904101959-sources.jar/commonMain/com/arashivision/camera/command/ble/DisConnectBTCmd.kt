package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver
import insta360.messages.DisconnectBTPeripheral

class DisConnectBTCmd(private val mDisconnectBTPeripheral: DisconnectBTPeripheral) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.disConnectBT(mDisconnectBTPeripheral)
    }
}
