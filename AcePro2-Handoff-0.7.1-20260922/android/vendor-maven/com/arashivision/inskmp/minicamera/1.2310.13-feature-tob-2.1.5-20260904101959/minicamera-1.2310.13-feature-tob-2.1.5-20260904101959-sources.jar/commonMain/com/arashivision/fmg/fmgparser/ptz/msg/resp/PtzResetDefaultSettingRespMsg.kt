package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzResetDefaultSettingRespMsg : PtzDataRespMessage() {
    var settingRespMsg: PtzSettingsReadRespMsg? = null
    var userAdjust: Int = 0
    var reserved: ByteArray = ByteArray(26)

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 40) {
            Log.d("unpack", "error!!!!")
            return
        }
        settingRespMsg = PtzSettingsReadRespMsg()
        settingRespMsg!!.unpack(data)
        userAdjust = FmgByteUtils.uint16BytesToInt(data[11], data[12])
        data.copyInto(reserved, 0, 14, 14 + reserved.size)
    }

    override fun toString(): String {
        return "PtzResetDefaultSettingRespMsg{" +
                "settingRespMsg=" + settingRespMsg +
                ", userAdjust=" + userAdjust +
                '}'
    }

    override fun name(): String {
        return "CMD_RESET_DEFAULT_SETTINGS"
    }
}
