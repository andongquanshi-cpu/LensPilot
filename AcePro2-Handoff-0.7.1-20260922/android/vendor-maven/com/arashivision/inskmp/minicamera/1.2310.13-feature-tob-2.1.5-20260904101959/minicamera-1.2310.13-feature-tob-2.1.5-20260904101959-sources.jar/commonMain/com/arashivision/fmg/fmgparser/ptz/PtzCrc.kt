package com.arashivision.fmg.fmgparser.ptz

class PtzCrc {
    //最后的输出值为小段模式
    var crcValue: Int = 0
        private set

    fun update_checksum(data: Int) {
        var data = data
        data = data and 0xff //cast because we want an unsigned type
        var tmp = data xor (crcValue and 0xff)
        tmp = tmp xor ((tmp shl 4) and 0xff)
        crcValue =
            ((crcValue shr 8) and 0xff) xor (tmp shl 8) xor (tmp shl 3) xor ((tmp shr 4) and 0xf)
    }

    fun start_checksum() {
        crcValue = CRC_INIT_VALUE
    }

    init {
        start_checksum()
    }

    companion object {
        //ptz特有crc，仿mavlink
        private const val CRC_INIT_VALUE = 0xffff
    }
}
