package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.onecamera.OneDriver

class SetFmgAngleSeqCmd(private val setAngleSeqBeanList: List<FmgSetAngleSeqBean>) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetAngleSeq(setAngleSeqBeanList)
    }
}
