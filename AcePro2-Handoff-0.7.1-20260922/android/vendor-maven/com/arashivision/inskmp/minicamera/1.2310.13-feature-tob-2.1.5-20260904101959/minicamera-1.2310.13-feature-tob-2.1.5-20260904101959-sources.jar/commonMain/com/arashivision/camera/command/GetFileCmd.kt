package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetFile

class GetFileCmd(private val mGetFile: GetFile) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getFile(mGetFile)
    }
}
