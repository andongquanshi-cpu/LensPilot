// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/Message.kt
package com.arashivision.onedriver.packet

/**
 * 消息类 - 对应C++中的Message类
 * 优化：简化构造函数，使用默认参数减少重载
 */
data class Message(
    val messageMethod: Int,
    val messageContentType: MessageContentType,
    val messageDirection: MessageDirection,
    val messageId: Long,
    val messageContent: ByteArray = ByteArray(0),
) {
    val messageContentSize: Int get() = messageContent?.size ?: 0

    /**
     * 从protobuf消息创建Message
     */
    constructor(
        messageMethod: Int,
        messageContentType: MessageContentType,
        messageDirection: MessageDirection,
        messageId: Long,
        protobufMessage: com.squareup.wire.Message<*, *>, // 这里应该是具体的protobuf类型
    ) : this(
        messageMethod,
        messageContentType,
        messageDirection,
        messageId,
        serializeProtobuf(protobufMessage)
    )

    companion object {
        private fun serializeProtobuf(message: com.squareup.wire.Message<*, *>): ByteArray {
            // 这里需要根据实际的protobuf类型进行序列化
            // 暂时返回空缓冲区，实际使用时需要实现
            return message.encode()
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true

        other as Message

        if (messageMethod != other.messageMethod) return false
        if (messageContentType != other.messageContentType) return false
        if (messageDirection != other.messageDirection) return false
        if (messageId != other.messageId) return false
        if (!messageContent.contentEquals(other.messageContent)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = messageMethod
        result = 31 * result + messageContentType.hashCode()
        result = 31 * result + messageDirection.hashCode()
        result = 31 * result + messageId.hashCode()
        result = 31 * result + messageContent.hashCode()
        return result
    }
}