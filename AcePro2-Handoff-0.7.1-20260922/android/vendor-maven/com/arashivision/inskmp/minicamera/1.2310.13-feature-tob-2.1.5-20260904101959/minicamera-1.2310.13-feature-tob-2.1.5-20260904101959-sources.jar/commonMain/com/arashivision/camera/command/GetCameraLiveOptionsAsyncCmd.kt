package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.common.BleLog
import com.arashivision.onecamera.OneDriver
import insta360.messages.LiveBroadCastOptionType

class GetCameraLiveOptionsAsyncCmd(
    private val mOptionList: List<LiveBroadCastOptionType>,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        BleLog.i(
            "syncCameraLiveOptions, mOptionList: " + (mOptionList?.toTypedArray()
                ?.contentToString() ?: "null")
        )
        return oneDrvier?.getCameraLiveOptionsAsync(mOptionList, mRequestOptions)
    }
}
