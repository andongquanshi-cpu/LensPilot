package com.arashivision.fmg.response.model

import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode

class FmgDeviceStatus {
    var batteryLevel: Int = 0 //电量信息，0-100
    var ptzMode: PtzMode? = null //云台模式，0：auto模式，1：跟随模式，2：Pitch锁定模式，3：FPV模式，4：锁定模式
    var isLimitedYaw: Boolean = false //云台yaw轴是否达到限位
    var isStalled: Boolean = false //云台是否堵转保护
    var isCharging: Boolean = false //是否正在充电
    var hasPayload: Boolean = false //负载有无
    var isOverTemp: Boolean = false //是否过温
    var imbalance: Boolean = false //true 平衡/ false 不平衡
    var sportMode: Boolean = false //true 运动模式/ false 非运动模式
    var sleep: Boolean = false //true 休眠中
    var isLowTemp: Boolean = false //是否低温
    var isLimitedPitch: Boolean = false //云台pitch轴是否达到限位
    var cfMode: Boolean = false //侧翻模式
    var hvMode: PtzHvMode? = null
    var motionType: Boolean = false
    var aiOnline: Boolean = false

    override fun equals(o: Any?): Boolean {
        if (this === o) return true
        val that = o as FmgDeviceStatus
        return batteryLevel == that.batteryLevel && ptzMode == that.ptzMode && isLimitedYaw == that.isLimitedYaw && isStalled == that.isStalled && isCharging == that.isCharging && hasPayload == that.hasPayload && isOverTemp == that.isOverTemp && imbalance == that.imbalance && sportMode == that.sportMode && sleep == that.sleep && isLowTemp == that.isLowTemp && isLimitedPitch == that.isLimitedPitch && hvMode == that.hvMode && motionType == that.motionType && cfMode == that.cfMode && aiOnline == that.aiOnline
    }

    override fun toString(): String {
        return "FmgDeviceStatus{" +
                "batteryLevel=" + batteryLevel +
                ", ptzMode=" + ptzMode +
                ", isLimitedYaw=" + isLimitedYaw +
                ", isStalled=" + isStalled +
                ", isCharging=" + isCharging +
                ", hasPayload=" + hasPayload +
                ", isOverTemp=" + isOverTemp +
                ", imbalance=" + imbalance +
                ", sportMode=" + sportMode +
                ", sleep=" + sleep +
                ", iwLowTemp=" + isLowTemp +
                ", isLimitedPitch=" + isLimitedPitch +
                ", hvMode=" + hvMode +
                ", cfMode=" + cfMode +
                ", motionType=" + motionType +
                ", aiOnline=" + aiOnline +
                '}'
    }
}
