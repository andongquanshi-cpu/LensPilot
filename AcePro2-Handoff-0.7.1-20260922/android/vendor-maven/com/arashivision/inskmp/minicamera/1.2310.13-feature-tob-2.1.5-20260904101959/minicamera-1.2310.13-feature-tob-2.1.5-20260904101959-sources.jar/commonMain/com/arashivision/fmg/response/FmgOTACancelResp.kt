package com.arashivision.fmg.response

class FmgOTACancelResp(var requestID: Long)
