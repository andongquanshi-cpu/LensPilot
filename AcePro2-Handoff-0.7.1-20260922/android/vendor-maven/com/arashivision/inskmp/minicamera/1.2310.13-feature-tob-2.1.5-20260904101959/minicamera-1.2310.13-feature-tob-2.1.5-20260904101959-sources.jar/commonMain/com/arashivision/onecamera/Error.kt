package com.arashivision.onecamera

object Error {
    const val ERR_NONE: Int = 0
    const val ERR_CAMERA_BASE: Int = -400
    const val ERR_NOCAMERA: Int = ERR_CAMERA_BASE - 1
    const val ERR_OPENDEVICE: Int = ERR_CAMERA_BASE - 2
    const val ERR_INITCAMERA: Int = ERR_CAMERA_BASE - 3
    const val ERR_ENCODER: Int = ERR_CAMERA_BASE - 4
    const val ERR_PLAYER: Int = ERR_CAMERA_BASE - 5
    const val ERR_PERMISSION: Int = ERR_CAMERA_BASE - 6
    const val ERR_CAMERA_STREAM_READ_ERROR: Int = ERR_CAMERA_BASE - 7
    const val ERR_CAMERA_STREAM_READ_TIMEOUT: Int = ERR_CAMERA_BASE - 8
    const val ERR_AUDIO_RECORD: Int = ERR_CAMERA_BASE - 9
    const val ERR_STREAM_NO_CSD: Int = ERR_CAMERA_BASE - 10
    const val ERR_STREAM_NO_AUDIO_CSD: Int = ERR_CAMERA_BASE - 11

    const val ERR_INVALID_OPERATION: Int = ERR_CAMERA_BASE - 20

    const val ERR_IO: Int = ERR_CAMERA_BASE - 30
    const val ERR_NOT_SUPPORT: Int = ERR_CAMERA_BASE - 31

    const val ERR_PIPELINE_UNKNOWN: Int = ERR_CAMERA_BASE - 40

    const val ERR_INITWIFI: Int = ERR_CAMERA_BASE - 50

    const val ERR_CAMERA_RESPONSE_ERROR: Int = ERR_CAMERA_BASE - 100
    const val ERR_PARSE_PROTO_RESPONSE_FAILED: Int = ERR_CAMERA_BASE - 101
    const val ERR_CAMERA_RESPONSE_TIMEOUT: Int = ERR_CAMERA_BASE - 102
    const val ERR_CAMERA_BUSY: Int = ERR_CAMERA_BASE - 103
}
