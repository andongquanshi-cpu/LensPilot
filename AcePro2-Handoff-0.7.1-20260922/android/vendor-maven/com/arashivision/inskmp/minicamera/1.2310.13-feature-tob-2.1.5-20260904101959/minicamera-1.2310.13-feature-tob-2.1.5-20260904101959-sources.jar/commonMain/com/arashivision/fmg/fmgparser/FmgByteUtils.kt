package com.arashivision.fmg.fmgparser

import com.arashivision.common.File
import com.arashivision.common.Log

object FmgByteUtils {
    private const val TAG = "ByteUtils"

    //调试用输出,格式为[a5 f3 00 fe 12 3f cf b1 52 f0 d7 c9 f0 f7 51 f4 c1 ab ea 0a d0 cb 6f b0 fa 0a 3c ca 11 65 30 32 2b 9a 00 e6 1c]
    @OptIn(ExperimentalStdlibApi::class)
    fun bytes2hexDebug(bytes: ByteArray): String {
        val sb = StringBuilder()
        var tmp: String
        sb.append("[")
        for (b in bytes) {
            // 将每个字节与0xFF进行与运算，然后转化为10进制，然后借助于Integer再转化为16进制
            tmp = (0xFF and b.toInt()).toString(16)
            if (tmp.length == 1) {
                tmp = "0$tmp" //只有一位的前面补个0
            }
            sb.append(tmp).append(" ") //每个字节用空格断开
        }
        sb.deleteRange(sb.length - 1, sb.length) //删除最后一个字节后面对于的空格
        sb.append("]")
        return sb.toString()
    }

    //byte数组转string,格式为a5f300fe123fcfb152f0d7c9f0f751f4c1abea0ad0cb6fb0fa0a3cca116530322b9a00e61c
    fun bytes2hex(bytes: ByteArray): String {
        val sb = StringBuilder()
        var tmp: String
        for (b in bytes) {
            // 将每个字节与0xFF进行与运算，然后转化为10进制，然后借助于Integer再转化为16进制
            tmp = (0xFF and b.toInt()).toString(16)
            if (tmp.length == 1) {
                tmp = "0$tmp" //只有一位的前面补个0
            }
            sb.append(tmp)
        }
        return sb.toString()
    }

    //ota特有crc协议
    fun otaCrc16(data: ByteArray): ByteArray {
        val len = data.size
        val poly = intArrayOf(0, 0xa001)
        var crc = 0xffff
        var i: Int
        var j = len
        while (j > 0) {
            var ds = (data[len - j].toInt() and 0xff).toShort()
            i = 0
            while (i < 8) {
                crc = (crc shr 1) xor poly[(crc xor ds.toInt()) and 1]
                ds = (ds.toInt() shr 1).toShort()
                i++
            }
            j--
        }
        return intToUint16ByteArray(crc)
    }

    //short类型转byte数组，小端模式
    fun shortToInt16ByteArray(value: Short): ByteArray {
        val data = ByteArray(2)
        data[0] = (value.toInt() and 0xFF).toByte()
        data[1] = ((value.toInt() shr 8) and 0xFF).toByte()
        return data
    }

    //int类型转byte数组，小端模式,当int为65536时，对应为0000
    fun intToUint16ByteArray(value: Int): ByteArray {
        val data = ByteArray(2)
        data[0] = (value and 0xFF).toByte()
        data[1] = ((value shr 8) and 0xFF).toByte()
        return data
    }

    //long类型转byte数组，小端模式，当long为4294967296时，对应为0000
    fun longToUint32ByteArray(value: Long): ByteArray {
        val data = ByteArray(4)
        data[0] = (value and 0xFFL).toByte()
        data[1] = ((value shr 8) and 0xFFL).toByte()
        data[2] = ((value shr 16) and 0xFFL).toByte()
        data[3] = ((value shr 24) and 0xFFL).toByte()
        return data
    }

    //长度为2的byte数组转short类型，有负数，对应C中的int16_t
    fun int16ByteArrayToShort(bytes: ByteArray): Short {
        if (bytes.size < 2) {
            Log.d(TAG, "Waring,byteArray length error")
            return 0
        }
        var value: Short = 0
        value = (value + (bytes[1].toInt() and 0x000000FF) shl 8).toShort()
        value = (value + (bytes[0].toInt() and 0x000000FF)).toShort()
        return value
    }

    fun int16BytesToShort(a: Byte, b: Byte): Short {
        val bytes = ByteArray(2)
        bytes[0] = a
        bytes[1] = b
        return int16ByteArrayToShort(bytes)
    }

    //长度为2的byte数组转int类型，无负数，对应C中的uint16_t
    fun uint16ByteArrayToInt(bytes: ByteArray): Int {
        if (bytes.size < 2) {
            Log.d(TAG, "Waring,byteArray length error")
            return 0
        }
        var value = 0
        value = value + ((bytes[1].toInt() and 0x000000FF) shl 8)
        value = value + (bytes[0].toInt() and 0x000000FF)
        return value
    }

    fun uint16BytesToInt(a: Byte, b: Byte): Int {
        val bytes = ByteArray(2)
        bytes[0] = a
        bytes[1] = b
        return uint16ByteArrayToInt(bytes)
    }

    //长度为4的byte数组转long类型，无负数,对应C中的uint32_t
    fun uint32ByteArrayToLong(bytes: ByteArray): Long {
        if (bytes.size < 4) {
            Log.d(TAG, "Waring,byteArray length error")
            return 0
        }
        var value: Long = 0
        value = value + ((bytes[3].toInt() and 0x000000FF) shl 24)
        value = value + ((bytes[2].toInt() and 0x000000FF) shl 16)
        value = value + ((bytes[1].toInt() and 0x000000FF) shl 8)
        value = value + (bytes[0].toInt() and 0x000000FF)
        return value
    }

    fun uint32BytesToLong(a: Byte, b: Byte, c: Byte, d: Byte): Long {
        val bytes = ByteArray(4)
        bytes[0] = a
        bytes[1] = b
        bytes[2] = c
        bytes[3] = d
        return uint32ByteArrayToLong(bytes)
    }

    //长度为8的byte数组转long类型，有负数！！，对于c中的uint64_t,当值c中uint64_t大于9223372036854775807时，该值变成负数！！
    fun uint64ByteArrayToLong(bytes: ByteArray): Long {
        if (bytes.size < 8) {
            Log.d(TAG, "Waring,byteArray length error")
            return 0
        }
        Log.i(TAG, "Waring , The conversion may have numeric errors!!")
        var value: Long = 0
        value = value + ((bytes[7].toLong() and 0x000000FFL) shl 56)
        value = value + ((bytes[6].toLong() and 0x000000FFL) shl 48)
        value = value + ((bytes[5].toLong() and 0x000000FFL) shl 40)
        value = value + ((bytes[4].toLong() and 0x000000FFL) shl 32)
        value = value + ((bytes[3].toLong() and 0x000000FFL) shl 24)
        value = value + ((bytes[2].toLong() and 0x000000FFL) shl 16)
        value = value + ((bytes[1].toLong() and 0x000000FFL) shl 8)
        value = value + (bytes[0].toLong() and 0x000000FFL)
        return value
    }

    //long类型转byte数组，对应c的uint64,传入值为-1时，bytes为FF,FF,FF,FF,FF,FF,FF,FF!!!
    fun longToUint64ByteArray(value: Long): ByteArray {
        val data = ByteArray(8)
        data[0] = (value and 0xFFL).toByte()
        data[1] = ((value shr 8) and 0xFFL).toByte()
        data[2] = ((value shr 16) and 0xFFL).toByte()
        data[3] = ((value shr 24) and 0xFFL).toByte()
        data[4] = ((value shr 32) and 0xFFL).toByte()
        data[5] = ((value shr 40) and 0xFFL).toByte()
        data[6] = ((value shr 48) and 0xFFL).toByte()
        data[7] = ((value shr 56) and 0xFFL).toByte()
        return data
    }

    fun floatToUint32ByteArray(value: Float): ByteArray {
        return longToUint32ByteArray(value.toBits().toLong())
    }

    fun uint32ByteArrayToFloat(a: ByteArray): Float {
        return Float.fromBits(uint32ByteArrayToLong(a).toInt())
    }

    fun doubleToUint64ByteArray(value: Double): ByteArray {
        return longToUint64ByteArray(value.toBits())
    }

    fun uint64ByteArrayToDouble(a: ByteArray): Double {
        return Double.fromBits(uint64ByteArrayToLong(a))
    }

    fun byteToShort(a: Byte): Short {
        return (a.toInt() and 0xFF).toShort()
    }

    //byte数组转char数组，默认为US_ASCII
    fun byteArrayToCharArray(
        bytes: ByteArray,
        charset: String = "US-ASCII",
    ): CharArray {
        // KMP兼容实现：直接使用String的编码转换
        val string = bytes.decodeToString()
        return string.toCharArray()
    }

    //char数组转byte数组,默认为US_ASCII
    fun charArrayToByteArray(
        chars: CharArray,
        charset: String = "US-ASCII",
    ): ByteArray {
        // KMP兼容实现：直接使用String的编码转换
        val string = chars.concatToString()
        return string.encodeToByteArray()
    }

    fun formatBytes(bytes: ByteArray): ByteArray {
        for (i in bytes.indices) {
            if (bytes[i].toInt() == 0) {
                return bytes.copyOfRange(0, i)
            }
        }
        return bytes
    }

    fun byteArrayToStringOnUS_ASCII(bytes: ByteArray): String {
        val formatByte = formatBytes(bytes)
        // KMP兼容实现：直接使用decodeToString
        return formatByte.decodeToString()
    }

    fun StringToByteArrayOnUS_ASCII(string: String, length: Int): ByteArray {
        if (string.length > length) {
            return ByteArray(0) //传入的字符串长度大于要生成的byte数组长度
        }
        val bytes = ByteArray(length)
        val originalBytes = string.encodeToByteArray()
        originalBytes.copyInto(bytes, 0, 0, originalBytes.size)
        return bytes
    }

    fun byteToBinary(value: Byte): String {
        var result = ""
        var a = value
        for (i in 0..7) {
            val c = a
            a = (a.toInt() shr 1).toByte() //每移一位如同将10进制数除以2并去掉余数。
            a = (a.toInt() shl 1).toByte()
            result = if (a == c) {
                "0$result"
            } else {
                "1$result"
            }
            a = (a.toInt() shr 1).toByte()
        }
        return result
    }


    const val FIRMWARE_INFO_SIZE: Int = 48

    @OptIn(ExperimentalStdlibApi::class)
    fun splitFirmware(firmware: ByteArray): ArrayList<ByteArray>? {
        val len = firmware.size
        if (len <= FIRMWARE_INFO_SIZE) { //长度异常，太短
            return null
        }

        //获取固件信息
        val fileInfo = ByteArray(FIRMWARE_INFO_SIZE)
        firmware.copyInto(
            destination = fileInfo,
            startIndex = len - FIRMWARE_INFO_SIZE,
            endIndex = len
        )
        Log.e("teststsg","asdas ${fileInfo.toHexString()}")
        //读取三段固件内容，[FMG1 / FMG Plus]有两段固件和蓝牙，[FMG 2]有三段固件和yaw轴电机和蓝牙
        val firmwareOffset1 = uint32BytesToLong(
            fileInfo[0],
            fileInfo[1], fileInfo[2], fileInfo[3]
        )
        val firmwareLength1 = uint32BytesToLong(
            fileInfo[4],
            fileInfo[5], fileInfo[6], fileInfo[7]
        )
        val firmwareOffset2 = uint32BytesToLong(
            fileInfo[8],
            fileInfo[9], fileInfo[10], fileInfo[11]
        )
        val firmwareLength2 = uint32BytesToLong(
            fileInfo[12],
            fileInfo[13], fileInfo[14], fileInfo[15]
        )
        val firmwareOffset3 = uint32BytesToLong(
            fileInfo[16],
            fileInfo[17], fileInfo[18], fileInfo[19]
        )
        val firmwareLength3 = uint32BytesToLong(
            fileInfo[20],
            fileInfo[21], fileInfo[22], fileInfo[23]
        )
        Log.i(
            TAG,
            "firmwareOffset1: $firmwareOffset1 firmwareLength1: $firmwareLength1 firmwareOffset2: $firmwareOffset2 firmwareLength2: $firmwareLength2 firmwareOffset3: $firmwareOffset3 firmwareLength3: $firmwareLength3"
        )
        val md5 = ByteArray(16) //整个文件除最后16个字节以外的md5
        fileInfo.copyInto(
            destination = md5,
            startIndex = 32,
            endIndex = 32 + md5.size
        )
        //固件长度为占用16个字节，保留16个字节，故md5从第33位开始
        Log.i(TAG, "FirmwareMd5:" + bytes2hexDebug(md5))

        val sumLength =
            (firmwareLength1 + firmwareLength2 + firmwareLength3 + FIRMWARE_INFO_SIZE).toInt() //应固件信息计算总产长度
        Log.i(TAG, "sumLength:$sumLength len: $len")
        if (sumLength != len) { //用收到的固件总长度与固件信息中记录的总长度判断
            return null
        }

        val firmware1 = ByteArray(firmwareLength1.toInt())
        val firmware2 = ByteArray(firmwareLength2.toInt())
        val firmware3 = ByteArray(firmwareLength3.toInt())
        // 截取云台固件 + 云台固件信息
        firmware.copyInto(
            firmware1,
            startIndex = firmwareOffset1.toInt(),
            endIndex = firmwareOffset1.toInt() + firmware1.size
        )

        // 截取 1代蓝牙固件 2代Yaw固件
        firmware.copyInto(
            firmware2,
            startIndex = firmwareOffset2.toInt(),
            endIndex = firmwareOffset2.toInt() + firmware2.size
        )

        // 截取 2代蓝牙固件
        firmware.copyInto(
            firmware3,
            startIndex = firmwareOffset3.toInt(),
            endIndex = firmwareOffset3.toInt() + firmware3.size
        )

        val firmwareList = ArrayList<ByteArray>()
        if (firmware1.size > 0) {
            firmwareList.add(firmware1)
        }
        if (firmware2.size > 0) {
            firmwareList.add(firmware2)
        }
        if (firmware3.size > 0) {
            firmwareList.add(firmware3)
        }
        if (firmwareList.isEmpty()) {
            return null
        }
        return firmwareList
    }

    fun height4AddLow4(height4: Byte, low4: Byte): Byte {
        return ((height4.toInt() shl 4) + low4).toByte()
    }

    fun combineBits(high2: Byte, mid2: Byte, low4: Byte): Byte {
        return ((high2.toInt() shl 6) + (mid2.toInt() shl 4) + low4).toByte()
    }

    fun readBytesFromFile(file: File?): ByteArray? {
        return file?.read()
    }
}
