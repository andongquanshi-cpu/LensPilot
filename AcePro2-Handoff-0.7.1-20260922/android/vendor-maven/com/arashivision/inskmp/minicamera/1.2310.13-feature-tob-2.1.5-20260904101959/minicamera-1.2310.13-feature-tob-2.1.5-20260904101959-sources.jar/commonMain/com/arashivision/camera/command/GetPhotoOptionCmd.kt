package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.PhotographyOptionType

class GetPhotoOptionCmd(private val mFunMode: Int, private val mOptions: List<PhotographyOptionType>) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getPhotographyOptions(mFunMode, mOptions)
    }
}
