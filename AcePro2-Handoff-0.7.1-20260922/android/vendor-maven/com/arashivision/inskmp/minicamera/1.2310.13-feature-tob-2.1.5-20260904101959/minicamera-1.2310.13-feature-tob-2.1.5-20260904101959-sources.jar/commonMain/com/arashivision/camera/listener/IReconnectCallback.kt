package com.arashivision.camera.listener

interface IReconnectCallback {
    fun needReconnectSocket(): Boolean

    fun onReconnectSocketSuccess()
}
