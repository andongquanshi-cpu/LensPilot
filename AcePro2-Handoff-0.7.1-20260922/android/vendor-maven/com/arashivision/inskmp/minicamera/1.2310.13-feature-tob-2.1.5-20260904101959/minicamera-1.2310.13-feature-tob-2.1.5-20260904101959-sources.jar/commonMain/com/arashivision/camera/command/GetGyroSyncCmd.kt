package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetGyro

/**
 * 异步获取陀螺仪数据
 */
class GetGyroSyncCmd(private val mGetGyro: GetGyro) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.getGyroAsync(mGetGyro)
        return null
    }
}
