package com.arashivision.fmg.response

class FmgGetUUIDResp(var requestID: Long, var uuid: String?)
