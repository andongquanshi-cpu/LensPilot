package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.TakePicture

class CaptureWithoutStorageCmd(private val mTakePicture: TakePicture) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.captureStillImageWithouStorage(mTakePicture)

        return 0
    }
}
