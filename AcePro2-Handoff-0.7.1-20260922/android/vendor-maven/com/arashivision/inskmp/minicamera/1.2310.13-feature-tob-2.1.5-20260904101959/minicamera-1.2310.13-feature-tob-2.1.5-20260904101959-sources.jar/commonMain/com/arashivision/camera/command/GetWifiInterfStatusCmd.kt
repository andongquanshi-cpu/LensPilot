package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class GetWifiInterfStatusCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.wifiInterfStatus
    }
}
