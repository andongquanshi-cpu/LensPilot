package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class RestoreFactorySettingsCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.restoreFactorySettings()
    }
}
