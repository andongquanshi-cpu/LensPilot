package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.onecamera.OneDriver

class SetFmgRunControlCmd(
    private val state: PtzGrfState,
    private val yaw: Float,
    private val pitch: Float,
    private val roll: Float
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetRunControl(state, yaw, pitch, roll)
    }
}
