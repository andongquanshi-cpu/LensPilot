package com.arashivision.onedriver.usb

import com.arashivision.common.Log
import com.arashivision.inskmp.insusb.UsbManagerCore
import com.arashivision.inskmp.insusb.callback.UsbCallbackCore
import com.arashivision.inskmp.insusb.data.UsbStateCore
import com.arashivision.onedriver.io.SocketIO.Companion.ERR_DIRTY_DATA
import com.arashivision.onedriver.packet.Packet
import com.arashivision.onedriver.packet.PacketDemuxer
import com.arashivision.onedriver.packet.PacketType

/**
 * 对应C++中的OneUsb类
 * 负责处理相机与设备之间的数据通信
 */
class OneUsb {
    companion object {
        const val WHAT_IN_PACKET = 0
        const val WHAT_SYNCED = 1
        const val WHAT_ERROR = 2
        const val WHAT_TEST_USB = 3

        // BLE+SPP 共存:SPP 通道收到 BLE 的同步包/心跳包,需转发给 BLE 完成握手
        const val WHAT_SYNC_SPP_FORWARD = 4

        private const val TAG = "OneUsb"

        // 同步开始字节
        private val kSyncStartBytes = byteArrayOf(
            's'.code.toByte(),
            'y'.code.toByte(),
            'N'.code.toByte(),
            'c'.code.toByte(),
            'S'.code.toByte(),
            't'.code.toByte(),
            'a'.code.toByte(),
            'I'.code.toByte(),
            'n'.code.toByte(),
            's'.code.toByte()
        )

        // 同步结束字节
        private val kSyncEndBytes = byteArrayOf(
            's'.code.toByte(),
            'y'.code.toByte(),
            'N'.code.toByte(),
            'c'.code.toByte(),
            'e'.code.toByte(),
            'N'.code.toByte(),
            'd'.code.toByte(),
            'i'.code.toByte(),
            'n'.code.toByte(),
            'S'.code.toByte()
        )

        // 心跳包数据
        private val kHearBeatData = byteArrayOf(0x07, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00)
    }

    // 状态变量
    private var mSynced = false
    private var mError = 0

    // 同步相关
    private val mBytesToProbeSync = mutableListOf<Byte>()

    // 数据包处理
    private val mPacketDemuxer = PacketDemuxer()

    // 消息通知
    private var notifyCallback: ((Map<String, Any>) -> Unit)? = null
    private var isUsbInited = false

    // UsbManagerCore 实例
    private var usbManagerCore: UsbManagerCore? = null

    // UsbCallbackCore 回调实现
    private val usbCallback = object : UsbCallbackCore {
        override fun onDataReceived(data: ByteArray) {
            Log.d(TAG, "onDataReceived: ${data.size} bytes")
            handleReadBuf(data)
        }

        override fun onError(errorCode: Int) {
            Log.e(TAG, "Usb error: $errorCode")
            notifyAndSetError(errorCode)
        }
    }

    /**
     * 设置消息通知器
     */
    fun setNotify(callback: (Map<String, Any>) -> Unit) {
        notifyCallback = callback
    }

    /**
     * 处理读取缓冲区数据
     */
    private fun handleReadBuf(buf: ByteArray): Boolean {
//        Log.e(TAG, "handleReadBuf  ${buf.size}")
        if (!mSynced) {


            mBytesToProbeSync.addAll(buf.toList())
            if (mBytesToProbeSync.size < kSyncEndBytes.size) {
                return false
            }

            val syncEndIndex = findSyncEndBytes()
            if (syncEndIndex == -1) {
                // 保留最后kSyncEndBytes.size - 1个字节，删除前面的字节
                val keepSize = kSyncEndBytes.size - 1
                if (mBytesToProbeSync.size > keepSize) {
                    val keepBytes = mBytesToProbeSync.takeLast(keepSize)
                    mBytesToProbeSync.clear()
                    mBytesToProbeSync.addAll(keepBytes)
                }
                return false
            }

            mSynced = true
            usbManagerCore?.setSynced(mSynced)
            Log.i(TAG, "sync OK")
            notifyCallback?.invoke(
                mapOf(
                    "what" to OneUsb.WHAT_SYNCED
                )
            )
            notifyInPacket(buf)
            return true
        } else {
            notifyInPacket(buf)
            return false
        }
    }

    /**
     * 查找同步结束字节
     */
    private fun findSyncEndBytes(): Int {
        for (i in 0..mBytesToProbeSync.size - kSyncEndBytes.size) {
            var found = true
            for (j in kSyncEndBytes.indices) {
                if (mBytesToProbeSync[i + j] != kSyncEndBytes[j]) {
                    found = false
                    break
                }
            }
            if (found) {
                return i
            }
        }
        return -1
    }

    /**
     * 写入同步包
     */
    suspend fun writeSyncPackets() {
        val syncPackets = listOf(
            Packet.newSyncronsizePacket(kSyncEndBytes)
        )
        write(syncPackets)
    }

    /**
     * 写入数据包列表
     */
    fun write(packets: List<Packet>) {
        if (mError != 0) {
            return
        }

        if (!isUsbInited || usbManagerCore?.getState() != UsbStateCore.CONNECTED) {
            Log.e(TAG, "Usb not ready for writing")
            return
        }

        val dataList = packets.map {
//                Log.e("haloqqq", "write ${it.toBytes().joinToString()}")
            it.toBytes()
        }
        val result = usbManagerCore?.write(dataList) ?: -1
        if (result != 0) {
            Log.e(TAG, "Failed to write packets, result: $result")
        }
    }

    /**
     * 通知输入数据包
     */
    private fun notifyInPacket(buf: ByteArray, size: Int = buf.size) {
        // 这里进行脏数据的判断，当缓存队列里还有包没有收完的情况下收到了心跳包，
        // 那么就认为之前的数据里有脏数据导致包接收异常（脏数据会导致包头的length异常）
        if (mPacketDemuxer.bufferHasData()) {
            if (size == kHearBeatData.size) {
                var equal = true
                for (i in kHearBeatData.indices) {
                    if (buf[i] != kHearBeatData[i]) {
                        equal = false
                        break
                    }
                }
                if (equal) {
                    Log.e(TAG, "notifyInPacket, receive heart beat but current demuxer has data, notify has dirty data")
                    notifyAndSetError(ERR_DIRTY_DATA)
                    return
                }
            }
        }
        val packetList = mPacketDemuxer.parseList(buf, size)
        for (packet in packetList) {
            val type = packet.getPacketType()
            when (packet.getPacketType()) {
                PacketType.Synchronize -> continue
                PacketType.HeartBeat -> {
                    Log.i(TAG, "camera heart beat")
                    continue
                }

                PacketType.LinuxCmd, PacketType.Message, PacketType.Stream, PacketType.SocketTunnel -> {
                    if (packet.getPacketType() == PacketType.LinuxCmd || mSynced) {
                        notifyCallback?.invoke(
                            mapOf(
                                "what" to OneUsb.WHAT_IN_PACKET,
                                "packet" to packet
                            )
                        )
                    }
                }

                else -> {
                    // 其他类型的包
                    if (mSynced) {
                        Log.i(TAG, "notifyInPacket else type")
                        notifyCallback?.invoke(
                            mapOf(
                                "what" to OneUsb.WHAT_IN_PACKET,
                                "packet" to packet
                            )
                        )
                    }
                }
            }
        }
    }

    /**
     * 通知错误
     */
    private fun notifyTestUsb(buf: ByteArray, size: Int = buf.size) {
        val packet = Packet.fromBytes(buf)
        if (packet == null) {
            Log.e(TAG, "notifyTestUsb but packet is null")
            return
        }
        notifyCallback?.invoke(
            mapOf(
                "what" to OneUsb.WHAT_TEST_USB,
                "packet" to packet
            )
        )
    }

    /**
     * 通知并设置错误
     */
    protected fun notifyAndSetError(err: Int) {
        if (mError != 0) {
            return
        }
        Log.i(TAG, "notify io error $err")
        mError = err
        notifyError(err)
    }

    /**
     * 通知错误
     */
    private fun notifyError(error: Int) {
        notifyCallback?.invoke(
            mapOf(
                "what" to OneUsb.WHAT_ERROR,
                "error" to error
            )
        )
    }

    suspend fun open(
        usbSysPath: String,
    ): Int {
        try {
            // 0. 创建 UsbManagerCore 实例
            usbManagerCore = UsbManagerCore()

            // 1. 初始化 UsbManagerCore
            var result = usbManagerCore!!.init(usbSysPath)
            if (result != 0) {
                Log.e(TAG, "Failed to init usbManagerCore: $result")
                usbManagerCore = null
                return result
            }

            // 2. 打开连接, 构造ins_socket中C++层对象
            Log.i(TAG, "usbManagerCore!!.open()")
            result = usbManagerCore!!.open()
            if (result != 0) {
                Log.e(TAG, "Failed to open usb: $result")
                usbManagerCore?.destroy()
                usbManagerCore = null
                return result
            }

            // 3. 设置回调
            Log.i(TAG, "usbManagerCore!!.setCallback()")
            usbManagerCore!!.setCallback(usbCallback)
            isUsbInited = true

            Log.i(TAG, "init UsbManagerCore and open Usb successfully!")
            return 0
        } catch (e: Exception) {
            Log.e(TAG, "Exception opening usb: ${e.message}")
            usbManagerCore?.destroy()
            usbManagerCore = null
            return -1
        }
    }

    suspend fun serve(
    ): Int {
        try {
            if (!isUsbInited) {
                Log.e(TAG, "serve() but !isUsbInited!")
                return -1;
            }

            // 4. 开始服务
            Log.i(TAG, "usbManagerCore!!.serve()")
            val result = usbManagerCore!!.serve()
            // C++中serve()会调用writeSyncPackets(), 上移到Kt层;
            writeSyncPackets()

            if (result != 0) {
                Log.e(TAG, "Failed to start usb serve: $result")
                usbManagerCore?.close()
                usbManagerCore?.destroy()
                usbManagerCore = null
                isUsbInited = false
                return result
            }
            Log.i(TAG, "Usb serve() successfully!")
            return 0
        } catch (e: Exception) {
            Log.e(TAG, "Exception usb serve(): ${e.message}")
            usbManagerCore?.close()
            usbManagerCore?.destroy()
            usbManagerCore = null
            return -1
        }
    }

    fun close() {
        if (isUsbInited) {
            Log.e(TAG, "close()")
            usbManagerCore?.close()
            usbManagerCore?.destroy()
            usbManagerCore = null
            isUsbInited = false
        }
    }

}
