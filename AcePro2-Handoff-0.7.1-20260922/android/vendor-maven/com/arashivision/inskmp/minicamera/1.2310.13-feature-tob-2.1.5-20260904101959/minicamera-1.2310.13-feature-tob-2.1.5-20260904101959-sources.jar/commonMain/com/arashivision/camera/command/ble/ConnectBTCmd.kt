package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver
import insta360.messages.ConnectToBTPeripheral

class ConnectBTCmd(private val mConnectToBTPeripheral: ConnectToBTPeripheral) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.connectBT(mConnectToBTPeripheral)
    }
}
