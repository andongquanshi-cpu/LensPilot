package com.arashivision.camera

import com.arashivision.camera.exception.OpenException

/**
 * 相机的状态
 */
class InstaCameraState private constructor() {
    var state: Int = IDEL
        private set


    private object SingletonInstance {
        val INSTANCE: InstaCameraState = InstaCameraState()
    }


    fun changeState(state: Int) {
        this.state = state
    }


    /**
     * 打开连接相机时，状态不正确抛出异常
     */
    fun checkIdelState() {
        if (state != IDEL) {
            throw OpenException("only idel status can open camera")
        }
    }


    /**
     * 相机连接成功后，发送操作指令，状态不正确抛出异常
     */
    @Throws(OpenException::class)
    fun checkoutOpenState() {
        if (state < OPEN_COMPLETE) {
            throw OpenException("only opened camera can send cmd")
        }
    }

    val isCameraReady: Boolean
        get() {
            if (state >= OPEN_COMPLETE) {
                return true
            }
            return false
        }

    companion object {
        const val IDEL: Int = 0

        const val OPENING: Int = 1

        const val OPEN_COMPLETE: Int = 2

        const val BUSY: Int = 3

        const val ERROR: Int = 4

        const val RECORDING: Int = 5

        const val RECORD_STOPING: Int = 6


        fun create(): InstaCameraState {
            return SingletonInstance.INSTANCE
        }
    }
}
