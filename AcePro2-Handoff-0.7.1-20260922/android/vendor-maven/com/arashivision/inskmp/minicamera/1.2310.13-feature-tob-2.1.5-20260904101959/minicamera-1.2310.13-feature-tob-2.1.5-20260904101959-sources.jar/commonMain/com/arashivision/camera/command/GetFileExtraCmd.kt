package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetFileExtra

class GetFileExtraCmd(private val getFileExtra: GetFileExtra) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getFileExtra(getFileExtra)
    }
}
