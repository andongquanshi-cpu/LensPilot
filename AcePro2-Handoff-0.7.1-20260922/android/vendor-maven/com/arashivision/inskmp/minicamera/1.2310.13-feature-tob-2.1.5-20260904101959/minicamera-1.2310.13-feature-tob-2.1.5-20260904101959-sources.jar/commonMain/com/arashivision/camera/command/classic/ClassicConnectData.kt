package com.arashivision.camera.command.classic

data class ClassicConnectData(val isBleProxy: Boolean, val mIsHeartBeatEnable: Boolean)



