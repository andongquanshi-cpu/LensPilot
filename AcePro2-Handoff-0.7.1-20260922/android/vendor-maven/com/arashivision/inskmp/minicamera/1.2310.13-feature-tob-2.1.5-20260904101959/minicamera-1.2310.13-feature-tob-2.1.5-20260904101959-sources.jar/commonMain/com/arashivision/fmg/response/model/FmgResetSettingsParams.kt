package com.arashivision.fmg.response.model

class FmgResetSettingsParams {
    var fmgSettingsParams: FmgSettingsParams? = null
    var degrees: Float = 0f

    override fun toString(): String {
        return "FmgSettingsResetParams{" +
                "fmgSettingsParams=" + fmgSettingsParams +
                ", degrees=" + degrees +
                '}'
    }
}
