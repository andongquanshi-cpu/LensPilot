package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.ButtonPressParamsType

class GetButtonPressParamsCmd(
    private val buttonPressMode: Int,
    private val buttonPressType: Int,
    private val optionType: List<ButtonPressParamsType>,
    private val requestOptions: RequestOptions,
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            requestOptions
        )
    }
}
