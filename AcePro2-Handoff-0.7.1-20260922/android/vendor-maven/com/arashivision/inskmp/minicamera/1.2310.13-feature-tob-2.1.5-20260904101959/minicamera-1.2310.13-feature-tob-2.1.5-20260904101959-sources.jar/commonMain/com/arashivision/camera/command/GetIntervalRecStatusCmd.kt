package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

internal class GetIntervalRecStatusCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.getIntervalRecStatus()
    }
}
