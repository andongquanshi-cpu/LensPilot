package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CardLocation

class SetMainStorageCmd(
    private val cardLocation: CardLocation,
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setMainStorage(cardLocation)
    }
}
