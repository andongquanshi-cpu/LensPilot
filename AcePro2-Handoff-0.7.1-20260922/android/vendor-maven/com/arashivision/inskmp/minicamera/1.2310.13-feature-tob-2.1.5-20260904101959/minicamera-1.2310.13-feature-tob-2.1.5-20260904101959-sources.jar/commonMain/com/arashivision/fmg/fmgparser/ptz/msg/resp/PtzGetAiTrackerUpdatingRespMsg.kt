package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetAiTrackerUpdatingRespMsg : PtzDataRespMessage() {
    var updatingSerial: Long = -1

    override fun unpack(data: ByteArray?) {
        if (data != null && data.size >= 4) {
            updatingSerial = FmgByteUtils.uint32ByteArrayToLong(data.copyOfRange(0, 4))
        }
    }

    override fun toString(): String {
        return "PtzGetAiTrackerUpdatingRespMsg{" +
                "updatingIndex=" + updatingSerial +
                '}'
    }

    override fun name(): String {
        return "CMD_AI_TRACKER_UPDATING"
    }
}
