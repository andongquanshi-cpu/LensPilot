package com.arashivision.camera.command

import com.arashivision.camera.listener.ICameraConnectionListener
import com.arashivision.common.BleLog
import com.arashivision.common.Log
import com.arashivision.common.coroutines.runOnMainThread
import com.arashivision.onecamera.OneDriver
import com.arashivision.onecamera.OneDriverInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class OpenWifiCmd(
    private val mNetworkHandle: Long,
    private val mToM: Int,
    private val mAddr: String,
    private val mPort: Short,
    private val mHeartBeats: Boolean,
    private val isUseUcd2: Boolean,
    private val mProcessBusyPacket: Boolean,
    private val mHeartHandler: CoroutineScope,
    private val mCameraConnectionListeners: ArrayList<ICameraConnectionListener>?,
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDriver: OneDriver?): Any? {
        Log.i(TAG, "start open wifi")
        var retv = oneDriver?.openWifi(mNetworkHandle, mToM, mAddr, mPort, isUseUcd2, mProcessBusyPacket) ?: 0
        BleLog.w("The result of opening wifi: $retv")

        // IPv6 直连(Aware NDP)socket 超时(-214)时，NDP 仍有效，重试一次重开 socket。
        if (retv == OneDriverInfo.Notification.UsbError.ERR_SOCKET_CONNECT && isIpv6Address(mAddr)) {
            Log.w(TAG, "open wifi socket connect timeout(-214) on ipv6 addr, retry once after ${RETRY_DELAY_MS}ms")
            delay(RETRY_DELAY_MS)
            oneDriver?.resetSocketForRetry() // 先还原状态，否则重试被 isOpened 挡掉
            retv = oneDriver?.openWifi(mNetworkHandle, mToM, mAddr, mPort, isUseUcd2, mProcessBusyPacket) ?: 0
            BleLog.w("The result of retrying open wifi: $retv")
        }

        if (retv != 0) {
            notifyError(retv)
            return retv
        }
        oneDriver?.let { notifyComplete(it) }
        Log.d(TAG, "open camera with wifi success")
        return retv
    }

    // IPv6 含 ':'，IPv4 不含；用于区分 Aware(IPv6) 与普通 AP(IPv4)。
    private fun isIpv6Address(addr: String): Boolean = addr.contains(':')


    private fun notifyError(retv: Int) {
        if (mCameraConnectionListeners == null) {
            return
        }

        runOnMainThread {
            for (listener in mCameraConnectionListeners) {
                listener.onCameraError(retv)
            }
        }
    }


    //成功回调，获取当前的信息
    private fun notifyComplete(oneDrvier: OneDriver) {
        //发送心跳包
        if (mHeartBeats) {
            mHeartHandler.launch {
                try {
                    repeat(Int.MAX_VALUE) {
                        oneDrvier.sendWifiHearBeat()
                        delay(1500)
                    }
                } catch (e: CancellationException) {
                    Log.d(TAG, "WiFi heartbeat cancelled")
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "Error in WiFi heartbeat: ${e.message}")
                    e.printStackTrace()
                }
            }
        }

        if (mCameraConnectionListeners == null) {
            return
        }
        //获取当前信息
        runOnMainThread {
            for (listener in mCameraConnectionListeners) {
                listener.onCameraConnect()
            }
        }
    }


    companion object {
        private val TAG: String = OpenWifiCmd::class.simpleName.toString()

        // -214 重试前的延迟
        private const val RETRY_DELAY_MS = 800L
    }
}
