package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgSettingsParams
import com.arashivision.onecamera.OneDriver

class SetFmgSettingsCmd(
// can only be set one param once cmd
    private val settingsParams: FmgSettingsParams
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return if (settingsParams.ptzMode != null) {
            oneDrvier?.ptzSetSettingsMode(settingsParams.ptzMode!!)
        } else if (settingsParams.ptzFollowSpeed != null) {
            oneDrvier?.ptzSetSettingFollowSpeed(settingsParams.ptzFollowSpeed!!)
        } else if (settingsParams.ptzRcSpeed != null) {
            oneDrvier?.ptzSetSettingRcSpeed(settingsParams.ptzRcSpeed!!)
        } else if (settingsParams.ptzZoomSpeed != null) {
            oneDrvier?.ptzSetSettingZoomSpeed(settingsParams.ptzZoomSpeed!!)
        } else if (settingsParams.ptzRcHorizontalDir != null) {
            oneDrvier?.ptzSetSettingRcHorizontalDir(settingsParams.ptzRcHorizontalDir!!)
        } else if (settingsParams.ptzRcVerticalDir != null) {
            oneDrvier?.ptzSetSettingRcVerticalDir(settingsParams.ptzRcVerticalDir!!)
        } else if (settingsParams.ptzSoundEnable != null) {
            oneDrvier?.ptzSetSettingSoundEnable(settingsParams.ptzSoundEnable!!)
        } else if (settingsParams.ptzHvMode != null) {
            oneDrvier?.ptzSetSettingHvMode(settingsParams.ptzHvMode!!)
        } else if (settingsParams.ptzSwitchModeWay != null) {
            oneDrvier?.ptzSetSettingSwitchModeWay(settingsParams.ptzSwitchModeWay!!)
        } else if (settingsParams.ptzLedBrightness != null) {
            oneDrvier?.ptzSetSettingLedBrightness(settingsParams.ptzLedBrightness!!)
        } else if (settingsParams.ptzMotorStrength != null && settingsParams.ptzMotorStrength != PtzMotorStrength.UNKNWOW) {
            oneDrvier?.ptzSetSettingMotorStrength(settingsParams.ptzMotorStrength!!)
        } else if (settingsParams.ptzRoll360 != null && settingsParams.ptzRoll360 != PtzRoll360.UNKNOW) {
            oneDrvier?.ptzSetSettingRoll360(settingsParams.ptzRoll360!!)
        } else if (settingsParams.ptzQuickStart != null && settingsParams.ptzQuickStart != PtzQuickStart.UNKNOW) {
            oneDrvier?.ptzSetSettingQuickStart(settingsParams.ptzQuickStart!!)
        } else if (settingsParams.ptzPitchLed != null && settingsParams.ptzPitchLed != PtzPitchLed.UNKNWOW) {
            oneDrvier?.ptzSetSettingPitchLed(settingsParams.ptzPitchLed!!)
        } else if (settingsParams.ptzEnableSaveHv != null && settingsParams.ptzEnableSaveHv != PtzEnableSaveHv.UNKNWOW) {
            oneDrvier?.ptzSetSettingEnableSaveHv(settingsParams.ptzEnableSaveHv!!)
        } else if (settingsParams.ptzSurroundShoot != null && settingsParams.ptzSurroundShoot != PtzSurroundShoot.UNKNOW) {
            oneDrvier?.ptzSetSettingSurroundShot(settingsParams.ptzSurroundShoot!!)
        } else {
            -1L
        }
    }
}
