package com.arashivision.fmg.response.model

class FmgCalibrateState(
// 待定
    var status: Int, // 进度
    var percentage: Int
)
