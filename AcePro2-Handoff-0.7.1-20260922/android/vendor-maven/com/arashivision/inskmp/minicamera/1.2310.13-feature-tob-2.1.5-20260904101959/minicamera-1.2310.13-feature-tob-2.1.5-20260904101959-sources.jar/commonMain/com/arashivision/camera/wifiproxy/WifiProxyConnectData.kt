package com.arashivision.camera.wifiproxy

import okio.Buffer

/**
 * KMP兼容的WifiProxyConnectData实现
 * 使用okio替代java.nio.ByteBuffer
 */
class WifiProxyConnectData(var socketId: Int, var port: Int, var url: String, var isUcd2: Boolean) : IWifiProxyData {
    override fun toBytes(): ByteArray {
        val urlBytes = url.encodeToByteArray()
        if (isUcd2) {
            return Buffer().apply {
                // 使用小端序写入数据
                writeIntLe(0x32444355)    // magic
                writeByte(0x01)         // version
                writeByte(12)            // header_length
                writeByte(0x0c)          // type
                writeByte(1)            // sequence
                writeIntLe(10 + urlBytes.size)              // payload_len：messageHeadSize + messageContent.size()
                writeByte(IWifiProxyData.CMD_CONNECT.toInt())
                writeByte(0)
                writeIntLe(socketId)         // 4 bytes: socketId
                writeIntLe(port)             // 4 bytes: port
                write(urlBytes)              // variable: url bytes
                val crc = WifiProxyDataParser.crc32(this)
                writeIntLe(crc)
            }.readByteArray()
        }

        val length = 4 + 1 + 2 + 1 + 1 + 4 + 4 + urlBytes.size
        return Buffer().apply {
            // 使用小端序写入数据
            writeIntLe(length)           // 4 bytes: length
            writeByte(0x0c)              // 1 byte: 0x0c
            writeByte(0)                 // 1 byte: 0
            writeByte(0)                 // 1 byte: 0
            writeByte(IWifiProxyData.CMD_CONNECT.toInt()) // 1 byte: CMD_CONNECT
            writeByte(0)                 // 1 byte: 0
            writeIntLe(socketId)         // 4 bytes: socketId
            writeIntLe(port)             // 4 bytes: port
            write(urlBytes)              // variable: url bytes
        }.readByteArray()
    }

    override fun size(): Int {
        val urlBytes = url.encodeToByteArray()
        return if (isUcd2) {
            4 + 1 + 1 + 1 + 1 + 4 + 1 + 1 + 4 + 4 + urlBytes.size + 4
        } else {
            4 + 1 + 2 + 1 + 1 + 4 + 4 + urlBytes.size
        }
    }
}
