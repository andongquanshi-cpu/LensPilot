package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetUuidRespMsg : PtzDataRespMessage() {
    var uuid: String? = null

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 10) {
            return
        }
        uuid = FmgByteUtils.byteArrayToStringOnUS_ASCII(data)
    }

    override fun toString(): String {
        return "uuid: $uuid"
    }

    override fun name(): String {
        return "CMD_GET_UUID"
    }
}
