package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StopBulletTimeCmd(private val mExtraData: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.stopBulletTime(mExtraData)
        return 0
    }
}
