package com.arashivision.camera.scheduler

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.common.Log
import com.arashivision.onecamera.OneDriver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.CoroutineContext

/**
 * 基于协程的调度器抽象基类
 * 提供优雅的异步任务调度能力
 */
abstract class CoroutineSchedulers {

    /**
     * 创建协程工作器
     */
    abstract fun createWorker(): CoroutineWorker

    /**
     * 释放调度器资源
     */
    abstract fun release()

    /**
     * 直接调度任务（异步）
     */
    fun scheduleDirectSync(
        oneDriver: OneDriver,
        delay: Long = 0L,
        vararg instaCmdExes: InstaCmdExe?,
    ) {
        val worker = createWorker()
        worker.scheduleSync(oneDriver, delay, *instaCmdExes)
    }

    /**
     * 直接调度任务（在协程中执行并等待结果）
     */
    suspend fun scheduleDirect(
        oneDriver: OneDriver,
        delay: Long = 0L,
        vararg instaCmdExes: InstaCmdExe?,
    ): Any? {
        val worker = createWorker()
        return worker.schedule(oneDriver, delay, *instaCmdExes)
    }

    /**
     * 协程工作器抽象类
     */
    abstract class CoroutineWorker {

        /**
         * 调度任务（异步）
         */
        abstract suspend fun schedule(
            oneDriver: OneDriver,
            delay: Long,
            vararg instaCmdExes: InstaCmdExe?,
        ): Any?

        /**
         * 调度任务（同步等待结果）
         */
        abstract fun scheduleSync(
            oneDriver: OneDriver,
            delay: Long,
            vararg instaCmdExes: InstaCmdExe?,
        )
    }
}

/**
 * 基于协程的命令调度器实现
 * 使用协程作用域和调度器来管理任务执行
 */
class CoroutineCommandScheduler(
    private val context: CoroutineContext = Dispatchers.Default,
    private val maxConcurrency: Int = 1,
) : CoroutineSchedulers() {

    // 使用 Default 调度器，通过 Mutex 确保串行执行（跨平台）
    private val scope = CoroutineScope(context + SupervisorJob())

    // 使用 Mutex 确保同一时间只有一个任务在执行
    private val mutex = Mutex()
    private var isReleased = false

    override fun createWorker(): CoroutineWorker {
        return CoroutineCommandWorker(scope, mutex)
    }

    override fun release() {
        if (!isReleased) {
            isReleased = true
//            scope.cancel()
        }
    }

    /**
     * 协程命令工作器实现
     */
    private inner class CoroutineCommandWorker(
        private val scope: CoroutineScope,
        private val mutex: Mutex,
    ) : CoroutineWorker() {


        override fun scheduleSync(
            oneDriver: OneDriver,
            delay: Long,
            vararg instaCmdExes: InstaCmdExe?,
        ) {
            val cmdName = instaCmdExes[0]::class.simpleName
            Log.e("xonesuhd", "scheduleSync start $cmdName")
            val validCommands = instaCmdExes.filterNotNull()
            if (validCommands.isEmpty()) {
                return
            }

            // mutex.withLock 确保同一时间只有一个任务在执行，解决并发问题
            scope.launch {
                mutex.withLock {
                    try {
                        if (delay > 0) {
                            delay(delay)
                        }
                        // 执行命令
                        for (command in validCommands) {
                            command.exeCmd(oneDriver)
                        }
                    } catch (e: Exception) {
                        // 处理异常
                        throw e
                    }
                }
            }

        }

        override suspend fun schedule(
            oneDriver: OneDriver,
            delay: Long,
            vararg instaCmdExes: InstaCmdExe?,
        ): Any? {
            val cmdName = instaCmdExes[0]::class.simpleName
            Log.d("xonesuhd", "schedule start $cmdName, delay=${delay}")
            val validCommands = instaCmdExes.filterNotNull()
            if (validCommands.isEmpty()) {
                return null
            }

            return mutex.withLock {
                val results = mutableListOf<Any?>()
                try {
                    if (delay > 0) {
                        delay(delay)
                    }
                    // 执行命令
                    for (command in validCommands) {
                        val result = command.exeCmd(oneDriver)
                        results.add(result)
                    }

                    // 存储结果
                } catch (e: Exception) {
                    // 处理异常
                    throw e
                }
                if (results.size == 1) results.first() else results
            }
        }

    }
}
