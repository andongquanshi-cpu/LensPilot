// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/io/CameraIO.kt
package com.arashivision.onedriver.io

import com.arashivision.common.Log
import com.arashivision.inskmp.inssocket.SocketManagerCore
import com.arashivision.inskmp.inssocket.callback.SocketCallbackCore
import com.arashivision.inskmp.inssocket.data.SocketConfigCore
import com.arashivision.inskmp.inssocket.data.SocketStateCore
import com.arashivision.onedriver.packet.Packet
import com.arashivision.onedriver.packet.PacketDemuxer
import com.arashivision.onedriver.packet.PacketType
import com.arashivision.onedriver.usb.OneUsb

/**
 * 相机IO抽象基类 - 对应C++中的CameraIO类
 * 负责处理相机与设备之间的数据通信
 */
class SocketIO {

    companion object {
        private const val TAG = "OneCameraIO"

        const val ERR_SOCKET_DEVICE_BUSY = 1001
        const val ERR_DIRTY_DATA = 1002

        // 同步开始字节
        private val kSyncStartBytes = byteArrayOf(
            's'.code.toByte(),
            'y'.code.toByte(),
            'N'.code.toByte(),
            'c'.code.toByte(),
            'S'.code.toByte(),
            't'.code.toByte(),
            'a'.code.toByte(),
            'I'.code.toByte(),
            'n'.code.toByte(),
            's'.code.toByte()
        )

        // 同步结束字节
        private val kSyncEndBytes = byteArrayOf(
            's'.code.toByte(),
            'y'.code.toByte(),
            'N'.code.toByte(),
            'c'.code.toByte(),
            'e'.code.toByte(),
            'N'.code.toByte(),
            'd'.code.toByte(),
            'i'.code.toByte(),
            'n'.code.toByte(),
            'S'.code.toByte()
        )

        // Socket Busy包: 8byte，data固定
        private val busyArray = byteArrayOf(0x08, 0x00, 0x00, 0x00, 0xb0.toByte(), 0x00, 0x00, 0x01)

        // 心跳包数据
        private val kHearBeatData = byteArrayOf(0x07, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00)

        // UCD2 magic number (小端序: 0x32444355 -> "UCD2")
        private val ucd2Magic = byteArrayOf(0x55, 0x43, 0x44, 0x32)
    }

    // 状态变量
    private var mReadSynced = false
    private var isWifiHeartDebug = false
    private var mError = 0
    private var isProcessBusyPacketEnable = false

    // 同步相关
    private val mBytesToProbeSync = mutableListOf<Byte>()

    // 数据包处理
    private val mPacketDemuxer = PacketDemuxer()

    // 消息通知
    private var notifyCallback: ((Map<String, Any>) -> Unit)? = null
    private var isSocketInited = false

    // SocketManagerCore 实例
    private var socketManagerCore: SocketManagerCore? = null

    // SocketCallbackCore 回调实现
    private val socketCallback = object : SocketCallbackCore {
        override fun onDataReceived(data: ByteArray) {
            handleReadBuf(data)
        }

        override fun onError(errorCode: Int) {
            Log.e(TAG, "Socket error: $errorCode")
            notifyAndSetError(errorCode)
        }
    }

    /**
     * 设置消息通知器
     */
    fun setNotify(callback: (Map<String, Any>) -> Unit) {
        notifyCallback = callback
    }

    /**
     * 处理读取缓冲区数据
     */
    private fun handleReadBuf(buf: ByteArray): Boolean {
//        Log.d(TAG, "handleReadBuf ${buf.size}")
        if (!Packet.useUcd2 && !mReadSynced) {
            Log.i(TAG, "handleReadBuf")
            if (isUcd2(buf)) {
                Packet.useUcd2 = true
                mReadSynced = true
                socketManagerCore?.setSynced(mReadSynced)
                notifyInPacket(buf)
                return false
            }
            // 当设备被其他手机连接时，当前尝试连接的手机会收到socket发过来的busy包
            if (isProcessBusyPacketEnable && isBusyPacket(buf)) {
                notifyError(ERR_SOCKET_DEVICE_BUSY)
                return false
            }

            mBytesToProbeSync.addAll(buf.toList())
            if (mBytesToProbeSync.size < kSyncEndBytes.size) {
                return false
            }

            val syncEndIndex = findSyncEndBytes()
            if (syncEndIndex == -1) {
                // 保留最后kSyncEndBytes.size - 1个字节，删除前面的字节
                val keepSize = kSyncEndBytes.size - 1
                if (mBytesToProbeSync.size > keepSize) {
                    val keepBytes = mBytesToProbeSync.takeLast(keepSize)
                    mBytesToProbeSync.clear()
                    mBytesToProbeSync.addAll(keepBytes)
                }
                return false
            }

            mReadSynced = true
            socketManagerCore?.setSynced(mReadSynced)
            Log.i(TAG, "sync OK")
            notifyCallback?.invoke(
                mapOf(
                    "what" to OneUsb.WHAT_SYNCED
                )
            )
            notifyInPacket(buf)
            return true
        } else {
            notifyInPacket(buf)
            return false
        }
    }

    /**
     * 判断数据是否是 ucd2.0
     *
     * @param buf data from socket
     * @return true if is ucd2 packet else false
     */
    fun isUcd2(buf: ByteArray): Boolean {
        if (buf.size < 4) {
            return false
        }
        for (i in 0 until 4) {
            if (buf[i] != ucd2Magic[i]) {
                return false
            }
        }
        return true
    }

    /**
     * 判断数据是否是busy包
     */
    private fun isBusyPacket(buf: ByteArray): Boolean {
        if (buf.size != 8) {
            return false
        }
        return buf.contentEquals(busyArray)
    }

    /**
     * 查找同步结束字节
     */
    private fun findSyncEndBytes(): Int {
        for (i in 0..mBytesToProbeSync.size - kSyncEndBytes.size) {
            var found = true
            for (j in kSyncEndBytes.indices) {
                if (mBytesToProbeSync[i + j] != kSyncEndBytes[j]) {
                    found = false
                    break
                }
            }
            if (found) {
                return i
            }
        }
        return -1
    }

    /**
     * 写入同步包
     */
    fun writeSyncPackets() {
        val syncPackets = listOf(
            Packet.newSyncronsizePacket(kSyncEndBytes)
        )
        Log.e(TAG, "Socket: writeSyncPackets")
        write(syncPackets)
    }

    /**
     * 写入数据包列表
     */
    fun write(packets: List<Packet>) {
        if (mError != 0) {
            return
        }
        if (!isSocketInited || socketManagerCore?.getState() != SocketStateCore.CONNECTED) {
            Log.e(TAG, "Socket not ready for writing")
            return
        }

        val dataList = packets.map {
//                Log.e("haloqqq", "write ${it.toBytes().joinToString()}")
            val type = it.getPacketType()
//                Log.i(TAG, "scoketio write type: ${type}")
            it.toBytes()
        }
        val result = socketManagerCore?.write(dataList) ?: -1
        if (result != 0) {
            Log.e(TAG, "Failed to write packets, result: $result")
        }
    }

    /**
     * 写入原始字节数据
     */
    fun writeRawBuf(data: ByteArray) {
        if (mError != 0) {
            Log.i(TAG, "writeRawBuf mError != 0, return")
            return
        }

        if (!isSocketInited || socketManagerCore?.getState() != SocketStateCore.CONNECTED) {
            Log.e(TAG, "Socket not ready for writing raw buffer")
            return
        }

        val result = socketManagerCore?.write(listOf(data)) ?: -1
        if (result != 0) {
            Log.e(TAG, "Failed to write raw buffer, result: $result")
        }
    }

    /**
     * 通知输入数据包
     */
    private fun notifyInPacket(buf: ByteArray, size: Int = buf.size) {
        // 这里进行脏数据的判断，当缓存队列里还有包没有收完的情况下收到了心跳包，
        // 那么就认为之前的数据里有脏数据导致包接收异常（脏数据会导致包头的length异常）
        if (mPacketDemuxer.bufferHasData()) {
            if (size == kHearBeatData.size) {
                var equal = true
                for (i in kHearBeatData.indices) {
                    if (buf[i] != kHearBeatData[i]) {
                        equal = false
                        break
                    }
                }
                if (equal) {
                    Log.e(
                        TAG,
                        "notifyInPacket, receive heart beat but current demuxer has data, notify has dirty data"
                    )
                    notifyAndSetError(ERR_DIRTY_DATA)
                    return
                }
            }
        }

        val packetList = mPacketDemuxer.parseList(buf, size)
        for (packet in packetList) {
//            val type = packet.getPacketType()
//            Log.i(TAG, "packet.getPacketType():$type")
            when (packet.getPacketType()) {

                PacketType.Synchronize -> continue
                PacketType.HeartBeat -> {
                    if (isWifiHeartDebug) {
                        Log.i(TAG, "camera hear beat")
                    }
                    continue
                }

                PacketType.LinuxCmd, PacketType.Message, PacketType.Stream, PacketType.SocketTunnel -> {
                    if (packet.getPacketType() == PacketType.LinuxCmd || Packet.useUcd2 || mReadSynced) {
                        notifyCallback?.invoke(
                            mapOf(
                                "what" to OneUsb.WHAT_IN_PACKET,
                                "packet" to packet
                            )
                        )
                    }
                }

                else -> {
                    // 其他类型的包
                    if (mReadSynced) {
                        notifyCallback?.invoke(
                            mapOf(
                                "what" to OneUsb.WHAT_IN_PACKET,
                                "packet" to packet
                            )
                        )
                    }
                }
            }
        }
    }

    /**
     * 通知并设置错误
     */
    protected fun notifyAndSetError(err: Int) {
        if (mError != 0) {
            return
        }
        Log.i(TAG, "notify io error $err")
        mError = err
        notifyError(err)
    }

    /**
     * 通知错误
     */
    private fun notifyError(error: Int) {
        notifyCallback?.invoke(
            mapOf(
                "what" to OneUsb.WHAT_ERROR,
                "error" to error
            )
        )
    }

    /**
     * 设置调试模式
     */
    fun setDebug(debug: Boolean) {
        isWifiHeartDebug = debug
    }

    /**
     * 设置是否处理busy包
     */
    fun setProcessBusyPacket(processBusyPacketEnable: Boolean) {
        isProcessBusyPacketEnable = processBusyPacketEnable
    }

    fun open(
        networkHandle: Long,
        timeout: Int,
        addr: String,
        port: Int,
    ): Int {
        try {
            // 0. 创建 SocketManagerCore 实例
            socketManagerCore = SocketManagerCore()
            // 1. 初始化 SocketManagerCore
            val config = SocketConfigCore(
                networkHandle = networkHandle,
                to = timeout,
                addr = addr,
                port = port
            )
            var result = socketManagerCore!!.init(config)
            if (result != 0) {
                Log.e(TAG, "Failed to init SocketManagerCore: $result")
                socketManagerCore = null
                return result
            }

            // 2. 打开连接, 构造ins_socket中C++层对象
            Log.i(TAG, "socketManagerCore!!.open()")
            result = socketManagerCore!!.open()
            if (result != 0) {
                Log.e(TAG, "Failed to open socket: $result")
                socketManagerCore?.destroy()
                socketManagerCore = null
                return result
            }
            // 3. 设置回调
            Log.i(TAG, "socketManagerCore!!.setCallback()")
            socketManagerCore!!.setCallback(socketCallback)
            isSocketInited = true
            Log.i(TAG, "init SocketManagerCore and open Socket successfully!")
            return 0
        } catch (e: Exception) {
            Log.e(TAG, "Exception opening socket: ${e.message}")
            socketManagerCore?.destroy()
            socketManagerCore = null
            return -1
        }
    }

    suspend fun serve(
    ): Int {
        try {
            if (!isSocketInited) {
                Log.e(TAG, "serve() but !isSocketInited!")
                return -1;
            }
            if (Packet.useUcd2) {
                Log.d(TAG, "UCD2.0 don't need sync-packet")
                mReadSynced = true
                socketManagerCore?.setSynced(true)
            }
            // 4. 开始服务
            Log.i(TAG, "socketManagerCore!!.serve()")
            val result = socketManagerCore!!.serve()
            // C++中serve()会调用writeSyncPackets(), 上移到Kt层;
            if (!Packet.useUcd2) {
                Log.d(TAG, "UCD1.0 send sync-packet")
                writeSyncPackets()
            }

            if (result != 0) {
                Log.e(TAG, "Failed to start socket serve: $result")
                socketManagerCore?.close()
                socketManagerCore?.destroy()
                socketManagerCore = null
                isSocketInited = false
                return result
            }
            Log.i(TAG, "Socket serve() successfully!")
            return 0
        } catch (e: Exception) {
            Log.e(TAG, "Exception socket serve(): ${e.message}")
            socketManagerCore?.close()
            socketManagerCore?.destroy()
            socketManagerCore = null
            return -1
        }
    }

    fun close() {
        if (isSocketInited) {
            Log.e(TAG, "close()")
            socketManagerCore?.close()
            socketManagerCore?.destroy()
            socketManagerCore = null
            isSocketInited = false
        }
    }

}
