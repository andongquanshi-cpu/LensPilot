package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.CheckAuthorization

class CheckAuthorizationCmd(
    private val checkAuthorization: CheckAuthorization,
    private val mRequestOptions: RequestOptions,
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.checkAuthorization(checkAuthorization, mRequestOptions)
    }
}
