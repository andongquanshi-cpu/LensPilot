package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzShakeHandRespOkMsg : PtzDataRespMessage() {
    var reserved: ByteArray? = null

    override fun unpack(data: ByteArray?) {
        reserved = data
    }

    override fun toString(): String {
        return if (reserved == null) {
            "null"
        } else {
            FmgByteUtils.bytes2hex(reserved!!)
        }
    }

    override fun name(): String {
        return "CMD_SHAKE_HAND_RESP_ACK_OK"
    }
}
