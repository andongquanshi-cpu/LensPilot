package com.arashivision.camera.wifiproxy

interface IWifiProxyData {
    fun toBytes(): ByteArray

    fun size(): Int

    companion object {
        const val CMD_CONNECT: Byte = 1
        const val CMD_MESSAGE: Byte = 2
        const val CMD_DISCONNECT: Byte = 3
    }
}
