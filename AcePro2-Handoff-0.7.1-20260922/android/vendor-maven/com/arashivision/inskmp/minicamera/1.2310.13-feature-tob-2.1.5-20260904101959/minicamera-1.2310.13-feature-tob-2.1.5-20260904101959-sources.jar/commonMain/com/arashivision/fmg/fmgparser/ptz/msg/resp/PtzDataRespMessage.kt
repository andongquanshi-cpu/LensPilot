package com.arashivision.fmg.fmgparser.ptz.msg.resp

abstract class PtzDataRespMessage {
    abstract fun unpack(data: ByteArray?)

    abstract override fun toString(): String

    abstract fun name(): String
}
