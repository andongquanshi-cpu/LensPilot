package com.arashivision.onedriver.action

import insta360.messages.MessageCode
import com.squareup.wire.Message

/**
 * Action状态枚举
 */
enum class ActionState {
    PrepareToTrigger,
    WaitResponse,
    Finished
}

/**
 * Action类别枚举
 */
enum class ActionCategory {
    Stream,
    Capture,
    Picture,
    Info,
    Interrupt // 中断类型命令
}

/**
 * Action类 - 对应C++版本的Action
 * 表示一个待执行的命令操作
 */
class Action(
    private val id: Long,
    private val op: MessageCode,
) {
    private var state: ActionState = ActionState.PrepareToTrigger
    private val props = mutableMapOf<String, Any?>()

    fun getId(): Long = id
    fun getOp(): MessageCode = op
    fun getState(): ActionState = state
    fun setState(newState: ActionState) {
        state = newState
    }

    /**
     * 获取Action类别
     */
    fun getCategory(): ActionCategory {
        return when (op) {
            MessageCode.PHONE_COMMAND_START_LIVE_STREAM,
            MessageCode.PHONE_COMMAND_STOP_LIVE_STREAM,
                -> ActionCategory.Stream

            MessageCode.PHONE_COMMAND_START_CAPTURE,
            MessageCode.PHONE_COMMAND_STOP_CAPTURE,
            MessageCode.PHONE_COMMAND_START_BULLETTIME_CAPTURE,
            MessageCode.PHONE_COMMAND_STOP_BULLETTIME_CAPTURE,
            MessageCode.PHONE_COMMAND_CANCEL_CAPTURE,
            MessageCode.PHONE_COMMAND_START_TIMELAPSE,
            MessageCode.PHONE_COMMAND_STOP_TIMELAPSE,
            MessageCode.PHONE_COMMAND_START_HDR_CAPTURE,
            MessageCode.PHONE_COMMAND_STOP_HDR_CAPTURE,
            MessageCode.PHONE_COMMAND_STOP_TIMESHIFT_CAPTURE,
            MessageCode.PHONE_COMMAND_START_TIMESHIFT_CAPTURE,
                -> ActionCategory.Capture

            MessageCode.PHONE_COMMAND_TAKE_PICTURE,
            MessageCode.PHONE_COMMAND_TAKE_PICTURE_WITHOUT_STORING,
                -> ActionCategory.Picture

            MessageCode.PHONE_COMMAND_STOP_TAKE_PICTURE -> ActionCategory.Interrupt

            else -> ActionCategory.Info
        }
    }

    /**
     * 设置属性
     */
    fun setProp(name: String, value: Any) {
        props[name] = value
    }

    /**
     * 获取属性
     */
    @Suppress("UNCHECKED_CAST")
    fun <T> getProp(name: String): T? {
        return props[name] as? T
    }

    /**
     * 检查是否有属性
     */
    fun hasProp(name: String): Boolean {
        return props.containsKey(name)
    }

    /**
     * 获取参数（MessageLite类型）
     */
    fun getParam(): Message<*, *>? = getProp("param")

    /**
     * 获取原始数据（RawBuf类型）
     */
    fun getRaw(): ByteArray? = getProp<ByteArray>("raw")

    /**
     * 获取超时时间
     */
    fun getTimeoutMs(): Int = getProp<Int>("timeoutMs") ?: 0

    /**
     * 获取重试次数
     */
    fun getRetryCount(): Int = getProp<Int>("retryCount") ?: 0

    /**
     * 获取是否恢复初始状态
     */
    fun getResumeInitial(): Boolean = getProp<Boolean>("resumeInitial") ?: false

    override fun toString(): String {
        return "${op.name}($id)"
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Action) return false
        return id == other.id
    }

    override fun hashCode(): Int {
        return id.hashCode()
    }

    fun putAll(data: Map<String, Any?>) {
        props.putAll(data)
    }
}
