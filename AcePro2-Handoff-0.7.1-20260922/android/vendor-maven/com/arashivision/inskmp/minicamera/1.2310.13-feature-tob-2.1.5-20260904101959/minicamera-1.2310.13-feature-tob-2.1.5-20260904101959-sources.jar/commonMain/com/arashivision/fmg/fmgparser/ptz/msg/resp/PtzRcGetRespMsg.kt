package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzRcGetRespMsg : PtzDataRespMessage() {
    var yaw: Float = 0f
    var pitch: Float = 0f
    var roll: Float = 0f

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 10) {
            Log.d("unpack", "error!!!!")
            return
        }

        val yawBytes = ByteArray(4)
        val pitchBytes = ByteArray(4)
        val rollBytes = ByteArray(4)
        data.copyInto(rollBytes, 0, 0, rollBytes.size)
        data.copyInto(pitchBytes, 0, 4, 4 + pitchBytes.size)
        data.copyInto(yawBytes, 0, 8, 8 + yawBytes.size)
        yaw = FmgByteUtils.uint32ByteArrayToFloat(yawBytes)
        pitch = FmgByteUtils.uint32ByteArrayToFloat(pitchBytes)
        roll = FmgByteUtils.uint32ByteArrayToFloat(rollBytes)
    }

    override fun toString(): String {
        return "yaw: $yaw pitch: $pitch roll: $roll"
    }

    override fun name(): String {
        return "CMD_RC_GET"
    }
}
