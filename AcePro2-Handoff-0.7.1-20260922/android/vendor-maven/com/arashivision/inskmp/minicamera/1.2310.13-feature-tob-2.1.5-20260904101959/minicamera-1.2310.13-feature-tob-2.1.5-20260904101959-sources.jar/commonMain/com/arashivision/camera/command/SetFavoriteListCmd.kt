package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.SetFavoriteList

class SetFavoriteListCmd(private val mSetFavoriteList: SetFavoriteList) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setFavoriteList(mSetFavoriteList)
    }
}
