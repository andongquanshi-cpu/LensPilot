package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgModel.PtzButtonEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzDwEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzRockerEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzTouchEventMode

class PtzGetButtonEnableRespMsg : PtzDataRespMessage() {
    var fmgButtonAbleParams: FmgButtonAbleParams? = null

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 8) {
            return
        }
        fmgButtonAbleParams = FmgButtonAbleParams()
        for (i in data.indices) {
            when (i) {
                0 -> fmgButtonAbleParams!!.modeBtnParams = getButtonEventModes(data[i])
                1 -> fmgButtonAbleParams!!.shutterBtnParams = getButtonEventModes(data[i])
                2 -> fmgButtonAbleParams!!.holdParams = getButtonEventModes(data[i])
                3 -> fmgButtonAbleParams!!.midBtnParams = getButtonEventModes(data[i])
                4 -> fmgButtonAbleParams!!.rockerParams = getRockerEventModes(data[i])
                5 -> fmgButtonAbleParams!!.touchParams = getTouchEventModes(data[i])
                6 -> fmgButtonAbleParams!!.dwParams = getDwEventModes(data[i])
                7 -> fmgButtonAbleParams!!.powerBtnParams = getButtonEventModes(data[i])
            }
        }
    }

    /**
     * @param data -1 全禁用，0 全启动
     * @return
     */
    private fun getButtonEventModes(data: Byte): Array<PtzButtonEventMode>? {
        if (data.toInt() == -1) return null
        val modeList: MutableList<PtzButtonEventMode> = ArrayList()
        if (data.toInt() == 0) {
            modeList.add(PtzButtonEventMode.ALL)
        } else {
            if ((data.toInt() and PtzButtonEventMode.CLICK_SINGLE.nativeValue) == 0) {
                modeList.add(PtzButtonEventMode.CLICK_SINGLE)
            }
            if ((data.toInt() and PtzButtonEventMode.CLICK_DOUBLE.nativeValue) == 0) {
                modeList.add(PtzButtonEventMode.CLICK_DOUBLE)
            }
            if ((data.toInt() and PtzButtonEventMode.CLICK_TRIPLE.nativeValue) == 0) {
                modeList.add(PtzButtonEventMode.CLICK_TRIPLE)
            }
            if ((data.toInt() and PtzButtonEventMode.CLICK_LONG.nativeValue) == 0) {
                modeList.add(PtzButtonEventMode.CLICK_LONG)
            }
            if ((data.toInt() and PtzButtonEventMode.CLICK_LONG_RELEASE.nativeValue) == 0) {
                modeList.add(PtzButtonEventMode.CLICK_LONG_RELEASE)
            }
        }
        return if (modeList.isEmpty()) null else modeList.toTypedArray<PtzButtonEventMode>()
    }

    private fun getRockerEventModes(data: Byte): Array<PtzRockerEventMode>? {
        if (data.toInt() == -1) return null
        val modeList: MutableList<PtzRockerEventMode> = ArrayList()
        if (data.toInt() == 0) {
            modeList.add(PtzRockerEventMode.ALL)
        } else {
            if ((data.toInt() and PtzRockerEventMode.RC_UP.nativeValue) == 0) {
                modeList.add(PtzRockerEventMode.RC_UP)
            }
            if ((data.toInt() and PtzRockerEventMode.RC_DOWN.nativeValue) == 0) {
                modeList.add(PtzRockerEventMode.RC_DOWN)
            }
            if ((data.toInt() and PtzRockerEventMode.RC_LEFT.nativeValue) == 0) {
                modeList.add(PtzRockerEventMode.RC_LEFT)
            }
            if ((data.toInt() and PtzRockerEventMode.RC_RIGHT.nativeValue) == 0) {
                modeList.add(PtzRockerEventMode.RC_RIGHT)
            }
            if ((data.toInt() and PtzRockerEventMode.RC_IDLE.nativeValue) == 0) {
                modeList.add(PtzRockerEventMode.RC_IDLE)
            }
        }
        return if (modeList.isEmpty()) null else modeList.toTypedArray<PtzRockerEventMode>()
    }

    private fun getTouchEventModes(data: Byte): Array<PtzTouchEventMode>? {
        if (data.toInt() == -1) return null
        val modeList: MutableList<PtzTouchEventMode> = ArrayList()
        if (data.toInt() == 0) {
            modeList.add(PtzTouchEventMode.ALL)
        } else {
            if ((data.toInt() and PtzTouchEventMode.TOUCH_CW.nativeValue) == 0) {
                modeList.add(PtzTouchEventMode.TOUCH_CW)
            }
            if ((data.toInt() and PtzTouchEventMode.TOUCH_CCW.nativeValue) == 0) {
                modeList.add(PtzTouchEventMode.TOUCH_CCW)
            }
            if ((data.toInt() and PtzTouchEventMode.TOUCH_START.nativeValue) == 0) {
                modeList.add(PtzTouchEventMode.TOUCH_START)
            }
            if ((data.toInt() and PtzTouchEventMode.TOUCH_END.nativeValue) == 0) {
                modeList.add(PtzTouchEventMode.TOUCH_END)
            }
            if ((data.toInt() and PtzTouchEventMode.TOUCH_LEFT_DOUBLE_CLICK.nativeValue) == 0) {
                modeList.add(PtzTouchEventMode.TOUCH_LEFT_DOUBLE_CLICK)
            }
            if ((data.toInt() and PtzTouchEventMode.TOUCH_RIGHT_DOUBLE_CLICK.nativeValue) == 0) {
                modeList.add(PtzTouchEventMode.TOUCH_RIGHT_DOUBLE_CLICK)
            }
        }
        return if (modeList.isEmpty()) null else modeList.toTypedArray<PtzTouchEventMode>()
    }

    private fun getDwEventModes(data: Byte): Array<PtzDwEventMode>? {
        if (data.toInt() == -1) return null
        val modeList: MutableList<PtzDwEventMode> = ArrayList()
        if (data.toInt() == 0) {
            modeList.add(PtzDwEventMode.ALL)
        } else {
            if ((data.toInt() and PtzDwEventMode.DW_CW_SINGLE.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DW_CW_SINGLE)
            }
            if ((data.toInt() and PtzDwEventMode.DW_CW_START.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DW_CW_START)
            }
            if ((data.toInt() and PtzDwEventMode.DWE_CW_STOP.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DWE_CW_STOP)
            }
            if ((data.toInt() and PtzDwEventMode.DW_CCW_SINGLE.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DW_CCW_SINGLE)
            }
            if ((data.toInt() and PtzDwEventMode.DW_CCW_START.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DW_CCW_START)
            }
            if ((data.toInt() and PtzDwEventMode.DW_CCW_STOP.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DW_CCW_STOP)
            }
            if ((data.toInt() and PtzDwEventMode.DW_SRC_VALUE.nativeValue) == 0) {
                modeList.add(PtzDwEventMode.DW_SRC_VALUE)
            }
        }
        return if (modeList.isEmpty()) null else modeList.toTypedArray<PtzDwEventMode>()
    }

    override fun toString(): String {
        return "PtzGetButtonEnableRespMsg{" +
                "fmgButtonAbleParams=" + fmgButtonAbleParams +
                '}'
    }

    override fun name(): String {
        return "CMD_GET_EVENT_STATUS"
    }
}
