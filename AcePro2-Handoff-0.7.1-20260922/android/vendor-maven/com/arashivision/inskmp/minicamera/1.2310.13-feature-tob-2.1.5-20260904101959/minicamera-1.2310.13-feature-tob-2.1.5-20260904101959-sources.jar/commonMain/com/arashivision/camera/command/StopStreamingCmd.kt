package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StopStreamingCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        val ret = oneDrvier?.stopStreaming()
        return ret
    }
}
