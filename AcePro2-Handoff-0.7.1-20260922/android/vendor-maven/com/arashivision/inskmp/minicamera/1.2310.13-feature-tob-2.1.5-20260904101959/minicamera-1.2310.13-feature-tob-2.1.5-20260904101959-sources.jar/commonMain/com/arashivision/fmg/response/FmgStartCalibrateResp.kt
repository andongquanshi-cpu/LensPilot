package com.arashivision.fmg.response

class FmgStartCalibrateResp(var requestID: Long)
