// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/MessageDemuxer.kt
package com.arashivision.onedriver.packet

/**
 * 消息解复用器 - 对应C++中的MessageDemuxer类
 * 优化：使用更高效的数据结构，简化分片重组逻辑
 */
class MessageDemuxer {
    // 使用MutableMap替代std::map，提高性能
    private val packets = mutableMapOf<Long, MutableList<Packet>>()

    /**
     * 从数据包解析消息
     */
    fun parse(packet: Packet): Message? {
        if (packet.getPacketType() != PacketType.Message) return null

        val messageId = packet.messageId ?: return null
        val endFlag = packet.messageEndFlag ?: return null

        if (endFlag != 0) {
            // 消息结束
            val fragments = packets[messageId]
            return if (fragments == null) {
                // 单包消息
                createMessageFromPacket(packet)
            } else {
                // 多包消息，需要重组
                // 先添加当前结束包到分片列表
                fragments.add(packet)
                // 然后重组所有分片
                val result = createMessageFromFragments(fragments)
                // 最后移除已处理的分片
                packets.remove(messageId)
                result
            }
        } else {
            // 消息分片
            packets.getOrPut(messageId) { mutableListOf() }.add(packet)
            return null
        }
    }

    /**
     * 重置状态
     */
    fun reset() {
        packets.clear()
    }

    private fun createMessageFromPacket(packet: Packet): Message? {
        val contentType = packet.messageContentType ?: return null
        val direction = packet.messageDirection ?: return null
        val id = packet.messageId ?: return null
        val content = packet.messageContent ?: ByteArray(0)
        val method = packet.messageMethod ?: return null

        return Message(method.value, contentType, direction, id, content)
    }

    private fun createMessageFromFragments(fragments: List<Packet>): Message? {
        if (fragments.isEmpty()) return null

        // 使用最后一个包的信息（通常是结束包），与C++版本保持一致
        val lastPacket = fragments.last()
        val method = lastPacket.messageMethod ?: return null
        val contentType = lastPacket.messageContentType ?: return null
        val direction = lastPacket.messageDirection ?: return null
        val id = lastPacket.messageId ?: return null

        // 重组内容 - 按顺序连接所有分片的内容
        val totalSize = fragments.sumOf { it.messageContent?.size ?: 0 }
        val totalContent = ByteArray(totalSize)
        var offset = 0
        
        fragments.forEach { packet ->
            packet.messageContent?.let { content ->
                content.copyInto(totalContent, offset, 0, content.size)
                offset += content.size
            }
        }

        return Message(method.value, contentType, direction, id, totalContent)
    }
}