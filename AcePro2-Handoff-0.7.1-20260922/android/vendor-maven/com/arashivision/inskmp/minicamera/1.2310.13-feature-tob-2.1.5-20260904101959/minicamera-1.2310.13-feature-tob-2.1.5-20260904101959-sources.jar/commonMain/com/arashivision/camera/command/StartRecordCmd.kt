package com.arashivision.camera.command

import com.arashivision.common.Log
import com.arashivision.onecamera.OneDriver

class StartRecordCmd(
    private val mRecordOriginVideo: Boolean,
    private val mLivePush: Boolean,
    mode: Int
) :
    InstaCmdExe {
    private val mMode = mode

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        Log.d(TAG, " one driver = $oneDrvier")

        //是否支持live
        if (!mLivePush) {
            if (mRecordOriginVideo) {
                return oneDrvier?.startRecordWithCameraStorage(mMode)
            }
        }
        return -1
    }

    companion object {
        private val TAG: String = StartRecordCmd::class.simpleName.toString()

    }
}
