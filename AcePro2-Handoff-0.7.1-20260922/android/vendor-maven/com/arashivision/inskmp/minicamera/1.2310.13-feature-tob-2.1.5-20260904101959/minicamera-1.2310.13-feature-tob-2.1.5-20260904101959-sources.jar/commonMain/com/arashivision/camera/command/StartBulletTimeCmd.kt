package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StartBulletTimeCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.startBulletTime()
    }
}
