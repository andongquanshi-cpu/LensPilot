package com.arashivision.camera.listener

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.ScanResultCore

/**
 * 蓝牙扫描的回调
 */
interface IBleScanListener {
    fun onRawScanResult(callbackType: Int, result: ScanResultCore?)

    fun onScanning(bleDevice: BleDeviceCore?)

    fun onScanUpdate(bleDevice: List<BleDeviceCore>?)

    fun onScanStarted(errorCode: Int)

    fun onScanFinished(scanResultList: List<BleDeviceCore>?)

    fun onScanReject()
}
