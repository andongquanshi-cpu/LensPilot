package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzEmptyReqMsg : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        return ByteArray(0)
    }

    override fun toString(): String {
        return name()
    }

    override fun name(): String {
        return "CMD_EMPTY_REQ"
    }
}
