package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.common.BleLog

class PtzGetEtdYaw360EventRespMsg : PtzDataRespMessage() {
    var yaw360EventParamsArray: Array<Yaw360EventParams>? = null

    override fun unpack(data: ByteArray?) {
        val list: MutableList<Yaw360EventParams> = ArrayList()
        try {
            val eventCountSignByteLength = 2
            if (data == null || data.size <= eventCountSignByteLength) {
                Log.d("unpack", "PtzGetEtdYaw360EventRespMsg data error!!!!")
            } else {
                BleLog.i("PtzGetEtdYaw360EventRespMsg:unpack" + FmgByteUtils.bytes2hexDebug(data))
                val eventCount = FmgByteUtils.uint16BytesToInt(data[0], data[1])
                if (eventCount > 0) {
                    val eventDataLength = (data.size - eventCountSignByteLength) / eventCount
                    var i = eventCountSignByteLength
                    while (i < data.size) {
                        val yaw360EventParams = Yaw360EventParams()
                        if (eventDataLength >= 2) {
                            yaw360EventParams.serial_number = FmgByteUtils.uint16BytesToInt(
                                data[i],
                                data[i + 1]
                            )
                        }
                        if (eventDataLength >= 4) {
                            yaw360EventParams.yaw_360_cnt = FmgByteUtils.uint16BytesToInt(
                                data[i + 2],
                                data[i + 3]
                            )
                        }
                        list.add(yaw360EventParams)
                        i += eventDataLength
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // 固件经常返回异常数据
            BleLog.e(
                "PtzGetEtdYaw360EventRespMsg data invalid, throw exception! data = " + data?.contentToString()
            )
        }
        yaw360EventParamsArray = list.toTypedArray<Yaw360EventParams>()
    }

    override fun toString(): String {
        return "yaw360EventParamsArray length = " + (if (yaw360EventParamsArray != null) yaw360EventParamsArray!!.size else 0)
    }

    override fun name(): String {
        return "CMD_GET_ETD - Yaw360Event"
    }

    class Yaw360EventParams {
        var serial_number: Int = 0
        var yaw_360_cnt: Int = 0
    }
}
