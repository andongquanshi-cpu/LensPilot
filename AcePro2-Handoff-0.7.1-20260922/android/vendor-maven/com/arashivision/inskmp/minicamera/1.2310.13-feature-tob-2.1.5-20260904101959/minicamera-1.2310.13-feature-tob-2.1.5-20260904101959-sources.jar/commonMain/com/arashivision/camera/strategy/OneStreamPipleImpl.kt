package com.arashivision.camera.strategy

import com.arashivision.common.Log

// TODO: 需要重新实现OneStreamPipleImpl类以支持KMP
// 当前版本依赖com.arashivision.onestream.OneStreamPipeline，需要KMP兼容版本

/**
 * OneStreamPipeline实现类
 * 
 * TODO: 需要重新实现OneStreamPipleImpl类以支持KMP
 * 当前版本已被暂时屏蔽，因为依赖OneStreamPipeline
 */
class OneStreamPipleImpl {
    // TODO: 重新实现OneStreamPipleImpl类
    // 需要处理：
    // 1. 移除对OneStreamPipeline的依赖
    // 2. 使用KMP兼容的替代方案
    // 3. 重新实现回调逻辑
    
    companion object {
    }
}
