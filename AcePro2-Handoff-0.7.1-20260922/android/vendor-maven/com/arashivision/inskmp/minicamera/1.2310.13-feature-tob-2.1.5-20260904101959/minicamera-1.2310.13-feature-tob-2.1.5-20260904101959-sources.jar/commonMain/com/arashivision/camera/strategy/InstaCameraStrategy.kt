package com.arashivision.camera.strategy

import com.arashivision.camera.InstaCameraModule
import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.camera.listener.ICameraConnectionListener
import com.arashivision.camera.listener.ICameraInfoListener
import com.arashivision.camera.listener.ICameraRecordListener
import com.arashivision.camera.listener.IReconnectCallback
import com.arashivision.camera.listener.ITimelapseListener
import com.arashivision.camera.listener.IWifiProxyDataListener
import com.arashivision.camera.listener.OnStillImageListener
import com.arashivision.camera.scheduler.CoroutineCommandExeManager
import com.arashivision.camera.strategy.IContentStaregyListener.IBleConntectListener
import com.arashivision.camera.strategy.IContentStaregyListener.IFmgOperateListener
import com.arashivision.camera.strategy.IContentStaregyListener.IUsbConnectListener
import com.arashivision.camera.strategy.IContentStaregyListener.IWIfiConnectListener
import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.common.BleLog
import com.arashivision.common.Log
import com.arashivision.common.coroutines.runOnMainThread
import com.arashivision.inskmp.insble.callback.BleStopWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insusb.AppUsbServiceCore
import com.arashivision.onecamera.OneDriver
import com.arashivision.onecamera.OneDriver.OnNotificationListener
import com.arashivision.onedriver.bean.StreamData
import com.arashivision.onedriver.bean.StreamGimbalData
import insta360.messages.OpenTrackingWithRect
import insta360.messages.SetPresetComposition
import insta360.messages.StreamTrackData
import com.arashivision.utils.CLogUtils
import insta360.messages.TakePictureResponse
import insta360.messages.Video
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking

/**
 * 连接的策略
 *
 *
 *
 *
 * 蓝牙，wifi，usb分别去实现
 */
abstract class InstaCameraStrategy : IContentStaregyListener, OnNotificationListener,
    IWIfiConnectListener, IBleConntectListener, IUsbConnectListener, IFmgOperateListener,
    IContentStaregyListener.IClassicConnectListener, OneDriver.OnStreamListener {

    protected lateinit var mOneDrvier: OneDriver

    // TODO: 暂时屏蔽OneStream相关字段，需要KMP兼容版本
    // var mStreamPiple: OneStreamPipeline? = null
    var mCommandExeManager: CoroutineCommandExeManager? = null

    private var mCameraInfoListeners: ArrayList<ICameraInfoListener>? = null
    private var mStillImageListeners: ArrayList<OnStillImageListener>? = null
    private var mCameraRecordListeners: ArrayList<ICameraRecordListener>? = null
    protected var mCameraConnectionListeners: ArrayList<ICameraConnectionListener>? = null
    private var mTimelapseListeners: ArrayList<ITimelapseListener>? = null
    private var mWifiProxyDataListeners: ArrayList<IWifiProxyDataListener>? = null

    private var streamListener: OneDriver.OnStreamListener? = null
    protected var mReconnectCallback: IReconnectCallback? = null

    protected var mBleWakeUpListener: BleWakeupCallbackCore? = null
    protected var mBleStopWakeupCallback: BleStopWakeupCallbackCore? = null
    private var isStreamTraget = false
    protected var mUsbService: AppUsbServiceCore? = null

    // 心跳协程域，用于控制心跳的生命周期
    protected var heartScope: CoroutineScope? = null


    protected var mGyroMatrix: FloatArray? = null

    //保证下列的东西在子类中只有一份
    fun init() {
        mOneDrvier = OneDriver()
        mOneDrvier.setNotificationListener(this)
        mOneDrvier.setStreamListener(this)
        mOneDrvier.setReconnectCallback(object : OneDriver.IReconnectCallback {
            override fun needReconnectSocket(): Boolean {
                return if (mReconnectCallback != null) {
                    mReconnectCallback!!.needReconnectSocket()
                } else {
                    false
                }
            }

            override fun onReconnectSocketSuccess() {
                if (mReconnectCallback != null) {
                    mReconnectCallback!!.onReconnectSocketSuccess()
                }
            }
        })

        mCommandExeManager = CoroutineCommandExeManager()
        mCameraInfoListeners = ArrayList()
        mStillImageListeners = ArrayList()
        mCameraRecordListeners = ArrayList()
        mCameraConnectionListeners = ArrayList()
        mTimelapseListeners = ArrayList()
        mWifiProxyDataListeners = ArrayList()
        mUsbService = AppUsbServiceCore(InstaCameraModule.context)
    }

    fun setGyroRebaseMatrix(matrix3: FloatArray) {
        this.mGyroMatrix = matrix3
    }


    /**
     * 异步执行指令
     */
    protected fun addWorker(vararg cmdExes: InstaCmdExe?): Any {
        return addWorker(0, *cmdExes)
    }

    protected fun addWorker(delay: Long, vararg cmdExes: InstaCmdExe?): Any {
        var result: Any? = null
        result = runBlocking {
            mCommandExeManager?.exeCommand(mOneDrvier, delay, *cmdExes)
        }
        return result ?: -1L
    }

    protected fun addWorkerSync(delay: Long, vararg cmdExes: InstaCmdExe?) {
        if (mCommandExeManager != null) {
            mCommandExeManager!!.exeCommandSync(mOneDrvier, delay, *cmdExes)
        }
    }

    fun addCameraInfoListener(cameraInfoListener: ICameraInfoListener) {
        if (!mCameraInfoListeners!!.contains(cameraInfoListener)) {
            mCameraInfoListeners!!.add(cameraInfoListener)
        }
    }

    fun removeCameraInfoListener(cameraInfoListener: ICameraInfoListener) {
        mCameraInfoListeners!!.remove(cameraInfoListener)
    }

    fun addWifiProxyDataListener(wifiProxyDataListener: IWifiProxyDataListener) {
        if (!mWifiProxyDataListeners!!.contains(wifiProxyDataListener)) {
            mWifiProxyDataListeners!!.add(wifiProxyDataListener)
        }
    }

    fun removeWifiProxyDataListener(wifiProxyDataListener: IWifiProxyDataListener) {
        mWifiProxyDataListeners!!.remove(wifiProxyDataListener)
    }

    fun addStillImageListener(onStillImageListener: OnStillImageListener) {
        if (!mStillImageListeners!!.contains(onStillImageListener)) {
            mStillImageListeners!!.add(onStillImageListener)
        }
    }

    fun removeStillImageListener(onStillImageListener: OnStillImageListener) {
        mStillImageListeners!!.remove(onStillImageListener)
    }

    fun addCameraRecordListener(cameraRecordListener: ICameraRecordListener) {
        if (!mCameraRecordListeners!!.contains(cameraRecordListener)) {
            mCameraRecordListeners!!.add(cameraRecordListener)
        }
    }

    fun removeCameraRecordListener(cameraRecordListener: ICameraRecordListener) {
        mCameraRecordListeners!!.remove(cameraRecordListener)
    }

    fun addConnectionListener(cameraConnectionListener: ICameraConnectionListener) {
        if (!mCameraConnectionListeners!!.contains(cameraConnectionListener)) {
            mCameraConnectionListeners!!.add(cameraConnectionListener)
        }
    }

    fun removeConnectionListener(connectionListener: ICameraConnectionListener) {
        mCameraConnectionListeners!!.remove(connectionListener)
    }

    fun addTimelapseListener(timelapseListener: ITimelapseListener) {
        if (!mTimelapseListeners!!.contains(timelapseListener)) {
            mTimelapseListeners!!.add(timelapseListener)
        }
    }

    fun removeTimelapseListener(timelapseListener: ITimelapseListener) {
        mTimelapseListeners!!.remove(timelapseListener)
    }

    fun setReconnectCallback(reconnectCallback: IReconnectCallback?) {
        mReconnectCallback = reconnectCallback
    }

    fun setBleWakeupListener(bleWakeupListener: BleWakeupCallbackCore?) {
        mBleWakeUpListener = bleWakeupListener
    }

    fun setBleStopWakeupListener(bleStopWakeupCallback: BleStopWakeupCallbackCore?) {
        mBleStopWakeupCallback = bleStopWakeupCallback
    }

    fun setNativeLoggerCallback(loggerCallback: CLogUtils.ILoggerCallback?) {
        mOneDrvier.setNativeLoggerCallback(loggerCallback)
    }

    fun reset() {
        heartScope?.cancel()
        heartScope = null
    }

    fun release() {

        if (mCommandExeManager != null) {
            mCommandExeManager!!.release()
            Log.i(TAG, "release CommandExeManager")
            mCommandExeManager = null
        }
    }


    override fun onDriverInfoNotify(what: Int, requestId: Long, err: Int, obj: Any?) {
        runOnMainThread {
            mCameraInfoListeners?.forEach {
                it.onCameraInfo(what, requestId, err, obj)
            }
        }
    }

    fun setPeerDriver(peer: com.arashivision.onecamera.OneDriver?) = mOneDrvier.setPeerDriver(peer)
    fun getOneDriver(): com.arashivision.onecamera.OneDriver = mOneDrvier

    override fun onDriverRecordVideoStateNotify(state: Int, error: Int, video: Video?) {
        Log.d(TAG, "record finish " + video?.uri + video?.file_size)
        runOnMainThread {
            mCameraRecordListeners?.forEach {
                it.onDriverRecordVideoStateNotify(state, error, video)
            }
        }
    }

    override fun onDriverUsbState(state: Int, err: Int) {
        BleLog.w("onDriverUsbState, state = $state,err = $err")
        //需要重新获取相机的options
        runOnMainThread {
            mCameraConnectionListeners?.forEach {
                if (err == 0) {
                    it.onCameraStateChange()
                } else {
                    // TODO:  需要在外部reset
                    reset()
                    it.onCameraError(err)
                }
            }
        }
    }


    override fun onDriverStillImageNotify(errorCode: Int, mResponse: TakePictureResponse?) {
        Log.d(TAG, "record finish $mStillImageListeners")

        runOnMainThread {
            mStillImageListeners?.forEach {
                it.onDriverStillImageNotify(errorCode, mResponse)
            }
        }
    }

    override fun onDriverStillImageWithoutStorageNotify(error: Int, datas: ByteArray?) {
        runOnMainThread {
            mStillImageListeners?.forEach {
                it.onDriverStillImageWithoutStorageNotify(error, datas)
            }
        }
    }

    override fun onDriverTimelapseNotify(state: Int, error: Int, video: Video?) {
        runOnMainThread {
            mTimelapseListeners?.forEach {
                it.ononTimelapseRecordNotify(state, error, video)
            }
        }
    }

    override fun onDriverStreamDataNotify(mData: StreamData) {
        streamListener?.onDriverStreamDataNotify(mData)
    }

    public fun setStreamListener(streamListener: OneDriver.OnStreamListener?) {
        this.streamListener = streamListener
    }

    override fun onWifiProxyDataNotify(wifiProxyData: IWifiProxyData?) {
        runOnMainThread {
            mWifiProxyDataListeners?.forEach {
                it.onReadWifiProxyData(wifiProxyData)
            }
        }
    }

    fun setGimbalDataCallback(gimbalDataCallback: ((StreamGimbalData) -> Unit)? = null) {
        mOneDrvier.gimbalDataCallback = gimbalDataCallback
    }

    fun setTrackDataCallback(trackDataCallback: ((StreamTrackData) -> Unit)? = null) {
        mOneDrvier.trackDataCallback = trackDataCallback
    }

    companion object {
        val TAG: String = InstaCameraStrategy::class.simpleName.toString()
    }
}
