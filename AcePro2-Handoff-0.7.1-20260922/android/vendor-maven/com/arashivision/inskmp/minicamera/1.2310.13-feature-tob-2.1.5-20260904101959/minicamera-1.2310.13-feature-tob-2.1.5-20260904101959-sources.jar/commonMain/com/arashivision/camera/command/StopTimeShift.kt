package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StopTimeShift(private val mExtraData: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.stopTimeShift(mExtraData)
        return null
    }
}
