package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SyncSetCatpureModeCmd(private val mMode: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setSyncCaptureMode(mMode)
    }
}
