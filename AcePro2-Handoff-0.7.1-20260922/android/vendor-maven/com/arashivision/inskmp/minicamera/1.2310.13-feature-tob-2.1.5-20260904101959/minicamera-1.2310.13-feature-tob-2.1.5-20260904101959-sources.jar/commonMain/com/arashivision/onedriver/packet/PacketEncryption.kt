package com.arashivision.onedriver.packet

import insta360.messages.EncryptScheme

data class PacketEncryptionParams(
    val scheme: EncryptScheme,
    val encrypt: (payload: ByteArray, aad: ByteArray, messageId: Long) -> PacketEncryptResult,
)

data class PacketEncryptResult(
    val ciphertext: ByteArray,
    val nonce: ByteArray?,
    val authTag: ByteArray?,
)

data class PacketDecryptParams(
    val decrypt: (ciphertext: ByteArray, aad: ByteArray, nonce: ByteArray?, authTag: ByteArray?) -> ByteArray,
)
