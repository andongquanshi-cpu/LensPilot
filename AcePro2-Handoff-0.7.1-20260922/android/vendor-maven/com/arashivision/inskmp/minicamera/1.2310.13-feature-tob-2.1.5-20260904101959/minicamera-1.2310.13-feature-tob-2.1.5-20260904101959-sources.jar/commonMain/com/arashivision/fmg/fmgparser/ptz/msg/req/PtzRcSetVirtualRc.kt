package com.arashivision.fmg.fmgparser.ptz.msg.req


class PtzRcSetVirtualRc(private val x: Short, private val y: Short) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(2)
        data[0] = x.toByte()
        data[1] = y.toByte()
        return data
    }

    override fun toString(): String {
        return "x: $x y: $y"
    }

    override fun name(): String {
        return "CMD_VIRTUAL_RC"
    }
}
