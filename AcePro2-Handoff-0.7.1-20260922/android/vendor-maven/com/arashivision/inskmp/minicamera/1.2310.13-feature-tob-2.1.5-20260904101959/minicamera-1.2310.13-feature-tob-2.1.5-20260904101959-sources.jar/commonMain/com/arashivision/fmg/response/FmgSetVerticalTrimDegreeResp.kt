package com.arashivision.fmg.response

class FmgSetVerticalTrimDegreeResp(var requestID: Long)
