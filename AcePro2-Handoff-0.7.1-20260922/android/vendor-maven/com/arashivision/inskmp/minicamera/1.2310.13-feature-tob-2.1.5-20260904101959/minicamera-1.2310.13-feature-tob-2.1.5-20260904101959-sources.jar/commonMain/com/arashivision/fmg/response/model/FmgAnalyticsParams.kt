package com.arashivision.fmg.response.model

import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdCFEventRespMsg.CFEventParams
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdErrorStateEventRespMsg.ErrorStateEventParams
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdPowerOffEventRespMsg.PowerOffEventParams
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdPowerOnEventRespMsg.PowerOnEventParams
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdYaw360EventRespMsg.Yaw360EventParams

class FmgAnalyticsParams {
    var totalPowerOnTimes: Int = 0 //开机总次数
    var fastPowerOnTimes: Int = 0 //快速开机次数
    var keyPowerOnTimes: Int = 0 //按键开机次数
    var totalPowerOffTimes: Int = 0 //关机总次数
    var fastPowerOffTimes: Int = 0 //快速关机次数
    var keyPowerOffTimes: Int = 0 //按键关机次数
    var forcePowerOffTimes: Int = 0 //强制关机的总次数

    var fastPowerOnEventArray: Array<PowerOnEvent?> = emptyArray() //快速开机事件项数组
    var keyPowerOnEventArray: Array<PowerOnEvent?> = emptyArray() //按键开机事件项数组
    var fastPowerOffEventArray: Array<PowerOffEvent?> = emptyArray() //快速关机埋点事件数组
    var keyPowerOffEventArray: Array<PowerOffEvent?> = emptyArray() //按键关机埋点事件数组
    var forcePowerOffEventArray: Array<PowerOffEvent?> = emptyArray() //强制关机埋点事件数组
    var errorStateEventArray: Array<ErrorStateEvent?> = emptyArray() //出错埋点事件数组
    var cfEventArray: Array<CFEvent?> = emptyArray()
    var yaw360EventArray: Array<Yaw360Event?> = emptyArray()

    override fun toString(): String {
        return "FmgAnalyticsParams{" +
                "totalPowerOnTimes=" + totalPowerOnTimes +
                ", fastPowerOnTimes=" + fastPowerOnTimes +
                ", keyPowerOnTimes=" + keyPowerOnTimes +
                ", totalPowerOffTimes=" + totalPowerOffTimes +
                ", fastPowerOffTimes=" + fastPowerOffTimes +
                ", keyPowerOffTimes=" + keyPowerOffTimes +
                ", forcePowerOffTimes=" + forcePowerOffTimes +
                ", fastPowerOnEventArray=" + fastPowerOnEventArray.contentToString() +
                ", keyPowerOnEventArray=" + keyPowerOnEventArray.contentToString() +
                ", fastPowerOffEventArray=" + fastPowerOffEventArray.contentToString() +
                ", keyPowerOffEventArray=" + keyPowerOffEventArray.contentToString() +
                ", forcePowerOffEventArray=" + forcePowerOffEventArray.contentToString() +
                ", errorStateEventArray=" + errorStateEventArray.contentToString() +
                ", cfEventArray=" + cfEventArray.contentToString() +
                ", yaw360EventArray=" + yaw360EventArray.contentToString() +
                '}'
    }

    class PowerOnEvent {
        var eventIndex: Int = 0

        constructor()

        constructor(powerOnEventParams: PowerOnEventParams) {
            this.eventIndex = powerOnEventParams.serial_number
        }
    }

    class PowerOffEvent {
        var eventIndex: Int = 0
        var runningTime: Int = 0

        constructor()

        constructor(powerOffEventParams: PowerOffEventParams) {
            this.eventIndex = powerOffEventParams.serial_number
            this.runningTime = powerOffEventParams.running_times
        }
    }

    class ErrorStateEvent {
        var eventIndex: Int = 0
        var runningTime: Int = 0
        var battery: Int = 0
        var errorType: Int = 0
        var isBTConnected: Boolean = false

        constructor()

        constructor(errorStateEventParams: ErrorStateEventParams) {
            this.eventIndex = errorStateEventParams.serial_number
            this.runningTime = errorStateEventParams.running_times
            this.battery = errorStateEventParams.battery.toInt()
            this.errorType = errorStateEventParams.bt_state_err_type
            this.isBTConnected = errorStateEventParams.bt_connected_state
        }
    }

    class CFEvent {
        var eventIndex: Int = 0

        constructor()

        constructor(cfEventParams: CFEventParams) {
            this.eventIndex = cfEventParams.serial_number
        }
    }

    class Yaw360Event {
        var eventIndex: Int = 0
        var yaw360Count: Int = 0

        constructor()

        constructor(yaw360EventParams: Yaw360EventParams) {
            this.eventIndex = yaw360EventParams.serial_number
            this.yaw360Count = yaw360EventParams.yaw_360_cnt
        }
    }
}
