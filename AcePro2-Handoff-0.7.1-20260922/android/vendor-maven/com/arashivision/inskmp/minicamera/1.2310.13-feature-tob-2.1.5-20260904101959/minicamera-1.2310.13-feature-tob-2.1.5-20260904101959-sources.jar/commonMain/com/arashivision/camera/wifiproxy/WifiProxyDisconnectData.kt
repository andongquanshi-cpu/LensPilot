package com.arashivision.camera.wifiproxy

import okio.Buffer

/**
 * KMP兼容的WifiProxyDisconnectData实现
 * 使用okio替代java.nio.ByteBuffer
 */
class WifiProxyDisconnectData(var socketId: Int, var isUcd2: Boolean) : IWifiProxyData {

    override fun toBytes(): ByteArray {
        if (isUcd2) {
            return Buffer().apply {
                writeIntLe(0x32444355)
                writeByte(0x01)
                writeByte(12)
                writeByte(0x0c)
                writeByte(1)
                writeIntLe(6)
                writeByte(IWifiProxyData.CMD_DISCONNECT.toInt()) // 1 byte: CMD_DISCONNECT
                writeByte(0)                 // 1 byte: 0
                writeIntLe(socketId)         // 4 bytes: socketId
                val crc = WifiProxyDataParser.crc32(this)
                writeIntLe(crc)
            }.readByteArray()
        }
        val length = 4 + 1 + 2 + 1 + 1 + 4

        return Buffer().apply {
            // 使用小端序写入数据
            writeIntLe(length)           // 4 bytes: length
            writeByte(0x0c)              // 1 byte: 0x0c
            writeByte(0)                 // 1 byte: 0
            writeByte(0)                 // 1 byte: 0
            writeByte(IWifiProxyData.CMD_DISCONNECT.toInt()) // 1 byte: CMD_DISCONNECT
            writeByte(0)                 // 1 byte: 0
            writeIntLe(socketId)         // 4 bytes: socketId
        }.readByteArray()
    }

    override fun size(): Int {
        return if (isUcd2) {
            4 + 1 + 1 + 1 + 1 + 4 + 1 + 1 + 4 + 4
        } else {
            4 + 1 + 2 + 1 + 1 + 4
        }
    }
}
