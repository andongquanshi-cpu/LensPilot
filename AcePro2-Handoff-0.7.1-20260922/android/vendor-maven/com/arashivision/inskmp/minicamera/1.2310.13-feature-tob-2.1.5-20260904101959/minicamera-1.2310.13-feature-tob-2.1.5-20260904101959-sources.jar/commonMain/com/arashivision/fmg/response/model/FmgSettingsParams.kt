package com.arashivision.fmg.response.model

import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed

class FmgSettingsParams {
    var ptzMode: PtzMode? = null // 云台模式
    var ptzFollowSpeed: PtzFollowSpeed? = null // 跟随速度
    var ptzRcSpeed: PtzRcSpeed? = null // 摇杆速度
    var ptzZoomSpeed: PtzZoomSpeed? = null // 变焦速度
    var ptzRcHorizontalDir: PtzRcHorizontalDir? = null // 摇杆水平方向
    var ptzRcVerticalDir: PtzRcVerticalDir? = null // 摇杆垂直方向
    var ptzSoundEnable: PtzSoundMode? = null //云台声音使能定义
    var ptzHvMode: PtzHvMode? = null //横屏竖屏模式
    var ptzSwitchModeWay: PtzSwitchModeWay? = null //切换模式的方法
    var ptzLedBrightness: Int? = null // 设置 LED亮度
    var ptzMotorStrength: PtzMotorStrength? = null //电机力度
    var ptzRoll360: PtzRoll360? = null //盗梦空间速度调整
    var ptzQuickStart: PtzQuickStart? = null //快速启动使能
    var ptzPitchLed: PtzPitchLed? = null //pitch轴臂上LED灯的亮度的状态
    var ptzSurroundShoot: PtzSurroundShoot? = null //一键环拍速度调整
    var ptzEnableSaveHv: PtzEnableSaveHv? = null //记忆横竖屏

    override fun toString(): String {
        return "FmgSettingsParams{" +
                "ptzMode = " + ptzMode +
                ", ptzFollowSpeed = " + ptzFollowSpeed +
                ", ptzRcSpeed = " + ptzRcSpeed +
                ", ptzZoomSpeed = " + ptzZoomSpeed +
                ", ptzRcHorizontalDir = " + ptzRcHorizontalDir +
                ", ptzRcVerticalDir = " + ptzRcVerticalDir +
                ", ptzSoundEnable = " + ptzSoundEnable +
                ", ptzScreenOrientation = " + ptzHvMode +
                ", ptzSwitchModeWay = " + ptzSwitchModeWay +
                ", ledBrightness = " + ptzLedBrightness +
                ", ptzMotorStrength = " + ptzMotorStrength +
                ", ptzRollSpeed = " + ptzRoll360 +
                ", ptzQuickStart = " + ptzQuickStart +
                ", ptzPitchLed = " + ptzPitchLed +
                ", ptzSurroundShoot = " + ptzSurroundShoot +
                ", ptzEnableSaveHv = " + ptzEnableSaveHv +
                '}'
    }
}
