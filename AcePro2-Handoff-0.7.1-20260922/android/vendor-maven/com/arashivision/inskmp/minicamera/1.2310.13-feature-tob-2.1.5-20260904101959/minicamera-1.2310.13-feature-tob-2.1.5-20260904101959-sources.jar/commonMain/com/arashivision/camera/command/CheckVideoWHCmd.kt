package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class CheckVideoWHCmd(private val width: Int, private val height: Int, private val fps: Int) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Boolean? {
        return oneDrvier?.checkVideo(width, height, fps)
    }
}
