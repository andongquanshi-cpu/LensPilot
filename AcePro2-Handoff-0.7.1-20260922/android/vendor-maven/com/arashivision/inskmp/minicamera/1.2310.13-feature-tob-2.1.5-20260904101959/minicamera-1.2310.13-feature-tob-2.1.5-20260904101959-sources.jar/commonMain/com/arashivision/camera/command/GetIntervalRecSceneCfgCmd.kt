package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 获取间隔录像场景界面配置
 */
internal class GetIntervalRecSceneCfgCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.getIntervalRecSceneCfg()
    }
}
