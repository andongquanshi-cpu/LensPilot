package com.arashivision.fmg.response

class FmgSetPanoIndexResp(var requestID: Long)
