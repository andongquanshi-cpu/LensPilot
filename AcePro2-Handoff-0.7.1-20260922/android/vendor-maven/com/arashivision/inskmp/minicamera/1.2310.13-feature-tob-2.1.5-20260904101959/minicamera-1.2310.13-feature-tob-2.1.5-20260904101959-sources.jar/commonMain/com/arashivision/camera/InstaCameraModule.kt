package com.arashivision.camera

object InstaCameraModule {
    var context: Any? = null
        private set

    fun init(app: Any) {
        context = app
    }
}