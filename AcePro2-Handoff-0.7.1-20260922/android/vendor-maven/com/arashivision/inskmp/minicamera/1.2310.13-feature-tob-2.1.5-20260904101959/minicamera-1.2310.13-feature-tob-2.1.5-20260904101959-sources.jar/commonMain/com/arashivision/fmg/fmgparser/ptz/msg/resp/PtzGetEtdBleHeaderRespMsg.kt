package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.BleLog
import com.arashivision.fmg.fmgparser.ByteArrayParser
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetEtdBleHeaderRespMsg : PtzDataRespMessage() {
    var dockkit_event_length: Int = 0
    var qu_event_length: Int = 0

    var samsung_tracking_count: Long = 0


    @OptIn(ExperimentalStdlibApi::class)
    override fun unpack(data: ByteArray?) {
        if (data == null) {
            return
        }
        BleLog.d("unpack: PtzGetEtdBleHeaderRespMsg data len: " + data.size + "data: " + data.toHexString(HexFormat.Default))
        val byteArrayParser: ByteArrayParser = ByteArrayParser(data, 0)
        if (byteArrayParser.reamingLength < DOCKKIT_EVENT_BYTES_LEN) {
            return
        }
        val dockkitBytes: ByteArray = byteArrayParser.parseByteArray(DOCKKIT_EVENT_BYTES_LEN)
        dockkit_event_length = FmgByteUtils.uint16ByteArrayToInt(dockkitBytes)

        if (byteArrayParser.reamingLength < QUICK_START_BYTES_LEN) {
            return
        }
        val quickStartBytes: ByteArray = byteArrayParser.parseByteArray(QUICK_START_BYTES_LEN)
        qu_event_length = FmgByteUtils.uint16ByteArrayToInt(quickStartBytes)

        if (byteArrayParser.reamingLength < SAMSUNG_TRACKING_COUNT_BYTES_LEN) {
            return
        }
        val samsungTrackingBytes: ByteArray = byteArrayParser.parseByteArray(SAMSUNG_TRACKING_COUNT_BYTES_LEN)
        samsung_tracking_count = FmgByteUtils.uint32ByteArrayToLong(samsungTrackingBytes)
    }

    override fun toString(): String {
        return TAG.toString() + "{" +
                "dockkit_event_length=" + dockkit_event_length +
                ", qu_event_length=" + qu_event_length +
                ", samsung_tracking_count=" + samsung_tracking_count +
                "}"
    }

    override fun name(): String {
        return "CMD_GET_ETD_BLE - ETD_ITEM_HEADER"
    }

    companion object {
        private val TAG = "PtzGetEtdBleHeaderRespMsg"
        private const val DOCKKIT_EVENT_BYTES_LEN = 2
        private const val QUICK_START_BYTES_LEN = 2
        private const val SAMSUNG_TRACKING_COUNT_BYTES_LEN = 4
    }
}