package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SingleSensorCmd(private val mSensor: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setSingleSensor(mSensor)
    }
}
