package com.arashivision.fmg.response

import com.arashivision.fmg.response.model.FmgSettingsParams

class FmgGetSettingsResp(var requestID: Long, var settingsParams: FmgSettingsParams?)
