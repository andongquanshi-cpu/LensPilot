package com.arashivision.fmg.response

class FmgGetDeviceInfoResp constructor(
    var requestID: Long,
    var serial: String = "",
    var cameraType: String = "",
    var fwVersion: String = ""
) {
    override fun toString(): String {
        return "{" +
                "serial = " + serial +
                ", cameraType = " + cameraType +
                ", fwVersion = " + fwVersion +
                '}'
    }
}
