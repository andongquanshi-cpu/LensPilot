package com.arashivision.onedriver.packet

import okio.Buffer

/**
 * 缓冲区流 - 对应C++中的BufferStream类
 * 优化：使用okio.Buffer提供零拷贝操作和更好的内存管理
 */
class BufferStream {
    private val buffer = Buffer()

    /**
     * 获取当前缓冲区大小
     */
    fun size(): Int = buffer.size.toInt()

    /**
     * 查看数据但不移除
     *
     * 关于 buffer.peek().read() 的行为：
     * 1. peek() 返回一个 BufferedSource，不会消耗原始 buffer
     * 2. peek().read() 也可能只读取部分数据（如果数据跨 Segment）
     * 3. 需要检查返回值，确保读取完整
     *
     * Okio Buffer 内部使用 Segment 链表存储数据：
     * - 每个 Segment 默认大小约 8192 字节
     * - read() 方法可能只读取一个 Segment 的数据
     * - 如果请求的字节数跨多个 Segment，需要多次调用 read()
     *
     * 为什么 peek().read() 和 buffer.read() 都可能只读取部分数据：
     * - 两者都受到 Segment 边界限制
     * - peek().read() 不会消耗数据，但读取行为相同
     * - buffer.read() 会消耗数据，但读取行为也相同
     */
    fun peek(data: ByteArray, size: Int): Int {
        if (size <= 0 || data.isEmpty()) return 0
        val actualSize = minOf(size, buffer.size.toInt(), data.size)
        if (actualSize <= 0) return 0

        val peekSource = buffer.peek()
        var totalRead = 0
        var offset = 0

        // 循环读取直到读取完整数据（处理跨 Segment 的情况）
        while (totalRead < actualSize) {
            val bytesRead = peekSource.read(data, offset, actualSize - totalRead)
            if (bytesRead <= 0) {
                // 没有更多数据可读，返回已读取的字节数
                break
            }
            totalRead += bytesRead
            offset += bytesRead
        }

        return totalRead
    }

    /**
     * 取出数据
     *
     * 关于 buffer.read() 的行为：
     * 1. buffer.read() 会消耗数据，buffer.size() 会减少
     * 2. buffer.read() 可能只读取部分数据（如果数据跨 Segment）
     * 3. 返回值是实际读取的字节数，可能小于请求的字节数
     *
     * Okio Buffer 内部结构：
     * - Buffer 使用 Segment 双向链表存储数据
     * - 每个 Segment 默认大小约 8192 字节（Segment.SIZE）
     * - read() 方法可能只读取一个 Segment 的数据
     * - 如果请求的字节数跨多个 Segment，需要多次调用 read()
     *
     * 为什么 buffer.read() 可能只读取部分数据：
     * - read() 方法内部会检查当前 Segment 的可用数据
     * - 如果当前 Segment 的数据不足，可能只读取该 Segment 的数据
     * - 需要循环调用 read() 直到读取完整数据
     *
     * 关于 readFully() 为什么只有第一位有值：
     * - readFully(ByteArray) 会尝试读取 data.size 字节
     * - ⚠️ 重要：readFully() 也受到 Segment 限制！
     * - readFully() 内部会循环调用 read()，但 read() 可能只读取一个 Segment
     * - 如果数据跨 Segment，readFully() 可能只读取第一个 Segment 的数据（约 8192 字节）
     * - 然后发现数据不足，抛出 EOFException
     * - 但在抛出异常前，可能已经读取了部分数据到数组中
     * - 数组的剩余部分保持未初始化状态（全为0）
     * - 这就是为什么你看到"只有第一位有值"的原因
     *
     * 示例：
     * - buffer 中有 10000 字节（跨多个 Segment）
     * - 调用 readFully(ByteArray(10000))
     * - readFully() 内部第一次 read() 可能只读取 8192 字节（第一个 Segment）
     * - 然后继续尝试读取，但如果后续 Segment 读取失败，会抛出 EOFException
     * - 结果：数组中只有前 8192 字节有数据，后面的字节全为0
     *
     * 解决方案：
     * - 使用循环读取，检查返回值，如果读取不完整则继续读取
     * - 这样既能保证数据完整性，又能避免额外的内存分配和复制
     * - 性能最优：正常情况下只有一次读取操作，无额外分配和复制
     */
    fun take(data: ByteArray, size: Int): Int {
        if (size <= 0 || data.isEmpty()) return 0
        val actualSize = minOf(size, buffer.size.toInt(), data.size)
        if (actualSize <= 0) return 0

        var totalRead = 0
        var offset = 0
        // 循环读取直到读取完整数据
        // 这样可以避免额外的内存分配和复制，同时确保数据完整性
        while (totalRead < actualSize) {
            val bytesRead = buffer.read(data, offset, actualSize - totalRead)
            if (bytesRead <= 0) {
                // 没有更多数据可读，返回已读取的字节数
                break
            }
            totalRead += bytesRead
            offset += bytesRead
        }

        return totalRead
    }

    /**
     * 添加数据
     */
    fun put(data: ByteArray, size: Int) {
        if (size <= 0 || data.isEmpty()) return
        val actualSize = minOf(size, data.size)

        // 使用okio的write操作，自动管理内存
        buffer.write(data, 0, actualSize)
    }

    /**
     * 添加数据（重载版本）
     */
    fun put(data: ByteArray) {
        put(data, data.size)
    }

    /**
     * 清空缓冲区
     */
    fun clear() {
        buffer.clear()
    }

    /**
     * 检查是否有数据
     */
    fun hasData(): Boolean = buffer.size > 0
}