package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log

class PtzBasketballG2ARespMsg : PtzDataRespMessage() {
    var mode: Short = 0
    var state: Short = 0
    var transition: Byte = 0
    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 3) {
            Log.d("unpack", "error!!!!")
            return
        }
        mode = data[0].toShort()
        state = data[1].toShort()
        transition = data[2]
    }

    override fun toString(): String {
        return "PtzBasketballG2ARespMsg{" +
                "mode=" + mode +
                ", state=" + state +
                ", transition=" + transition +
                '}'
    }

    override fun name(): String {
        return "CMD_BASKETBALL_G2A"
    }
}
