package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType

class SetButtonPressParamsCmd(
    private val buttonPressMode: Int,
    private val buttonPressType: Int,
    private val optionType: List<ButtonPressParamsType>,
    private val buttonPressParams: ButtonPressParams,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            buttonPressParams,
            mRequestOptions
        )
    }
}
