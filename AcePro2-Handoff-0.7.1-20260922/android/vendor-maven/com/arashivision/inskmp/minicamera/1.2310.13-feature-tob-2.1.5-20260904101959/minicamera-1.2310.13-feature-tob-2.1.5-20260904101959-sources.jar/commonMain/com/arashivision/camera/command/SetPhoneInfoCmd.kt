package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetPhoneInfoCmd(
    private val manufacturer: String,
    private val model: String,
    private val osVersion: String
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setPhoneInfo(manufacturer, model, osVersion)
    }
}
