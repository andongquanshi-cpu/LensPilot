package com.arashivision.camera.command.ble

import com.arashivision.common.Log
import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleNotifyCallbackCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.forEachItem
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import com.arashivision.onecamera.OneDriver
import kotlinx.coroutines.runBlocking

class Go2BleWakeupCmd(
    private val mBleDevice: BleDeviceCore?,
    protected var mBleWakeUpListener: BleWakeupCallbackCore?,
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        //如果是go2，执行notify指令
        if (mBleDevice != null) {
            val bleManager = BleManagerCore
            val bluetoothGattServices = runBlocking { bleManager.getBluetoothGattServices(mBleDevice) }
            if (bluetoothGattServices == null) {
                if (mBleWakeUpListener != null) {
                    Log.i(TAG, "send notify to wake up go2 fail due to gatt services is empty")
                    mBleWakeUpListener!!.wakeupError(-2)
                }
                return null
            }
            for (service in bluetoothGattServices) {
                Log.i(TAG, "service = " + service.getUuid())
                if (service.getUuid()?.contains("be80") == true) {
                    service.getCharacteristicArray()?.forEachItem { characteristic ->
                        if (characteristic.canNotify()) {
                            bleManager.notify(
                                mBleDevice,
                                characteristic.getCharacterServiceUuid(),
                                characteristic.getCharacterUuid(),
                                object : BleNotifyCallbackCore() {
                                    override fun onNotifySuccess() {
                                        Log.i(
                                            TAG,
                                            "send notify to wake up go2 success$mBleWakeUpListener"
                                        )
                                        if (mBleWakeUpListener != null) {
                                            mBleWakeUpListener!!.wakeupSuccess()
                                        }
                                    }

                                    override fun onNotifyFailure(e: BleExceptionCore) {
                                        Log.i(
                                            TAG,
                                            "send notify to wake up go2 fail " + e.getDescription()
                                        )
                                        if (mBleWakeUpListener != null) {
                                            mBleWakeUpListener!!.wakeupError(-3)
                                        }
                                    }

                                    override fun onCharacteristicChanged(bytes: ByteArray) {
                                    }
                                })
                        }
                    }
                }
            }
        } else {
            if (mBleWakeUpListener != null) {
                Log.i(TAG, "send notify to wake up go2 fail due to listener is null")
                mBleWakeUpListener!!.wakeupError(-4)
            }
        }
        return null
    }

    companion object {
        private val TAG: String = Go2BleWakeupCmd::class.simpleName.toString()
    }
}
