package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetFlowStateCmd(private val flowStateEnable: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setFlowStateEnable(flowStateEnable)
    }
}
