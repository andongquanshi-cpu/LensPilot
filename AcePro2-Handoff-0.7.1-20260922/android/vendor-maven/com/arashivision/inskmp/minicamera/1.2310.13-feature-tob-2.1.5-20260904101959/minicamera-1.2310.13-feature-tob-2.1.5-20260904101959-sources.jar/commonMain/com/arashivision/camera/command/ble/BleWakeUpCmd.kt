package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.onecamera.OneDriver

/**
 * 唤醒相机的指令
 */
class BleWakeUpCmd(
    private val mode: Int,
    private val mDeviceName: String,
    private val mTxPowser: Byte,
    private val mBleWakeUpListener: BleWakeupCallbackCore
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        //唤醒指令为相机名的后6位
        sendWakeUpCmd()

        return null
    }

    private fun sendWakeUpCmd() {
        val bleManager = BleManagerCore
        bleManager.startWakeupAdvertise(mode, mDeviceName, mTxPowser, mBleWakeUpListener)
    }

    companion object {
        private val TAG: String = BleWakeUpCmd::class.simpleName.toString()
    }
}
