package com.arashivision.common

expect fun currentTimeMillis(): Long
expect fun elapsedRealtime(): Long

/**
 * 将传入的时间戳，转为当地时间
 * @param time 时间戳。原安卓中入参是 System.currentTimeMillis() / 1000
 * @return localTime 当地时间。
 * 例如：若 time 是 1620000000（2021-05-03 00:00:00 UTC 对应的秒级时间戳），timezone 为北京时区，那么返回值应该是 8.
 * */
expect fun formatLocalTime(time: Long): Int