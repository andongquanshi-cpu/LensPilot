package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.onecamera.OneDriver

class SetFmgTimeElapseCmd(
    private val mode: PtzTemMode,
    private val state: PtzTemState,
    private val duration: Int
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetTimeElapse(mode, state, duration)
    }
}
