package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.WifiConnectionInfo

class SetWifiStateCmd(private val info: WifiConnectionInfo, private val wifiNetState: Int) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setWifiState(info, wifiNetState)
    }
}
