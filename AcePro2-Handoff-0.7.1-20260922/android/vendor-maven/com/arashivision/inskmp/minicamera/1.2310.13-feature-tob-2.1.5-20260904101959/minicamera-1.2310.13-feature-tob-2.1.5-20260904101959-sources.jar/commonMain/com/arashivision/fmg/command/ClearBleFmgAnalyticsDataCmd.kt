package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver


/**
 * 清除 FMG 的蓝牙应用的埋点数据，区别于
 * {@link ClearFmgAnalyticsDataCmd}
 */
class ClearBleFmgAnalyticsDataCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzClearBleAnalyticsData()
    }
}
