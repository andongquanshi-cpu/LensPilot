package com.arashivision.camera.listener

interface ICameraConnectionListener {
    fun onCameraConnect()

    fun onCameraStateChange()

    fun onCameraError(error: Int)
}
