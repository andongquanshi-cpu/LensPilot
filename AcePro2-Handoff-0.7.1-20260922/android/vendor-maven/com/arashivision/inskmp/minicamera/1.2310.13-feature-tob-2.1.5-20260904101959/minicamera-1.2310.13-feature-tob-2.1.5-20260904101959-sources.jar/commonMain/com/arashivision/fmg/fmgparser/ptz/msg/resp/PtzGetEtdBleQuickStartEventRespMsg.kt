package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.BleLog
import com.arashivision.fmg.fmgparser.ByteArrayParser
import com.arashivision.fmg.fmgparser.FmgByteUtils

/**
 * FMG 蓝牙应用埋点数据展开即拍（快速开拍）埋点信息
 */
class PtzGetEtdBleQuickStartEventRespMsg : PtzDataRespMessage() {
    var quickStartEventParamsArray: Array<QuickEventParams?>? = null

    @OptIn(ExperimentalStdlibApi::class)
    override fun unpack(data: ByteArray?) {
        if (data == null) {
            return
        }
        if (data.size < DATA_COUNT_BYTES_LEN) {
            BleLog.e("unpack PtzGetEtdBleQuickStartEventRespMsg error: data len invalid - " + data.size)
            return
        }
        val count: Int = FmgByteUtils.uint16BytesToInt(data[0], data[1])
        if (count == 0) {
            BleLog.e("unpack PtzGetEtdBleQuickStartEventRespMsg count 0")
            return
        }

        quickStartEventParamsArray = arrayOfNulls<QuickEventParams>(count)
        val eventLength = (data.size - DATA_COUNT_BYTES_LEN) / count
        BleLog.d("PtzGetEtdBleQuickStartEventRespMsg unpack: count: " + count + ", data: " + data.toHexString(HexFormat.Default) + ", eventLength: " + eventLength)

        try {
            val parser: ByteArrayParser = ByteArrayParser(data, DATA_COUNT_BYTES_LEN)
            for (i in 0..<count) {
                val paramsBytes: ByteArray = parser.parseByteArray(eventLength)
                val result: Int = FmgByteUtils.byteToShort(paramsBytes[0]).toInt()
                val phoneBrand: Int = FmgByteUtils.byteToShort(paramsBytes[1]).toInt()

                // 后面还有 reserved 数据，暂不需要解析
                quickStartEventParamsArray!![i] = QuickEventParams(result, phoneBrand)
            }
        } catch (e: Exception) {
            // 固件经常返回异常数据
            BleLog.e("PtzGetEtdBleQuickStartEventRespMsg throw exception: " + e.message + ", data = " + data.toHexString(HexFormat.Default))
        }
    }

    override fun toString(): String {
        return "quickStartEventParamsArray length = " + (if (quickStartEventParamsArray != null) quickStartEventParamsArray!!.size else 0)
    }

    override fun name(): String {
        return "CMD_GET_ETD_BLE - ETD_ITEM_QUICK_START"
    }

    class QuickEventParams(
        /**
         * 快速开拍发送消息结果
         * 0：固件蓝牙发送成功
         * 1: 固件蓝牙发送失败
         */
        var result: Int,
        /**
         * 快速开拍使能厂商序号
         */
        var phoneBrand: Int,
    ) {
        /**
         * 保留字段：文档中是 6个字节
         */
        var reserved: IntArray? = null
    }

    companion object {
        private const val DATA_COUNT_BYTES_LEN = 2
    }
}