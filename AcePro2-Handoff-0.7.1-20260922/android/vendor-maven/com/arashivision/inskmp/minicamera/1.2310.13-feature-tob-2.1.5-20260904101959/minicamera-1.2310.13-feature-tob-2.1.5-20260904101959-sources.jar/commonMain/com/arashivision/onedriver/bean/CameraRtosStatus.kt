package com.arashivision.onedriver.bean


class CameraRtosStatus {
    /**
     * [com.arashivision.onecamera.OneDriverInfo.LinuxCmd.RtosStatus]
     */
    var statusCode: Int = 0
}
