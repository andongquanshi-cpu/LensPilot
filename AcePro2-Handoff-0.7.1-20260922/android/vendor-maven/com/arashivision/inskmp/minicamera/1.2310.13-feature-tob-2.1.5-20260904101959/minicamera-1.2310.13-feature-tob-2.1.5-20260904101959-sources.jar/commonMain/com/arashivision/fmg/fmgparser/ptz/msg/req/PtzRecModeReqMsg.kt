package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzRecModeReqMsg(private val status: Short) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(1)
        data[0] = status.toByte()
        return data
    }

    override fun toString(): String {
        return "status: $status"
    }

    override fun name(): String {
        return "CMD_REC_MODE"
    }
}
