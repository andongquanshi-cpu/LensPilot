package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils
import kotlin.random.Random

class PtzUpdateRebootReqMsg : PtzDataReqMessage() {
    private val data = ByteArray(6)

    override fun packData(): ByteArray? {
        Random.nextBytes(data)
        data[0] = (data[4] + data[5]).toByte()
        data[1] = (data[4] * data[5]).toByte()
        data[2] = (data[0].toInt() xor data[4].toInt()).toByte()
        data[3] = (data[1].toInt() xor data[5].toInt()).toByte()
        return data
    }

    override fun toString(): String {
        return FmgByteUtils.bytes2hex(data)
    }

    override fun name(): String {
        return "CMD_UPDATE_REBOOT"
    }
}
