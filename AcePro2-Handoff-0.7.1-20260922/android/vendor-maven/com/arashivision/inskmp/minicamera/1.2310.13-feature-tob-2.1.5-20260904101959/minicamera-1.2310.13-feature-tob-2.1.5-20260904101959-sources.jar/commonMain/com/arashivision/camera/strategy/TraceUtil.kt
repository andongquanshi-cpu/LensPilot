package com.arashivision.camera.strategy

expect object TraceUtil {
    var TRACE: Boolean
}
