package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzTrackSensitivityModeReqMsg(private val mode: Short) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(1)
        data[0] = mode.toByte()
        return data
    }

    override fun toString(): String {
        return "mode: $mode"
    }

    override fun name(): String {
        return "CMD_ETS"
    }
}
