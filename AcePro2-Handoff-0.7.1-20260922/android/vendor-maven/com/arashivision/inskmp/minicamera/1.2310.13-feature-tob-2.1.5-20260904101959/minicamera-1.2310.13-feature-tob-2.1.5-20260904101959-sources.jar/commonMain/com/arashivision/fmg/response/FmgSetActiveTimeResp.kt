package com.arashivision.fmg.response

class FmgSetActiveTimeResp(var requestID: Long)
