package com.arashivision.fmg.fmgparser.ptz

interface IDataPacket {
    val data: ByteArray?

    val crc16: Int

    val cmd: Short

    val frame: Short

    fun packetPack(data: ByteArray?): ByteArray
}
