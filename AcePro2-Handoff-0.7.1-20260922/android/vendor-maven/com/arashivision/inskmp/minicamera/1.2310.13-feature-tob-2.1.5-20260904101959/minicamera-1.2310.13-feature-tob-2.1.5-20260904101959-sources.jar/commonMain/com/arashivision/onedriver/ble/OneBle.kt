package com.arashivision.onedriver.ble

import com.arashivision.ble.OneBleIOProxy
import com.arashivision.common.BleLog
import com.arashivision.common.Log
import com.arashivision.onedriver.io.SocketIO
import com.arashivision.onedriver.packet.Go2BlePacket
import com.arashivision.onedriver.packet.Packet
import com.arashivision.onedriver.packet.PacketDemuxer
import com.arashivision.onedriver.packet.PacketType
import com.arashivision.onedriver.usb.OneUsb

/**
 * OneBle的Kotlin实现 - 对应C++版本的oneble.cpp
 *
 * 主要功能：
 * - 接收OneBleIOProxy，透传write和onWifiProxyData方法
 * - 处理数据包的解复用和通知
 * - 管理BLE状态和错误处理
 */
class OneBle(
    private val oneBleIOProxy: OneBleIOProxy,
) {
    companion object {
        private const val TAG = "OneBle"
    }

    private val packetDemuxer = PacketDemuxer()

    // 消息通知回调
    private var notifyCallback: ((Map<String, Any>) -> Unit)? = null

    /**
     * 设置消息通知回调
     * 对应C++版本的setNotify方法
     */
    fun setNotify(callback: (Map<String, Any>) -> Unit) {
        notifyCallback = callback
    }

    /**
     * 写入Packet列表
     * 对应C++版本的write方法
     */
    fun write(packets: List<Packet>): Int {
        for (packet in packets) {
            val data = packet.toBytes()
            // 透传给OneBleIOProxy
            oneBleIOProxy.onWrite(data)
        }

        return 0
    }

    /**
     * 写入Go2BlePacket列表
     * 对应C++版本的writeBle方法
     */
    fun writeBle(packets: List<Go2BlePacket>): Int {
        for (packet in packets) {
            val data = packet.getRawBuf()
            // 透传给OneBleIOProxy
            oneBleIOProxy.onWrite(data)
        }

        return 0
    }


    fun writeBleRawData(data: ByteArray) {
        oneBleIOProxy.onWrite(data)
    }

    fun onWifiProxyData(data: ByteArray) {
        oneBleIOProxy.onWifiProxyData(data)
    }

    suspend fun putData(data: ByteArray, isBleProxy: Boolean, isClassicPipe: Boolean) {
        notifyInPacket(data, isBleProxy, isClassicPipe)
    }

    /**
     * 设置BLE状态
     * 对应C++版本的setBleState方法
     */
    suspend fun setBleState(state: Int) {
        notifyAndSetError(state)
    }

    // ==================== 私有方法 ====================

    /**
     * 通知数据包接收
     * 对应C++版本的notifyInPacket方法
     */
    @OptIn(ExperimentalStdlibApi::class)
    private fun notifyInPacket(data: ByteArray, isBleProxy: Boolean, isClassicPipe: Boolean) {
//        val binary = data.joinToString(" ") { byte ->
//            byte.toInt().and(0xFF).toString(2).padStart(8, '0')
//        }
        if (!isClassicPipe) {
            BleLog.d("notifyInPacket data=${data.size}")
        }
        val packets = if (isBleProxy) { // isClassicPipe 控制字节流大小
            packetDemuxer.parseBleUcp(data, data.size, isClassicPipe)
        } else {
            packetDemuxer.parseBleUdp(data, data.size, isClassicPipe)
        }

        for (packet in packets) {
            when (packet.getPacketType()) {
                PacketType.Synchronize, PacketType.HeartBeat -> {
                    // BLE+SPP 共存:SPP 通道收到的同步包 / 心跳包,转发给 BLE,让 BLE 的握手得以完成。
                    // 转发「完整帧」(rawFrame,含 ff0641 等帧头),GO(UCP)的同步包靠帧头识别;
                    // 仅共存(isClassicPipe=SPP 通道)才转发,纯 BLE / 纯 SPP 时对端为空,等价于原来的丢弃。
                    if (isClassicPipe) {
                        notifyCallback?.invoke(
                            mapOf(
                                "what" to OneUsb.WHAT_SYNC_SPP_FORWARD,
                                "data" to (packet.rawFrame ?: packet.toBytes())
                            )
                        )
                    }
                    return
                }
                else -> {
                    // 通知上层
                    notifyCallback?.invoke(
                        mapOf(
                            "what" to OneUsb.WHAT_IN_PACKET,
                            "packet" to packet
                        )
                    )
                }
            }
        }

    }

    /**
     * 通知错误
     * 对应C++版本的notifyAndSetError方法
     */
    private suspend fun notifyAndSetError(error: Int) {
        notifyCallback?.invoke(
            mapOf(
                "what" to OneUsb.WHAT_ERROR,
                "error" to error
            )
        )
    }
}