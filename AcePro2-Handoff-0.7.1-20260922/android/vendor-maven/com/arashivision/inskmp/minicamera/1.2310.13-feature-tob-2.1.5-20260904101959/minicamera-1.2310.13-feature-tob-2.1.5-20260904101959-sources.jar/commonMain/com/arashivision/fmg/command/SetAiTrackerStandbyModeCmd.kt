package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.onecamera.OneDriver

class SetAiTrackerStandbyModeCmd(private val standbyMode: PtzAiTrackerStandbyMode) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzAiTrackerStandbyMode(standbyMode)
    }
}
