package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.onecamera.OneDriver

class SetFmgPanoIndexCmd(private val index: Short, private val frame: PtzPanoIndexFrame) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetPanoIndex(index, frame)
    }
}
