package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class HdrStopCaptureCmd(private val mExtraData: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.stopHdrCapture(mExtraData)
        return 0
    }
}
