package com.arashivision.fmg.response

class FmgGetActiveTimeResp(var requestID: Long, var activeTime: Long)
