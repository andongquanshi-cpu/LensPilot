package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 按键测试的cmd
 */
class ButtonTestCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.testButtonPress()
        return null
    }
}
