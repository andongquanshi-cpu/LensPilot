package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.IntervalRecStartStop

internal class StartStopIntervalRecCmd(private val intervalRecStartStop: IntervalRecStartStop) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.startStopIntervalRec(intervalRecStartStop)
    }
}
