package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.StopTimelapse

class StopTimelapseCmd(private val stopTimelapse: StopTimelapse) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.stopTimeplapse(stopTimelapse)
        return null
    }
}
