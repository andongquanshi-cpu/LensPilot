package com.arashivision.fmg.response

class FmgDisableHandDragResp(var requestID: Long)
