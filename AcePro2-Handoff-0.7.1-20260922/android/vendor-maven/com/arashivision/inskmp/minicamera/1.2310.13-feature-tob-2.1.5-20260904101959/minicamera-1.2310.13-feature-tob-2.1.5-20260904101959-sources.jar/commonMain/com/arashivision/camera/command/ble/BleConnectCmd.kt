package com.arashivision.camera.command.ble

import com.arashivision.ble.OneBleIOProxy
import com.arashivision.camera.InstaCameraState
import com.arashivision.camera.InstaSdkExperiment
import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.camera.command.classic.ClassicConnectData
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IWifiProxyDataListener
import com.arashivision.camera.wifiproxy.WifiProxyDataParser
import com.arashivision.common.BleLog
import com.arashivision.common.coroutines.ioScope
import com.arashivision.common.coroutines.runOnMainThread
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleGattCallbackCore
import com.arashivision.inskmp.insble.callback.BleMtuChangedCallbackCore
import com.arashivision.inskmp.insble.callback.BleNotifyCallbackCore
import com.arashivision.inskmp.insble.callback.BleWriteCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BluetoothGattCharacteristicCore
import com.arashivision.inskmp.insble.data.BluetoothGattCore
import com.arashivision.inskmp.insble.data.ConnectL2SuccessResultCore
import com.arashivision.inskmp.insble.data.forEachItem
import com.arashivision.inskmp.insble.data.setPreferredPhy
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import com.arashivision.inskmp.insble.utils.BleUtils
import com.arashivision.onecamera.OneDriver
import com.arashivision.onecamera.OneDriverInfo
import com.arashivision.onedriver.packet.Packet
import kotlinx.atomicfu.atomic
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.concurrent.Volatile
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class BleConnectCmd(
    private var mBleDevice: BleDeviceCore,
    private val bleConnectListener: IBleConnectListener?,
    private val mHeartHandler: CoroutineScope?,
    //    private byte[] syncData = {0xa,0xb,0xb,0xa,0xa,0xb,0xb,0xa,0xa,0xb,0xb,0xa,0xa,0xb,0xb,0xa,0xa,0xb,0xb,0xa};
    private val mIsHeartBeatEnable: Boolean,
    private val isUseUcd2: Boolean,
    private val mWakeUpAuthorizationUUID: String,
    private val mWifiProxyDataListener: IWifiProxyDataListener,
) : SynchronizedObject(), InstaCmdExe, OneBleIOProxy {
    private var isFail = false

    private var mOneDrvier: OneDriver? = null
    private var mWriteCharacteristic: BluetoothGattCharacteristicCore? = null

    @Volatile
    private var mHasSynced = false
    private var mHasOpenBle = false
    private var mHasNotifySuccess = false
    private var mHasNotifyConnectSuccess = false
    private var mSyncResult: SyncResult? = null
    private var isBleProxy = false

    // BLE+SPP 共存:保存 notify 阶段的连接上下文,供 SPP 转发来的 sync(forwardedSyncListener)复用握手处理
    private var mSyncBleDevice: BleDeviceCore? = null
    private var mSyncGatt: BluetoothGattCore? = null
    private var mSyncStatus: Int = 0

    private var heatJob: Job? = null
    private var job: Job? = null
    private val syncData = byteArrayOf(
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte()
    )

    // 标记当前蓝牙连接是否已经失败，即调用了 notifyBleFailStatus
    @Volatile
    private var alreadyFailed = false

    // 用于 onWrite 方法的线程安全锁
    private val writeMutex = Mutex()

    private val writeScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default.limitedParallelism(1)
    )

    // 用于 onCharacteristicChanged 方法的线程安全锁，防止数据乱序和状态竞争
    private val characteristicChangedMutex = Mutex()

    // 单线程协程作用域，用于保证 onCharacteristicChanged 回调的顺序处理
    // 使用 limitedParallelism(1) 限制并行度为 1，确保回调按照到达的顺序依次处理
    // 这是 KMP 兼容的方式，避免多线程调度导致的乱序问题
    private val characteristicChangedScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default.limitedParallelism(1)
    )

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any {
        this.mOneDrvier = oneDrvier
        // BLE+SPP 共存:注册「经 SPP 转发来的同步包/心跳包」监听(早于建链注册,避免漏接)。
        // 与 BLE 通道自身收到数据走完全相同的 handleReceivedData。
        oneDrvier?.setForwardedSyncListener { data -> handleReceivedData(data) }
        if (BleManagerCore.getBleBluetooth(mBleDevice) == null) {
            if (BleManagerCore.isConnected(mBleDevice)) {
                BleLog.w("start connect ble, bleDevice has connected, ignore.")
            }
            BleManagerCore.connect(mBleDevice, bleCallBack)
        } else bleConnectListener?.onStartFailed()
        return 0
    }

    private val bleCallBack: BleGattCallbackCore = object : BleGattCallbackCore() {
        override fun onStartConnect() {
            if (bleConnectListener == null) {
                return
            }
            bleConnectListener.onStartConnect()
        }

        override fun onConnectFail(bleDevice: BleDeviceCore, exception: BleExceptionCore) {
            if (bleConnectListener == null) {
                return
            }
            //            mOpenCountDownLatch.countDown();
            notifyBleFailStatus(bleDevice, exception)
        }

        override fun onConnectSuccess(bleDevice: BleDeviceCore, gatt: Any, status: Int) {
            if (bleConnectListener == null) {
                return
            }
            if (gatt !is BluetoothGattCore) return
            BleLog.d("connect success: ${mBleDevice.key}, status=$status")
            setPreferredPhy(gatt)

            mBleDevice = bleDevice
            BleManagerCore.setMtu(bleDevice, BLE_MTU, object : BleMtuChangedCallbackCore() {
                override fun onSetMTUFailure(exception: BleExceptionCore) {
                    BleLog.e("onSetMTUFailure")
                }

                override fun onMtuChanged(mtu: Int) {
                    BleLog.d("BleConnectCmd, onMtuChanged() called with: mtu = [$mtu]")
                    val deviceName = bleDevice.name
                    val delayMills =
                        if (!deviceName.isNullOrEmpty() && deviceName.startsWith("X3 ")) {
                            // 固件bug，X3蓝牙连接成功后立刻给相机发消息大概率会被丢
                            1000L
                        } else if (isUseUcd2) {
                            10L
                        } else {
                            200L // todo-majie 耗时
                        }
                    BleLog.d("CutDownSleep, delayMills:$delayMills")
                    //延迟150ms做notify和read
                    ioScope.launch {
                        delay(delayMills)
                        notifyAndRead(
                            bleDevice,
                            gatt,
                            status
                        )
                    }
                }
            })
        }

        override fun onDisConnected(
            isActiveDisConnected: Boolean,
            device: BleDeviceCore,
            gatt: Any,
            status: Int,
        ) {
            //            mOpenCountDownLatch.countDown();
            runOnMainThread {
                BleLog.d("dis connect")
                println("BleConnectCmd disconnectBle")
                if (mOneDrvier != null) {
                    mOneDrvier!!.setBleError(OneDriverInfo.BlueToothConstants.BleError.BLE_DISCONNECT)
                }
                if (bleConnectListener == null) {
                    return@runOnMainThread
                }
                bleConnectListener.onDisConnected(isActiveDisConnected, device, gatt, status)
            }
        }

        override fun onConnectL2Success(bleDevice: BleDeviceCore, gatt: BluetoothGattCore, status: Int): ConnectL2SuccessResultCore {
            if (bleConnectListener == null) {
                return ConnectL2SuccessResultCore();
            }
            BleLog.d("onConnectL2Success() connect success = " + mBleDevice.key + ", status = " + status);

            return bleConnectListener.onConnectL2Success(bleDevice, gatt, status);
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun notifyAndRead(bleDevice: BleDeviceCore, gatt: Any, status: Int) {
        if (alreadyFailed) {
            BleLog.w("notifyAndRead when already failed.")
            return
        }
        if (gatt !is BluetoothGattCore) return
        // BLE+SPP 共存:保存连接上下文,供 SPP 转发来的 sync 复用握手处理
        mSyncBleDevice = bleDevice
        mSyncGatt = gatt
        mSyncStatus = status
        //通过driver写完成信息
        val service = gatt.getGattServiceByIdContain(SID)
        var notifyCharacteristicSet = false
        service?.getCharacteristicArray()?.forEachItem character@{ characteristic ->
            BleLog.i("Characteristics forEach characteristic=${characteristic.getCharacterServiceUuid()}")
            if (notifyCharacteristicSet) {
                // 跳过后续的 notify 特征值
                return@character
            }
            if (characteristic.canReadAndWrite()) {
                mWriteCharacteristic = characteristic
            }

            if (characteristic.canNotify()) {
                notifyCharacteristicSet = true
                // BLE+SPP 共存:此处 mSync* 已就绪(notifyAndRead 开头已赋值),在 notify 之前即通知上层
                // 建立 SPP→BLE 转发链,尽早覆盖「相机的同步包经 SPP 早到」的窗口,避免同步包丢失导致超时。
                bleConnectListener?.onBlePhysicalConnected(bleDevice, gatt, status)
                BleManagerCore.notify(
                    bleDevice,
                    characteristic.getCharacterServiceUuid(),
                    characteristic.getCharacterUuid(),
                    object : BleNotifyCallbackCore() {
                        override fun onNotifySuccess() {
                            BleLog.d("notify success, mHasSynced=$mHasSynced, mHasOpenBle=$mHasOpenBle, ${this@BleConnectCmd}")
                            //                                mOpenCountDownLatch.countDown();
                            mHasNotifySuccess = true

                            ioScope.launch {
                                characteristicChangedMutex.withLock {
                                    if (!mHasSynced) {
                                        cancelReceiveSyncPackTimeoutRunnable()
                                        postReceiveSyncPackTimeoutRunnable(bleDevice, gatt)
                                    }
                                    if (!mHasOpenBle) {
                                        mHasOpenBle = true
                                        val ret = mOneDrvier!!.openCameraBle(this@BleConnectCmd, isUseUcd2)
                                        if (ret != 0) {
                                            BleLog.w("notify openCameraBle=$ret")
                                            val openFail: BleExceptionCore = BleExceptionCore(
                                                BleExceptionCore.ERROR_CODE_OPEN,
                                                ""
                                            )
                                            notifyBleFailStatus(bleDevice, openFail)
                                            return@launch
                                        }
                                    }

                                    if (mWakeUpAuthorizationUUID.isNotEmpty()) {
                                        mOneDrvier!!.sendWakeUpAuthorization(
                                            mWakeUpAuthorizationUUID
                                        )
                                    }

                                    tryNotifyConnectSuccess()
                                }
                            }
                        }

                        override fun onNotifyFailure(exception: BleExceptionCore) {
                            BleLog.d("notify error " + exception + ", " + this@BleConnectCmd)
                            if (exception.getCode() == BleExceptionCore.ERROR_CODE_CRASH_PRIVILEGED) {
                                notifyBleFailStatus(
                                    bleDevice,
                                    BleExceptionCore(
                                        BleExceptionCore.ERROR_CODE_CRASH_PRIVILEGED,
                                        exception.getDescription()
                                    )
                                )
                            } else if (exception.getCode() == BleExceptionCore.ERROR_CODE_THROWABLE) {
                                notifyBleFailStatus(
                                    bleDevice,
                                    BleExceptionCore(
                                        BleExceptionCore.ERROR_CODE_THROWABLE,
                                        exception.getDescription()
                                    )
                                )
                            } else {
                                notifyBleFailStatus(
                                    bleDevice,
                                    BleExceptionCore(
                                        BleExceptionCore.ERROR_CODE_NOTIFY_FAILURE,
                                        exception.getDescription()
                                    )
                                )
                            }
                            //                                mOpenCountDownLatch.countDown();
                        }

                        override fun onCharacteristicChanged(data: ByteArray) {
                            handleReceivedData(data)
                        }
                    })
                return@character
            }
        }


        if (mWriteCharacteristic == null) {
            val openFail: BleExceptionCore =
                BleExceptionCore(BleExceptionCore.ERROR_CODE_CHARACTERISTICS, "")
            notifyBleFailStatus(bleDevice, openFail)
        }
    }

    /**
     * 处理 BLE 收到的一帧数据。两个来源走完全相同的逻辑:
     *   ① BLE 通道自身收到(onCharacteristicChanged);
     *   ② BLE+SPP 共存时,SPP 转发来的同步包/心跳包(forwardedSyncListener)。
     * 实现与本需求前的 onCharacteristicChanged 内容保持一致,仅把连接上下文
     * (bleDevice/gatt/status)改为取 notifyAndRead 阶段保存的 mSync*。
     */
    private fun handleReceivedData(data: ByteArray) {
        // 使用单线程协程作用域确保回调按顺序处理
        characteristicChangedScope.launch {
            characteristicChangedMutex.withLock {
                val bleDevice = mSyncBleDevice
                val gatt = mSyncGatt
                if (mOneDrvier != null && bleDevice != null && gatt != null) {
                    if (parseWakeUpData(data)) {
                        BleLog.w("data is wake up authorization, skip check sync.")
                        return@withLock
                    }
                    if (!mHasSynced && mOneDrvier != null) {
                        cancelReceiveSyncPackTimeoutRunnable()
                        mHasSynced = true
                        val praseSync = praseSync(data)
                        BleLog.i("has sync $praseSync")
                        if (!mHasOpenBle) {
                            mHasOpenBle = true
                            val ret = mOneDrvier!!.openCameraBle(callBack = this@BleConnectCmd, isUseUcd2 = isUseUcd2)
                            if (ret != 0) {
                                BleLog.w("Characteristic openCameraBle=$ret")
                                val openFail: BleExceptionCore =
                                    BleExceptionCore(BleExceptionCore.ERROR_CODE_OPEN, "")
                                notifyBleFailStatus(bleDevice, openFail)
                                return@withLock
                            }
                        }
                        if (praseSync) {
                            mOneDrvier!!.setBleProxy(true)
                            isBleProxy = true
                        } else {
                            mOneDrvier!!.setBleProxy(false)
                            isBleProxy = false
                        }
                        if (isBleProxy) {
                            mOneDrvier!!.writeBleSync(syncData)
                        } else {
                            mOneDrvier!!.putData(data, isBleProxy)
                        }
                        val syncResult = SyncResult()
                        syncResult.bleDevice = bleDevice
                        syncResult.gatt = gatt
                        syncResult.status = mSyncStatus
                        mSyncResult = syncResult
                        tryNotifyConnectSuccess()
                    } else if (mHasSynced && mOneDrvier != null) {
                        mOneDrvier!!.putData(data, isBleProxy)
                    }
                } else {
                    BleLog.e("mOneDrvier == null or sync context not ready")
                }
            }
        }
    }

    /**
     * 解析唤醒是否成功的通知
     *
     * @param data
     * @return false：代表该data不是唤醒的通知； true：代表该data是唤醒的通知
     */
    @OptIn(ExperimentalStdlibApi::class)
    private fun parseWakeUpData(data: ByteArray): Boolean {
        val hexString = data.toHexString(HexFormat.Default)
        BleLog.d("parseWakeUpData data=" + BleUtils.printProtoBytes(hexString))
        if (hexString.isNotEmpty() && hexString.startsWith("ff0d03") && data.size >= 6) {
            if (data[5].toInt() == 0) {
                BleLog.w("wake up authorization failed")
                notifyBleFailStatus(
                    mBleDevice,
                    BleExceptionCore(
                        BleExceptionCore.ERROR_CODE_WAKE_UP_AUTHORIZATION_FAIL,
                        "wake up authorization failed"
                    )
                )
            } else if (data[5].toInt() == 1) {
                BleLog.d("wake up authorization success")
            }
            return true
        } else if (data.size >= 3 && data[0] == 0xff.toByte() && data[1] == 0x0d.toByte() && data[2] == 0x0a.toByte()) {
            // 前三字节 0xff 0x0d 0x0a：相机被其它端抢占
            BleLog.w("wake up busy (preempted), data=" + BleUtils.printProtoBytes(hexString))
            notifyBleFailStatus(
                mBleDevice,
                BleExceptionCore(
                    BleExceptionCore.ERROR_CODE_ERROR_CODE_OPEN_BUSY,
                    "wake up busy"
                )
            )
            return true
        } else if ("ff0640080008000000b00000016d90" == hexString) {
            // 蓝牙 busy
            BleLog.d("ble is busy")
        }
        return false
    }

    /**
     * 解析同步包
     *
     * @param data
     */
    @OptIn(ExperimentalStdlibApi::class)
    private fun praseSync(data: ByteArray): Boolean {
        val hexString = data.toHexString(HexFormat.Default)
        if (hexString.isNotEmpty() && hexString.startsWith("ff0641")) {
            //write data to ble
            return true
        }
        return false
    }

    /**
     * 蓝牙打开后jni回调，写数据，将数据写到蓝牙中
     */
    @OptIn(ExperimentalStdlibApi::class)
    override fun onWrite(mData: ByteArray) {
        writeScope.launch {
            writeMutex.withLock {
                val dataHexString = mData.toHexString(HexFormat.Default)

                BleLog.d("$TAG onWrite ble key=" + mBleDevice.key + ", data=" + dataHexString)
                if (mWriteCharacteristic == null) {
                    getRwCharacteristic()
                }

                if (mWriteCharacteristic != null) {
                    var offset = 0
                    isFail = false
                    while (!isFail && offset < mData.size) {
                        val writeLen = if ((offset + BLE_WRITE_MAX_LEN) > mData.size)
                            (mData.size - offset) else BLE_WRITE_MAX_LEN
                        val mBleWrite = ByteArray(writeLen)
                        mData.copyInto(mBleWrite, startIndex = offset, endIndex = offset + writeLen)
                        BleLog.d("offset = $offset, len = $writeLen")
                        var isResumed = atomic(false)  // 添加标志位
                        suspendCoroutine { continuation ->
                            BleManagerCore.write(
                                mBleDevice,
                                mWriteCharacteristic!!.getCharacterServiceUuid(),
                                mWriteCharacteristic!!.getCharacterUuid(),
                                0x02, // BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                                mBleWrite,
                                false,
                                false,
                                object : BleWriteCallbackCore() {
                                    override fun onWriteSuccess(
                                        current: Int,
                                        total: Int,
                                        justWrite: ByteArray?,
                                    ) {
                                        BleLog.d("write success")
                                        val bleHeartDelayExperiment =
                                            InstaSdkExperiment.bleHeartDelayExperiment
                                        if (bleHeartDelayExperiment > 0) {
                                            if ("ff07400700070000000500006b46" == dataHexString ||
                                                "07000000050000" == dataHexString
                                            ) {
                                                writeSendHeartBeat(bleHeartDelayExperiment)
                                            }
                                        }
                                        if (!isResumed.value) {
                                            isResumed.value = true
                                            continuation.resume(Unit)
                                        }
                                    }

                                    override fun onWriteFailure(exception: BleExceptionCore) {
                                        BleLog.d("write error $exception, ${this@BleConnectCmd}")
                                        bleConnectListener?.onWriteFailed(mBleDevice, exception)
                                        isFail = true
                                        if (!isResumed.value) {
                                            isResumed.value = true
                                            continuation.resume(Unit)
                                        }
                                    }
                                }
                            )
                        }

                        offset += writeLen
                    }
                }
            }
        }
    }


    override fun onWifiProxyData(proxyData: ByteArray) {
        val wifiProxyData = WifiProxyDataParser.parse(proxyData, Packet.useUcd2)
        if (wifiProxyData != null) {
            mWifiProxyDataListener.onReadWifiProxyData(wifiProxyData)
        } else {
            BleLog.e("WifiProxyDataParser failed")
        }
    }

    private suspend fun getRwCharacteristic() {
        val bluetoothGatt =
            BleManagerCore.getBluetoothGatt(mBleDevice)
        if (bluetoothGatt != null) {
            val service = bluetoothGatt.getGattServiceByIdContain(SID)
            service?.getCharacteristicArray()?.forEachItem { characteristic ->
                if (characteristic.canReadAndWrite()) {
                    BleLog.d(
                        "get rw characteristic empty ,set characteristic"
                    )
                    mWriteCharacteristic = characteristic
                }
            }
        }
    }

//
//    private fun checkCameraTurnon(): Boolean {
//        var check = true
//        val scanRecord = mBleDevice.scanRecord
//        val adStructures = AdvertiseUtil.parseBleAdData(scanRecord)
//        if (!adStructures.isEmpty()) {
//            //获取相机是否关机
//            for (ad in adStructures) {
//                Log.i(TAG, "ad = $ad")
//                //判断type为ff的广播，data最后两位
//                if ("ff".equals(ad.type, ignoreCase = true)) {
//                    //每两位转换成对应的ascii码
//                    var asciiToString = ad.data
//                    Log.i(TAG, "ascii string = $asciiToString")
//                    asciiToString = asciiToString.substring(asciiToString.length - 2)
//                    //获取最后两位，如果为00 代表关机，01代表开机
//                    if (asciiToString.equals("00", ignoreCase = true)) {
//                        check = false
//                    }
//                }
//            }
//        }
//        return check
//    }

    private fun tryNotifyConnectSuccess() {
        //发送心跳包
        if (mHeartHandler != null && mOneDrvier != null && mIsHeartBeatEnable && mHasSynced && heatJob?.isActive != true) {
            heatJob = mHeartHandler.launch {
                delay(1500)
                mOneDrvier?.sendHeartBeat()
                if (InstaSdkExperiment.bleHeartDelayExperiment <= 0) {
                    repeat(Int.MAX_VALUE) {
                        delay(1000)
                        mOneDrvier?.sendHeartBeat()
                    }
                }
            }
        }
        if (mHasNotifySuccess && mSyncResult != null && !mHasNotifyConnectSuccess) {
            mHasNotifyConnectSuccess = true
            notifyBleSuccessStatus(
                mSyncResult!!.bleDevice,
                mSyncResult!!.gatt,
                mSyncResult!!.status
            )
        }
    }

    private fun writeSendHeartBeat(bleHeartDelayExperiment: Long) {
        if (mHeartHandler != null && mOneDrvier != null && mIsHeartBeatEnable && heatJob?.isActive != true
        ) {
            heatJob = mHeartHandler.launch {
                delay(bleHeartDelayExperiment)
                mOneDrvier?.sendHeartBeat()
                if (bleHeartDelayExperiment <= 0) {
                    repeat(Int.MAX_VALUE) {
                        delay(1000)
                        mOneDrvier?.sendHeartBeat()
                    }
                }
            }
        }
    }

    private fun notifyBleSuccessStatus(
        bleDevice: BleDeviceCore?,
        gatt: BluetoothGattCore?,
        status: Int,
    ) {
        runOnMainThread { bleConnectListener!!.onConnectSuccess(bleDevice, gatt, status) }
        InstaCameraState.create().changeState(InstaCameraState.OPEN_COMPLETE)
    }

    private fun notifyBleFailStatus(bleDevice: BleDeviceCore, bleException: BleExceptionCore) {
        if (alreadyFailed) {
            BleLog.w("notifyBleFailStatus when already failed.")
            return
        }
        alreadyFailed = true
        cancelReceiveSyncPackTimeoutRunnable()
        runOnMainThread { bleConnectListener!!.onConnectFail(bleDevice, bleException) }
        InstaCameraState.create().changeState(InstaCameraState.ERROR)
    }

    private fun postReceiveSyncPackTimeoutRunnable(
        bleDevice: BleDeviceCore,
        gatt: BluetoothGattCore,
    ) {
        job = ioScope.launch {
            delay(5000)
            val openFail: BleExceptionCore =
                BleExceptionCore(BleExceptionCore.ERROR_CODE_SYNC_PACK, "")
            notifyBleFailStatus(bleDevice, openFail)
        }

    }

    private fun cancelReceiveSyncPackTimeoutRunnable() {
        job?.cancel()
    }

    private class SyncResult {
        var bleDevice: BleDeviceCore? = null
        var gatt: BluetoothGattCore? = null
        var status: Int = 0
    }

    companion object {
        private val TAG: String = BleConnectCmd::class.simpleName.toString()
        private const val BLE_MTU = 256
        private const val BLE_WRITE_MAX_LEN = BLE_MTU - 50

        private const val SID = "be80"
    }
}

