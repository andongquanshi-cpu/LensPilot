package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzPanoReqMsg(
//uint_8
    private val status: Short, //uint_8
    private val type: Short, //yaw int_16
    private val x_angle: Short, //pitch int_16
    private val y_angle: Short
) :
    PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(6)
        data[0] = status.toByte()
        data[1] = type.toByte()
        val yawArray = FmgByteUtils.shortToInt16ByteArray(x_angle)
        val pitchArray = FmgByteUtils.shortToInt16ByteArray(y_angle)
        yawArray.copyInto(data, 2, 0, yawArray.size)
        pitchArray.copyInto(data, 4, 0, pitchArray.size)
        return data
    }

    override fun toString(): String {
        return "status" + status + "type" + type + "yaw" + x_angle + "pitch" + y_angle
    }

    override fun name(): String {
        return "CMD_PANO"
    }
}
