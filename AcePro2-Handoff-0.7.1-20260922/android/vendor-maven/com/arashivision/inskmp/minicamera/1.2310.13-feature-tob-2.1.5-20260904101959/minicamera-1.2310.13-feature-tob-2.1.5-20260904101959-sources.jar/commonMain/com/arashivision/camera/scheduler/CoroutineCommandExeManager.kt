package com.arashivision.camera.scheduler

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.common.Log
import com.arashivision.onecamera.OneDriver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive

/**
 * 基于协程的命令执行管理器
 * 提供优雅的异步命令执行能力，支持流式处理和批量操作
 */
class CoroutineCommandExeManager(
    private val scheduler: CoroutineSchedulers = CoroutineCommandScheduler(),
) {

    private var isReleased = false

    /**
     * 异步执行命令（在协程中执行并等待结果）
     * @param oneDriver 相机驱动
     * @param delay 延迟时间（毫秒）
     * @param instaCmdExes 要执行的命令
     * @return 执行结果
     */
    suspend fun exeCommand(
        oneDriver: OneDriver?,
        delay: Long = 0L,
        vararg instaCmdExes: InstaCmdExe?,
    ): Any? {
        if (oneDriver == null) {
            Log.w(TAG, "OneDriver is null, command execution cancelled")
            return null
        }
        return try {
            scheduler.scheduleDirect(oneDriver, delay, *instaCmdExes)
        } catch (e: Exception) {
            Log.e(TAG, "Command execution failed $e")
            throw e
        }
    }

    /**
     * 同步执行命令（挂起函数）
     * @param oneDriver 相机驱动
     * @param delay 延迟时间（毫秒）
     * @param instaCmdExes 要执行的命令
     * @return 执行结果
     */
    fun exeCommandSync(
        oneDriver: OneDriver?,
        delay: Long = 0L,
        vararg instaCmdExes: InstaCmdExe?,
    ) {
        if (oneDriver == null) {
            Log.w(TAG, "OneDriver is null, command execution cancelled")
            return
        }

        scheduler.scheduleDirectSync(oneDriver, delay, *instaCmdExes)

    }

    /**
     * 批量执行命令
     * @param oneDriver 相机驱动
     * @param commands 命令列表
     * @param delay 每个命令间的延迟
     * @return 执行结果流
     */
    fun exeCommandsBatch(
        oneDriver: OneDriver?,
        commands: List<InstaCmdExe>,
        delay: Long = 0L,
    ): Flow<Any?> = flow {
        if (oneDriver == null) {
            Log.w(TAG, "OneDriver is null, batch execution cancelled")
            return@flow
        }

        for (command in commands) {
            try {
                val result = scheduler.scheduleDirectSync(oneDriver, delay, command)
                emit(result)
            } catch (e: Exception) {
                Log.e(TAG, "Batch command execution failed $e")
                throw e
            }
        }
    }.flowOn(Dispatchers.IO)

    /**
     * 带重试的命令执行
     * @param oneDriver 相机驱动
     * @param command 要执行的命令
     * @param maxRetries 最大重试次数
     * @param retryDelay 重试延迟
     * @return 执行结果
     */
    suspend fun exeCommandWithRetry(
        oneDriver: OneDriver?,
        command: InstaCmdExe,
        maxRetries: Int = 3,
        retryDelay: Long = 1000L,
    ): Any? {
        if (oneDriver == null) {
            Log.w(TAG, "OneDriver is null, retry execution cancelled")
            return null
        }

        var lastException: Exception? = null

        repeat(maxRetries) { attempt ->
            try {
                return scheduler.scheduleDirectSync(oneDriver, 0L, command)
            } catch (e: Exception) {
                lastException = e
                Log.w(TAG, "Command execution attempt ${attempt + 1} failed $e")

                if (attempt < maxRetries - 1) {
                    delay(retryDelay)
                }
            }
        }

        Log.e(TAG, "Command execution failed after $maxRetries attempts")
        throw lastException ?: Exception("Command execution failed")
    }

    /**
     * 创建命令执行流
     * @param oneDriver 相机驱动
     * @param command 要执行的命令
     * @param interval 执行间隔
     * @return 结果流
     */
    fun exeCommandFlow(
        oneDriver: OneDriver?,
        command: InstaCmdExe,
        interval: Long = 1000L,
    ): Flow<Any?> = flow {
        if (oneDriver == null) {
            Log.w(TAG, "OneDriver is null, flow execution cancelled")
            return@flow
        }

        while (currentCoroutineContext().isActive) {
            try {
                val result = scheduler.scheduleDirectSync(oneDriver, 0L, command)
                emit(result)
                delay(interval)
            } catch (e: Exception) {
                Log.e(TAG, "Flow command execution failed $e")
                throw e
            }
        }
    }.flowOn(Dispatchers.IO)

    /**
     * 释放资源
     */
    fun release() {
        if (!isReleased) {
            isReleased = true
            scheduler.release()
            Log.d(TAG, "CoroutineCommandExeManager released")
        }
    }

    companion object {
        private const val TAG = "CoroutineCommandExeManager"
    }
}
