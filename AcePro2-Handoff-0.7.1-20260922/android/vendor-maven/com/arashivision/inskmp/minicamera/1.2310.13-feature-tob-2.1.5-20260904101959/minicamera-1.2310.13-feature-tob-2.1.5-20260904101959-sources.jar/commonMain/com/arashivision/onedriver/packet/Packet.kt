// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/Packet.kt
package com.arashivision.onedriver.packet

import insta360.messages.EncryptScheme
import insta360.messages.MessageCode
import kotlinx.atomicfu.atomic

/**
 * 数据包类 - 对应C++中的Packet类
 * 直接持有RawBuf，与C++版本保持一致
 */


/**
 * UCD 1.0 协议：现状，参考文档： https://arashivision.feishu.cn/wiki/wikcnsNYQBmlmJBpOMZkXT7dSDf
 * +--------+------+----------------+-----------+---------+
 * | Length | Type | padding-length |  payload  | padding |
 * +--------+------+----------------+-----------+---------+
 * |   32   |  8   |       16       |           |         |
 * +--------+------+----------------+-----------+---------+
 */


/**
 * UCD 2.0 协议：AIPL统一平台， 参考文档： https://arashivision.feishu.cn/docx/FBacdod8bo0EDWxMt73cHLR1nff
 * +-------+---------+----------------+-------+------------+
 * | magic | version | header_length  |  type | sequence   |
 * +-------+---------+----------------+-------+------------+
 * |   32  |  8      |       8        |   8   |     8      |
 * +---------------+-------------+---------+---------+-----+
 * | payload_len   | options     | payload |      CRC      |
 * +---------------+-------------+---------+---------------+
 * |   32          |             |         |      32       |
 * +---------------+-------------+---------+---------------+
 */

class Packet private constructor(
    private val rawBuf: ByteArray,
) {
    /**
     * BLE+SPP 共存:拆包时保留的「完整原始帧」(含 ff0641 等帧头 + 尾部 CRC)。
     * rawBuf 是剥掉帧头后的本体,而 GO(UCP)的 sync 判定 praseSync 需要带帧头的完整帧,
     * 故在 parseBleUcp 拆包时把完整帧记到这里,供 SPP→BLE 转发使用。默认 null。
     */
    var rawFrame: ByteArray? = null

    // 消息相关字段（当type为Message时有效）
    val messageMethod: MessageCode? get() = if (getPacketType() == PacketType.Message) parseMessageMethod() else null
    val messageContentType: MessageContentType? get() = if (getPacketType() == PacketType.Message) parseMessageContentType() else null
    val messageEndFlag: Int? get() = if (getPacketType() == PacketType.Message) parseMessageEndFlag() else null
    val messageDirection: MessageDirection? get() = if (getPacketType() == PacketType.Message) parseMessageDirection() else null
    val messageId: Long? get() = if (getPacketType() == PacketType.Message) parseMessageId() else null
    val messageContent: ByteArray? get() = if (getPacketType() == PacketType.Message) parseMessageContent() else null

    // 流相关字段（当type为Stream时有效）
    val streamType: StreamType? get() = if (getPacketType() == PacketType.Stream) parseStreamType() else null
    val streamTimestamp: Long? get() = if (getPacketType() == PacketType.Stream) parseStreamTimestamp() else null
    val streamData: ByteArray? get() = if (getPacketType() == PacketType.Stream) parseStreamData() else null

    // Linux命令相关字段（当type为LinuxCmd时有效）
    val linuxCmdCmd: LinuxCmdCmd? get() = if (getPacketType() == PacketType.LinuxCmd) parseLinuxCmdCmd() else null
    val linuxCmdDirection: LinuxCmdDirection? get() = if (getPacketType() == PacketType.LinuxCmd) parseLinuxCmdDirection() else null
    val linuxCmdContent: Int? get() = if (getPacketType() == PacketType.LinuxCmd) parseLinuxCmdContent() else null

    // 隧道相关字段（当type为SocketTunnel时有效）
    val tunnelConnectionId: Int get() = if (getPacketType() == PacketType.SocketTunnel) parseTunnelConnectionId() else 0
    val tunnelFlags: Int get() = if (getPacketType() == PacketType.SocketTunnel) parseTunnelFlags() else 0
    val tunnelWindowLimit: Long get() = if (getPacketType() == PacketType.SocketTunnel) parseTunnelWindowLimit() else 0L
    val tunnelContent: ByteArray get() = if (getPacketType() == PacketType.SocketTunnel) parseTunnelContent() else ByteArray(0)

    /**
     * 获取包类型
     */
    fun getPacketType(): PacketType {
        val data = rawBuf
        if (useUcd2) {
            if (data.size < 7) return PacketType.HeartBeat
            return PacketType.fromValue(data[6].toInt() and 0xFF) ?: PacketType.HeartBeat
        }
        if (data.size < 5) return PacketType.HeartBeat
        return PacketType.fromValue(data[4].toInt() and 0xFF) ?: PacketType.HeartBeat
    }

    /**
     * 获取包长度（不含padding）
     */
    fun getPacketLengthWithoutPadding(): Int {
        return getPacketLengthBesidesPadding() - getPacketPaddingLength()
    }

    /**
     * 获取包长度（含padding）
     */
    fun getPacketLengthBesidesPadding(): Int {
        val data = rawBuf
        if (useUcd2) {
            if (data.size < 12) return 0
            val headerLength = data[5].toInt() and 0xFF
            val payloadLen = (data[8].toInt() and 0xFF) or
                    ((data[9].toInt() and 0xFF) shl 8) or
                    ((data[10].toInt() and 0xFF) shl 16) or
                    ((data[11].toInt() and 0xFF) shl 24)
            return headerLength + payloadLen + 4 // + CRC
        }
        if (data.size < 4) return 0
        return (data[0].toInt() and 0xFF) or
                ((data[1].toInt() and 0xFF) shl 8) or
                ((data[2].toInt() and 0xFF) shl 16) or
                ((data[3].toInt() and 0xFF) shl 24)
    }

    /**
     * 获取padding长度
     */
    fun getPacketPaddingLength(): Int {
        val data = rawBuf
        if (useUcd2) {
            return 0 // ucd2 格式没有 padding
        }
        if (data.size < 7) return 0
        return (data[5].toInt() and 0xFF) or ((data[6].toInt() and 0xFF) shl 8)
    }

    /**
     * 获取完整的包数据（包含包头）
     */
    fun toBytes(): ByteArray = rawBuf

    companion object {
        // UCD2 magic number (小端序: 0x32444355 -> "UCD2")
        val ucd2Magic = byteArrayOf(0x55, 0x43, 0x44, 0x32)

        // UCD2 协议使用标志
        var useUcd2: Boolean = false

        // 全局解密参数（由上层设置）
        var decryptParams: PacketDecryptParams? = null

        // 全局加密参数（由上层设置，仅对标记需要加密的消息生效）
        var encryptParams: PacketEncryptionParams? = null

        // UCD2 序列号（1-255循环）
        private val ucd2Sequence = atomic(1)

        // UCD2 固定头部长度
        private const val PACKET_FIXED_HEADER_LEN = 12

        // CRC32 查找表
        val CRC32_TABLE: IntArray = intArrayOf(
            0x00000000, 0x04C11DB7, 0x09823B6E, 0x0D4326D9, 0x130476DC, 0x17C56B6B,
            0x1A864DB2, 0x1E475005, 0x2608EDB8, 0x22C9F00F, 0x2F8AD6D6, 0x2B4BCB61,
            0x350C9B64, 0x31CD86D3, 0x3C8EA00A, 0x384FBDBD, 0x4C11DB70, 0x48D0C6C7,
            0x4593E01E, 0x4152FDA9, 0x5F15ADAC, 0x5BD4B01B, 0x569796C2, 0x52568B75,
            0x6A1936C8, 0x6ED82B7F, 0x639B0DA6, 0x675A1011, 0x791D4014, 0x7DDC5DA3,
            0x709F7B7A, 0x745E66CD, -0x67dc4920, -0x631d54a9, -0x6e5e7272, -0x6a9f6fc7,
            -0x74d83fc4, -0x70192275, -0x7d5a04ae, -0x799b191b, -0x41d4a4a8, -0x4515b911,
            -0x48569fca, -0x4c97827f, -0x52d0d27c, -0x5611cfcd, -0x5b52e916, -0x5f93f4a3,
            -0x2bcd9270, -0x2f0c8fd9, -0x224fa902, -0x268eb4b7, -0x38c9e4b4, -0x3c08f905,
            -0x314bdfde, -0x358ac26b, -0xdc57fd8, -0x9046261, -0x44744ba, -0x86590f,
            -0x1ec1090c, -0x1a0014bd, -0x17433266, -0x13822fd3, 0x34867077, 0x30476DC0,
            0x3D044B19, 0x39C556AE, 0x278206AB, 0x23431B1C, 0x2E003DC5, 0x2AC12072,
            0x128E9DCF, 0x164F8078, 0x1B0CA6A1, 0x1FCDBB16, 0x018AEB13, 0x054BF6A4,
            0x0808D07D, 0x0CC9CDCA, 0x7897AB07, 0x7C56B6B0, 0x71159069, 0x75D48DDE,
            0x6B93DDDB, 0x6F52C06C, 0x6211E6B5, 0x66D0FB02, 0x5E9F46BF, 0x5A5E5B08,
            0x571D7DD1, 0x53DC6066, 0x4D9B3063, 0x495A2DD4, 0x44190B0D, 0x40D816BA,
            -0x535a3969, -0x579b24e0, -0x5ad80207, -0x5e191fb2, -0x405e4fb5, -0x449f5204,
            -0x49dc74db, -0x4d1d696e, -0x7552d4d1, -0x7193c968, -0x7cd0efbf, -0x7811f20a,
            -0x6656a20d, -0x6297bfbc, -0x6fd49963, -0x6b1584d6, -0x1f4be219, -0x1b8affb0,
            -0x16c9d977, -0x1208c4c2, -0xc4f94c5, -0x88e8974, -0x5cdafab, -0x10cb21e,
            -0x39430fa1, -0x3d821218, -0x30c134cf, -0x3400297a, -0x2a47797d, -0x2e8664cc,
            -0x23c54213, -0x27045fa6, 0x690CE0EE, 0x6DCDFD59, 0x608EDB80, 0x644FC637,
            0x7A089632, 0x7EC98B85, 0x738AAD5C, 0x774BB0EB, 0x4F040D56, 0x4BC510E1,
            0x46863638, 0x42472B8F, 0x5C007B8A, 0x58C1663D, 0x558240E4, 0x51435D53,
            0x251D3B9E, 0x21DC2629, 0x2C9F00F0, 0x285E1D47, 0x36194D42, 0x32D850F5,
            0x3F9B762C, 0x3B5A6B9B, 0x0315D626, 0x07D4CB91, 0x0A97ED48, 0x0E56F0FF,
            0x1011A0FA, 0x14D0BD4D, 0x19939B94, 0x1D528623, -0xed0a9f2, -0xa11b447,
            -0x75292a0, -0x3938f29, -0x1dd4df2e, -0x1915c29b, -0x1456e444, -0x1097f9f5,
            -0x28d8444a, -0x2c1959ff, -0x215a7f28, -0x259b6291, -0x3bdc3296, -0x3f1d2f23,
            -0x325e09fc, -0x369f144d, -0x42c17282, -0x46006f37, -0x4b4349f0, -0x4f825459,
            -0x51c5045e, -0x550419eb, -0x58473f34, -0x5c862285, -0x64c99f3a, -0x6008828f,
            -0x6d4ba458, -0x698ab9e1, -0x77cde9e6, -0x730cf453, -0x7e4fd28c, -0x7a8ecf3d,
            0x5D8A9099, 0x594B8D2E, 0x5408ABF7, 0x50C9B640, 0x4E8EE645, 0x4A4FFBF2,
            0x470CDD2B, 0x43CDC09C, 0x7B827D21, 0x7F436096, 0x7200464F, 0x76C15BF8,
            0x68860BFD, 0x6C47164A, 0x61043093, 0x65C52D24, 0x119B4BE9, 0x155A565E,
            0x18197087, 0x1CD86D30, 0x029F3D35, 0x065E2082, 0x0B1D065B, 0x0FDC1BEC,
            0x3793A651, 0x3352BBE6, 0x3E119D3F, 0x3AD08088, 0x2497D08D, 0x2056CD3A,
            0x2D15EBE3, 0x29D4F654, -0x3a56d987, -0x3e97c432, -0x33d4e2e9, -0x3715ff60,
            -0x2952af5b, -0x2d93b2ee, -0x20d09435, -0x24118984, -0x1c5e343f, -0x189f298a,
            -0x15dc0f51, -0x111d12e8, -0xf5a42e3, -0xb9b5f56, -0x6d8798d, -0x219643c,
            -0x764702f7, -0x72861f42, -0x7fc53999, -0x7b042430, -0x6543742b, -0x6182699e,
            -0x6cc14f45, -0x680052f4, -0x504fef4f, -0x548ef2fa, -0x59cdd421, -0x5d0cc998,
            -0x434b9993, -0x478a8426, -0x4ac9a2fd, -0x4e08bf4c
        )

        // UCD2 加密选项类型
        private const val OPTION_TYPE_ENCRYPT: Byte = 0x40

        // 加密选项数据长度: scheme(1) + nonce(12) + authTag(16) = 29
        private const val ENCRYPT_OPTION_DATA_LEN_AES_GCM = 29
        // XOR 加密选项数据长度: scheme(1) = 1
        private const val ENCRYPT_OPTION_DATA_LEN_XOR = 1

        /**
         * 获取下一个 UCD2 序列号（1-255循环）
         */
        private fun nextUcd2Sequence(): Int {
            val current = ucd2Sequence.getAndIncrement()
            val result = if (current > 255) {
                ucd2Sequence.value = 1
                1
            } else {
                current
            }
            return result
        }

        private fun buildUcd2Frame(
            type: PacketType,
            payload: ByteArray,
            options: ByteArray? = null,
        ): Packet {
            return buildUcd2FrameWithSeq(type, payload, options, nextUcd2Sequence())
        }

        private fun buildUcd2FrameWithSeq(
            type: PacketType,
            payload: ByteArray,
            options: ByteArray?,
            sequence: Int,
        ): Packet {
            val headerLength = PACKET_FIXED_HEADER_LEN + (options?.size ?: 0)
            val totalSize = headerLength + payload.size
            val data = ByteArray(totalSize + 4)
            data[0] = 0x55; data[1] = 0x43; data[2] = 0x44; data[3] = 0x32
            data[4] = 0x01
            data[5] = headerLength.toByte()
            data[6] = type.value.toByte()
            data[7] = sequence.toByte()
            data[8] = (payload.size and 0xFF).toByte()
            data[9] = ((payload.size shr 8) and 0xFF).toByte()
            data[10] = ((payload.size shr 16) and 0xFF).toByte()
            data[11] = ((payload.size shr 24) and 0xFF).toByte()
            options?.copyInto(data, PACKET_FIXED_HEADER_LEN)
            payload.copyInto(data, headerLength)
            val crc = crc32(data, totalSize, 0)
            data[totalSize] = (crc and 0xFF).toByte()
            data[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
            data[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
            data[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()
            return fromBytesRaw(data)
        }

        private fun buildEncryptOptions(scheme: EncryptScheme, encResult: PacketEncryptResult): ByteArray {
            return if (scheme == EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128) {
                val opts = ByteArray(2 + ENCRYPT_OPTION_DATA_LEN_AES_GCM)
                opts[0] = OPTION_TYPE_ENCRYPT
                opts[1] = ENCRYPT_OPTION_DATA_LEN_AES_GCM.toByte()
                opts[2] = scheme.value.toByte()
                encResult.nonce!!.copyInto(opts, 3)
                encResult.authTag!!.copyInto(opts, 15)
                opts
            } else {
                byteArrayOf(OPTION_TYPE_ENCRYPT, ENCRYPT_OPTION_DATA_LEN_XOR.toByte(), scheme.value.toByte())
            }
        }

        /**
         * 计算 CRC32 校验值
         */
        fun crc32(data: ByteArray, size: Int, initCrc: Int = 0): Int {
            var reg = 0xFFFFFFFF.toInt()
            for (n in 0 until size) {
                reg = reg xor (data[n].toInt() and 0xFF)
                for (i in 0 until 4) {
                    val tmp = CRC32_TABLE[(reg ushr 24) and 0xFF]
                    reg = (reg shl 8) xor tmp
                }
            }
            return reg
        }

        /**
         * 判断数据是否是 ucd2.0
         */
        fun isUcd2(buf: ByteArray): Boolean {
            if (buf.size < 4) {
                return false
            }
            for (i in 0 until 4) {
                if (buf[i] != ucd2Magic[i]) {
                    return false
                }
            }
            return true
        }

        /**
         * 从字节数组创建Packet
         */
        fun fromBytes(data: ByteArray): Packet? {
            if (!useUcd2 || data.size < PACKET_FIXED_HEADER_LEN + 4) return Packet(data)
            val headerLength = data[5].toInt() and 0xFF
            if (headerLength <= PACKET_FIXED_HEADER_LEN) return Packet(data)

            val encryptInfo = parseEncryptOption(data, PACKET_FIXED_HEADER_LEN, headerLength)
                ?: return Packet(data)
            if (encryptInfo.scheme == EncryptScheme.ENCRYPT_SCHEME_NONE.value) return Packet(data)

            val params = decryptParams ?: run {
                com.arashivision.common.Log.e(
                    "Packet",
                    "fromBytes: encrypted frame but decryptParams is null, scheme=${encryptInfo.scheme}"
                )
                return Packet(data)
            }

            val ciphertext = data.copyOfRange(headerLength, data.size - 4)
            val plaintext = try {
                val aad = data.copyOfRange(0, PACKET_FIXED_HEADER_LEN)
                @OptIn(ExperimentalStdlibApi::class)
                com.arashivision.common.Log.d(
                    "Packet",
                    "decrypt[scheme=${encryptInfo.scheme}] " +
                        "aadHex=${aad.toHexString(HexFormat.UpperCase)} " +
                        "nonceHex=${encryptInfo.nonce?.toHexString(HexFormat.UpperCase)} " +
                        "tagHex=${encryptInfo.authTag?.toHexString(HexFormat.UpperCase)} " +
                        "ctLen=${ciphertext.size}"
                )
                params.decrypt(ciphertext, aad, encryptInfo.nonce, encryptInfo.authTag)
            } catch (e: Exception) {
                com.arashivision.common.Log.e(
                    "Packet",
                    "fromBytes: decrypt failed, scheme=${encryptInfo.scheme}, error=${e.message}"
                )
                return Packet(data)
            }

            // 重组为等价的明文 UCD2 帧：保留前 12B 基础帧头，去掉 Options，
            // headerLength 改回 12，payloadLen 改为明文长度，重算 CRC32。
            val totalSize = PACKET_FIXED_HEADER_LEN + plaintext.size
            val rebuilt = ByteArray(totalSize + 4)
            data.copyInto(rebuilt, 0, 0, PACKET_FIXED_HEADER_LEN)
            rebuilt[5] = PACKET_FIXED_HEADER_LEN.toByte()
            rebuilt[8] = (plaintext.size and 0xFF).toByte()
            rebuilt[9] = ((plaintext.size shr 8) and 0xFF).toByte()
            rebuilt[10] = ((plaintext.size shr 16) and 0xFF).toByte()
            rebuilt[11] = ((plaintext.size shr 24) and 0xFF).toByte()
            plaintext.copyInto(rebuilt, PACKET_FIXED_HEADER_LEN)
            val crc = crc32(rebuilt, totalSize, 0)
            rebuilt[totalSize] = (crc and 0xFF).toByte()
            rebuilt[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
            rebuilt[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
            rebuilt[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()
            return Packet(rebuilt)
        }

        // 内部组装路径专用：跳过解密。发送侧拼好密文帧后回封装为 Packet 实例时使用，避免"加密一次解密一次"。
        internal fun fromBytesRaw(data: ByteArray): Packet = Packet(data)

        private data class EncryptOptionInfo(val scheme: Int, val nonce: ByteArray?, val authTag: ByteArray?)

        private fun parseEncryptOption(buf: ByteArray, optionsStart: Int, headerLength: Int): EncryptOptionInfo? {
            var offset = optionsStart
            while (offset + 2 <= headerLength) {
                val optType = buf[offset]
                val optLen = buf[offset + 1].toInt() and 0xFF
                if (optType == OPTION_TYPE_ENCRYPT && optLen > 0) {
                    val scheme = buf[offset + 2].toInt() and 0xFF
                    return when {
                        scheme == EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128.value && optLen >= ENCRYPT_OPTION_DATA_LEN_AES_GCM -> {
                            val nonce = buf.copyOfRange(offset + 3, offset + 3 + 12)
                            val authTag = buf.copyOfRange(offset + 15, offset + 15 + 16)
                            EncryptOptionInfo(scheme, nonce, authTag)
                        }
                        scheme == EncryptScheme.ENCRYPT_SCHEME_XOR.value -> EncryptOptionInfo(scheme, null, null)
                        scheme == EncryptScheme.ENCRYPT_SCHEME_NONE.value -> EncryptOptionInfo(scheme, null, null)
                        else -> {
                            com.arashivision.common.Log.e("Packet", "parseEncryptOption: unknown scheme=$scheme")
                            EncryptOptionInfo(scheme, null, null)
                        }
                    }
                }
                offset += 2 + optLen
            }
            return null
        }


        /**
         * 创建消息包 - 对应C++的newMessagePacket
         */
        fun newMessagePacket(
            messageMethod: MessageCode,
            messageContentType: MessageContentType,
            messageEndFlag: Int,
            messageDirection: MessageDirection,
            messageId: Long,
            messageContent: ByteArray,
            protocol: Protocol,
            encryptionParams: PacketEncryptionParams? = null,
            isClassicPipe: Boolean,
        ): Packet {
            require(messageContent.size <= getMaxMessageContentSize(protocol, isClassicPipe)) { "Content size exceeds maximum" }

            if (useUcd2) {
                val messageHeadSize = getMessageHeadSize()
                val rawPayload = ByteArray(messageHeadSize + messageContent.size)
                rawPayload[0] = (messageMethod.value and 0xFF).toByte()
                rawPayload[1] = ((messageMethod.value shr 8) and 0xFF).toByte()
                rawPayload[2] = messageContentType.value.toByte()
                val messageIdBits = messageId and 0x3FFFFFFF
                val directionBit = if (messageDirection == MessageDirection.CameraToPhone) 1L else 0L
                val endBit = messageEndFlag.toLong() and 0x1
                val combinedBits = messageIdBits or (directionBit shl 30) or (endBit shl 31)
                rawPayload[3] = (combinedBits and 0xFF).toByte()
                rawPayload[4] = ((combinedBits shr 8) and 0xFF).toByte()
                rawPayload[5] = ((combinedBits shr 16) and 0xFF).toByte()
                rawPayload[6] = ((combinedBits shr 24) and 0xFF).toByte()
                rawPayload[7] = 0
                rawPayload[8] = 0
                messageContent.copyInto(rawPayload, messageHeadSize)

                if (encryptionParams != null) {
                    // GCM 密文与明文等长；XOR 同样等长。先算最终 headerLength 与 sequence，
                    // 让 AAD 与最终发送帧头字节级一致，否则对端 GCM Tag 校验必然失败。
                    val optionDataLen = if (encryptionParams.scheme == EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128)
                        ENCRYPT_OPTION_DATA_LEN_AES_GCM else ENCRYPT_OPTION_DATA_LEN_XOR
                    val realHeaderLen = PACKET_FIXED_HEADER_LEN + 2 + optionDataLen
                    val seq = nextUcd2Sequence()
                    val ciphertextSize = rawPayload.size

                    val aad = ByteArray(PACKET_FIXED_HEADER_LEN)
                    aad[0] = 0x55; aad[1] = 0x43; aad[2] = 0x44; aad[3] = 0x32
                    aad[4] = 0x01
                    aad[5] = realHeaderLen.toByte()
                    aad[6] = PacketType.Message.value.toByte()
                    aad[7] = seq.toByte()
                    aad[8] = (ciphertextSize and 0xFF).toByte()
                    aad[9] = ((ciphertextSize shr 8) and 0xFF).toByte()
                    aad[10] = ((ciphertextSize shr 16) and 0xFF).toByte()
                    aad[11] = ((ciphertextSize shr 24) and 0xFF).toByte()

                    val encResult = encryptionParams.encrypt(rawPayload, aad, messageId)
                    val options = buildEncryptOptions(encryptionParams.scheme, encResult)
                    return buildUcd2FrameWithSeq(PacketType.Message, encResult.ciphertext, options, seq)
                }

                require(PACKET_FIXED_HEADER_LEN + rawPayload.size <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }
                return buildUcd2Frame(PacketType.Message, rawPayload)
            }

            val packetHeadSize = getPacketHeadSize()
            val messageHeadSize = getMessageHeadSize()
            var paddingSize = 0
            if ((packetHeadSize + messageHeadSize + messageContent.size) % 512 == 0) {
                paddingSize = 1
            }
            val totalSize = packetHeadSize + messageHeadSize + messageContent.size + paddingSize
            require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

            val data = ByteArray(totalSize)
            // 写入PacketDef结构
            data[0] = (totalSize and 0xFF).toByte()
            data[1] = ((totalSize shr 8) and 0xFF).toByte()
            data[2] = ((totalSize shr 16) and 0xFF).toByte()
            data[3] = ((totalSize shr 24) and 0xFF).toByte()
            data[4] = PacketType.Message.value.toByte()
            data[5] = (paddingSize and 0xFF).toByte()
            data[6] = ((paddingSize shr 8) and 0xFF).toByte()

            // 写入MessageDef结构
            data[7] = (messageMethod.value and 0xFF).toByte()
            data[8] = ((messageMethod.value shr 8) and 0xFF).toByte()
            data[9] = messageContentType.value.toByte()

            // 写入messageId + direction + end (4字节)
            val messageIdBits = messageId and 0x3FFFFFFF
            val directionBit = if (messageDirection == MessageDirection.CameraToPhone) 1L else 0L
            val endBit = messageEndFlag.toLong() and 0x1
            val combinedBits = messageIdBits or (directionBit shl 30) or (endBit shl 31)

            data[10] = (combinedBits and 0xFF).toByte()
            data[11] = ((combinedBits shr 8) and 0xFF).toByte()
            data[12] = ((combinedBits shr 16) and 0xFF).toByte()
            data[13] = ((combinedBits shr 24) and 0xFF).toByte()

            // 写入rsv (2字节)
            data[14] = 0
            data[15] = 0
            // 写入消息内容
            messageContent.copyInto(
                destination = data,
                destinationOffset = packetHeadSize + messageHeadSize,
                startIndex = 0,
                endIndex = messageContent.size
            )

            return fromBytesRaw(data)
        }

        /**
         * 创建心跳包 - 对应C++的newHeartBeatPacket
         */
        fun newHeartBeatPacket(): Packet? {
            if (useUcd2) {
                val payloadSize = 0
                val totalSize = getPacketHeadSize() + payloadSize
                val totalPacketSize = totalSize + 4 // + CRC
                val data = ByteArray(totalPacketSize)

                // 写入 Packet2Def 结构
                data[0] = 0x55
                data[1] = 0x43
                data[2] = 0x44
                data[3] = 0x32
                data[4] = 0x01 // version
                data[5] = getPacketHeadSize().toByte() // header_length
                data[6] = PacketType.HeartBeat.value.toByte()
                data[7] = nextUcd2Sequence().toByte()
                data[8] = (payloadSize and 0xFF).toByte()
                data[9] = ((payloadSize shr 8) and 0xFF).toByte()
                data[10] = ((payloadSize shr 16) and 0xFF).toByte()
                data[11] = ((payloadSize shr 24) and 0xFF).toByte()

                // 计算并写入 CRC32
                val crc = crc32(data, totalSize, 0)
                data[totalSize] = (crc and 0xFF).toByte()
                data[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
                data[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
                data[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()

                return fromBytesRaw(data)
            }

            val data = ByteArray(getPacketHeadSize())

            data[0] = (data.size and 0xFF).toByte()
            data[1] = ((data.size shr 8) and 0xFF).toByte()
            data[2] = ((data.size shr 16) and 0xFF).toByte()
            data[3] = ((data.size shr 24) and 0xFF).toByte()
            data[4] = PacketType.HeartBeat.value.toByte()
            data[5] = 0 // paddingLength
            data[6] = 0 // paddingLength

            return fromBytesRaw(data)
        }

        /**
         * 获取协议支持的最大消息内容大小
         */
        fun getMaxMessageContentSize(protocol: Protocol, isClassicPipe: Boolean): Int {
            return getMaxCompatiblePacketSize(protocol, isClassicPipe) - getPacketHeadSize() - getMessageHeadSize()
        }

        /**
         * 探测包大小
         * 支持 ucd2 格式和传统格式
         */
        fun probePacketSize(buf: ByteArray, size: Int): Int {
            if (useUcd2) {
                if (size < 12) return -1
                // ucd2 格式：header_length + payload_len + CRC(4)
                val headerLength = buf[5].toInt() and 0xFF
                val payloadLen = (buf[8].toInt() and 0xFF) or
                        ((buf[9].toInt() and 0xFF) shl 8) or
                        ((buf[10].toInt() and 0xFF) shl 16) or
                        ((buf[11].toInt() and 0xFF) shl 24)
                return headerLength + payloadLen + 4 // + CRC size
            }

            if (size < 4) return -1
            // 传统格式：前4字节是包长度（小端序）
            return (buf[0].toInt() and 0xFF) or
                    ((buf[1].toInt() and 0xFF) shl 8) or
                    ((buf[2].toInt() and 0xFF) shl 16) or
                    ((buf[3].toInt() and 0xFF) shl 24)
        }

        /**
         * 最小探测大小
         */
        fun minSizeToProbePacketSize(): Int {
            return if (useUcd2) 12 else 4
        }

        /**
         * 获取包头部大小
         */
        fun getPacketHeadSize(): Int {
            return if (useUcd2) PACKET_FIXED_HEADER_LEN else ProtocolConstants.PACKET_HEAD_SIZE
        }

        /**
         * 获取消息头部大小
         */
        fun getMessageHeadSize(): Int = ProtocolConstants.MESSAGE_HEAD_SIZE

        /**
         * 获取流头部大小
         */
        fun getStreamHeadSize(): Int = ProtocolConstants.STREAM_HEAD_SIZE

        /**
         * 获取隧道头部大小
         */
        fun getTunnelHeadSize(): Int = ProtocolConstants.TUNNEL_HEAD_SIZE

        /**
         * 获取Linux命令头部大小
         */
        fun getLinuxCmdHeadSize(): Int = ProtocolConstants.LINUX_CMD_HEAD_SIZE

        /**
         * 获取最大兼容包大小
         */
        fun getMaxCompatiblePacketSize(protocol: Protocol, isClassicPipe: Boolean): Int {
            val maxPacketSize = when (protocol) {
                Protocol.Bluetooth -> if (isClassicPipe) ProtocolConstants.MAX_CLASSIC_PHOTO_TO_CAMERA_PACKET_SIZE else ProtocolConstants.MAX_BLUETOOTH_PHOTO_TO_CAMERA_PACKET_SIZE
                else -> ProtocolConstants.MAX_USB_PHOTO_TO_CAMERA_PACKET_SIZE
            }
            if (Packet.useUcd2) {
                return maxPacketSize
            }
            return if (maxPacketSize % 512 == 0) maxPacketSize - 1 else maxPacketSize
        }

        /**
         * 获取最大流数据大小
         */
        fun getMaxStreamDataSize(protocol: Protocol, isClassicPipe: Boolean): Int {
            return getMaxCompatiblePacketSize(protocol, isClassicPipe) - getPacketHeadSize() - getStreamHeadSize()
        }

        /**
         * 获取最大隧道内容大小
         */
        fun getMaxTunnelContentSize(protocol: Protocol, isClassicPipe: Boolean): Int {
            return getMaxCompatiblePacketSize(protocol, isClassicPipe) - getPacketHeadSize() - getTunnelHeadSize()
        }

        /**
         * 计算总包大小 - 对应C++的getTotalPacketSize
         */
        fun getTotalPacketSize(messageContent: ByteArray): Int {
            val packetHeadSize = getPacketHeadSize()
            val messageHeadSize = getMessageHeadSize()
            var paddingSize = 0
            if ((packetHeadSize + messageHeadSize + messageContent.size) % 512 == 0) {
                paddingSize = 1
            }
            return packetHeadSize + messageHeadSize + messageContent.size + paddingSize
        }

        /**
         * 创建同步包 - 对应C++的newSyncronsizePacket
         * 注意：UCD2.0去掉了sync同步包
         */
        fun newSyncronsizePacket(synchronizePayload: ByteArray): Packet {
            // UCD2.0 不支持同步包，只使用传统格式
            val totalSize = getPacketHeadSize() + synchronizePayload.size
            require(totalSize < 512) { "Total size too large" }

            val data = ByteArray(totalSize)

            data[0] = (totalSize and 0xFF).toByte()
            data[1] = ((totalSize shr 8) and 0xFF).toByte()
            data[2] = ((totalSize shr 16) and 0xFF).toByte()
            data[3] = ((totalSize shr 24) and 0xFF).toByte()
            data[4] = PacketType.Synchronize.value.toByte()
            data[5] = 0 // paddingLength
            data[6] = 0 // paddingLength

            // 复制同步内容
            synchronizePayload.copyInto(
                destination = data,
                destinationOffset = getPacketHeadSize(),
                startIndex = 0,
                endIndex = synchronizePayload.size
            )

            return fromBytesRaw(data)
        }

        /**
         * 创建流包 - 对应C++的newStreamPacket
         */
        fun newStreamPacket(
            streamType: StreamType,
            streamTimestamp: Long,
            streamData: ByteArray,
            protocol: Protocol,
            isClassicPipe: Boolean,
        ): Packet {
            if (useUcd2) {
                val payloadSize = getStreamHeadSize() + streamData.size
                val totalSize = getPacketHeadSize() + payloadSize
                val totalPacketSize = totalSize + 4 // + CRC
                require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

                val data = ByteArray(totalPacketSize)

                // 写入 Packet2Def 结构
                data[0] = 0x55
                data[1] = 0x43
                data[2] = 0x44
                data[3] = 0x32
                data[4] = 0x01 // version
                data[5] = getPacketHeadSize().toByte() // header_length
                data[6] = PacketType.Stream.value.toByte()
                data[7] = nextUcd2Sequence().toByte()
                data[8] = (payloadSize and 0xFF).toByte()
                data[9] = ((payloadSize shr 8) and 0xFF).toByte()
                data[10] = ((payloadSize shr 16) and 0xFF).toByte()
                data[11] = ((payloadSize shr 24) and 0xFF).toByte()

                // 写入 StreamDef 结构
                val payloadOffset = getPacketHeadSize()
                data[payloadOffset] = streamType.value.toByte()
                data[payloadOffset + 1] = (streamTimestamp and 0xFF).toByte()
                data[payloadOffset + 2] = ((streamTimestamp shr 8) and 0xFF).toByte()
                data[payloadOffset + 3] = ((streamTimestamp shr 16) and 0xFF).toByte()
                data[payloadOffset + 4] = ((streamTimestamp shr 24) and 0xFF).toByte()
                data[payloadOffset + 5] = ((streamTimestamp shr 32) and 0xFF).toByte()
                data[payloadOffset + 6] = ((streamTimestamp shr 40) and 0xFF).toByte()
                data[payloadOffset + 7] = ((streamTimestamp shr 48) and 0xFF).toByte()
                data[payloadOffset + 8] = ((streamTimestamp shr 56) and 0xFF).toByte()

                // 复制流数据
                streamData.copyInto(
                    destination = data,
                    destinationOffset = payloadOffset + getStreamHeadSize(),
                    startIndex = 0,
                    endIndex = streamData.size
                )

                // 计算并写入 CRC32
                val crc = crc32(data, totalSize, 0)
                data[totalSize] = (crc and 0xFF).toByte()
                data[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
                data[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
                data[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()

                return fromBytesRaw(data)
            }

            var paddingSize = 0
            if ((getPacketHeadSize() + getStreamHeadSize() + streamData.size) % 512 == 0) {
                paddingSize = 1
            }
            val totalSize =
                getPacketHeadSize() + getStreamHeadSize() + streamData.size + paddingSize
            require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

            val data = ByteArray(totalSize)

            data[0] = (totalSize and 0xFF).toByte()
            data[1] = ((totalSize shr 8) and 0xFF).toByte()
            data[2] = ((totalSize shr 16) and 0xFF).toByte()
            data[3] = ((totalSize shr 24) and 0xFF).toByte()
            data[4] = PacketType.Stream.value.toByte()
            data[5] = (paddingSize and 0xFF).toByte()
            data[6] = ((paddingSize shr 8) and 0xFF).toByte()

            // 写入StreamDef结构
            data[7] = streamType.value.toByte()
            data[8] = (streamTimestamp and 0xFF).toByte()
            data[9] = ((streamTimestamp shr 8) and 0xFF).toByte()
            data[10] = ((streamTimestamp shr 16) and 0xFF).toByte()
            data[11] = ((streamTimestamp shr 24) and 0xFF).toByte()
            data[12] = ((streamTimestamp shr 32) and 0xFF).toByte()
            data[13] = ((streamTimestamp shr 40) and 0xFF).toByte()
            data[14] = ((streamTimestamp shr 48) and 0xFF).toByte()
            data[15] = ((streamTimestamp shr 56) and 0xFF).toByte()

            // 复制流数据
            streamData.copyInto(
                destination = data,
                destinationOffset = getPacketHeadSize() + getStreamHeadSize(),
                startIndex = 0,
                endIndex = streamData.size
            )

            return fromBytesRaw(data)
        }

        /**
         * 创建隧道包 - 对应C++的newTunnelPacket
         */
        fun newTunnelPacket(
            tunnelConnectionId: Int,
            tunnelFlags: Int,
            tunnelWindowLimit: Long,
            tunnelContent: ByteArray,
            protocol: Protocol,
            isClassicPipe: Boolean,
        ): Packet {
            if (useUcd2) {
                val payloadSize = getTunnelHeadSize() + tunnelContent.size
                val totalSize = getPacketHeadSize() + payloadSize
                val totalPacketSize = totalSize + 4 // + CRC
                require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

                val data = ByteArray(totalPacketSize)

                // 写入 Packet2Def 结构
                data[0] = 0x55
                data[1] = 0x43
                data[2] = 0x44
                data[3] = 0x32
                data[4] = 0x01 // version
                data[5] = getPacketHeadSize().toByte() // header_length
                data[6] = PacketType.SocketTunnel.value.toByte()
                data[7] = nextUcd2Sequence().toByte()
                data[8] = (payloadSize and 0xFF).toByte()
                data[9] = ((payloadSize shr 8) and 0xFF).toByte()
                data[10] = ((payloadSize shr 16) and 0xFF).toByte()
                data[11] = ((payloadSize shr 24) and 0xFF).toByte()

                // 写入 TunnelDef 结构
                val payloadOffset = getPacketHeadSize()
                data[payloadOffset] = (tunnelConnectionId and 0xFF).toByte()
                data[payloadOffset + 1] = ((tunnelConnectionId shr 8) and 0xFF).toByte()
                data[payloadOffset + 2] = ((tunnelConnectionId shr 16) and 0xFF).toByte()
                data[payloadOffset + 3] = ((tunnelConnectionId shr 24) and 0xFF).toByte()
                data[payloadOffset + 4] = (tunnelFlags and 0xFF).toByte()
                data[payloadOffset + 5] = ((tunnelFlags shr 8) and 0xFF).toByte()
                data[payloadOffset + 6] = (tunnelWindowLimit and 0xFF).toByte()
                data[payloadOffset + 7] = ((tunnelWindowLimit shr 8) and 0xFF).toByte()
                data[payloadOffset + 8] = ((tunnelWindowLimit shr 16) and 0xFF).toByte()
                data[payloadOffset + 9] = ((tunnelWindowLimit shr 24) and 0xFF).toByte()
                data[payloadOffset + 10] = ((tunnelWindowLimit shr 32) and 0xFF).toByte()
                data[payloadOffset + 11] = ((tunnelWindowLimit shr 40) and 0xFF).toByte()
                data[payloadOffset + 12] = ((tunnelWindowLimit shr 48) and 0xFF).toByte()
                data[payloadOffset + 13] = ((tunnelWindowLimit shr 56) and 0xFF).toByte()

                // 复制隧道内容
                tunnelContent.copyInto(
                    destination = data,
                    destinationOffset = payloadOffset + getTunnelHeadSize(),
                    startIndex = 0,
                    endIndex = tunnelContent.size
                )

                // 计算并写入 CRC32
                val crc = crc32(data, totalSize, 0)
                data[totalSize] = (crc and 0xFF).toByte()
                data[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
                data[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
                data[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()

                return fromBytesRaw(data)
            }

            var paddingSize = 0
            if ((getPacketHeadSize() + getTunnelHeadSize() + tunnelContent.size) % 512 == 0) {
                paddingSize = 1
            }
            val totalSize =
                getPacketHeadSize() + getTunnelHeadSize() + tunnelContent.size + paddingSize
            require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

            val data = ByteArray(totalSize)

            data[0] = (totalSize and 0xFF).toByte()
            data[1] = ((totalSize shr 8) and 0xFF).toByte()
            data[2] = ((totalSize shr 16) and 0xFF).toByte()
            data[3] = ((totalSize shr 24) and 0xFF).toByte()
            data[4] = PacketType.SocketTunnel.value.toByte()
            data[5] = (paddingSize and 0xFF).toByte()
            data[6] = ((paddingSize shr 8) and 0xFF).toByte()

            // 写入TunnelDef结构
            data[7] = (tunnelConnectionId and 0xFF).toByte()
            data[8] = ((tunnelConnectionId shr 8) and 0xFF).toByte()
            data[9] = ((tunnelConnectionId shr 16) and 0xFF).toByte()
            data[10] = ((tunnelConnectionId shr 24) and 0xFF).toByte()
            data[11] = (tunnelFlags and 0xFF).toByte()
            data[12] = ((tunnelFlags shr 8) and 0xFF).toByte()
            data[13] = (tunnelWindowLimit and 0xFF).toByte()
            data[14] = ((tunnelWindowLimit shr 8) and 0xFF).toByte()
            data[15] = ((tunnelWindowLimit shr 16) and 0xFF).toByte()
            data[16] = ((tunnelWindowLimit shr 24) and 0xFF).toByte()
            data[17] = ((tunnelWindowLimit shr 32) and 0xFF).toByte()
            data[18] = ((tunnelWindowLimit shr 40) and 0xFF).toByte()
            data[19] = ((tunnelWindowLimit shr 48) and 0xFF).toByte()
            data[20] = ((tunnelWindowLimit shr 56) and 0xFF).toByte()

            // 复制隧道内容
            tunnelContent.copyInto(
                destination = data,
                destinationOffset = getPacketHeadSize() + getTunnelHeadSize(),
                startIndex = 0,
                endIndex = tunnelContent.size
            )

            return fromBytesRaw(data)
        }

        /**
         * 创建Linux命令包 - 对应C++的newLinuxCmdPacket
         */
        fun newLinuxCmdPacket(
            linuxCmdCmd: LinuxCmdCmd,
            linuxCmdDirection: LinuxCmdDirection,
            linuxCmdContent: Int,
        ): Packet {
            if (useUcd2) {
                val payloadSize = getLinuxCmdHeadSize()
                val totalSize = getPacketHeadSize() + payloadSize
                val totalPacketSize = totalSize + 4 // + CRC
                require(totalSize < 512) { "Total size too large" }

                val data = ByteArray(totalPacketSize)

                // 写入 Packet2Def 结构
                data[0] = 0x55
                data[1] = 0x43
                data[2] = 0x44
                data[3] = 0x32
                data[4] = 0x01 // version
                data[5] = getPacketHeadSize().toByte() // header_length
                data[6] = PacketType.LinuxCmd.value.toByte()
                data[7] = nextUcd2Sequence().toByte()
                data[8] = (payloadSize and 0xFF).toByte()
                data[9] = ((payloadSize shr 8) and 0xFF).toByte()
                data[10] = ((payloadSize shr 16) and 0xFF).toByte()
                data[11] = ((payloadSize shr 24) and 0xFF).toByte()

                // 写入 LinuxCmdDef 结构
                val payloadOffset = getPacketHeadSize()
                data[payloadOffset] = linuxCmdCmd.value.toByte()
                data[payloadOffset + 1] = linuxCmdDirection.value.toByte()
                data[payloadOffset + 2] = linuxCmdContent.toByte()

                // 计算并写入 CRC32
                val crc = crc32(data, totalSize, 0)
                data[totalSize] = (crc and 0xFF).toByte()
                data[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
                data[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
                data[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()

                return fromBytesRaw(data)
            }

            val totalSize = getPacketHeadSize() + getLinuxCmdHeadSize()
            require(totalSize < 512) { "Total size too large" }

            val data = ByteArray(totalSize)

            data[0] = (totalSize and 0xFF).toByte()
            data[1] = ((totalSize shr 8) and 0xFF).toByte()
            data[2] = ((totalSize shr 16) and 0xFF).toByte()
            data[3] = ((totalSize shr 24) and 0xFF).toByte()
            data[4] = PacketType.LinuxCmd.value.toByte()
            data[5] = 0 // paddingLength
            data[6] = 0 // paddingLength

            // 写入LinuxCmdDef结构
            data[7] = linuxCmdCmd.value.toByte()
            data[8] = linuxCmdDirection.value.toByte()
            data[9] = linuxCmdContent.toByte()

            return fromBytesRaw(data)
        }

        /**
         * 创建带payload的包 - 对应C++的newPacketWithPacketPayload
         */
        fun newPacketWithPacketPayload(
            packetType: PacketType,
            payload: ByteArray,
            protocol: Protocol,
            isClassicPipe: Boolean,
        ): Packet {
            if (useUcd2) {
                val payloadSize = payload.size
                val totalSize = getPacketHeadSize() + payloadSize
                val totalPacketSize = totalSize + 4 // + CRC
                require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

                val data = ByteArray(totalPacketSize)

                // 写入 Packet2Def 结构
                data[0] = 0x55
                data[1] = 0x43
                data[2] = 0x44
                data[3] = 0x32
                data[4] = 0x01 // version
                data[5] = getPacketHeadSize().toByte() // header_length
                data[6] = packetType.value.toByte()
                data[7] = nextUcd2Sequence().toByte()
                data[8] = (payloadSize and 0xFF).toByte()
                data[9] = ((payloadSize shr 8) and 0xFF).toByte()
                data[10] = ((payloadSize shr 16) and 0xFF).toByte()
                data[11] = ((payloadSize shr 24) and 0xFF).toByte()

                // 复制payload
                payload.copyInto(
                    destination = data,
                    destinationOffset = getPacketHeadSize(),
                    startIndex = 0,
                    endIndex = payload.size
                )

                // 计算并写入 CRC32
                val crc = crc32(data, totalSize, 0)
                data[totalSize] = (crc and 0xFF).toByte()
                data[totalSize + 1] = ((crc shr 8) and 0xFF).toByte()
                data[totalSize + 2] = ((crc shr 16) and 0xFF).toByte()
                data[totalSize + 3] = ((crc shr 24) and 0xFF).toByte()

                return fromBytesRaw(data)
            }

            var paddingSize = 0
            if ((getPacketHeadSize() + payload.size) % 512 == 0) {
                paddingSize = 1
            }
            val totalSize = getPacketHeadSize() + payload.size + paddingSize
            require(totalSize <= getMaxCompatiblePacketSize(protocol, isClassicPipe)) { "Total size exceeds maximum" }

            val data = ByteArray(totalSize)

            data[0] = (totalSize and 0xFF).toByte()
            data[1] = ((totalSize shr 8) and 0xFF).toByte()
            data[2] = ((totalSize shr 16) and 0xFF).toByte()
            data[3] = ((totalSize shr 24) and 0xFF).toByte()
            data[4] = packetType.value.toByte()
            data[5] = (paddingSize and 0xFF).toByte()
            data[6] = ((paddingSize shr 8) and 0xFF).toByte()

            // 复制payload
            payload.copyInto(
                destination = data,
                destinationOffset = getPacketHeadSize(),
                startIndex = 0,
                endIndex = payload.size
            )

            return fromBytesRaw(data)
        }

    }

    // 私有解析方法
    private fun parseMessageMethod(): MessageCode? {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 2) return MessageCode.fromValue(0)
        return MessageCode.fromValue((data[offset].toInt() and 0xFF) or ((data[offset + 1].toInt() and 0xFF) shl 8)) ?: MessageCode.fromValue(200)
    }

    private fun parseMessageContentType(): MessageContentType? {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 3) return null
        return MessageContentType.fromValue(data[offset + 2].toInt() and 0xFF)
    }

    private fun parseMessageEndFlag(): Int {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 7) return 0
        val combinedBits = (data[offset + 6].toInt() and 0xFF)
        return (combinedBits shr 7) and 1
    }

    private fun parseMessageDirection(): MessageDirection? {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 7) return null
        val combinedBits = (data[offset + 6].toInt() and 0xFF)
        return MessageDirection.fromValue((combinedBits shr 6) and 1)
    }

    private fun parseMessageId(): Long {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 7) return 0
        return ((data[offset + 3].toLong() and 0xFF) or
                ((data[offset + 4].toLong() and 0xFF) shl 8) or
                ((data[offset + 5].toLong() and 0xFF) shl 16) or
                ((data[offset + 6].toLong() and 0xFF) shl 24)) and 0x3FFFFFFF
    }

    private fun parseMessageContent(): ByteArray {
        val payload = getPayload()
        if (payload.size <= getMessageHeadSize()) return ByteArray(0)
        return payload.copyOfRange(getMessageHeadSize(), payload.size)
    }

    private fun parseStreamType(): StreamType? {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 1) return null
        return StreamType.fromValue(data[offset].toInt() and 0xFF)
    }

    private fun parseStreamTimestamp(): Long {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 9) return 0L
        return (data[offset + 1].toLong() and 0xFF) or
                ((data[offset + 2].toLong() and 0xFF) shl 8) or
                ((data[offset + 3].toLong() and 0xFF) shl 16) or
                ((data[offset + 4].toLong() and 0xFF) shl 24) or
                ((data[offset + 5].toLong() and 0xFF) shl 32) or
                ((data[offset + 6].toLong() and 0xFF) shl 40) or
                ((data[offset + 7].toLong() and 0xFF) shl 48) or
                ((data[offset + 8].toLong() and 0xFF) shl 56)
    }

    private fun parseStreamData(): ByteArray {
        val payload = getPayload()
        if (payload.size <= getStreamHeadSize()) return ByteArray(0)
        return payload.copyOfRange(getStreamHeadSize(), payload.size)
    }

    private fun parseLinuxCmdCmd(): LinuxCmdCmd? {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 1) return null
        return LinuxCmdCmd.fromValue(data[offset].toInt() and 0xFF)
    }

    private fun parseLinuxCmdDirection(): LinuxCmdDirection? {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 2) return null
        return LinuxCmdDirection.fromValue(data[offset + 1].toInt() and 0xFF)
    }

    private fun parseLinuxCmdContent(): Int {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 3) return 0
        return data[offset + 2].toInt() and 0xFF
    }

    /**
     * 解析隧道连接ID - 对应C++的getTunnelConnectionId
     */
    private fun parseTunnelConnectionId(): Int {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 4) return 0
        return (data[offset].toInt() and 0xFF) or
                ((data[offset + 1].toInt() and 0xFF) shl 8) or
                ((data[offset + 2].toInt() and 0xFF) shl 16) or
                ((data[offset + 3].toInt() and 0xFF) shl 24)
    }

    /**
     * 解析隧道标志 - 对应C++的getTunnelFlags
     */
    private fun parseTunnelFlags(): Int {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 6) return 0
        return (data[offset + 4].toInt() and 0xFF) or
                ((data[offset + 5].toInt() and 0xFF) shl 8)
    }

    /**
     * 解析隧道窗口限制 - 对应C++的getTunnelWindowLimit
     */
    private fun parseTunnelWindowLimit(): Long {
        val data = rawBuf
        val offset = if (useUcd2) {
            val headerLength = data[5].toInt() and 0xFF
            headerLength
        } else {
            getPacketHeadSize()
        }
        if (data.size < offset + 14) return 0L
        return (data[offset + 6].toLong() and 0xFF) or
                ((data[offset + 7].toLong() and 0xFF) shl 8) or
                ((data[offset + 8].toLong() and 0xFF) shl 16) or
                ((data[offset + 9].toLong() and 0xFF) shl 24) or
                ((data[offset + 10].toLong() and 0xFF) shl 32) or
                ((data[offset + 11].toLong() and 0xFF) shl 40) or
                ((data[offset + 12].toLong() and 0xFF) shl 48) or
                ((data[offset + 13].toLong() and 0xFF) shl 56)
    }

    /**
     * 解析隧道内容 - 对应C++的getTunnelContent
     */
    private fun parseTunnelContent(): ByteArray {
        val payload = getPayload()
        if (payload.size <= getTunnelHeadSize()) return ByteArray(0)

        return payload.copyOfRange(getTunnelHeadSize(), payload.size)
    }

    /**
     * 获取payload数据（去除包头和padding）- 对应C++的getPayload
     * 加密帧已在 fromBytes 入口完成解密，此处直接读 rawBuf 的明文 payload。
     */
    fun getPayload(): ByteArray {
        if (useUcd2) {
            if (rawBuf.size < 12) return ByteArray(0)
            val headerLength = rawBuf[5].toInt() and 0xFF
            return rawBuf.copyOfRange(headerLength, rawBuf.size - 4)
        }

        val headSize = getPacketHeadSize()
        val paddingLength = getPacketPaddingLength()

        if (rawBuf.size <= headSize + paddingLength) return ByteArray(0)

        return rawBuf.copyOfRange(headSize, rawBuf.size - paddingLength)
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Packet) return false
        return rawBuf.contentEquals(other.rawBuf)
    }

    override fun hashCode(): Int {
        return rawBuf.contentHashCode()
    }
}