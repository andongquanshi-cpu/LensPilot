package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetAccessCameraFileStateCmd(
    /**
     * [com.arashivision.onecamera.OneDriverInfo.Request.AccessCameraFileState]
     */
    private val mAccessState: Int
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setAccessCameraFileState(mAccessState)
    }
}
