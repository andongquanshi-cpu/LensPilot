package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.GetTimelapseOptions

class GetTimelapseOptionAsyncCmd(
    private val mGetTimelapseOptions: GetTimelapseOptions,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getTimelapseOptionsAsync(mGetTimelapseOptions, mRequestOptions)
    }
}
