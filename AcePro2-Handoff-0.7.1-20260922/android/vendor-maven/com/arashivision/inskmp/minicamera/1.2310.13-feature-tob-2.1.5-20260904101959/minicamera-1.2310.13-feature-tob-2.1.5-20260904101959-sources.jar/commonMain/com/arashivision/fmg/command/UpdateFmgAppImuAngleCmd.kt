package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.onecamera.OneDriver

class UpdateFmgAppImuAngleCmd(private val fmgAngleBean: FmgAngleBean?) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzUpdateAppImuAngle(fmgAngleBean)
        return null
    }
}
