package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class RebootCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.reboot()
    }
}
