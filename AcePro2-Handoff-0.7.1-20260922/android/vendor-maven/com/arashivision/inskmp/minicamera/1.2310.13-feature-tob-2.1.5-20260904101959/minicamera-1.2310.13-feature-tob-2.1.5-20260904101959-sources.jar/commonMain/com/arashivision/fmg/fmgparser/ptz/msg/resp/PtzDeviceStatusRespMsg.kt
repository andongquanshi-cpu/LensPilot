package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode

class PtzDeviceStatusRespMsg : PtzDataRespMessage() {
    var battery: Short = 0
    var mode: Short = 0
    var limitYaw: Boolean = false
    var stall: Boolean = false
    var charging: Boolean = false
    var payload: Boolean = false
    var overTemp: Boolean = false
    var imbalance: Boolean = false
    var sportMode: Boolean = false
    var sleep: Boolean = false
    var lowTemp: Boolean = false
    var limitPitch: Boolean = false
    var motionType: Boolean = false
    var hvMode: PtzHvMode? = null
    var cfMode: Boolean = false
    var aiOnline: Boolean = false

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 3) {
            Log.d("unpack", "error!!!!")
            return
        }
        battery = FmgByteUtils.byteToShort(data[0])
        mode = FmgByteUtils.byteToShort(data[1])
        val s1 = FmgByteUtils.byteToBinary(data[2])
        val chars1 = s1.toCharArray()
        limitYaw = chars1[7] == '1'
        stall = chars1[6] == '1'
        charging = chars1[5] == '1'
        payload = chars1[4] == '1'
        overTemp = chars1[3] == '1'
        imbalance = chars1[2] == '1'
        sportMode = chars1[1] == '1'
        sleep = chars1[0] == '1'
        if (data.size < 4) {
            return
        }
        val s2 = FmgByteUtils.byteToBinary(data[3])
        val chars2 = s2.toCharArray()
        lowTemp = chars2[7] == '1'
        limitPitch = chars2[6] == '1'
        hvMode = if (chars2[5] == '1') {
            PtzHvMode.HORIZONTAL
        } else {
            PtzHvMode.VERTICAL
        }
        motionType = chars2[4] == '1'
        cfMode = chars2[3] == '1'
        aiOnline = chars2[2] == '1'
    }

    override fun toString(): String {
        return ("battery: " + battery + " mode: " + mode + " limitYaw: " + limitYaw + " stall: " + stall
                + " charging: " + charging + " payload: " + payload + " overTemp: " + overTemp +
                " imbalance: " + imbalance + " sportMode: " + sportMode + " sleep: " + sleep + " lowTemp: " + lowTemp
                + " limitPitch: " + limitPitch + " hvMode: " + hvMode.toString() + " cfMode: " + cfMode + " motionType: " + motionType
                + " aiOnline" + aiOnline)
    }

    override fun name(): String {
        return "CMD_DEVICE_STATUS"
    }
}
