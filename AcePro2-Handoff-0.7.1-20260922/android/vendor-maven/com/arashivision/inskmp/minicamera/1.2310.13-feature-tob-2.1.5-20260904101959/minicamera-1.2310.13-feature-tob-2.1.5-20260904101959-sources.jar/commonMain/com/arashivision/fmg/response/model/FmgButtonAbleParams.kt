package com.arashivision.fmg.response.model

import com.arashivision.fmg.response.model.FmgModel.PtzButtonEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzDwEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzRockerEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzTouchEventMode

class FmgButtonAbleParams {
    var modeBtnParams: Array<PtzButtonEventMode>? = null
    var shutterBtnParams: Array<PtzButtonEventMode>? = null
    var holdParams: Array<PtzButtonEventMode>? = null
    var midBtnParams: Array<PtzButtonEventMode>? = null
    var powerBtnParams: Array<PtzButtonEventMode>? = null
    var rockerParams: Array<PtzRockerEventMode>? = null
    var touchParams: Array<PtzTouchEventMode>? = null
    var dwParams: Array<PtzDwEventMode>? = null

    override fun toString(): String {
        return "FmgButtonAbleParams{" +
                "modeBtnParams=" + modeBtnParams.contentToString() +
                ", shutterBtnParams=" + shutterBtnParams.contentToString() +
                ", holdParams=" + holdParams.contentToString() +
                ", midBtnParams=" + midBtnParams.contentToString() +
                ", powerBtnParams=" + powerBtnParams.contentToString() +
                ", rockerParams=" + rockerParams.contentToString() +
                ", touchParams=" + touchParams.contentToString() +
                ", dwParams=" + dwParams.contentToString() +
                '}'
    }
}
