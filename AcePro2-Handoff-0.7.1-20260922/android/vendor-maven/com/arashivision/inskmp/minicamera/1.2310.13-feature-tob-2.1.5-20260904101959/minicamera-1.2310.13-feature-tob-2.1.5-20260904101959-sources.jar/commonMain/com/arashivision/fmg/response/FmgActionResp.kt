package com.arashivision.fmg.response

class FmgActionResp(var requestID: Long)
