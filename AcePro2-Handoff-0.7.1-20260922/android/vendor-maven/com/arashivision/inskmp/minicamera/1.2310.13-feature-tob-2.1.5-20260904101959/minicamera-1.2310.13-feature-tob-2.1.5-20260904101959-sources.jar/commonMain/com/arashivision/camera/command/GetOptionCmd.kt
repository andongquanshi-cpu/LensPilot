package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.OptionType

/**
 * 同步获取options的cmd
 */
class GetOptionCmd(private val mOptionList: List<OptionType>?) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return if (mOptionList == null) {
            oneDrvier?.getAllOption(OptionType.entries)
        } else {
            oneDrvier?.getOptions(mOptionList)
        }
    }
}
