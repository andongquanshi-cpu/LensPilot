package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType

class MultiVideoModeCmd(
    private val functionMode: Int,
    private val sensorMode: Int,
    private val optionList: List<MultiPhotographyOptionsType>,
    private val mOptions: MultiPhotographyOptions,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setMultiVideoMode(
            functionMode,
            sensorMode,
            optionList,
            mOptions,
            mRequestOptions
        )
    }
}
