package com.arashivision.fmg.response

class FmgEnableHandDragResp(var requestID: Long)
