package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzRcSetReqMsg(private val yaw: Float, private val pitch: Float, private val roll: Float) :
    PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(12)
        val yawByteArray = FmgByteUtils.floatToUint32ByteArray(yaw)
        val pitchByteArray = FmgByteUtils.floatToUint32ByteArray(pitch)
        val rollByteArray = FmgByteUtils.floatToUint32ByteArray(roll)
        rollByteArray.copyInto(data, 0, 0, rollByteArray.size)
        pitchByteArray.copyInto(data, 4, 0, pitchByteArray.size)
        yawByteArray.copyInto(data, 8, 0, yawByteArray.size)
        return data
    }

    override fun toString(): String {
        return "yaw: $yaw pitch: $pitch roll: $roll"
    }

    override fun name(): String {
        return "CMD_RC_SET"
    }
}
