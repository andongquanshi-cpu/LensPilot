package com.arashivision.camera.command

import com.arashivision.common.Log
import com.arashivision.onecamera.OneDriver
import insta360.messages.TakePicture

/**
 * 拍照的command
 */
class CaptureCommand(private val mTakePicture: TakePicture, private val withoutStorage: Boolean) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        Log.d(TAG, " one driver = $oneDrvier")
        if (withoutStorage) {
            oneDrvier?.captureStillImageWithouStorage(mTakePicture)
        } else {
            oneDrvier?.captureStillImage(mTakePicture)
        }
        return 0
    }

    companion object {
        private val TAG: String = CaptureCommand::class.simpleName.toString()
    }
}
