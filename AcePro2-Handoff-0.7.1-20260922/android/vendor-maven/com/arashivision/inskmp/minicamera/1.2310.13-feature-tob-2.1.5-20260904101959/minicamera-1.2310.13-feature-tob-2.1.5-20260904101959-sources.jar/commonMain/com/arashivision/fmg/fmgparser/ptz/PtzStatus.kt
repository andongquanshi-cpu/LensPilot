package com.arashivision.fmg.fmgparser.ptz


object PtzStatus {
    const val PROTOCOL: Short = 104

    object PtzBps {
        const val SHAKE_HAND: Long = 9600
    }

    object PtzFrame {
        const val REQ_NONE: Short = 0
        const val REQ_SHAKE_HAND_STEP_1: Short = 0
        const val REQ_SHAKE_HAND_STEP_2: Short = 1
        const val REQ_UPDATE_RESET: Short = 0x5A
        const val REQ_UPDATE_INFO: Short = 0x5A
        const val REQ_UPDATED: Short = 0xA5
        const val REQ_UPDATE_REBOOT: Short = 0xA5

        const val ACK_OK: Short = 0x80
        const val ACK_NO_NEED_UPDATE: Short = 0x81
        const val ACK_NEED_UPDATE: Short = 0x82
        const val ACK_SHAKE_HAND: Short = 0x83

        const val ACK_ERR_SAME_POINT: Short = 0xB0
        const val ACK_ERR_NOT_SUPPORT: Short = 0xB1
        const val ACK_ERR_IMU: Short = 0xB2
        const val ACK_ERR_LIMIT: Short = 0xB3
        const val ACK_ERR_NOT_READY: Short = 0xB4

        const val ACK_ERR_LENGTH: Short = 0xE0
        const val ACK_ERR_CRC16: Short = 0xE1
        const val ACK_ERR_INVALID_APP: Short = 0xE2
        const val ACK_ERR_INVALID_FRAME: Short = 0xE3
        const val ACK_ERR_DP_LENGTH: Short = 0xE4
        const val ACK_ERR_SIZE: Short = 0xE5
        const val ACK_ERR_CRC32: Short = 0xE6
        const val ACK_ERR_CHECKSUM: Short = 0xE7
        const val ACK_ERR_CRC32_CP: Short = 0xE8
        const val ACK_ERR_CHECKSUM_CP: Short = 0xE9
        const val ACK_ERR_UPDATE_STATUS: Short = 0xEA
        const val ACK_ERR_FRAME_FLAG: Short = 0xEB
        const val ACK_ERR_INVALID_DATA: Short = 0xEC
        const val ACK_ERR_STATUS: Short = 0xED
        const val ACK_ERR_INVALID_CMD: Short = 0xEE

        const val ACK_FINISHED: Short = 0xFF

        const val SF_UNKNOWN: Short = 0xFF
        const val SF_ALL: Short = 0x00
        const val SF_MODE: Short = 0x01
        const val SF_FOLLOW_SPEED: Short = 0x02
        const val SF_RC_SPEED: Short = 0x03
        const val SF_ZOOM_SPEED: Short = 0x04
        const val SF_RC_HORIZONTAL_DIR: Short = 0x05
        const val SF_RC_VERTICAL_DIR: Short = 0x06
        const val SF_KEY_DEFINE: Short = 0x07
        const val SF_SOUND_ENABLE: Short = 0x08
        const val SF_HV_MODE: Short = 0x09
        const val SF_SWITCH_MODE_WAY: Short = 0x0A
        const val SF_LED: Short = 0x0B
        const val SF_MOTOR_STRENGTH: Short = 0x0C
        const val SF_ROLL_SPEED: Short = 0x0D
        const val SF_QUICK_START_ENABLE: Short = 0x0E
        const val SF_PITCH_LED: Short = 0x0F
        const val SF_DOCKKIT_ENABLE: Short = 0x10
        const val SF_ENABLE_SAVE_HV: Short = 0x11 //记忆横竖屏
        const val SF_YAW_300: Short = 0x12 //一键环拍
        const val TF_NONE: Short = 0x00
        const val TF_NORMAL: Short = 0x01
        const val TF_LOST: Short = 0x02
        const val TF_EXIT: Short = 0x03
        const val TF_SPECULATE: Short = 0x04
        const val TF_COMPOSITION: Short = 0x05


        const val VERTICAL_TRIM_GET: Short = 0x00
        const val VERTICAL_TRIM_SET: Short = 0x01

        const val FHE_SINGLE_CLICK: Short = 0x00
        const val FHE_DOUBLE_CLICK: Short = 0x01
        const val FHE_TRIPLE_CLICK: Short = 0x02
        const val FHE_LONG: Short = 0x03
        const val FHE_LONG_RELEASE: Short = 0x04

        const val FHE_RC_UP: Short = 0x10
        const val FHE_RC_DOWN: Short = 0x11
        const val FHE_RC_LEFT: Short = 0x12
        const val FHE_RC_RIGHT: Short = 0x13
        const val FHE_RC_IDLE: Short = 0x14
        const val FHE_RC_SRC_VALUE: Short = 0x15

        const val FHE_TOUCH_CW: Short = 0x20
        const val FHE_TOUCH_CCW: Short = 0x21
        const val FHE_TOUCH_START: Short = 0x22 //触摸事件：开始了触摸
        const val FHE_TOUCH_END: Short = 0x23 //触摸事件：结束了触摸
        const val FHE_TOUCH_LEFT_DC: Short = 0x24 //左边区域（拍摄按键）的触摸双击 DOUBLE_CLICK
        const val FHE_TOUCH_RIGHT_DC: Short = 0x25 //右边区域（切换按键）的触摸双击

        const val FHE_DW_CW_SINGLE: Short = 0x30
        const val FHE_DW_CW_START: Short = 0x31
        const val FHE_DW_CW_STOP: Short = 0x32
        const val FHE_DW_CCW_SINGLE: Short = 0x33
        const val FHE_DW_CCW_START: Short = 0x34
        const val FHE_DW_CCW_STOP: Short = 0x35
        const val FHE_DW_SRC_VALUE: Short = 0x36


        const val MB_EVENT: Short = 0x01 //模式按键
        const val SB_EVENT: Short = 0x02 //快门按键
        const val HOLD_EVENT: Short = 0x04 //扳机按键
        const val MID_EVENT: Short = 0x08 //摇杆中键
        const val RC_EVENT: Short = 0x10 //摇杆
        const val TOUCH_EVENT: Short = 0x20 //触摸
        const val DW_EVENT: Short = 0x40 //拨轮
        const val PB_EVENT: Short = 0x80 //电源按键

        const val MID_CAL_GET: Short = 0x00
        const val MID_CAL_SET: Short = 0x01

        const val GRF_IDLE: Short = 0x00
        const val GRF_ANGLE: Short = 0x01
        const val GRF_SPEED: Short = 0x02


        const val REC_MODE_START: Short = 0X01
        const val REC_MODE_END: Short = 0X00
        const val REC_MODE_INIT: Short = 0x02

        const val CAMERA_TYPE_BACK: Short = 0X00
        const val CAMERA_TYPE_FRONT: Short = 0X01

        const val ETD_ITEM_HEADER: Short = 0x00 //整个埋点数据的header
        const val ETD_ITEM_FPON: Short = 0x01 //fast power on，快速开机下的事件项
        const val ETD_ITEM_KPON: Short = 0x02 //key power on，按键开机下的事件项
        const val ETD_ITEM_FPO: Short = 0x03 //fast power off，快速关机下的事件项
        const val ETD_ITEM_KPO: Short = 0x04 //key power off，按键关机下的事件项
        const val ETD_ITEM_FOPO: Short = 0x05 //force power off，强制关机下的事件项
        const val ETD_ITEM_ERR: Short = 0x06 //错误状态下的事件项
        const val ETD_ITEM_CF: Short = 0x07
        const val ETD_ITEM_YAW_360: Short = 0x08 //Yaw轴360°转动事件项
        const val ETD_BLE_ITEM_HEADER: Short = 0x00;   // 蓝牙应用埋点数据的 header
        const val ETD_BLE_ITEM_DOCKKIT: Short = 0x01;  // 获取 DOCKKIT 的事件项
        const val ETD_BLE_ITEM_QUICK_START: Short = 0x02;  // 快速开拍事件项

        const val GRF_ANGLE_SEQ_PROCESS: Short = 0x02
        const val GRF_INDEX_FINISH: Short = 0x04
        const val GRF_ROLL_FINISH: Short = 0x05
        const val GRF_ANGLE_NOT_SUPPORT: Short = 0x08

        const val DW_SRC_VALUE_DISABLE: Short = 0
        const val DW_SRC_VALUE_ENABLE: Short = 0X01

        const val ETS_GET: Short = 0
        const val ETS_SET: Short = 0X01

        const val GAF_BACK_CENTER: Short = 0x00 //回中，同扳机键双击
        const val GAF_VH: Short = 0x01 //横竖拍，同切换键双击
        const val GAF_FLIP: Short = 0x02 //翻转，同扳机键三击
        const val GAF_RC_CLEAR: Short = 0x03 //摇杆构图的清零
    }

    object PtzCmd {
        const val CMD_SHAKE_HAND: Short = 0x30
        const val CMD_DEVICE_INFO: Short = 0x31
        const val CMD_SET_ACTIVE_TIME: Short = 0x32
        const val CMD_GET_ACTIVE_TIME: Short = 0x33
        const val CMD_DEVICE_STATUS: Short = 0x34
        const val CMD_ZOOM_SCALE: Short = 0x35
        const val CMD_BACK_CENTER: Short = 0x36
        const val CMD_GIMBAL_VIBRATION: Short = 0x37
        const val CMD_SET_CAMERA_TYPE: Short = 0x38
        const val CMD_ENABLE_HAND_DRAG: Short = 0x39
        const val CMD_DISABLE_HAND_DRAG: Short = 0x3A
        const val CMD_ACTION: Short = 0x3B


        const val CMD_SETTINGS_READ: Short = 0X40
        const val CMD_SETTINGS_WRITE: Short = 0X41
        const val CMD_GIMBAL_CAL: Short = 0X42
        const val CMD_VERTICAL_TRIM: Short = 0X43
        const val CMD_GIMBAL_CAL_STATUS: Short = 0X44
        const val CMD_RESET_DEFAULT_SETTINGS: Short = 0X45
        const val CMD_ETS: Short = 0x46
        const val CMD_APP_IMU_INFO: Short = 0x47

        const val CMD_TARGETS_FOLLOW: Short = 0x50
        const val CMD_RC: Short = 0x51
        const val CMD_AUTO_ACTION: Short = 0x52
        const val CMD_PANO: Short = 0x53
        const val CMD_TIME_ELAPSE: Short = 0x54
        const val CMD_REC_MODE: Short = 0x55
        const val CMD_BASKETBALL_A2G: Short = 0x56
        const val CMD_BASKETBALL_G2A: Short = 0x57
        const val CMD_ROLL_360: Short = 0x58

        const val CMD_RC_SET: Short = 0x60
        const val CMD_RC_GET: Short = 0x61
        const val CMD_GRF_ANGLE_REACH: Short = 0x62
        const val CMD_ANGLE_SEQ_SET: Short = 0x63
        const val CMD_PANO_INDEX: Short = 0x64
        const val CMD_APP_STATUS: Short = 0x65
        const val CMD_VIRTUAL_RC: Short = 0x66

        const val CMD_MB_EVENT: Short = 0xA0 //模式（M）按键消息
        const val CMD_SB_EVENT: Short = 0xA1 //快门按键消息
        const val CMD_HOLD_EVENT: Short = 0xA2 //扳机按键消息
        const val CMD_MID_EVENT: Short = 0xA3 //摇杆中键消息
        const val CMD_RC_EVENT: Short = 0xA4 //摇杆按键消息
        const val CMD_TOUCH_EVENT: Short = 0xA5 //触摸消息
        const val CMD_DW_EVENT: Short = 0xA6 //拨轮消息
        const val CMD_PB_EVENT: Short = 0xA7 //电源按键消息
        const val CMD_GIMBAL_EVENT: Short = 0xA8 //一键环拍结束事件


        const val CMD_APP_HB: Short = 0xB0
        const val CMD_EVENT_EANBLE: Short = 0xB1
        const val CMD_EVENT_DISABLE: Short = 0xB2
        const val CMD_GET_EVENT_STATUS: Short = 0xB3
        const val CMD_DW_DATA: Short = 0xB4

        const val CMD_ERROR: Short = 0xE0
        const val CMD_TEST: Short = 0xE1
        const val CMD_MID_CAL: Short = 0xE2
        const val CMD_UPDATE_SN: Short = 0xE3
        const val CMD_GET_UUID: Short = 0xE4
        const val CMD_GET_BLE_VERSION: Short = 0xE5
        const val CMD_GET_ETD: Short = 0xE6
        const val CMD_CLEAR_ETD: Short = 0xE7
        const val CMD_GET_ETD_BLE: Short = 0xEB;
        const val CMD_CLEAR_ETD_BLE: Short = 0xEC;


        const val CMD_UPDATE_RESET: Short = 0xF0
        const val CMD_UPDATE_SHAKE_HAND: Short = 0xF1
        const val CMD_UPDATE_INFO: Short = 0xF2
        const val CMD_UPDATING: Short = 0xF3
        const val CMD_UPDATED: Short = 0xF4
        const val CMD_UPDATE_REBOOT: Short = 0xF5

        /** AI跟踪模块命令  */
        const val CMD_AI_TRACKER_DEVICE_INFO: Short = 0x20
        const val CMD_AI_TRACKER_SHAKE_HAND: Short = 0x21
        const val CMD_AI_TRACKER_UPDATE_RESET: Short = 0x22
        const val CMD_AI_TRACKER_UPDATE_SHAKE_HAND: Short = 0x23
        const val CMD_AI_TRACKER_UPDATE_INFO: Short = 0x24
        const val CMD_AI_TRACKER_UPDATING: Short = 0x25
        const val CMD_AI_TRACKER_UPDATED: Short = 0x26
        const val CMD_AI_TRACKER_UPDATE_COMPLETE: Short = 0x27
        const val CMD_AI_TRACKER_UPDATE_FINISH: Short = 0x28
        const val CMD_AI_TRACKER_FOLLOW_DATA: Short = 0x29
        const val CMD_AI_TRACKER_SETTING_READ: Short = 0x2A
        const val CMD_AI_TRACKER_SETTING_WRITE: Short = 0x2B

        fun isNotification(cmd: Short): Boolean {
            return listOf(
                CMD_DEVICE_STATUS,
                CMD_MB_EVENT,
                CMD_SB_EVENT,
                CMD_HOLD_EVENT,
                CMD_MID_EVENT,
                CMD_RC_EVENT,
                CMD_TOUCH_EVENT,
                CMD_DW_EVENT,
                CMD_PB_EVENT,
                CMD_GIMBAL_CAL_STATUS,
                CMD_GRF_ANGLE_REACH,
                CMD_BASKETBALL_G2A,
                CMD_GIMBAL_EVENT
            ).contains(cmd)
        }

        fun isUpgradCmd(cmd: Short): Boolean {
            return listOf(
                CMD_AI_TRACKER_DEVICE_INFO,
                CMD_AI_TRACKER_SHAKE_HAND,
                CMD_AI_TRACKER_UPDATE_RESET,
                CMD_AI_TRACKER_UPDATE_SHAKE_HAND,
                CMD_AI_TRACKER_UPDATE_INFO,
                CMD_AI_TRACKER_UPDATING,
                CMD_AI_TRACKER_UPDATED,
                CMD_AI_TRACKER_UPDATE_COMPLETE,
                CMD_AI_TRACKER_UPDATE_FINISH,
                CMD_AI_TRACKER_FOLLOW_DATA,
                CMD_UPDATE_RESET,
                CMD_UPDATE_SHAKE_HAND,
                CMD_UPDATE_INFO,
                CMD_UPDATING,
                CMD_UPDATED,
                CMD_UPDATE_REBOOT
            ).contains(cmd)
        }
    }

    /**
     * TEM_延时摄影的模式
     * TE_轨迹摄影开始/暂停
     */
    object TEM {
        const val TEM_STATIC: Short = 0x00 //静态延时
        const val TEM_LEFT_TO_RIGHT: Short = 0x01 //从左到右
        const val TEM_RIGHT_TO_LEFT: Short = 0x02 //从右到左
        const val TEM_CUSTOM: Short = 0x03 //自定义

        const val TE_DELETE_LAST_POINT: Short = 0xF0
        const val TE_START_EXE: Short = 0x10 //开始延时
        const val TE_STOP_EXE: Short = 0x20 //停止延时
    }

    object REC_MODE {
        const val REC_PANO_CAPTURE: Short = 0x00
        const val REC_NORMAL_CAPTURE: Short = 0x01
        const val REC_NORMAL_RECORD: Short = 0x02
        const val REC_TIME_LAPSE: Short = 0x03
        const val REC_TIME_SHIFT: Short = 0x04
        const val REC_FILM_MODE: Short = 0x05
        const val REC_SLOW_MOTION: Short = 0x06
        const val REC_BASKETBALL: Short = 0x07
        const val REC_SCREEN_RECORDING_TRACKING: Short = 0x08
        const val REC_DOLLY_ZOOM: Short = 0x09 //滑动变焦
        const val REC_NULL: Short = 0xFF
    }

    object PANO_MODE {
        const val GPT_3X3_START: Short = 0x00
        const val GPT_3X3_STOP: Short = 0x01
        const val GPT_180_START: Short = 0x10
        const val GPT_180_STOP: Short = 0x11
        const val GPT_SPHERICAL_START: Short = 0x20
        const val GPT_SPHERICAL_STOP: Short = 0x21
        const val GPT_240_START: Short = 0x30
        const val GPT_240_STOP: Short = 0x31
        const val GPT_SPHERICAL_0_5_START: Short = 0x40
        const val GPT_SPHERICAL_0_5_STOP: Short = 0x41
        const val GPT_SPHERICAL_1_0_START: Short = 0x50
        const val GPT_SPHERICAL_1_0_STOP: Short = 0x51
    }

    object HAND_DRAG {
        const val GHDF_ROLL: Short = 0x01
        const val GHDF_PITCH: Short = 0x02
        const val GHDF_YAW: Short = 0x04
    }

    object TRACK_SENSITIVITY_MODE {
        const val TS_NORMAL: Short = 0x00
        const val TS_SENSITIVE: Short = 0x01
        const val TS_HILAG: Short = 0x02
    }

    object PANO_INDEX_FRAME {
        const val PIF_IDLE: Short = 0x00
        const val PIF_SPHERICAL_0_5: Short = 0x01
        const val PIF_SPHERICAL_1_0: Short = 0x02
    }

    object ROLL_360_MODE {
        const val GROLL_IDLE: Short = 0x00 //保留
        const val GROLL_INIT: Short = 0x01 //云台根据盗梦空间顺/逆时针设置，ROLL轴转至盗梦空间起始位置
        const val GROLL_MOVE: Short = 0x02 //云台根据盗梦空间速度设置，执行ROLL轴旋转动作
        const val GROLL_STOP: Short = 0x03 //终止盗梦空间动作，ROLL轴复位（用于过程中停止）
    }

    object AI_TRACKER_FRAME {
        const val SF_ALL: Short = 0x00
        const val SF_STANDBY_MEM: Short = 0x01 // AI追踪模块随开随关
        const val SF_AUTO_STANDBY_TIME: Short = 0x02 // AI追踪模块自动休眠时间
        const val SF_ONE_PLAM_SHOOT: Short = 0x03 // AI追踪模块一步开拍配置
        const val SF_UNKNOWN: Short = 0xFF
    }

    object PHONE_BRAND {
        const val PHONEBRAND_IDLE: Short = 0x00
        const val PHONEBRAND_IOS: Short = 0x01
        const val PHONEBRAND_HUAWEI: Short = 0x02
        const val PHONEBRAND_HONOR: Short = 0x03
        const val PHONEBRAND_SAMSUNG: Short = 0x04
        const val PHONEBRAND_OPPO: Short = 0x05
        const val PHONEBRAND_VIVO: Short = 0x06
        const val PHONEBRAND_ONEPLUS: Short = 0x07
        const val PHONEBRAND_REALME: Short = 0x08
        const val PHONEBRAND_GOOGLE: Short = 0x09
        const val PHONEBRAND_Nothing: Short = 0x0A
        const val PHONEBRAND_MEIZU: Short = 0x0B
        const val PHONEBRAND_XIAOMI: Short = 0x0C
        const val PHONEBRAND_REDMI: Short = 0x0D
        const val PHONEBRAND_OTHER: Short = 0xF0
    }
}
