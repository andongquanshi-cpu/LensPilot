package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.AssistantLanguageCtrl

internal class SetAssistantLanguageCmd(private val request: AssistantLanguageCtrl) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.setAssistantLanguage(request)
    }
}
