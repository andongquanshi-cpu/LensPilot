package com.arashivision.fmg.response

class FmgVibrationResp(var requestID: Long)
