package com.arashivision.fmg.fmgparser.ota

import com.arashivision.fmg.fmgparser.FmgByteUtils

class OtaFirmwarePacket {
    private var mIndex_L: Byte = 0
    private var mIndex_H: Byte = 0
    private val mData = ByteArray(16)
    private var mCrc_L: Byte = 0
    private var mCrc_H: Byte = 0

    fun pack(index: Int, data: ByteArray) {
        val indexByte = FmgByteUtils.intToUint16ByteArray(index)
        this.mIndex_L = indexByte[0]
        this.mIndex_H = indexByte[1]

        // 替换第一个 System.arraycopy
        data.copyInto(this.mData, 0, 0, data.size)

        val crcData = ByteArray(18).apply {
            this[0] = mIndex_L
            this[1] = mIndex_H
            mData.copyInto(this, 2, 0, 16)
        }

        val crc = FmgByteUtils.otaCrc16(crcData)

        this.mCrc_L = crc[0]
        this.mCrc_H = crc[1]
    }

    val packetData: ByteArray
        get() {
            val packet = ByteArray(20)
            packet[0] = mIndex_L
            packet[1] = mIndex_H
            mData.copyInto(packet, 2, 0, 16)
            packet[18] = mCrc_L
            packet[19] = mCrc_H
            return packet
        }
}
