// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/Go2BlePacket.kt
package com.arashivision.onedriver.packet

import insta360.messages.MessageCode

/**
 * Go2BlePacket的Kotlin实现 - 对应C++中的Go2BlePacket类
 * 专门处理Go2设备的蓝牙数据包格式
 */
class Go2BlePacket private constructor(
    private val rawBuf: ByteArray,
) {


    companion object {
        /**
         * 获取BLE包头部大小
         * C++版本：BlePacketDef = header(1) + direction(1) + typeCmd(1) + length(2) = 5字节
         */
        fun getBlePacketHeadSize(): Int = 5

        /**
         * 获取最大消息内容大小
         */
        fun getMaxMessageContentSize(isClassicPipe: Boolean): Int {
           return getMaxCompatiblePacketSize(isClassicPipe) - getBlePacketHeadSize() - Packet.getMessageHeadSize()
        }

        /**
         * 探测包大小
         * C++版本：直接返回length字段，不是总大小
         */
        fun probePacketSize(buf: ByteArray, size: Int): Int {
            if (size < 4) return -1 // 至少需要4字节才能读取length字段

            // BLE包格式：前5字节是头部，第4-5字节是长度（小端序）
            val length = (buf[3].toInt() and 0xFF) or ((buf[4].toInt() and 0xFF) shl 8)
            return length // 直接返回length字段，不是总大小
        }

        /**
         * 创建新的BLE包
         * 对应C++版本的newBlePacket逻辑
         */
        fun newBlePacket(
            messageMethod: MessageCode,
            messageContentType: MessageContentType,
            messageEndFlag: Int,
            messageDirection: MessageDirection,
            messageId: Long,
            messageContent: ByteArray,
            isClassicPipe: Boolean,
        ): Go2BlePacket {
            val blePacketHeadSize = getBlePacketHeadSize()
            val connectSize = Packet.getTotalPacketSize(messageContent)

            require(messageContent.size <= getMaxMessageContentSize(isClassicPipe)) { "Content size exceeds maximum" }

            // 计算padding
            var paddingSize = 0
            if (connectSize % 512 == 0) {
                paddingSize = 1
            }

            // 创建Packet内容 - 对应C++的contentBuf
            val contentData = ByteArray(connectSize)

            // 写入PacketDef结构 - 对应C++的contentPktBuf
            val packetHeadSize = Packet.getPacketHeadSize()
            val messageHeadSize = Packet.getMessageHeadSize()

            // PacketDef: length (4字节)
            contentData[0] = (connectSize and 0xFF).toByte()
            contentData[1] = ((connectSize shr 8) and 0xFF).toByte()
            contentData[2] = ((connectSize shr 16) and 0xFF).toByte()
            contentData[3] = ((connectSize shr 24) and 0xFF).toByte()

            // PacketDef: type (1字节)
            contentData[4] = PacketType.Message.value.toByte()

            // PacketDef: paddingLength (2字节)
            contentData[5] = (paddingSize and 0xFF).toByte()
            contentData[6] = ((paddingSize shr 8) and 0xFF).toByte()

            // MessageDef: method (2字节)
            contentData[7] = (messageMethod.value and 0xFF).toByte()
            contentData[8] = ((messageMethod.value shr 8) and 0xFF).toByte()

            // MessageDef: contentType (1字节)
            contentData[9] = messageContentType.value.toByte()

            // MessageDef: messageId + direction + end (4字节)
            val messageIdBits = messageId and 0x3FFFFFFF
            val directionBit = if (messageDirection == MessageDirection.CameraToPhone) 1L else 0L
            val endBit = messageEndFlag.toLong() and 0x1
            val combinedBits = messageIdBits or (directionBit shl 30) or (endBit shl 31)

            contentData[10] = (combinedBits and 0xFF).toByte()
            contentData[11] = ((combinedBits shr 8) and 0xFF).toByte()
            contentData[12] = ((combinedBits shr 16) and 0xFF).toByte()
            contentData[13] = ((combinedBits shr 24) and 0xFF).toByte()

            // MessageDef: rsv (2字节) - 保留字段，设为0
            contentData[14] = 0
            contentData[15] = 0

            // 写入消息内容
            messageContent.copyInto(
                destination = contentData,
                destinationOffset = packetHeadSize + messageHeadSize,
                startIndex = 0,
                endIndex = messageContent.size
            )

            // 创建完整的BLE包 - 对应C++的allBuf
            val totalSize = blePacketHeadSize + connectSize + 2 // +2 for CRC
            val allData = ByteArray(totalSize)

            // 写入BLE包头 - 对应C++的BlePacketDef
            allData[0] = 0xFF.toByte() // header - 固定值
            allData[1] = 0x07.toByte() // direction - 固定值
            allData[2] = 0x40.toByte() // typeCmd - 固定值
            allData[3] = (connectSize and 0xFF).toByte() // length (低字节)
            allData[4] = ((connectSize shr 8) and 0xFF).toByte() // length (高字节)

            // 复制Packet内容
            contentData.copyInto(
                destination = allData,
                destinationOffset = blePacketHeadSize,
                startIndex = 0,
                endIndex = connectSize
            )

            // 计算并写入CRC
            val crc = crc16Check(allData, totalSize - 2, 0xFFFF)
            allData[totalSize - 2] = (crc and 0xFF).toByte()
            allData[totalSize - 1] = ((crc shr 8) and 0xFF).toByte()

            return Go2BlePacket(allData)
        }

        /**
         * 从普通包创建BLE包
         */
        fun newBlePacketFromPacket(packet: Packet): Go2BlePacket {
            val blePacketHeadSize = getBlePacketHeadSize()
            val connectSize = packet.toBytes().size
            val totalSize = blePacketHeadSize + connectSize + 2 // +2 for CRC
            val allData = ByteArray(totalSize)

            // 写入BLE包头 - 对应C++的BlePacketDef
            allData[0] = 0xFF.toByte() // header - 固定值
            allData[1] = 0x07.toByte() // direction - 固定值
            allData[2] = 0x40.toByte() // typeCmd - 固定值
            allData[3] = (connectSize and 0xFF).toByte() // length (低字节)
            allData[4] = ((connectSize shr 8) and 0xFF).toByte() // length (高字节)

            // 复制Packet内容
            packet.toBytes().copyInto(
                destination = allData,
                destinationOffset = blePacketHeadSize,
                startIndex = 0,
                endIndex = connectSize
            )

            // 计算并写入CRC
            val crc = crc16Check(allData, totalSize - 2, 0xFFFF)
            allData[totalSize - 2] = (crc and 0xFF).toByte()
            allData[totalSize - 1] = ((crc shr 8) and 0xFF).toByte()

            return Go2BlePacket(allData)
        }

        /**
         * 从缓冲区创建BLE包
         * 对应C++版本的newBlePacketFromBuf逻辑
         */
        fun newBlePacketFromBuf(packetBuf: ByteArray): Go2BlePacket? {
            val size = packetBuf.size

            if (size < getBlePacketHeadSize() + 2) return null // 至少需要头部+CRC

            // 从正确的偏移量读取length字段
            val contentSize =
                (packetBuf[3].toInt() and 0xFF) or ((packetBuf[4].toInt() and 0xFF) shl 8)
            if (size != getBlePacketHeadSize() + contentSize + 2) return null

            // 验证CRC
            val crc = crc16Check(packetBuf, getBlePacketHeadSize() + contentSize, 0xFFFF)
            val expectedCrc = (packetBuf[getBlePacketHeadSize() + contentSize].toInt() and 0xFF) or
                    ((packetBuf[getBlePacketHeadSize() + contentSize + 1].toInt() and 0xFF) shl 8)

            if (crc != expectedCrc) return null

            return Go2BlePacket(packetBuf)
        }

        /**
         * 创建BLE同步包
         * 对应C++版本的newBleSyncPacket逻辑
         */
        fun newBleSyncPacket(data: ByteArray): Go2BlePacket {
            val contentSize = data.size
            val totalSize = getBlePacketHeadSize() + contentSize + 2

            val bufData = ByteArray(totalSize)

            // 写入头部 - 对应C++的BlePacketDef结构
            bufData[0] = 0xFF.toByte() // header - 同步包标识
            bufData[1] = 0x07.toByte() // direction
            bufData[2] = 0x41.toByte() // typeCmd
            bufData[3] = (contentSize and 0xFF).toByte() // length (低字节)
            bufData[4] = ((contentSize shr 8) and 0xFF).toByte() // length (高字节)

            // 写入数据
            data.copyInto(
                destination = bufData,
                destinationOffset = getBlePacketHeadSize(),
                startIndex = 0,
                endIndex = contentSize
            )

            // 计算并写入CRC
            val crc = crc16Check(bufData, getBlePacketHeadSize() + contentSize, 0xFFFF)
            bufData[getBlePacketHeadSize() + contentSize] = (crc and 0xFF).toByte()
            bufData[getBlePacketHeadSize() + contentSize + 1] = ((crc shr 8) and 0xFF).toByte()

            return Go2BlePacket(bufData)
        }

        /**
         * 创建BLE包2（特殊格式）
         * 对应C++版本的newBlePacket2逻辑
         */
        fun newBlePacket2(direction: Int, typeCmd: Int, data: ByteArray): Go2BlePacket {
            val contentSize = data.size
            val totalSize = getBlePacketHeadSize() + contentSize + 2

            val bufData = ByteArray(totalSize)

            // 写入头部 - 对应C++的BlePacketDef结构
            bufData[0] = 0xFF.toByte() // header - 固定值
            bufData[1] = direction.toByte() // direction
            bufData[2] = typeCmd.toByte() // typeCmd
            bufData[3] = (contentSize and 0xFF).toByte() // length (低字节)
            bufData[4] = ((contentSize shr 8) and 0xFF).toByte() // length (高字节)

            // 写入数据
            data.copyInto(
                destination = bufData,
                destinationOffset = getBlePacketHeadSize(),
                startIndex = 0,
                endIndex = contentSize
            )

            // 计算并写入CRC
            val crc = crc16Check(bufData, getBlePacketHeadSize() + contentSize, 0xFFFF)
            bufData[getBlePacketHeadSize() + contentSize] = (crc and 0xFF).toByte()
            bufData[getBlePacketHeadSize() + contentSize + 1] = ((crc shr 8) and 0xFF).toByte()

            return Go2BlePacket(bufData)
        }

        /**
         * 创建开启经典蓝牙(SPP)的BLE包
         * Direction: APP_CMD_DIRECT_APP_TO_BT(0x0C)
         * CMD: APP_CMD_PHONE_BT_SPP_START=0x04
         * data:
         * struct {
         * uint32 session_id; // 会话id，可随机
         * uint8 connect_type; //  0:广播扫描；1：直连
         * }
         *
         * @doc https://arashivision.feishu.cn/docx/ALPudc6GBobNf2x8ifFcxxshn3f
         */
        fun newOpenClassicBluetoothPacket(sessionId: Long, connectType: Int): Go2BlePacket {
            val data = ByteArray(5)
            data[0] = (sessionId and 0xFF).toByte()
            data[1] = ((sessionId shr 8) and 0xFF).toByte()
            data[2] = ((sessionId shr 16) and 0xFF).toByte()
            data[3] = ((sessionId shr 24) and 0xFF).toByte()
            data[4] = connectType.toByte()
            return newBlePacket2(0x0C, 0x04, data)
        }

        /**
         * 创建AI语音就绪的BLE包
         * Direction: APP_CMD_DIRECT_APP_TO_BT(0x0C)
         * CMD: APP_CMD_PHONE_AI_VOICE_READY=0x06
         * data:
         * struct {
         * uint32 session_id; // 会话id，可随机
         * uint8 phone_platform;// 0 :ios ; 1: Android；2：鸿蒙
         * }
         *
         * @doc https://arashivision.feishu.cn/docx/ALPudc6GBobNf2x8ifFcxxshn3f
         */
        fun newAiVoiceReadyPacket(sessionId: Long, phonePlatform: Int): Go2BlePacket {
            val data = ByteArray(5)
            data[0] = (sessionId and 0xFF).toByte()
            data[1] = ((sessionId shr 8) and 0xFF).toByte()
            data[2] = ((sessionId shr 16) and 0xFF).toByte()
            data[3] = ((sessionId shr 24) and 0xFF).toByte()
            data[4] = phonePlatform.toByte()
            return newBlePacket2(0x0C, 0x06, data)
        }

        /**
         * 创建手机型号的BLE包
         * Direction: APP_CMD_DIRECT_APP_TO_BT(0x0C)
         * CMD: APP_CMD_PHONE_MODEL=0x0B
         * data:
         * struct {
         * uint8 phone_model; // 手机型号：01--华为(暂华为手机使用)
         * }
         *
         * @doc https://arashivision.feishu.cn/docx/ALPudc6GBobNf2x8ifFcxxshn3f
         */
        fun newPhoneModelPacket(phoneModel: Int): Go2BlePacket {
            val data = ByteArray(1)
            data[0] = phoneModel.toByte()
            return newBlePacket2(0x0C, 0x0B, data)
        }

        /**
         * 获取最大兼容包大小
         */
        private fun getMaxCompatiblePacketSize(isClassicPipe: Boolean): Int {
            val maxPacketSize = if (isClassicPipe) ProtocolConstants.MAX_CLASSIC_PHOTO_TO_CAMERA_PACKET_SIZE else ProtocolConstants.MAX_BLUETOOTH_PHOTO_TO_CAMERA_PACKET_SIZE
            return if (maxPacketSize % 512 == 0) maxPacketSize - 1 else maxPacketSize
        }

        /**
         * CRC16校验
         */
        private fun crc16Check(buf: ByteArray, len: Int, value: Int): Int {
            var crc = value
            for (i in 0 until len) {
                crc = crc xor (buf[i].toInt() and 0xFF)
                for (j in 0 until 8) {
                    if (crc and 1 != 0) {
                        crc = (crc shr 1) xor 0xA001
                    } else {
                        crc = crc shr 1
                    }
                }
            }
            return crc
        }
    }

    fun getRawBuf(): ByteArray {
        return rawBuf
    }
}