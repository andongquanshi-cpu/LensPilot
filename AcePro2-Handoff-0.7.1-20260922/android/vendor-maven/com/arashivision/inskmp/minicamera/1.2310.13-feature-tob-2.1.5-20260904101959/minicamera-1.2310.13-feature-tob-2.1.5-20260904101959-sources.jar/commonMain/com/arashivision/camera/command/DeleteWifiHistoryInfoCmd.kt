package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class DeleteWifiHistoryInfoCmd(private val ssid: String) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.deleteWifiHistoryInfo(ssid)
    }
}
