package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.SetFileExtra

class SetFileExtraCmd(private val setFileExtra: SetFileExtra) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setFileExtra(setFileExtra)
    }
}
