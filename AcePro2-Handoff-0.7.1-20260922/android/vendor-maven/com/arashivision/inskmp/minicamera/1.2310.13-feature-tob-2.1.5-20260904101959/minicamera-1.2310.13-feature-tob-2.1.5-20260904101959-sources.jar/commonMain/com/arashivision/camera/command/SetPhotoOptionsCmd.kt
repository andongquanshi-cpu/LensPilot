package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions

class SetPhotoOptionsCmd(
    private val mFuncMode: Int,
    private val optionList: List<PhotographyOptionType>,
    private val mPhotoOptions: PhotographyOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setPhotographyOptions(mFuncMode,optionList, mPhotoOptions)
    }
}
