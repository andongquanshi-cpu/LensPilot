package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.onecamera.OneDriver

class SetFmgRoll360ActionCmd(private val action: PtzRoll360Action) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetRoll360Action(action)
    }
}
