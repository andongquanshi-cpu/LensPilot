package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.camera.listener.IBleScanListener
import com.arashivision.common.Log
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleScanCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.ScanResultCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.arashivision.onecamera.OneDriver

class BleScanCmd(private val mBleScanListener: IBleScanListener) : BleScanCallbackCore(), InstaCmdExe {

    // 主构造函数：接收 scanTimeout, autoConnect 和 IBleScanListener
    constructor(
        scanTimeout: Long,
        autoConnect: Boolean,
        bleScanListener: IBleScanListener,
    ) : this(bleScanListener) {
        // 在主构造函数体中初始化扫描规则
        BleManagerCore.initScanRule(
            BleScanRuleConfigCore.Builder()
                .setScanTimeOut(scanTimeout)
                .setAutoConnect(autoConnect)
                .build()
        )
    }

    // 次构造函数：接收 BleScanRuleConfigCore 和 IBleScanListener
    constructor(
        scanRuleConfig: BleScanRuleConfigCore,
        bleScanListener: IBleScanListener,
    ) : this(bleScanListener) {
        // 在次构造函数体中直接使用传入的配置
        BleManagerCore.initScanRule(scanRuleConfig)
    }

    override fun onScanFinished(scanResultList: List<BleDeviceCore>) {
        mBleScanListener.onScanFinished(scanResultList)
    }


    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        Log.d("---", "one driver = $oneDrvier")
        BleManagerCore.scan(this)
        return null
    }

    override fun onScanStarted(errorCode: Int) {
        mBleScanListener.onScanStarted(errorCode)
    }

    override fun onRawScanResult(callbackType: Int, result: ScanResultCore?) {
        mBleScanListener.onRawScanResult(callbackType, result)
    }

    override fun onScanning(bleDevice: BleDeviceCore?) {
        mBleScanListener.onScanning(bleDevice)
    }

    override fun onScanUpdate(bleDevice: List<BleDeviceCore>) {
        mBleScanListener.onScanUpdate(bleDevice)
    }

    override fun onScanReject() {
        mBleScanListener.onScanReject()
    }
}
