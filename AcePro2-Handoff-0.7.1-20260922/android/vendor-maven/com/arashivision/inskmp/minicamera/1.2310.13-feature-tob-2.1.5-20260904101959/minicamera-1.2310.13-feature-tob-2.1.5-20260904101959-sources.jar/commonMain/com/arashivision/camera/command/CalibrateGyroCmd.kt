package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CalibrateGyro

class CalibrateGyroCmd(private val mCalibrateGyro: CalibrateGyro) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.calibrateGyro(mCalibrateGyro)
    }
}
