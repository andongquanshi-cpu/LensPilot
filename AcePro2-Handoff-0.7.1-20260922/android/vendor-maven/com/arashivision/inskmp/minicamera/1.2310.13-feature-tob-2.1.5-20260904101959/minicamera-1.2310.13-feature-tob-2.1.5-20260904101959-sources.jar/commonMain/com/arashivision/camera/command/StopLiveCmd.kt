package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
class StopLiveCmd() : InstaCmdExe {

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return null
    }
}
