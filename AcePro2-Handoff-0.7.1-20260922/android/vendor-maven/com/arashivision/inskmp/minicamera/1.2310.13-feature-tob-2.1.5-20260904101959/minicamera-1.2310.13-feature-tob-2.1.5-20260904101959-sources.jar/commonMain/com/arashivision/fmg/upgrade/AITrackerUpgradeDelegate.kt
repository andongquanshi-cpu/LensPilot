package com.arashivision.fmg.upgrade

import com.arashivision.fmg.FmgCommDelegate
import com.arashivision.fmg.FmgCommDelegate.IRequestCallback
import com.arashivision.fmg.fmgparser.FmgPhoneEnum
import com.arashivision.fmg.fmgparser.ptz.PtzDataPacket
import com.arashivision.fmg.fmgparser.ptz.PtzStatus
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzBps
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzCmd
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzFrame
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzAITrackUpdateInfoReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzDataReqMessage
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzEmptyReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpDateShakeHandReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateRebootReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateResetReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateingReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetAiTrackerUpdatingRespMsg
import com.arashivision.common.BleLog
import com.arashivision.common.Build
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.common.coroutines.ioScope
import kotlinx.coroutines.launch

/**
 * AI追踪模块固件升级 代理类
 * 升级协议：https://arashivision.feishu.cn/wiki/VFquwVUkgi1UvGkh55Pc31PlnVM
 *
 * 升级流程：
 * 单文件传输流程：RESET(重置数据) ->SHAKE_HAND(握手) ->UPDATE_INFO(发送传输文件信息) ->UPDATING(发送文件数据) ->UPDATED(文件数据发送完成，通知固件校验文件) ->COMPLETE(完成)
 * 重复单文件传输流程发完所有文件： ->UPDATE_FINISH（通知所有文件发送完成）
 *
 */
class AITrackerUpgradeDelegate(
    private val mFmgCommDelegate: FmgCommDelegate,
) {
    private val AI_TRACKER_UPGRADE_TIMEOUT_MS: Long = 10000
    private val SPLIT_WRITE_NUM = 244

    private var mIAITrackerUpgradeCallback: IAITrackerUpgradeCallback? = null

    interface IAITrackerUpgradeCallback {
        fun onProgressChanged(requestId: Long, progress: Float)

        fun onCancel(requestId: Long)

        fun onUpgradeError(requestId: Long, error: Int)

        fun onUpgradeSuccess(requestId: Long)
    }

    private enum class UpgradeStep {
        RESET, SHAKE_HAND, UPDATE_INFO, UPDATING, UPDATED, COMPLETE, FINISH
    }

    private interface UpgradeStepCallback {
        fun onUpgradeStepSuccess(
            state: UpgradeStep,
            requestId: Long,
            responseDataPacket: PtzDataPacket,
        )
    }

    private var mAITrackUpgradeConfig: AITrackUpgradeConfig? = null
    private var indexPackage = 0

    private var uploadedSize: Long = 0

    private var mFmgUpgradeStepCallback: UpgradeStepCallback? = null

    fun startUpgrade(
        upgradeConfig: AITrackUpgradeConfig,
        upgradeCallback: IAITrackerUpgradeCallback?,
    ): Long {
        // 设置蓝牙写入分包数；
        BleManagerCore.setSplitWriteNum(SPLIT_WRITE_NUM)
        mIAITrackerUpgradeCallback = upgradeCallback
        indexPackage = 0
        uploadedSize = 0
        mAITrackUpgradeConfig = upgradeConfig
        ioScope.launch {
            BleLog.d("start AITrackerUpgrade $upgradeConfig")
            if (mAITrackUpgradeConfig!!.isValid) {
                mFmgUpgradeStepCallback = object : UpgradeStepCallback {
                    override fun onUpgradeStepSuccess(
                        state: UpgradeStep,
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        BleLog.d(
                            "AITracker onUpgradeStepSuccess state = " + state.name + ", frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                responseDataPacket.frame
                            )
                        )
                        val upgradeBean: AITrackUpgradeConfig?
                        when (state) {
                            UpgradeStep.RESET -> ptzUpdateHandShakeStep1(
                                requestId,
                                this
                            )

                            UpgradeStep.SHAKE_HAND -> {
                                upgradeBean = mAITrackUpgradeConfig
                                if (upgradeBean != null && upgradeBean.requestId == requestId) {
                                    ptzUpdateInfo(
                                        requestId,
                                        upgradeBean.getOTAFileDataByIndex(indexPackage),
                                        this
                                    )
                                } else {
                                    notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                }
                            }

                            UpgradeStep.UPDATE_INFO -> {
                                upgradeBean = mAITrackUpgradeConfig
                                if (upgradeBean != null && upgradeBean.requestId == requestId) {
                                    val fileData =
                                        upgradeBean.getOTAFileDataByIndex(indexPackage)
                                    ptzUpdating(requestId, fileData, 0, this)
                                } else {
                                    notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                }
                            }

                            UpgradeStep.UPDATING -> ptzUpdated(requestId, this)
                            UpgradeStep.UPDATED -> ptzUpdateComplete(requestId, this)
                            UpgradeStep.COMPLETE -> {
                                upgradeBean = mAITrackUpgradeConfig
                                if (upgradeBean != null && upgradeBean.requestId == requestId) {
                                    indexPackage++
                                    if (indexPackage < upgradeBean.upgradePartSize) {
                                        ptzUpdateReset(requestId, mFmgUpgradeStepCallback!!)
                                    } else {
                                        ptzUpdateFinish(requestId, mFmgUpgradeStepCallback!!)
                                    }
                                } else {
                                    notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                }
                            }

                            UpgradeStep.FINISH -> {
                                upgradeBean = mAITrackUpgradeConfig
                                if (upgradeBean != null && upgradeBean.requestId == requestId) {
                                    notifyOTASuccess(requestId)
                                } else {
                                    notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                }
                            }
                        }
                    }
                }
                ptzUpdateReset(upgradeConfig.requestId, mFmgUpgradeStepCallback)
            } else {
                notifyOTAError(upgradeConfig.requestId, PtzFrame.ACK_ERR_LENGTH.toInt())
            }
        }
        return upgradeConfig.requestId
    }

    fun cancelUpgrade() {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && mIAITrackerUpgradeCallback != null) {
            BleLog.d("AITracker cancel FMG upgrade")
            mIAITrackerUpgradeCallback!!.onCancel(upgradeConfig.requestId)
        }
        mAITrackUpgradeConfig = null
    }

    private fun ptzUpdateReset(requestId: Long, callback: UpgradeStepCallback?) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_AI_TRACKER_UPDATE_RESET, PtzFrame.REQ_UPDATE_RESET)
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateResetReqMsg()
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val upgradeConfig1 = mAITrackUpgradeConfig
                        if (upgradeConfig1 != null && upgradeConfig1.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback?.onUpgradeStepSuccess(
                                    UpgradeStep.RESET,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdateReset error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }

                }
            )
        }
    }

    private fun ptzUpdateHandShakeStep1(requestId: Long, callback: UpgradeStepCallback) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val phoneBrandValue: Short = FmgPhoneEnum.Companion.findByKey(Build.BRAND).value
            val ptzDataPacket = PtzDataPacket(
                PtzCmd.CMD_AI_TRACKER_UPDATE_SHAKE_HAND,
                PtzFrame.REQ_SHAKE_HAND_STEP_1
            )
            val ptzDataReqMessage: PtzDataReqMessage =
                PtzUpDateShakeHandReqMsg(PtzStatus.PROTOCOL, phoneBrandValue, PtzBps.SHAKE_HAND)
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean1 = mAITrackUpgradeConfig
                        if (fmgUpgradeBean1 != null && fmgUpgradeBean1.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_SHAKE_HAND) {
                                ptzUpdateHandShakeStep2(requestId, callback)
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdateHandShakeStep1 error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                })
        }
    }

    private fun ptzUpdateHandShakeStep2(requestId: Long, callback: UpgradeStepCallback) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val phoneBrandValue: Short = FmgPhoneEnum.Companion.findByKey(Build.BRAND).value
            val ptzDataPacket = PtzDataPacket(
                PtzCmd.CMD_AI_TRACKER_UPDATE_SHAKE_HAND,
                PtzFrame.REQ_SHAKE_HAND_STEP_2
            )
            val ptzDataReqMessage: PtzDataReqMessage =
                PtzUpDateShakeHandReqMsg(PtzStatus.PROTOCOL, phoneBrandValue, PtzBps.SHAKE_HAND)
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val upgradeConfig = mAITrackUpgradeConfig
                        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_SHAKE_HAND) {
                                callback.onUpgradeStepSuccess(
                                    UpgradeStep.SHAKE_HAND,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdateHandShakeStep2 error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                })
        }
    }

    private fun ptzUpdateInfo(
        requestId: Long,
        fileData: ByteArray?,
        callback: UpgradeStepCallback,
    ) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val updateInfoSize: Int = PtzAITrackUpdateInfoReqMsg.Companion.UPDATE_INFO_DATA_SIZE
            if (fileData == null || fileData.size < updateInfoSize) {
                BleLog.e("AITracker ptzUpdateInfo error, " + (if (fileData == null) "fileDara is null" else ("fileData size error =" + fileData.size)))
                notifyOTAError(requestId, PtzFrame.ACK_ERR_LENGTH.toInt())
                return
            }
            val updateInfo =
                fileData.sliceArray((fileData.size - updateInfoSize) until fileData.size)

            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_AI_TRACKER_UPDATE_INFO, PtzFrame.REQ_NONE)
            val ptzDataReqMessage = PtzAITrackUpdateInfoReqMsg(updateInfo)
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val upgradeConfig1 = mAITrackUpgradeConfig
                        if (upgradeConfig1 != null && upgradeConfig1.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_NEED_UPDATE) {
                                callback.onUpgradeStepSuccess(
                                    UpgradeStep.UPDATE_INFO,
                                    requestId,
                                    responseDataPacket
                                )
                            } else if (frame == PtzFrame.ACK_NO_NEED_UPDATE) {
                                uploadOTAProgressChanged(requestId, fileData.size.toLong())
                                callback.onUpgradeStepSuccess(
                                    UpgradeStep.COMPLETE,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdateInfo error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                }, AI_TRACKER_UPGRADE_TIMEOUT_MS, false
            )
        }
    }

    /**
     * 通过递归的方式发送升级文件数据
     * 目前是每次发送 100(packNum)包，每包最多238(packDataSize)字节
     *
     * @param requestId
     * @param remainingFileData
     * @param packetSerial 包序号
     * @param callback
     */
    private fun ptzUpdating(
        requestId: Long,
        remainingFileData: ByteArray?,
        packetSerial: Int,
        callback: UpgradeStepCallback,
    ) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val ptzDataPacket =
                AITrackerUpgradeDataPacket(
                    PtzCmd.CMD_AI_TRACKER_UPDATING,
                    packetSerial.toShort()
                )
            var packetData = remainingFileData
            var ptzUpdateingReqMsg: PtzUpdateingReqMsg? = null
            BleLog.d("ptzUpdating 剩余 packetData length:" + packetData!!.size)
            for (i in 0 until upgradeConfig.packNum) {
                if (packetData!!.size >= upgradeConfig.packDataSize) {
                    ptzUpdateingReqMsg = PtzUpdateingReqMsg(
                        packetData.sliceArray(0 until upgradeConfig.packDataSize)
                    )
                    ptzDataPacket.addPtzUpdateingReqMsg(ptzUpdateingReqMsg)
                    packetData =
                        packetData.sliceArray(ptzUpdateingReqMsg.packData()!!.size until packetData.size)
                } else {
                    ptzUpdateingReqMsg =
                        PtzUpdateingReqMsg(packetData.sliceArray(packetData.indices))
                    ptzDataPacket.addPtzUpdateingReqMsg(ptzUpdateingReqMsg)
                    break
                }
            }

            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket,
                ptzUpdateingReqMsg!!, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val upgradeConfig = mAITrackUpgradeConfig
                        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_ERR_INVALID_FRAME) {
                                val packetDataContextLength = ptzDataPacket.dataContextLength
                                uploadOTAProgressChanged(
                                    requestId,
                                    packetDataContextLength.toLong()
                                )
                                val remainDataSize =
                                    remainingFileData!!.size - packetDataContextLength
                                if (remainDataSize > 0) {
                                    if (isRepeatUpdatingSerial(
                                            responseDataPacket,
                                            packetSerial + upgradeConfig.packNum
                                        )
                                    ) {
                                        // 丢弃重复回复
                                        BleLog.d("updatingSerial < (packetSerial + upgradeConfig.getPackNum())")
                                        return
                                    }
                                    val newFileData =
                                        remainingFileData.sliceArray((remainingFileData.size - remainDataSize) until remainingFileData.size)
                                    ptzUpdating(
                                        requestId,
                                        newFileData,
                                        packetSerial + upgradeConfig.packNum,
                                        callback
                                    )
                                } else {
                                    callback.onUpgradeStepSuccess(
                                        UpgradeStep.UPDATING,
                                        requestId,
                                        responseDataPacket
                                    )
                                }
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdating error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                }, upgradeConfig.sendSinglePackTimeout, upgradeConfig.isWriteWithResponse
            )
        }
    }

    /**
     * 检查升级包序号是否重复
     * 可能出现以下情况：
     * 1. 发送第100 包时固件超时未回复，APP 重送第100 包
     * 2. 这可能会导致固件回复两次第100 包
     * 此时需要丢弃固件的第二次第100 包的回复
     *
     */
    private fun isRepeatUpdatingSerial(
        responseDataPacket: PtzDataPacket,
        packetSerial: Int,
    ): Boolean {
        var updatingSerial: Long = -1
        val aiTrackerUpdatingRespMsg = responseDataPacket.unPack()
        if (aiTrackerUpdatingRespMsg is PtzGetAiTrackerUpdatingRespMsg) {
            updatingSerial = aiTrackerUpdatingRespMsg.updatingSerial
        }
        BleLog.d("ptzUpdating updatingSerial: $updatingSerial packetSerial: $packetSerial")
        // 老固件不会返回updatingIndex；默认为-1，则-1 不处理
        return updatingSerial != -1L && updatingSerial < packetSerial
    }

    private fun ptzUpdated(requestId: Long, callback: UpgradeStepCallback) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_AI_TRACKER_UPDATED, PtzFrame.REQ_UPDATED)
            val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean1 = mAITrackUpgradeConfig
                        if (fmgUpgradeBean1 != null && fmgUpgradeBean1.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback.onUpgradeStepSuccess(
                                    UpgradeStep.UPDATED,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdated error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                }, AI_TRACKER_UPGRADE_TIMEOUT_MS, false
            )
        }
    }

    private fun ptzUpdateComplete(requestId: Long, callback: UpgradeStepCallback) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_AI_TRACKER_UPDATE_COMPLETE, PtzFrame.REQ_UPDATE_REBOOT)
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateRebootReqMsg()
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val upgradeConfig = mAITrackUpgradeConfig
                        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback.onUpgradeStepSuccess(
                                    UpgradeStep.COMPLETE,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdateReboot error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                }, AI_TRACKER_UPGRADE_TIMEOUT_MS, false
            )
        }
    }

    private fun ptzUpdateFinish(requestId: Long, callback: UpgradeStepCallback) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_AI_TRACKER_UPDATE_FINISH, PtzFrame.REQ_NONE)
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateRebootReqMsg()
            mFmgCommDelegate.addNewRequestTask(
                requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val upgradeConfig = mAITrackUpgradeConfig
                        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback.onUpgradeStepSuccess(
                                    UpgradeStep.FINISH,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "AITracker ptzUpdateReboot error, frame = " + FmgCommDelegate.Companion.formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                }, AI_TRACKER_UPGRADE_TIMEOUT_MS, false
            )
        }
    }

    private fun uploadOTAProgressChanged(requestId: Long, dataSize: Long) {
        val upgradeBean = mAITrackUpgradeConfig
        if (upgradeBean != null && upgradeBean.requestId == requestId) {
            uploadedSize += dataSize
            if (mIAITrackerUpgradeCallback != null) {
                val percent = uploadedSize / 1f / upgradeBean.upgradeFileTotalSize
                mIAITrackerUpgradeCallback!!.onProgressChanged(requestId, percent)
            }
        }
    }

    private fun notifyOTAError(requestId: Long, error: Int) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            if (mIAITrackerUpgradeCallback != null) {
                mIAITrackerUpgradeCallback!!.onUpgradeError(requestId, error)
            }
            mAITrackUpgradeConfig = null
        }
    }

    private fun notifyOTASuccess(requestId: Long) {
        val upgradeConfig = mAITrackUpgradeConfig
        if (upgradeConfig != null && upgradeConfig.requestId == requestId) {
            if (mIAITrackerUpgradeCallback != null) {
                mIAITrackerUpgradeCallback!!.onUpgradeSuccess(requestId)
            }
            mAITrackUpgradeConfig = null
        }
    }
}
