package com.arashivision.fmg

class RcScrValueData internal constructor(upDown: Byte, leftRight: Byte) {
    val upDown: Int = upDown.toInt()
    val leftRight: Int = leftRight.toInt()
}
