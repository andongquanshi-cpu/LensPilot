package com.arashivision.camera.command.ble

import com.arashivision.ble.OneBleIOProxy
import com.arashivision.camera.InstaCameraState
import com.arashivision.camera.InstaSdkExperiment
import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.camera.command.classic.ClassicConnectData
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IWifiProxyDataListener
import com.arashivision.camera.wifiproxy.WifiProxyDataParser
import com.arashivision.common.BleLog
import com.arashivision.common.coroutines.ioScope
import com.arashivision.common.coroutines.runOnMainThread
import com.arashivision.inskmp.insble.BleLogCore
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleWriteCallbackCore
import com.arashivision.inskmp.insble.callback.ClassicCallback
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BluetoothGattCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import com.arashivision.inskmp.insble.utils.BleUtils
import com.arashivision.onecamera.OneDriver
import kotlinx.atomicfu.atomic
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.concurrent.Volatile
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class ClassicConnectCmd(
    private var mBleDevice: BleDeviceCore,
    private val bleConnectListener: IBleConnectListener?,
    private var classicConnectData: ClassicConnectData?,
    private val mHeartHandler: CoroutineScope?,
    private val mWifiProxyDataListener: IWifiProxyDataListener,
    private val isUseUcd2: Boolean,
) : SynchronizedObject(), InstaCmdExe, OneBleIOProxy {
    private var isFail = false

    private var mOneDrvier: OneDriver? = null
    private var mHasOpenBle = false
    private var mHasNotifySuccess = false
    private var mHasNotifyConnectSuccess = false
    private var mSyncResult: SyncResult? = null
    private var isBleProxy = false
    private var heatJob: Job? = null
    private var job: Job? = null
    private var writePrint: Int = 0
    private var readPrint: Int = 0
    private val syncData = byteArrayOf(
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte(),
        0xab.toByte(),
        0xba.toByte()
    )

    // 标记当前蓝牙连接是否已经失败，即调用了 notifyBleFailStatus
    @Volatile
    private var alreadyFailed = false

    // 用于 onWrite 方法的线程安全锁
    private val writeMutex = Mutex()

    private val writeScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default.limitedParallelism(1)
    )

    // 用于 onCharacteristicChanged 方法的线程安全锁，防止数据乱序和状态竞争
    private val characteristicChangedMutex = Mutex()

    // 单线程协程作用域，用于保证 onCharacteristicChanged 回调的顺序处理
    // 使用 limitedParallelism(1) 限制并行度为 1，确保回调按照到达的顺序依次处理
    // 这是 KMP 兼容的方式，避免多线程调度导致的乱序问题
    private val characteristicChangedScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default.limitedParallelism(1)
    )

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any {
        this.mOneDrvier = oneDrvier
        // 经典蓝牙
        val nativeBleDevice = mBleDevice.nativeBleDevice
        if (mBleDevice.isClassicBluetooth && nativeBleDevice is String && classicConnectData != null) { // 经典蓝牙
            connectClassicBluetooth(nativeBleDevice)
            return 0
        }
        return 0
    }

    private fun connectClassicBluetooth(address: String) {
        // 经典蓝牙
        BleManagerCore.connectClassic(address, object : ClassicCallback {
            override fun connectSuccess() {
                mOneDrvier?.setClassicBluetoothStatus(true)
                ioScope.launch {
                    val ret = mOneDrvier?.openCameraBle(this@ClassicConnectCmd, isUseUcd2)
                    mHasOpenBle = ret == 0
                    isBleProxy = classicConnectData!!.isBleProxy // 判断 ucp、ucd
                    mOneDrvier?.setBleProxy(isBleProxy)
                    if (isBleProxy) {
                        mOneDrvier?.writeBleSync(syncData)
                    } else {
//                        mOneDrvier?.putData(data, isBleProxy) // 心跳
                    }
                    BleLogCore.i("classic_bluetooth, connectSuccess: openCameraBle=$ret, isBleProxy=$isBleProxy")
                    // 通道(openCameraBle + 握手 writeBleSync)就绪后再通知上层。
                    // 否则上层收到成功即进入 CHECK_TYPE 下发首批 syncOptions，会早于通道打开/握手，
                    // 导致首批 GetOptions 写入未就绪通道而丢失（需等重试才补回）。
                    runOnMainThread { bleConnectListener?.onConnectClassicSuccess(mBleDevice, 0) }
                }
            }

            override fun connectFailed(errorCode: Int) {
                mOneDrvier?.setClassicBluetoothStatus(false)
                runOnMainThread { bleConnectListener?.onConnectClassicFail(mBleDevice, BleExceptionCore(
                    errorCode,
                    "classic bluetooth connect failed"
                )) }
            }

            override fun onReceive(byteArray: ByteArray) {
                characteristicChangedScope.launch {
                    characteristicChangedMutex.withLock {
                        onReceiveClassicData(byteArray)
//                        BleLogCore.i("classic_bluetooth, onReceive-> putData(${byteArray.toHexString(HexFormat.Default)})")
//                        mOneDrvier?.putData(byteArray, true)
                    }
                }
            }

            override fun writeHeart() {
                BleLogCore.i("classic_bluetooth, writeHeart")
                writeSendHeartBeat(1_000)
            }

        })
    }

    private suspend fun onReceiveClassicData(data: ByteArray) {
        if (alreadyFailed) {
            BleLog.w("${TAG}, onReceiveClassicData when already failed.")
            return
        }
        // 使用单线程协程作用域确保回调按顺序处理
        characteristicChangedScope.launch {
            characteristicChangedMutex.withLock {
                mOneDrvier?.let {
                    if (parseWakeUpData(data)) {
                        BleLog.w("${TAG}, data is wake up authorization, skip check sync.")
                        return@withLock
                    }
                    mOneDrvier!!.putData(data, isBleProxy)
                } ?: BleLog.e("${TAG}, mOneDrvier == null")
            }
        }
    }

    /**
     * 解析唤醒是否成功的通知
     *
     * @param data
     * @return false：代表该data不是唤醒的通知； true：代表该data是唤醒的通知
     */
    @OptIn(ExperimentalStdlibApi::class)
    private fun parseWakeUpData(data: ByteArray): Boolean {
        val hexString = data.toHexString(HexFormat.Default)
        readPrint++
        if (hexString.length < 300 || readPrint > 30) {
            readPrint = 0
            BleLog.d("parseWakeUpData($TAG) data size=${data.size}, " + BleUtils.printProtoBytes(hexString))
        }
        if (hexString.isNotEmpty() && hexString.startsWith("ff0d03") && data.size >= 6) {
            if (data[5].toInt() == 0) {
                BleLog.w("wake up authorization failed")
                notifyBleFailStatus(
                    mBleDevice,
                    BleExceptionCore(
                        BleExceptionCore.ERROR_CODE_WAKE_UP_AUTHORIZATION_FAIL,
                        "wake up authorization failed"
                    )
                )
            } else if (data[5].toInt() == 1) {
                BleLog.d("wake up authorization success")
            }
            return true
        } else if ("ff0640080008000000b00000016d90" == hexString) {
            // 蓝牙 busy
            BleLog.d("ble is busy")
        }
        return false
    }

    /**
     * 解析同步包
     *
     * @param data
     */
    @OptIn(ExperimentalStdlibApi::class)
    private fun praseSync(data: ByteArray): Boolean {
        val hexString = data.toHexString(HexFormat.Default)
        if (hexString.isNotEmpty() && hexString.startsWith("ff0641")) {
            //write data to ble
            return true
        }
        return false
    }

    /**
     * 蓝牙打开后jni回调，写数据，将数据写到蓝牙中
     */
    @OptIn(ExperimentalStdlibApi::class)
    override fun onWrite(mData: ByteArray) {
        writeScope.launch {
            writeMutex.withLock {
                val dataHexString = mData.toHexString(HexFormat.Default)
                writePrint++
                if (dataHexString.length < 300 || writePrint > 30) {
                    writePrint = 0
                    BleLog.i("${TAG}, onWrite data=${BleUtils.printProtoBytes(dataHexString)}")
                }

                isFail = false
                val isResumed = atomic(false)
                suspendCoroutine { continuation ->
                    BleManagerCore.classicWrite(
                        mData,
                        false,
                        object : BleWriteCallbackCore() {
                            override fun onWriteSuccess(
                                current: Int,
                                total: Int,
                                justWrite: ByteArray?,
                            ) {
//                                BleLog.d("${TAG}, write success")
                                if (!isResumed.value) {
                                    isResumed.value = true
                                    continuation.resume(Unit)
                                }
                            }

                            override fun onWriteFailure(exception: BleExceptionCore) {
                                BleLog.d("${TAG},  write error $exception, ${this@ClassicConnectCmd}")
                                bleConnectListener?.onWriteFailed(mBleDevice, exception)
                                isFail = true
                                if (!isResumed.value) {
                                    isResumed.value = true
                                    continuation.resume(Unit)
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onWifiProxyData(proxyData: ByteArray) {
        val wifiProxyData = WifiProxyDataParser.parse(proxyData, isUseUcd2)
        if (wifiProxyData != null) {
            mWifiProxyDataListener.onReadWifiProxyData(wifiProxyData)
        } else {
            BleLog.e("WifiProxyDataParser failed")
        }
    }

    private fun tryNotifyConnectSuccess() {
        //发送心跳包
        if (mHeartHandler != null && mOneDrvier != null &&
            classicConnectData?.mIsHeartBeatEnable == true &&
            heatJob?.isActive != true) {
            heatJob = mHeartHandler.launch {
                delay(1500)
                mOneDrvier?.sendHeartBeat()
                if (InstaSdkExperiment.bleHeartDelayExperiment <= 0) {
                    repeat(Int.MAX_VALUE) {
                        delay(1000)
                        mOneDrvier?.sendHeartBeat()
                    }
                }
            }
        }
        if (mHasNotifySuccess && mSyncResult != null && !mHasNotifyConnectSuccess) {
            mHasNotifyConnectSuccess = true
            notifyBleSuccessStatus(
                mSyncResult!!.bleDevice,
                mSyncResult!!.gatt,
                mSyncResult!!.status
            )
        }
    }

    private fun writeSendHeartBeat(bleHeartDelayExperiment: Long) {
        if (mHeartHandler != null && mOneDrvier != null &&
            classicConnectData?.mIsHeartBeatEnable == true
            && heatJob?.isActive != true
        ) {
            heatJob = mHeartHandler.launch {
                delay(bleHeartDelayExperiment)
                mOneDrvier?.sendHeartBeat()
                if (bleHeartDelayExperiment <= 0) {
                    repeat(Int.MAX_VALUE) {
                        delay(1000)
                        mOneDrvier?.sendHeartBeat()
                    }
                }
            }
        }
    }

    private fun notifyBleSuccessStatus(
        bleDevice: BleDeviceCore?,
        gatt: BluetoothGattCore?,
        status: Int,
    ) {
        runOnMainThread { bleConnectListener!!.onConnectSuccess(bleDevice, gatt, status) }
        InstaCameraState.create().changeState(InstaCameraState.OPEN_COMPLETE)
    }

    private fun notifyBleFailStatus(bleDevice: BleDeviceCore, bleException: BleExceptionCore) {
        if (alreadyFailed) {
            BleLog.w("notifyBleFailStatus when already failed.")
            return
        }
        alreadyFailed = true
        cancelReceiveSyncPackTimeoutRunnable()
        runOnMainThread { bleConnectListener!!.onConnectClassicFail(bleDevice, bleException) }
        InstaCameraState.create().changeState(InstaCameraState.ERROR)
    }

    private fun postReceiveSyncPackTimeoutRunnable(
        bleDevice: BleDeviceCore,
        gatt: BluetoothGattCore,
    ) {
        job = ioScope.launch {
            delay(5000)
            val openFail: BleExceptionCore =
                BleExceptionCore(BleExceptionCore.ERROR_CODE_SYNC_PACK, "")
            notifyBleFailStatus(bleDevice, openFail)
        }

    }

    private fun cancelReceiveSyncPackTimeoutRunnable() {
        job?.cancel()
    }

    private class SyncResult {
        var bleDevice: BleDeviceCore? = null
        var gatt: BluetoothGattCore? = null
        var status: Int = 0
    }

    companion object {
        private val TAG: String = "classic_bluetooth"
    }
}

