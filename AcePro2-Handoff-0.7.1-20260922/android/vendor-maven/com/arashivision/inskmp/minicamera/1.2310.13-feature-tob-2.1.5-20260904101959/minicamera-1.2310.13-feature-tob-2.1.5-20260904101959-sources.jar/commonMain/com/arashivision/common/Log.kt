package com.arashivision.common

expect object Log {
    fun v(tag: String, msg: String)
    fun d(tag: String, msg: String)
    fun i(tag: String, msg: String)
    fun w(tag: String, msg: String)
    fun e(tag: String, msg: String)
    fun t(tag: String, msg: String)

    fun setCameraLoggerCallback(callback: ICameraLoggerCallback)

}

interface ICameraLoggerCallback {
    fun onLogV(tag: String, msg: String)
    fun onLogD(tag: String, msg: String)
    fun onLogI(tag: String, msg: String)
    fun onLogW(tag: String, msg: String)
    fun onLogE(tag: String, msg: String)
    fun onLogT(tag: String, msg: String)
}