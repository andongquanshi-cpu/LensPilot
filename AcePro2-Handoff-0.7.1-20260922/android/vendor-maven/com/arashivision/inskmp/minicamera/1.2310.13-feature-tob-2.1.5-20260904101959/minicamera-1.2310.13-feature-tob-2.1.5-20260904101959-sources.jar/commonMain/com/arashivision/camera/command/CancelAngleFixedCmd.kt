package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CancelAngleFixed

class CancelAngleFixedCmd(
    private val cancelAngleFixed: CancelAngleFixed,
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.cancelAngleFixed(cancelAngleFixed)
    }
}
