package com.arashivision.camera.command.ble


import com.arashivision.camera.InstaCameraState
import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IFmgConnectSyncListener
import com.arashivision.fmg.FmgCommDelegate
import com.arashivision.onecamera.OneDriver
import com.arashivision.common.BleLog
import com.arashivision.common.coroutines.runOnMainThread
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleGattCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import kotlinx.coroutines.CoroutineScope

class FMGConnectCmd(
    private var mBleDevice: BleDeviceCore,
    private val mBleConnectListener: IBleConnectListener?,
    private val mHeartHandler: CoroutineScope?,
) :
    InstaCmdExe {

    private var mOneDrvier: OneDriver? = null

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any {
        mOneDrvier = oneDrvier
        BleManagerCore.connect(mBleDevice, mBleCallBack)
        return 0
    }


    private val mBleCallBack: BleGattCallbackCore = object : BleGattCallbackCore() {
        override fun onStartConnect() {
            notifyBleStartConnectStatus()
        }

        override fun onConnectFail(bleDevice: BleDeviceCore, exception: BleExceptionCore) {
            notifyBleFailStatus(bleDevice, exception)
        }

        override fun onConnectSuccess(bleDevice: BleDeviceCore, gatt: Any, status: Int) {
            mBleDevice = bleDevice
            BleLog.d("connect success = " + bleDevice.key + ", status = " + status)
            //            if (bleDevice.getDevice().getBondState() != BluetoothDevice.BOND_BONDED) {
//                registerBondReceiver();
//            }
            val oneDriver = mOneDrvier
            if (oneDriver != null) {
                oneDriver.openFmgBle(
                    FmgCommDelegate(
                        oneDriver,
                        bleDevice,
                        mHeartHandler
                    )
                )
                oneDriver.ptzConnectSync(bleDevice, object : IFmgConnectSyncListener {
                    override fun onSyncSuccess() {
                        notifyBleSuccessStatus(bleDevice, gatt, status)
                    }

                    override fun onSyncError(error: Int) {
                        notifyBleFailStatus(bleDevice, BleExceptionCore(error, error.toString()))
                    }
                })
            }
        }

        override fun onDisConnected(
            isActiveDisConnected: Boolean,
            device: BleDeviceCore,
            gatt: Any,
            status: Int,
        ) {
            notifyBleDisconnectStatus(isActiveDisConnected, device, gatt, status)
        }
    }

    /***********************  Listener   */
    private fun notifyBleStartConnectStatus() {
        runOnMainThread { mBleConnectListener?.onStartConnect() }
        InstaCameraState.create().changeState(InstaCameraState.OPENING)
    }

    private fun notifyBleDisconnectStatus(
        isActiveDisConnected: Boolean,
        device: BleDeviceCore,
        gatt: Any,
        status: Int,
    ) {
//        unregisterBondReceiver();
        runOnMainThread {
            mBleConnectListener?.onDisConnected(
                isActiveDisConnected,
                device,
                gatt,
                status
            )
        }
            ?: mBleConnectListener?.onDisConnected(isActiveDisConnected, device, gatt, status)
        InstaCameraState.create().changeState(InstaCameraState.IDEL)
    }

    private fun notifyBleSuccessStatus(bleDevice: BleDeviceCore, gatt: Any, status: Int) {
        runOnMainThread { mBleConnectListener?.onConnectSuccess(bleDevice, gatt, status) }
        InstaCameraState.create().changeState(InstaCameraState.OPEN_COMPLETE)
    }

    private fun notifyBleFailStatus(bleDevice: BleDeviceCore, bleException: BleExceptionCore) {
//        unregisterBondReceiver();
        runOnMainThread { mBleConnectListener?.onConnectFail(bleDevice, bleException) }
        InstaCameraState.create().changeState(InstaCameraState.ERROR)
    }


    companion object {
        private val TAG: String = FMGConnectCmd::class.simpleName.toString()
    }
}
