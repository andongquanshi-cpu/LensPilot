package com.arashivision.onedriver

import com.arashivision.onecamera.OneDriverInfo
import insta360.messages.MessageCode

/**
 * 信息类型映射器
 * 将 MessageCode 转换为对应的 InfoType
 * 对应 C++ 中的 InfoTypeFromMessageCode 函数
 */
object InfoTypeMapper {

    /**
     * 从 MessageCode 获取对应的 InfoType
     * @param messageCode 消息代码
     * @return 对应的信息类型，如果未找到则返回 UNKNOWN
     */
    fun infoTypeFromMessageCode(messageCode: MessageCode?): Int {
        return messageCodeToInfoTypeMap[messageCode] ?: OneDriverInfo.Response.InfoType.UNKNOWN
    }

    /**
     * MessageCode 到 InfoType 的映射表
     * 对应 C++ 中的 kNotifyTypeInfoMap
     */
    private val messageCodeToInfoTypeMap = mapOf(
        // 固件升级完成
        MessageCode.CAMERA_NOTIFICATION_FIRMWARE_UPGRADE_COMPLETE to OneDriverInfo.Response.InfoType.FIRMWARE_UPGRADE_COMPLETE,

        // 录像自动分割
        MessageCode.CAMERA_NOTIFICATION_CAPTURE_AUTO_SPLIT to OneDriverInfo.Response.InfoType.RECORD_AUTO_SPLIT,

        // 电池更新
        MessageCode.CAMERA_NOTIFICATION_BATTERY_UPDATE to OneDriverInfo.Response.InfoType.BATTERY_UPDATE,

        // 电池低电量
        MessageCode.CAMERA_NOTIFICATION_BATTERY_LOW to OneDriverInfo.Response.InfoType.BATTERY_LOW,

        // 充电盒电池更新
        MessageCode.CAMERA_NOTIFICATION_CHARGE_BOX_BATTERY_UPDATE to OneDriverInfo.Response.InfoType.NOTIFY_CHARGE_BOX_BATTERY_UPDATE,

        // 关机
        MessageCode.CAMERA_NOTIFICATION_SHUTDOWN to OneDriverInfo.Response.InfoType.SHUTDOWN,

        // 存储更新
        MessageCode.CAMERA_NOTIFICATION_STORAGE_UPDATE to OneDriverInfo.Response.InfoType.STORAGE_UPDATE,

        // 拍摄参数联动变更通知
        MessageCode.CAMERA_NOTIFICATION_PHOTOGRAPHY_OPTIONS_CHANGE to OneDriverInfo.Response.InfoType.PHOTOGRAPHY_OPTIONS_CHANGE,

        // 存储已满
        MessageCode.CAMERA_NOTIFICATION_STORAGE_FULL to OneDriverInfo.Response.InfoType.STORAGE_FULL,

        // 按键按下
        MessageCode.CAMERA_NOTIFICATION_KEY_PRESSED to OneDriverInfo.Response.InfoType.BUTTON_PRESSED,

        // 录像停止
        MessageCode.CAMERA_NOTIFICATION_CAPTURE_STOPPED to OneDriverInfo.Response.InfoType.RECORD_STOPPED,

        // 拍照状态更新
        MessageCode.CAMERA_NOTIFICATION_TAKE_PICTURE_STATE_UPDATE to OneDriverInfo.Response.InfoType.CAPTURE_STILL_IMAGE_STATE_UPDATE,

        // 手机插入
        MessageCode.CAMERA_NOTIFICATION_PHONE_INSERT to OneDriverInfo.Response.InfoType.PHONE_INSERT,

        // 蓝牙发现外设
        MessageCode.CAMERA_NOTIFICATION_BT_DISCOVER_PERIPHERAL to OneDriverInfo.Response.InfoType.BT_DISCOVER_PERIPHERAL,

        // 蓝牙连接外设
        MessageCode.CAMERA_NOTIFICATION_BT_CONNECTED_TO_PERIPHERAL to OneDriverInfo.Response.InfoType.BT_CONNECTED_TO_PERIPHERAL,

        // 蓝牙断开外设
        MessageCode.CAMERA_NOTIFICATION_BT_DISCONNECTED_PERIPHERAL to OneDriverInfo.Response.InfoType.BT_DISCONNECTED_PERIPHERAL,

        // 相机子模式变化
        MessageCode.CAMERA_NOTIFICATION_CAM_SUBMODE_CHANGE to OneDriverInfo.Response.InfoType.NOTIFICATION_CAM_SUBMODE_CHANGE,

        // 开始直播流
        MessageCode.PHONE_COMMAND_START_LIVE_STREAM to OneDriverInfo.Response.InfoType.START_LIVE_STREAM,

        // 停止直播流
        MessageCode.PHONE_COMMAND_STOP_LIVE_STREAM to OneDriverInfo.Response.InfoType.STOP_LIVE_STREAM,

        // I帧请求
        MessageCode.PHONE_COMMAND__IFRAME_REQUEST to OneDriverInfo.Response.InfoType.IFRAME_REQUEST,

        // 取消拍摄
        MessageCode.PHONE_COMMAND_CANCEL_CAPTURE to OneDriverInfo.Response.InfoType.CANCEL_CAPTURE,

        // 删除文件结果通知
        MessageCode.CAMERA_NOTIFICATION_DELETE_FILE_RESULT to OneDriverInfo.Response.InfoType.NOTIFICATION_DELETE_FILE_RESULT,

        // 设置选项
        MessageCode.PHONE_COMMAND_SET_OPTIONS to OneDriverInfo.Response.InfoType.SET_OPTIONS,

        // 获取选项
        MessageCode.PHONE_COMMAND_GET_OPTIONS to OneDriverInfo.Response.InfoType.GET_OPTIONS,

        // 设置摄影选项
        MessageCode.PHONE_COMMAND_SET_PHOTOGRAPHY_OPTIONS to OneDriverInfo.Response.InfoType.SET_PHOTOGRAPHY_OPTIONS,

        // 获取摄影选项
        MessageCode.PHONE_COMMAND_GET_PHOTOGRAPHY_OPTIONS to OneDriverInfo.Response.InfoType.GET_PHOTOGRAPHY_OPTIONS,

        // 获取文件附加信息
        MessageCode.PHONE_COMMAND_GET_FILE_EXTRA to OneDriverInfo.Response.InfoType.GET_FILE_EXTRA,

        // 删除文件
        MessageCode.PHONE_COMMAND_DELETE_FILES to OneDriverInfo.Response.InfoType.DELETE_FILES,

        // 获取文件列表
        MessageCode.PHONE_COMMAND_GET_FILE_LIST to OneDriverInfo.Response.InfoType.GET_FILE_LIST,

        // 获取录制文件
        MessageCode.PHONE_COMMAND_GET_RECORDING_FILE to OneDriverInfo.Response.InfoType.GET_FILE_LIST_INCLUDE_RECORDING,

        // 获取文件信息列表
        MessageCode.PHONE_COMMAND_GET_FILEINFO_LIST to OneDriverInfo.Response.InfoType.GET_FILEINFO_LIST,

        // 获取编辑信息列表
        MessageCode.PHONE_COMMAND_GET_EDITINFO_LIST to OneDriverInfo.Response.InfoType.GET_EDITINFO_LIST,

        // 设置文件附加信息
        MessageCode.PHONE_COMMAND_SET_FILE_EXTRA to OneDriverInfo.Response.InfoType.SET_FILE_EXTRA,

        // 准备获取文件包
        MessageCode.PHONE_COMMAND_PREPARE_GET_FILE_PACKAGE to OneDriverInfo.Response.InfoType.PREPARE_GET_FILE_PACKAGE,

        // 准备获取文件同步包
        MessageCode.PHONE_COMMAND_PREPARE_GET_FILE_SYNC_PACKAGE to OneDriverInfo.Response.InfoType.PREPARE_GET_FILE_SYNC_PACKAGE,

        // 获取文件包完成
        MessageCode.PHONE_COMMAND_GET_FILE_PACKAGE_FINISH to OneDriverInfo.Response.InfoType.GET_FILE_PACKAGE_FINISH,

        // 获取文件包同步完成
        MessageCode.PHONE_COMMAND_GET_FILE_PACKAGE_SYNC_FINISH to OneDriverInfo.Response.InfoType.GET_FILE_PACKAGE_SYNC_FINISH,

        // 获取延时摄影选项
        MessageCode.PHONE_COMMAND_GET_TIMELAPSE_OPTIONS to OneDriverInfo.Response.InfoType.GET_TIMELAPSE_OPTIONS,

        // 设置延时摄影选项
        MessageCode.PHONE_COMMAND_SET_TIMELAPSE_OPTIONS to OneDriverInfo.Response.InfoType.SET_TIMELAPSE_OPTIONS,

        // 擦除SD卡
        MessageCode.PHONE_COMMAND_ERASE_SD_CARD to OneDriverInfo.Response.InfoType.ERASE_SD_CARD,

        // 校准陀螺仪
        MessageCode.PHONE_COMMAND_CALIBRATE_GYRO to OneDriverInfo.Response.InfoType.CALIBRATE_GYRO,

        // 获取小缩略图
        MessageCode.PHONE_COMMAND_GET_MINI_THUMBNAIL to OneDriverInfo.Response.InfoType.GET_MINI_THUMBNAIL,

        // 测试SD卡速度
        MessageCode.PHONE_COMMAND_TEST_SD_CARD_SPEED to OneDriverInfo.Response.InfoType.TEST_SD_CARD_SPEED,

        // 重启相机
        MessageCode.PHONE_COMMAND_REBOOT_CAMERA to OneDriverInfo.Response.InfoType.REBOOT_CAMERA,

        // 开启相机WiFi
        MessageCode.PHONE_COMMAND_OPEN_CAMERA_WIFI to OneDriverInfo.Response.InfoType.OPEN_CAMERA_WIFI,

        // 关闭相机WiFi
        MessageCode.PHONE_COMMAND_CLOSE_CAMERA_WIFI to OneDriverInfo.Response.InfoType.CLOSE_CAMERA_WIFI,

        // 重置相机WiFi
        MessageCode.PHONE_COMMAND_RESET_WIFI to OneDriverInfo.Response.InfoType.RESET_CAMERA_WIFI,

        // 设置相机WiFi抢占启用
        MessageCode.PHONE_COMMAND_SET_WIFI_SEIZE_ENABLE to OneDriverInfo.Response.InfoType.SET_CAMERA_WIFI_SEIZE_ENABLE,

        // 设置WiFi连接信息
        MessageCode.PHONE_COMMAND_SET_WIFI_CONNECTION_INFO to OneDriverInfo.Response.InfoType.SET_WIFI_CONNECTION_INFO,

        // 获取WiFi连接信息
        MessageCode.PHONE_COMMAND_GET_WIFI_CONNECTION_INFO to OneDriverInfo.Response.InfoType.GET_WIFI_CONNECTION_INFO,

        // 设置可用WiFi
        MessageCode.PHONE_COMMAND_SET_AVAILABLE_WIFI to OneDriverInfo.Response.InfoType.SET_AVAILABLE_WIFI,

        // 获取连接的蓝牙
        MessageCode.PHONE_COMMAND_GET_CONNECTED_BT_PERIPHERALS to OneDriverInfo.Response.InfoType.GET_CONNECT_BT,

        // 获取当前拍摄状态
        MessageCode.PHONE_COMMAND_GET_CURRENT_CAPTURE_STATUS to OneDriverInfo.Response.InfoType.GET_CURRENT_CAPTURE_STATUS,

        // 扫描蓝牙
        MessageCode.PHONE_COMMAND_SCAN_BT_PERIPHERAL to OneDriverInfo.Response.InfoType.SCAN_BT,

        // 连接蓝牙
        MessageCode.PHONE_COMMAND_CONNECT_TO_BT_PERIPHERAL to OneDriverInfo.Response.InfoType.CONNECT_TO_BT,

        // 断开蓝牙
        MessageCode.PHONE_COMMAND_DISCONNECT_BT_PERIPHERAL to OneDriverInfo.Response.InfoType.DISCONNECT_BT,

        // 相机状态通知
        MessageCode.CAMERA_NOTIFICATION_CURRENT_CAPTURE_STATUS to OneDriverInfo.Response.InfoType.CAMERA_STATUS_NOTIFY,

        // 检查授权
        MessageCode.PHONE_COMMAND_CHECK_AUTHORIZATION to OneDriverInfo.Response.InfoType.CHECK_AUTHORIZATION,

        // 取消授权
        MessageCode.PHONE_COMMAND_CANCEL_AUTHORIZATION to OneDriverInfo.Response.InfoType.CANCEL_AUTHORIZATION,

        // 请求授权
        MessageCode.PHONE_COMMAND_REQUEST_AUTHORIZATION to OneDriverInfo.Response.InfoType.REQUEST_AUTHORIZATION,

        // 取消请求授权
        MessageCode.PHONE_COMMAND_CANCEL_REQUEST_AUTHORIZATION to OneDriverInfo.Response.InfoType.CANCEL_REQUEST_AUTHORIZATION,

        // 通知授权
        MessageCode.CAMERA_NOTIFICATION_AUTHORIZATION_RESULT to OneDriverInfo.Response.InfoType.NOTIFY_AUTHORIZATION,

        // 开启相机OLED
        MessageCode.PHONE_COMMAND_OPEN_OLED to OneDriverInfo.Response.InfoType.OPEN_CAMERA_OLED,

        // 关闭相机OLED
        MessageCode.PHONE_COMMAND_CLOSE_OLED to OneDriverInfo.Response.InfoType.CLOSE_CAMERA_OLED,

        // 上传GPS
        MessageCode.PHONE_COMMAND_UPLOAD_GPS to OneDriverInfo.Response.InfoType.UPLOAD_GPS,

        // 获取陀螺仪计数
        MessageCode.PHONE_COMMAND_GET_GYRO to OneDriverInfo.Response.InfoType.GET_GYRO_COUNT,

        // 通知延时摄影状态更新
        MessageCode.CAMERA_NOTIFICATION_TIMELAPSE_STATUS_UPDATE to OneDriverInfo.Response.InfoType.NOTIFY_TIMELAPSE_STATUS_UPDATE,

        // 获取IPerf平均值
        MessageCode.PHONE_COMMAND_GET_IPERF_AVERAGE to OneDriverInfo.Response.InfoType.GET_IPERF_AVERAGE,

        // 开启IPerf
        MessageCode.PHONE_COMMAND_OPEN_IPERF to OneDriverInfo.Response.InfoType.OPEN_IPERF,

        // 关闭IPerf
        MessageCode.PHONE_COMMAND_CLOSE_IPERF to OneDriverInfo.Response.InfoType.CLOSE_IPERF,

        // LED测试
        MessageCode.FACTORY_COMMAND_LED_TEST to OneDriverInfo.Response.InfoType.LED_TEST,

        // 振动测试
        MessageCode.FACTORY_COMMAND_MOTOR_TEST to OneDriverInfo.Response.InfoType.FACTORY_VIBRATE_TEST,

        // 扬声器测试
        MessageCode.FACTORY_COMMAND_SPEAKER_TEST to OneDriverInfo.Response.InfoType.SPEAKER_TEST,

        // WiFi状态测试
        MessageCode.FACTORY_COMMAND_WIFI_STATUS_TEST to OneDriverInfo.Response.InfoType.WIFISTATUS_TEST,

        // 蓝牙状态测试
        MessageCode.FACTORY_COMMAND_BLUETOOTH_STATUS_TEST to OneDriverInfo.Response.InfoType.BLUETOOTHSTATUS_TEST,

        // 设置同步拍摄模式
        MessageCode.PHONE_COMMAND_SET_SYNC_CAPTURE_MODE to OneDriverInfo.Response.InfoType.SET_SYNC_CAPTURE_MODE,

        // 获取同步拍摄模式
        MessageCode.PHONE_COMMAND_GET_SYNC_CAPTURE_MODE to OneDriverInfo.Response.InfoType.GET_SYNC_CAPTURE_MODE,

        // 设置待机模式
        MessageCode.PHONE_COMMAND_SET_STANDBY_MODE to OneDriverInfo.Response.InfoType.SET_STANDBY_MODE,

        //
        MessageCode.PHONE_COMMAND_RESTORE_FACTORY_SETTINGS to OneDriverInfo.Response.InfoType.RESTORE_FACTORY_SETTINGS,

        // 设置相机直播信息
        MessageCode.PHONE_COMMAND_SET_CAMERA_LIVE_INFO to OneDriverInfo.Response.InfoType.SET_CAMERA_LIVE_INFO,

        // 获取相机直播信息
        MessageCode.PHONE_COMMAND_GET_CAMERA_LIVE_INFO to OneDriverInfo.Response.InfoType.GET_CAMERA_LIVE_INFO,

        // 设置WiFi状态
        MessageCode.PHONE_COMMAND_SET_WIFI_STATE to OneDriverInfo.Response.InfoType.SET_WIFI_STATE,

        // 设置云标签显示
        MessageCode.PHONE_COMMAND_SET_CLOUD_TAB_SHOW to OneDriverInfo.Response.InfoType.SET_SHOW_CLOUD_TAB,

        // 手机信息
        MessageCode.PHONE_COMMAND_PHONE_INFO to OneDriverInfo.Response.InfoType.SET_PHONE_INFO,

        // 设置WiFi模式
        MessageCode.PHONE_COMMAND_SET_WIFI_MODE to OneDriverInfo.Response.InfoType.SET_WIFI_MODE,

        // 获取WiFi模式
        MessageCode.PHONE_COMMAND_GET_WIFI_MODE to OneDriverInfo.Response.InfoType.GET_WIFI_MODE,

        // 获取WiFi扫描列表
        MessageCode.PHONE_COMMAND_GET_WIFI_SCAN_LIST to OneDriverInfo.Response.InfoType.GET_WIFI_SCAN_LIST,

        // 获取已连接WiFi列表
        MessageCode.PHONE_COMMAND_GET_CONNECTED_WIFI_LIST to OneDriverInfo.Response.InfoType.GET_CONNECTED_WIFI_LIST,

        // 开始相机直播
        MessageCode.PHONE_COMMAND_START_CAMERA_LIVE to OneDriverInfo.Response.InfoType.START_CAMERA_LIVE,

        // 停止相机直播
        MessageCode.PHONE_COMMAND_STOP_CAMERA_LIVE to OneDriverInfo.Response.InfoType.STOP_CAMERA_LIVE,

        // 通知WiFi模式变化
        MessageCode.CAMERA_NOTIFICATION_WIFI_MODE_CHANGE to OneDriverInfo.Response.InfoType.NOTIFY_WIFI_MODE_CHANGE,

        // 通知相机直播状态
        MessageCode.CAMERA_NOTIFICATION_CAMERA_LIVE_STATUS to OneDriverInfo.Response.InfoType.NOTIFY_CAMERA_LIVE_STATUS,

        // 设置相机直播准备
        MessageCode.PHONE_COMMAND_SET_CAMERA_LIVE_PREPARE to OneDriverInfo.Response.InfoType.SET_CAMERA_LIVE_PREPARE,

        // 通知相机直播在线状态
        MessageCode.CAMERA_NOTIFICATION_LIVE_ONLINE_STATUS to OneDriverInfo.Response.InfoType.NOTIFY_CAMERA_LIVE_ONLINE_STATUS,

        // 通知同步拍摄模式更新
        MessageCode.CAMERA_NOTIFICATION_SYNC_CAPTURE_MODE_UPDATE to OneDriverInfo.Response.InfoType.NOTIFICATION_SYNC_CAPTURE_MODE_UPDATE,

        // 通知蓝牙遥控版本更新
        MessageCode.CAMERA_NOTIFICATION_BT_REMOTE_VER_UPDATED to OneDriverInfo.Response.InfoType.NOTIFICATION_BT_REMOTE_VER_UPDATED,

        // 工厂按钮状态测试
        MessageCode.FACTORY_COMMAND_BUTTON_STATUS_TEST to OneDriverInfo.Response.InfoType.FACTORY_BUTTON_STATUS_TEST,

        // 工厂接触测试
        MessageCode.FACTORY_COMMAND_TP_JIUGONGGE_TEST to OneDriverInfo.Response.InfoType.FACTORY_CONTACT_TEST,

        // 工厂颜色测试
        MessageCode.FACTORY_COMMAND_LCD_COLOR_TEST to OneDriverInfo.Response.InfoType.FACTORY_COLOR_TEST,

        // 工厂USB速度测试
        MessageCode.FACTORY_COMMAND_USB_SPEED_TEST to OneDriverInfo.Response.InfoType.FACTORY_USB_SPEED_TEST,

        // 工厂LCD关闭测试
        MessageCode.FACTORY_COMMAND_USB_LCD_TP_CLOSE_TEST to OneDriverInfo.Response.InfoType.FACTORY_LCD_CLOSE_TESTT,

        // 相机温度值
        MessageCode.CAMERA_NOTIFICATION_CAM_TEMPERATURE_VALUE to OneDriverInfo.Response.InfoType.CAM_TEMPERATURE_VALUE,

        // 相机WiFi开始
        MessageCode.CAMERA_NOTIFICATION_CAM_WIFI_START to OneDriverInfo.Response.InfoType.CAM_WIFI_START,

        // 相机蓝牙消息解析失败
        MessageCode.CAMERA_NOTIFICATION_CAM_BT_MSG_ANALYZE_FAILED to OneDriverInfo.Response.InfoType.CAM_BT_MSG_ANALYZE_FAILED,

        // 实时预览开始旋转
        MessageCode.CAMERA_NOTIFICATION_LIVEVIEW_BEGIN_ROTATE to OneDriverInfo.Response.InfoType.LIVEVIEW_BEGIN_ROTATE,

        // 直播流参数更新
        MessageCode.CAMERA_NOTIFICATION_UPDATE_LIVE_STREAM_PARAMS to OneDriverInfo.Response.InfoType.LIVE_STREAM_PARAMS_UPDATE,

        // 通知曝光更新
        MessageCode.CAMERA_NOTIFICATION_EXPOSURE_UPDATE to OneDriverInfo.Response.InfoType.NOTIFY_EXPOSURE_UPDATE,

        // 通知WiFi扫描列表变化
        MessageCode.CAMERA_NOTIFICATION_WIFI_SCAN_LIST_CHANGED to OneDriverInfo.Response.InfoType.NOTIFY_WIFI_SCAN_LIST_CHANGED,

        // WiFi连接结果
        MessageCode.CAMERA_NOTIFICATION_WIFI_STATUS to OneDriverInfo.Response.InfoType.WIFI_CONNECTION_RESULT,

        // 数据导出状态通知
        MessageCode.CAMERA_NOTIFICATION_DATA_EXPORT_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_DATA_EXPORT_STATUS,

        // 通知固件升级状态到应用
        MessageCode.CAMERA_NOTIFICATION_FIRMWARE_UPGRADE_STATUS_TOAPP to OneDriverInfo.Response.InfoType.NOTIFY_FIRMWARE_UPGRADE_STATUS_TOAPP,

        // 通知云存储绑定状态
        MessageCode.CAMERA_NOTIFICATION_CLOUD_STORAGE_BIND_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_CLOUD_STORAGE_BIND_STATUS,

        // 通知应用云上传中断
        MessageCode.CAMERA_NOTIFICATION_APP_CLOUD_UPLOAD_INTERRUPT to OneDriverInfo.Response.InfoType.NOTIFICATION_APP_CLOUD_UPLOAD_INTERRUPT,

        // 设置关键时间点
        MessageCode.PHONE_COMMAND_SET_KEY_TIME_POINT to OneDriverInfo.Response.InfoType.SET_KEYTIME_POINT,

        // 设置流状态启用
        MessageCode.PHONE_COMMAND_SET_FLOWSTATE_ENABLE to OneDriverInfo.Response.InfoType.SET_FLOWSTATE_ENABLE,

        // 获取流状态启用
        MessageCode.PHONE_COMMAND_GET_FLOWSTATE_ENABLE to OneDriverInfo.Response.InfoType.GET_FLOWSTATE_ENABLE,

        // 设置单传感器
        MessageCode.PHONE_COMMAND_SET_ACTIVE_SENSOR to OneDriverInfo.Response.InfoType.SET_SINGLE_SENSOR,

        // 获取单传感器
        MessageCode.PHONE_COMMAND_GET_ACTIVE_SENSOR to OneDriverInfo.Response.InfoType.GET_SINGLE_SENSOR,

        // 获取多视频模式
        MessageCode.PHONE_COMMAND_GET_MULTI_PHOTOGRAPHY_OPTIONS to OneDriverInfo.Response.InfoType.GET_MULTI_VIDEO_MODE,

        // 设置多视频模式
        MessageCode.PHONE_COMMAND_SET_MULTI_PHOTOGRAPHY_OPTIONS to OneDriverInfo.Response.InfoType.SET_MULTI_VIDEO_MODE,

        // 充电盒连接状态更新
        MessageCode.CAMERA_NOTIFICATION_CHARGE_BOX_CONNECT_STATUS to OneDriverInfo.Response.InfoType.CHARGE_BOX_CONNECT_STATUS_UPDATE,

        // 设置按键按下参数
        MessageCode.PHONE_COMMAND_SET_BUTTON_PRESS_PARAM to OneDriverInfo.Response.InfoType.SET_BUTTON_PRESS_PARAM,

        // 获取按键按下参数
        MessageCode.PHONE_COMMAND_GET_BUTTON_PRESS_PARAM to OneDriverInfo.Response.InfoType.GET_BUTTON_PRESS_PARAM,

        // 设置访问相机文件状态
        MessageCode.PHONE_COMMAND_SET_ACCESS_CAMERA_FILE_STATE to OneDriverInfo.Response.InfoType.SET_ACCESS_CAMERA_FILE_STATE,

        // 设置应用ID
        MessageCode.PHONE_COMMAND_SET_APPID to OneDriverInfo.Response.InfoType.SET_APP_ID,

        // 通知检测到人脸
        MessageCode.CAMERA_NOTIFICATION_DETECTED_FACE to OneDriverInfo.Response.InfoType.NOTIFICATION_DETECTED_FACE,

        // 获取暗光EIS状态
        MessageCode.PHONE_COMMAND_DARK_EIS_STATUS to OneDriverInfo.Response.InfoType.GET_DARK_EIS_STATUS,

        // 通知暗光EIS状态
        MessageCode.CAMERA_NOTIFICATION_DARK_EIS_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_DARK_EIS_STATUS,

        // 快速读取器获取状态
        MessageCode.PHONE_COMMAND_QUICKREADER_GET_STATUS to OneDriverInfo.Response.InfoType.QUICKREADER_GET_STATUS,

        // 停止USB卡备份
        MessageCode.PHONE_COMMAND_STOP_USBCARD_BACKUP to OneDriverInfo.Response.InfoType.STOP_USBCARD_BACKUP,

        // 手机命令通知OTA错误
        MessageCode.PHONE_COMMAND_NOTIFY_OTA_ERROR to OneDriverInfo.Response.InfoType.PHONE_COMMAND_NOTIFY_OTA_ERROR,

        // 停止拍照
        MessageCode.PHONE_COMMAND_STOP_TAKE_PICTURE to OneDriverInfo.Response.InfoType.STOP_TAKE_PICTURE,

        // 通知支持在录制状态下拍照
        MessageCode.CAMERA_NOTIFICATION_SUPPORT_TAKE_PHOTO_ON_REC_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_SUPPORT_TAKE_PHOTO_ON_REC_STATUS,

        // 暂停录制
        MessageCode.PHONE_COMMAND_PAUSE_RECORDING to OneDriverInfo.Response.InfoType.PAUSE_RECORDING,

        // 获取P3静态HDR参数
        MessageCode.PHONE_COMMAND_GET_P3_STATIC_HDR_PARAMS to OneDriverInfo.Response.InfoType.GET_P3_STATIC_HDR_PARAMS,

        // 工厂陀螺仪测试
        MessageCode.FACTORY_COMMAND_GYROSCOPE_TEST to OneDriverInfo.Response.InfoType.FACTORY_GYRO_TEST,

        // 工厂老化测试
        MessageCode.FACTORY_COMMAND_GET_AGEINGTEST_STATUS to OneDriverInfo.Response.InfoType.FACTORY_AGEING_TEST,

        // 工厂DSP链路测试
        MessageCode.FACTORY_COMMAND_DEVLINK_TEST to OneDriverInfo.Response.InfoType.FACTORY_DSP_LINK_TEST,

        // 工厂白平衡测试
        MessageCode.FACTORY_COMMAND_VIGNETTE_DATA_SAVE to OneDriverInfo.Response.InfoType.FACTORY_WHITE_BLANCE_TEST,

        // 工厂黑电平测试
        MessageCode.FACTORY_COMMAND_BLC_DATA_SAVE to OneDriverInfo.Response.InfoType.FACTORY_BLACK_LEVEL_TEST,

        // 工厂坏点测试
        MessageCode.FACTORY_COMMAND_BPC_DATA_SAVE to OneDriverInfo.Response.InfoType.FACTORY_BAD_POINT_TEST,

        // 工厂充电盒
        MessageCode.FACTORY_COMMAND_CHARGINGBOX to OneDriverInfo.Response.InfoType.FACTORY_CHARGING_BOX,

        // 工厂充电盒按钮测试
        MessageCode.FACTORY_COMMAND_CHARGINGBOX_BUTTON_TEST to OneDriverInfo.Response.InfoType.FACTORY_CHARGING_BOX,

        // 工厂充电盒霍尔测试
        MessageCode.FACTORY_COMMAND_CHARGINGBOX_HALL_TEST to OneDriverInfo.Response.InfoType.FACTORY_CHARGING_BOX,

        // 工厂脚本JSON上传
        MessageCode.FACTORY_COMMAND_SCRIPT_JSON_UPLOAD to OneDriverInfo.Response.InfoType.FACTORY_SCRIPT_JSON_UPLOAD,

        // 工厂脚本命令上传
        MessageCode.FACTORY_COMMAND_SCRIPT_CMD_UPLOAD to OneDriverInfo.Response.InfoType.FACTORY_SCRIPT_CMD_UPLOAD,

        // 工厂脚本刷新
        MessageCode.FACTORY_COMMAND_SCRIPT_REFRESH to OneDriverInfo.Response.InfoType.FACTORY_SCRIPT_REFERSH,

        // 工厂脚本运行
        MessageCode.FACTORY_COMMAND_SCRIPT_CMD_RUN to OneDriverInfo.Response.InfoType.FACTORY_SCRIPT_RUN,

        // 工厂设置AAA工厂模式
        MessageCode.FACTORY_COMMAND_SET_AAA_FACTORYMODE to OneDriverInfo.Response.InfoType.FACTORY_SETAAA_FACTORY_MODE,

        // 工厂设置AAA正常模式
        MessageCode.FACTORY_COMMAND_SET_AAA_NORMALMODE to OneDriverInfo.Response.InfoType.FACTORY_SETAAA_NORMAL_MODE,

        // 工厂获取白平衡状态
        MessageCode.FACTORY_COMMAND_GET_WHITEBLANCE_STATUS to OneDriverInfo.Response.InfoType.FACTORY_GET_WHITEBLANCE_STATUS,

        // 工厂获取SFR状态
        MessageCode.FACTORY_COMMAND_GET_SFR_STATUS to OneDriverInfo.Response.InfoType.FACTORY_GET_SFR_STATUS,

        // 工厂获取SFR结果
        MessageCode.FACTORY_COMMAND_GET_SFR_RESULT to OneDriverInfo.Response.InfoType.FACTORY_GET_SFR_RESULT,

        // 通知需要下载文件
        MessageCode.CAMERA_NOTIFICATION_NEED_DOWNLOAD_FILE to OneDriverInfo.Response.InfoType.NOTIFICATION_NEED_DOWNLOAD_FILE,

        // 下载信息
        MessageCode.PHONE_COMMAND_DOWNLOAD_INFO to OneDriverInfo.Response.InfoType.DOWNLOAD_INFO,

        // 获取下载文件列表
        MessageCode.PHONE_COMMAND_GET_DOWNLOAD_FILE_LIST to OneDriverInfo.Response.InfoType.GET_DOWNLOAD_FILE_LIST,

        // 添加下载列表结果同步
        MessageCode.PHONE_COMMAND_ADD_DOWNLOAD_LIST_RESULT_SYNC to OneDriverInfo.Response.InfoType.ADD_DOWNLOAD_LIST_RESULT_SYNC,

        // 间隔录像1 获取间隔录像配置
        MessageCode.PHONE_COMMAND_GET_INTERVALREC_CFG to OneDriverInfo.Response.InfoType.GET_INTERVALREC_CFG,

        // 间隔录像2 设置间隔录像配置
        MessageCode.PHONE_COMMAND_SET_INTERVALREC_CFG to OneDriverInfo.Response.InfoType.SET_INTERVALREC_CFG,

        // 间隔录像3 间隔录像启动、停止
        MessageCode.PHONE_COMMAND_INTERVALREC_REC_START_STOP to OneDriverInfo.Response.InfoType.INTERVALREC_REC_START_STOP,

        // 间隔录像4 间隔录像取消
        MessageCode.PHONE_COMMAND_INTERVALREC_REC_CANCEL_CMD to OneDriverInfo.Response.InfoType.INTERVALREC_REC_CANCEL_CMD,

        // 间隔录像5 获取间隔录像状态
        MessageCode.PHONE_COMMAND_GET_INTERVAL_RECORD_STATUS to OneDriverInfo.Response.InfoType.GET_INTERVAL_RECORD_STATUS,

        // 间隔录像6 获取间隔录像场景界面配置
        MessageCode.PHONE_COMMAND_GET_INTERVALREC_SCENE_CFG to OneDriverInfo.Response.InfoType.GET_INTERVALREC_SCENE_CFG,

        // 间隔录像7 获取间隔录像交互反馈配置
        MessageCode.PHONE_COMMAND_GET_INTERVALREC_FEEDBACK_CFG to OneDriverInfo.Response.InfoType.GET_INTERVALREC_FEEDBACK_CFG,

        // 间隔录像8 设置间隔录像交互反馈配置
        MessageCode.PHONE_COMMAND_SET_INTERVALREC_FEEDBACK_CFG to OneDriverInfo.Response.InfoType.SET_INTERVALREC_FEEDBACK_CFG,

        // 间隔录像9 通知间隔录像消息
        MessageCode.CAMERA_NOTIFICATION_INTERVAL_REC_INFO to OneDriverInfo.Response.InfoType.NOTIFICATION_INTERVAL_REC_INFO,

        // 间隔录像10 通知间隔录像异常结束
        MessageCode.CAMERA_NOTIFICATION_INTERVAL_REC_RESULT to OneDriverInfo.Response.InfoType.NOTIFICATION_INTERVAL_REC_RESULT,

        // 间隔录像11 通知用户接管间隔录像拍摄事件
        MessageCode.CAMERA_NOTIFICATION_USER_TAKEOVER to OneDriverInfo.Response.InfoType.NOTIFICATION_USER_TAKEOVER,

        // 通知USB卡状态
        MessageCode.CAMERA_NOTIFICATION_USBCARD_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_USBCARD_STATUS,

        // 通知收藏变化状态
        MessageCode.CAMERA_NOTIFICATION_FAVORITE_CHANGE_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_FAVORITE_CHANGE_STATUS,

        // 设置收藏
        MessageCode.PHONE_COMMAND_SET_FAVORITE to OneDriverInfo.Response.InfoType.SET_FAVORITE,

        // 获取云存储上传状态
        MessageCode.PHONE_COMMAND_GET_CLOUD_STORAGE_UPLOAD_STATUS to OneDriverInfo.Response.InfoType.GET_CLOUD_STORAGE_UPLOAD_STATUS,

        // 设置云存储上传状态
        MessageCode.PHONE_COMMAND_SET_CLOUD_STORAGE_UPLOAD_STATUS to OneDriverInfo.Response.InfoType.SET_CLOUD_STORAGE_UPLOAD_STATUS,

        // 获取云存储绑定状态
        MessageCode.PHONE_COMMAND_GET_CLOUD_STORAGE_BIND_STATUS to OneDriverInfo.Response.InfoType.GET_CLOUD_STORAGE_BIND_STATUS,

        // 设置云存储绑定状态
        MessageCode.PHONE_COMMAND_SET_CLOUD_STORAGE_BIND_STATUS to OneDriverInfo.Response.InfoType.SET_CLOUD_STORAGE_BIND_STATUS,

        // 删除WiFi历史信息
        MessageCode.PHONE_COMMAND_DEL_WIFI_HISTORY_INFO to OneDriverInfo.Response.InfoType.DEL_WIFI_HISTORY_INFO,

        // 控制预录制
        MessageCode.PHONE_COMMAND_CTRL_PRE_RECORD to OneDriverInfo.Response.InfoType.CTRL_PRE_RECORD,

        // 同步时间精确
        MessageCode.PHONE_COMMAND_SYNCTIME_ACCURATE to OneDriverInfo.Response.InfoType.SYNC_TIME_ACCURATE,

        // 通知行车记录仪信息
        MessageCode.CAMERA_NOTIFICATION_DASH_CAM_INFO to OneDriverInfo.Response.InfoType.NOTIFICATION_DASH_CAM_INFO,

        // 通知虚拟PTZ移动状态
        MessageCode.CAMERA_NOTIFICATION_VIRTUAL_PTZ_MOVEMENT_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_VIRTUAL_PTZ_MOVEMENT_STATUS,

        // 通知APP动态跟拍初始视角状态
        MessageCode.CAMERA_NOTIFICATION_PTZ_PERSPECTIVE_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_PTZ_PERSPECTIVE_STATUS,

        // 取消锁定视角
        MessageCode.PHONE_COMMAND_CANCEL_ANGLE_FIXED to OneDriverInfo.Response.InfoType.CANCEL_ANGLE_FIXED,

        // 动态跟拍2.0：带画框的开始追踪
        MessageCode.PHONE_COMMAND_OPEN_TRACKING_WITH_RECT to OneDriverInfo.Response.InfoType.OPEN_TRACKING_WITH_RECT,

        // 取消追踪
        MessageCode.PHONE_COMMAND_CANCEL_TRACKING to OneDriverInfo.Response.InfoType.CANCEL_TRACKING,

        // 获取动态跟拍追踪状态
        MessageCode.PHONE_COMMAND_GET_PTZ_TRACK_STATE to OneDriverInfo.Response.InfoType.GET_PTZ_TRACK_STATE,

        // 设置网络配置启用
        MessageCode.PHONE_COMMAND_SET_NETWORK_CONFIG_ENABLE to OneDriverInfo.Response.InfoType.SET_NETWORK_CONFIG_ENABLE,

        // 设置关机
        MessageCode.PHONE_COMMAND_SET_SHUTDOWN to OneDriverInfo.Response.InfoType.SET_SHUTDOWN,

        // 获取切换WiFi频道
        MessageCode.PHONE_COMMAND_SWITCH_WIFI_CHANNEL to OneDriverInfo.Response.InfoType.GET_SWITCH_WIFI_CHANNEL,

        // 获取WiFi干扰状态
        MessageCode.PHONE_COMMAND_GET_WIFI_INTERFERENCE_STATUS to OneDriverInfo.Response.InfoType.GET_WIFI_INTERF_STATUS,

        // 通知切换WiFi频道
        MessageCode.CAMERA_NOTIFICATION_WIFI_CHANNEL_SWITCH_RES to OneDriverInfo.Response.InfoType.NOTIFICATION_SWITCH_WIFI_CHANNEL,

        // 通知获取WiFi干扰状态
        MessageCode.CAMERA_NOTIFICATION_WIFI_INTERFERENCE_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_GET_WIFI_INTERFERENCE_STATUS,

        // 相机通知观看结果
        MessageCode.CAMERA_NOTIFICATION_WATCH_RES to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_WATCH_RES,

        // 通知相机P2P传输中
        MessageCode.CAMERA_NOTIFICATION_IS_P2P_TRANSMITING to OneDriverInfo.Response.InfoType.NOTIFY_CAMERA_IS_P2P_TRANSMITING,

        // 通知相机LivePhoto切换状态
        MessageCode.CAMERA_NOTIFICATION_LIVEPHOTO_SWITCH_STATUS to OneDriverInfo.Response.InfoType.NOTIFY_CAMERA_LIVEPHOTO_SWITCH_STATUS,

        // 通知设置相机云感知弹窗间隔
        MessageCode.PHONE_COMMAND_SET_CLOUD_PROMPT_INTERVAL to OneDriverInfo.Response.InfoType.SET_CLOUD_PROMPT_INTERVAL,

        // 通知相机关闭wifi
        MessageCode.CAMERA_NOTIFICATION_CLOSE_WIFI to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_CLOSE_WIFI,

        MessageCode.CAMERA_NOTIFICATION_STREET_PHOTO_STATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_STREET_PHOTO_STATUS,
        MessageCode.PHONE_COMMAND_GIMBAL_CONTROL to OneDriverInfo.Response.InfoType.PHONE_COMMAND_GIMBAL_CONTROL,
        MessageCode.CAMERA_NOTIFICATION_GIMBAL_CALIBRATION to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_GIMBAL_CALIBRATION,
        // 云台异常状态（限位信息）通知
        MessageCode.CAMERA_NOTIFICATION_PTZ_STATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_PTZ_STATE,

        // 分离屏电量更新通知
        MessageCode.CAMERA_NOTIFICATION_DETACHABLE_SCREEN_BATTERY_UPDATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_DETACHABLE_SCREEN_BATTERY_UPDATE,
        // 分离屏状态更新通知
        MessageCode.CAMERA_NOTIFICATION_DETACHABLE_SCREEN_CONNECT_STATUS to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_DETACHABLE_SCREEN_CONNECT_STATUS,

        // 设置主存储
        MessageCode.PHONE_COMMAND_SET_MAIN_STORAGE to OneDriverInfo.Response.InfoType.SET_MAIN_STORAGE,

        // 存储位置变化通知
        MessageCode.CAMERA_NOTIFICATION_STORAGE_LOCATION_CHANGE to OneDriverInfo.Response.InfoType.NOTIFICATION_STORAGE_LOCATION_CHANGE,

        // 格式化存储（按类型区分内置/外置，与 PHONE_COMMAND_ERASE_SD_CARD 区分）
        MessageCode.PHONE_COMMAND_FORMAT_STORAGE to OneDriverInfo.Response.InfoType.FORMAT_STORAGE,
        MessageCode.PHONE_COMMAND_SINGLE_HOST_CTRL_INFO  to OneDriverInfo.Response.InfoType.SINGLE_HOST_CTRL_INFO,
        MessageCode.CAMERA_NOTIFICATION_SINGLE_HOST_INFO  to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_SINGLE_HOST_INFO,

        // 配方分享
        MessageCode.PHONE_COMMAND_RECIPE_SHARE_STATUS to OneDriverInfo.Response.InfoType.RECIPE_SHARE_STATUS,
        MessageCode.CAMERA_NOTIFICATION_RECIPE_SHARE to OneDriverInfo.Response.InfoType.RECIPE_SHARE,

        // 加密能力查询
        MessageCode.PHONE_COMMAND_ENCRYPT_CAPABILITY_QUERY to OneDriverInfo.Response.InfoType.ENCRYPT_CAPABILITY_QUERY,

        // 加密密钥交换
        MessageCode.PHONE_COMMAND_ENCRYPT_KEY_EXCHANGE to OneDriverInfo.Response.InfoType.ENCRYPT_KEY_EXCHANGE,
        MessageCode.CAMERA_NOTIFICATION_PTZ_TRACK_STATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_PTZ_TRACK_STATE,
        MessageCode.PHONE_COMMAND_GET_PTZ_TRACK_STATE to OneDriverInfo.Response.InfoType.GET_PTZ_TRACK_STATE,
        MessageCode.PHONE_COMMAND_OPEN_TRACKING_WITH_RECT to OneDriverInfo.Response.InfoType.OPEN_TRACKING_WITH_RECT,
        MessageCode.PHONE_COMMAND_CANCEL_TRACKING to OneDriverInfo.Response.InfoType.CANCEL_TRACKING,
        MessageCode.PHONE_COMMAND_SET_PRESET_COMPOSITION to OneDriverInfo.Response.InfoType.SET_PRESET_COMPOSITION,
        MessageCode.PHONE_COMMAND_GET_PRESET_COMPOSITION to OneDriverInfo.Response.InfoType.GET_PRESET_COMPOSITION,
        MessageCode.CAMERA_NOTIFICATION_PRESET_COMPOSITION to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_PRESET_COMPOSITION,

        // 通知相机进入/退出设置页（美颜/滤镜等）
        MessageCode.PHONE_COMMAND_NOTIFY_PHOTO_SETTING_PAGE to OneDriverInfo.Response.InfoType.NOTIFY_SETTING_PAGE,

        // AF场景变化通知
        MessageCode.CAMERA_NOTIFICATION_AF_SCENE_CHANGE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_AF_SCENE_CHANGE,
        // 头追(耳挂)佩戴状态通知
        MessageCode.CAMERA_NOTIFICATION_TM_TRACKER_EAR_HOOK_WEAR_STATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_TM_TRACKER_EAR_HOOK_WEAR_STATE,
        // 获取固件子版本号
        MessageCode.PHONE_COMMAND_GET_FIRMWARE_VERSIONS to OneDriverInfo.Response.InfoType.GET_FIRMWARE_VERSIONS,
        MessageCode.CAMERA_NOTIFICATION_AI_HIGHLIGHT_STATUS  to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_AI_HIGHLIGHT_STATUS,

        // APP -> 相机：绑定蓝牙 MAC 业务特征
        MessageCode.PHONE_COMMAND_FEATURE_BLUETOOTHMAC_BIND to OneDriverInfo.Response.InfoType.BIND_BLUETOOTH_MAC_FEATURE,

        // offset_state变化通知
        MessageCode.CAMERA_NOTIFICATION_OFFSET_STATE_UPDATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_OFFSET_STATE_UPDATE,
        // APP -> 相机：通用音频流开关
        MessageCode.PHONE_COMMAND_SET_AUDIO_STREAM to OneDriverInfo.Response.InfoType.SET_AUDIO_STREAM,

        // APP -> 相机：下发 AI 意图
        MessageCode.PHONE_COMMAND_AI_INTENT to OneDriverInfo.Response.InfoType.SET_AI_INTENT,

        // APP -> 相机：下发当前语音助手的 region
        MessageCode.PHONE_COMMAND_SET_USER_REGION to OneDriverInfo.Response.InfoType.SET_USER_REGION,

        // APP -> 相机：下发当前自动选择的语音助手本地语音和翻译语言
        MessageCode.PHONE_COMMAND_SET_ASSISTANT_LANGUAGE to OneDriverInfo.Response.InfoType.SET_ASSISTANT_LANGUAGE,

        // APP <-> 相机：获取互译配置
        MessageCode.PHONE_COMMAND_GET_TRANSLATE_CONFIG to OneDriverInfo.Response.InfoType.GET_TRANSLATE_CONFIG,

        // 相机 -> APP：音频活动状态（VAD）
        MessageCode.CAMERA_NOTIFICATION_AUDIO_ACTIVITY_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_AUDIO_ACTIVITY_STATUS,

        // 相机 -> APP，文件结果已就绪
        MessageCode.CAMERA_NOTIFICATION_DATA_INFO_READY to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_DATA_INFO_READY,

        // 请求数据传输（RequestData）
        MessageCode.PHONE_COMMAND_REQUEST_DATA to OneDriverInfo.Response.InfoType.PHONE_COMMAND_REQUEST_DATA,

        // 数据传输分片（DataTransPort）
        MessageCode.CAMERA_NOTIFICATION_DATA_TRANSPORT to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_DATA_TRANSPORT,

        // 数据传输反馈（DataTransportResult）
        MessageCode.PHONE_COMMAND_DATA_TRANSPORT_FEEDBACK to OneDriverInfo.Response.InfoType.PHONE_COMMAND_DATA_TRANSPORT_FEEDBACK,

        // 相机 -> APP，语音助手已退出
        MessageCode.CAMERA_NOTIFICATION_AI_QUIT_ASSISTANT to OneDriverInfo.Response.InfoType.NOTIFICATION_AI_QUIT_ASSISTANT,

        // 相机 -> APP，主动推送蓝牙状态
        MessageCode.CAMERA_NOTIFICATION_BLUETOOTH_STATUS to OneDriverInfo.Response.InfoType.NOTIFICATION_BLUETOOTH_STATUS,

        // 相机 -> APP，自动切换夜景录像模式变更（暗光切夜景 / 回退普通录像）
        MessageCode.CAMERA_NOTIFICATION_AUTO_SWITCH_NIGHT_VIDEO to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_AUTO_SWITCH_NIGHT_VIDEO,

        // 相机 -> APP，姿态重建状态变更
        MessageCode.CAMERA_NOTIFICATION_POSTURE_REBUILD_STATE to OneDriverInfo.Response.InfoType.CAMERA_NOTIFICATION_POSTURE_REBUILD_STATE,
    )
}
