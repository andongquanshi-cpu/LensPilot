package com.arashivision.onedriver.bean

/**
 * USB状态枚举
 */
enum class UsbState(val value: Int) {
    SYNCED(0),     // 已同步
    ERROR(1),      // 错误
    NOT_START(10)   // 未开始
}
