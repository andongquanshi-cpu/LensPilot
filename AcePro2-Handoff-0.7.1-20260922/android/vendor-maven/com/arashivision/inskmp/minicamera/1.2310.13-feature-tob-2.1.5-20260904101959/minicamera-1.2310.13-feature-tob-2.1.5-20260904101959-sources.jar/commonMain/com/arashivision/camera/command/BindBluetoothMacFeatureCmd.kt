package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.FeatureBluetoothMacBind

class BindBluetoothMacFeatureCmd(
    private val featureBluetoothMacBind: FeatureBluetoothMacBind,
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.bindBluetoothMacFeature(featureBluetoothMacBind)
    }
}
