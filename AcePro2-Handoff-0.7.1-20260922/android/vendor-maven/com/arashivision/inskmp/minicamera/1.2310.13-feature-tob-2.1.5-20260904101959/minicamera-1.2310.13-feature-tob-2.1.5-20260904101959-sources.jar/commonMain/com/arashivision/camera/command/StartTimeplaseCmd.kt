package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.StartTimelapse

class StartTimeplaseCmd(private val mStartTimelapse: StartTimelapse) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.startTimeplapse(mStartTimelapse)
        return 0
    }
}
