package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver

class GetSingleSensorCmd(private val mRequestOptions: RequestOptions) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getSingleSensor(mRequestOptions)
    }
}
