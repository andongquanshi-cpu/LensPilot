package com.arashivision.camera.listener

import insta360.messages.Video

interface ITimelapseListener {
    fun ononTimelapseRecordNotify(state: Int, error: Int, video: Video?)
}
