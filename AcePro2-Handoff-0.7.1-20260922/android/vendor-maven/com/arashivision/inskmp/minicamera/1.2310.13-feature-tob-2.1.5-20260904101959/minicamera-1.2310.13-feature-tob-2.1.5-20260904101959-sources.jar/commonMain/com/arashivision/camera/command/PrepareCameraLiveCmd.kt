package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class PrepareCameraLiveCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.prepareCameraLive()
    }
}
