package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.IntervalRecInfo

internal class GetIntervalRecCfgCmd(private val intervalRecInfo: IntervalRecInfo) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.getIntervalRecCfg(intervalRecInfo)
    }
}
