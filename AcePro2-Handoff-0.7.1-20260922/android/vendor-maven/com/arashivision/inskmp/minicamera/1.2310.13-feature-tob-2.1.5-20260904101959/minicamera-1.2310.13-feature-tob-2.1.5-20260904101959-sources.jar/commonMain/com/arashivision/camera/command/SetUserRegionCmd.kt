package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.UserRegionCtrl

internal class SetUserRegionCmd(private val request: UserRegionCtrl) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.setUserRegion(request)
    }
}
