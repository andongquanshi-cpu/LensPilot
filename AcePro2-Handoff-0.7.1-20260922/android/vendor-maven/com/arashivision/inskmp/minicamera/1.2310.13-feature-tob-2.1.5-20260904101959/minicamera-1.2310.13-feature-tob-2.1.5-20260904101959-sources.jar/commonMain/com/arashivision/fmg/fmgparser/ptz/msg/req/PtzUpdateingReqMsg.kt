package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzUpdateingReqMsg(
//长度为128的byte数组
    private val data: ByteArray
) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        return data
    }

    override fun toString(): String {
        return FmgByteUtils.bytes2hex(data)
    }

    override fun name(): String {
        return "CMD_UPDATING_REQ"
    }

    companion object {
        const val MAX_DATA_SIZE_PER_PACKET: Int = 128
        const val MAX_DATA_SIZE_PER_PACKET_V2: Int = 220
    }
}
