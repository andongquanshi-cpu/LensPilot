// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/PacketDemuxer.kt
package com.arashivision.onedriver.packet

import com.arashivision.common.BleLog

/**
 * 数据包解复用器 - 对应C++中的PacketDemuxer类
 * 优化：简化逻辑，减少不必要的内存分配
 */
class PacketDemuxer {
    private val buffer = BufferStream()
    private val probeHead = ByteArray(Packet.minSizeToProbePacketSize())
    private val ucpProbeHead = ByteArray(Go2BlePacket.getBlePacketHeadSize())

    /**
     * 解析单个数据包
     */
    fun parseBleUdp(data: ByteArray, size: Int, isClassicPipe: Boolean): List<Packet> {
        buffer.put(data, size)
        val packets = mutableListOf<Packet>()

        if (buffer.size() < Packet.minSizeToProbePacketSize()) {
            BleLog.d(" notifyInPacket packet= null 111")
            return packets
        }

        // 探测包大小
        val peekedSize = buffer.peek(probeHead, probeHead.size)
        if (peekedSize < probeHead.size) {
            BleLog.d(" notifyInPacket packet= null 2222")
        }

        val packetSize = Packet.probePacketSize(probeHead, probeHead.size)
        if (packetSize <= 0 || buffer.size() < packetSize) {
            BleLog.d(" notifyInPacket packet= null $packetSize  ${buffer.size()}")
            return packets
        }

        // 取出完整包数据
        val packetData = ByteArray(packetSize)
        val takenSize = buffer.take(packetData, packetSize)
        if (takenSize != packetSize) {
            BleLog.d(" notifyInPacket packet= null 4444")
            return packets
        }

        Packet.fromBytes(packetData)?.let {
            packets.add(it)
        }
        return packets
    }

    /**
     * 解析BLE数据包
     * 对应C++版本的parseBle逻辑
     */
    fun parseBleUcpV1(data: ByteArray, size: Int): Packet? {
        buffer.put(data, size)

        if (buffer.size() < Go2BlePacket.getBlePacketHeadSize()) {
            BleLog.d(" parseBle packet < BlePacketHeadSize")
            return null
        }

        // 探测包大小
        val peekedSize = buffer.peek(ucpProbeHead, ucpProbeHead.size)
        if (peekedSize < ucpProbeHead.size) {
            BleLog.d(" parseBle packet peekedSize $peekedSize < BlePacketHeadSize")
        }

        val packetSize = Go2BlePacket.probePacketSize(ucpProbeHead, ucpProbeHead.size)
        val totalSize = Go2BlePacket.getBlePacketHeadSize() + packetSize + 2
        if (packetSize <= 0 || buffer.size() != totalSize) {
            BleLog.d(" parseBle not match totalSize $totalSize  ${buffer.size()}")
            return null
        }

        // 取出完整包数据
        val totalData = ByteArray(totalSize)
        val takenSize = buffer.take(totalData, totalSize)
        if (takenSize != totalSize) {
            BleLog.d(" parseBle packet size is not match")
            return null
        }
        val packetBuf = totalData.copyOfRange(
            Go2BlePacket.getBlePacketHeadSize(), // 起点（跳过头部）
            totalData.size - 2 // 终点（去除末尾 2 字节）
        )
        return Packet.fromBytes(packetBuf)
    }

    fun parseBleUcp(data: ByteArray, size: Int, isClassicPipe: Boolean): List<Packet> {
        val packets = mutableListOf<Packet>()
        if (data.isEmpty()) {
            return packets
        }

        // 1. 校验 data 是否是完整包
        if ((data.size >= Go2BlePacket.getBlePacketHeadSize() + 2) &&
            data[0] == 0xFF.toByte()) {
            val payloadSize = Go2BlePacket.probePacketSize(data, data.size)
            val totalSize = Go2BlePacket.getBlePacketHeadSize() + payloadSize + 2
            if (totalSize == data.size) {
                val packetBuf = data.copyOfRange(
                    Go2BlePacket.getBlePacketHeadSize(), // 起点（跳过头部）
                    data.size - 2 // 终点（去除末尾 2 字节）
                )
                Packet.fromBytes(packetBuf)?.let {
                    it.rawFrame = data // 完整原始帧(含帧头),供 BLE+SPP 共存转发
                    packets.add(it)
                }
                return packets
            }
        }

        // 2. 当新包不是以 0xff 开头，且缓存池为空，则丢弃
        if (data[0] != 0xFF.toByte() && buffer.size() == 0) {
            return packets
        }

        // 3. 当新包不是以 0xff 开头，且缓存不为空，需要判断是否合并。
        buffer.put(data, size)
        if (buffer.size() < Go2BlePacket.getBlePacketHeadSize()) {
            BleLog.w(" parseBle packet < BlePacketHeadSize")
            buffer.clear()
            return packets
        }

        // 探测包大小
        val peekedSize = buffer.peek(ucpProbeHead, ucpProbeHead.size)
        if (peekedSize < ucpProbeHead.size) {
            BleLog.d(" parseBle packet peekedSize $peekedSize < BlePacketHeadSize")
        }
        // ucp 协议都是以 0xff 开头的，https://arashivision.feishu.cn/wiki/wikcnWfc90XEZxDVabIgqDOq62b
        if (ucpProbeHead[0] != 0xff.toByte()) {
            BleLog.w("parseBle, ${ucpProbeHead[0]} is start with 0xff")
            buffer.clear()
            return packets
        }

        val payloadSize = Go2BlePacket.probePacketSize(ucpProbeHead, ucpProbeHead.size)
        if (payloadSize <= 0) {
            BleLog.w("parseBle, payloadSize(=$payloadSize) is error,  buffer=${buffer.size()}")
            buffer.clear()
            return packets
        }

        // 判断 buffer 的总大小：若超过则直接清空缓存并丢弃；若小于等下一包；若等于返回新 packet
        val totalSize = Go2BlePacket.getBlePacketHeadSize() + payloadSize + 2
        if (buffer.size() < totalSize) {
            BleLog.d("parseBle, the bufferSize(=${buffer.size()}) is less than totalSize(=$totalSize)")
            return packets
        } else if (buffer.size() > totalSize) {
            BleLog.w("parseBle, the bufferSize(=${buffer.size()}) exceeds totalSize(=$totalSize)")
            if (isClassicPipe) {
                val totalData = ByteArray(totalSize)
                val takenSize = buffer.take(totalData, totalSize)
                if (takenSize != totalSize) {
                    BleLog.w("parseBle packet size is not match (classic pipe)")
                    buffer.clear()
                    return packets
                }
                val packetBuf = totalData.copyOfRange(
                    Go2BlePacket.getBlePacketHeadSize(),
                    totalData.size - 2
                )
                Packet.fromBytes(packetBuf)?.let {
                    it.rawFrame = totalData // 完整原始帧(含帧头),供 BLE+SPP 共存转发
                    packets.add(it)
                }
                if (buffer.size() > 0) {
                    val remainingSize = buffer.size()
                    val remaining = ByteArray(remainingSize)
                    buffer.take(remaining, remainingSize)
                    buffer.clear()
                    packets.addAll(parseBleUcp(remaining, remainingSize, isClassicPipe))
                }
                return packets
            } else {
                buffer.clear()
                return packets
            }
        }

        // 取出完整包数据
        val totalData = ByteArray(totalSize)
        val takenSize = buffer.take(totalData, totalSize)
        if (takenSize != totalSize) {
            BleLog.w("parseBle packet size is not match")
            return packets
        }
        val packetBuf = totalData.copyOfRange(
            Go2BlePacket.getBlePacketHeadSize(), // 起点（跳过头部）
            totalData.size - 2 // 终点（去除末尾 2 字节）
        )
        Packet.fromBytes(packetBuf)?.let {
            it.rawFrame = totalData // 完整原始帧(含帧头),供 BLE+SPP 共存转发
            packets.add(it)
        }
        return packets
    }

    /**
     * 解析多个数据包
     */
    fun parseList(data: ByteArray, size: Int): List<Packet> {
        buffer.put(data, size)
        val packets = mutableListOf<Packet>()

        while (buffer.size() >= Packet.minSizeToProbePacketSize()) {
            val peekedSize = buffer.peek(probeHead, probeHead.size)
            if (peekedSize < probeHead.size) break

            val packetSize = Packet.probePacketSize(probeHead, probeHead.size)
            if (packetSize <= 0 || buffer.size() < packetSize) break

            val packetData = ByteArray(packetSize)
            val takenSize = buffer.take(packetData, packetSize)
            if (takenSize != packetSize) break

            val packet = Packet.fromBytes(packetData)
            if (packet != null) {
                packets.add(packet)
            }
        }

        return packets
    }

    /**
     * 检查缓冲区是否有数据
     */
    fun bufferHasData(): Boolean = buffer.hasData()
}