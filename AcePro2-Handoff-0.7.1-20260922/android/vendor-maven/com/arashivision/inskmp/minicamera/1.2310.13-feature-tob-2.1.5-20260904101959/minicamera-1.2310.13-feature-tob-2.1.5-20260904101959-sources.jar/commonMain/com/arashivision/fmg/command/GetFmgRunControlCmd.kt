package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.onecamera.OneDriver

class GetFmgRunControlCmd(private val state: PtzGrfState) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzGetRunControl(state)
    }
}
