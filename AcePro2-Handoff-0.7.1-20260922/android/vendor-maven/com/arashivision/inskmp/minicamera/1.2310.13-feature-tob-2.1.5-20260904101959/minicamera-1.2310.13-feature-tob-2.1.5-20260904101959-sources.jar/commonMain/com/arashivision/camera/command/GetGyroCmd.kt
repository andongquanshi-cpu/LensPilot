package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetGyro

/**
 * 同步获取陀螺仪数据
 */
class GetGyroCmd(private val mGetGyro: GetGyro) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getGyro(mGetGyro)
    }
}
