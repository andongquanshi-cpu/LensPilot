package com.arashivision.camera.strategy

import com.arashivision.camera.RequestOptions
import com.arashivision.camera.command.AAAFactoryMode
import com.arashivision.camera.command.AAANormalMode
import com.arashivision.camera.command.AgeTestStatusCmd
import com.arashivision.camera.command.AyncSetTimelapseOptionCmd
import com.arashivision.camera.command.BadPointTestCmd
import com.arashivision.camera.command.BindBluetoothMacFeatureCmd
import com.arashivision.camera.command.BlackLevelTestCmd
import com.arashivision.camera.command.ButtonTestCmd
import com.arashivision.camera.command.CalibrateGyroCmd
import com.arashivision.camera.command.CameraWifiHearCmd
import com.arashivision.camera.command.CancelAuthorizationCmd
import com.arashivision.camera.command.CancelAngleFixedCmd
import com.arashivision.camera.command.CancelIntervalRecCmd
import com.arashivision.camera.command.CancelRequestAuthorizationCmd
import com.arashivision.camera.command.CancelTrackingCmd
import com.arashivision.camera.command.CaptureCommand
import com.arashivision.camera.command.ChargingBoxCmd
import com.arashivision.camera.command.CheckAuthorizationCmd
import com.arashivision.camera.command.CheckVideoCmd
import com.arashivision.camera.command.CheckVideoWHCmd
import com.arashivision.camera.command.CloseCameraWifiCmd
import com.arashivision.camera.command.DataTransportFeedbackCmd
import com.arashivision.camera.command.DeleteFileListCmd
import com.arashivision.camera.command.DeleteWifiHistoryInfoCmd
import com.arashivision.camera.command.DspLinkCmd
import com.arashivision.camera.command.EraseSdcardCmd
import com.arashivision.camera.command.FormatStorageCmd
import com.arashivision.camera.command.GetButtonPressParamsCmd
import com.arashivision.camera.command.GetCameraLiveOptionsAsyncCmd
import com.arashivision.camera.command.GetCaptureStatus
import com.arashivision.camera.command.GetCloudStorageBindStatusCmd
import com.arashivision.camera.command.GetCloudStorageUploadStatusCmd
import com.arashivision.camera.command.GetDarkEisStatusCmd
import com.arashivision.camera.command.GetDownloadFileListCmd
import com.arashivision.camera.command.GetEditInfoListCmd
import com.arashivision.camera.command.GetFileCmd
import com.arashivision.camera.command.GetFileExtraCmd
import com.arashivision.camera.command.GetFileFinishCmd
import com.arashivision.camera.command.GetFileInfoListCmd
import com.arashivision.camera.command.GetFileListCmd
import com.arashivision.camera.command.GetFileListIncludeRecordingCmd
import com.arashivision.camera.command.GetFirmwareVersionInfoCmd
import com.arashivision.camera.command.GetFlowStateCmd
import com.arashivision.camera.command.GetGyroCmd
import com.arashivision.camera.command.GetIntervalRecCfgCmd
import com.arashivision.camera.command.GetIntervalRecFeedbackCfgCmd
import com.arashivision.camera.command.GetIntervalRecSceneCfgCmd
import com.arashivision.camera.command.GetIntervalRecStatusCmd
import com.arashivision.camera.command.GetMultiVideoCmd
import com.arashivision.camera.command.GetOptionCmd
import com.arashivision.camera.command.GetOptionSyncCmd
import com.arashivision.camera.command.GetPhotoOptionCmd
import com.arashivision.camera.command.GetPhotoOptionsAsyncCmd
import com.arashivision.camera.command.GetPresetCompositionCmd
import com.arashivision.camera.command.GetPtzTrackStateCmd
import com.arashivision.camera.command.GetQuickReaderStatusCmd
import com.arashivision.camera.command.GetSFRResultCmd
import com.arashivision.camera.command.GetSFRStatusCmd
import com.arashivision.camera.command.GetSingleSensorCmd
import com.arashivision.camera.command.GetSyncCaptureModeCmd
import com.arashivision.camera.command.GetTimelapseOptionAsyncCmd
import com.arashivision.camera.command.GetTimelapseOptionCmd
import com.arashivision.camera.command.GetTranslateConfigCmd
import com.arashivision.camera.command.GetWhiteBlanceStatusCmd
import com.arashivision.camera.command.GetWifiConnectListCmd
import com.arashivision.camera.command.GetWifiConnectionInfoCmd
import com.arashivision.camera.command.GetWifiInterfStatusCmd
import com.arashivision.camera.command.GetWifiModeCmd
import com.arashivision.camera.command.GetWifiScanListCmd
import com.arashivision.camera.command.GyroScopeCmd
import com.arashivision.camera.command.HdrCaptureCommand
import com.arashivision.camera.command.HdrStopCaptureCmd
import com.arashivision.camera.command.KeyTimePointCmd
import com.arashivision.camera.command.LedTestCmd
import com.arashivision.camera.command.MultiVideoModeCmd
import com.arashivision.camera.command.NotifyOTAErrorCmd
import com.arashivision.camera.command.ObtainRtosStatusCmd
import com.arashivision.camera.command.OpenCameraWifiCmd
import com.arashivision.camera.command.OpenTrackingWithRectCmd
import com.arashivision.camera.command.OpenUsbCmd
import com.arashivision.camera.command.OpenWifiCmd
import com.arashivision.camera.command.PackFileCmd
import com.arashivision.camera.command.PauseRecordCmd
import com.arashivision.camera.command.PrepareCameraLiveCmd
import com.arashivision.camera.command.PreviewStreamingCmd
import com.arashivision.camera.command.RebootCmd
import com.arashivision.camera.command.RecipeShareStatusCmd
import com.arashivision.camera.command.RequestAuthorizationCmd
import com.arashivision.camera.command.RequestDataCmd
import com.arashivision.camera.command.RequestP3StaticStreamDataCmd
import com.arashivision.camera.command.RequestStreamIframeCmd
import com.arashivision.camera.command.ResetCameraWifiCmd
import com.arashivision.camera.command.RestoreFactorySettingsCmd
import com.arashivision.camera.command.ScriptJsonUploadCmd
import com.arashivision.camera.command.ScriptRefershCmd
import com.arashivision.camera.command.ScriptRunCmd
import com.arashivision.camera.command.ScriptcmdUploadCmd
import com.arashivision.camera.command.SendAiVoiceReadyCmd
import com.arashivision.camera.command.SendOpenCameraClassicBluetoothCmd
import com.arashivision.camera.command.SendStreamDataCmd
import com.arashivision.camera.command.SetAccessCameraFileStateCmd
import com.arashivision.camera.command.SetAiIntentCmd
import com.arashivision.camera.command.SetAssistantLanguageCmd
import com.arashivision.camera.command.SetAppIdCmd
import com.arashivision.camera.command.SetAudioStreamCmd
import com.arashivision.camera.command.SetAvailableWifiCmd
import com.arashivision.camera.command.SetButtonPressParamsCmd
import com.arashivision.camera.command.SetCameraLiveOptionsAsyncCmd
import com.arashivision.camera.command.SetCameraWifiSeizeEnableCmd
import com.arashivision.camera.command.SetCloudPromptIntervalCmd
import com.arashivision.camera.command.SetCloudStorageBindStatusCmd
import com.arashivision.camera.command.SetCloudStorageUploadStatusCmd
import com.arashivision.camera.command.SetFavoriteListCmd
import com.arashivision.camera.command.SetFileExtraCmd
import com.arashivision.camera.command.SetFlowStateCmd
import com.arashivision.camera.command.SetGimbalControlCmd
import com.arashivision.camera.command.SetGpsCmd
import com.arashivision.camera.command.SetIntervalRecCfgCmd
import com.arashivision.camera.command.SetIntervalRecFeedbackCfgCmd
import com.arashivision.camera.command.SetMainStorageCmd
import com.arashivision.camera.command.SetNetworkConfigEnableCmd
import com.arashivision.camera.command.SetOptionAsyncCmd
import com.arashivision.camera.command.SetPhoneInfoCmd
import com.arashivision.camera.command.SetPhotoOptionsCmd
import com.arashivision.camera.command.SetPhotoOptionsSyncCmd
import com.arashivision.camera.command.SetPreRecordCmd
import com.arashivision.camera.command.SetPresetCompositionCmd
import com.arashivision.camera.command.NotifySettingPageCmd
import com.arashivision.camera.command.SetShowCloudTabCmd
import com.arashivision.camera.command.SetShutdownCmd
import com.arashivision.camera.command.SetTimelapseOptionCmd
import com.arashivision.camera.command.SetTransferStatusCmd
import com.arashivision.camera.command.SetUserRegionCmd
import com.arashivision.camera.command.SetWifiConnectionInfoCmd
import com.arashivision.camera.command.SetWifiModeCmd
import com.arashivision.camera.command.SetWifiStateCmd
import com.arashivision.camera.command.SingleHostInfoCmd
import com.arashivision.camera.command.SingleSensorCmd
import com.arashivision.camera.command.SpeakerTestCmd
import com.arashivision.camera.command.StandByCmd
import com.arashivision.camera.command.StartBulletTimeCmd
import com.arashivision.camera.command.StartCameraLiveCmd
import com.arashivision.camera.command.StartRecordCmd
import com.arashivision.camera.command.StartStopIntervalRecCmd
import com.arashivision.camera.command.StartTimeplaseCmd
import com.arashivision.camera.command.StartTimeshiftCmd
import com.arashivision.camera.command.StopBulletTimeCmd
import com.arashivision.camera.command.StopCameraLiveCmd
import com.arashivision.camera.command.StopLCDCmd
import com.arashivision.camera.command.StopRecordCmd
import com.arashivision.camera.command.StopStreamingCmd
import com.arashivision.camera.command.StopTakePictureCommand
import com.arashivision.camera.command.StopTimeShift
import com.arashivision.camera.command.StopTimelapseCmd
import com.arashivision.camera.command.StopUsbcardBackupCmd
import com.arashivision.camera.command.SwitchWifiChannelCmd
import com.arashivision.camera.command.SyncAccurateTimeCmd
import com.arashivision.camera.command.SyncCaptureStatusCmd
import com.arashivision.camera.command.SyncSetCatpureModeCmd
import com.arashivision.camera.command.SyncSetStandByCmd
import com.arashivision.camera.command.TestTypeCCmd
import com.arashivision.camera.command.UpdateDownloadInfoCmd
import com.arashivision.camera.command.VibrateStopTestCmd
import com.arashivision.camera.command.VibrateTextCmd
import com.arashivision.camera.command.WhiteBlanceTestCmd
import com.arashivision.camera.command.WriteWifiProxyDataCmd
import com.arashivision.camera.command.ble.BleCloseCmd
import com.arashivision.camera.command.ble.BleConnectCmd
import com.arashivision.camera.command.ble.BleScanCmd
import com.arashivision.camera.command.ble.BleSendDisconnectDataCmd
import com.arashivision.camera.command.ble.BleStatusCmd
import com.arashivision.camera.command.ble.BleStopCmd
import com.arashivision.camera.command.ble.BleStopScanCmd
import com.arashivision.camera.command.ble.BleStopWakeupCmd
import com.arashivision.camera.command.ble.BleWakeUpCmd
import com.arashivision.camera.command.ble.ClassicConnectCmd
import com.arashivision.camera.command.ble.ConnectBTCmd
import com.arashivision.camera.command.ble.DisConnectBTCmd
import com.arashivision.camera.command.ble.FMGConnectCmd
import com.arashivision.camera.command.ble.GetConnectBTCmd
import com.arashivision.camera.command.ble.Go2BleWakeupCmd
import com.arashivision.camera.command.ble.ScanBTCmd
import com.arashivision.camera.command.classic.ClassicConnectData
import com.arashivision.camera.command.notifyGetDownloadFileListResultCmd
import com.arashivision.camera.command.usb.CloseUsbCmd
import com.arashivision.camera.command.usb.ColorTestCmd
import com.arashivision.camera.command.usb.ContactTestCmd
import com.arashivision.camera.command.usb.UsbSpeedCmd
import com.arashivision.camera.command.wifi.CloeIperfCmd
import com.arashivision.camera.command.wifi.GetIperfAverageCmd
import com.arashivision.camera.command.wifi.OpenIperfCmd
import com.arashivision.camera.command.wifi.WifiStatusCmd
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IBleScanListener
import com.arashivision.camera.listener.IWifiProxyDataListener
import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.fmg.command.BackCenterCmd
import com.arashivision.fmg.command.BasketballA2GCmd
import com.arashivision.fmg.command.CancelFmgAITrackUpgradeCmd
import com.arashivision.fmg.command.CancelFmgUpgradeCmd
import com.arashivision.fmg.command.ClearBleFmgAnalyticsDataCmd
import com.arashivision.fmg.command.ClearFmgAnalyticsDataCmd
import com.arashivision.fmg.command.DisableFmgHandDragCmd
import com.arashivision.fmg.command.EnableFmgHandDragCmd
import com.arashivision.fmg.command.FmgVibrationCmd
import com.arashivision.fmg.command.GetAiTrackerDeviceInfoCmd
import com.arashivision.fmg.command.GetFmgActiveTimeCmd
import com.arashivision.fmg.command.GetFmgAiTrackerAllSettingsCmd
import com.arashivision.fmg.command.GetFmgAllSettingsCmd
import com.arashivision.fmg.command.GetFmgAnalyticsDataCmd
import com.arashivision.fmg.command.GetFmgBleAnalyticsDataCmd
import com.arashivision.fmg.command.GetFmgButtonEnableCmd
import com.arashivision.fmg.command.GetFmgDeviceInfoCmd
import com.arashivision.fmg.command.GetFmgMidCalCmd
import com.arashivision.fmg.command.GetFmgRunControlCmd
import com.arashivision.fmg.command.GetFmgTrackSensitivityCmd
import com.arashivision.fmg.command.GetFmgUUIDCmd
import com.arashivision.fmg.command.GetFmgVerticalTrimDegreeCmd
import com.arashivision.fmg.command.InitFmgRecModeCmd
import com.arashivision.fmg.command.ResetFmgDefaultSettingsCmd
import com.arashivision.fmg.command.SetAiTrackerAutoStandbyTimeCmd
import com.arashivision.fmg.command.SetAiTrackerOnePlamShootCmd
import com.arashivision.fmg.command.SetAiTrackerStandbyModeCmd
import com.arashivision.fmg.command.SetDwSrcEventStateCmd
import com.arashivision.fmg.command.SetFmgActionCmd
import com.arashivision.fmg.command.SetFmgActiveTimeCmd
import com.arashivision.fmg.command.SetFmgAngleSeqCmd
import com.arashivision.fmg.command.SetFmgAppStatusCmd
import com.arashivision.fmg.command.SetFmgButtonDisableCmd
import com.arashivision.fmg.command.SetFmgButtonEnableCmd
import com.arashivision.fmg.command.SetFmgCameraFacingCmd
import com.arashivision.fmg.command.SetFmgMidCalCmd
import com.arashivision.fmg.command.SetFmgPanoCmd
import com.arashivision.fmg.command.SetFmgPanoIndexCmd
import com.arashivision.fmg.command.SetFmgRoll360ActionCmd
import com.arashivision.fmg.command.SetFmgRunControlCmd
import com.arashivision.fmg.command.SetFmgSettingsCmd
import com.arashivision.fmg.command.SetFmgTargetFollowCmd
import com.arashivision.fmg.command.SetFmgTimeElapseCmd
import com.arashivision.fmg.command.SetFmgTrackSensitivityCmd
import com.arashivision.fmg.command.SetFmgVerticalTrimDegreeCmd
import com.arashivision.fmg.command.SetFmgVirtualRcCmd
import com.arashivision.fmg.command.SetFmgZoomScaleCmd
import com.arashivision.fmg.command.StartFmgAITrackUpgradeCmd
import com.arashivision.fmg.command.StartFmgCalibrateCmd
import com.arashivision.fmg.command.StartFmgHeartBeatCmd
import com.arashivision.fmg.command.StartFmgRecModeCmd
import com.arashivision.fmg.command.StartFmgUpgradeCmd
import com.arashivision.fmg.command.StopFmgHeartBeatCmd
import com.arashivision.fmg.command.StopFmgRecModeCmd
import com.arashivision.fmg.command.UpdateFmgAppImuAngleCmd
import com.arashivision.fmg.command.UpdateFmgAppImuInfoCmd
import com.arashivision.fmg.command.UpdateHbRecModeCmd
import com.arashivision.fmg.command.ptzBasketballInitNoBaskCmd
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.fmg.response.model.FmgSettingsParams
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.arashivision.onedriver.packet.StreamType
import insta360.messages.AiIntentCtrl
import insta360.messages.AssistantLanguageCtrl
import insta360.messages.AudioStreamCtrl
import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType
import insta360.messages.CalibrateGyro
import insta360.messages.CancelAngleFixed
import insta360.messages.CardLocation
import insta360.messages.CheckAuthorization
import insta360.messages.CloudStorageBindParams
import insta360.messages.CloudStorageUploadParams
import insta360.messages.ConnectToBTPeripheral
import insta360.messages.CtrlPreRecord
import insta360.messages.DataTransPortDir
import insta360.messages.DataTransportResult
import insta360.messages.DeleteFiles
import insta360.messages.DisconnectBTPeripheral
import insta360.messages.DownLoadInfo
import insta360.messages.DownloadListResultSync
import insta360.messages.FeatureBluetoothMacBind
import insta360.messages.FormatStorage
import insta360.messages.GetConnectedBTPeripheral
import insta360.messages.GetFile
import insta360.messages.GetFileExtra
import insta360.messages.GetFileFinish
import insta360.messages.GetFileList
import insta360.messages.GetGyro
import insta360.messages.GetGyroResp
import insta360.messages.GetTimelapseOptions
import insta360.messages.GimbalControl
import insta360.messages.IntervalRecCancel
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecStartStop
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveOptionCtrlInfo
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.OpenTrackingWithRect
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.RecipeShareStatus
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation
import insta360.messages.ScanBTPeripheral
import insta360.messages.SetFavoriteList
import insta360.messages.SetFileExtra
import insta360.messages.SetKeyTimePoint
import insta360.messages.SetNetworkConfigEnable
import insta360.messages.SetPresetComposition
import insta360.messages.PhotoSettingPage
import insta360.messages.SetTimelapseOptions
import insta360.messages.SingleHostCmdInfo
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.TakePicture
import insta360.messages.TestSDCardSpeed
import insta360.messages.TimelapseOptions
import insta360.messages.UserRegionCtrl
import insta360.messages.WifiConnectionInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class ConnectStrategyImpl() : InstaCameraStrategy() {

    init {

    }

    override fun syncCaptureStatus(): Long {
        return addWorker(SyncCaptureStatusCmd()) as Long
    }

    override fun previewStream(startStreamingParam: StartLiveStream, offset: String) {
        addWorker(
            PreviewStreamingCmd(
                startStreamingParam,
            )
        )
    }

    override fun closePreviewStream() {
        addWorker(StopStreamingCmd())
    }

    override fun requestStreamIframe() {
        addWorker(RequestStreamIframeCmd())
    }

    override fun stopUsbcardBackup(): Long {
        return addWorker(StopUsbcardBackupCmd()) as Long
    }

    override fun getQuickReaderStatus(): Long =
        addWorker(GetQuickReaderStatusCmd()) as Long

    override fun takePicture(takePicture: TakePicture, withoutStorage: Boolean) {
        addWorker(CaptureCommand(takePicture, withoutStorage))
    }

    override fun stopTakePicture(): Long {
        return addWorker(StopTakePictureCommand()) as Long
    }

    override fun startLedTest() {
        addWorker(LedTestCmd())
    }

    override fun startBleStatusTest() {
        addWorker(BleStatusCmd())
    }


    override fun startRecord(
        recordOriginVideo: Boolean,
        livePush: Boolean,
        mode: Int,
    ) {
        addWorker(
            StartRecordCmd(
                recordOriginVideo, livePush, mode
            )
        )
    }

    override fun stopRecord(mode: Int, extraData: ByteArray) {
        addWorker(StopRecordCmd(mode, extraData))
    }

    override fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long {
        return addWorker(SetPreRecordCmd(ctrlPreRecord)) as Long
    }

    override fun setOptionAsync(
        optionList: List<OptionType>,
        options: Options,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(SetOptionAsyncCmd(optionList, options, requestOptions)) as Long
    }

    override fun getPort(): Int {
        val tunelPort = mOneDrvier.tunelPort
        if (tunelPort <= 0) {
            return 8080
        }
        return tunelPort
    }

    override fun calibrateGyro(gyro: CalibrateGyro): Long {
        return addWorker(CalibrateGyroCmd(gyro)) as Long
    }


    override fun startTimeplapse(startTimelapse: StartTimelapse) {
        addWorker(StartTimeplaseCmd(startTimelapse))
    }


    override fun eraseSdcard(): Long {
        return addWorker(EraseSdcardCmd()) as Long
    }

    override fun formatStorage(formatStorage: FormatStorage): Long {
        return addWorker(FormatStorageCmd(formatStorage)) as Long
    }

    override fun setMainStorage(cardLocation: CardLocation): Long {
        return addWorker(SetMainStorageCmd(cardLocation)) as Long
    }

    override fun reboot(): Long {
        return addWorker(RebootCmd()) as Long
    }

    override fun notifyOTAError(): Long {
        return addWorker(NotifyOTAErrorCmd()) as Long
    }

    override fun setAppId(appId: String): Long {
        return addWorker(SetAppIdCmd(appId)) as Long
    }

    override fun setShutdown(): Long {
        return addWorker(SetShutdownCmd()) as Long
    }

    override fun cancelAngleFixed(cancelAngleFixed: CancelAngleFixed): Long {
        return addWorker(CancelAngleFixedCmd(cancelAngleFixed)) as Long
    }
    override fun checkAuthorization(
        checkAuthorization: CheckAuthorization,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(CheckAuthorizationCmd(checkAuthorization, requestOptions)) as Long
    }

    override fun requestAuthorization(authorizationOperationType: Int): Long {
        return addWorker(RequestAuthorizationCmd(authorizationOperationType)) as Long
    }

    override fun writeWifiProxyData(wifiProxyData: IWifiProxyData) {
        addWorker(WriteWifiProxyDataCmd(wifiProxyData))
    }

    override fun getOptions(optionList: List<OptionType>): Options? {
        val `object` = addWorker(GetOptionCmd(optionList))
        if (`object` is Options) {
            return `object`
        }
        return null
    }

    override fun getOptionsSync(
        optionList: List<OptionType>?,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(GetOptionSyncCmd(optionList, requestOptions)) as Long
    }

    override fun negotiateEncryption(onComplete: (Boolean) -> Unit) {
        mOneDrvier.negotiateEncryption(onComplete)
    }

    override fun getPhotoOptionsAsync(
        funcMode: Int,
        options: List<PhotographyOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(GetPhotoOptionsAsyncCmd(funcMode, options, requestOptions)) as Long
    }

    override fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        opetions: List<ButtonPressParamsType>,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(
            GetButtonPressParamsCmd(
                buttonPressMode,
                buttonPressType,
                opetions,
                requestOptions
            )
        ) as Long
    }

    override fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        buttonPressParams: ButtonPressParams,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(
            SetButtonPressParamsCmd(
                buttonPressMode,
                buttonPressType,
                optionType,
                buttonPressParams,
                requestOptions
            )
        ) as Long
    }

    override fun getTimelapseOption(getTimelapseOptions: GetTimelapseOptions): TimelapseOptions? {
        return addWorker(GetTimelapseOptionCmd(getTimelapseOptions)) as TimelapseOptions
    }

    override fun getTimelapseOptionAsync(
        getTimelapseOptions: GetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(GetTimelapseOptionAsyncCmd(getTimelapseOptions, requestOptions)) as Long
    }

    override fun getCameraLiveOptionsSync(
        optionList: List<LiveBroadCastOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(GetCameraLiveOptionsAsyncCmd(optionList, requestOptions)) as Long
    }

    override fun setCameraLiveOptionsAsync(
        optionList: List<LiveBroadCastOptionType>,
        options: LiveOptionCtrlInfo,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(SetCameraLiveOptionsAsyncCmd(optionList, options, requestOptions)) as Long
    }

    override fun getFileInfoList(cardLocation: CardLocation): Long = addWorker(GetFileInfoListCmd(cardLocation)) as Long

    override fun getEditInfoList(): Long = addWorker(GetEditInfoListCmd()) as Long

    override fun getTranslateConfig(timeoutMs: Int): Long = addWorker(GetTranslateConfigCmd(timeoutMs)) as Long

    override fun getFileList(fileList: GetFileList): Long {
        return addWorker(GetFileListCmd(fileList)) as Long
    }

    override fun getFileListIncludeRecording(fileList: GetFileList): Long {
        return addWorker(GetFileListIncludeRecordingCmd(fileList)) as Long
    }

    override fun getFile(getFile: GetFile): Long {
        return addWorker(GetFileCmd(getFile)) as Long
    }

    override fun setFavoriteList(setFavoriteList: SetFavoriteList): Long {
        return addWorker(SetFavoriteListCmd(setFavoriteList)) as Long
    }

    override fun packFile(getFile: GetFile): Long {
        return addWorker(PackFileCmd(getFile)) as Long
    }

    override fun getFileFinish(getFileFinish: GetFileFinish): Long {
        return addWorker(GetFileFinishCmd(getFileFinish)) as Long
    }

    override fun setTransferStatus(getFileFinish: GetFileFinish): Long {
        return addWorker(SetTransferStatusCmd(getFileFinish)) as Long
    }

    override fun startWifiStatusTest() {
        addWorker(WifiStatusCmd())
    }

    override fun startSpeakerTest() {
        addWorker(SpeakerTestCmd())
    }

    override fun delteFileList(obj: DeleteFiles): Long {
        return addWorker(DeleteFileListCmd(obj)) as Long
    }

    override fun getGyro(getGyro: GetGyro): GetGyroResp? {
        val `object` = addWorker(GetGyroCmd(getGyro))
        if (`object` is GetGyroResp) {
            return `object`
        }

        return null
    }

    override fun getGyroSync(getGyro: GetGyro): Long {
        return addWorker(GetGyroCmd(getGyro)) as Long
    }

    override fun setFileExtra(setFileExtra: SetFileExtra): Long {
        return addWorker(SetFileExtraCmd(setFileExtra)) as Long
    }

    override fun getFileExtra(getFileExtra: GetFileExtra): Long {
        return addWorker(GetFileExtraCmd(getFileExtra)) as Long
    }

    override fun recipeShareStatus(recipeShareStatus: RecipeShareStatus): Long {
        return addWorker(RecipeShareStatusCmd(recipeShareStatus)) as Long
    }

    override fun testButtonState() {
        addWorker(ButtonTestCmd())
    }

    override fun startTestTypeC() {
        addWorker(TestTypeCCmd())
    }

    override fun stopLCDTest() {
        addWorker(StopLCDCmd())
    }

    override fun getCaptureStatus(requestOptions: RequestOptions): Long {
        return addWorker(GetCaptureStatus(requestOptions)) as Long
    }

    override fun setSyncCaptureMode(mode: Int): Long {
        return addWorker(SyncSetCatpureModeCmd(mode)) as Long
    }

    override fun getSyncCaptureMode(): Long = addWorker(GetSyncCaptureModeCmd()) as Long

    override fun pauseRecord(): Long {
        return addWorker(PauseRecordCmd()) as Long
    }

    override fun setStandbyMode(mode: Int): Long {
        return addWorker(SyncSetStandByCmd(mode)) as Long
    }

    override fun getPhotoOptions(
        funcMode: Int,
        options: List<PhotographyOptionType>,
    ): PhotographyOptions? {
        return addWorker(GetPhotoOptionCmd(funcMode, options)) as PhotographyOptions
    }

    override fun setTimelapseOptions(info: SetTimelapseOptions): Long {
        return addWorker(SetTimelapseOptionCmd(info)) as Long
    }

    override fun setTimelapseOptionsASync(
        info: SetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(AyncSetTimelapseOptionCmd(info, requestOptions)) as Long
    }

    override fun startBulletTime(): Long {
        return addWorker(StartBulletTimeCmd()) as Long
    }

    override fun cancelAuthorization(requestOptions: RequestOptions): Long {
        return addWorker(CancelAuthorizationCmd(requestOptions)) as Long
    }

    override fun cancelRequestAuthorization(authorizationOperationType: Int): Long {
        return addWorker(CancelRequestAuthorizationCmd(authorizationOperationType)) as Long
    }

    override fun stopTimelapse(stopTimelapse: StopTimelapse) {
        addWorker(StopTimelapseCmd(stopTimelapse))
    }

    override fun stopBulletTime(extraData: ByteArray) {
        addWorker(StopBulletTimeCmd(extraData))
    }

    override fun setPhotoOptions(
        funcMode: Int,
        optionList: List<PhotographyOptionType>,
        options: PhotographyOptions,
    ): Long {
        return addWorker(SetPhotoOptionsCmd(funcMode, optionList, options)) as Long
    }

    override fun scanBT(obj: ScanBTPeripheral): Long {
        return addWorker(ScanBTCmd(obj)) as Long
    }

    override fun connectBT(obj: ConnectToBTPeripheral): Long {
        return addWorker(ConnectBTCmd(obj)) as Long
    }

    override fun disConnectBT(obj: DisconnectBTPeripheral): Long {
        return addWorker(DisConnectBTCmd(obj)) as Long
    }

    override fun getConnectBT(obj: GetConnectedBTPeripheral): Long {
        return addWorker(GetConnectBTCmd(obj)) as Long
    }

    override fun setGpsData(gpsData: ByteArray): Long {
        return addWorker(SetGpsCmd(gpsData)) as Long
    }

    override fun setCameraWifiHeartDebug(debug: Boolean) {
        addWorker(CameraWifiHearCmd(debug))
    }

    override fun updateDownloadInfo(downLoadInfo: DownLoadInfo): Long {
        return addWorker(UpdateDownloadInfoCmd(downLoadInfo)) as Long
    }

    override fun getDownloadFileList(fileList: GetFileList): Long {
        return addWorker(GetDownloadFileListCmd(fileList)) as Long
    }

    override fun notifyGetDownloadFileListResult(addListResultSync: DownloadListResultSync): Long {
        return addWorker(notifyGetDownloadFileListResultCmd(addListResultSync)) as Long
    }

    override fun setGimbalControl(gimbalControl: GimbalControl): Long {
        return addWorker(SetGimbalControlCmd(gimbalControl)) as Long
    }

    override fun dspLinkTest(): Long {
        return addWorker(DspLinkCmd()) as Long
    }

    override fun gyroScopeTest(): Long {
        return addWorker(GyroScopeCmd()) as Long
    }

    override fun whiteBlanceTest(): Long {
        return addWorker(WhiteBlanceTestCmd()) as Long
    }

    override fun blackLevelTest(): Long {
        return addWorker(BlackLevelTestCmd()) as Long
    }

    override fun badPointTest(): Long {
        return addWorker(BadPointTestCmd()) as Long
    }

    override fun getAgeTestStatus(): Long = addWorker(AgeTestStatusCmd()) as Long

    override fun setMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        options: MultiPhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(
            MultiVideoModeCmd(
                funcMode,
                sensorMode,
                optionList,
                options,
                requestOptions
            )
        ) as Long
    }

    override fun getMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(GetMultiVideoCmd(funcMode, sensorMode, optionList, requestOptions)) as Long
    }

    override fun setSingleSensor(sensor: Int): Long {
        return addWorker(SingleSensorCmd(sensor)) as Long
    }

    override fun getSingleSensor(requestOptions: RequestOptions): Long {
        return addWorker(GetSingleSensorCmd(requestOptions)) as Long
    }

    override fun vibrateTest(): Long {
        return addWorker(VibrateTextCmd()) as Long
    }

    override fun stopVibrate(): Long {
        return addWorker(VibrateStopTestCmd()) as Long
    }

    override fun chargingBox(commandType: Int, datas: ByteArray): Long {
        return addWorker(ChargingBoxCmd(commandType, datas)) as Long
    }

    override fun checkVideoSupport(videoResultion: Int): Boolean {
        return addWorker(CheckVideoCmd(videoResultion)) as Boolean
    }

    override fun checkVideoSupport(width: Int, height: Int, fps: Int): Boolean {
        return addWorker(CheckVideoWHCmd(width, height, fps)) as Boolean
    }

    override fun wakeUpGo2Ble(bleDevice: BleDeviceCore) {
        addWorker(Go2BleWakeupCmd(bleDevice, mBleWakeUpListener))
    }

    override fun openBle(): Int {
        return -1
    }

    override fun uploadScriptJson(jsonFile: ByteArray): Long {
        return addWorker(ScriptJsonUploadCmd(jsonFile)) as Long
    }

    override fun uploadScriptCmd(cmdFile: ByteArray): Long {
        return addWorker(ScriptcmdUploadCmd(cmdFile)) as Long
    }

    override fun scriptRefersh(): Long {
        return addWorker(ScriptRefershCmd()) as Long
    }

    override fun scriptRun(): Long {
        return addWorker(ScriptRunCmd()) as Long
    }

    override fun setAAAFactoryMode(): Long {
        return addWorker(AAAFactoryMode()) as Long
    }

    override fun setAAANormalMode(): Long {
        return addWorker(AAANormalMode()) as Long
    }

    override fun getWhiteBlanceStatus(): Long = addWorker(GetWhiteBlanceStatusCmd()) as Long

    override fun getSFRStatus(): Long = addWorker(GetSFRStatusCmd()) as Long

    override fun getSFRResult(): Long = addWorker(GetSFRResultCmd()) as Long

    override fun setSyncStandByMode(mode: Int): Long {
        return addWorker(StandByCmd(mode)) as Long
    }

    override fun setPhotoOptionSync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return addWorker(
            SetPhotoOptionsSyncCmd(
                funcMode,
                optionTypes,
                options,
                requestOptions
            )
        ) as Long
    }

    override fun stopTimeShift(extraData: ByteArray) {
        addWorker(StopTimeShift(extraData))
    }

    override fun setKeyTimePoint(keyTimePoint: SetKeyTimePoint): Long {
        return addWorker(KeyTimePointCmd(keyTimePoint)) as Long
    }

    override fun openCameraWifi(countryChannel: Int): Long {
        return addWorker(OpenCameraWifiCmd(countryChannel)) as Long
    }

    override fun closeCameraWifi(): Long {
        return addWorker(CloseCameraWifiCmd()) as Long
    }

    override fun resetCameraWifi(countryChannel: Int): Long {
        return addWorker(ResetCameraWifiCmd(countryChannel)) as Long
    }

    override fun setCameraWifiSeizeEnable(connectionState: Int): Long {
        return addWorker(SetCameraWifiSeizeEnableCmd(connectionState)) as Long
    }

    override fun setWifiConnectionInfo(wifiConnectionInfo: WifiConnectionInfo): Long {
        return addWorker(SetWifiConnectionInfoCmd(wifiConnectionInfo)) as Long
    }

    override fun setAvailableWifi(wifiConnectionInfo: WifiConnectionInfo): Long {
        return addWorker(SetAvailableWifiCmd(wifiConnectionInfo)) as Long
    }

    override fun getWifiConnectionInfo(): Long = addWorker(GetWifiConnectionInfoCmd()) as Long

    override fun setWifiMode(wifiMode: Int, countryCode: String?): Long {
        return addWorker(SetWifiModeCmd(wifiMode, countryCode)) as Long
    }

    override fun requestData(
        dir: DataTransPortDir,
        rxdatainfo: List<RequestReceiveDataInformation>?,
        txdatainfo: List<RequestSendDataInformation>?,
    ): Long {
        return addWorker(RequestDataCmd(dir, rxdatainfo, txdatainfo)) as Long
    }

    override fun dataTransportFeedback(dataTransportResult: DataTransportResult): Long {
        return addWorker(DataTransportFeedbackCmd(dataTransportResult)) as Long
    }

    override fun switchWifiChannel(needScan: Int, channel: Int): Long {
        return addWorker(SwitchWifiChannelCmd(needScan, channel)) as Long
    }

    override fun getWifiInterfStatus(): Long = addWorker(GetWifiInterfStatusCmd()) as Long

    override fun setWifiState(info: WifiConnectionInfo, wifiNetState: Int): Long {
        return addWorker(SetWifiStateCmd(info, wifiNetState)) as Long
    }

    override fun setShowCloudTab(showCloudTab: Boolean): Long {
        return addWorker(SetShowCloudTabCmd(showCloudTab)) as Long
    }

    override fun setPhoneInfo(manufacturer: String, model: String, osVersion: String): Long {
        return addWorker(SetPhoneInfoCmd(manufacturer, model, osVersion)) as Long
    }

    override fun getWifiMode(): Long = addWorker(GetWifiModeCmd()) as Long

    override fun deleteWifiHistoryInfo(ssid: String): Long {
        return addWorker(DeleteWifiHistoryInfoCmd(ssid)) as Long
    }

    override fun getWifiConnectList(): Long = addWorker(GetWifiConnectListCmd()) as Long

    override fun getWifiScanList(interval: Int, count: Int): Long {
        return addWorker(GetWifiScanListCmd(interval, count)) as Long
    }

    override fun startCameraLive(): Long {
        return addWorker(StartCameraLiveCmd()) as Long
    }

    override fun stopCameraLive(): Long {
        return addWorker(StopCameraLiveCmd()) as Long
    }

    override fun requestP3StaticStreamData(): Long {
        return addWorker(RequestP3StaticStreamDataCmd()) as Long
    }

    override fun prepareCameraLive(): Long {
        return addWorker(PrepareCameraLiveCmd()) as Long
    }

    override fun setAccessCameraFileState(accessState: Int): Long {
        return addWorker(SetAccessCameraFileStateCmd(accessState)) as Long
    }

    override fun setFlowStateEnable(enable: Int): Long {
        return addWorker(SetFlowStateCmd(enable)) as Long
    }

    override fun getFlowStateEnable(): Long = addWorker(GetFlowStateCmd()) as Long

    override fun getDarkEisStatus(): Long = addWorker(GetDarkEisStatusCmd()) as Long

    fun setPreRecord(): Long {
        return addWorker(GetDarkEisStatusCmd()) as Long
    }

    override fun startTimeShift(): Long {
        return addWorker(StartTimeshiftCmd()) as Long
    }

    override fun openWifi(
        networkHandle: Long,
        to: Int,
        addr: String,
        port: Short,
        heartBeats: Boolean,
        isUseUcd2: Boolean,
        processBusyPacketEnable: Boolean,
    ) {
        // 创建心跳协程域
        heartScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        addWorkerSync(
            0, OpenWifiCmd(
                networkHandle,
                to,
                addr,
                port,
                heartBeats,
                isUseUcd2,
                processBusyPacketEnable,
                heartScope!!,
                mCameraConnectionListeners
            )
        )
    }

    override fun closeWifi() {
        addWorker(CloseUsbCmd(mUsbService))
        // 取消心跳协程域，停止所有心跳
        heartScope?.cancel()
        heartScope = null
    }

    override fun openIperf(mode: Int) {
        addWorker(OpenIperfCmd(mode))
    }

    override fun closeIperf() {
        addWorker(CloeIperfCmd())
    }

    override fun getIperfAverage() {
        addWorker(GetIperfAverageCmd())
    }

    override fun isCameraSyncedReady(): Boolean {
        return mOneDrvier.checkSynced()
    }

    override fun setGlobalRequestTimeoutMs(timeoutMs: Int): Boolean {
        return mOneDrvier.setGlobalRequestTimeoutMs(timeoutMs)
    }

    override fun setGlobalRequestRetryCount(retryCount: Int): Boolean {
        return mOneDrvier.setGlobalRequestRetryCount(retryCount)
    }

    override fun scan(scanTimeout: Long, autoConnect: Boolean, bleScanListener: IBleScanListener) {
        addWorkerSync(0, BleScanCmd(scanTimeout, autoConnect, bleScanListener))
    }

    override fun scan(bleScanRuleConfigCore: BleScanRuleConfigCore, bleScanListener: IBleScanListener) {
        addWorkerSync(0, BleScanCmd(bleScanRuleConfigCore, bleScanListener))
    }

    override fun stopScan() {
        addWorkerSync(0, BleStopScanCmd())
    }

    override fun disConnect(bleDevice: BleDeviceCore) {
        addWorker(BleStopCmd(bleDevice))
    }

    override fun connectDevice(
        bleDevice: BleDeviceCore,
        wakeUpAuthorizationUUID: String,
        enableHeartBeat: Boolean,
        isUseUcd2: Boolean,
        bleConnectListener: IBleConnectListener?,
    ) {
        // 创建心跳协程域
        heartScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        val deviceName = bleDevice.name
        if (!deviceName.isNullOrEmpty() &&
            (deviceName.startsWith("Flow") || deviceName.startsWith("FMG"))
        ) {
            addWorkerSync(
                0, FMGConnectCmd(
                    bleDevice,
                    bleConnectListener,
                    heartScope
                )
            )
        } else {
            addWorkerSync(
                0, BleConnectCmd(
                    bleDevice,
                    bleConnectListener,
                    heartScope,
                    enableHeartBeat,
                    isUseUcd2,
                    wakeUpAuthorizationUUID,
                    object : IWifiProxyDataListener {
                        override fun onReadWifiProxyData(wifiProxyData: IWifiProxyData?) {
                            onWifiProxyDataNotify(wifiProxyData)
                        }

                    },
                ))
        }
    }

    override fun disConnectBle() {
        closeBle()
    }

    override fun sendDisconnectBleData() {
        addWorker(BleSendDisconnectDataCmd())
    }

    override fun wakeUpBle(mode: Int, deviceName: String, txPower: Byte) {
        addWorker(BleWakeUpCmd(mode, deviceName, txPower, mBleWakeUpListener!!))
    }

    override fun closeBle() {
        addWorker(BleCloseCmd())
        // 取消心跳协程域，停止所有心跳
        heartScope?.cancel()
        heartScope = null
    }

    override fun stopWakeup() {
        addWorker(BleStopWakeupCmd(mBleStopWakeupCallback))
    }

    override fun connectClassicBluetooth(bleDevice: BleDeviceCore,
                                         isBleProxy: Boolean,
                                         isHeartBeatEnable: Boolean,
                                         isUseUcd2: Boolean,
                                         listener: IBleConnectListener) {
        addWorkerSync(
            0, ClassicConnectCmd(
                bleDevice,
                bleConnectListener = listener,
                classicConnectData = ClassicConnectData(isBleProxy, isHeartBeatEnable),
                heartScope,
                object : IWifiProxyDataListener {
                    override fun onReadWifiProxyData(wifiProxyData: IWifiProxyData?) {
                        onWifiProxyDataNotify(
                            wifiProxyData!!
                        )
                    }

                },
                isUseUcd2 = isUseUcd2,
            ))
    }

    override fun disconnectClassicBluetooth(address: String): Boolean {
        return BleManagerCore.disconnectClassicBluetooth(address)
    }

    override fun extendClassicConnectTimeout() {
        BleManagerCore.extendClassicConnectTimeout()
    }

    override fun sendOpenCameraClassicBluetooth(connectType: Int): Long {
        return addWorker(SendOpenCameraClassicBluetoothCmd(connectType)) as Long
    }

    override fun sendAiVoiceReady(isHuawei: Boolean): Long {
        return addWorker(SendAiVoiceReadyCmd(isHuawei)) as Long
    }

    override fun openUsb() {
        addWorker(OpenUsbCmd(mUsbService!!, mCameraConnectionListeners!!))
    }

    override fun startHdrCapture() {
        addWorker(HdrCaptureCommand())
    }

    override fun stopHdrCapture(extraData: ByteArray) {
        addWorker(HdrStopCaptureCmd(extraData))
    }

    override fun testUsbSpeed(testSDCardSpeed: TestSDCardSpeed) {
        addWorker(UsbSpeedCmd(testSDCardSpeed))
    }

    override fun closeUsb() {
        addWorkerSync(0, CloseUsbCmd(mUsbService))
    }

    override fun obtainCameraRtosStatus() {
        addWorker(ObtainRtosStatusCmd())
    }

    override fun startContactTest() {
        addWorker(ContactTestCmd())
    }

    override fun startColorTest() {
        addWorker(ColorTestCmd())
    }

    override fun getFmgDeviceInfo() = addWorker(GetFmgDeviceInfoCmd()) as Long

    override fun getFmgUUID() = addWorker(GetFmgUUIDCmd()) as Long

    override fun getFmgActiveTime() = addWorker(GetFmgActiveTimeCmd()) as Long

    override fun setFmgActiveTime(activeTime: Long): Long {
        return addWorker(SetFmgActiveTimeCmd(activeTime)) as Long
    }

    override fun setFmgZoomScale(scale: Short) {
        addWorkerSync(0, SetFmgZoomScaleCmd(scale))
    }

    override fun getFmgAllSettings() = addWorker(GetFmgAllSettingsCmd()) as Long

    override fun setFmgSettingsMode(mode: PtzMode): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzMode = mode
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingFollowSpeed(followSpeed: PtzFollowSpeed): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzFollowSpeed = followSpeed
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingRcSpeed(rcSpeed: PtzRcSpeed): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzRcSpeed = rcSpeed
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingZoomSpeed(zoomSpeed: PtzZoomSpeed): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzZoomSpeed = zoomSpeed
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingRcHorizontalDir(horizontalDir: PtzRcHorizontalDir): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzRcHorizontalDir = horizontalDir
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingRcVerticalDir(verticalDir: PtzRcVerticalDir): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzRcVerticalDir = verticalDir
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingSoundEnable(soundMode: PtzSoundMode): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzSoundEnable = soundMode
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingHvMode(hvMode: PtzHvMode): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzHvMode = hvMode
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingSwitchModeWay(modeWay: PtzSwitchModeWay): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzSwitchModeWay = modeWay
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setSettingLedBrightness(brightness: Int): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzLedBrightness = brightness
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingMotorStrength(motorStrength: PtzMotorStrength): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzMotorStrength = motorStrength
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingRoll360(rollSpeed: PtzRoll360): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzRoll360 = rollSpeed
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingQuickStart(quickStart: PtzQuickStart): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzQuickStart = quickStart
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun setFmgSettingPitchLed(pitchLed: PtzPitchLed): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzPitchLed = pitchLed
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun getFmgVerticalTrimDegree() = addWorker(GetFmgVerticalTrimDegreeCmd()) as Long

    override fun setFmgVerticalTrimDegree(degree: Float): Long {
        return addWorker(SetFmgVerticalTrimDegreeCmd(degree)) as Long
    }

    override fun startOrUpdateFmgTargetFollow(followParams: FmgTargetFollowParams) {
        addWorkerSync(
            0,
            SetFmgTargetFollowCmd(SetFmgTargetFollowCmd.Companion.TF_NORMAL, followParams)
        )
    }

    override fun speculateFmgTargetFollow(followParams: FmgTargetFollowParams) {
        addWorkerSync(
            0,
            SetFmgTargetFollowCmd(SetFmgTargetFollowCmd.Companion.TF_SPECULATE, followParams)
        )
    }

    override fun compositionFmgTargetFollow() {
        addWorkerSync(
            0,
            SetFmgTargetFollowCmd(SetFmgTargetFollowCmd.Companion.TF_COMPOSITION, null)
        )
    }

    override fun lostFmgTargetFollow() {
        addWorkerSync(0, SetFmgTargetFollowCmd(SetFmgTargetFollowCmd.Companion.TF_LOST, null))
    }

    override fun exitFmgTargetFollow() {
        addWorkerSync(0, SetFmgTargetFollowCmd(SetFmgTargetFollowCmd.Companion.TF_EXIT, null))
    }

    override fun startFmgCalibrate(): Long {
        return addWorker(StartFmgCalibrateCmd()) as Long
    }

    override fun startFmgUpgrade(
        fileData: ByteArray,
        writeWithoutResponse: Boolean,
        mtu: Int,
        writeExtraBleOTA: Boolean,
    ): Long {
        return addWorker(
            StartFmgUpgradeCmd(
                fileData,
                writeWithoutResponse,
                mtu,
                writeExtraBleOTA
            )
        ) as Long
    }

    override fun cancelFmgUpgrade() {
        addWorker(CancelFmgUpgradeCmd())
    }

    override fun startFmgAITrackUpgrade(upgradeConfig: AITrackUpgradeConfig): Long {
        return addWorker(StartFmgAITrackUpgradeCmd(upgradeConfig)) as Long
    }

    override fun cancelFmgAITrackUpgrade() {
        addWorker(CancelFmgAITrackUpgradeCmd())
    }


    override fun setFmgButtonEnable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return addWorker(SetFmgButtonEnableCmd(fmgButtonAbleParams)) as Long
    }

    override fun setFmgButtonDisable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return addWorker(SetFmgButtonDisableCmd(fmgButtonAbleParams)) as Long
    }

    override fun setDwSrcEventState(enable: Boolean): Long {
        return addWorker(SetDwSrcEventStateCmd(enable)) as Long
    }

    override fun getFmgButtonEnableStates() = addWorker(GetFmgButtonEnableCmd()) as Long

    override fun getFmgMidCal() = addWorker(GetFmgMidCalCmd()) as Long

    override fun setFmgMidCal(euler: DoubleArray): Long {
        return addWorker(SetFmgMidCalCmd(euler)) as Long
    }

    override fun getFmgRunControl(state: PtzGrfState): Long {
        return addWorker(GetFmgRunControlCmd(state)) as Long
    }

    override fun setFmgRunControl(
        state: PtzGrfState,
        yaw: Float,
        pitch: Float,
        roll: Float,
    ): Long {
        return addWorker(SetFmgRunControlCmd(state, yaw, pitch, roll)) as Long
    }

    override fun setFmgVirtualRc(x: Short, y: Short): Long {
        return addWorker(SetFmgVirtualRcCmd(x, y)) as Long
    }

    override fun setFmgTimeElapse(mode: PtzTemMode, state: PtzTemState, duration: Int): Long {
        return addWorker(SetFmgTimeElapseCmd(mode, state, duration)) as Long
    }

    override fun resetFmgDefaultSettings(): Long {
        return addWorker(ResetFmgDefaultSettingsCmd()) as Long
    }

    override fun getFmgTrackSensitivityMode() = addWorker(GetFmgTrackSensitivityCmd()) as Long

    override fun setFmgTrackSensitivityMode(mode: PtzTrackSensitivityMode): Long {
        return addWorker(SetFmgTrackSensitivityCmd(mode)) as Long
    }

    override fun setFmgPano(mode: PtzPanoMode): Long {
        return addWorker(SetFmgPanoCmd(mode)) as Long
    }

    override fun startFmgRecMode(mode: PtzRecMode): Long {
        return addWorker(StartFmgRecModeCmd(mode)) as Long
    }

    override fun stopFmgRecMode(mode: PtzRecMode): Long {
        return addWorker(StopFmgRecModeCmd(mode)) as Long
    }

    override fun initFmgRecMode(mode: PtzRecMode): Long {
        return addWorker(InitFmgRecModeCmd(mode)) as Long
    }

    override fun fmgVibration(): Long {
        return addWorker(FmgVibrationCmd()) as Long
    }

    override fun enableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return addWorker(EnableFmgHandDragCmd(list)) as Long
    }

    override fun disableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return addWorker(DisableFmgHandDragCmd(list)) as Long
    }

    override fun setFmgCameraFacing(frame: Short): Long {
        return addWorker(SetFmgCameraFacingCmd(frame)) as Long
    }

    override fun backCenter(): Long {
        return addWorker(BackCenterCmd()) as Long
    }

    override fun updateFmgAppImuAngle(fmgAngleBean: FmgAngleBean) {
        addWorker(UpdateFmgAppImuAngleCmd(fmgAngleBean))
    }

    override fun updateFmgAppImuInfo(floats: FloatArray) {
        addWorker(UpdateFmgAppImuInfoCmd(floats))
    }

    override fun getFmgAnalyticsData() = addWorker(GetFmgAnalyticsDataCmd()) as Long

    override fun clearFmgAnalyticsData(): Long {
        return addWorker(ClearFmgAnalyticsDataCmd()) as Long
    }

    override fun getFmgBleAnalyticsData(): Long {
        return addWorker(GetFmgBleAnalyticsDataCmd()) as Long
    }

    override fun clearFmgBleAnalyticsData(): Long {
        return addWorker(ClearBleFmgAnalyticsDataCmd()) as Long
    }

    override fun startFmgHeartBeat() {
        addWorker(StartFmgHeartBeatCmd())
    }

    override fun stopFmgHeartBeat() {
        addWorker(StopFmgHeartBeatCmd())
    }

    override fun setFmgAngleSeq(paramsList: List<FmgSetAngleSeqBean>): Long {
        return addWorker(SetFmgAngleSeqCmd(paramsList)) as Long
    }

    override fun setPanoIndex(index: Short, frame: PtzPanoIndexFrame): Long {
        return addWorker(SetFmgPanoIndexCmd(index, frame)) as Long
    }

    override fun setFmgAction(action: Short): Long {
        return addWorker(SetFmgActionCmd(action)) as Long
    }

    override fun setFmgAppStatus(recording: Short, touch: Short): Long {
        return addWorker(SetFmgAppStatusCmd(recording, touch)) as Long
    }

    override fun setFmgRoll360Action(action: PtzRoll360Action): Long {
        return addWorker(SetFmgRoll360ActionCmd(action)) as Long
    }

    override fun getAiTrackerDeviceInfo(): Long = addWorker(GetAiTrackerDeviceInfoCmd()) as Long

    override fun setAiTrackerStandbyMode(standbyMode: PtzAiTrackerStandbyMode): Long {
        return addWorker(SetAiTrackerStandbyModeCmd(standbyMode)) as Long
    }

    override fun setAiTrackerAutoStandbyTime(standbyTime: PtzAiTrackerAutoStandbyTime): Long {
        return addWorker(SetAiTrackerAutoStandbyTimeCmd(standbyTime)) as Long
    }

    override fun setAiTrackerOnePlamShoot(onePlamShoot: PtzAiTrackerOnePlamShoot): Long {
        return addWorker(SetAiTrackerOnePlamShootCmd(onePlamShoot)) as Long
    }

    override fun getAiTrackerSettings(): Long = addWorker(GetFmgAiTrackerAllSettingsCmd()) as Long

    override fun updateHbRecMode(mode: PtzRecMode) {
        addWorker(UpdateHbRecModeCmd(mode))
    }

    override fun setFmgSettingSurroundShoot(surroundShoot: PtzSurroundShoot): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzSurroundShoot = surroundShoot
        val setFmgSettingsCmd = SetFmgSettingsCmd(settingsParams)
        return addWorker(setFmgSettingsCmd) as Long
    }

    override fun setFmgSettingEnableSaveHv(enableSaveHv: PtzEnableSaveHv): Long {
        val settingsParams = FmgSettingsParams()
        settingsParams.ptzEnableSaveHv = enableSaveHv
        return addWorker(SetFmgSettingsCmd(settingsParams)) as Long
    }

    override fun getCloudStorageUploadStatus(): Long =
        addWorker(GetCloudStorageUploadStatusCmd()) as Long

    override fun setCloudStorageUploadStatus(params: CloudStorageUploadParams): Long {
        return addWorker(SetCloudStorageUploadStatusCmd(params)) as Long
    }

    override fun getCloudStorageBindStatus(): Long =
        addWorker(GetCloudStorageBindStatusCmd()) as Long

    override fun setCloudStorageBindStatus(params: CloudStorageBindParams): Long {
        return addWorker(SetCloudStorageBindStatusCmd(params)) as Long
    }

    override fun setNetworkConfigEnable(params: SetNetworkConfigEnable): Long {
        return addWorker(SetNetworkConfigEnableCmd(params)) as Long
    }

    override fun syncAccurateTime(): Long {
        return addWorker(SyncAccurateTimeCmd()) as Long
    }

    override fun ptzBasketballA2G(
        mode: PtzBaksetballMode,
        state: PtzBaksetballState,
        transition: PtzBaksetballTransition,
    ): Long {
        return addWorker(BasketballA2GCmd(mode, state, transition)) as Long
    }

    override fun ptzBasketballInitNoBask() {
        addWorker(ptzBasketballInitNoBaskCmd())
    }

    override fun setCloudPromptInterval(intervalSeconds: Long, cloudBackupPromptsSeconds: Long): Long {
        return addWorker(SetCloudPromptIntervalCmd(intervalSeconds, cloudBackupPromptsSeconds)) as Long
    }

    override fun restoreFactorySettings(): Long {
        return addWorker(RestoreFactorySettingsCmd()) as Long
    }

    override fun setSingleHostInfo(singleHostCmdInfo: SingleHostCmdInfo): Long {
        return addWorker(SingleHostInfoCmd(singleHostCmdInfo)) as Long
    }

    override fun getIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return addWorker(GetIntervalRecCfgCmd(intervalRecInfo)) as Long
    }

    override fun setIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return addWorker(SetIntervalRecCfgCmd(intervalRecInfo)) as Long
    }

    override fun startStopIntervalRec(intervalRecStartStop: IntervalRecStartStop): Long {
        return addWorker(StartStopIntervalRecCmd(intervalRecStartStop)) as Long
    }

    override fun cancelIntervalRec(intervalRecCancel: IntervalRecCancel): Long {
        return addWorker(CancelIntervalRecCmd(intervalRecCancel)) as Long
    }

    override fun getIntervalRecStatus(): Long {
        return addWorker(GetIntervalRecStatusCmd()) as Long
    }

    override fun getIntervalRecSceneCfg(): Long {
        return addWorker(GetIntervalRecSceneCfgCmd()) as Long
    }

    override fun getIntervalRecFeedbackCfg(): Long {
        return addWorker(GetIntervalRecFeedbackCfgCmd()) as Long
    }

    override fun setIntervalRecFeedbackCfg(intervalRecFeedback: IntervalRecFeedback): Long {
        return addWorker(SetIntervalRecFeedbackCfgCmd(intervalRecFeedback)) as Long
    }

    override fun getFirmwareVersionsInfo(): Long {
        return addWorker(GetFirmwareVersionInfoCmd()) as Long
    }

    override fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long {
        return addWorker(OpenTrackingWithRectCmd(openTrackingWithRect)) as Long
    }

    override fun cancelTracking(): Long {
        return addWorker(CancelTrackingCmd()) as Long
    }

    override fun setPresetComposition(setPresetComposition: SetPresetComposition): Long {
        return addWorker(SetPresetCompositionCmd(setPresetComposition)) as Long
    }

    override fun notifySettingPage(settingPageNotify: PhotoSettingPage): Long {
        return addWorker(NotifySettingPageCmd(settingPageNotify)) as Long
    }

    override fun getPresetComposition(): Long {
        return addWorker(GetPresetCompositionCmd()) as Long
    }

    override fun getPtzTrackState(): Long {
        return addWorker(GetPtzTrackStateCmd()) as Long
    }
    override fun setAudioStream(request: AudioStreamCtrl, timeoutMs: Int): Long {
        return addWorker(SetAudioStreamCmd(request, timeoutMs)) as Long
    }

    override fun setAiIntent(request: AiIntentCtrl): Long {
        return addWorker(SetAiIntentCmd(request)) as Long
    }

    override fun setAssistantLanguage(request: AssistantLanguageCtrl): Long {
        return addWorker(SetAssistantLanguageCmd(request)) as Long
    }

    override fun setUserRegion(request: UserRegionCtrl): Long {
        return addWorker(SetUserRegionCmd(request)) as Long
    }

    override fun bindBluetoothMacFeature(featureBluetoothMacBind: FeatureBluetoothMacBind): Long {
        return addWorker(BindBluetoothMacFeatureCmd(featureBluetoothMacBind)) as Long
    }

    override fun sendStreamData(streamType: StreamType, timestamp: Long, data: ByteArray) {
        addWorker(SendStreamDataCmd(streamType, timestamp, data))
    }

    // 原来的HeartHandler类已被CoroutineHeartHandler替代
    // 常量已移动到CoroutineHeartHandler中
}
