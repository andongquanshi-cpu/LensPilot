package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class GetPresetCompositionCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getPresetComposition()
    }
}