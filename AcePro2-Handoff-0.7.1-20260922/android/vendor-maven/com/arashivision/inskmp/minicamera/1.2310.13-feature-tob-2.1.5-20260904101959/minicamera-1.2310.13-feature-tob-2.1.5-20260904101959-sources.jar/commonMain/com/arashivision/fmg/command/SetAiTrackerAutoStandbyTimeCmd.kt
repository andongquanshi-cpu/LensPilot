package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.onecamera.OneDriver

class SetAiTrackerAutoStandbyTimeCmd(private val standbyTime: PtzAiTrackerAutoStandbyTime) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzAiTrackerAutoStandbyTime(standbyTime)
    }
}
