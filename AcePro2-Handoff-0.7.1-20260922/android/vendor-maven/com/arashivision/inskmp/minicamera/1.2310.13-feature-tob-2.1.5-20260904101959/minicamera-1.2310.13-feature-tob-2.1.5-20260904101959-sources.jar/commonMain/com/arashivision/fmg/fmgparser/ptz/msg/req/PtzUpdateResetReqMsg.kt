package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils
import kotlin.random.Random

class PtzUpdateResetReqMsg : PtzDataReqMessage() {
    private val data = ByteArray(6)


    override fun packData(): ByteArray? {
        Random.nextBytes(data)
        data[2] = (data[0] + data[1]).toByte()
        data[3] = (data[0] * data[1]).toByte()
        data[4] = (data[0].toInt() xor data[2].toInt()).toByte()
        data[5] = (data[1].toInt() xor data[3].toInt()).toByte()
        return data
    }

    override fun toString(): String {
        return FmgByteUtils.bytes2hex(data)
    }

    override fun name(): String {
        return "CMD_UPDATE_RESET_REQ"
    }
}
