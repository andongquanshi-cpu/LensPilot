package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver
import insta360.messages.ScanBTPeripheral

/**
 * 扫描蓝牙遥控器
 */
class ScanBTCmd(private val mScanBTPeripheral: ScanBTPeripheral) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.scanBT(mScanBTPeripheral)
    }
}
