package com.arashivision.onedriver.action

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Action队列类 - 对应C++版本的ActionQueue
 * 管理Action的队列操作
 */
class ActionQueue {
    private val actions = mutableListOf<Action>()
    private val mutex = Mutex()

    /**
     * 查找指定ID的Action
     */
    suspend fun findAction(actionId: Long): Action? = mutex.withLock {
        return actions.find { it.getId() == actionId }
    }

    /**
     * 移除指定ID的Action
     */
    suspend fun removeAction(actionId: Long) = mutex.withLock {
        actions.removeAll { it.getId() == actionId }
    }

    /**
     * 获取指定ID之前的Action列表
     * 如果找不到指定ID，返回整个队列
     */
    suspend fun getActionsBefore(actionId: Long): List<Action> = mutex.withLock {
        val result = mutableListOf<Action>()
        for (action in actions) {
            if (action.getId() == actionId) {
                break
            }
            result.add(action)
        }
        return result
    }

    /**
     * 克隆Action列表
     */
    suspend fun cloneActions(): List<Action> = mutex.withLock {
        return actions.toList()
    }

    /**
     * 获取队列大小
     */
    suspend fun size(): Int = mutex.withLock {
        return actions.size
    }

    /**
     * 检查队列是否为空
     */
    suspend fun isEmpty(): Boolean = mutex.withLock {
        return actions.isEmpty()
    }

    /**
     * 清空队列
     */
    suspend fun clear() = mutex.withLock {
        actions.clear()
    }

    /**
     * 添加Action到队列末尾
     */
    suspend fun pushBack(action: Action) = mutex.withLock {
        actions.add(action)
    }

    /**
     * 获取队列第一个Action
     */
    suspend fun front(): Action? = mutex.withLock {
        return actions.firstOrNull()
    }

    /**
     * 获取队列最后一个Action
     */
    suspend fun back(): Action? = mutex.withLock {
        return actions.lastOrNull()
    }

    /**
     * 移除队列第一个Action
     */
    suspend fun popFront() = mutex.withLock {
        if (actions.isNotEmpty()) {
            actions.removeAt(0)
        }
    }

    /**
     * 获取队列的迭代器（用于遍历）
     */
    suspend fun getIterator(): List<Action> = mutex.withLock {
        return actions.toList()
    }

    /**
     * 移除指定位置的Action
     */
    suspend fun removeAt(index: Int): Action? = mutex.withLock {
        return if (index in actions.indices) {
            actions.removeAt(index)
        } else {
            null
        }
    }

    /**
     * 转换为字符串表示
     */
    override fun toString(): String {
        return actions.joinToString(prefix = "[", postfix = "]", separator = ", ")
    }
}
