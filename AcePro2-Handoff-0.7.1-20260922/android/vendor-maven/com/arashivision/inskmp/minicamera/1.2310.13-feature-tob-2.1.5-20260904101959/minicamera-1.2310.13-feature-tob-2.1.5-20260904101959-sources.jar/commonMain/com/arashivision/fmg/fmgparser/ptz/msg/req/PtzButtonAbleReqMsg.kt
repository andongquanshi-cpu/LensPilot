package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzButtonAbleReqMsg(private val value: IntArray) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(value.size)
        for (i in value.indices) {
            data[i] = value[i].toByte()
        }
        return data
    }

    override fun toString(): String {
        return "value: " + value.contentToString()
    }

    override fun name(): String {
        return "PtzButtonAbleReqMsg"
    }
}
