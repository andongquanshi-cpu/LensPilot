package com.arashivision.fmg.response

class FmgSetTimeElapseResp(var requestID: Long)
