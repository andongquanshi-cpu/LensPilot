package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

class StartFmgUpgradeCmd(
    private val mFileData: ByteArray,
    private val writeWithoutResponse: Boolean,
    private val mtu: Int,
    private val writeExtraBleOTA: Boolean
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.startFmgUpgrade(mFileData, writeWithoutResponse, mtu, writeExtraBleOTA)
    }
}
