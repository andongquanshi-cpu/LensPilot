package com.arashivision.fmg

import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateingReqMsg

class FmgUpgradeBean(
    val requestId: Long,
    originalOTAFileData: ByteArray,
    writeUpgradeWithoutResponse: Boolean,
    writeUpgradeMTU: Int,
    writeExtraBleOTA: Boolean
) {
    val upgradeFileTotalSize: Long = originalOTAFileData.size.toLong()
    var upgradedDataSize: Int = 0
        private set
    private val mUpgradePartList: List<ByteArray>? =
        FmgByteUtils.splitFirmware(originalOTAFileData)
    var isWriteUpgradeWithoutResponse: Boolean = false
        private set
    var writeUpgradeMTU: Int = PtzUpdateingReqMsg.Companion.MAX_DATA_SIZE_PER_PACKET
        private set
    var isWriteExtraBleOTA: Boolean = false
        private set

    init {
        isWriteUpgradeWithoutResponse = writeUpgradeWithoutResponse
        this.writeUpgradeMTU = writeUpgradeMTU
        isWriteExtraBleOTA = writeExtraBleOTA
    }

    val isValid: Boolean
        get() = mUpgradePartList != null && !mUpgradePartList.isEmpty()

    fun getOTAFileDataByIndex(index: Int): ByteArray? {
        if (mUpgradePartList != null && mUpgradePartList.size > index) {
            return mUpgradePartList[index]
        }
        return null
    }

    val upgradePartSize: Int
        get() {
            if (mUpgradePartList != null) {
                return mUpgradePartList.size
            }
            return 0
        }

    fun addUploadedDataSize(dataSize: Int) {
        upgradedDataSize += dataSize
    }
}
