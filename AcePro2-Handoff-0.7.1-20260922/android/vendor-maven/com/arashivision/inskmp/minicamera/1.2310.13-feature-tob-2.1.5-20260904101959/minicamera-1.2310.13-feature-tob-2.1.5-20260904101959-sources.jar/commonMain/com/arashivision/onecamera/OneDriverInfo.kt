package com.arashivision.onecamera

//
///**
// * Created by vans on 16/10/17.
// */
class OneDriverInfo {
    class LinuxCmd {
        object RtosStatus {
            const val NORMAL: Int = 0x01
            const val ERROR: Int = 0x02
        }
    }

    /**
     * used when record without storage or live
     */
    object RecordFormat {
        const val VIDEO_FORMAT_MP4: String = "mp4"
        const val VIDEO_FORMAT_FLV: String = "flv"
    }

    //
//    /**
//     * video format ,only h264 support
//     */
//    object VideoFormat {
//        const val CAMERA_FRAME_FORMAT_FRAME_BASED_H264: Int =
//            0 //        public static final int CAMERA_FRAME_FORMAT_MJPEG = 1;
//    }
//
//    /**
//     * Audio Codec when streaming
//     */
//    object AudioCodec {
//        const val RAW: Int = 0
//        const val ADTS: Int = 1
//    }
//
//    /**
//     * Audio Channel
//     */
//    object AudioChannel {
//        const val MONO: Int = 1
//        const val STEREO: Int = 2
//    }
//
    class Notification {
        object ShutDownErrorCode {
            const val BATTERT_RUNOUT: Int = 0
            const val TEMPERATURE_OVERLIMIT: Int = 1
        }

        object ErrorCode {
            const val OVER_TIME_LIMIT: Int = 0
            const val STORAGE_FULL: Int = 1
            const val OTHER_SITUATION: Int = 2
            const val OVER_FILE_NUMBER_LIMIT: Int = 3
            const val LOW_CARD_SPEED: Int = 4
            const val MUXER_STREAM_ERROR: Int = 5
            const val DROP_FRAMES: Int = 6
            const val LOW_BATTERY: Int = 7
            const val STORAGEFRGMT: Int = 8
            const val HIGH_TEMP: Int = 9
            const val LOW_POWER_START: Int = 10
            const val STORAGE_RUNOUT_START: Int = 11
            const val HIGH_TEMP_START: Int = 12
        }

        //        object CardState {
//            const val STOR_CS_PASS: Int = 0
//            const val STOR_CS_NOCARD: Int = 1
//            const val STOR_CS_NOSPACE: Int = 2
//            const val STOR_CS_INVALID_FORMAT: Int = 3
//            const val STOR_CS_WPCARD: Int = 4
//            const val STOR_CS_OTHER_ERROR: Int = 5
//        }
//
//        object CardLocation {
//            const val STOR_CL_CAMERA: Int = 0
//            const val STOR_CL_READER: Int = 1
//        }
//
        object TakePictureState {
            const val SHUTTER: Int = 0
            const val COMPRESS: Int = 1
            const val WRITE_FILE: Int = 2
        }

        //
//        object KeyId {
//            const val F0_SHORT_PRESS: Int = 0
//            const val F0_DOUBLE_PRESS: Int = 1
//            const val F0_TRIPLE_PRESS: Int = 2
//        }
//
//        object UsbState {
//            const val SYNCED: Int = 0
//            const val ERROR: Int = 1
//            const val NOT_START: Int = 2
//        }
//
        object UsbError {
            const val ERR_CAMERA_BASE: Int = 0
            const val ERR_USB: Int = -120
            const val ERR_NO_DEV: Int = -121
            const val ERR_DEV_DETACH: Int = -121

            const val ERR_SOCKET_CLOSE: Int = -210
            const val ERR_SOCKET_READ: Int = -211
            const val ERR_SOCKET_WRITE: Int = -212
            const val ERR_SOCKET_FD_SET: Int = -213
            const val ERR_SOCKET_CONNECT: Int = -214
            const val ERR_SOCKET_TIMEOUT: Int = -19

            const val ERR_SOCKET_DIRTY_DATA: Int = -21

            // cloud upload busy
            const val INS_WIFI_BUSY_UPLOAD: Int = -504

            // wifi switch busy
            const val INS_WIFI_BUSY_SWITCHING: Int = -505
        }
//
//        object Authorization {
//            const val SUCCESS: Int = 0
//            const val REJECT: Int = 1
//            const val TIMEOUT: Int = 2
//            const val SYSTEM_BUSY: Int = 3
//        }
//
//        object AuthorizationOperationType {
//            const val BLE_CONNECT: Int = 0 // 蓝牙连接首次校验走check_authorization.proto，此处定义只做个占位
//            const val WIFI_PWD_SETTING: Int = 1
//            const val CLOUD_BIND: Int = 2
//            const val USB_STORAGE_PASSWD_SETTING: Int = 3
//        }
    }

    //
//    class Request {
//        object BTPeripheralType {
//            const val BTPERIPHERALTYPE_ALL: Int = 0
//            const val BTPERIPHERALTYPE_REMOTE: Int = 1
//        }
//
//        object MediaType {
//            const val MEDIATYPE_VIDEO: Int = 0
//            const val MEDIATYPE_PHOTO: Int = 1
//            const val MEDIATYPE_VIDEO_AND_PHOTO: Int = 2
//            const val MEDIATYPE_DNG: Int = 3
//            const val MEDIATYPE_MP4: Int = 4
//            const val MEDIATYPE_JPG: Int = 5
//            const val MEDIATYPE_INS_DATA: Int = 6
//            const val MEDIATYPE_IDLE_ANALYSIS: Int = 7
//            const val MEDIATYPE_PROFILE_DATA: Int = 8
//        }
//
////        object TimelapseMode {
////            // video 的设置
////            const val TIMELAPSE_VIDEO: Int = 1
////
////            // image 的设置（go之后变为移动延时）
////            const val TIMELAPSE_INTERVAL_SHOOTING: Int = 2
////
////            //定位延时的设置
////            const val STATIC_TIMELAPSE_VIDEO: Int = 3
////
////            //间隔录像的设置
////            const val TIMELAPSE_INTERVAL_VIDEO: Int = 4
////
////            // 星空模式拍照的设置
////            const val TIMELAPSE_STARLAPSE_SHOOTING: Int = 5
////
////            //QC 单击
////            const val TIMELAPSE_QC_SINGLE_PRESS: Int = 6
////
////            //QC 双击
////            const val TIMELAPSE_QC_DOUBLE_PRESS: Int = 7
////
////            //单主机 单击
////            const val TIMELAPSE_CAMERA_SINGLE_PRESS: Int = 8
////
////            //单主机 双击
////            const val TIMELAPSE_CAMERA_DOUBLE_PRESS: Int = 9
////        }
//
//        /**
//         * 传输速度
//         */
//        object StandbyMode {
//            //默认
//            const val STANDBY_MODE_UNKNOWN: Int = 0
//
//            //低速
//            const val STANDBY_MODE_LOW_ENERGY: Int = 1
//
//            //高速
//            const val STANDBY_MODE_WAKE_UP: Int = 2
//        }
//
//        object ImageMode {
//            const val NORMAL: Int = 0
//            const val AEB: Int = 1
//            const val RAW: Int = 2
//            const val BURST: Int = 3
//            const val AEB_NIGHT: Int = 4
//        }
//
//        object ExtraType {
//            // 所有文件尾数据，包括总大小、版本、UUID等
//            const val EXTRA_TYPE_ALL: Int = 0x00
//
//            // 文件尾的metadata 数据，返回的数据为序列化过的 ExtraMetadata
//            const val EXTRA_TYPE_METADATA: Int = 0x01
//
//            // 视频的缩略图
//            const val EXTRA_TYPE_THUMBNAIL: Int = 0x02
//
//            // 陀螺仪数据 {{ timestamp, accelerate{x, y, z}, rotation_rate{x, y, z} } ... }
//            const val EXTRA_TYPE_GYRO: Int = 0x03
//
//            // 曝光数据 {{timestamp, exposure_duration} ... }
//            const val EXTRA_TYPE_EXPOSURE: Int = 0x04
//
//            // 左右圆分别存储时，另一个视频的缩略图
//            const val EXTRA_TYPE_EXT_THUMBNAIL: Int = 0x05
//        }
//
//        object IperfMode {
//            const val TCP: Int = 0
//            const val UDP: Int = 1
//        }
//
    /**
     * keytime point
     */
    object KeyTimeDetial {
        const val TRACK_THAT: String = "com.insta360.keyTime.trackThat"
        const val HIGHLIGHT: String = "com.insta360.keyTime.highlight"
        const val SLOWDOWN: String = "com.insta360.keyTime.slowdown"
        const val ONETAKE: String = "com.insta360.keyTime.onetake"
        const val MULTICAM_INNER: String = "com.insta360.keyTime.multicamInnerScreen"
        const val MULTICAM_OUTER: String = "com.insta360.keyTime.multicamOuterScreen"
        const val MULTICAM_SPLIT: String = "com.insta360.keyTime.multicamSplitScreen"
    }
//
//        object KeyTimeType {
//            const val INSTANT: Int = 0
//            const val START: Int = 1
//            const val END: Int = 2
//        }
//
//        object SensorDevice {
//            const val SENSOR_DEVICE_UNKNOWN: Int = 0
//            const val SENSOR_DEVICE_FRONT: Int = 1
//            const val SENSOR_DEVICE_REAR: Int = 2
//            const val SENSOR_DEVICE_ALL: Int = 3
//        }
//
//        object FileType {
//            const val FILE_TYPE_UNKNOWN: Int = 0
//            const val FILE_TYPE_ETK: Int = 1
//            const val FILE_TYPE_LOG: Int = 2
//            const val FILE_TYPE_PARAMS_JSON: Int = 3
//            const val FILE_TYPE_PARAMS_RIJSON: Int = 4
//        }
//
//        object TransferStatus {
//            const val TRANSFER_UNKNOWN: Int = 0
//            const val TRANSFER_SUCCESS: Int = 1
//            const val TRANSFER_FAIL: Int = 2
//        }
//
//        object ConnectionState {
//            const val UNKNOWN: Int = 0
//            const val MONOPOLIZED: Int = 1
//            const val SEIZABLE: Int = 2
//        }
//
//        object AccessCameraFileState {
//            const val UNKNOWN: Int = 0
//            const val IDLE: Int = 1
//            const val EXPORT: Int = 2
//            const val DOWNLOAD: Int = 3
//            const val PLAYBACK: Int = 4
//            const val LIVE_VIEW: Int = 5
//        }
//    }
//
    object Response {
        const val RESPONSE_SUC: Int = 0
//
//        /**
//         * 相机云存储上传行为
//         */
//        object CloudUploadAction {
//            const val CLOUD_UPLOAD_UNKNOWN: Int = 0
//
//            //进入预上传状态
//            const val CLOUD_UPLOAD_PRE: Int = 1
//
//            //进入上传状态
//            const val CLOUD_UPLOAD_INTERRUPT: Int = 2
//        }
//
//        object WifiConnectResult {
//            // 已连接路由器，且网络可连通公网
//            const val SUCCESS: Int = 0
//
//            // 已连接路由器，但无法ping通公网
//            const val TIMEOUT: Int = 1
//
//            // 无法连接路由器，可能是密码错误
//            const val ERROR_CONNECT_FAILED: Int = 2
//
//            // 密码错误
//            const val PASSWORD_ERROR: Int = 3
//
//            // 无法分配到IP
//            const val UNABLE_ASSIGN_IP: Int = 4
//
//            // 无密码wifi连接到路由器
//            const val CONNECT_SUCCESS: Int = 5
//        }
//
//        object DeleteWifiResult {
//            const val NONE: Int = 0
//            const val SUCCESS: Int = 1
//            const val SSID_NOT_FOUND: Int = 2
//        }
//
//        object CloudBindResult {
//            const val BIND_SUCCESS: Int = 0
//            const val BIND_FAILED: Int = 1
//        }
//
//        object CloudBindStatus {
//            const val NONE: Int = 0
//            const val BOUND: Int = 1
//
//            const val NOT_BOUND: Int = 2
//        }
//
//
//        object CloudUploadStatus {
//            const val NONE: Int = 0
//            const val UPLOADING: Int = 1
//            const val IDLE: Int = 2
//        }
//
//        object CameraCaptureState {
//            const val NOT_CAPTURE: Int = 0
//            const val NORMAL_CAPTURE: Int = 1
//            const val TIMELAPSE_CAPTURE: Int = 2
//            const val INTERVAL_SHOOTING_CAPTURE: Int = 3
//
//            // ONEX [2018-07-24]
//            const val SINGLE_SHOOTING: Int = 4
//            const val HDR_SHOOTING: Int = 5
//
//            /**
//             * 10,9,8 .... shooting,then finished
//             */
//            const val SELF_TIMER_SHOOTING: Int = 6
//            const val BULLET_TIME_CAPTURE: Int = 7
//
//            /**
//             * param setting in camera
//             */
//            const val SETTINGS_NEW_VALUE: Int = 8
//
//            /**
//             * hdr record
//             */
//            const val HDR_CAPTURE: Int = 9
//
//            /**
//             * burst shooting
//             */
//            const val BURST_SHOOTING: Int = 10
//
//            /**
//             *
//             */
//            const val STATIC_TIMELAPSE_SHOOTING: Int = 11
//
//
//            /**
//             * interval video
//             */
//            const val INTERVAL_VIDEO_CAPTURE: Int = 12
//
//            /**
//             * timeshift
//             */
//            const val TIMESHIFT_CAPTURE: Int = 13
//
//            /**
//             * night shoot
//             */
//            const val AEB_NIGHT_SHOOTING: Int = 14
//
//            /**
//             * single power pano
//             */
//            const val SINGLE_POWER_PANO_SHOOTING: Int = 15
//
//            /**
//             * hdr power pano
//             */
//            const val HDR_POWER_PANO_SHOOTING: Int = 16
//
//            /**
//             * super normal captue
//             */
//            const val SUPER_NORMAL_CAPTURE: Int = 17
//
//            /**
//             * loop recording capture
//             */
//            const val LOOP_RECORDING_CAPTURE: Int = 18
//
//            /**
//             * starlapse shooting
//             */
//            const val STARLAPSE_SHOOTING: Int = 19
//
//            const val FPV_RECORDING_CAPTURE: Int = 20
//
//            const val MOVIE_RECORDING_CAPTURE: Int = 21
//
//            const val SLOW_MOTION_CAPTURE: Int = 22
//
//            const val SELFIE_RECORDING_CAPTURE: Int = 23
//
//            const val PURE_VIDEO: Int = 24
//
//            const val DASH_CAM: Int = 29
//
//            const val PTZ_RECORD: Int = 30
//
//            const val MOSQUITO: Int = 31
//
//            /**
//             * unknown state ,only happen when higher camera hw firmware add new state,but app is still old version
//             */
//            const val UNKNOWN_STATE: Int = 100
//        }
//
//        object CameraCaptureSubState {
//            const val SUB_STATE_NULL: Int = 0
//            const val SUB_STATE_PAUSE: Int = 1
//            const val SUB_STATE_RECORD_SAVE: Int = 2
//            const val SUB_STATE_PHOTO_SAVE: Int = 3
//            const val SUB_STATE_STARTLAPSE_SYNTHESIS: Int = 4
//            const val SUB_STATE_PHOTO_CANCEL: Int = 8
//            const val SUB_STATE_RECORD_CANCEL: Int = 9
//            const val SUB_STATE_PRE_RECORDING: Int = 10
//            const val SUB_STATE_RUNNING_STARTED_WITH_PRE_RECORD: Int = 11
//            const val SUB_STATE_EXPOSURE: Int = 12
//        }
//
//        object StreamType {
//            const val AUDIO_STREAM: Int = 0x10
//            const val VIDEO_STREAM: Int = 0x20
//            const val VIDEO_STREAM_L: Int = 0x21
//            const val VIDEO_STREAM_R: Int = 0x22
//            const val GYRO_STREAM: Int = 0x30
//            const val VIDEO_EXPOSURE_TIME: Int = 0x40
//
//            const val VIDEO_PTZ: Int = 0x83
//            const val P3_ALGORITHM: Int = 0x84
//            const val UNKNOWN: Int = 0xFF
//        }
//

        //
//        object Authenticate {
//            const val AUTHORIZED: Int = 0
//            const val UNAUTHORIZED: Int = 1
//            const val SYSTEMBUSY: Int = 2
//        }
//
//        object SyncCaptureModeInfo {
//            const val SYNC_MODE_UNKNOWN: Int = 0
//            const val SYNC_MODE_NORMAL_IMAGE: Int = 1
//            const val SYNC_MODE_NORMAL_VIDEO: Int = 2
//            const val SYNC_MODE_HDR_IMAGE: Int = 3
//            const val SYNC_MODE_HDR_VIDEO: Int = 4
//            const val SYNC_MODE_INTERVAL_IMAGE: Int = 5
//            const val SYNC_MODE_TIMELAPSE_VIDEO: Int = 6
//            const val SYNC_MODE_BURST_PHOTO: Int = 7
//            const val SYNC_MODE_BULLETTIME_VIDEO: Int = 8
//        }
//
//
        object InfoType {
            const val FIRMWARE_UPGRADE_COMPLETE: Int = 0

            const val RECORD_AUTO_SPLIT: Int = 1

            const val BATTERY_UPDATE: Int = 2

            const val BATTERY_LOW: Int = 3

            const val SHUTDOWN: Int = 4

            const val STORAGE_UPDATE: Int = 5

            const val STORAGE_FULL: Int = 6

            const val BUTTON_PRESSED: Int = 7

            const val RECORD_STOPPED: Int = 8

            const val CAPTURE_STILL_IMAGE_STATE_UPDATE: Int = 9

            //stupid camera not realize
            //            public static final int DELETE_FILES_PROGRESS = 10;
            const val PHONE_INSERT: Int = 11

            const val BT_DISCOVER_PERIPHERAL: Int = 12

            const val BT_CONNECTED_TO_PERIPHERAL: Int = 13

            const val BT_DISCONNECTED_PERIPHERAL: Int = 14

            const val NOTIFICATION_SYNC_CAPTURE_MODE_UPDATE: Int = 15
            const val NOTIFICATION_SYNC_BUTTON_TRIGGER: Int = 16
            const val NOTIFICATION_BT_REMOTE_VER_UPDATED: Int = 17

            //response of some aynsc req
            const val START_LIVE_STREAM: Int = 50
            const val STOP_LIVE_STREAM: Int = 51
            const val CANCEL_CAPTURE: Int = 52
            const val SET_OPTIONS: Int = 53
            const val GET_OPTIONS: Int = 54
            const val SET_PHOTOGRAPHY_OPTIONS: Int = 55
            const val GET_PHOTOGRAPHY_OPTIONS: Int = 56
            const val GET_FILE_EXTRA: Int = 57
            const val DELETE_FILES: Int = 58
            const val GET_FILE_LIST: Int = 59
            const val SET_FILE_EXTRA: Int = 60
            const val GET_TIMELAPSE_OPTIONS: Int = 61
            const val SET_TIMELAPSE_OPTIONS: Int = 62

            //            public static final int GET_GYRO = 63;
            const val ERASE_SD_CARD: Int = 64
            const val CALIBRATE_GYRO: Int = 65
            const val GET_MINI_THUMBNAIL: Int = 66
            const val TEST_SD_CARD_SPEED: Int = 67
            const val REBOOT_CAMERA: Int = 68

            const val OPEN_CAMERA_WIFI: Int = 69
            const val CLOSE_CAMERA_WIFI: Int = 70

            /**
             * new add for old sync command to async command
             */
            const val GET_CONNECT_BT: Int = 71
            const val GET_CURRENT_CAPTURE_STATUS: Int = 72
            const val SCAN_BT: Int = 73
            const val CONNECT_TO_BT: Int = 74
            const val DISCONNECT_BT: Int = 75

            const val GET_FILEINFO_LIST: Int = 76

            const val CAMERA_STATUS_NOTIFY: Int = 77
            const val CHECK_AUTHORIZATION: Int = 78
            const val CANCEL_AUTHORIZATION: Int = 79
            const val NOTIFY_AUTHORIZATION: Int = 80
            const val NOTIFY_TIMELAPSE_STATUS_UPDATE: Int = 81

            const val OPEN_CAMERA_OLED: Int = 82
            const val CLOSE_CAMERA_OLED: Int = 83

            const val UPLOAD_GPS: Int = 84

            const val GET_GYRO_COUNT: Int = 85

            const val GET_IPERF_AVERAGE: Int = 86
            const val OPEN_IPERF: Int = 87
            const val CLOSE_IPERF: Int = 88
            const val LED_TEST: Int = 89
            const val SPEAKER_TEST: Int = 90

            const val WIFISTATUS_TEST: Int = 91
            const val BLUETOOTHSTATUS_TEST: Int = 92

            const val SET_SYNC_CAPTURE_MODE: Int = 93
            const val GET_SYNC_CAPTURE_MODE: Int = 94
            const val SET_STANDBY_MODE: Int = 95
            const val CAM_TEMPERATURE_VALUE: Int = 96
            const val SET_KEYTIME_POINT: Int = 97
            const val SET_FLOWSTATE_ENABLE: Int = 98
            const val GET_FLOWSTATE_ENABLE: Int = 99
            const val FACTORY_CONTACT_TEST: Int = 101
            const val FACTORY_COLOR_TEST: Int = 102
            const val FACTORY_AGEING_TEST: Int = 106
            const val FACTORY_WHITE_BLANCE_TEST: Int = 108
            const val FACTORY_BLACK_LEVEL_TEST: Int = 109
            const val FACTORY_GYRO_TEST: Int = 111
            const val FACTORY_VIBRATE_TEST: Int = 112
            const val FACTORY_CHARGING_BOX: Int = 113
            const val FACTORY_SETAAA_FACTORY_MODE: Int = 118
            const val FACTORY_SETAAA_NORMAL_MODE: Int = 119
            const val GET_CLOUD_STORAGE_UPLOAD_STATUS: Int = 123
            const val SET_CLOUD_STORAGE_UPLOAD_STATUS: Int = 124
            const val GET_CLOUD_STORAGE_BIND_STATUS: Int = 125
            const val SET_CLOUD_STORAGE_BIND_STATUS: Int = 126
            const val NOTIFICATION_CLOUD_STORAGE_BIND_STATUS: Int = 127

            const val DEL_WIFI_HISTORY_INFO: Int = 128
            const val SET_MULTI_VIDEO_MODE: Int = 200
            const val GET_MULTI_VIDEO_MODE: Int = 201
            const val SET_SINGLE_SENSOR: Int = 202
            const val GET_SINGLE_SENSOR: Int = 203
            const val CAM_WIFI_START: Int = 204
            const val CAM_BT_MSG_ANALYZE_FAILED: Int = 205
            const val LIVEVIEW_BEGIN_ROTATE: Int = 206
            const val NOTIFY_EXPOSURE_UPDATE: Int = 207
            const val PREPARE_GET_FILE_PACKAGE: Int = 208
            const val GET_FILE_PACKAGE_FINISH: Int = 209
            const val SET_CAMERA_WIFI_SEIZE_ENABLE: Int = 210
            const val GET_FILE_LIST_INCLUDE_RECORDING: Int = 211
            const val REQUEST_AUTHORIZATION: Int = 212
            const val CANCEL_REQUEST_AUTHORIZATION: Int = 213
            const val CHARGE_BOX_CONNECT_STATUS_UPDATE: Int = 214
            const val SET_BUTTON_PRESS_PARAM: Int = 215
            const val GET_BUTTON_PRESS_PARAM: Int = 216
            const val IFRAME_REQUEST: Int = 217
            const val SET_WIFI_CONNECTION_INFO: Int = 218
            const val GET_WIFI_CONNECTION_INFO: Int = 219

            const val WIFI_CONNECTION_RESULT: Int = 220
            const val SET_ACCESS_CAMERA_FILE_STATE: Int = 221
            const val SET_APP_ID: Int = 222
            const val LIVE_STREAM_PARAMS_UPDATE: Int = 223
            const val NOTIFY_CHARGE_BOX_BATTERY_UPDATE: Int = 224
            const val NOTIFY_FIRMWARE_UPGRADE_STATUS_TOAPP: Int = 225
            const val NOTIFICATION_DATA_EXPORT_STATUS: Int = 226
            const val PREPARE_GET_FILE_SYNC_PACKAGE: Int = 227
            const val GET_FILE_PACKAGE_SYNC_FINISH: Int = 228
            const val NOTIFICATION_DETECTED_FACE: Int = 229
            const val GET_DARK_EIS_STATUS: Int = 230
            const val NOTIFICATION_DARK_EIS_STATUS: Int = 231
            const val NOTIFICATION_SUPPORT_TAKE_PHOTO_ON_REC_STATUS: Int = 232
            const val PAUSE_RECORDING: Int = 233

            const val PHONE_COMMAND_NOTIFY_OTA_ERROR: Int = 234
            const val NOTIFICATION_NEED_DOWNLOAD_FILE: Int = 235
            const val DOWNLOAD_INFO: Int = 236
            const val GET_DOWNLOAD_FILE_LIST: Int = 237
            const val ADD_DOWNLOAD_LIST_RESULT_SYNC: Int = 238
            const val NOTIFICATION_CAM_SUBMODE_CHANGE: Int = 239

            const val SET_AVAILABLE_WIFI: Int = 240


            const val STOP_USBCARD_BACKUP: Int = 243
            const val QUICKREADER_GET_STATUS: Int = 244
            const val NOTIFICATION_USBCARD_STATUS: Int = 245
            const val NOTIFICATION_APP_CLOUD_UPLOAD_INTERRUPT: Int = 129
            const val SET_NETWORK_CONFIG_ENABLE: Int = 130

            const val GET_EDITINFO_LIST: Int = 247
            const val SET_CAMERA_LIVE_INFO: Int = 248
            const val GET_CAMERA_LIVE_INFO: Int = 249
            const val SET_WIFI_MODE: Int = 250
            const val GET_WIFI_MODE: Int = 251
            const val GET_WIFI_SCAN_LIST: Int = 252
            const val GET_CONNECTED_WIFI_LIST: Int = 253
            const val START_CAMERA_LIVE: Int = 254
            const val STOP_CAMERA_LIVE: Int = 255
            const val NOTIFY_WIFI_MODE_CHANGE: Int = 256
            const val NOTIFY_CAMERA_LIVE_STATUS: Int = 257
            const val NOTIFY_WIFI_SCAN_LIST_CHANGED: Int = 258
            const val NOTIFICATION_FAVORITE_CHANGE_STATUS: Int = 259
            const val SET_FAVORITE: Int = 260
            const val CTRL_PRE_RECORD: Int = 262
            const val SYNC_TIME_ACCURATE: Int = 263
            const val NOTIFICATION_DASH_CAM_INFO: Int = 264
            const val SET_WIFI_STATE: Int = 265
            const val SET_SHOW_CLOUD_TAB: Int = 266
            const val SET_PHONE_INFO: Int = 267
            const val SET_SHUTDOWN: Int = 268
            const val NOTIFICATION_VIRTUAL_PTZ_MOVEMENT_STATUS: Int = 269
            const val GET_SWITCH_WIFI_CHANNEL: Int = 270
            const val GET_WIFI_INTERF_STATUS: Int = 271
            const val NOTIFICATION_SWITCH_WIFI_CHANNEL: Int = 272
            const val NOTIFICATION_GET_WIFI_INTERFERENCE_STATUS: Int = 273
            const val GET_P3_STATIC_HDR_PARAMS: Int = 274
            const val SET_CAMERA_LIVE_PREPARE: Int = 275
            const val NOTIFY_CAMERA_LIVE_ONLINE_STATUS: Int = 276
            const val STOP_TAKE_PICTURE: Int = 277
            const val NOTIFY_CAMERA_IS_P2P_TRANSMITING: Int = 278
            const val NOTIFY_CAMERA_LIVEPHOTO_SWITCH_STATUS: Int = 279
            const val SET_CLOUD_PROMPT_INTERVAL: Int = 280
            const val CAMERA_NOTIFICATION_CLOSE_WIFI: Int = 281

            const val NOTIFICATION_DELETE_FILE_RESULT: Int = 242

            const val GET_INTERVALREC_CFG = 282
            const val SET_INTERVALREC_CFG = 283
            const val INTERVALREC_REC_START_STOP = 284
            const val INTERVALREC_REC_CANCEL_CMD = 285
            const val GET_INTERVAL_RECORD_STATUS = 286
            const val GET_INTERVALREC_SCENE_CFG = 287
            const val GET_INTERVALREC_FEEDBACK_CFG = 288
            const val SET_INTERVALREC_FEEDBACK_CFG = 289
            const val NOTIFICATION_INTERVAL_REC_INFO: Int = 290
            const val NOTIFICATION_INTERVAL_REC_RESULT: Int = 291
            const val NOTIFICATION_USER_TAKEOVER: Int = 292

            const val SET_AUDIO_STREAM: Int = 293

            const val LINUX_CMD_RTOS_STATUS: Int = 300
            const val RESET_CAMERA_WIFI: Int = 301
            const val CAMERA_NOTIFICATION_WATCH_RES: Int = 302
            const val CAMERA_NOTIFICATION_STREET_PHOTO_STATUS: Int = 303
            const val PHONE_COMMAND_GIMBAL_CONTROL: Int = 304
            const val CAMERA_NOTIFICATION_GIMBAL_CALIBRATION: Int = 305
            const val CAMERA_NOTIFICATION_DETACHABLE_SCREEN_BATTERY_UPDATE: Int = 306
            const val CAMERA_NOTIFICATION_DETACHABLE_SCREEN_CONNECT_STATUS: Int = 307
            const val SET_MAIN_STORAGE: Int = 308
            const val NOTIFICATION_STORAGE_LOCATION_CHANGE: Int = 309
            const val FORMAT_STORAGE: Int = 310
            const val SINGLE_HOST_CTRL_INFO: Int = 311
            const val CAMERA_NOTIFICATION_SINGLE_HOST_INFO: Int = 312
            const val RECIPE_SHARE: Int = 313
            const val RECIPE_SHARE_STATUS: Int = 314
            const val ENCRYPT_CAPABILITY_QUERY: Int = 315
            const val ENCRYPT_KEY_EXCHANGE: Int = 316
            const val CAMERA_NOTIFICATION_PTZ_TRACK_STATE: Int = 317
            const val GET_PTZ_TRACK_STATE: Int = 318
            const val OPEN_TRACKING_WITH_RECT: Int = 319
            const val CANCEL_TRACKING: Int = 320
            const val SET_PRESET_COMPOSITION: Int = 321
            const val GET_PRESET_COMPOSITION: Int = 322
            const val CAMERA_NOTIFICATION_PRESET_COMPOSITION: Int = 323
            const val CAMERA_NOTIFICATION_AF_SCENE_CHANGE: Int = 324
            const val GET_FIRMWARE_VERSIONS: Int = 325
            const val PHONE_COMMAND_OPEN_CLASSIC_BLUETOOTH: Int = 326
            const val NOTIFICATION_AUDIO_ACTIVITY_STATUS: Int = 327
            const val CAMERA_NOTIFICATION_DATA_INFO_READY: Int = 328
            const val PHONE_COMMAND_REQUEST_DATA: Int = 329
            const val CAMERA_NOTIFICATION_DATA_TRANSPORT: Int = 330
            const val PHONE_COMMAND_DATA_TRANSPORT_FEEDBACK: Int = 331
            const val SET_AI_INTENT: Int = 332
            const val NOTIFICATION_BLUETOOTH_STATUS: Int = 333
            const val BIND_BLUETOOTH_MAC_FEATURE: Int = 334
            const val CAMERA_NOTIFICATION_AI_HIGHLIGHT_STATUS: Int = 335
            const val NOTIFICATION_AI_QUIT_ASSISTANT: Int = 336
            const val GET_TRANSLATE_CONFIG: Int = 337
            const val CAMERA_NOTIFICATION_OFFSET_STATE_UPDATE: Int = 338
            const val NOTIFICATION_PTZ_PERSPECTIVE_STATUS: Int = 339
            const val CANCEL_ANGLE_FIXED: Int = 340
            const val NOTIFICATION_PTZ_TRACK_STATE: Int = 341
            const val CAMERA_NOTIFICATION_TM_TRACKER_EAR_HOOK_WEAR_STATE: Int = 342
            const val SET_USER_REGION: Int = 343
             const val SET_ASSISTANT_LANGUAGE: Int = 344
            const val CAMERA_NOTIFICATION_PTZ_STATE: Int = 345
            const val NOTIFY_SETTING_PAGE: Int = 346

            // 自动切换夜景录像模式变更通知
            const val CAMERA_NOTIFICATION_AUTO_SWITCH_NIGHT_VIDEO: Int = 347
            const val CAMERA_NOTIFICATION_POSTURE_REBUILD_STATE: Int = 348
            const val UNKNOWN: Int = 100

            const val FACTORY_USB_SPEED_TEST: Int = 103
            const val FACTORY_LCD_CLOSE_TESTT: Int = 104
            const val FACTORY_BUTTON_STATUS_TEST: Int = 105
            const val FACTORY_AGE_TEST_STATUS: Int = 106
            const val FACTORY_DSP_LINK_TEST: Int = 107
            const val FACTORY_WHITEBLANCE_TEST: Int = 108
            const val FACTORY_BLACKLEVEL_TEST: Int = 109
            const val FACTORY_BAD_POINT_TEST: Int = 110
            const val FACTORY_GYRO: Int = 111
            const val FACTORY_VIBRATE: Int = 112
            const val FACTORY_COMMAND_CHARGINGBOX: Int = 113
            const val FACTORY_SCRIPT_JSON_UPLOAD: Int = 114
            const val FACTORY_SCRIPT_CMD_UPLOAD: Int = 115
            const val FACTORY_SCRIPT_REFERSH: Int = 116
            const val FACTORY_SCRIPT_RUN: Int = 117
            const val FACTORY_SET_AAAFACTORY_MODE: Int = 118
            const val FACTORY_SET_AAANORMAL_MODE: Int = 119
            const val FACTORY_GET_WHITEBLANCE_STATUS: Int = 120
            const val FACTORY_GET_SFR_STATUS: Int = 121
            const val FACTORY_GET_SFR_RESULT: Int = 122
            const val RESTORE_FACTORY_SETTINGS: Int = 131

            const val FMG_OTA_COMPLETE: Int = 1000
            const val FMG_OTA_PROGRESS_CHANGE: Int = 1001
            const val FMG_OTA_CANCEL: Int = 1002
            const val FMG_GET_DEVICE_INFO: Int = 1003
            const val FMG_SET_ACTIVE_TIME: Int = 1004
            const val FMG_GET_ACTIVE_TIME: Int = 1005
            const val FMG_GET_SETTINGS: Int = 1006
            const val FMG_SET_SETTINGS: Int = 1007
            const val FMG_GET_VERTICAL_TRIM_DEGREE: Int = 1008
            const val FMG_SET_VERTICAL_TRIM_DEGREE: Int = 1009
            const val FMG_START_CALIBRATE: Int = 1010
            const val FMG_CALIBRATE_PROGRESS_CHANGE: Int = 1011
            const val FMG_SET_BUTTON_ENABLE: Int = 1012
            const val FMG_SET_BUTTON_DISABLE: Int = 1013
            const val FMG_GET_MID_CAL: Int = 1014
            const val FMG_SET_MID_CAL: Int = 1015
            const val FMG_ZOOM_SCALE: Int = 1016
            const val FMG_SET_RC: Int = 1017
            const val FMG_GET_RC: Int = 1018
            const val FMG_TIME_ELAPSE: Int = 1019
            const val FMG_RESET_DEFAULT_SETTINGS: Int = 1020
            const val FMG_PANO: Int = 1021
            const val FMG_VIBRATION: Int = 1022
            const val ENABLE_HAND_DRAG: Int = 1023
            const val DISABLE_HAND_DRAG: Int = 1024
            const val FMG_SET_CAMERA_FACING: Int = 1025
            const val FMG_GET_ANALYTICS_DATA: Int = 1026
            const val FMG_CLEAR_ANALYTICS_DATA: Int = 1027
            const val FMG_GET_UUID: Int = 1028
            const val FMG_ANGLE_SEQ_SET: Int = 1029
            const val FMG_GET_BUTTON_ENABLE_STATE: Int = 1030
            const val FMG_GET_ETS: Int = 1031
            const val FMG_SET_ETS: Int = 1032
            const val FMG_ACTION: Int = 1033
            const val FMG_OTA_AI_TRACK_COMPLETE: Int = 1034
            const val FMG_OTA_AI_TRACK_PROGRESS_CHANGE: Int = 1035
            const val FMG_OTA_AI_TRACK_CANCEL: Int = 1036
            const val FMG_SET_PANO_INDEX: Int = 1037
            const val FMG_APP_STATUS: Int = 1038
            const val FMG_BASKETBALL_G2A: Int = 1039
            const val FMG_SET_ROLL_360_MODE: Int = 1040
            const val FMG_GET_AI_TRACKER_DEVICE_INFO: Int = 1041
            const val FMG_BACK_CENTER: Int = 1042
            const val FMG_GET_AI_TRACKER_SETTINGS: Int = 1043
            const val FMG_SET_AI_TRACKER_SETTINGS: Int = 1044
            const val FMG_SET_YAW_360_MODE: Int = 1045

            const val FMG_NOTIFY_DEVICE_STATUS: Int = 2000 //云台推送设备状态
            const val FMG_NOTIFY_MODE_BTN_EVENT: Int = 2001 //模式（M）按键消息
            const val FMG_NOTIFY_SHUTTER_BTN_EVENT: Int = 2002 //快门按键消息
            const val FMG_NOTIFY_HOLD_BTN_EVENT: Int = 2003 //扳机按键消息
            const val FMG_NOTIFY_MIDDLE_BTN_EVENT: Int = 2004 //摇杆中键消息
            const val FMG_NOTIFY_ROCKER_EVENT: Int = 2005 //摇杆按键消息
            const val FMG_NOTIFY_TOUCH_EVENT: Int = 2006 //触摸消息
            const val FMG_NOTIFY_DIAL_WHEEL_EVENT: Int = 2007 //拨轮消息
            const val FMG_NOTIFY_DIAL_WHEEL_VAULE_EVENT: Int = 2008 //拨轮原始值
            const val FMG_NOTIFY_POWER_BTN_EVENT: Int = 2009 //电源按键消息
            const val FMG_NOTIFY_GRF_ANGLE_REACH: Int = 2010 //CMD_RC_SET命令 在设置位置信息（GRF_ANGLE）完成后的通知
            const val FMG_NOTIFY_RC_SRC_VALUE_EVENT: Int = 2011 //摇杆原始值
            const val FMG_NOTIFY_SURROUND_SHOOT_COMPLETE: Int = 2012 //一键环拍完成结束
            const val PHOTOGRAPHY_OPTIONS_CHANGE: Int = 2013 //拍摄参数联动变更通知（相机主动推送被联动改动的参数）

            const val FMG_BUSYNESS: Int = 9999
        }
//
//        /**
//         * 按键状态，当前正在按的按键是哪一个
//         */
//        object ButtonState {
//            const val BUTTON_UNKNOWN: Int = 0
//            const val BUTTON_POWER_DONW: Int = 1 //电源键按下状态
//            const val BUTTON_SHOOT_DONW: Int = 2 //拍摄键按下状态
//            const val BUTTON_BOTH_DONW: Int = 3 //两个按键同时按下状态
//            const val BUTTON_NONE_DONW: Int = 4 //无按键按下状态
//        }
//
//        object UpgradeState {
//            const val UPGRADE_STATE_IDLE: Int = 0 // 空闲状态
//            const val UPGRADE_STATE_PRE_NOFILE: Int = 1 // 没有升级文件
//            const val UPGRADE_STATE_GET_FILE_LIST_ERROR: Int = 2 // 四合一包 固件解压错误
//            const val UPGRADE_STATE_PRE_CAME_NOPOWER: Int = 3 // 相机低电
//            const val UPGRADE_STATE_PRE_CASE_NOPOWER: Int = 4 // 充电盒低电
//            const val UPGRADE_STATE_ING_UNPACK: Int = 5 // 正在解压升级包
//            const val UPGRADE_STATE_ING_UNPACK_ERROR: Int = 6 // 解压包失败
//            const val UPGRADE_STATE_ING_CHECK_MD5_ERROR: Int = 7 // 校验四合一包md5失败
//            const val UPGRADE_STATE_ING_CASE_FW_START: Int = 8 // 开始传输充电盒升级包
//            const val UPGRADE_STATE_ING_CASE_FW_ERROR: Int = 9 // 传输充电盒升级包失败
//            const val UPGRADE_STATE_ING_CASE_BT_FW_START: Int = 10 // 开始传输充电盒蓝牙升级包
//            const val UPGRADE_STATE_ING_CASE_BT_FW_ERROR: Int = 11 // 传输充电盒升级包失败
//            const val UPGRADE_STATE_ING_CAME_BT_FW_START: Int = 12 // 开始传输主机蓝牙升级包
//            const val UPGRADE_STATE_ING_CAME_BT_FW_ERROR: Int = 13 // 传输主机蓝牙升级包失败
//            const val UPGRADE_STATE_ING_CAME_FW_START: Int = 14 // 开始升级主机固件
//            const val UPGRADE_STATE_VERSION_CHECK_SUCCESS: Int = 15 // 升级后版本校验成功
//            const val UPGRADE_STATE_VERSION_CHECK_FAILED: Int = 16 // 升级后版本校验失败
//            const val UPGRADE_STATE_ING_FW_UPLOAD: Int = 17 // app开始传升级包
//            const val UPGRADE_STATE_FW_UPLOAD_FAILED: Int = 18 // app传升级包失败
//            const val UPGRADE_STATE_FW_UPLOAD_SUCCESS: Int = 19 // app传升级包成功
//            const val UPGRADE_STATE_PRE_USB_SHAKEHANDS_FAIL: Int = 20 // 检测usb握手失败
//            const val UPGRADE_STATE_PRE_BT_SHAKEHANDS_FAIL: Int = 21 // 检测蓝牙握手失败
//            const val UPGRADE_STATE_CAME_AND_CASE_NOPOWER: Int = 22
//            const val UPGRADE_STATE_ING_CAME_BT_FW_DOUBLE_START: Int = 23 // 固件升级时间为5分钟
//        }
//    }
//
//    /**
//     * get camera configuration by Options
//     * [OneDriver.getOptionsAsync]}
//     * [OneDriver.setOptionsAsync]
//     */
//    object Options {
//        const val TIME_WATERMARK_SWITCH: String = "time_watermark_switch"
//        const val QUICK_READER_MOVING_FLAG: String = "quick_reader_moving_flag"
//        const val INTERNAL_SPLICING: String = "enableInternalSplicing"
//        const val DARK_EIS_ENABLE_GLOBAL: String = "dark_eis_enable_global"
//        const val METERING_ENABLE_GLOBAL: String = "metering_enable_global"
//
//        //        public static final String VIDEO_RESULUTION = "video_resolution";
//        const val VIDEO_RESULUTION_WIDTH: String = "video_resolution-width"
//        const val VIDEO_RESULUTION_HEIGHT: String = "video_resolution-height"
//        const val VIDEO_RESULUTION_FPS: String = "video_resolution-fps"
//
//        // 照片分辨率, readwrite
//        //        public static final String VIDEO_RESULUTION_WIDTH = "photo_size";
//        const val PHOTO_SIZE_WIDTH: String = "photo_size-width"
//        const val PHOTO_SIZE_HEIGHT: String = "photo_size-height"
//
//        // 视频码率, readwrite
//        const val VIDEO_BITRATE: String = "video_bitrate"
//
//        // 音频码率, readwrite
//        const val AUDIO_BITRATE: String = "audio_bitrate"
//
//        // 音频采样率, readwrite
//        const val AUDIO_SAMPLERATE: String = "audio_samplerate"
//
//        // 初始 OFFSET, readwrite
//        const val ORIGIN_OFFSET: String = "origin_offset"
//
//        // 最长录像时间(min), readwrite
//        const val CAPTURE_TIME_LIMIT: String = "capture_time_limit"
//
//        // 获取GPS 超时时间(min), readwrite
//        const val GPS_TIMEOUT: String = "gps_timeout"
//
//        // 剩余录像时间, readonly
//        const val REMAINING_CAPTURE_TIME: String = "remaining_capture_time"
//
//        // 剩余可拍摄照片数量, readonly
//        const val REMAINIG_PICTURES: String = "remaining_pictures"
//
//        // 当前电池等级, readonly
//        //        public static final String VIDEO_RESULUTION_WIDTH = "battery_status";
//        const val BATTERY_POWER_TYPE: String = "battery_status-power_type"
//        const val BATTERY_LEVEL: String = "battery_status-battery_level"
//        const val BATTERY_SCALE: String = "battery_status-battery_scale"
//        const val BATTERY_TYPE: String = "battery_status-battery_type"
//
//        // 本地时间, write only !
//        const val LOCAL_TIME: String = "local_time"
//
//        // 本地时区, readwrite
//        const val TIME_ZONE: String = "time_zone_seconds_from_gmt"
//
//        // 静音, readwrite
//        const val MUTE: String = "mute"
//
//        // 设备序列号, readwrite
//        const val SERIAL_NUMBER: String = "serial_number"
//
//        // UUID, readonly
//        const val ONE_UUID: String = "uuid"
//
//        // 按钮点击模式, readwrite
//        //        public static final String VIDEO_RESULUTION_WIDTH = "pressoptions";
//        const val BUTTON_PRESS_CLICK: String = "pressoptions-click"
//        const val BUTTON_PRESS_DOUBLE_CLICK: String = "pressoptions-doubleclick"
//        const val BUTTON_PRESS_TRIPLE_CLICK: String = "pressoptions-tripleclick"
//        const val BUTTON_PRESS_LONG_PRESS: String = "pressoptions-longpress"
//        const val BUTTON_PRESS_SHORT_PRESS: String = "pressoptions-shortpress"
//        const val BUTTON_PRESS_SHUTDOWN_CLICK: String = "pressoptions-shutdown_click"
//        const val BUTTON_PRESS_SHUTDOWN_SHORT_PRESS: String = "pressoptions-shutdown_short_press"
//        const val BUTTON_PRESS_SHUTDOWN_DOUBLE_CLICK: String = "pressoptions-shutdown_double_click"
//        const val BUTTON_PRESS_SHUTDOWN_TRIPLE_CLICK: String = "pressoptions-shutdown_triple_click"
//        const val BUTTON_PRESS_SHUTDOWN_LONG_PRESS: String = "pressoptions-shutdown_long_press"
//
//        // 激活时间, readwrite
//        const val ACTIVATE_TIME: String = "activate_time"
//
//        // 存储状态, readonly
//        //        public static final String VIDEO_RESULUTION_WIDTH = "storage_state";
//        const val STORAGE_CARD_STATE: String = "storage_state-card_state"
//        const val STORAGE_FREE_SPACE: String = "storage_state-free_space"
//        const val STORAGE_TOTAL_SPACE: String = "storage_state-total_space"
//        const val STORAGE_CARD_LOCATION: String = "storage_state-card_location"
//
//        // 镜头类型, readonly
//        const val LENS_INDEX: String = "lens_index"
//
//        // 相机OFFSET, readwrite
//        const val MEDIA_OFFSET: String = "media_offset"
//
//        // 定时拍摄, readwrite
//        const val SELF_TIMER: String = "self_timer"
//
//        // 陀螺仪数据的采样率, readwrite
//        const val GYRO_SAMPLE_RATE: String = "gyro_sample_rate"
//
//        // 加速度计的刻度范围
//        const val ACC_FULL_SCALE_RANGE: String = "acc_range"
//
//        // 陀螺仪数据的刻度范围, readwrite
//        const val GYRO_FULL_SCALE_RANGE: String = "gyro_range"
//
//        // 拍RAW, readwrite
//        const val TAKE_RAW_PICTURE: String = "take_raw_picture"
//
//        // Log模式, readwrite
//        const val LOG_MODE: String = "log_mode"
//
//        // 相机的预览流的时间戳
//        const val MEDIA_TIME: String = "media_time"
//
//        // 固件版本
//        const val FIRMWAREREVISION: String = "firmwarerevision"
//
//        //current system
//        const val APOPTION_SYSTEM: String = "sys_adoption"
//
//        const val CPU_TYPE: String = "cpu_type"
//
//        const val GYRO_FILTER: String = "gyro_filter"
//
//        const val MCTF_ENABLE: String = "mctf_enable"
//
//        const val SPORT_MODE_ENABLE: String = "sport_mode_enable"
//
//        const val WIFI_SSID: String = "wifi_ssid"
//
//        const val WIFI_PWD: String = "wifi_password"
//
//        const val WIFI_CH: String = "wifi_channel"
//
//        const val WIFI_MODE: String = "wifi_mode"
//
//        const val WIFI_STATE: String = "wifi_state"
//
//        const val WIFI_PWD_VERSION: String = "wifi_passwd_version"
//
//        const val WIFI_IS_BUSY: String = "wifi_is_busy"
//
//        const val WIFI_MAC_ADDRESS: String = "wifi_mac_address"
//
//        const val WIFI_CH_COUNTY: String = "wifi_channel_country"
//
//        const val WIFI_CHANNEL_LIST: String = "wifi_channel_list"
//
//        const val AUTHORIZATION_ID: String = "authorization_id"
//
//        const val CALIBRATION_OFFSET: String = "calibration_offset"
//
//        const val PHOTO_SUB_MODE: String = "photo_sub_mode"
//
//        const val VIDEO_SUB_MODE: String = "video_sub_mode"
//
//        const val SECOND_STREAM_RES: String = "second_stream_res"
//
//        const val WIFI_STATUS: String = "wifi_status"
//
//        const val EVO_STATUS_MODE: String = "evo_status_mode"
//
//        const val ORIGIN_OFFSET_3D: String = "origin_offset_3d"
//
//        const val MEDIA_OFFSET_3D: String = "media_offset_3d"
//
//        const val CALIBRATION_OFFSET_3D: String = "calibration_offset_3d"
//
//        const val CAMERA_TYPE: String = "camera_type"
//
//        const val BT_REMOTE_VERSION: String = "bt_remote_version"
//
//        const val BT_REMOTE_TYPE: String = "bt_remote_type"
//
//        //全景镜头0序列号
//        const val SENSOR0_SERIAL_VR360: String = "sensor0_serial_vr360"
//
//        //全景镜头1序列号
//        const val SENSOR1_SERIAL_VR360: String = "sensor1_serial_vr360"
//
//        //广角镜头序列号
//        const val SENSOR_SERIAL_VR180: String = "sensor_serial_vr180"
//
//        //镜头序列号
//        const val SENSOR_SERIALS: String = "sensor_serials"
//
//        //语音授权序列号
//        const val MOBVOI_LICENSE: String = "mobvoi_license"
//
//        //语音授权publicKey
//        const val MOBVOI_PUBLIC_KEY: String = "mobvoi_public_key"
//
//        const val QUALITY_SETTING: String = "quality_setting"
//
//        const val INTERNAL_FLOWSTATE: String = "internal_flowstate"
//
//        // 视频编码格式
//        const val VIDEO_ENCODE_TYPE: String = "video_encode_type"
//
//        // 主视频编码格式
//        const val MAIN_VIDEO_ENCODE_TYPE: String = "main_video_encode_type"
//
//        //正插/反插
//        const val IS_SELFIE: String = "is_selfie"
//
//        //闪烁频率
//        const val IMAGE_FLICKER: String = "image_flicker"
//
//        //sensor
//        const val FOCUS_SENSOR: String = "focus_sensor"
//
//        //expect output type
//        const val EXPECT_OUT_TYPE: String = "expect_output"
//
//        //chargbox status
//        const val CHARGEBOX_CONNECTED_STATE: String = "chargebox_connected_state"
//        const val CHARGEBOX_USB_CONNECTED_STATE: String = "chargebox_usb_connected_state"
//        const val CHARGEBOX_BATTERY_POWER_TYPE: String = "chargingbox_battery_status-power_type"
//        const val CHARGEBOX_BATTERY_LEVEL: String = "chargingbox_battery_status-battery_level"
//        const val CHARGEBOX_BATTERY_SCALE: String = "chargingbox_battery_status-battery_scale"
//        const val CHARGEBOX_BATTERY_TYPE: String = "chargingbox_battery_status-battery_type"
//
//        //硬件版本类型
//        const val HW_TYPE: String = "hw_type"
//
//        //origin offset v2
//        const val ORIGIN_OFFSET_V2: String = "ofigin_offset_v2"
//
//        //origin offset v3
//        const val ORIGIN_OFFSET_V3: String = "ofigin_offset_v3"
//
//        //media offset v2
//        const val MEDIA_OFFSET_V2: String = "media_offset_v2"
//
//        //media offset v3
//        const val MEDIA_OFFSET_V3: String = "media_offset_v3"
//
//        //gyro timestamp
//        const val GYRO_TIME_STAMP: String = "gyro_time_stamp"
//
//        const val SENSOR_ID: String = "sensor_id"
//
//        const val SENSOR_TYPE: String = "sensor_type"
//
//        const val MOBVOI_LICENSE_VERITY_STATE: String = "mobvoi_license_verity_state"
//
//        const val CAMERA_LANGUAGE: String = "camera_language"
//
//        const val CAMERA_POSTURE: String = "camera_posture"
//
//        const val BT_WAKEUP_SW: String = "bt_wakeup_sw"
//
//        const val OFFSET_STATES: String = "offset_states"
//
//        const val CAMERA_DEVICE_VERSION: String = "camera_device_version"
//
//        const val CAMERA_BLE_VERSION: String = "camera_ble_version"
//
//        const val CAMERA_OTA_PKG_VERSION: String = "camera_ota_pkg_version"
//
//        const val CHARGEBOX_VERSION: String = "box_version"
//
//        const val CHARGEBOX_BLE_VERSION: String = "box_bt_version"
//
//        const val CHARGEBOX_OTA_PKG_VERSION: String = "box_ota_pkg_version"
//
//        // 开始拍摄时的相机姿态（用于app兼容GO3普通录像比例旋转）
//        const val CAMERA_POSTURE_WHEN_CAPTURE_START: String = "camera_posture_when_capture_start"
//
//        // 开始拍摄时的充电盒连接状态（用于app兼容GO3普通录像比例旋转）
//        const val CHARGEBOX_CONNECTED_STATE_WHEN_CAPTURE_START: String =
//            "chargebox_connected_state_when_capture_start"
//
//        // DashCamInfo
//        const val DISK_TOTAL_SPACE: String = "disk_total_space"
//        const val DISK_FREE_SIZE: String = "disk_free_size"
//        const val DASH_CAM_LOOP_SPACE: String = "dash_cam_loop_space"
//        const val DASH_CAM_FILE_SPACE: String = "dash_cam_file_space"
//
//        // WindowCropInfo
//        const val WINDOW_CROP_SRC_WIDTH: String = "window_crop_src_width"
//        const val WINDOW_CROP_SRC_HEIGHT: String = "window_crop_src_height"
//        const val WINDOW_CROP_DST_WIDTH: String = "window_crop_dst_width"
//        const val WINDOW_CROP_DST_HEIGHT: String = "window_crop_dst_height"
//        const val WINDOW_CROP_OFFSET_X: String = "window_crop_offset_x"
//        const val WINDOW_CROP_OFFSET_Y: String = "window_crop_offset_y"
//        const val HALF_WINDOW_CROP_SRC_WIDTH: String = "half_window_crop_src_width"
//        const val HALF_WINDOW_CROP_SRC_HEIGHT: String = "half_window_crop_src_height"
//        const val HALF_WINDOW_CROP_DST_WIDTH: String = "half_window_crop_dst_width"
//        const val HALF_WINDOW_CROP_DST_HEIGHT: String = "half_window_crop_dst_height"
//        const val HALF_WINDOW_CROP_OFFSET_X: String = "half_window_crop_offset_x"
//        const val HALF_WINDOW_CROP_OFFSET_Y: String = "half_window_crop_offset_y"
//
//
//        const val QUICK_CAPTURE_ENABLE: String = "quick_capture_enable"
//
//        const val ASSISTIVE_GRID: String = "assistive_grid_enable"
//
//        const val FREEFRAME_GRID: String = "freeframe_grid_enable"
//
//        const val HEAT_SHELL_TYPE: String = "heat_shell_type"
//
//        const val OFFSET_DETECTED_TYPE: String = "offset_detected_type"
//
//        const val HAS_CRASH: String = "has_crash"
//
//        const val CLOUD_IS_BUSY_STATUS: String = "cloud_is_busy_status"
//
//        const val PTZ_PANO_SAVE_SWITCH: String = "ptz_pano_save_switch"
//
//        const val USB_STORAGE_PASSWD: String = "usb_storage_passwd"
//
//        //ButtonFollowOptions
//        const val BUTTON_FOLLOW_OPTIONS_CLICK: String = "button_follow_options-click"
//        const val BUTTON_FOLLOW_OPTIONS_DOUBLE_CLICK: String = "button_follow_options-double_click"
//        const val BUTTON_FOLLOW_OPTIONS_TRIPLE_CLICK: String = "button_follow_options-triple_click"
//        const val BUTTON_FOLLOW_OPTIONS_LONG_PRESS: String = "button_follow_options-long_press"
//        const val BUTTON_FOLLOW_OPTIONS_SHUTDOWN_CLICK: String =
//            "button_follow_options-shutdown_click"
//        const val BUTTON_FOLLOW_OPTIONS_SHUTDOWN_DOUBLE_CLICK: String =
//            "button_follow_options-shutdown_double_click"
//        const val BUTTON_FOLLOW_OPTIONS_SHUTDOWN_TRIPLE_CLICK: String =
//            "button_follow_options-shutdown_triple_click"
//        const val BUTTON_FOLLOW_OPTIONS_SHUTDOWN_LONG_PRESS: String =
//            "button_follow_options-shutdown_long_press"
//
//        const val CHECK_BIAS_CORRECTED: String = "check_bias_corrected"
//        const val RECTIFY_GYRO_BIAS_NEED_BIAS_CORRECTED: String =
//            "rectify_gyro_bias_need_bias_corrected"
//        const val RECTIFY_GYRO_BIAS_ACC_X: String = "rectify_gyro_bias_acc_x"
//        const val RECTIFY_GYRO_BIAS_ACC_Y: String = "rectify_gyro_bias_acc_y"
//        const val RECTIFY_GYRO_BIAS_ACC_Z: String = "rectify_gyro_bias_acc_z"
//        const val RECTIFY_GYRO_BIAS_GYRO_X: String = "rectify_gyro_bias_gyro_x"
//        const val RECTIFY_GYRO_BIAS_GYRO_Y: String = "rectify_gyro_bias_gyro_y"
//        const val RECTIFY_GYRO_BIAS_GYRO_Z: String = "rectify_gyro_bias_gyro_z"
//
//        const val CAMERA_LIVE_STATUS: String = "live_broadcast_status"
//        const val CAMERA_LIVE_ERROR_CODE: String = "live_broadcast_error_code"
//        const val P2P_TRANS_STATUS: String = "p2p_trans_status"
//
//
//        object VideoSubMode {
//            const val VIDEO_NORMAL: Int = 0
//            const val VIDEO_BULLETTIME: Int = 1
//            const val VIDEO_TIMELAPSE: Int = 2
//            const val VIDEO_HDR: Int = 3
//            const val VIDEO_TIMESHIFT: Int = 4
//            const val VIDEO_SUPER: Int = 5
//            const val VIDEO_LOOPRECORDING: Int = 6
//            const val VIDEO_FPV: Int = 7
//            const val VIDEO_MOVIE: Int = 8
//            const val VIDEO_SLOW_MOTION: Int = 9
//            const val VIDEO_SELFIE: Int = 10
//            const val VIDEO_PURE: Int = 11
//            const val VIDEO_LIVEVIEW: Int = 12
//            const val VIDEO_DASH_CAM: Int = 14
//            const val VIDEO_PTZ: Int = 15 // 虚拟云台
//            const val VIDEO_MOSQUITO: Int = 16 // 蚊子视角
//            const val VIDEO_NONE: Int = 100
//        }
//
//        object CaptureMode {
//            const val MODE_NORMAL: Int = 1
//            const val MODE_BULLETTIME: Int = 2
//            const val MODE_HDR: Int = 3
//            const val MODE_TIMESHIFT: Int = 4
//            const val MODE_SUPER_VIDEO: Int = 5
//            const val MODE_LOOPRECORDING: Int = 6
//            const val MODE_FPV: Int = 7
//            const val MODE_MOVIE: Int = 8
//            const val MODE_SLOWMOTION: Int = 9
//            const val MODE_SELFIE: Int = 10
//            const val MODE_PURE_VIDEO: Int = 11
//            const val VIDEO_DASH_CAM: Int = 12
//            const val MODE_PTZ: Int = 13
//            const val MODE_MOSQUITO: Int = 14
//        }
//
//
//        object TempState {
//            const val TEMP_LOW: Int = 0
//            const val TEMP_ALERT: Int = 1
//            const val TEMP_MIDDLE: Int = 2
//            const val TEMP_HIGH: Int = 3
//            const val TEMP_HIGH_SHUTDOWN: Int = 4
//        }
//
//        object PhotoSubMode {
//            const val PHOTO_SINGLE: Int = 0
//            const val PHOTO_HDR: Int = 1
//            const val PHOTO_INTERVAL: Int = 2
//            const val PHOTO_BURST: Int = 3
//            const val AEB_NIGHT: Int = 4
//            const val PHOTO_INSTA_PANO: Int = 5
//            const val PHOTO_INSTA_PANO_HDR: Int = 6
//            const val PHOTO_STARLAPSE: Int = 7
//            const val PHOTO_NONE: Int = 100
//        }
//
//        object WifiMode {
//            const val AP: Int = 0
//            const val STA: Int = 1
//            const val P2P: Int = 2
//        }
//
//
//        object WifiState {
//            const val UNKNOWN: Int = 0
//            const val AUTO: Int = 1
//            const val ON: Int = 2
//            const val OFF: Int = 3
//        }
//
//        object PowerType {
//            const val BATTERY: Int = 0
//            const val ADAPTER: Int = 1
//        }
//
//        object AdoptionSystem {
//            const val PHONE_IOS: Int = 0
//            const val PHONE_ANDROID: Int = 1
//        }
//
//        //for preview and record
//        object VideoResolution {
//            const val RES_3840_1920P30: Int = 0
//            const val RES_2560_1280P30: Int = 1
//            const val RES_1920_960P30: Int = 2
//            const val RES_2560_1280P60: Int = 3
//            const val RES_2048_512P120: Int = 4
//            const val RES_3328_832P60: Int = 5
//            const val RES_3072_1536P30: Int = 6
//            const val RES_2240_1120P30: Int = 7
//            const val RES_2240_1120P24: Int = 8
//            const val RES_1440_720P30: Int = 9
//
//            /**
//             * 5.7k
//             */
//            const val RES_2880_2880P30: Int = 10
//            const val RES_3840_1920P60: Int = 11
//            const val RES_3840_1920P50: Int = 12
//            const val RES_3008_1504P100: Int = 13
//            const val RES_960_480P30: Int = 14
//            const val RES_3040_1520P30: Int = 15
//            const val RES_2176_1088P30: Int = 16
//            const val RES_720_360P30: Int = 17
//            const val RES_480_240P30: Int = 18
//
//            /**
//             * 5.7k
//             */
//            const val RES_2880_2880P25: Int = 19
//
//            //ONE X
//            const val RES_2880_2880P24: Int = 20
//
//            const val RES_3840_1920P20: Int = 21
//            const val RES_1920_960P20: Int = 22
//
//            //ONE R
//            const val RES_3840_2160p60: Int = 23
//            const val RES_3840_2160p30: Int = 24
//            const val RES_2720_1530p100: Int = 25
//            const val RES_1920_1080p200: Int = 26
//            const val RES_1920_1080p240: Int = 27
//            const val RES_1920_1080p120: Int = 28
//            const val RES_1920_1080p30: Int = 29
//            const val RES_5472_3078p30: Int = 30
//            const val RES_4000_3000p30: Int = 31
//            const val RES_854_640P30: Int = 32
//            const val RES_720_406P30: Int = 33
//            const val RES_424_240P15: Int = 34
//            const val RES_1024_512P30: Int = 35
//            const val RES_640_320P30: Int = 36
//            const val RES_5312_2988P30: Int = 37
//            const val RES_2720_1530P60: Int = 38
//            const val RES_2720_1530P30: Int = 39
//            const val RES_1920_1080P60: Int = 40
//            const val RES_2720_2040P30: Int = 41
//            const val RES_1920_1440P30: Int = 42
//            const val RES_1280_720P30: Int = 43
//            const val RES_1280_960P30: Int = 44
//            const val RES_1152_768P30: Int = 45
//            const val RES_5312_2988P25: Int = 46
//            const val RES_5312_2988P24: Int = 47
//            const val RES_3840_2160P25: Int = 48
//            const val RES_3840_2160P24: Int = 49
//            const val RES_2720_1530P25: Int = 50
//            const val RES_2720_1530P24: Int = 51
//            const val RES_1920_1080P25: Int = 52
//            const val RES_1920_1080P24: Int = 53
//            const val RES_4000_3000P25: Int = 54
//            const val RES_4000_3000P24: Int = 55
//            const val RES_2720_2040P25: Int = 56
//            const val RES_2720_2040P24: Int = 57
//            const val RES_1920_1440P25: Int = 58
//            const val RES_1920_1440P24: Int = 59
//
//            //x2
//            const val RES_2560_1440P30: Int = 60
//            const val RES_2560_1440P60: Int = 61
//            const val RES_1920_1440P60: Int = 62
//            const val RES_1440_2560P30: Int = 63
//            const val RES_1080_1920P30: Int = 64
//            const val RES_1440_1920P30: Int = 65
//            const val RES_1440_2560P60: Int = 66
//            const val RES_1440_1920P60: Int = 67
//            const val RES_1080_1920P60: Int = 68
//            const val RES_2560_1440P25: Int = 69
//            const val RES_1440_2560P25: Int = 70
//            const val RES_1080_1920P25: Int = 71
//            const val RES_720_1280P30: Int = 72 //Second Stream
//            const val RES_960_1280P30: Int = 73 //Second Stream
//            const val RES_1152_1152P30: Int = 74 //Second Stream
//            const val RES_640_360P30: Int = 75 //Second Stream
//            const val RES_640_480P30: Int = 76 //Second Stream
//            const val RES_360_640P30: Int = 77 //Second Stream
//            const val RES_480_640P30: Int = 78 //Second Stream
//            const val RES_368_368P30: Int = 79 //Second Stream
//            const val RES_854_854P30: Int = 80 //go2
//            const val RES_1920_1080P50: Int = 81 //onex2 / go2
//            const val RES_1080_1920P50: Int = 82 //onex2 / go2
//            const val RES_2560_1440P50: Int = 83 //onex2 / go2
//            const val RES_1440_2560P50: Int = 84 //onex2 /go2
//            const val RES_1080_1920P24: Int = 85 //onex2 / go2
//            const val RES_2560_1440P24: Int = 86 //onex2 /go2
//            const val RES_1440_2560P24: Int = 87 //onex2 /go2
//            const val RES_1080_1920P120: Int = 88 //onex2
//            const val RES_1280_1280P30: Int = 89 //go2
//            const val RES_2880_2880P15: Int = 90 //x2
//            const val RES_1440_720P15: Int = 91 //x2
//            const val RES_3840_2160P50: Int = 92 //oneR/RS
//
//            //rs
//            const val RES_1280_1280P25: Int = 93 // oneR/RS
//            const val RES_3040_3040P24: Int = 94
//            const val RES_3040_3040P25: Int = 95
//            const val RES_3040_3040P30: Int = 96
//            const val RES_3840_1920P24: Int = 97
//            const val RES_3840_1920P25: Int = 98
//            const val RES_3040_1520P50: Int = 99
//            const val RES_2720_1530P50: Int = 100
//            const val RES_5312_3552P24: Int = 101
//            const val RES_5312_3552P25: Int = 102
//            const val RES_5312_3552P30: Int = 103
//            const val RES_5472_2328P24: Int = 104
//            const val RES_5472_2328P25: Int = 105
//            const val RES_5472_2328P30: Int = 106
//            const val RES_1600_900P30: Int = 107
//            const val RES_1760_990P30: Int = 108
//            const val RES_3840_1634P30: Int = 109
//            const val RES_3840_1634P25: Int = 110
//            const val RES_3840_1634P24: Int = 111
//            const val RES_6720_2856P25: Int = 112
//            const val RES_6720_2856P24: Int = 113
//            const val RES_6016_2560P25: Int = 114
//            const val RES_6016_2560P24: Int = 115
//            const val RES_3200_3200P24: Int = 116
//            const val RES_3200_3200P25: Int = 117
//            const val RES_3200_3200P30: Int = 118
//            const val RES_3072_3072P24: Int = 119
//            const val RES_3072_3072P25: Int = 120
//            const val RES_3072_3072P30: Int = 121
//            const val RES_2160_3840P60: Int = 122
//            const val RES_2160_3840P50: Int = 123
//            const val RES_2160_3840P30: Int = 124
//            const val RES_2160_3840P25: Int = 125
//            const val RES_2160_3840P24: Int = 126
//            const val RES_3000_1500P120: Int = 131
//            const val RES_1530_2720P60: Int = 132
//            const val RES_1530_2720P50: Int = 133
//            const val RES_1530_2720P30: Int = 134
//            const val RES_1530_2720P25: Int = 135
//            const val RES_1530_2720P24: Int = 136
//            const val RES_3840_960P120: Int = 137
//            const val RES_1152_648P30: Int = 138
//            const val RES_648_1152P30: Int = 139
//            const val RES_1152_864P30: Int = 140
//            const val RES_864_1152P30: Int = 141
//            const val RES_2944_2880P30: Int = 142
//            const val RES_3920_1920P30: Int = 143
//            const val RES_1530_2720P100: Int = 149
//            const val RES_1920_1080P100: Int = 150
//            const val RES_1080_1920P100: Int = 151
//            const val RES_4000_3000P50: Int = 152
//            const val RES_4000_3000P60: Int = 153
//            const val RES_7680_4320P30: Int = 154
//            const val RES_2944_736P200: Int = 155
//            const val RES_3456_1944P24: Int = 156
//            const val RES_3456_1944P25: Int = 157
//            const val RES_3456_1944P30: Int = 158
//            const val RES_3456_1944P50: Int = 159
//            const val RES_3456_1944P60: Int = 160
//            const val RES_1944_3456P24: Int = 161
//            const val RES_1944_3456P25: Int = 162
//            const val RES_1944_3456P30: Int = 163
//            const val RES_2944_736P180: Int = 164
//            const val RES_3840_3840P24: Int = 165
//            const val RES_3840_3840P25: Int = 166
//            const val RES_3840_3840P30: Int = 167
//            const val RES_3584_2400P24: Int = 168
//            const val RES_3584_2400P25: Int = 169
//            const val RES_3584_2400P30: Int = 170
//            const val RES_3584_2400P50: Int = 171
//            const val RES_3584_2400P60: Int = 172
//            const val RES_2400_3584P24: Int = 173
//            const val RES_2400_3584P25: Int = 174
//            const val RES_2400_3584P30: Int = 175
//            const val RES_2400_3584P50: Int = 176
//            const val RES_2400_3584P60: Int = 177
//            const val RES_2880_1440P24: Int = 178
//            const val RES_2880_1440P25: Int = 179
//            const val RES_2880_1440P30: Int = 180
//            const val RES_2880_1440P50: Int = 181
//            const val RES_2880_1440P60: Int = 182
//            const val RES_1440_2880P24: Int = 183
//            const val RES_1440_2880P25: Int = 184
//            const val RES_1440_2880P30: Int = 185
//            const val RES_1440_2880P50: Int = 186
//            const val RES_1440_2880P60: Int = 187
//            const val RES_2944_2944P30: Int = 188
//            const val RES_2944_2944P25: Int = 189
//            const val RES_2944_2944P24: Int = 190
//            const val RES_3584_2016P30: Int = 192
//            const val RES_3584_2016P25: Int = 193
//            const val RES_3584_2016P24: Int = 194
//            const val RES_2016_3584P30: Int = 195
//            const val RES_2016_3584P25: Int = 196
//            const val RES_2016_3584P24: Int = 197
//            const val RES_2880_720P30: Int = 198 //x3 自拍预览
//            const val RES_3584_2016P50: Int = 199
//            const val RES_3584_2016P60: Int = 200
//            const val RES_2016_3584P50: Int = 201
//            const val RES_2016_3584P60: Int = 202
//            const val RES_3840_2880P30: Int = 203
//            const val RES_3840_2880P25: Int = 204
//            const val RES_3840_2880P24: Int = 205
//            const val RES_2880_1440P48: Int = 206
//            const val RES_1440_2880P48: Int = 207
//            const val RES_3840_1920P48: Int = 208
//            const val RES_640_640P30: Int = 209
//            const val RES_7680_4320P24: Int = 210
//            const val RES_7680_4320P25: Int = 211
//            const val RES_7680_3268P25: Int = 212
//            const val RES_7680_3268P30: Int = 213
//            const val RES_3840_2160P120: Int = 214
//            const val RES_2720_2040P60: Int = 215
//            const val RES_2720_2040P50: Int = 216
//            const val RES_2720_1530P120: Int = 217
//            const val RES_1920_1440P50: Int = 218
//            const val RES_7680_3268P24: Int = 219
//            const val RES_3840_2160P100: Int = 220
//            const val RES_2560_1440P1: Int = 221
//            const val RES_1440_2560P1: Int = 222
//            const val RES_2560_1440P2: Int = 223
//            const val RES_1440_2560P2: Int = 224
//            const val RES_2560_1440P5: Int = 225
//            const val RES_1440_2560P5: Int = 226
//            const val RES_2560_1440P15: Int = 227
//            const val RES_1440_2560P15: Int = 228
//        }
//
//        object ButtonPressMode {
//            const val DO_NOT_CHANGE: Int = 0
//
//            // 无
//            const val DO_NOTHING: Int = 1
//            const val SHUT_DOWN: Int = 2
//            const val TAKE_PICTURE: Int = 3
//            const val CAPTURE: Int = 4
//
//            // self take picture in time set
//            const val SELFTIMER: Int = 5
//
//            // 旧的timelapse, 根据output_type 判断是拍摄video 还是照片序列。[DEPRECATED, 为了兼容保留]
//            //public static final int TIMELAPSE = 6;
//            const val HIGH_FRAME_RATE: Int = 7
//
//            // 延时摄影
//            const val ACTION_TIMELAPSE_VIDEO: Int = 8
//
//            // 间隔拍摄照片序列
//            const val INTERVAL_SHOOTING: Int = 9
//
//            //间隔录像
//            const val ACTION_INTERVAL_VIDEO: Int = 10
//
//            //hdr拍摄
//            const val TAKE_HDR_IMAGE: Int = 11
//
//            //定位延时摄影
//            const val ACTION_STATIC_TIMELAPSE: Int = 12
//
//            // 陀螺仪校正
//            const val ACTION_CALIBRATE_GYRO: Int = 13
//
//            //hdr录像
//            const val ACTION_HDR_CAPTURE: Int = 14
//
//            //移动延时
//            const val ACTION_TIMESHIFT: Int = 15
//
//            //burst拍照
//            const val TAKE_BURST_IMAGE: Int = 16
//
//            //超级夜景
//            const val TAKE_AEB_NIGHT_IMAGE: Int = 17
//
//            //超级录像
//            const val SUPER_CAPTURE: Int = 18
//
//            // 循环录像
//            const val ACTION_LOOPRECORDING: Int = 19
//
//            // 星空模式拍照
//            const val TAKE_STARLAPSE_IMAGE: Int = 20
//
//            // FPV模式
//            const val FPV_RECORDING: Int = 21
//
//            // 电影模式
//            const val MOVIE_RECORDING: Int = 22
//
//            // 慢动作模式
//            const val SLOW_MOTION_RECORDING: Int = 23
//
//            // X3 自拍录像
//            const val SELFIE_RECORDING: Int = 24
//
//            // 按键功能跟随盒子
//            const val FOLLOW_CHARGEBOX: Int = 25
//
//            // PURE_VIDEO
//            const val PURE_VIDEO: Int = 26
//        }
//
//        object ButtonPressType {
//            // 单击， 默认拍照
//            const val CLICK: Int = 0
//
//            // 双击， 默认录像
//            const val DOUBLE_CLICK: Int = 1
//
//            // 三击
//            const val TRIPLE_CLICK: Int = 2
//
//            // 长按，默认关机
//            const val LONG_PRESS: Int = 3
//
//            // 相机关机时单击
//            const val SHUTDOWN_CLICK: Int = 4
//
//            // 相机关机时双击
//            const val SHUTDOWN_DOUBLE_CLICK: Int = 5
//
//            // 相机关机时三击
//            const val SHUTDOWN_TRIPLE_CLICK: Int = 6
//
//            // 相机关机时长按
//            const val SHUTDOWN_LONG_PRESS: Int = 7
//        }
//
//        object ButtonFollowMode {
//            const val FOLLOW_UNKNOWN: Int = 0
//
//            // 全部跟随
//            const val FOLLOW_FULL: Int = 1
//
//            // 仅跟随参数
//            const val FOLLOW_PARM: Int = 2
//
//            // 仅跟随模式 枚举占位-不支持-等同全跟随
//            const val FOLLOW_MODE: Int = 3
//
//            // 不跟随
//            const val FOLLOW_NONE: Int = 4
//        }
//
//        object PhotoSize {
//            const val Size_6912_3456: Int = 0
//            const val Size_6272_3136: Int = 1
//            const val Size_6080_3040: Int = 2
//            const val Size_4000_3000: Int = 3 //(4:3)
//            const val Size_4000_2250: Int = 4 //(16:9)
//            const val Size_5212_3542: Int = 5 //(3:2)
//            const val Size_5312_2988: Int = 6 //(16:9)
//            const val Size_8000_6000: Int = 7
//            const val Size_8000_4500: Int = 8
//            const val Size_2976_2976: Int = 9
//            const val Size_5984_5984: Int = 10
//            const val Size_11968_5984: Int = 11
//            const val Size_5952_2976: Int = 12
//            const val Size_4096_3072: Int = 19
//        }
//
//        object AccFullScaleRange {
//            const val RANGE_2G: Int = 0
//            const val RANGE_4G: Int = 1
//            const val RANGE_8G: Int = 2
//            const val RANGE_16G: Int = 3
//        }
//
//        object GyroFullScaleRange {
//            const val RANGE_250DPS: Int = 0
//            const val RANGE_500DPS: Int = 1
//            const val RANGE_1000DPS: Int = 2
//            const val RANGE_2000DPS: Int = 3
//        }
//
//        object WifiStatus {
//            const val AUTO: Int = 0
//            const val ON: Int = 1
//        }
//
//        object EVOStatusMode {
//            /**
//             * not vr180 picture
//             */
//            const val DEGREE_NONE: Int = 0
//            const val DEGREE180: Int = 1
//            const val DEGREE360: Int = 2
//        }
//
//        object BTRemoteType {
//            /**
//             * not vr180 picture
//             */
//            const val UNKNOWN_BT_REMOTE: Int = 0
//            const val BT_REMOTE_WITHOUT_GPS: Int = 1
//            const val BT_REMOTE_WITH_GPS: Int = 2
//        }
//
//        /**
//         * 5.7k frame quality
//         */
//        object QualitySetting {
//            const val HIGH_QUALITY: Int = 0
//            const val LOW_QUALITY: Int = 1
//        }
//
//        object VideoEncodeType {
//            const val ENCODE_H264: Int = 0
//            const val ENCODE_H265: Int = 1
//        }
//
//        /**
//         * go 修改频率
//         */
//        object ImageFlickerType {
//            const val IMAGE_FLICKER_AUTO: Int = 0
//            const val IMAGE_FLICKER_60HZ: Int = 1
//            const val IMAGE_FLICKER_50HZ: Int = 2
//        }
//
//        object GammaMode {
//            const val STANDARD: Int = 0
//            const val LOG: Int = 1
//            const val VIVID: Int = 2
//            const val FLAT: Int = 3
//            const val URBAN_1: Int = 4
//            const val URBAN_2: Int = 5
//            const val OCEANBLUE_1: Int = 6
//            const val OCEANBLUE_2: Int = 7
//            const val SNOW_1: Int = 8
//            const val SNOW_2: Int = 9
//            const val BIKING_1: Int = 10
//            const val BIKING_2: Int = 11
//            const val NIGHTLIGHT_1: Int = 12
//            const val NIGHTLIGHT_2: Int = 13
//            const val PORTRAIT: Int = 14
//            const val LEICA_1: Int = 15
//            const val LEICA_2: Int = 16
//            const val FILM: Int = 17
//            const val VINTAGE: Int = 18
//            const val URBAN: Int = 19
//            const val NIGHT: Int = 20
//        }
//
//        object ExpectOutputType {
//            const val DEFAULT: Int = 0
//            const val INSTA_PANO: Int = 1
//            const val MULTI_CAMERA: Int = 2
//            const val ONE_TAKE: Int = 3
//        }
//
//        object ChargeboxConnectedType {
//            const val DISCONNECTED: Int = 0
//            const val CONNECTED: Int = 1
//        }
//
//        object ChargeboxUsbBtConnectedType {
//            const val USB_BT_STATUS_UNDEFINED: Int = 0
//            const val USB_BT_STATUS_DISCONNECTED: Int = 1
//            const val USB_BT_STATUS_CONNECTED: Int = 2
//        }
//
//        object HwType {
//            const val HW_TYPE_UNKNOWN: Int = 0
//            const val HW_TYPE_MFI: Int = 1
//            const val HW_TYPE_NO_MFI: Int = 2
//        }
//
//        object SensorType {
//            const val PANO_577: Int = 0
//            const val WIDE_577: Int = 1
//            const val WIDE_283: Int = 2
//            const val WIDE_586: Int = 3
//            const val AF_586: Int = 4
//            const val PANO_283: Int = 5
//            const val PANO_586: Int = 6
//            const val ACTION_577: Int = 7
//        }
//
//        object LanguageType {
//            const val EN: Int = 0
//            const val ZH: Int = 1
//            const val JA: Int = 2
//        }
//
//        object BatteryType {
//            const val THICK: Int = 0
//            const val THIN: Int = 1
//            const val VERTICAL: Int = 2
//            const val NONE: Int = 100 // 未插电池只有USB供电的情况
//        }
//
//        object OffsetState {
//            // 无外置镜
//            const val COMMON: Int = 0
//
//            // 黏贴式球面镜
//            const val SPHERE_PROTECT: Int = 1
//
//            // 潜水壳水下
//            const val DIVING_WATER: Int = 2
//
//            // 23年新潜水壳水下
//            const val DIVING_WATER_23: Int = 3
//
//            // X4 A级保护镜
//            const val PROTECT_A: Int = 4
//
//            // X4 S级保护镜
//            const val PROTECT_S: Int = 5
//
//            // X4 自动识别
//            const val PROTECT_AUTO: Int = 6
//
//            // A3 ND16
//            const val FILTER_ND16: Int = 7
//
//            // A3 ND32
//            const val FILTER_ND32: Int = 8
//
//            // A3 ND64
//            const val FILTER_ND64: Int = 9
//        }
//
//        object OffsetDetectedType {
//            const val UNKNOWN: Int = 0
//            const val AUTO_A: Int = 1
//            const val AUTO_S: Int = 2
//            const val AUTO_OFF: Int = 3
//            const val AUTO_AS: Int = 4
//        }
//
//        object HeatShellType {
//            const val NONE: Int = 0
//            const val STANDARD: Int = 1
//        }
//
//        object CameraPostureType {
//            const val CAMERA_POSTURE_ROTATE_0: Int = 0
//            const val CAMERA_POSTURE_ROTATE_90: Int = 1
//            const val CAMERA_POSTURE_ROTATE_180: Int = 2
//            const val CAMERA_POSTURE_ROTATE_270: Int = 3
//            const val CAMERA_POSTURE_UP: Int = 4
//            const val CAMERA_POSTURE_DOWN: Int = 5
//        }
//
//        object BtWakeupSwState {
//            const val BT_WAKEUP_SW_OFF: Int = 0
//            const val BT_WAKEUP_SW_ON: Int = 1
//            const val BT_WAKEUP_SW_UNKNOWN: Int = 2
//        }
    }
//
//    /**
//     * [OneDriver.getPhotographyOptionsAsync]
//     */
////    object PhotographyOptions {
////        const val CHANNEL: String = "channel"
////        const val BRIGHTNESS: String = "brightness"
////        const val CONTRAST: String = "contrast"
////        const val SATURATION: String = "saturation"
////        const val HUE: String = "hue"
////        const val SHARPNESS: String = "sharpness"
////        const val EXPOSURE_BIAS: String = "exposure_bias"
////        const val EXPOSURE_MODE: String = "exposure_mode"
////        const val EXPOSURE_PROG: String = "exposure_prog-mode"
////        const val EXPOSURE_MANUAL: String = "exposure_manual-relate_mode"
////        const val AE_METER_MODE: String = "meter_mode"
////        const val AE_MANUAL_METER_WEIGHT: String = "manual_meter_weights"
////        const val WHITE_BALANCE: String = "white_balance"
////        const val WHITE_BALANCE_VALUE: String = "white_balance_value"
////        const val FLICKER: String = "flicker"
////        const val EV_INDEX: String = "ev_index"
////        const val LOG_MODE_ENABLE: String = "log_mode_enable"
////        const val LONG_EXPOSURE_MANUAL: String = "long_exposure_manual"
////        const val STILL_EXPOSURE_OPTIONS: String = "still_exposure_options-program"
////        const val STILL_EXPOSURE_OPTIONS_ISO: String = "still_exposure_options-iso"
////        const val STILL_EXPOSURE_OPTIONS_SHUTTER: String = "still_exposure_options-shutter"
////        const val VIDEO_EXPOSURE_OPTIONS: String = "video_exposure_options-program"
////        const val VIDEO_EXPOSURE_OPTIONS_ISO: String = "video_exposure_options-iso"
////        const val VIDEO_EXPOSURE_OPTIONS_SHUTTER: String = "video_exposure_options-shutter"
////        const val LAPSE_TIME: String = "lapse_time"
////        const val PREVIEW_MCTF_ENABLE: String = "preview_mctf_enable"
////        const val PREVIEW_SPORT_MODE_ENABLE: String = "preview_sport_mode_enable"
////        const val VIDEO_ISO_TOP_LIMIT: String = "video_iso_top_limit"
////        const val RAW_CAPTURE_TYPE: String = "raw_capture_type"
////        const val PHOTOGRAPHY_SELF_TIMER: String = "photo_self_timer"
////        const val AEB_CAPTURE_NUM: String = "aeb_capture_num"
////        const val PREVIEW_SPORT_LEVEL: String = "preview_sport_level"
////        const val RECORD_DURAION: String = "record_duration"
////        const val PHOTO_SIZE_ID: String = "photo_size_id"
////        const val RECORD_RESOLUTION: String = "record_resolution"
////        const val PHOTO_RESOLUTION: String = "photo_resolution"
////        const val FOV_TYPE: String = "fov_type"
////        const val PHOTO_GRAPHY_BITRATE: String = "video_bitrate"
////        const val FLOWSTATE_ENABLE: String = "flowstate_enable"
////        const val FLOWSTATE_VIDEO_ENABLE: String = "flowstate_video_enable"
////        const val DOUBLE_ZOOM: String = "double_zoom"
////        const val FLOWSTATE_LEVEL: String = "flowstate_level"
////        const val FLOWSTATE_LEVEL_BY_CV5: String = "flow_state_level_by_cv5"
////        const val STARLAPSE_EXPORT_TYPE: String = "starlapse_export_type"
////        const val COLOR_MODE: String = "color_mode"
////        const val RES_REC_LIMIT: String = "limit_time"
////        const val ACCELERATE_FREQUENCY: String = "accelerate_frequency"
////        const val FOCAL_LENGTH_VALUE: String = "focal_length_value"
////        const val REMAINING_TIME: String = "remaining_time"
////        const val DARK_EIS_ENABLE: String = "dark_eis_enable"
////        const val BURST_CAPTURE_NUM: String = "burst_capture_num"
////        const val CACHE_CAPTURE_NUM: String = "cache_capture_num"
////        const val METERING_ENABLE: String = "metering_enable"
////        const val BURST_CAPTURE_TIME: String = "burst_capture_time"
////        const val CACHE_CAPTURE_ENABLE: String = "cache_capture_enable"
////        const val ZOOM_SCALE: String = "zoom_scale"
////        const val MAX_REC_TIME: String = "max_rec_time"
////        const val PANO_EXPOSURE_MODE: String = "pano_exposure_mode"
////        const val VIDEO_SELFIE_MODE: String = "video_selfie_mode"
////
////        // HDR开关状态 63
////        const val HDR_SWITCH_STATUS: String = "hdr_switch_status"
////        const val FLOWSTATE_HORIZON_ENABLE: String = "flowstate_horizon_enable"
////        const val I_LOG_SWITCH: String = "i_log_switch"
////        const val COLOR_RECOVERY_SWITCH: String = "color_recovery_switch"
////        const val FACE_OPTIMIZE_MODE: String = "face_optimize_mode"
////        const val RENDER_VLP_EULER: String = "render_vlp_euler"
////        const val RENDER_VLP_FOV: String = "render_vlp_fov"
////        const val RENDER_VLP_RES: String = "render_vlp_res"
////        const val RENDER_VLP_QUAT: String = "render_vlp_quat"
////        const val RENDER_DISTORTION_CORRECTION: String = "render_distortion_correction"
////        const val RENDER_VLP_ACTION: String = "render_vlp_action"
////        const val RENDER_VLP_CENTER_POTION: String = "render_vlp_center_potion"
////        const val PHOTO_HDR_TYPE: String = "photo_hdr_type"
////        const val PURE_VIDEO_ENHANC_TYPE: String = "pure_video_enhance_type"
////        const val RENDER_VLP_ZOOM: String = "ptz_fov_factor"
////        const val TRACK_RESET: String = "track_reset"
////        const val P3_SWITCH: String = "p3_switch"
////        const val P3_EXTEND_PARAM: String = "p3_extend_param"
////        const val LIVEPHOTO_MODE: String = "LIVEPHOTO_MODE"
////        const val MACROLENS_SWITCH: String = "macrolens_switch"
////    }
//
//    object ButtonPressParamsOptions {
//        // 录像分辨率
//        const val BUTTON_PARAM_RECORD_RESOLUTION: String = "button_param_record_resolution"
//
//        // 拍射间隔时间
//        const val BUTTON_PARAM_LAPSE_TIME: String = "button_param_lapse_time"
//
//        const val REC_LIMIT_TIME: String = "rec_limit_time"
//    }
//
//    /**
//     * setMultiVideoMode
//     * getMultiVideoMode
//     */
//    object MultiVideoOptions {
//        const val RESOLUTION_RECORD: String = "resolution"
//        const val PHOTOGRAPHY_INTERNAL_FLOWSTATE: String = "photography_flowstate"
//        const val DIMENSION_TYPE: String = "dimension_type"
//        const val VISION_TYPE: String = "vision_type"
//
//
//        object DimensionType {
//            const val DIMENSION_TYPE_HORIZONTAL: Int = 0
//            const val DIMENSION_TYPE_VERTICAL: Int = 1
//        }
//
//        object VisionType {
//            const val VISION_FOV_WIDE: Int = 0
//            const val VISION_FOV_LINEAR: Int = 1
//            const val VISION_FOV_ULTRAWIDE: Int = 2
//            const val VISION_FOV_NARROW: Int = 3
//            const val VISION_FOV_POV: Int = 4
//            const val VISION_FOV_LINEARPLUS: Int = 5
//            const val VISION_FOV_LINEARHORIZON: Int = 6
//            const val VISION_FOV_FPV: Int = 7
//            const val VISION_TYPE_TYPE_SUPER: Int = 8
//            const val VISION_TYPE_TYPE_TINYPLANET: Int = 9
//            const val VISION_TYPE_TYPE_INFINITYWIDE: Int = 10 //极广角
//        }
//    }
//
//    /**
//     * used to get Photo configuration of camera,every [FunctionMode] has it own photo options
//     * [OneDriver.getPhotographyOptionsAsync]
//     * [OneDriver.setPhotographyOptionsAsync]
//     */
//    class PhotoOptionsConstants {
//        /**
//         * function mode type
//         */
//        object FunctionMode {
//            //take piture and record
//            const val FUNCMODE_NORMAL: Int = 0
//
//            //preview
//            const val FUNCMODE_LIVE_STREAM: Int = 1
//
//            // timelapse video
//            const val FUNCMODE_TIMELAPSE: Int = 2
//
//            //interval shooting(timelapse picture)
//            const val FUNCMODE_INTERVAL_SHOOTING: Int = 3
//
//            //high frame rate
//            const val FUNCMODE_HIGH_FRAME_RATE: Int = 4
//
//            // burst
//            const val FUNCTION_MODE_BURST: Int = 5
//
//            // 普通拍照
//            const val FUNCTION_MODE_NORMAL_IMAGE: Int = 6
//
//            // 普通录像
//            const val FUNCTION_MODE_NORMAL_VIDEO: Int = 7
//
//            // HDR拍照
//            const val FUNCTION_MODE_HDR_IMAGE: Int = 8
//
//            // HDR录像
//            const val FUNCTION_MODE_HDR_VIDEO: Int = 9
//
//            // 间隔录像
//            const val FUNCTION_MODE_INTERVAL_VIDEO: Int = 10
//
//            //定位延时摄影
//            const val FUNCTION_MODE_STATIC_TIMELAPSE: Int = 11
//
//            //timeshift
//            const val FUNCTION_MODE_TIMESHIFT: Int = 12
//
//            //night shoot
//            const val FUNCTION_MODE_AEB_NIGHT_IMAGE: Int = 13
//
//            //normal power pano image
//            const val FUNCTION_MODE_NORMAL_POWER_PANO_IMAGE: Int = 14
//
//            //hdr power pano image
//            const val FUNCTION_MODE_HDR_POWER_PANO_IMAGE: Int = 15
//
//            //super video
//            const val FUNCTION_MODE_SUPER_VIDEO: Int = 16
//
//            // 循环录像Loop Recording
//            const val FUNCTION_MODE_LOOP_RECORDING_VIDEO: Int = 17
//
//            // 星空模式拍照
//            const val FUNCTION_MODE_STARLAPSE_IMAGE: Int = 18
//
//            // FPV录像
//            const val FUNCTION_MODE_FPV_VIDEO: Int = 19
//
//            // 电影模式
//            const val FUNCTION_MODE_MOVIE_VIDEO: Int = 20
//
//            // 慢动作模式
//            const val FUNCTION_MODE_SLOWMOTION_VIDEO: Int = 21
//
//            // X3 自拍录像
//            const val FUNCTION_MODE_SELFIE_VIDEO: Int = 22
//
//            //GO3 QC 单击
//            const val FUNCTION_MODE_QC_SINGLE_PRESS: Int = 23
//
//            //GO3 QC 双击
//            const val FUNCTION_MODE_QC_DOUBLE_PRESS: Int = 24
//
//            //GO3 单主机 单击
//            const val FUNCTION_MODE_CAMERA_SINGLE_PRESS: Int = 25
//
//            //GO3 单主机 双击
//            const val FUNCTION_MODE_CAMERA_DOUBLE_PRESS: Int = 26
//
//            //PureVideo
//            const val FUNCTION_MODE_PURE_VIDEO: Int = 27
//
//            const val FUNCTION_MODE_DASH_CAM: Int = 63
//
//            //虚拟云台
//            const val FUNCTION_MODE_PTZ: Int = 64
//
//            // 蚊子视角
//            const val FUNCTION_MODE_MOSQUITO: Int = 65
//        }
//
//        object AEMeterMode {
//            const val AE_METER_MODE_NORMAL: Int = 0
//            const val AE_METER_MODE_MANUAL: Int = 1
//        }
//
//        object WhiteBalance {
//            const val WB_AUTO: Int = 0
//            const val WB_2700K: Int = 1
//            const val WB_4000K: Int = 2
//            const val WB_5000K: Int = 3
//            const val WB_6500K: Int = 4
//            const val WB_7500K: Int = 5
//        }
//
//        object Flicker {
//            const val FLICKER_AUTO: Int = 0
//            const val FLICKER_60HZ: Int = 1
//            const val FLICKER_50HZ: Int = 2
//        }
//
//        //still ExposureOptions and video ExposureOptions
//        object Program {
//            const val AUTO: Int = 0
//            const val ISO_PRIORITY: Int = 1
//            const val SHUTTER_PRIORITY: Int = 2
//            const val MANUAL: Int = 3
//            const val ADAPTIVE: Int = 4
//            const val FULL_AUTO: Int = 5
//        }
//
//        object RawCaptureType {
//            const val RAW_CAPTURE_OFF: Int = 0
//            const val RAW_CAPTURE_DNG: Int = 1
//            const val RAW_CAPTURE_RAW: Int = 2 //not support yet = 0;
//            const val RAW_CAPTURE_PURESHOT: Int = 3
//            const val RAW_CAPTURE_PURESHOT_RAW: Int = 4
//            const val RAW_CAPTURE_INSP: Int = 5
//            const val RAW_CAPTURE_INSP_RAW: Int = 6
//        }
//
//        object FlowStateLevel {
//            const val FLOW_STATE_LEVEL_CLOSE: Int = 0
//            const val FLOW_STATE_LEVEL_LOW: Int = 1
//            const val FLOW_STATE_LEVEL_STANDARD: Int = 2
//            const val FLOW_STATE_LEVEL_HIGH: Int = 3
//        }
//
//        object FlowStateLevelByCv5 {
//            const val FLOW_STATE_LEVEL_Cv5_CLOSE: Int = 0
//            const val FLOW_STATE_LEVEL_Cv5_SLIGHT: Int = 1
//            const val FLOW_STATE_LEVEL_Cv5_GENERAL: Int = 2
//            const val FLOW_STATE_LEVEL_Cv5_STRONG: Int = 3
//        }
//
//        object FlowStateHorizonType {
//            const val FLOW_STATE_HORIZON_DISABLE: Int = 0
//            const val FLOW_STATE_HORIZON_ENABLE: Int = 1
//            const val FLOW_STATE_HORIZON_AUTO: Int = 2
//        }
//
//        object PanoExposureMode {
//            const val PANO_EXPOSURE_MODE_OFF: Int = 0
//            const val PANO_EXPOSURE_MODE_LIGHT: Int = 1
//            const val PANO_EXPOSURE_MODE_LSOLATED: Int = 2
//        }
//
//        object PREVIEW_SPORT_LEVEL {
//            const val PREVIEW_SPORT_AUTO: Int = 0
//            const val PREVIEW_SPORT_FAST: Int = 1
//            const val PREVIEW_SPORT_FASTER: Int = 2
//        }
//
//        object VideoResolution {
//            const val RES_3840_1920P30: Int = 0
//            const val RES_2560_1280P30: Int = 1
//            const val RES_1920_960P30: Int = 2
//            const val RES_2560_1280P60: Int = 3
//            const val RES_2048_512P120: Int = 4
//            const val RES_3328_832P60: Int = 5
//            const val RES_3072_1536P30: Int = 6
//            const val RES_2240_1120P30: Int = 7
//            const val RES_2240_1120P24: Int = 8
//            const val RES_1440_720P30: Int = 9
//            const val RES_2880_2880P30: Int = 10
//            const val RES_3840_1920P60: Int = 11
//            const val RES_3840_1920P50: Int = 12
//            const val RES_3008_1504P100: Int = 13
//            const val RES_960_480P30: Int = 14
//            const val RES_3040_1520P30: Int = 15
//            const val RES_2176_1088P30: Int = 16
//            const val RES_720_360P30: Int = 17
//            const val RES_480_240P30: Int = 18
//            const val RES_2880_2880P25: Int = 19
//            const val RES_2880_2880P24: Int = 20
//            const val RES_3840_1920P20: Int = 21
//            const val RES_1920_960P20: Int = 22
//            const val RES_3840_2160p60: Int = 23
//            const val RES_3840_2160p30: Int = 24
//            const val RES_2720_1530p100: Int = 25
//            const val RES_1920_1080p200: Int = 26
//            const val RES_1920_1080p240: Int = 27
//            const val RES_1920_1080p120: Int = 28
//            const val RES_1920_1080p30: Int = 29
//            const val RES_5472_3078p30: Int = 30
//            const val RES_4000_3000p30: Int = 31
//            const val RES_854_640P30: Int = 32
//            const val RES_720_406P30: Int = 33
//            const val RES_424_240P15: Int = 34
//            const val RES_1024_512P30: Int = 35
//            const val RES_640_320P30: Int = 36
//            const val RES_5312_2988P30: Int = 37
//            const val RES_2720_1530P60: Int = 38
//            const val RES_2720_1530P30: Int = 39
//            const val RES_1920_1080P60: Int = 40
//            const val RES_2720_2040P30: Int = 41
//            const val RES_1920_1440P30: Int = 42
//            const val RES_1280_720P30: Int = 43
//            const val RES_1280_960P30: Int = 44
//            const val RES_1152_768P30: Int = 45
//            const val RES_5312_2988P25: Int = 46
//            const val RES_5312_2988P24: Int = 47
//            const val RES_3840_2160P25: Int = 48
//            const val RES_3840_2160P24: Int = 49
//            const val RES_2720_1530P25: Int = 50
//            const val RES_2720_1530P24: Int = 51
//            const val RES_1920_1080P25: Int = 52
//            const val RES_1920_1080P24: Int = 53
//            const val RES_4000_3000P25: Int = 54
//            const val RES_4000_3000P24: Int = 55
//            const val RES_2720_2040P25: Int = 56
//            const val RES_2720_2040P24: Int = 57
//            const val RES_1920_1440P25: Int = 58
//            const val RES_1920_1440P24: Int = 59
//
//            //x2
//            const val RES_2560_1440P30: Int = 60
//            const val RES_2560_1440P60: Int = 61
//            const val RES_1920_1440P60: Int = 62
//            const val RES_1440_2560P30: Int = 63
//            const val RES_1080_1920P30: Int = 64
//            const val RES_1440_1920P30: Int = 65
//            const val RES_1440_2560P60: Int = 66
//            const val RES_1440_1920P60: Int = 67
//            const val RES_1080_1920P60: Int = 68
//            const val RES_2560_1440P25: Int = 69
//            const val RES_1440_2560P25: Int = 70
//            const val RES_1080_1920P25: Int = 71
//            const val RES_720_1280P30: Int = 72 //Second Stream
//            const val RES_960_1280P30: Int = 73 //Second Stream
//            const val RES_1152_1152P30: Int = 74 //Second Stream
//            const val RES_640_360P30: Int = 75 //Second Stream
//            const val RES_640_480P30: Int = 76 //Second Stream
//            const val RES_360_640P30: Int = 77 //Second Stream
//            const val RES_480_640P30: Int = 78 //Second Stream
//            const val RES_368_368P30: Int = 79 //Second Stream
//            const val RES_854_854P30: Int = 80 //go2
//            const val RES_1920_1080P50: Int = 81 //onex2 / go2
//            const val RES_1080_1920P50: Int = 82 //onex2 / go2
//            const val RES_2560_1440P50: Int = 83 //onex2 / go2
//            const val RES_1440_2560P50: Int = 84 //onex2 /go2
//            const val RES_1080_1920P24: Int = 85 //onex2 / go2
//            const val RES_2560_1440P24: Int = 86 //onex2 /go2
//            const val RES_1440_2560P24: Int = 87 //onex2 /go2
//            const val RES_1080_1920P120: Int = 88 //onex2
//            const val RES_1280_1280P30: Int = 89 //go2
//            const val RES_2880_2880P15: Int = 90 //x2
//            const val RES_1440_720P15: Int = 91 //x2
//            const val RES_3840_2160P50: Int = 92 //oneR/RS
//
//            //rs
//            const val RES_1280_1280P25: Int = 93 // oneR/RS
//            const val RES_3040_3040P24: Int = 94
//            const val RES_3040_3040P25: Int = 95
//            const val RES_3040_3040P30: Int = 96
//            const val RES_3840_1920P24: Int = 97
//            const val RES_3840_1920P25: Int = 98
//            const val RES_3040_1520P50: Int = 99
//            const val RES_2720_1530P50: Int = 100
//            const val RES_5312_3552P24: Int = 101
//            const val RES_5312_3552P25: Int = 102
//            const val RES_5312_3552P30: Int = 103
//            const val RES_5472_2328P24: Int = 104
//            const val RES_5472_2328P25: Int = 105
//            const val RES_5472_2328P30: Int = 106
//            const val RES_1600_900P30: Int = 107
//            const val RES_1760_990P30: Int = 108
//            const val RES_3840_1634P30: Int = 109
//            const val RES_3840_1634P25: Int = 110
//            const val RES_3840_1634P24: Int = 111
//            const val RES_6720_2856P25: Int = 112
//            const val RES_6720_2856P24: Int = 113
//            const val RES_6016_2560P25: Int = 114
//            const val RES_6016_2560P24: Int = 115
//            const val RES_3200_3200P24: Int = 116
//            const val RES_3200_3200P25: Int = 117
//            const val RES_3200_3200P30: Int = 118
//            const val RES_3072_3072P24: Int = 119
//            const val RES_3072_3072P25: Int = 120
//            const val RES_3072_3072P30: Int = 121
//            const val RES_2160_3840P60: Int = 122
//            const val RES_2160_3840P50: Int = 123
//            const val RES_2160_3840P30: Int = 124
//            const val RES_2160_3840P25: Int = 125
//            const val RES_2160_3840P24: Int = 126
//            const val RES_3000_1500P120: Int = 131
//            const val RES_1530_2720P60: Int = 132
//            const val RES_1530_2720P50: Int = 133
//            const val RES_1530_2720P30: Int = 134
//            const val RES_1530_2720P25: Int = 135
//            const val RES_1530_2720P24: Int = 136
//            const val RES_3840_960P120: Int = 137
//            const val RES_1152_648P30: Int = 138
//            const val RES_648_1152P30: Int = 139
//            const val RES_1152_864P30: Int = 140
//            const val RES_864_1152P30: Int = 141
//            const val RES_2944_2880P30: Int = 142
//            const val RES_3920_1920P30: Int = 143
//            const val RES_1530_2720P100: Int = 149
//            const val RES_1920_1080P100: Int = 150
//            const val RES_1080_1920P100: Int = 151
//            const val RES_4000_3000P50: Int = 152
//            const val RES_4000_3000P60: Int = 153
//            const val RES_7680_4320P30: Int = 154
//            const val RES_2944_736P200: Int = 155
//            const val RES_3456_1944P24: Int = 156
//            const val RES_3456_1944P25: Int = 157
//            const val RES_3456_1944P30: Int = 158
//            const val RES_3456_1944P50: Int = 159
//            const val RES_3456_1944P60: Int = 160
//            const val RES_1944_3456P24: Int = 161
//            const val RES_1944_3456P25: Int = 162
//            const val RES_1944_3456P30: Int = 163
//            const val RES_2944_736P180: Int = 164
//            const val RES_3840_3840P24: Int = 165
//            const val RES_3840_3840P25: Int = 166
//            const val RES_3840_3840P30: Int = 167
//            const val RES_3584_2400P24: Int = 168
//            const val RES_3584_2400P25: Int = 169
//            const val RES_3584_2400P30: Int = 170
//            const val RES_3584_2400P50: Int = 171
//            const val RES_3584_2400P60: Int = 172
//            const val RES_2400_3584P24: Int = 173
//            const val RES_2400_3584P25: Int = 174
//            const val RES_2400_3584P30: Int = 175
//            const val RES_2400_3584P50: Int = 176
//            const val RES_2400_3584P60: Int = 177
//            const val RES_2880_1440P24: Int = 178
//            const val RES_2880_1440P25: Int = 179
//            const val RES_2880_1440P30: Int = 180
//            const val RES_2880_1440P50: Int = 181
//            const val RES_2880_1440P60: Int = 182
//            const val RES_1440_2880P24: Int = 183
//            const val RES_1440_2880P25: Int = 184
//            const val RES_1440_2880P30: Int = 185
//            const val RES_1440_2880P50: Int = 186
//            const val RES_1440_2880P60: Int = 187
//            const val RES_2944_2944P30: Int = 188
//            const val RES_2944_2944P25: Int = 189
//            const val RES_2944_2944P24: Int = 190
//            const val RES_3584_2016P30: Int = 192
//            const val RES_3584_2016P25: Int = 193
//            const val RES_3584_2016P24: Int = 194
//            const val RES_2016_3584P30: Int = 195
//            const val RES_2016_3584P25: Int = 196
//            const val RES_2016_3584P24: Int = 197
//            const val RES_2880_720P30: Int = 198 //x3 自拍预览
//            const val RES_3584_2016P50: Int = 199
//            const val RES_3584_2016P60: Int = 200
//            const val RES_2016_3584P50: Int = 201
//            const val RES_2016_3584P60: Int = 202
//            const val RES_3840_2880P30: Int = 203
//            const val RES_3840_2880P25: Int = 204
//            const val RES_3840_2880P24: Int = 205
//            const val RES_2880_1440P48: Int = 206
//            const val RES_1440_2880P48: Int = 207
//            const val RES_3840_1920P48: Int = 208
//            const val RES_640_640P30: Int = 209
//            const val RES_7680_4320P24: Int = 210
//            const val RES_7680_4320P25: Int = 211
//            const val RES_7680_3268P25: Int = 212
//            const val RES_7680_3268P30: Int = 213
//            const val RES_3840_2160P120: Int = 214
//            const val RES_2720_2040P60: Int = 215
//            const val RES_2720_2040P50: Int = 216
//            const val RES_2720_1530P120: Int = 217
//            const val RES_1920_1440P50: Int = 218
//            const val RES_7680_3268P24: Int = 219
//            const val RES_3840_2160P100: Int = 220
//            const val RES_2560_1440P1: Int = 221
//            const val RES_1440_2560P1: Int = 222
//            const val RES_2560_1440P2: Int = 223
//            const val RES_1440_2560P2: Int = 224
//            const val RES_2560_1440P5: Int = 225
//            const val RES_1440_2560P5: Int = 226
//            const val RES_2560_1440P15: Int = 227
//            const val RES_1440_2560P15: Int = 228
//        }
//
//        object FovType {
//            const val FOV_TYPE_WIDE: Int = 0
//            const val FOV_TYPE_LINEAR: Int = 1
//            const val FOV_TYPE_ULTRAWIDE: Int = 2
//            const val FOV_TYPE_NARROW: Int = 3
//            const val FOV_TYPE_POV: Int = 4
//            const val FOV_TYPE_LINEARPLUS: Int = 5
//            const val FOV_LINEAR_45HORIZON: Int = 6
//            const val FOV_TYPE_FPV: Int = 7
//            const val FOV_TYPE_SUPER: Int = 8
//            const val FOV_TYPE_TINYPLANET: Int = 9
//            const val FOV_TYPE_INFINITYWIDE: Int = 10 //极广角
//            const val FOV_LINEAR_360HORIZON: Int = 11
//            const val FOV_LINEAR_22HORIZON: Int = 12
//            const val FOV_DEWARP: Int = 13
//            const val FOV_TYPE_MEGA: Int = 14
//            const val FOV_TYPE_TITAN: Int = 15
//            const val FOV_TYPE_SUPER_MICRO: Int = 16
//        }
//
//        object PTZ_FOV {
//            const val VLP_BACK: Int = 0
//            const val VLP_FRONT: Int = 1
//            const val VLP_TOP: Int = 2
//            const val VLP_BOTTOM: Int = 3
//            const val VLP_TRACK: Int = 4
//            const val VLP_ADVANCE: Int = 5
//            const val VLP_FREE: Int = 6
//        }
//
//        object ColorMode {
//            const val NORMAL: Int = 0
//            const val LOG: Int = 1
//            const val VIVID: Int = 2
//            const val HDR: Int = 3
//        }
//
//        object GammaMode {
//            const val STANDARD: Int = 0
//            const val LOG: Int = 1
//            const val VIVID: Int = 2
//            const val FLAT: Int = 3
//            const val URBAN_1: Int = 4
//            const val URBAN_2: Int = 5
//            const val OCEANBLUE_1: Int = 6
//            const val OCEANBLUE_2: Int = 7
//            const val SNOW_1: Int = 8
//            const val SNOW_2: Int = 9
//            const val BIKING_1: Int = 10
//            const val BIKING_2: Int = 11
//            const val NIGHTLIGHT_1: Int = 12
//            const val NIGHTLIGHT_2: Int = 13
//            const val PORTRAIT: Int = 14
//            const val LEICA_1: Int = 15
//            const val LEICA_2: Int = 16
//            const val FILM: Int = 17
//            const val VINTAGE: Int = 18
//            const val URBAN: Int = 19
//            const val NIGHT: Int = 20
//        }
//
//        object StarlapseExportType {
//            const val STARLAPSE_VIDEO: Int = 0
//            const val STAR_TRAILS_VIDEO: Int = 1
//            const val STAR_TRAILS_PHOTO: Int = 2
//        }
//
//        object GimbalActionType {
//            const val UNKNOWN_360: Int = 0
//            const val YAW_360: Int = 1
//            const val ROLL_360: Int = 2
//        } //ExposureProg
//        //        public static class ProgMode
//        //        {
//        //            public static final int PROG_MODE_OFF = 0;
//        //            public static final int PROG_MODE_ISO = 1;
//        //            public static final int PROG_MODE_SHUTTER_SPEED = 2;
//        //        }
//        //        iso = [
//        //                100, 125, 160, 200,  250, 320,
//        //                400, 500, 640, 800, 1000, 1250,
//        //                1600, 2000, 2500, 3200, 4000, 5000,
//        //                6400, 8000, 10000, 12800, 16000, 20000, 25600
//        //                ];
//        //
//        //        shutter_speeds = [
//        //                (MAX_INT32/1000) ... 1, 4/5, 3/5, 1/2, 2/5, 1/3, 1/4,
//        //                1/5/, 4/25, 1/8, 1/10, 2/25, 1/15, 1/20, 1/25, 1/30, 1/40,
//        //                1/50, 1/60, 1/80, 1/100, 1/120, 1/160, 1/200, 1/240, 1/320, 1/400,
//        //                1/500, 1/640, 1/800, 1/1000, 1/1250, 1/1600, 1/2000, 1/2500, 1/3200, 1/4000,
//        //                1/5000, 1/6400, 1/8000
//        //                ]
//    }
//
    /**
     * bluetooth constants
     */
    class BlueToothConstants {
        //        public static final String BLE_FILTER_NAME = "Insta360 ONE";
        object BleError {
            const val BLE_WRITE_ERROR: Int = 401
            const val BLE_NOTIFY_ERROR: Int = 402
            const val BLE_NO_PERMISSION: Int = 403
            const val BLE_READ_RSSI: Int = 404
            const val BLE_DISCONNECT: Int = 501
        }
    }
//
//    object KeyTimePointType {
//        const val INSTANT: Int = 0
//        const val START: Int = 1
//        const val END: Int = 2
//    }
//
//    object MultiVideoMode {
//        const val SINGLE_SCREEN_SIDE: Int = 1
//        const val SINGLE_OFF_SIDE: Int = 2
//        const val DUAL: Int = 3
//    }
//
//    object ChargingBoxType {
//        //刷屏（白色）
//        const val FAC_OLED_TEST: Int = 0
//
//        //刷奇数列
//        const val FAC_OLED_ROW_EVEN: Int = 0x001
//
//        //刷偶数列
//        const val FAC_OLED_ROW_UNEVEN: Int = 0x002
//
//        //刷奇数行
//        const val FAC_OLED_LINE_EVEN: Int = 0x003
//
//        //刷偶数行
//        const val FAC_OLED_LINE_UNEVEN: Int = 0x004
//
//        const val FAC_LED_TEST: Int = 0x005
//
//        const val FAC_DEVLINK_TEST: Int = 0x006
//
//        const val FAC_BUTTON_TEST: Int = 0x007
//
//        //按键测试完成后告诉固件结束按键测试
//        const val FAC_NORMAL_MODE_REFRESH: Int = 0x008
//
//        const val FAC_HALL_TEST: Int = 0x009
//
//        const val FAC_BLUETOOTH_TEST: Int = 0x00A
//
//        const val FAC_BLUETOOTH_WKUP_TEST: Int = 0x00B
//
//        const val FAC_GET_SERIAL: Int = 0x0C
//
//        const val FAC_SET_SERIAL: Int = 0x0D
//
//        const val FAC_VERSION_TEST: Int = 0x0E
//
//        const val FAC_UUID_TEST: Int = 0x0F
//
//        const val FAC_BATTARY: Int = 16
//    }
//
//    object ChargingBoxRespType {
//        //成功
//        const val SUCCESS: Int = 0
//
//        //失败
//        const val FAIL: Int = 1
//
//        //手动确认
//        const val MANUAL: Int = 2
//
//        const val BUTTON_1: Int = 3
//
//        const val BUTTON_2: Int = 4
//    }
//
//    object CameraLiveMode {
//        // 普通直播模式
//        const val LIVE_NORMAL: Int = 0
//
//        // 高清直播模式
//        const val LIVE_HDR: Int = 1
//    }
//
//    /**
//     * get camera configuration by Options
//     * [OneDriver.getCameraLiveOptionsAsync]}
//     * [OneDriver.setCameraLiveOptionsAsync]
//     */
//    object CameraLiveOptions {
//        const val OPTION_RESOLUTION: String = "option_resolution"
//        const val OPTION_ENABLE_AUTO_BITRATE: String = "option_enable_auto_bitrate"
//        const val OPTION_PREFER_VIDEO_BITRATE: String = "option_prefer_video_bitrate"
//        const val OPTION_PREFER_AUDIO_BITRATE: String = "option_prefer_audio_bitrate"
//        const val OPTION_VIDEO_ENCODER: String = "option_video_encoder"
//        const val OPTION_AUDIO_ENCODER: String = "option_audio_encoder"
//        const val OPTION_PLATFORM: String = "option_platform"
//        const val OPTION_RTMP_ADDRESS: String = "option_rtmp_address"
//
//
//        object LiveAutoBitrateSwitch {
//            const val LIVE_AUTO_BITRATE_UNKNOWN: Int = 0
//            const val LIVE_AUTO_BITRATE_DISABLE: Int = 1
//            const val LIVE_AUTO_BITRATE_ENABLE: Int = 2
//        }
//
//        object LiveVideoEncoderType {
//            const val VIDEO_DEFAULT: Int = 0
//            const val VIDEO_H264: Int = 1
//            const val VIDEO_H265: Int = 2
//            const val VIDEO_RAW: Int = 3
//        }
//
//        object LiveAudioEncoderType {
//            const val AUDIO_DEFAULT: Int = 0
//            const val AUDIO_AAC: Int = 1
//        }
//
//        object LivePlatformType {
//            const val LIVE_PLATFORM_NONE: Int = 0
//            const val LIVE_PLATFORM_FACEBOOK: Int = 1
//            const val LIVE_PLATFORM_WECHAT: Int = 2
//            const val LIVE_PLATFORM_WEIBO: Int = 3
//            const val LIVE_PLATFORM_GOOGLE_STREET_VIEW: Int = 4
//            const val LIVE_PLATFORM_QZONE: Int = 5
//            const val LIVE_PLATFORM_YOUTUBE: Int = 6
//            const val LIVE_PLATFORM_KAKAOTALK: Int = 7
//            const val LIVE_PLATFORM_TWITTER: Int = 8
//            const val LIVE_PLATFORM_QQ: Int = 9
//            const val LIVE_PLATFORM_VEER: Int = 10
//            const val LIVE_PLATFORM_KUAISHOU: Int = 11
//            const val LIVE_PLATFORM_DOUYIN: Int = 12
//            const val LIVE_PLATFORM_BILIBILI: Int = 13
//            const val LIVE_PLATFORM_DOUYU: Int = 14
//            const val LIVE_PLATFORM_HUYA: Int = 15
//        }
//    }
//
//    object CameraLiveStatus {
//        const val LIVE_STATUS_IDLE: Int = 0
//        const val LIVE_STATUS_PREPARE: Int = 1
//        const val LIVE_STATUS_STARTING: Int = 2
//        const val LIVE_STATUS_RUNNING: Int = 3
//        const val LIVE_STATUS_STOPPING: Int = 4
//    }
//
//    object CameraLiveErrorCode {
//        const val LIVE_ERROR_NONE: Int = 0 //没有错误
//        const val LIVE_ERROR_NORMAL: Int = 1 //通用错误
//        const val LIVE_ERROR_OVERHEART: Int = 2
//        const val LIVE_ERROR_NETWORK: Int = 3
//        const val LIVE_ERROR_TOKEN_EXPIRED: Int = 4
//        const val LIVE_ERROR_CAMERA_BUSY: Int = 5 //相机处于录像等不支持直播的状态中
//    }
//
//    object P2pTransStatus {
//        const val STATUS_IDLE: Int = 0
//        const val STATUS_TRANSMITING: Int = 1
//    }
//
//    object LivePhotoStatus {
//        const val LIVEPHOTO_NONE: Int = 0 // 无类型
//        const val LIVEPHOTO_OFF: Int = 1 // 关闭状态
//        const val LIVEPHOTO_ON: Int = 2 // 开启状态
//        const val LIVEPHOTO_LOADING: Int = 3 // 设置中
//    }
}
