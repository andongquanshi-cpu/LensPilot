package com.arashivision.onedriver.bean

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class StreamGimbalData {
    // uint64_t
    var timestamp: Long = 0

    // uint8_t
    var status: Long = 0

    // uint32_t
    var id: Long = 0
    var fov: Float = 0f
    var distance: Float = 0f

    // quat[4]
    var quats: FloatArray = FloatArray(4)
    var rect: VlpRect? = null

    // uint8_t
    var trackResult: Long = 0

    // panini模型 融合值
    var alpha: Float = 0f

    fun unpack(data: ByteArray?) {
        if (data == null) {
            Log.e("StreamPtzInfo", "unpack error data is null")
            return
        }
        if (data.size < MIN_DATA_LENGTH) {
            Log.e("StreamPtzInfo", "unpack error length: " + data.size + " < " + MIN_DATA_LENGTH)
            return
        }
        //        Log.d("StreamPtzInfo", "unpack data: "+Arrays.toString(data));
        var offset = 0
        timestamp = FmgByteUtils.uint64ByteArrayToLong(data.sliceArray(offset until (offset + 8).also { offset += 8 }))
        Log.d("StreamPtzInfo", "timestamp=${timestamp}")
        status = FmgByteUtils.uint16ByteArrayToInt(data.sliceArray(offset until (offset + 4).also { offset += 4 })).toLong()
        id = FmgByteUtils.uint32ByteArrayToLong(data.sliceArray(offset until (offset + 4).also { offset += 4 }))
        fov = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))
        distance = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))

        quats[0] = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))
        quats[1] = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))
        quats[2] = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))
        quats[3] = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))

        rect = VlpRect()
        rect!!.unpack(data.sliceArray(offset until (offset + 16).also { offset += 16 }))
        trackResult = FmgByteUtils.uint16ByteArrayToInt(data.sliceArray(offset until (offset + 4).also { offset += 4 })).toLong()
        alpha = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(offset until (offset + 4).also { offset += 4 }))
    }

    class VlpRect {
        var x: Float = 0f
        var y: Float = 0f
        var w: Float = 0f
        var h: Float = 0f

        fun unpack(data: ByteArray?) {
            if (data == null) return
            x = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(0 until 4))
            y = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(4 until 8))
            w = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(8 until 12))
            h = FmgByteUtils.uint32ByteArrayToFloat(data.sliceArray(12 until 16))
        }

    }

    companion object {
        private const val MIN_DATA_LENGTH = 64
    }
}
