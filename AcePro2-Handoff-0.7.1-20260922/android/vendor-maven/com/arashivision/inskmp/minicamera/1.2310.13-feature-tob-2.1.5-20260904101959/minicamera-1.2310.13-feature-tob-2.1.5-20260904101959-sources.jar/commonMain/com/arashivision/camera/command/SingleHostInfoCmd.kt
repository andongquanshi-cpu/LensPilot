package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.SingleHostCmdInfo

class SingleHostInfoCmd(private val singleHostCmdInfo: SingleHostCmdInfo) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setSingleHostCmdInfo(singleHostCmdInfo)
    }
}
