package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzMidcalRespMsg : PtzDataRespMessage() {
    var euler: DoubleArray = DoubleArray(3)

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 20) {
            Log.d("unpack", "error!!!!")
            return
        }
        val doublebytes1 = ByteArray(8)
        val doublebytes2 = ByteArray(8)
        val doublebytes3 = ByteArray(8)
        data.copyInto(doublebytes1, 0, 0, doublebytes1.size)
        data.copyInto(doublebytes2, 0, 8, 8 + doublebytes2.size)
        data.copyInto(doublebytes3, 0, 16, 16 + doublebytes3.size)
        euler[0] = FmgByteUtils.uint64ByteArrayToDouble(doublebytes1)
        euler[1] = FmgByteUtils.uint64ByteArrayToDouble(doublebytes2)
        euler[2] = FmgByteUtils.uint64ByteArrayToDouble(doublebytes3)
    }

    override fun toString(): String {
        return euler.contentToString()
    }

    override fun name(): String {
        return "CMD_MID_CAL"
    }
}
