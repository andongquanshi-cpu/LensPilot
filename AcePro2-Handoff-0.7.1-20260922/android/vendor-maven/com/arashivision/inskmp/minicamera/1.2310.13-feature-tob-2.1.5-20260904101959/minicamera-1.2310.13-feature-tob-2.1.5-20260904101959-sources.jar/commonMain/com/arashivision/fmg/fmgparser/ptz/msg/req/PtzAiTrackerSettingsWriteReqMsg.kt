package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzAiTrackerSettingsWriteReqMsg(private val data: Byte) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val packdata = ByteArray(1)
        packdata[0] = data
        return packdata
    }

    override fun toString(): String {
        return "data: $data"
    }

    override fun name(): String {
        return "CMD_AI_TRACKER_SETTING_WRITE"
    }
}
