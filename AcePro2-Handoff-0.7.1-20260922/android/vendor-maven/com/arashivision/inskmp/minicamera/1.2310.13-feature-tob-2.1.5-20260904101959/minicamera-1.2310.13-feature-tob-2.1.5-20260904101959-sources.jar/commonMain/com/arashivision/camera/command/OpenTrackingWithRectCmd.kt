package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GimbalControl
import insta360.messages.OpenTrackingWithRect

class OpenTrackingWithRectCmd(private val openTrackingWithRect: OpenTrackingWithRect) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.openTrackingWithRect(openTrackingWithRect)
    }
}
