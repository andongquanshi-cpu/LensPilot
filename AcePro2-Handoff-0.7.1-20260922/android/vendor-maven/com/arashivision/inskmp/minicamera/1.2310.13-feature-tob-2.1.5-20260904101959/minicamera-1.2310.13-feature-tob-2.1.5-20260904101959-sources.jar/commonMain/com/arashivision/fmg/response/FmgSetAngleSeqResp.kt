package com.arashivision.fmg.response

class FmgSetAngleSeqResp(var requestID: Long)
