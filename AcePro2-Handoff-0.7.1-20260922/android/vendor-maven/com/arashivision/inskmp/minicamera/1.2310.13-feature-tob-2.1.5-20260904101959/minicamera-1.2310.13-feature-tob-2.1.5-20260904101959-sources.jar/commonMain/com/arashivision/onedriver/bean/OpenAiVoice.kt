package com.arashivision.onedriver.bean

data class OpenAiVoice (
    val sessionId: Long,
    val result: Int
)