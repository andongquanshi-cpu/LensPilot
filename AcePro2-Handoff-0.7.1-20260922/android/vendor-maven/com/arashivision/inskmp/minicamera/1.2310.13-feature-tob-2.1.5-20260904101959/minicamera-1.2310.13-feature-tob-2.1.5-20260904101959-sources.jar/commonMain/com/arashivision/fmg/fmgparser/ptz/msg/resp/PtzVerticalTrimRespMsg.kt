package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzVerticalTrimRespMsg : PtzDataRespMessage() {
    var degrees: Short = 0

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 2) return
        degrees = FmgByteUtils.int16BytesToShort(data[0], data[1])
    }

    override fun toString(): String {
        return "degrees: $degrees"
    }

    override fun name(): String {
        return "CMD_VERTICAL_TRIM"
    }
}
