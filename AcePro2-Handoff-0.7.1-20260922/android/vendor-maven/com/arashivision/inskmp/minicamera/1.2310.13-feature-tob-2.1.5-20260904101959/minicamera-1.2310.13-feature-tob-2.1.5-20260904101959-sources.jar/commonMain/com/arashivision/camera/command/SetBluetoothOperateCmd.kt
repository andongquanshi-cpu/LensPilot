package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.BluetoothOperate
import insta360.messages.OptionType
import insta360.messages.Options

class SetBluetoothOperateCmd(
    private val bluetoothOperate: BluetoothOperate,
    private val requestOptions: RequestOptions,
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setOptionsAsync(
            listOf(OptionType.BLUETOOTH_OPERATE),
            Options(bluetooth_operate = bluetoothOperate),
            requestOptions
        )
    }
}
