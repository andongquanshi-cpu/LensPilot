package com.arashivision.fmg

import com.arashivision.camera.listener.IFmgConnectSyncListener
import com.arashivision.camera.listener.IFmgHandShakeListener
import com.arashivision.camera.strategy.TraceUtil
import com.arashivision.common.BleLog
import com.arashivision.common.Build
import com.arashivision.common.Log
import com.arashivision.common.currentTimeMillis
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.fmg.fmgparser.FmgPhoneEnum
import com.arashivision.fmg.fmgparser.ota.ExtraBleUpgradeResultParser
import com.arashivision.fmg.fmgparser.ota.ExtraBleUpgradeResultParser.IOtaParseCallback
import com.arashivision.fmg.fmgparser.ota.OtaCmdPacketPack
import com.arashivision.fmg.fmgparser.ota.OtaFirmwarePacketPack
import com.arashivision.fmg.fmgparser.ota.OtaFirmwarePacketPack.IOtaFirmwarePacketPack
import com.arashivision.fmg.fmgparser.ota.OtaStatus
import com.arashivision.fmg.fmgparser.ptz.IDataPacket
import com.arashivision.fmg.fmgparser.ptz.PtzDataPacket
import com.arashivision.fmg.fmgparser.ptz.PtzParser
import com.arashivision.fmg.fmgparser.ptz.PtzParser.IPtzParser
import com.arashivision.fmg.fmgparser.ptz.PtzStatus
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.AI_TRACKER_FRAME
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzBps
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzCmd
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzFrame
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzAiTrackerSettingsWriteReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzAppHbReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzAppImuInfoReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzBasketballA2GReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzButtonAbleReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzDataReqMessage
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzEmptyReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzGetEtdEventReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzMidcalReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzRcSetReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzRcSetVirtualRc
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzRecModeReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzSetActiveTimeReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzSetAngleSeqReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzSetAppStatusReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzSetPanoIndexReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzSettingsWriteReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzShakeHandReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzTargetsFollowReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzTimeElapseReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzTrackSensitivityModeReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpDateShakeHandReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateInfoReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateRebootReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateResetReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateingReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzVerticalTrimReqMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzAiTrackerSettingsReadRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzAngleSeqProcessRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzBasketballG2ARespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzDataRespMessage
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzDeviceInfoRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzDeviceStatusRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetActiveTimeRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetAiTrackerDeviceInfoRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetButtonEnableRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdBleHeaderRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdBleQuickStartEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdCFEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdErrorStateEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdHeaderRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdPowerOffEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdPowerOnEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdYaw360EventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetUuidRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGimbalCalStatusRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzMidcalRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzRcGetRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzResetDefaultSettingRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzSettingsReadRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzTrackSensitivityModeRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzVerticalTrimRespMsg
import com.arashivision.fmg.response.FmgActionResp
import com.arashivision.fmg.response.FmgBackCenterResp
import com.arashivision.fmg.response.FmgDisableHandDragResp
import com.arashivision.fmg.response.FmgEnableHandDragResp
import com.arashivision.fmg.response.FmgGetActiveTimeResp
import com.arashivision.fmg.response.FmgGetAiTrackerDeviceInfoResp
import com.arashivision.fmg.response.FmgGetAiTrackerSettingsResp
import com.arashivision.fmg.response.FmgGetAnalyticsDataResp
import com.arashivision.fmg.response.FmgGetButtonEnableStatusResp
import com.arashivision.fmg.response.FmgGetDeviceInfoResp
import com.arashivision.fmg.response.FmgGetEtsResp
import com.arashivision.fmg.response.FmgGetMidCalResp
import com.arashivision.fmg.response.FmgGetRunControlResp
import com.arashivision.fmg.response.FmgGetSettingsResp
import com.arashivision.fmg.response.FmgGetUUIDResp
import com.arashivision.fmg.response.FmgGetVerticalTrimDegreeResp
import com.arashivision.fmg.response.FmgOTACancelResp
import com.arashivision.fmg.response.FmgOTACompleteResp
import com.arashivision.fmg.response.FmgOTAProgressChangedResp
import com.arashivision.fmg.response.FmgSetActiveTimeResp
import com.arashivision.fmg.response.FmgSetAiTrackerSettingsResp
import com.arashivision.fmg.response.FmgSetAngleSeqResp
import com.arashivision.fmg.response.FmgSetAppStatusResp
import com.arashivision.fmg.response.FmgSetCameraFacingResp
import com.arashivision.fmg.response.FmgSetEtsResp
import com.arashivision.fmg.response.FmgSetMidCalResp
import com.arashivision.fmg.response.FmgSetPanoIndexResp
import com.arashivision.fmg.response.FmgSetPanoResp
import com.arashivision.fmg.response.FmgSetResetSettingsResp
import com.arashivision.fmg.response.FmgSetRoll360ModeResp
import com.arashivision.fmg.response.FmgSetRunControlResp
import com.arashivision.fmg.response.FmgSetSettingsResp
import com.arashivision.fmg.response.FmgSetTimeElapseResp
import com.arashivision.fmg.response.FmgSetVerticalTrimDegreeResp
import com.arashivision.fmg.response.FmgStartCalibrateResp
import com.arashivision.fmg.response.FmgVibrationResp
import com.arashivision.fmg.response.FmgZoomScaleResp
import com.arashivision.fmg.response.model.FmgAiTrackerSettingsParams
import com.arashivision.fmg.response.model.FmgAnalyticsParams
import com.arashivision.fmg.response.model.FmgAnalyticsParams.CFEvent
import com.arashivision.fmg.response.model.FmgAnalyticsParams.ErrorStateEvent
import com.arashivision.fmg.response.model.FmgAnalyticsParams.PowerOffEvent
import com.arashivision.fmg.response.model.FmgAnalyticsParams.PowerOnEvent
import com.arashivision.fmg.response.model.FmgAnalyticsParams.Yaw360Event
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.fmg.response.model.FmgBleAnalyticsParams
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgCalibrateState
import com.arashivision.fmg.response.model.FmgDeviceStatus
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.fmg.response.model.FmgModel.PtzAngleSqeState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.fmg.response.model.FmgModel.PtzButtonEvent
import com.arashivision.fmg.response.model.FmgModel.PtzButtonEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzButtonMode
import com.arashivision.fmg.response.model.FmgModel.PtzDwEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.fmg.response.model.FmgModel.PtzRockerEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.fmg.response.model.FmgModel.PtzTouchEventMode
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed
import com.arashivision.fmg.response.model.FmgResetSettingsParams
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.fmg.response.model.FmgSettingsParams
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.fmg.response.model.FmgTargetFollowParams.FollowType
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.fmg.upgrade.AITrackerUpgradeDelegate
import com.arashivision.fmg.upgrade.AITrackerUpgradeDelegate.IAITrackerUpgradeCallback
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleIndicateCallbackCore
import com.arashivision.inskmp.insble.callback.BleMtuChangedCallbackCore
import com.arashivision.inskmp.insble.callback.BleNotifyCallbackCore
import com.arashivision.inskmp.insble.callback.BleWriteCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BluetoothGattCharacteristicCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import com.arashivision.onecamera.Error
import com.arashivision.onecamera.OneDriver
import com.arashivision.onecamera.OneDriverInfo.Response.InfoType
import kotlinx.atomicfu.atomic
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.atomicfu.locks.synchronized
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.selects.onTimeout
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.min

class FmgCommDelegate(
    private val mOneDriver: OneDriver,
    private val mBleDevice: BleDeviceCore,
    private val heartHandler: CoroutineScope?,
) {
    //    private final Handler mHeartHandler;
    private val mIsDestroyed = atomic(false)

    private var mPtzWriteCharacteristic: BluetoothGattCharacteristicCore? = null
    private var mExtraBleUpgradeCharacteristic: BluetoothGattCharacteristicCore? = null
    private val mWriteBleResult = atomic(false)
    private val mInHeartBeat = atomic(false)
    private val mDuringUpgrading = atomic(false)
    private var mStartTargetFollowTime = -1L
    private var mTargetFollowId: Short = -1
    private var connectStarttime = 0L
    private val writeMutex = Mutex()
    private var recMode = PtzRecMode.NULL
    private var fmgAngleBean: FmgAngleBean? = null
    private var heartJob: Job? = null

    //        mHeartHandler = heartHandler;
    private val mAITrackerUpgradeDelegate =
        AITrackerUpgradeDelegate(this)

    // 任务队列，类似Handler的串行执行能力
    // 使用Channel实现任务队列，所有任务都会在同一个协程中排队执行
    private data class SerialTask(
        val taskId: Long = 0L, // 任务ID，用于取消延迟任务
        val action: suspend () -> Unit,
        val executeTime: Long = 0L, // 执行时间戳，0表示立即执行
    )

    private val taskChannel = Channel<SerialTask>(Channel.UNLIMITED)
    private val cancelChannel = Channel<Long>(Channel.UNLIMITED)
    private val serialScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default.limitedParallelism(1)
    )
    private var taskLoopJob: Job? = null
    private val taskIdCounter = atomic(0L)
    private val cancelledTaskIds = mutableSetOf<Long>()

    init {
        // 启动任务循环，处理所有任务（包括延迟任务）
        // 使用单个协程循环处理所有任务，避免多个协程挂起
        taskLoopJob = serialScope.launch {
            val delayedTasks = mutableListOf<SerialTask>()
            val checkInterval = 50L // 检查延迟任务的间隔（毫秒）

            while (isActive) {
                val currentTime = currentTimeMillis()

                // 处理取消请求
                while (true) {
                    val cancelledId = cancelChannel.tryReceive().getOrNull() ?: break
                    cancelledTaskIds.add(cancelledId)
                    delayedTasks.removeAll { it.taskId == cancelledId }
                    // 定期清理已取消的任务ID，避免集合无限增长
                    if (cancelledTaskIds.size > 1000) {
                        cancelledTaskIds.clear()
                    }
                }

                // 处理到期的延迟任务
                val readyTasks = delayedTasks.filter { it.executeTime <= currentTime }
                delayedTasks.removeAll(readyTasks)
                for (task in readyTasks) {
                    // 检查任务是否已被取消
                    if (task.taskId !in cancelledTaskIds) {
                        try {
                            task.action()
                        } catch (e: Exception) {
                            BleLog.e("SerialTask execution error ${e.message}")
                        }
                    }
                }

                // 计算下一个延迟任务的等待时间
                val nextDelayedTime = delayedTasks.minOfOrNull { it.executeTime }
                val waitTime = if (nextDelayedTime != null) {
                    (nextDelayedTime - currentTime).coerceAtMost(checkInterval).coerceAtLeast(0)
                } else {
                    checkInterval
                }

                // 使用select同时等待Channel新任务、取消请求和延迟任务的超时
                val result = select<Any?> {
                    taskChannel.onReceive { it }
                    cancelChannel.onReceive { it }
                    onTimeout(waitTime) { null }
                }

                when (result) {
                    is SerialTask -> {
                        if (result.executeTime > 0 && result.executeTime > currentTime) {
                            // 延迟任务，检查是否已被取消
                            if (result.taskId !in cancelledTaskIds) {
                                delayedTasks.add(result)
                            }
                        } else {
                            // 立即执行，检查是否已被取消
                            if (result.taskId !in cancelledTaskIds) {
                                try {
                                    result.action()
                                } catch (e: Exception) {
                                    BleLog.e("SerialTask execution error ${e.message}")
                                }
                            }
                        }
                    }

                    is Long -> {
                        // 收到取消请求
                        cancelledTaskIds.add(result)
                        delayedTasks.removeAll { it.taskId == result }
                    }
                }
            }
        }
    }

    /**
     * 提交任务到串行队列（立即执行）
     */
    private fun post(action: suspend () -> Unit) {
        val taskId = taskIdCounter.incrementAndGet()
        taskChannel.trySend(SerialTask(taskId, action, 0))
    }

    /**
     * 提交延迟任务到串行队列
     * @return 任务ID，可用于取消任务
     */
    private fun postDelayed(delayMs: Long, action: suspend () -> Unit): Long {
        val taskId = taskIdCounter.incrementAndGet()
        val executeTime = currentTimeMillis() + delayMs
        taskChannel.trySend(SerialTask(taskId, action, executeTime))
        return taskId
    }

    /**
     * 取消延迟任务
     * @param taskId 任务ID，由 postDelayed 返回
     */
    private fun cancelDelayedTask(taskId: Long) {
        cancelChannel.trySend(taskId)
    }

    fun destroy() {
        BleLog.d("FmgCommDelegate destroy")
        mIsDestroyed.value = true
        ptzStopHeartBeat()
        clearRequestQueue()
        cancelFmgUpgrade()
        cancelAITrackUpgrade()
        mFmgHandShakeListener = null
        taskLoopJob?.cancel()
        serialScope.cancel()
    }

    fun ptzConnectSync(bleDevice: BleDeviceCore?, syncListener: IFmgConnectSyncListener?) {
        if (bleDevice != null) {
            mDuringUpgrading.value = (false)
            BleManagerCore
                .setMtu(bleDevice, BLE_WRITE_MAX_LEN, object : BleMtuChangedCallbackCore() {
                    override fun onSetMTUFailure(exception: BleExceptionCore) {
                        syncListener?.onSyncError(BleExceptionCore.ERROR_CODE_SET_MTU)
                    }

                    override fun onMtuChanged(mtu: Int) {
                        BleLog.i("ptzConnectSync onMtuChanged mtu:$mtu")
                        BleManagerCore.setSplitWriteNum(244)
                        post {
                            //flow 1代特有，暂时不考虑修改
                            registerExtraBleUpgrade(bleDevice, object : RegisterBleCallback {
                                override fun onRegisterSuccess() {
                                    connectPtzService(bleDevice, syncListener)
                                }

                                override fun onRegisterFailure(exception: BleExceptionCore?) {
                                    connectPtzService(bleDevice, syncListener)
                                }
                            })
                        }
                    }
                })
        }
    }

    private fun connectPtzService(
        bleDevice: BleDeviceCore,
        syncListener: IFmgConnectSyncListener?,
    ) {
        post {
            registerPtzBle(bleDevice, object : RegisterBleCallback {
                override fun onRegisterSuccess() {
                    // 实测FMG刚notify成功立刻发消息某些手机上云台不会回，固件不知道原因，在此延迟1s再发送第一个消息
                    postDelayed(1000) {
                        ptzHandShake(object : IFmgHandShakeListener {
                            override fun onHandShakeSuccess() {
                                syncListener?.onSyncSuccess()
                                ptzStartHeartBeat()
                            }

                            override fun onHandShakeError(error: Int) {
                                syncListener?.onSyncError(BleExceptionCore.ERROR_CODE_SHAKE_HAND)
                            }
                        })
                    }
                }

                override fun onRegisterFailure(exception: BleExceptionCore?) {
                    BleLog.d("Ptz notify error $exception")
                    if (syncListener != null) {
//                    if (exception is OtherException) {
//                        syncListener.onSyncError(exception.getCode())
//                    } else {
                        syncListener.onSyncError(BleExceptionCore.ERROR_CODE_NOTIFY_FAILURE)
//                    }
                    }
                }
            })
        }
    }

    fun ptzStartHeartBeat() {
        if (!mInHeartBeat.value) {
            mInHeartBeat.value = (true)
            heartJob = heartHandler?.launch {
                while (mInHeartBeat.value) {
                    if (mIsDestroyed.value) {
                        break
                    }
                    if (mFmgUpgradeBean != null) {
                        // OTA升级时发心跳包会写入失败，影响固件升级
                        delay(1000)
                        continue
                    }
                    var roll: Short = 0
                    if (fmgAngleBean != null) {
                        roll = fmgAngleBean!!.roll.toShort()
                    }
                    val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_APP_HB, PtzFrame.REQ_NONE)
                    val ptzAppHbReqMsg =
                        PtzAppHbReqMsg(currentTimeMillis(), recMode.nativeValue, roll)
                    addNewRequestTask(ptzDataPacket, ptzAppHbReqMsg, null)
                    delay(1000)
                }
            }
        }
    }

    fun ptzStopHeartBeat() {
        mInHeartBeat.value = (false)
        heartJob?.cancel()
    }

    /********************  Ptz Response Data   */
    private val mPtzParser = PtzParser(object : IPtzParser {
        override fun onGetCompletePacket(ptzDataPacket: PtzDataPacket) {
            val cmd = ptzDataPacket.cmd
            if (cmd == PtzCmd.CMD_ERROR) {
                if (!handlePtzResponse(ptzDataPacket)) {
                    onError(ptzDataPacket.frame.toInt())
                }
            } else if (PtzCmd.isNotification(cmd)) {
                handlePtzNotification(ptzDataPacket)
            } else {
                handlePtzResponse(ptzDataPacket)
            }
            executeNextTaskIfAvailable()
        }

        override fun onError(e: Int) {
            BleLog.e("PtzParser onError, code = $e")
            if (!triggerCurrentTaskAgain()) {
                executeNextTaskIfAvailable()
            }
        }
    })

    fun onPtzResponse(data: ByteArray) {
        if (!mIsDestroyed.value) {
            mPtzParser.resolverV2(data)
        }
    }

    private enum class RequestTaskState {
        IDLE, PREPARING, RUNNING, FINISHED
    }

    private inner class PtzRequestTask(
        private val requestId: Long, private val ptzDataPacket: IDataPacket,
        private val ptzDataReqMessage: PtzDataReqMessage,
        val requestCallback: IRequestCallback?,
        val timeoutMs: Long, private val writeWithResponse: Boolean,
    ) {
        val state = atomic(RequestTaskState.IDLE)

        private constructor(
            requestId: Long, ptzDataPacket: PtzDataPacket,
            ptzDataReqMessage: PtzDataReqMessage,
            requestCallback: IRequestCallback?,
        ) : this(
            requestId,
            ptzDataPacket,
            ptzDataReqMessage,
            requestCallback,
            DEFAULT_TIMEOUT_MS,
            DEFAULT_WRITE_WITH_RESPONSE
        )

        constructor(
            requestId: Long, ptzDataPacket: IDataPacket,
            ptzDataReqMessage: PtzDataReqMessage,
            requestCallback: IRequestCallback?,
            writeWithResponse: Boolean,
        ) : this(
            requestId,
            ptzDataPacket,
            ptzDataReqMessage,
            requestCallback,
            DEFAULT_TIMEOUT_MS,
            writeWithResponse
        )

        val cmd: Short
            get() = ptzDataPacket.cmd

        val frame: Short
            get() = ptzDataPacket.frame

        fun prepare() {
            if (state.value == RequestTaskState.IDLE) {
                state.value = (RequestTaskState.PREPARING)
            }
        }

        suspend fun execute() {
            state.value = (RequestTaskState.RUNNING)
            val pack = ptzDataPacket.packetPack(ptzDataReqMessage.packData())
            val writeWithResponse = requestCallback != null && this.writeWithResponse
            writePtzData(pack!!, writeWithResponse)
        }

        fun handleResponse(ptzDataPacket: PtzDataPacket): Boolean {
            if (isValidResponse(ptzDataPacket)) {
                requestCallback?.onRequestCallback(requestId, ptzDataPacket)
                state.value = (RequestTaskState.FINISHED)
                return true
            } else {
                return false
            }
        }

        // 高频发送请求时固件偶现回复一次和RequestData完全一致的数据，后边又会紧跟正常回复
        // 固件未查明原因，这里过滤下异常response
        fun isValidResponse(responsePacket: PtzDataPacket): Boolean {
            if (cmd == PtzCmd.CMD_TEST) {
                return true
            } else {
                val requestData = ptzDataPacket.data
                val responseData = responsePacket.data
                return !(requestData != null && requestData.size > 4 && responseData != null && responseData.size == requestData.size && ptzDataPacket.crc16 == responsePacket.crc16)
            }
        }

        override fun toString(): String {
            return "FmgRequestTask{" +
                    "requestId = " + requestId +
                    ", cmd = " + formatValueToHex(cmd) +
                    ", frame = " + formatValueToHex(frame) + " (" + frame + ")" +
                    ", ReqMessage = " + ptzDataReqMessage.name() +
                    ", callback = " + (requestCallback != null) +
                    '}'
        }
    }

    interface IRequestCallback {
        fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket)
    }

    private val mRequestQueue = mutableListOf<PtzRequestTask>()
    private val queueLock = SynchronizedObject()

    private fun addNewRequestTask(
        ptzDataPacket: PtzDataPacket,
        ptzDataReqMessage: PtzDataReqMessage,
        requestCallback: IRequestCallback?,
    ): Long {
        return addNewRequestTask(null, ptzDataPacket, ptzDataReqMessage, requestCallback)
    }

    fun addNewRequestTask(
        requestId: Long?,
        ptzDataPacket: PtzDataPacket,
        ptzDataReqMessage: PtzDataReqMessage,
        requestCallback: IRequestCallback?,
    ): Long {
        return addNewRequestTask(
            requestId,
            ptzDataPacket,
            ptzDataReqMessage,
            requestCallback,
            null,
            null
        )
    }

    /**
     * 将新任务添加到执行队列
     *
     * @param requestId         给上层回调response时对应用的id，传null则自增
     * @param ptzDataPacket     组装数据用的packet
     * @param ptzDataReqMessage 组装数据用的msg
     * @param requestCallback   云台回复命令时的回调，传null代表该命令云台不回复
     * @param timeoutMs         命令未收到云台回复的超时重发时间，传null则使用RequestTask默认时间
     * @return requestId
     */
    fun addNewRequestTask(
        requestId: Long?,
        ptzDataPacket: IDataPacket,
        ptzDataReqMessage: PtzDataReqMessage,
        requestCallback: IRequestCallback?,
        timeoutMs: Long?,
        writeWithResponse: Boolean?,
    ): Long {
        var requestId = requestId
        var writeWithResponse = writeWithResponse
        synchronized(queueLock) {

            if (!mIsDestroyed.value) {
                if (mDuringUpgrading.value && !PtzCmd.isUpgradCmd(ptzDataPacket.cmd)) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_BUSYNESS,
                        ptzDataPacket.cmd.toInt(),
                        null
                    )
                    return -1L
                }
                if (requestId == null) {
                    requestId = generateRequestId()
                }
                if (writeWithResponse == null) {
                    writeWithResponse = DEFAULT_WRITE_WITH_RESPONSE
                }
                if (timeoutMs == null) {
                    mRequestQueue.add(
                        PtzRequestTask(
                            requestId!!, ptzDataPacket, ptzDataReqMessage, requestCallback,
                            writeWithResponse!!
                        )
                    )
                } else {
                    mRequestQueue.add(
                        PtzRequestTask(
                            requestId!!,
                            ptzDataPacket,
                            ptzDataReqMessage,
                            requestCallback,
                            timeoutMs,
                            writeWithResponse!!
                        )
                    )
                }
                executeNextTaskIfAvailable()
                return requestId!!
            } else {
                return -1L
            }
        }
    }

    private fun clearRequestQueue() {
        synchronized(queueLock) {
            requestTimeoutTaskId?.let { cancelDelayedTask(it) }
            mRequestQueue.clear()
        }
    }

    private fun clearRequestQueueByCmd(cmd: Short) {
        synchronized(queueLock) {
            var isRemovedRunningTask = false
            val iterator = mRequestQueue.iterator()
            while (iterator.hasNext()) {
                val requestTask = iterator.next()
                if (requestTask.cmd == cmd) {
                    if (requestTask.state.value == RequestTaskState.PREPARING
                        || requestTask.state.value == RequestTaskState.RUNNING
                    ) {
                        isRemovedRunningTask = true
                    }
                    iterator.remove()
                }
            }
            if (isRemovedRunningTask) {
                executeNextTaskIfAvailable()
            }
        }
    }

    private var requestTimeoutId = atomic(0L)
    private var requestTimeoutTaskId: Long? = null

    private fun scheduleRequestTimeout(timeoutMs: Long) {
        // 取消之前的超时任务
        requestTimeoutTaskId?.let { cancelDelayedTask(it) }
        requestTimeoutId.incrementAndGet()
        if (timeoutMs > 0) {
            val timeoutId = requestTimeoutId.value
            requestTimeoutTaskId = postDelayed(timeoutMs) {
                // 检查超时任务是否仍然有效
                if (requestTimeoutId.value == timeoutId) {
                    triggerCurrentTaskAgain()
                }
            }
        } else {
            requestTimeoutTaskId = null
        }
    }


    private fun triggerCurrentTaskAgain(): Boolean {
        synchronized(queueLock) {
            if (mIsDestroyed.value) return false
            val requestTask = mRequestQueue.firstOrNull()
            if (requestTask != null && requestTask.state.value == RequestTaskState.RUNNING) {
                BleLog.i("triggerCurrentTaskAgain, $requestTask")
                post { requestTask.execute() }
                scheduleRequestTimeout(requestTask.timeoutMs)
                return true
            }
            return false
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private fun executeNextTaskIfAvailable() {
        synchronized(queueLock) {
            if (mIsDestroyed.value) return
            while (mRequestQueue.isNotEmpty()) {
                val requestTask = mRequestQueue.firstOrNull()
                if (requestTask == null) {
                    continue
                }
                when (requestTask.state.value) {
                    RequestTaskState.FINISHED -> {
                        BleLog.i("executeNextTaskIfAvailable, but peek task is already finished, remove and check next")
                        mRequestQueue.remove(requestTask)
                    }

                    RequestTaskState.PREPARING -> {
                        BleLog.i("executeNextTaskIfAvailable, but peek task is already preparing, ignored")
                        return
                    }

                    RequestTaskState.RUNNING -> {
                        BleLog.i("executeNextTaskIfAvailable, but peek task is already running, ignored")
                        return
                    }

                    RequestTaskState.IDLE -> {
                        BleLog.d("executeNextTaskIfAvailable 执行 cmd= ${requestTask.cmd.toHexString()} callback 是否为空 ${requestTask.requestCallback == null}")
                        requestTask.prepare()
                        post { requestTask.execute() }
                        if (requestTask.requestCallback == null) {
                            post {
                                // 云台不回复的 组一个假的response进来
                                onPtzResponse(
                                    PtzDataPacket(
                                        requestTask.cmd,
                                        requestTask.frame
                                    ).packetPack(null)
                                )
                            }
                        } else if (requestTask.timeoutMs > 0) {
                            scheduleRequestTimeout(requestTask.timeoutMs)
                        }
                        return
                    }
                }
            }
        }
    }

    private fun handlePtzResponse(responseDataPacket: PtzDataPacket): Boolean {
        synchronized(queueLock) {
            if (mIsDestroyed.value) return true
            val requestTask = mRequestQueue.firstOrNull()
            if (requestTask != null && requestTask.state.value == RequestTaskState.RUNNING && (responseDataPacket.cmd == requestTask.cmd
                        || (responseDataPacket.cmd == PtzCmd.CMD_ERROR
                        && responseDataPacket.frame == PtzFrame.ACK_ERR_INVALID_CMD))
            ) {
                BleLog.i("executeNextTaskIfAvailable handlePtzResponse, $requestTask")

                requestTimeoutTaskId?.let { cancelDelayedTask(it) }
                if (requestTask.handleResponse(responseDataPacket)) {
                    mRequestQueue.remove(requestTask)
                    return true
                } else {
                    scheduleRequestTimeout(requestTask.timeoutMs)
                }
            }
            return false
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private fun handlePtzNotification(responseDataPacket: PtzDataPacket) {
        synchronized(queueLock) {
            if (mIsDestroyed.value) return
            val dataRespMessage: PtzDataRespMessage
            BleLog.i("handlePtzNotification, " + responseDataPacket.cmd.toHexString())
            when (responseDataPacket.cmd) {
                PtzCmd.CMD_DEVICE_STATUS -> {
                    val ptzDeviceStatusRespMsg =
                        responseDataPacket.unPack() as PtzDeviceStatusRespMsg
                    val deviceStatus = FmgDeviceStatus()
                    deviceStatus.batteryLevel = ptzDeviceStatusRespMsg.battery.toInt()
                    deviceStatus.isCharging = ptzDeviceStatusRespMsg.charging
                    deviceStatus.ptzMode =
                        PtzMode.Companion.findByValue(ptzDeviceStatusRespMsg.mode.toInt())
                    deviceStatus.isLimitedYaw = ptzDeviceStatusRespMsg.limitYaw
                    deviceStatus.isStalled = ptzDeviceStatusRespMsg.stall
                    deviceStatus.hasPayload = ptzDeviceStatusRespMsg.payload
                    deviceStatus.isOverTemp = ptzDeviceStatusRespMsg.overTemp
                    deviceStatus.imbalance = ptzDeviceStatusRespMsg.imbalance
                    deviceStatus.sportMode = ptzDeviceStatusRespMsg.sportMode
                    deviceStatus.sleep = ptzDeviceStatusRespMsg.sleep
                    deviceStatus.isLowTemp = ptzDeviceStatusRespMsg.lowTemp
                    deviceStatus.isLimitedPitch = ptzDeviceStatusRespMsg.limitPitch
                    deviceStatus.hvMode = ptzDeviceStatusRespMsg.hvMode
                    deviceStatus.motionType = ptzDeviceStatusRespMsg.motionType
                    deviceStatus.cfMode = ptzDeviceStatusRespMsg.cfMode
                    deviceStatus.aiOnline = ptzDeviceStatusRespMsg.aiOnline
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_NOTIFY_DEVICE_STATUS,
                        Error.ERR_NONE,
                        deviceStatus
                    )
                }

                PtzCmd.CMD_MB_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_MODE_BTN_EVENT,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_SB_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_SHUTTER_BTN_EVENT,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_HOLD_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_HOLD_BTN_EVENT,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_MID_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_MIDDLE_BTN_EVENT,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_RC_EVENT -> if (responseDataPacket.frame.toInt() == PtzButtonEvent.RC_SRC_VALUE.nativeValue) {
                    var upDown: Byte? = null
                    var leftRight: Byte? = null
                    var data: RcScrValueData? = null
                    if (responseDataPacket.data?.size ?: 0 > 1) {
                        upDown = responseDataPacket.data!![0]
                        leftRight = responseDataPacket.data!![1]
                        data = RcScrValueData(upDown, leftRight)
                    }
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_NOTIFY_RC_SRC_VALUE_EVENT,
                        Error.ERR_NONE,
                        data
                    )
                } else {
                    notifyBtnEvent(InfoType.FMG_NOTIFY_ROCKER_EVENT, responseDataPacket.frame)
                }

                PtzCmd.CMD_TOUCH_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_TOUCH_EVENT,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_DW_EVENT -> if (responseDataPacket.frame.toInt() == PtzButtonEvent.DW_SRC_VALUE.nativeValue) {
                    var srcValue: Byte? = null
                    if (responseDataPacket.data?.size ?: 0 > 0) {
                        srcValue = responseDataPacket.data!![0]
                    }
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_NOTIFY_DIAL_WHEEL_VAULE_EVENT,
                        Error.ERR_NONE,
                        srcValue
                    )
                } else {
                    notifyBtnEvent(InfoType.FMG_NOTIFY_DIAL_WHEEL_EVENT, responseDataPacket.frame)
                }

                PtzCmd.CMD_PB_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_POWER_BTN_EVENT,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_GIMBAL_EVENT -> notifyBtnEvent(
                    InfoType.FMG_NOTIFY_SURROUND_SHOOT_COMPLETE,
                    responseDataPacket.frame
                )

                PtzCmd.CMD_GIMBAL_CAL_STATUS -> {
                    dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGimbalCalStatusRespMsg) {
                        val ptzGimbalCalStatusRespMsg = dataRespMessage
                        val calibrateState = FmgCalibrateState(
                            ptzGimbalCalStatusRespMsg.status.toInt(),
                            ptzGimbalCalStatusRespMsg.percentage.toInt()
                        )
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_CALIBRATE_PROGRESS_CHANGE,
                            ptzGimbalCalStatusRespMsg.status.toInt(),
                            calibrateState
                        )
                    } else {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_CALIBRATE_PROGRESS_CHANGE,
                            Error.ERR_CAMERA_RESPONSE_ERROR,
                            null
                        )
                    }
                }

                PtzCmd.CMD_GRF_ANGLE_REACH -> {
                    val frame = responseDataPacket.frame
                    if (frame == PtzAngleSqeState.GRF_ANGLE_SEQ_PROCESS.nativeValue) {
                        dataRespMessage = responseDataPacket.unPack()
                        if (dataRespMessage is PtzAngleSeqProcessRespMsg) {
                            mOneDriver.driverInfoNotify(
                                InfoType.FMG_NOTIFY_GRF_ANGLE_REACH,
                                frame.toInt(),
                                dataRespMessage.process
                            )
                        } else {
                            mOneDriver.driverInfoNotify(
                                InfoType.FMG_NOTIFY_GRF_ANGLE_REACH,
                                frame.toInt(),
                                0
                            )
                        }
                    } else {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_NOTIFY_GRF_ANGLE_REACH,
                            frame.toInt(),
                            null
                        )
                    }
                }

                PtzCmd.CMD_BASKETBALL_G2A -> {
                    dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzBasketballG2ARespMsg) {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_BASKETBALL_G2A, Error.ERR_NONE,
                            dataRespMessage
                        )
                    } else {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_BASKETBALL_G2A,
                            Error.ERR_CAMERA_RESPONSE_ERROR,
                            null
                        )
                    }
                }
            }
        }
    }

    private fun notifyBtnEvent(what: Int, frame: Short) {
        val ptzButtonEvent: PtzButtonEvent? = PtzButtonEvent.Companion.nativeValueOf(frame.toInt())
        //没有对应枚举类型的事件，视为非法事件，不上报
        if (ptzButtonEvent != null) {
            mOneDriver.driverInfoNotify(what, Error.ERR_NONE, ptzButtonEvent)
        } else {
            BleLog.e("notifyBtnEvent Illegal event, what:$what frame:$frame")
        }
    }

    /********************  Ptz Cmd API   */
    private var mFmgHandShakeListener: IFmgHandShakeListener? = null

    private fun ptzHandShake(listener: IFmgHandShakeListener) {
        mFmgHandShakeListener = listener
        ptzHandShakeStep1()
    }

    private fun ptzHandShakeStep1() {
        val phoneBrandValue: Short = FmgPhoneEnum.Companion.findByKey(Build.BRAND).value
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SHAKE_HAND, PtzFrame.REQ_SHAKE_HAND_STEP_1)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzShakeHandReqMsg(PtzStatus.PROTOCOL, phoneBrandValue, PtzBps.SHAKE_HAND)
        BleLog.e("ptzHandShakeStep1 CMD_SHAKE_HAND, ptzDataReqMessage = $ptzDataReqMessage")
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_SHAKE_HAND) {
                    ptzHandShakeStep2()
                } else {
                    BleLog.e("ptzHandShakeStep1 error, frame = " + formatValueToHex(frame))
                    val handShakeListener = mFmgHandShakeListener
                    handShakeListener?.onHandShakeError(frame.toInt())
                    mFmgHandShakeListener = null
                }
            }
        })
    }

    private fun ptzHandShakeStep2() {
        val phoneBrandValue: Short = FmgPhoneEnum.Companion.findByKey(Build.BRAND).value
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SHAKE_HAND, PtzFrame.REQ_SHAKE_HAND_STEP_2)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzShakeHandReqMsg(PtzStatus.PROTOCOL, phoneBrandValue, PtzBps.SHAKE_HAND)
        BleLog.e("ptzHandShakeStep2 CMD_SHAKE_HAND, ptzDataReqMessage = $ptzDataReqMessage")
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val handShakeListener = mFmgHandShakeListener
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_SHAKE_HAND) {
                    handShakeListener?.onHandShakeSuccess()
                } else {
                    BleLog.e("ptzHandShakeStep1 error, frame = " + formatValueToHex(frame))
                    handShakeListener?.onHandShakeError(frame.toInt())
                }
                mFmgHandShakeListener = null
            }
        })
    }

    private fun onRequestError(what: Int, error: Int, obj: Any) {
        // 固件返回的错误码 ACK_OK = 0x80, error 就可能是 0。应用层 OK = 0, 所以需要把error = 0 的情况做下转换。
        var error = error
        if (error == Error.ERR_NONE) error = Error.ERR_CAMERA_RESPONSE_ERROR
        mOneDriver.driverInfoNotify(what, error, obj)
    }

    fun ptzGetDeviceInfo(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_DEVICE_INFO, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzDeviceInfoRespMsg) {
                        val deviceInfoRespMsg = dataRespMessage
                        val deviceInfoResp = FmgGetDeviceInfoResp(
                            requestId,
                            deviceInfoRespMsg.sn,
                            deviceInfoRespMsg.type,
                            deviceInfoRespMsg.version
                        )
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_DEVICE_INFO,
                            Error.ERR_NONE,
                            deviceInfoResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetDeviceInfo error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_DEVICE_INFO,
                    frame.toInt(),
                    FmgGetDeviceInfoResp(requestId)
                )
            }
        })
    }

    fun ptzGetUUID(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_UUID, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetUuidRespMsg) {
                        val getUUIDResp = FmgGetUUIDResp(requestId, dataRespMessage.uuid)
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_UUID,
                            Error.ERR_NONE,
                            getUUIDResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetUUID error, frame = " + formatValueToHex(frame))
                val getUUIDResp = FmgGetUUIDResp(requestId, "")
                mOneDriver.driverInfoNotify(InfoType.FMG_GET_UUID, frame.toInt(), getUUIDResp)
            }
        })
    }

    fun ptzSetActiveTime(time: Long): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SET_ACTIVE_TIME, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSetActiveTimeReqMsg(time)
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_ACTIVE_TIME,
                        Error.ERR_NONE,
                        FmgSetActiveTimeResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetActiveTime error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_ACTIVE_TIME,
                        frame.toInt(),
                        FmgSetActiveTimeResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzGetActiveTime(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ACTIVE_TIME, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetActiveTimeRespMsg) {
                        val getActiveTimeResp =
                            FmgGetActiveTimeResp(requestId, dataRespMessage.time)
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_ACTIVE_TIME,
                            Error.ERR_NONE,
                            getActiveTimeResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetActiveTime error, frame = " + formatValueToHex(frame))
                val getActiveTimeResp = FmgGetActiveTimeResp(requestId, -1)
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ACTIVE_TIME,
                    frame.toInt(),
                    getActiveTimeResp
                )
            }
        })
    }

    fun ptzSetZoomScale(scale: Short): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ZOOM_SCALE, scale)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_ZOOM_SCALE,
                        Error.ERR_NONE,
                        FmgZoomScaleResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetActiveTime error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_ZOOM_SCALE,
                        frame.toInt(),
                        FmgZoomScaleResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzResetDefaultSettings(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_RESET_DEFAULT_SETTINGS, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                var frame = responseDataPacket.frame
                val cmd = responseDataPacket.cmd
                if (frame == PtzFrame.ACK_OK && cmd == ptzDataPacket.cmd) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzResetDefaultSettingRespMsg) {
                        val resetDefaultSettingRespMsg = dataRespMessage
                        val resetSettingsParams = FmgResetSettingsParams()
                        val settingsParams = FmgSettingsParams()
                        settingsParams.ptzMode = PtzMode.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.mode.toInt()
                        )
                        settingsParams.ptzFollowSpeed = PtzFollowSpeed.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.follow_speed.toInt()
                        )
                        settingsParams.ptzRcSpeed = PtzRcSpeed.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.rc_speed.toInt()
                        )
                        settingsParams.ptzZoomSpeed = PtzZoomSpeed.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.zoom_speed.toInt()
                        )
                        settingsParams.ptzRcHorizontalDir =
                            PtzRcHorizontalDir.Companion.findByValue(
                                resetDefaultSettingRespMsg.settingRespMsg!!.horizontal_dir.toInt()
                            )
                        settingsParams.ptzRcVerticalDir = PtzRcVerticalDir.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.vertical_dir.toInt()
                        )
                        settingsParams.ptzSoundEnable = PtzSoundMode.Companion.nativeValueOf(
                            resetDefaultSettingRespMsg.settingRespMsg!!.sound_enable.toInt()
                        )
                        settingsParams.ptzHvMode = PtzHvMode.Companion.nativeValueOf(
                            resetDefaultSettingRespMsg.settingRespMsg!!.hv_mode.toInt()
                        )
                        settingsParams.ptzSwitchModeWay = PtzSwitchModeWay.Companion.nativeValueOf(
                            resetDefaultSettingRespMsg.settingRespMsg!!.switch_mode_way.toInt()
                        )
                        settingsParams.ptzMotorStrength = PtzMotorStrength.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.motor_strength.toInt()
                        )
                        settingsParams.ptzRoll360 = PtzRoll360.Companion.nativeValueOf(
                            resetDefaultSettingRespMsg.settingRespMsg!!.roll_360.toInt()
                        )
                        settingsParams.ptzQuickStart = PtzQuickStart.Companion.nativeValueOf(
                            resetDefaultSettingRespMsg.settingRespMsg!!.quick_start_enable.toInt()
                        )
                        settingsParams.ptzPitchLed = PtzPitchLed.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.pitch_led.toInt()
                        )
                        settingsParams.ptzLedBrightness =
                            resetDefaultSettingRespMsg.settingRespMsg!!.led_status.toInt()
                        settingsParams.ptzEnableSaveHv = PtzEnableSaveHv.Companion.findByValue(
                            resetDefaultSettingRespMsg.settingRespMsg!!.enable_save_hv.toInt()
                        )
                        settingsParams.ptzSurroundShoot = PtzSurroundShoot.Companion.nativeValueOf(
                            resetDefaultSettingRespMsg.settingRespMsg!!.yaw_300.toInt()
                        )
                        resetSettingsParams.fmgSettingsParams = settingsParams
                        resetSettingsParams.degrees = resetDefaultSettingRespMsg.userAdjust / 10f
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_RESET_DEFAULT_SETTINGS,
                            Error.ERR_NONE,
                            FmgSetResetSettingsResp(requestId, resetSettingsParams)
                        )
                        return
                    }
                }
                BleLog.e("ptzSetActiveTime error, frame = " + formatValueToHex(frame))
                if (frame.toInt() == Error.ERR_NONE) {
                    // firebase出现过 frame = 0 的情况，返回给客户端，客户端会认为是OK，所以转换一下
                    frame = Error.ERR_PARSE_PROTO_RESPONSE_FAILED.toShort()
                }
                onRequestError(
                    InfoType.FMG_RESET_DEFAULT_SETTINGS,
                    frame.toInt(),
                    FmgSetResetSettingsResp(requestId, null)
                )
            }
        })
    }

    /**
     * 设置 跟踪灵敏度增强命令
     *
     * @param mode
     * @return
     */
    fun ptzSetTrackSensitivityMode(mode: PtzTrackSensitivityMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ETS, PtzFrame.ETS_SET)
        val ptzDataReqMessage: PtzDataReqMessage = PtzTrackSensitivityModeReqMsg(mode.nativeValue)
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETS_SET) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_ETS,
                        Error.ERR_NONE,
                        FmgSetEtsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetTrackSensitivityMode error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_ETS,
                        frame.toInt(),
                        FmgSetEtsResp(requestId)
                    )
                }
            }
        })
    }

    /**
     * 获取 跟踪灵敏度增强命令
     *
     * @return
     */
    fun ptzGetTrackSensitivityMode(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ETS, PtzFrame.ETS_GET)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val fmgGetEtsResp = FmgGetEtsResp(requestId)
                if (frame == PtzFrame.ETS_GET) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzTrackSensitivityModeRespMsg) {
                        fmgGetEtsResp.mode = PtzTrackSensitivityMode.Companion.nativeValueOf(
                            dataRespMessage.mode
                        )
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_ETS,
                            Error.ERR_NONE,
                            fmgGetEtsResp
                        )
                        return
                    }
                    BleLog.e("ptzGetTrackSensitivityMode error, dataRespMessage isNot PtzTrackSensitivityModeRespMsg")
                }
                BleLog.e("ptzGetTrackSensitivityMode error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(InfoType.FMG_GET_ETS, frame.toInt(), fmgGetEtsResp)
            }
        })
    }

    fun ptzGetAllSettings(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_READ, PtzFrame.SF_ALL)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_ALL) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzSettingsReadRespMsg) {
                        val settingsReadRespMsg = dataRespMessage
                        val settingsParams = FmgSettingsParams()
                        settingsParams.ptzMode =
                            PtzMode.Companion.findByValue(settingsReadRespMsg.mode.toInt())
                        settingsParams.ptzFollowSpeed =
                            PtzFollowSpeed.Companion.findByValue(settingsReadRespMsg.follow_speed.toInt())
                        settingsParams.ptzRcSpeed =
                            PtzRcSpeed.Companion.findByValue(settingsReadRespMsg.rc_speed.toInt())
                        settingsParams.ptzZoomSpeed =
                            PtzZoomSpeed.Companion.findByValue(settingsReadRespMsg.zoom_speed.toInt())
                        settingsParams.ptzRcHorizontalDir =
                            PtzRcHorizontalDir.Companion.findByValue(settingsReadRespMsg.horizontal_dir.toInt())
                        settingsParams.ptzRcVerticalDir =
                            PtzRcVerticalDir.Companion.findByValue(settingsReadRespMsg.vertical_dir.toInt())
                        settingsParams.ptzSoundEnable =
                            PtzSoundMode.Companion.nativeValueOf(settingsReadRespMsg.sound_enable.toInt())
                        settingsParams.ptzHvMode =
                            PtzHvMode.Companion.nativeValueOf(settingsReadRespMsg.hv_mode.toInt())
                        settingsParams.ptzSwitchModeWay =
                            PtzSwitchModeWay.Companion.nativeValueOf(settingsReadRespMsg.switch_mode_way.toInt())
                        settingsParams.ptzLedBrightness = settingsReadRespMsg.led_status.toInt()
                        settingsParams.ptzMotorStrength =
                            PtzMotorStrength.Companion.findByValue(settingsReadRespMsg.motor_strength.toInt())
                        settingsParams.ptzRoll360 =
                            PtzRoll360.Companion.nativeValueOf(settingsReadRespMsg.roll_360.toInt())
                        settingsParams.ptzQuickStart =
                            PtzQuickStart.Companion.nativeValueOf(settingsReadRespMsg.quick_start_enable.toInt())
                        settingsParams.ptzPitchLed =
                            PtzPitchLed.Companion.findByValue(settingsReadRespMsg.pitch_led.toInt())
                        settingsParams.ptzEnableSaveHv =
                            PtzEnableSaveHv.Companion.findByValue(settingsReadRespMsg.enable_save_hv.toInt())
                        settingsParams.ptzSurroundShoot =
                            PtzSurroundShoot.Companion.nativeValueOf(settingsReadRespMsg.yaw_300.toInt())
                        val getSettingsResp = FmgGetSettingsResp(requestId, settingsParams)
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_SETTINGS,
                            Error.ERR_NONE,
                            getSettingsResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetSettings error, frame = " + formatValueToHex(frame))
                val getSettingsResp = FmgGetSettingsResp(requestId, null)
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_SETTINGS,
                    frame.toInt(),
                    getSettingsResp
                )
            }
        })
    }

    fun ptzSetSettingsMode(mode: PtzMode): Long {
        val nativeValue = mode.ordinal.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_MODE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_MODE) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingsMode error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingFollowSpeed(followSpeed: PtzFollowSpeed): Long {
        val nativeValue = followSpeed.ordinal.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_FOLLOW_SPEED)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_FOLLOW_SPEED) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingFollowSpeed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingRcSpeed(rcSpeed: PtzRcSpeed): Long {
        val nativeValue = rcSpeed.ordinal.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_RC_SPEED)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_RC_SPEED) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingRcSpeed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingZoomSpeed(zoomSpeed: PtzZoomSpeed): Long {
        val nativeValue = zoomSpeed.ordinal.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_ZOOM_SPEED)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_ZOOM_SPEED) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingRcSpeed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingRcHorizontalDir(horizontalDir: PtzRcHorizontalDir): Long {
        val nativeValue = horizontalDir.nativeValue.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_RC_HORIZONTAL_DIR)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_RC_HORIZONTAL_DIR) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingRcHorizontalDir error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingRcVerticalDir(verticalDir: PtzRcVerticalDir): Long {
        val nativeValue = verticalDir.nativeValue.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_RC_VERTICAL_DIR)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_RC_VERTICAL_DIR) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingRcVerticalDir error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    /**
     * 设置云台开启/禁用 声音
     *
     * @param soundMode
     * @return
     */
    fun ptzSetSettingSoundEnable(soundMode: PtzSoundMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_SOUND_ENABLE)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzSettingsWriteReqMsg(soundMode.nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_SOUND_ENABLE) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingSoundEnable error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    /**
     * 设置横竖屏
     *
     * @param mode
     * @return
     */
    fun ptzSetSettingHvMode(mode: PtzHvMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_HV_MODE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(mode.nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_HV_MODE) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingHvMode error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    /**
     * 设置切换模式
     *
     * @param mode
     * @return
     */
    fun ptzSetSettingSwitchModeWay(mode: PtzSwitchModeWay): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_SWITCH_MODE_WAY)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(mode.nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_SWITCH_MODE_WAY) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingSwitchModeWay error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    /**
     * 设置Led灯亮度
     *
     * @param brightness 范围为0-100，对可调亮度的灯，0-100对应亮度。对不可调亮度的灯，0：灭，其他亮。
     * @return
     */
    fun ptzSetSettingLedBrightness(brightness: Int): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_LED)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(brightness.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_LED) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingLed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingMotorStrength(motorStrength: PtzMotorStrength): Long {
        val nativeValue = motorStrength.ordinal.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_MOTOR_STRENGTH)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_MOTOR_STRENGTH) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingRcSpeed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    /***
     * 设置一键环拍数据
     * @param surroundShoot
     * @return
     */
    fun ptzSetSettingSurroundShot(surroundShoot: PtzSurroundShoot): Long {
        val nativeValue = surroundShoot.nativeValue.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_YAW_300)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_YAW_300) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingSurroundShot error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingRollSpeed(rollSpeed: PtzRoll360): Long {
        val nativeValue = rollSpeed.nativeValue.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_ROLL_SPEED)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_ROLL_SPEED) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingRollSpeed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingQuickStart(quickStart: PtzQuickStart): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_QUICK_START_ENABLE)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzSettingsWriteReqMsg(quickStart.nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_QUICK_START_ENABLE) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingQuickStart error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzSetSettingPitchLed(pitchLed: PtzPitchLed): Long {
        val nativeValue = pitchLed.ordinal.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_PITCH_LED)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_PITCH_LED) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingPitchLed error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    /***
     * FMG 记忆横竖屏
     * @param ptzEnableSaveHv
     * @return
     */
    fun ptzSetSettingEnableSaveHv(ptzEnableSaveHv: PtzEnableSaveHv): Long {
        val nativeValue = ptzEnableSaveHv.nativeValue.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SETTINGS_WRITE, PtzFrame.SF_ENABLE_SAVE_HV)
        val ptzDataReqMessage: PtzDataReqMessage = PtzSettingsWriteReqMsg(nativeValue.toByte())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.SF_ENABLE_SAVE_HV) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetSettingEnableSaveHv error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_SETTINGS,
                        frame.toInt(),
                        FmgSetSettingsResp(requestId)
                    )
                }
            }
        })
    }

    // 水平微调获取角度
    fun ptzGetVerticalTrimDegree(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_VERTICAL_TRIM, PtzFrame.VERTICAL_TRIM_GET)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.VERTICAL_TRIM_GET) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzVerticalTrimRespMsg) {
                        val getVerticalTrimDegreeResp =
                            FmgGetVerticalTrimDegreeResp(requestId, dataRespMessage.degrees / 10f)
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_VERTICAL_TRIM_DEGREE,
                            Error.ERR_NONE,
                            getVerticalTrimDegreeResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetVerticalTrimDegree error, frame = " + formatValueToHex(frame))
                val getVerticalTrimDegreeResp = FmgGetVerticalTrimDegreeResp(requestId)
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_VERTICAL_TRIM_DEGREE,
                    frame.toInt(),
                    getVerticalTrimDegreeResp
                )
            }
        })
    }

    // 水平微调设置角度
    fun ptzSetVerticalTrimDegree(degree: Float): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_VERTICAL_TRIM, PtzFrame.VERTICAL_TRIM_SET)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzVerticalTrimReqMsg((degree * 10).toInt().toShort())
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_VERTICAL_TRIM_DEGREE,
                        Error.ERR_NONE,
                        FmgSetVerticalTrimDegreeResp(requestId)
                    )
                } else {
                    BleLog.e("ptzSetVerticalTrimDegree error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_VERTICAL_TRIM_DEGREE,
                        frame.toInt(),
                        FmgSetVerticalTrimDegreeResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzStartOrUpdateTargetFollow(followParams: FmgTargetFollowParams) {
        val currentTimeMillis = currentTimeMillis()
        if (mStartTargetFollowTime == -1L) {
            mStartTargetFollowTime = currentTimeMillis
        }
        val pos_x = followParams.posX.toShort()
        val pos_y = followParams.posY.toShort()
        val scale = (followParams.scale * 10).toInt().toShort()
        val width = followParams.width.toShort()
        val height = followParams.height.toShort()
        val app_millis = currentTimeMillis - mStartTargetFollowTime
        val composition = followParams.composition
        mTargetFollowId++
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TARGETS_FOLLOW, PtzFrame.TF_NORMAL)
        val ptzDataReqMessage: PtzDataReqMessage = PtzTargetsFollowReqMsg(
            pos_x,
            pos_y,
            scale,
            width,
            height,
            followParams.followType!!.nativeValue,
            followParams.isFront,
            app_millis,
            mTargetFollowId.toInt(),
            composition
        )
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, null)
    }

    fun ptzLostTargetFollow() {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TARGETS_FOLLOW, PtzFrame.TF_LOST)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                BleLog.d("ptzLostTargetFollow response, frame = " + formatValueToHex(frame))
            }
        })
    }

    fun ptzCompositionTargetFollow() {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TARGETS_FOLLOW, PtzFrame.TF_COMPOSITION)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                BleLog.d("ptzCompositionTargetFollow response, frame = " + formatValueToHex(frame))
            }
        })
    }

    fun ptzExitTargetFollow() {
        clearRequestQueueByCmd(PtzCmd.CMD_TARGETS_FOLLOW)
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TARGETS_FOLLOW, PtzFrame.TF_EXIT)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                BleLog.d("ptzExitTargetFollow response, frame = " + formatValueToHex(frame))
            }
        })
        resetTargetFollowData()
    }

    fun ptzSpeculateTargetFollow(followParams: FmgTargetFollowParams) {
        val currentTimeMillis = currentTimeMillis()
        if (mStartTargetFollowTime == -1L) {
            mStartTargetFollowTime = currentTimeMillis
        }
        val pos_x = followParams.posX.toShort()
        val pos_y = followParams.posY.toShort()
        val scale = (followParams.scale * 10).toInt().toShort()
        val width = followParams.width.toShort()
        val height = followParams.height.toShort()
        val app_millis = currentTimeMillis - mStartTargetFollowTime
        val composition = followParams.composition
        mTargetFollowId++
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TARGETS_FOLLOW, PtzFrame.TF_SPECULATE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzTargetsFollowReqMsg(
            pos_x,
            pos_y,
            scale,
            width,
            height,
            followParams.followType!!.nativeValue,
            followParams.isFront,
            app_millis,
            mTargetFollowId.toInt(),
            composition
        )
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, null)
    }

    private fun resetTargetFollowData() {
        mStartTargetFollowTime = -1L
        mTargetFollowId = -1
    }

    fun ptzStartCalibrate(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GIMBAL_CAL, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_START_CALIBRATE,
                        Error.ERR_NONE,
                        FmgStartCalibrateResp(requestId)
                    )
                } else {
                    BleLog.e("ptzStartCalibrate error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_START_CALIBRATE,
                        frame.toInt(),
                        FmgStartCalibrateResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzGetAnalyticsData(): Long {
        val requestId = generateRequestId()
        ptzGetEtdItemHeader(requestId)
        return requestId
    }

    private fun ptzGetEtdItemHeader(requestId: Long) {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_HEADER)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_HEADER) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdHeaderRespMsg) {
                        val ptzGetEtdHeaderRespMsg = dataRespMessage
                        BleLog.d("ptzGetEtdItemHeader result = $ptzGetEtdHeaderRespMsg")
                        val fmgAnalyticsParams = FmgAnalyticsParams()
                        fmgAnalyticsParams.totalPowerOnTimes = ptzGetEtdHeaderRespMsg.power_on_cnt
                        fmgAnalyticsParams.fastPowerOnTimes =
                            ptzGetEtdHeaderRespMsg.fast_power_on_cnt
                        fmgAnalyticsParams.keyPowerOnTimes = ptzGetEtdHeaderRespMsg.key_power_on_cnt
                        fmgAnalyticsParams.totalPowerOffTimes = ptzGetEtdHeaderRespMsg.power_off_cnt
                        fmgAnalyticsParams.fastPowerOffTimes =
                            ptzGetEtdHeaderRespMsg.fast_power_off_cnt
                        fmgAnalyticsParams.keyPowerOffTimes =
                            ptzGetEtdHeaderRespMsg.key_power_off_cnt
                        fmgAnalyticsParams.forcePowerOffTimes =
                            ptzGetEtdHeaderRespMsg.force_power_off_cnt
                        fmgAnalyticsParams.fastPowerOnEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.fast_power_on_etd_length)
                        fmgAnalyticsParams.keyPowerOnEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.key_power_on_etd_length)
                        fmgAnalyticsParams.fastPowerOffEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.fast_power_off_etd_length)
                        fmgAnalyticsParams.keyPowerOffEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.key_power_off_etd_length)
                        fmgAnalyticsParams.forcePowerOffEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.force_power_off_etd_length)
                        fmgAnalyticsParams.errorStateEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.err_etd_length)
                        fmgAnalyticsParams.cfEventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.cf_etd_length)
                        fmgAnalyticsParams.yaw360EventArray =
                            arrayOfNulls(ptzGetEtdHeaderRespMsg.yaw_360_length)
                        ptzGetEtdItemFastPowerOn(requestId, fmgAnalyticsParams, 0)
                        return
                    }
                }
                BleLog.e("ptzGetEtdItemHeader error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemFastPowerOn(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.fastPowerOnEventArray.size) {
            ptzGetEtdItemKeyPowerOn(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_FPON)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            fmgAnalyticsParams.fastPowerOnEventArray.size - startIndex
        )
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_FPON) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdPowerOnEventRespMsg) {
                        val powerOnEventParamsArray = dataRespMessage.powerOnEventParamsArray
                        if (powerOnEventParamsArray!!.size > 0) {
                            for (i in powerOnEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.fastPowerOnEventArray.size) {
                                    val powerOnEventParams = powerOnEventParamsArray[i]
                                    val powerOnEvent = PowerOnEvent(powerOnEventParams!!)
                                    fmgAnalyticsParams.fastPowerOnEventArray[destPos] = powerOnEvent
                                }
                            }
                            ptzGetEtdItemFastPowerOn(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + powerOnEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemKeyPowerOn(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }
                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemFastPowerOn cmd invalid, ignored")
                    ptzGetEtdItemKeyPowerOn(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemFastPowerOn error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemKeyPowerOn(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.keyPowerOnEventArray.size) {
            ptzGetEtdItemFastPowerOff(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_KPON)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            fmgAnalyticsParams.keyPowerOnEventArray.size - startIndex
        )
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_KPON) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdPowerOnEventRespMsg) {
                        val powerOnEventParamsArray = dataRespMessage.powerOnEventParamsArray
                        if (powerOnEventParamsArray!!.size > 0) {
                            for (i in powerOnEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.keyPowerOnEventArray.size) {
                                    val powerOnEventParams = powerOnEventParamsArray[i]
                                    val powerOnEvent = PowerOnEvent(powerOnEventParams!!)
                                    fmgAnalyticsParams.keyPowerOnEventArray[destPos] = powerOnEvent
                                }
                            }
                            ptzGetEtdItemKeyPowerOn(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + powerOnEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemFastPowerOff(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }
                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemKeyPowerOn cmd invalid, ignored")
                    ptzGetEtdItemFastPowerOff(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemKeyPowerOn error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemFastPowerOff(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.fastPowerOffEventArray.size) {
            ptzGetEtdItemKeyPowerOff(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_FPO)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            fmgAnalyticsParams.fastPowerOffEventArray.size - startIndex
        )
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_FPO) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdPowerOffEventRespMsg) {
                        val powerOffEventParamsArray = dataRespMessage.powerOffEventParamsArray
                        if (powerOffEventParamsArray!!.size > 0) {
                            for (i in powerOffEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.fastPowerOffEventArray.size) {
                                    val powerOffEventParams = powerOffEventParamsArray[i]
                                    val powerOffEvent = PowerOffEvent(
                                        powerOffEventParams!!
                                    )
                                    fmgAnalyticsParams.fastPowerOffEventArray[destPos] =
                                        powerOffEvent
                                }
                            }
                            ptzGetEtdItemFastPowerOff(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + powerOffEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemKeyPowerOff(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }

                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemFastPowerOff cmd invalid, ignored")
                    ptzGetEtdItemKeyPowerOff(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemFastPowerOff error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemKeyPowerOff(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.keyPowerOffEventArray.size) {
            ptzGetEtdItemForcePowerOff(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_KPO)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            fmgAnalyticsParams.keyPowerOffEventArray.size - startIndex
        )
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_KPO) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdPowerOffEventRespMsg) {
                        val powerOffEventParamsArray = dataRespMessage.powerOffEventParamsArray
                        if (powerOffEventParamsArray!!.size > 0) {
                            for (i in powerOffEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.keyPowerOffEventArray.size) {
                                    val powerOffEventParams = powerOffEventParamsArray[i]
                                    val powerOffEvent = PowerOffEvent(
                                        powerOffEventParams!!
                                    )
                                    fmgAnalyticsParams.keyPowerOffEventArray[destPos] =
                                        powerOffEvent
                                }
                            }
                            ptzGetEtdItemKeyPowerOff(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + powerOffEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemForcePowerOff(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }

                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemKeyPowerOff cmd invalid, ignored")
                    ptzGetEtdItemForcePowerOff(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemKeyPowerOff error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemForcePowerOff(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.forcePowerOffEventArray.size) {
            ptzGetEtdItemErrorState(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_FOPO)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            fmgAnalyticsParams.forcePowerOffEventArray.size - startIndex
        )
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_FOPO) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdPowerOffEventRespMsg) {
                        val powerOffEventParamsArray = dataRespMessage.powerOffEventParamsArray
                        if (powerOffEventParamsArray!!.size > 0) {
                            for (i in powerOffEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.forcePowerOffEventArray.size) {
                                    val powerOffEventParams = powerOffEventParamsArray[i]
                                    val powerOffEvent = PowerOffEvent(
                                        powerOffEventParams!!
                                    )
                                    fmgAnalyticsParams.forcePowerOffEventArray[destPos] =
                                        powerOffEvent
                                }
                            }
                            ptzGetEtdItemForcePowerOff(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + powerOffEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemErrorState(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }

                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemForcePowerOff cmd invalid, ignored")
                    ptzGetEtdItemErrorState(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemForcePowerOff error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemErrorState(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.errorStateEventArray.size) {
            ptzGetEtdItemCfState(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_ERR)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            fmgAnalyticsParams.errorStateEventArray.size - startIndex
        )
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_ERR) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdErrorStateEventRespMsg) {
                        val errorStateEventParamsArray = dataRespMessage.errorStateEventParamsArray
                        if (errorStateEventParamsArray!!.size > 0) {
                            for (i in errorStateEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.errorStateEventArray.size) {
                                    val errorStateEventParams = errorStateEventParamsArray[i]
                                    val errorStateEvent = ErrorStateEvent(
                                        errorStateEventParams!!
                                    )
                                    fmgAnalyticsParams.errorStateEventArray[destPos] =
                                        errorStateEvent
                                }
                            }
                            ptzGetEtdItemErrorState(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + errorStateEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemCfState(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }

                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemErrorState cmd invalid, ignored")
                    ptzGetEtdItemCfState(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemErrorState error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemCfState(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.cfEventArray.size) {
            ptzGetEtdItemYaw360State(requestId, fmgAnalyticsParams, 0)
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_CF)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzGetEtdEventReqMsg(startIndex, fmgAnalyticsParams.cfEventArray.size - startIndex)
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_CF) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdCFEventRespMsg) {
                        val cfEventParamsArray = dataRespMessage.cFEventParamsArray
                        if (cfEventParamsArray!!.size > 0) {
                            for (i in cfEventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.cfEventArray.size) {
                                    val cfEventParams = cfEventParamsArray[i]
                                    val cfEvent = CFEvent(cfEventParams!!)
                                    fmgAnalyticsParams.cfEventArray[destPos] = cfEvent
                                }
                            }
                            ptzGetEtdItemCfState(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + cfEventParamsArray.size
                            )
                        } else {
                            ptzGetEtdItemYaw360State(requestId, fmgAnalyticsParams, 0)
                        }
                        return
                    }
                }
                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemCfState cmd invalid, ignored")
                    ptzGetEtdItemYaw360State(requestId, fmgAnalyticsParams, 0)
                    return
                }
                BleLog.e("ptzGetEtdItemCfState error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    private fun ptzGetEtdItemYaw360State(
        requestId: Long,
        fmgAnalyticsParams: FmgAnalyticsParams,
        startIndex: Int,
    ) {
        if (startIndex >= fmgAnalyticsParams.yaw360EventArray.size) {
            BleLog.i("[ptzGetEtdItemYaw360State] startIndex >= fmgAnalyticsParams.yaw360EventArray.length")
            mOneDriver.driverInfoNotify(
                InfoType.FMG_GET_ANALYTICS_DATA,
                Error.ERR_NONE,
                FmgGetAnalyticsDataResp(requestId, fmgAnalyticsParams)
            )
            return
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD, PtzFrame.ETD_ITEM_YAW_360)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzGetEtdEventReqMsg(startIndex, fmgAnalyticsParams.yaw360EventArray.size - startIndex)
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_ITEM_YAW_360) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdYaw360EventRespMsg) {
                        val yaw360EventParamsArray = dataRespMessage.yaw360EventParamsArray
                        if (yaw360EventParamsArray!!.size > 0) {
                            for (i in yaw360EventParamsArray.indices) {
                                val destPos = startIndex + i
                                if (destPos < fmgAnalyticsParams.yaw360EventArray.size) {
                                    val yaw360EventParams = yaw360EventParamsArray[i]
                                    val yaw360Event = Yaw360Event(yaw360EventParams!!)
                                    fmgAnalyticsParams.yaw360EventArray[destPos] = yaw360Event
                                }
                            }
                            ptzGetEtdItemYaw360State(
                                requestId,
                                fmgAnalyticsParams,
                                startIndex + yaw360EventParamsArray.size
                            )
                        } else {
                            mOneDriver.driverInfoNotify(
                                InfoType.FMG_GET_ANALYTICS_DATA,
                                Error.ERR_NONE,
                                FmgGetAnalyticsDataResp(requestId, fmgAnalyticsParams)
                            )
                        }
                        return
                    }
                }
                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemYaw360State cmd invalid, ignored")
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_GET_ANALYTICS_DATA,
                        Error.ERR_NONE,
                        FmgGetAnalyticsDataResp(requestId, fmgAnalyticsParams)
                    )
                    return
                }
                BleLog.e("ptzGetEtdItemYaw360State error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null)
                )
            }
        })
    }

    /**
     * 清除 FMG 主板埋点数据
     * @return requestId
     */
    fun ptzClearAnalyticsData(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_CLEAR_ETD, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    BleLog.d("ptzClearAnalyticsData success")
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_CLEAR_ANALYTICS_DATA,
                        requestId,
                        Error.ERR_NONE,
                        null
                    )
                } else {
                    BleLog.e("ptzClearAnalyticsData error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_CLEAR_ANALYTICS_DATA,
                        requestId,
                        frame.toInt(),
                        null
                    )
                }
            }
        })
    }

    /**
     * 清除 FMG 蓝牙应用埋点数据
     * @return requestId
     */
    fun ptzClearBleAnalyticsData(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_CLEAR_ETD_BLE, PtzFrame.REQ_NONE)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    BleLog.d("ptzClearBleAnalyticsData success")
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_CLEAR_ANALYTICS_DATA,
                        requestId,
                        Error.ERR_NONE,
                        null
                    )
                } else {
                    BleLog.e("ptzClearBleAnalyticsData error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_CLEAR_ANALYTICS_DATA,
                        requestId,
                        frame.toInt(),
                        null
                    )
                }
            }
        })
    }


    private enum class FmgUpgradeStep {
        RESET, SHAKE_HAND, UPDATE_INFO, UPDATING, UPDATED, REBOOT
    }

    private interface FmgUpgradeStepCallback {
        fun onFmgUpgradeStepSuccess(
            state: FmgUpgradeStep,
            requestId: Long,
            responseDataPacket: PtzDataPacket,
        )
    }

    private var mFmgUpgradeBean: FmgUpgradeBean? = null
    private var indexPackage = 0

    /**
     * 固件升级V2 FmgPlus 及之后的Fmg2 使用该函数升级；
     * fileData 中包含了多个升级包 FmgUpgradeBean() 中进行包的拆分；
     * 每段 固件包 都需要
     *
     * @param fileData
     * @return
     */
    private var mFmgUpgradeStepCallback: FmgUpgradeStepCallback? = null

    fun startFmgUpgrade(
        fileData: ByteArray,
        writeWithoutResponse: Boolean,
        mtu: Int,
        writeExtraBleOTA: Boolean,
    ): Long {
        //OTA升级时发心跳包会写入失败，影响固件升级
        ptzStopHeartBeat()
        mDuringUpgrading.value = (true)
        indexPackage = 0
        val requestId = generateRequestId()
        post {
            BleLog.d("start FMG upgrade, requestId = $requestId")
            val copyData = fileData.copyOf(fileData.size)
            val fmgUpgradeBean =
                FmgUpgradeBean(requestId, copyData, writeWithoutResponse, mtu, writeExtraBleOTA)
            mFmgUpgradeBean = fmgUpgradeBean
            if (fmgUpgradeBean.isValid) {
                mFmgUpgradeStepCallback = object : FmgUpgradeStepCallback {
                    override fun onFmgUpgradeStepSuccess(
                        state: FmgUpgradeStep,
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        post {
                            BleLog.d(
                                "onFmgUpgradeStepSuccess state = " + state.name + ", frame = " + formatValueToHex(
                                    responseDataPacket.frame
                                )
                            )
                            val fmgUpgradeBean: FmgUpgradeBean?
                            when (state) {
                                FmgUpgradeStep.RESET -> ptzUpdateHandShakeStep1(
                                    requestId,
                                    mFmgUpgradeStepCallback!!
                                )

                                FmgUpgradeStep.SHAKE_HAND -> {
                                    fmgUpgradeBean = mFmgUpgradeBean
                                    if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                                        ptzUpdateInfo(
                                            requestId,
                                            fmgUpgradeBean.getOTAFileDataByIndex(indexPackage),
                                            mFmgUpgradeStepCallback!!
                                        )
                                    } else {
                                        notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                    }
                                }

                                FmgUpgradeStep.UPDATE_INFO -> {
                                    fmgUpgradeBean = mFmgUpgradeBean
                                    if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                                        ptzUpdating(
                                            requestId,
                                            fmgUpgradeBean.getOTAFileDataByIndex(indexPackage)!!,
                                            0,
                                            mFmgUpgradeStepCallback!!
                                        )
                                    } else {
                                        notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                    }
                                }

                                FmgUpgradeStep.UPDATING -> ptzUpdated(
                                    requestId,
                                    mFmgUpgradeStepCallback!!
                                )

                                FmgUpgradeStep.UPDATED -> ptzUpdateReboot(
                                    requestId,
                                    mFmgUpgradeStepCallback!!
                                )

                                FmgUpgradeStep.REBOOT -> {
                                    fmgUpgradeBean = mFmgUpgradeBean
                                    if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                                        if (fmgUpgradeBean.isWriteExtraBleOTA) {
                                            startExtraBleUpgrade(
                                                requestId,
                                                fmgUpgradeBean.getOTAFileDataByIndex(1)!!
                                            )
                                        } else {
                                            mPtzWriteCharacteristic = null
                                            indexPackage++
                                            if (indexPackage < fmgUpgradeBean.upgradePartSize) {
                                                registerPtzBle(
                                                    mBleDevice,
                                                    object : RegisterBleCallback {
                                                        override fun onRegisterSuccess() {
                                                            if (mFmgUpgradeStepCallback != null) {
                                                                postDelayed(1000) {
                                                                    ptzUpdateReset(
                                                                        requestId,
                                                                        mFmgUpgradeStepCallback!!
                                                                    )
                                                                }
                                                            }
                                                        }

                                                        override fun onRegisterFailure(exception: BleExceptionCore?) {
                                                            notifyOTAError(
                                                                requestId,
                                                                OtaStatus.OTA_FAIL_BLE_INDICATE_FAILURE.toInt()
                                                            )
                                                        }
                                                    })
                                            } else {
                                                notifyOTASuccess(requestId)
                                            }
                                        }
                                    } else {
                                        notifyOTAError(requestId, responseDataPacket.frame.toInt())
                                    }
                                }
                            }
                        }
                    }
                }
                ptzUpdateReset(requestId, mFmgUpgradeStepCallback)
            } else {
                notifyOTAError(requestId, PtzFrame.ACK_ERR_LENGTH.toInt())
            }
        }
        return requestId
    }

    fun cancelFmgUpgrade() {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null) {
            BleLog.d("cancel FMG upgrade")
            notifyOTACancel(fmgUpgradeBean.requestId)
        }
        mFmgUpgradeBean = null
    }

    private fun ptzUpdateReset(requestId: Long, callback: FmgUpgradeStepCallback?) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_UPDATE_RESET, PtzFrame.REQ_UPDATE_RESET)
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateResetReqMsg()
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback?.onFmgUpgradeStepSuccess(
                                    FmgUpgradeStep.RESET,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e("ptzUpdateReset error, frame = " + formatValueToHex(frame))
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                })
        }
    }

    private fun ptzUpdateHandShakeStep1(requestId: Long, callback: FmgUpgradeStepCallback) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val phoneBrandValue: Short = FmgPhoneEnum.Companion.findByKey(Build.BRAND).value
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_UPDATE_SHAKE_HAND, PtzFrame.REQ_SHAKE_HAND_STEP_1)
            val ptzDataReqMessage: PtzDataReqMessage =
                PtzUpDateShakeHandReqMsg(PtzStatus.PROTOCOL, phoneBrandValue, PtzBps.SHAKE_HAND)
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_SHAKE_HAND) {
                                ptzUpdateHandShakeStep2(requestId, callback)
                            } else {
                                BleLog.e(
                                    "ptzUpdateHandShakeStep1 error, frame = " + formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                })
        }
    }

    private fun ptzUpdateHandShakeStep2(requestId: Long, callback: FmgUpgradeStepCallback) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val phoneBrandValue: Short = FmgPhoneEnum.Companion.findByKey(Build.BRAND).value
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_UPDATE_SHAKE_HAND, PtzFrame.REQ_SHAKE_HAND_STEP_2)
            val ptzDataReqMessage: PtzDataReqMessage =
                PtzUpDateShakeHandReqMsg(PtzStatus.PROTOCOL, phoneBrandValue, PtzBps.SHAKE_HAND)
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_SHAKE_HAND) {
                                callback.onFmgUpgradeStepSuccess(
                                    FmgUpgradeStep.SHAKE_HAND,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e(
                                    "ptzUpdateHandShakeStep2 error, frame = " + formatValueToHex(
                                        frame
                                    )
                                )
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                })
        }
    }

    private fun ptzUpdateInfo(
        requestId: Long,
        fileData: ByteArray?,
        callback: FmgUpgradeStepCallback,
    ) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val updateInfoSize: Int = PtzUpdateInfoReqMsg.Companion.UPDATE_INFO_DATA_SIZE
            if (fileData == null || fileData.size < updateInfoSize) {
                BleLog.e("ptzUpdateInfo error, " + (if (fileData == null) "fileDara is null" else ("fileData size error =" + fileData.size)))
                notifyOTAError(requestId, PtzFrame.ACK_ERR_LENGTH.toInt())
                return
            }
            val updateInfo =
                fileData.sliceArray((fileData.size - updateInfoSize) until fileData.size)

            val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_UPDATE_INFO, PtzFrame.REQ_UPDATE_INFO)
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateInfoReqMsg(updateInfo)
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_NEED_UPDATE) {
                                callback.onFmgUpgradeStepSuccess(
                                    FmgUpgradeStep.UPDATE_INFO,
                                    requestId,
                                    responseDataPacket
                                )
                            } else if (frame == PtzFrame.ACK_NO_NEED_UPDATE) {
                                fmgUpgradeBean.addUploadedDataSize(fileData.size)
                                notifyOTAProgressChanged(requestId)
                                callback.onFmgUpgradeStepSuccess(
                                    FmgUpgradeStep.REBOOT,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e("ptzUpdateInfo error, frame = " + formatValueToHex(frame))
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                },
                UPGRADE_TIMEOUT_MS,
                false
            )
        }
    }

    private fun ptzUpdating(
        requestId: Long,
        remainingFileData: ByteArray,
        packetSerial: Int,
        callback: FmgUpgradeStepCallback,
    ) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val maxPacketSize = fmgUpgradeBean.writeUpgradeMTU
            val packetData = remainingFileData.copyOfRange(
                0,
                min(remainingFileData.size, maxPacketSize)
            )


            val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_UPDATING, packetSerial.toShort())
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateingReqMsg(packetData)
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK || frame == PtzFrame.ACK_ERR_INVALID_FRAME) {
                                fmgUpgradeBean.addUploadedDataSize(packetData.size)
                                val remainDataSize = remainingFileData.size - packetData.size
                                notifyOTAProgressChanged(requestId)
                                if (remainDataSize > 0) {
                                    val newFileData = remainingFileData.copyOfRange(
                                        fromIndex = (remainingFileData.size - remainDataSize),
                                        toIndex = remainingFileData.size
                                    )
                                    ptzUpdating(requestId, newFileData, packetSerial + 1, callback)
                                } else {
                                    callback.onFmgUpgradeStepSuccess(
                                        FmgUpgradeStep.UPDATING,
                                        requestId,
                                        responseDataPacket
                                    )
                                }
                            } else {
                                BleLog.e("ptzUpdating error, frame = " + formatValueToHex(frame))
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                },
                3000L,
                !fmgUpgradeBean.isWriteUpgradeWithoutResponse
            )
        }
    }

    private fun ptzUpdated(requestId: Long, callback: FmgUpgradeStepCallback) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_UPDATED, PtzFrame.REQ_UPDATED)
            val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback.onFmgUpgradeStepSuccess(
                                    FmgUpgradeStep.UPDATED,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e("ptzUpdated error, frame = " + formatValueToHex(frame))
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                },
                UPGRADE_TIMEOUT_MS,
                false
            )
        }
    }

    private fun ptzUpdateReboot(requestId: Long, callback: FmgUpgradeStepCallback) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_UPDATE_REBOOT, PtzFrame.REQ_UPDATE_REBOOT)
            val ptzDataReqMessage: PtzDataReqMessage = PtzUpdateRebootReqMsg()
            addNewRequestTask(
                requestId,
                ptzDataPacket,
                ptzDataReqMessage,
                object : IRequestCallback {
                    override fun onRequestCallback(
                        requestId: Long,
                        responseDataPacket: PtzDataPacket,
                    ) {
                        val fmgUpgradeBean = mFmgUpgradeBean
                        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                            val frame = responseDataPacket.frame
                            if (frame == PtzFrame.ACK_OK) {
                                callback.onFmgUpgradeStepSuccess(
                                    FmgUpgradeStep.REBOOT,
                                    requestId,
                                    responseDataPacket
                                )
                            } else {
                                BleLog.e("ptzUpdateReboot error, frame = " + formatValueToHex(frame))
                                notifyOTAError(requestId, frame.toInt())
                            }
                        }
                    }
                },
                UPGRADE_TIMEOUT_MS,
                false
            )
        }
    }

    private fun notifyOTASuccess(requestId: Long) {
        indexPackage = 0
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            mOneDriver.driverInfoNotify(
                InfoType.FMG_OTA_COMPLETE,
                Error.ERR_NONE, FmgOTACompleteResp(requestId, Error.ERR_NONE)
            )
        }
        mDuringUpgrading.value = (false)
        mFmgUpgradeBean = null
    }

    private fun notifyOTAError(requestId: Long, error: Int) {
        indexPackage = 0
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            mOneDriver.driverInfoNotify(
                InfoType.FMG_OTA_COMPLETE,
                Error.ERR_CAMERA_RESPONSE_ERROR, FmgOTACompleteResp(requestId, error)
            )
        }
        mDuringUpgrading.value = (false)
        mFmgUpgradeBean = null
    }

    private fun notifyOTAProgressChanged(requestId: Long) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            val percent = fmgUpgradeBean.upgradedDataSize / 1f / fmgUpgradeBean.upgradeFileTotalSize
            mOneDriver.driverInfoNotify(
                InfoType.FMG_OTA_PROGRESS_CHANGE,
                Error.ERR_NONE, FmgOTAProgressChangedResp(requestId, percent)
            )
        }
    }

    private fun notifyOTACancel(requestId: Long) {
        val fmgUpgradeBean = mFmgUpgradeBean
        if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
            mOneDriver.driverInfoNotify(
                InfoType.FMG_OTA_CANCEL,
                Error.ERR_NONE, FmgOTACancelResp(requestId)
            )
        }
        mFmgUpgradeBean = null
    }

    fun startAITrackUpgrade(aiTrackUpgradeConfig: AITrackUpgradeConfig): Long {
        //OTA升级时发心跳包会写入失败，影响固件升级
        ptzStopHeartBeat()
        mDuringUpgrading.value = (true)
        return mAITrackerUpgradeDelegate.startUpgrade(
            aiTrackUpgradeConfig,
            object : IAITrackerUpgradeCallback {
                override fun onProgressChanged(requestId: Long, progress: Float) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_OTA_AI_TRACK_PROGRESS_CHANGE,
                        Error.ERR_NONE, FmgOTAProgressChangedResp(requestId, progress)
                    )
                }

                override fun onCancel(requestId: Long) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_OTA_AI_TRACK_CANCEL,
                        Error.ERR_NONE, FmgOTACancelResp(requestId)
                    )
                }

                override fun onUpgradeError(requestId: Long, error: Int) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_OTA_AI_TRACK_COMPLETE,
                        Error.ERR_CAMERA_RESPONSE_ERROR, FmgOTACompleteResp(requestId, error)
                    )
                }

                override fun onUpgradeSuccess(requestId: Long) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_OTA_AI_TRACK_COMPLETE,
                        Error.ERR_NONE, FmgOTACompleteResp(requestId, Error.ERR_NONE)
                    )
                }
            })
    }

    fun cancelAITrackUpgrade() {
        mAITrackerUpgradeDelegate.cancelUpgrade()
    }

    fun ptzSetButtonEnable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        val dataPari = getButtonAbleFrame(fmgButtonAbleParams)
        return if (dataPari != null) {
            setButtonEnable(dataPari)
        } else {
            -1
        }
    }

    private fun setButtonEnable(dataPari: Pair<Int, List<Int>>): Long {
        val frame = dataPari.first
        val data = IntArray(dataPari.second.size)
        for (i in data.indices) {
            data[i] = dataPari.second[i]
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_EVENT_EANBLE, frame.toShort())
        val ptzDataReqMessage = PtzButtonAbleReqMsg(data)
        BleLog.d(
            "ptzSetButtonEnable frame:" + frame + " data:" + FmgByteUtils.bytes2hexDebug(
                ptzDataPacket.packetPack(ptzDataReqMessage.packData())
            )
        )
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_BUTTON_ENABLE,
                        requestId,
                        Error.ERR_NONE,
                        null
                    )
                } else {
                    BleLog.e("ptzSetButtonEnable error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_BUTTON_ENABLE,
                        requestId,
                        frame.toInt(),
                        null
                    )
                }
            }
        })
    }

    fun ptzSetButtonDisable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        val dataPari = getButtonAbleFrame(fmgButtonAbleParams)
        return if (dataPari != null) {
            setButtonDisable(dataPari)
        } else {
            -1
        }
    }

    private fun setButtonDisable(dataPari: Pair<Int, List<Int>>): Long {
        val frame = dataPari.first
        val data = IntArray(dataPari.second.size)
        for (i in data.indices) {
            data[i] = dataPari.second[i]
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_EVENT_DISABLE, frame.toShort())
        val ptzDataReqMessage = PtzButtonAbleReqMsg(data)
        BleLog.d(
            "ptzSetButtonDisable frame:" + frame + " data:" + FmgByteUtils.bytes2hexDebug(
                ptzDataPacket.packetPack(ptzDataReqMessage.packData())
            )
        )
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                if (frame == PtzFrame.ACK_OK.toInt()) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_BUTTON_DISABLE,
                        requestId,
                        Error.ERR_NONE,
                        null
                    )
                } else {
                    BleLog.e("ptzSetButtonDisable error, frame = " + formatValueToHex(frame.toShort()))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_BUTTON_DISABLE,
                        requestId,
                        frame.toInt(),
                        null
                    )
                }
            }
        })
    }

    fun setDwSrcEventState(enable: Boolean): Long {
        val ptzDataPacket = PtzDataPacket(
            PtzCmd.CMD_DW_DATA,
            if (enable) PtzFrame.DW_SRC_VALUE_ENABLE else PtzFrame.DW_SRC_VALUE_DISABLE
        )
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ACK_OK) {
                    BleLog.e(
                        "setDwSrcEventState onRequestCallback, enable = " + enable + ", frame = " + formatValueToHex(
                            frame
                        )
                    )
                    mOneDriver.driverInfoNotify(
                        if (enable) InfoType.FMG_SET_BUTTON_ENABLE else InfoType.FMG_SET_BUTTON_DISABLE,
                        requestId,
                        Error.ERR_NONE,
                        null
                    )
                } else {
                    BleLog.e(
                        "setDwSrcEventState onRequestCallback error, enable = " + enable + ", frame = " + formatValueToHex(
                            frame
                        )
                    )
                    mOneDriver.driverInfoNotify(
                        if (enable) InfoType.FMG_SET_BUTTON_ENABLE else InfoType.FMG_SET_BUTTON_DISABLE,
                        requestId,
                        frame.toInt(),
                        null
                    )
                }
            }
        })
    }

    val buttonEnableStates: Long
        get() {
            val ptzDataPacket =
                PtzDataPacket(PtzCmd.CMD_GET_EVENT_STATUS, PtzFrame.REQ_NONE)
            val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
            return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
                override fun onRequestCallback(
                    requestId: Long,
                    responseDataPacket: PtzDataPacket,
                ) {
                    val frame = responseDataPacket.frame
                    val getButtonEnableStatusResp =
                        FmgGetButtonEnableStatusResp(requestId)
                    if (frame == PtzFrame.ACK_OK) {
                        BleLog.i(
                            "getButtonEnableState data= " + responseDataPacket.data
                                .contentToString()
                        )
                        val dataRespMessage = responseDataPacket.unPack()
                        if (dataRespMessage is PtzGetButtonEnableRespMsg) {
                            getButtonEnableStatusResp.fmgButtonAbleParams =
                                dataRespMessage.fmgButtonAbleParams
                            mOneDriver.driverInfoNotify(
                                InfoType.FMG_GET_BUTTON_ENABLE_STATE,
                                frame.toInt(),
                                getButtonEnableStatusResp
                            )
                            return
                        }
                    }
                    BleLog.e(
                        "getButtonEnableState error, frame = " + formatValueToHex(
                            frame
                        )
                    )
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_GET_BUTTON_ENABLE_STATE,
                        frame.toInt(),
                        getButtonEnableStatusResp
                    )
                }
            })
        }

    fun ptzGetMidCal(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_MID_CAL, PtzFrame.MID_CAL_GET)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val getMidCalResp = FmgGetMidCalResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzMidcalRespMsg) {
                        getMidCalResp.euler = dataRespMessage.euler
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_MID_CAL,
                            Error.ERR_NONE,
                            getMidCalResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetMidCal error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(InfoType.FMG_GET_MID_CAL, frame.toInt(), getMidCalResp)
            }
        })
    }

    fun ptzSetMidCal(euler: DoubleArray): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_MID_CAL, PtzFrame.MID_CAL_SET)
        val ptzDataReqMessage = PtzMidcalReqMsg(euler)
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val setMidCalResp = FmgSetMidCalResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_MID_CAL,
                        Error.ERR_NONE,
                        setMidCalResp
                    )
                } else {
                    BleLog.e("ptzSetMidCal error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_MID_CAL,
                        frame.toInt(),
                        setMidCalResp
                    )
                }
            }
        })
    }

    fun ptzSetRunControl(state: PtzGrfState, yaw: Float, pitch: Float, roll: Float): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_RC_SET, state.nativeValue)
        val ptzRcSetReqMsg = PtzRcSetReqMsg(yaw, pitch, roll)
        return addNewRequestTask(ptzDataPacket, ptzRcSetReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val setRunControlResp = FmgSetRunControlResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_RC,
                        Error.ERR_NONE,
                        setRunControlResp
                    )
                } else {
                    BleLog.e("ptzSetMidCal error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_RC,
                        frame.toInt(),
                        setRunControlResp
                    )
                }
            }
        })
    }

    fun ptzSetVirtualRc(x: Short, y: Short): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_VIRTUAL_RC, 0x5A.toShort())
        val ptzRcSetVirtualRc = PtzRcSetVirtualRc(x, y)
        return addNewRequestTask(ptzDataPacket, ptzRcSetVirtualRc, null)
    }

    fun ptzGetRunControl(state: PtzGrfState): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_RC_GET, state.nativeValue)
        val ptzEmptyReqMsg = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzEmptyReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val getRunControlResp = FmgGetRunControlResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzRcGetRespMsg) {
                        val ptzRcGetRespMsg = dataRespMessage
                        getRunControlResp.yaw = ptzRcGetRespMsg.yaw
                        getRunControlResp.patch = ptzRcGetRespMsg.pitch
                        getRunControlResp.roll = ptzRcGetRespMsg.roll
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_RC,
                            Error.ERR_NONE,
                            getRunControlResp
                        )
                        return
                    }
                }
                BleLog.e("ptzSetMidCal error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(InfoType.FMG_GET_RC, frame.toInt(), getRunControlResp)
            }
        })
    }


    fun ptzSetTimeElapse(mode: PtzTemMode, state: PtzTemState, duration: Int): Long {
        BleLog.i("ptzSetTimeElapse, mode = ${mode.nativeValue}, state = ${state.nativeValue}, duration = ${duration} ")
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TIME_ELAPSE, PtzFrame.REQ_NONE)
        val ptzTimeElapseReqMsg = PtzTimeElapseReqMsg(mode.nativeValue, state.nativeValue, duration)
        return addNewRequestTask(ptzDataPacket, ptzTimeElapseReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val setTimeElapseResp = FmgSetTimeElapseResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_TIME_ELAPSE,
                        Error.ERR_NONE,
                        setTimeElapseResp
                    )
                } else {
                    BleLog.e("ptzSetMidCal error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_TIME_ELAPSE,
                        frame.toInt(),
                        setTimeElapseResp
                    )
                }
            }
        })
    }


    fun ptzSetPano(mode: PtzPanoMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_PANO, mode.nativeValue)
        return addNewRequestTask(ptzDataPacket, PtzEmptyReqMsg(), object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val fmgSetPanoResp = FmgSetPanoResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(InfoType.FMG_PANO, Error.ERR_NONE, fmgSetPanoResp)
                } else {
                    BleLog.e("ptzSetPano error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(InfoType.FMG_PANO, frame.toInt(), fmgSetPanoResp)
                }
            }
        })
    }

    /**
     * 仅需通知云台进入模式。不关心是否成功
     */
    fun ptzRecModeStart(mode: PtzRecMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_REC_MODE, mode.nativeValue)
        val ptzRecModeReqMsg = PtzRecModeReqMsg(PtzFrame.REC_MODE_START)
        return addNewRequestTask(ptzDataPacket, ptzRecModeReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                BleLog.e("ptzRecModeStart, frame = " + responseDataPacket.frame)
            }
        })
    }

    /**
     * 仅需通知云台退出模式。不关心是否成功
     */
    fun ptzRecModeEnd(mode: PtzRecMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_REC_MODE, mode.nativeValue)
        val ptzRecModeReqMsg = PtzRecModeReqMsg(PtzFrame.REC_MODE_END)
        return addNewRequestTask(ptzDataPacket, ptzRecModeReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                BleLog.e("ptzRecModeEnd, frame = " + responseDataPacket.frame)
            }
        })
    }

    /**
     * 仅需通知云台初始化模式。不关心是否成功
     */
    fun ptzRecModeInit(mode: PtzRecMode): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_REC_MODE, mode.nativeValue)
        val ptzRecModeReqMsg = PtzRecModeReqMsg(PtzFrame.REC_MODE_INIT)
        return addNewRequestTask(ptzDataPacket, ptzRecModeReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                BleLog.e("ptzRecModeInit, frame = " + responseDataPacket.frame)
            }
        })
    }

    fun ptzVibration(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GIMBAL_VIBRATION, PtzFrame.REQ_NONE)
        return addNewRequestTask(ptzDataPacket, PtzEmptyReqMsg(), object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val fmgVibrationResp = FmgVibrationResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_VIBRATION,
                        Error.ERR_NONE,
                        fmgVibrationResp
                    )
                } else {
                    BleLog.e("ptzVibration error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_VIBRATION,
                        frame.toInt(),
                        fmgVibrationResp
                    )
                }
            }
        })
    }

    fun enableHandDrag(list: ArrayList<PtzHandDrag>): Long {
        var frame: Short = 0
        for (i in list.indices) {
            frame = (list[i].nativeValue + frame).toShort()
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ENABLE_HAND_DRAG, frame)
        return addNewRequestTask(ptzDataPacket, PtzEmptyReqMsg(), object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val fmgEnableHandDragResp = FmgEnableHandDragResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.ENABLE_HAND_DRAG,
                        Error.ERR_NONE,
                        fmgEnableHandDragResp
                    )
                } else {
                    BleLog.e("enableHandDrag error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.ENABLE_HAND_DRAG,
                        frame.toInt(),
                        fmgEnableHandDragResp
                    )
                }
            }
        })
    }

    fun disableHandDrag(list: ArrayList<PtzHandDrag>): Long {
        var frame: Short = 0
        for (i in list.indices) {
            frame = (list[i].nativeValue + frame).toShort()
        }
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_DISABLE_HAND_DRAG, frame)
        return addNewRequestTask(ptzDataPacket, PtzEmptyReqMsg(), object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val fmgDisableHandDragResp = FmgDisableHandDragResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.DISABLE_HAND_DRAG,
                        Error.ERR_NONE,
                        fmgDisableHandDragResp
                    )
                } else {
                    BleLog.e("enableHandDrag error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.DISABLE_HAND_DRAG,
                        frame.toInt(),
                        fmgDisableHandDragResp
                    )
                }
            }
        })
    }

    fun ptzSetCameraFacing(frame: Short): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_SET_CAMERA_TYPE, frame)
        return addNewRequestTask(ptzDataPacket, PtzEmptyReqMsg(), object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val setCameraFacingResp = FmgSetCameraFacingResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_CAMERA_FACING,
                        Error.ERR_NONE,
                        setCameraFacingResp
                    )
                } else {
                    BleLog.e("ptzSetCameraFacing error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_CAMERA_FACING,
                        frame.toInt(),
                        setCameraFacingResp
                    )
                }
            }
        })
    }

    fun ptzBackCenter(): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_BACK_CENTER, 0.toShort())
        return addNewRequestTask(ptzDataPacket, PtzEmptyReqMsg(), object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val backCenterResp = FmgBackCenterResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_BACK_CENTER,
                        Error.ERR_NONE,
                        backCenterResp
                    )
                } else {
                    BleLog.e("ptzBackCenter error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_BACK_CENTER,
                        frame.toInt(),
                        backCenterResp
                    )
                }
            }
        })
    }

    fun ptzUpdateAppImuAngle(fmgAngleBean: FmgAngleBean?) {
        this.fmgAngleBean = fmgAngleBean
    }

    fun ptzUpdateAppImuInfo(floats: FloatArray) {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_APP_IMU_INFO, PtzFrame.REQ_NONE)
        val ptzAppImuInfoReqMsg = PtzAppImuInfoReqMsg(floats)
        addNewRequestTask(ptzDataPacket, ptzAppImuInfoReqMsg, null)
    }

    fun ptzSetAngleSeq(paramsList: List<FmgSetAngleSeqBean>): Long {
        if (paramsList.size > 5) {
            BleLog.e("ptzSetAngleSeq error, paramsList size > 5")
            return -1
        }
        val frame = paramsList.size.toShort()
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ANGLE_SEQ_SET, frame)
        val setAngleSeqReqMsg = PtzSetAngleSeqReqMsg(paramsList)
        return addNewRequestTask(ptzDataPacket, setAngleSeqReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val setAngleSeqResp = FmgSetAngleSeqResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_ANGLE_SEQ_SET,
                        PtzFrame.REQ_NONE.toInt(),
                        setAngleSeqResp
                    )
                } else {
                    BleLog.e("ptzSetAngleSeq error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_ANGLE_SEQ_SET,
                        frame.toInt(),
                        setAngleSeqResp
                    )
                }
            }
        })
    }

    fun ptzBasketballA2G(
        mode: PtzBaksetballMode,
        state: PtzBaksetballState,
        transition: PtzBaksetballTransition,
    ): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_BASKETBALL_A2G, 0.toShort())
        val ptzBasketballA2GReqMsg =
            PtzBasketballA2GReqMsg(mode.nativeValue, state.nativeValue, transition.nativeValue)
        return addNewRequestTask(ptzDataPacket, ptzBasketballA2GReqMsg, null)
    }

    fun ptzBasketballInitNoBask() {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_TARGETS_FOLLOW, PtzFrame.TF_LOST)
        val ptzDataReqMessage: PtzDataReqMessage = PtzTargetsFollowReqMsg(
            0.toShort(),
            0.toShort(),
            1.toShort(),
            0.toShort(),
            0.toShort(),
            FollowType.BASKET.nativeValue,
            false,
            0,
            0,
            false
        )
        addNewRequestTask(ptzDataPacket, ptzDataReqMessage, null)
    }

    fun ptzSetPanoIndex(index: Short, frame: PtzPanoIndexFrame): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_PANO_INDEX, frame.nativeValue)
        val setPanoIndexReqMsg = PtzSetPanoIndexReqMsg(index)
        return addNewRequestTask(ptzDataPacket, setPanoIndexReqMsg, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                val setPanoIndexResp = FmgSetPanoIndexResp(requestId)
                if (frame == PtzFrame.ACK_OK) {
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_PANO_INDEX,
                        PtzFrame.REQ_NONE.toInt(),
                        setPanoIndexResp
                    )
                } else {
                    BleLog.e("ptzSetPanoIndex error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_PANO_INDEX,
                        frame.toInt(),
                        setPanoIndexResp
                    )
                }
            }
        })
    }

    fun ptzAction(action: Short): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ACTION, action)
        return addNewRequestTask(
            ptzDataPacket,
            PtzEmptyReqMsg(),
            object : IRequestCallback {
                override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                    val frame = responseDataPacket.frame
                    if (frame == PtzFrame.ACK_OK) {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_ACTION,
                            Error.ERR_NONE,
                            FmgActionResp(requestId)
                        )
                    } else {
                        BleLog.e("ptzAction error, frame = " + formatValueToHex(frame))
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_ACTION,
                            frame.toInt(),
                            FmgActionResp(requestId)
                        )
                    }
                }
            })
    }

    fun ptzSetAppStatus(recording: Short, touch: Short): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_APP_STATUS, 0.toShort())
        val ptzSetAppStatusReqMsg = PtzSetAppStatusReqMsg(recording, touch)
        return addNewRequestTask(
            ptzDataPacket,
            ptzSetAppStatusReqMsg,
            object : IRequestCallback {
                override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                    val frame = responseDataPacket.frame
                    if (frame == PtzFrame.ACK_OK) {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_APP_STATUS,
                            Error.ERR_NONE,
                            FmgSetAppStatusResp(requestId)
                        )
                    } else {
                        BleLog.e("ptzSetAppStatus error, frame = " + formatValueToHex(frame))
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_APP_STATUS,
                            frame.toInt(),
                            FmgSetAppStatusResp(requestId)
                        )
                    }
                }
            })
    }

    fun ptzSetRoll360Action(action: PtzRoll360Action): Long {
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_ROLL_360, action.nativeValue)
        return addNewRequestTask(
            ptzDataPacket,
            PtzEmptyReqMsg(),
            object : IRequestCallback {
                override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                    val frame = responseDataPacket.frame
                    if (frame == PtzFrame.ACK_OK) {
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_SET_ROLL_360_MODE,
                            Error.ERR_NONE,
                            FmgSetRoll360ModeResp(requestId)
                        )
                    } else {
                        BleLog.e("ptzSetRoll360Action error, frame = " + formatValueToHex(frame))
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_SET_ROLL_360_MODE,
                            frame.toInt(),
                            FmgSetRoll360ModeResp(requestId)
                        )
                    }
                }
            })
    }

    fun ptzGetAiTrackerDeviceInfo(): Long {
        BleLog.e("PtzGetAiTrackerDeviceInfoRespMsg start")
        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_AI_TRACKER_DEVICE_INFO, 0.toShort())
        return addNewRequestTask(
            ptzDataPacket,
            PtzEmptyReqMsg(),
            object : IRequestCallback {
                override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                    val frame = responseDataPacket.frame
                    BleLog.e(
                        "PtzGetAiTrackerDeviceInfoRespMsg onRequestCallback, frame = " + formatValueToHex(
                            frame
                        )
                    )
                    if (frame == PtzFrame.ACK_OK) {
                        val dataRespMessage = responseDataPacket.unPack()
                        BleLog.e("PtzGetAiTrackerDeviceInfoRespMsg unPack")
                        if (dataRespMessage is PtzGetAiTrackerDeviceInfoRespMsg) {
                            val ptzGetAiTrackerDeviceInfoRespMsg = dataRespMessage
                            val fmgGetAiTrackerDeviceInfoResp = FmgGetAiTrackerDeviceInfoResp(
                                requestId,
                                ptzGetAiTrackerDeviceInfoRespMsg.sn,
                                ptzGetAiTrackerDeviceInfoRespMsg.type,
                                ptzGetAiTrackerDeviceInfoRespMsg.kernel_version,
                                ptzGetAiTrackerDeviceInfoRespMsg.models_version
                            )
                            mOneDriver.driverInfoNotify(
                                InfoType.FMG_GET_AI_TRACKER_DEVICE_INFO,
                                frame.toInt(),
                                fmgGetAiTrackerDeviceInfoResp
                            )
                            BleLog.e("PtzGetAiTrackerDeviceInfoRespMsg $dataRespMessage")
                        }
                    }
                }
            })
    }

    fun ptzAiTrackerStandbyMode(mode: PtzAiTrackerStandbyMode): Long {
        val nativeValue = mode.nativeValue.toShort()
        val ptzDataPacket =
            PtzDataPacket(PtzCmd.CMD_AI_TRACKER_SETTING_WRITE, AI_TRACKER_FRAME.SF_STANDBY_MEM)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzAiTrackerSettingsWriteReqMsg(nativeValue.toByte())
        BleLog.e("ptzAiTrackerStandbyMode ptzDataReqMessage = $ptzDataReqMessage")
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == AI_TRACKER_FRAME.SF_STANDBY_MEM) {
                    BleLog.i("ptzAiTrackerStandbyMode success, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_AI_TRACKER_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetAiTrackerSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzAiTrackerStandbyMode error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_AI_TRACKER_SETTINGS,
                        frame.toInt(),
                        FmgSetAiTrackerSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzAiTrackerAutoStandbyTime(time: PtzAiTrackerAutoStandbyTime): Long {
        val nativeValue = time.nativeValue.toShort()
        val ptzDataPacket = PtzDataPacket(
            PtzCmd.CMD_AI_TRACKER_SETTING_WRITE,
            AI_TRACKER_FRAME.SF_AUTO_STANDBY_TIME
        )
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzAiTrackerSettingsWriteReqMsg(nativeValue.toByte())
        BleLog.e("ptzAiTrackerAutoStandbyTime ptzDataReqMessage = $ptzDataReqMessage")
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == AI_TRACKER_FRAME.SF_AUTO_STANDBY_TIME) {
                    BleLog.e(
                        "ptzAiTrackerAutoStandbyTime success, frame = " + formatValueToHex(
                            frame
                        )
                    )
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_AI_TRACKER_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetAiTrackerSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzAiTrackerAutoStandbyTime error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_AI_TRACKER_SETTINGS,
                        frame.toInt(),
                        FmgSetAiTrackerSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzAiTrackerOnePlamShoot(mode: PtzAiTrackerOnePlamShoot): Long {
        val nativeValue = mode.nativeValue.toShort()
        val ptzDataPacket =
            PtzDataPacket(PtzCmd.CMD_AI_TRACKER_SETTING_WRITE, AI_TRACKER_FRAME.SF_ONE_PLAM_SHOOT)
        val ptzDataReqMessage: PtzDataReqMessage =
            PtzAiTrackerSettingsWriteReqMsg(nativeValue.toByte())
        BleLog.e("ptzAiTrackerOnePlamShoot ptzDataReqMessage = $ptzDataReqMessage")
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == AI_TRACKER_FRAME.SF_ONE_PLAM_SHOOT) {
                    BleLog.e("ptzAiTrackerOnePlamShoot success, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_AI_TRACKER_SETTINGS,
                        Error.ERR_NONE,
                        FmgSetAiTrackerSettingsResp(requestId)
                    )
                } else {
                    BleLog.e("ptzAiTrackerOnePlamShoot error, frame = " + formatValueToHex(frame))
                    mOneDriver.driverInfoNotify(
                        InfoType.FMG_SET_AI_TRACKER_SETTINGS,
                        frame.toInt(),
                        FmgSetAiTrackerSettingsResp(requestId)
                    )
                }
            }
        })
    }

    fun ptzGetAiTrackerSettings(): Long {
        val ptzDataPacket =
            PtzDataPacket(PtzCmd.CMD_AI_TRACKER_SETTING_READ, AI_TRACKER_FRAME.SF_ALL)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        return addNewRequestTask(ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                BleLog.e("responseDataPacket = $responseDataPacket")
                if (frame == AI_TRACKER_FRAME.SF_ALL) {
                    BleLog.e("frame == PtzStatus.AI_TRACKER_FRAME.SF_ALL")
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzAiTrackerSettingsReadRespMsg) {
                        BleLog.e("dataRespMessage instanceof PtzAiTrackerSettingsReadRespMsg")
                        val aiTrackerSettingsReadRespMsg = dataRespMessage
                        val aiTrackerSettingsParams = FmgAiTrackerSettingsParams()
                        aiTrackerSettingsParams.standbyMode =
                            PtzAiTrackerStandbyMode.Companion.nativeValueOf(
                                aiTrackerSettingsReadRespMsg.standby_mem_flag.toInt()
                            )
                        aiTrackerSettingsParams.autoStandbyTime =
                            PtzAiTrackerAutoStandbyTime.Companion.nativeValueOf(
                                aiTrackerSettingsReadRespMsg.auto_standby_time.toInt()
                            )
                        aiTrackerSettingsParams.onePlamShoot =
                            PtzAiTrackerOnePlamShoot.Companion.nativeValueOf(
                                aiTrackerSettingsReadRespMsg.one_plam_shoot.toInt()
                            )
                        val getAiTrackerSettingsResp =
                            FmgGetAiTrackerSettingsResp(requestId, aiTrackerSettingsParams)
                        mOneDriver.driverInfoNotify(
                            InfoType.FMG_GET_AI_TRACKER_SETTINGS,
                            Error.ERR_NONE,
                            getAiTrackerSettingsResp
                        )
                        return
                    }
                }
                BleLog.e("ptzGetAiTrackerSettings error, frame = " + formatValueToHex(frame))
                val getAiTrackerSettingsResp = FmgGetAiTrackerSettingsResp(requestId, null)
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_AI_TRACKER_SETTINGS,
                    frame.toInt(),
                    getAiTrackerSettingsResp
                )
            }
        })
    }

    fun updateHbRecMode(mode: PtzRecMode) {
        this.recMode = mode
    }

    /********************  Write Extra Ble API   */
    /**
     * 只有1代云台会通过此套接口进行蓝牙固件升级
     */
    private fun startExtraBleUpgrade(requestId: Long, bleData: ByteArray) {
        post {
            val fmgUpgradeBean = mFmgUpgradeBean
            if (fmgUpgradeBean != null && fmgUpgradeBean.requestId == requestId) {
                BleLog.d("start handle update pack")
                writeExtraBleData(requestId, OtaCmdPacketPack.startUpdatePack()!!)
                OtaFirmwarePacketPack.firmwareToPackets(
                    bleData,
                    object : IOtaFirmwarePacketPack {
                        override fun onPackSuccess(
                            index: Int,
                            buf: ByteArray?,
                            packetFwDataLength: Int,
                        ) {
                            BleLog.d("upload handle pack, index = $index, packetFwDataLength = $packetFwDataLength")
                            post {
                                buf?.let { writeExtraBleData(requestId, it) }
                                fmgUpgradeBean.addUploadedDataSize(packetFwDataLength)
                                if (index % 200 == 0) {
                                    notifyOTAProgressChanged(requestId)
                                }
                            }
                        }

                        override fun onPackEnd(index: Int) {
                            post {
                                BleLog.d("end handle update pack, index = $index")
                                writeExtraBleData(
                                    requestId,
                                    OtaCmdPacketPack.endUpdatePack(index)!!
                                )
                                notifyOTAProgressChanged(requestId)
                            }
                        }
                    })
            }
        }
    }

    private suspend fun writeExtraBleData(requestId: Long, data: ByteArray) {
        while (true) {
            val fmgUpgradeBean = mFmgUpgradeBean
            if (fmgUpgradeBean == null || fmgUpgradeBean.requestId != requestId) break
            if (mIsDestroyed.value) break

            if (mExtraBleUpgradeCharacteristic == null) {
                mExtraBleUpgradeCharacteristic = getHandleOTACharacteristic(mBleDevice)
            }
            if (mExtraBleUpgradeCharacteristic != null) {
                val writeResult = writeBleData(mExtraBleUpgradeCharacteristic, data, false)
                if (writeResult) {
                    break
                }
            } else {
                BleLog.e("writeOTAData error, mHandleOTACharacteristic is null")
            }
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun registerExtraBleUpgradeNotify(bleDevice: BleDeviceCore) {
        val characteristic = getHandleOTACharacteristic(bleDevice)
        if (characteristic != null) {
            BleLog.i("start register extra ble upgrade notify")
            BleManagerCore.indicate(
                bleDevice,
                characteristic.getCharacterServiceUuid(),
                characteristic.getCharacterUuid(),
                object : BleIndicateCallbackCore() {
                    override fun onIndicateSuccess() {
                        BleLog.d("register extra ble upgrade success")
                    }

                    override fun onIndicateFailure(exception: BleExceptionCore) {
                        BleLog.d("register extra ble upgrade error $exception")
                    }

                    override fun onCharacteristicChanged(data: ByteArray?) {
                        post {
                            if (TraceUtil.TRACE) {
                                val hexString = data?.toHexString(HexFormat.Default)
                                Log.d(
                                    TAG,
                                    "extra ble upgrade notify data = $hexString"
                                )
                            }
                            onExtraBleUpgradeNotify(data)
                        }
                    }
                })
        }
    }


    private suspend fun registerPtzBle(
        bleDevice: BleDeviceCore,
        registerBleCallback: RegisterBleCallback,
    ) {
        connectStarttime = currentTimeMillis()
        val characteristic = getPtzRwCharacteristic(bleDevice)
        if (characteristic == null) {
            Log.d(TAG, "nit PTZ BluetoothGattCharacteristic is null")
            registerBleCallback.onRegisterFailure(null)
            return
        } else {
            Log.d(TAG, "nit characteristic UUID 为: " + characteristic.getCharacterUuid())
            var isSupportIndicate = false
            var isSupportNotify = false
            val sb = StringBuilder()
            isSupportIndicate = characteristic.isIndicate()
            isSupportNotify = characteristic.canNotify()
            if (isSupportIndicate || isSupportNotify) {
                sb.append("nit 该characteristic支持:")
                if (isSupportIndicate) {
                    sb.append(" Indicate ")
                }
                if (isSupportNotify) {
                    sb.append(" Notify ")
                }
            } else {
                sb.append("该characteristic 出错，既不支持Indicate，也不支持notify")
            }
            Log.d(TAG, sb.toString())
        }
        if (characteristic.isIndicate()) {
            Log.d(TAG, "nit PTZ支持indicate，使用indicate")
            BleLog.i("nit PtzBle is support indicate")
            BleManagerCore.indicate(
                bleDevice,
                characteristic.getCharacterServiceUuid(),
                characteristic.getCharacterUuid(),
                object : IndicatePtzCallback() {
                    override fun onIndicateSuccess() {
                        Log.d(
                            TAG,
                            "nit 监听耗时为: " + (currentTimeMillis() - connectStarttime)
                        )
                        Log.d(TAG, "nit PTZ注册indicate成功")
                        registerBleCallback.onRegisterSuccess()
                        BleLog.d("nit register PtzBle upgrade success")
                    }

                    override fun onIndicateFailure(exception: BleExceptionCore) {
                        Log.d(TAG, "nit PTZ注册indicate失败")
                        registerBleCallback.onRegisterFailure(exception)
                        BleLog.d("nit register PtzBle upgrade error $exception")
                    }
                })
        } else if (characteristic.canNotify()) {
            Log.d(TAG, "nit PTZ支持notify，使用notify")
            BleLog.i("nit PtzBle is support notify")
            BleManagerCore.notify(
                bleDevice,
                characteristic.getCharacterServiceUuid(),
                characteristic.getCharacterUuid(),
                object : NotifyPtzCallback() {
                    override fun onNotifySuccess() {
                        Log.d(
                            TAG,
                            "nit 监听耗时为: " + (currentTimeMillis() - connectStarttime)
                        )
                        Log.d(TAG, "nit PTZ注册notify成功")
                        registerBleCallback.onRegisterSuccess()
                        BleLog.d("nit register PtzBle upgrade success")
                    }

                    override fun onNotifyFailure(exception: BleExceptionCore) {
                        Log.d(TAG, "nit PTZ注册notify失败")
                        registerBleCallback.onRegisterFailure(exception)
                        BleLog.d("nit register PtzBle upgrade error $exception")
                    }
                })
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun registerExtraBleUpgrade(
        bleDevice: BleDeviceCore,
        registerBleCallback: RegisterBleCallback,
    ) {
        val characteristic = getHandleOTACharacteristic(bleDevice)
        if (characteristic == null) {
            Log.d(TAG, "nit OTA BluetoothGattCharacteristic is null")
            registerBleCallback.onRegisterFailure(null)
            return
        }
        Log.d(
            TAG,
            "nit OTA BluetoothGattCharacteristic.getProperties: " + characteristic.nativeCharacter
        )
        if (characteristic.isIndicate()) {
            Log.d(TAG, "nit ota蓝牙升级支持indicate，使用indicate")
            BleLog.i("nit ExtraBleUpgrade is support indicate")
            BleManagerCore.indicate(
                bleDevice,
                characteristic.getCharacterServiceUuid(),
                characteristic.getCharacterUuid(),
                object : BleIndicateCallbackCore() {
                    override fun onIndicateSuccess() {
                        Log.d(TAG, "nit ota蓝牙升级indicate注册成功")
                        registerBleCallback.onRegisterSuccess()
                        BleLog.d("nit register extra ble upgrade success")
                    }

                    override fun onIndicateFailure(exception: BleExceptionCore) {
                        Log.d(TAG, "ota蓝牙升级indicate注册失败")
                        BleLog.d("nit register extra ble upgrade error $exception")
                    }

                    override fun onCharacteristicChanged(data: ByteArray?) {
                        post {
                            if (TraceUtil.TRACE) {
                                val hexString = data?.toHexString(HexFormat.Default)
                                Log.d(
                                    TAG,
                                    "nit extra ble upgrade notify data = $hexString"
                                )
                            }
                            onExtraBleUpgradeNotify(data)
                        }
                    }
                })
        } else if (characteristic.canNotify()) {
            Log.d(TAG, "nit ota蓝牙升级支持notify，使用notify")
            BleLog.i("nit ExtraBleUpgrade is support notify")
            BleManagerCore.notify(
                bleDevice,
                characteristic.getCharacterServiceUuid(),
                characteristic.getCharacterUuid(),
                object : BleNotifyCallbackCore() {
                    override fun onNotifySuccess() {
                        Log.d(TAG, "nit ota蓝牙升级notify注册成功")
                        registerBleCallback.onRegisterSuccess()
                        BleLog.d("nit register extra ble upgrade success")
                    }

                    override fun onNotifyFailure(exception: BleExceptionCore) {
                        Log.d(TAG, "nit ota蓝牙升级notify注册失败")
                        registerBleCallback.onRegisterFailure(exception)
                        BleLog.d("nit register extra ble upgrade error $exception")
                    }

                    override fun onCharacteristicChanged(data: ByteArray) {
                        post {
                            if (TraceUtil.TRACE) {
                                val hexString = data.toHexString(HexFormat.Default)
                                Log.d(
                                    TAG,
                                    "nit extra ble upgrade notify data = $hexString"
                                )
                            }
                            onExtraBleUpgradeNotify(data)
                        }
                    }
                })
        }
    }

    interface RegisterBleCallback {
        fun onRegisterSuccess()

        fun onRegisterFailure(exception: BleExceptionCore?)
    }


    fun onExtraBleUpgradeNotify(data: ByteArray?) {
        if (!mIsDestroyed.value) {
            val fmgUpgradeBean = mFmgUpgradeBean
            if (fmgUpgradeBean != null) {
                ExtraBleUpgradeResultParser.parse(data, object : IOtaParseCallback {
                    override fun onUpdateSuccess() {
                        notifyOTASuccess(fmgUpgradeBean.requestId)
                    }

                    override fun onUpdateFail(errorCode: Short) {
                        notifyOTAError(fmgUpgradeBean.requestId, errorCode.toInt())
                    }

                    override fun onParserError() {
                        notifyOTAError(fmgUpgradeBean.requestId, OtaStatus.OTA_RESPONSE_ERR.toInt())
                    }
                })
            }
        }
    }

    /********************  Write Data   */
    private suspend fun writePtzData(data: ByteArray, writeWithResponse: Boolean): Boolean {
        if (mPtzWriteCharacteristic == null) {
            mPtzWriteCharacteristic = getPtzRwCharacteristic(mBleDevice)
        }
        if (mPtzWriteCharacteristic != null) {
            return writeBleData(mPtzWriteCharacteristic, data, writeWithResponse)
        } else {
            BleLog.e("writePtzData error, mPtzWriteCharacteristic is null")
            return false
        }
    }

    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun writeBleData(
        characteristic: BluetoothGattCharacteristicCore?,
        mData: ByteArray,
        writeWithResponse: Boolean,
    ): Boolean {
        return writeMutex.withLock {
            if (TraceUtil.TRACE) {
                Log.d(
                    TAG,
                    "write ble = " + mBleDevice.key + ", data = " + mData.toHexString(HexFormat.Default) + " writeWithResponse = " + writeWithResponse
                )
            }
            if (characteristic != null) {
                mWriteBleResult.value = (true)
                var isResumed = atomic(false)  // 添加标志位，防止多次 resume
                suspendCoroutine { continuation ->
                    Log.d(TAG, "suspendCoroutine write ble = " + mBleDevice.key)
                    BleManagerCore.write(
                        mBleDevice,
                        characteristic.getCharacterServiceUuid(),
                        characteristic.getCharacterUuid(),
                        if (writeWithResponse) 0x02 else 0x01,
                        mData,
                        mData.size > BleManagerCore.getSplitWriteNum(),
                        !writeWithResponse,
                        object : BleWriteCallbackCore() {
                            override fun onWriteSuccess(
                                current: Int,
                                total: Int,
                                justWrite: ByteArray?,
                            ) {
                                Log.d(
                                    TAG,
                                    "write success current:" + current + " total:" + total + " justWrite: " + justWrite?.toHexString(
                                        HexFormat.Default
                                    )
                                )
                                if (total <= 1 || (current >= total)) {
                                    if (!isResumed.value) {
                                        isResumed.value = true
                                        mWriteBleResult.value = (true)
                                        continuation.resume(mWriteBleResult.value)
                                    }
                                }
                            }

                            override fun onWriteFailure(exception: BleExceptionCore) {

                                Log.d(TAG, "write error $exception")
                                if (!isResumed.value) {
                                    isResumed.value = true
                                    mWriteBleResult.value = (false)
                                    continuation.resume(mWriteBleResult.value)
                                }
                            }
                        })
                }
            } else {
                false
            }
        }
    }

    private suspend fun getPtzRwCharacteristic(bleDevice: BleDeviceCore): BluetoothGattCharacteristicCore? {
        val otaUUIDs = oTAUUIDs
        val characteristicUUIDs = characteristicUUIDs
        if (indexPackage < otaUUIDs.size) {
            return getBleCharacteristic(
                bleDevice, otaUUIDs[indexPackage],
                characteristicUUIDs[indexPackage]
            )
        }
        return getBleCharacteristic(bleDevice, PTZ_SERVICE_UUID, PTZ_CHARACTERISTIC_UUID)
    }

    private val oTAUUIDs: Array<String>
        get() {
            if (mFmgUpgradeBean == null) {
                return OTA_SERVICE_UUIDS_1
            }
            return if (mFmgUpgradeBean?.upgradePartSize == 3) {
                OTA_SERVICE_UUIDS_3
            } else {
                OTA_SERVICE_UUIDS_2
            }
        }

    private val characteristicUUIDs: Array<String>
        get() {
            if (mFmgUpgradeBean == null) {
                return OTA_CHARACTERISTIC_UUIDS_1
            }
            return if (mFmgUpgradeBean?.upgradePartSize == 3) {
                OTA_CHARACTERISTIC_UUIDS_3
            } else {
                OTA_CHARACTERISTIC_UUIDS_2
            }
        }

    private suspend fun getHandleOTACharacteristic(bleDevice: BleDeviceCore): BluetoothGattCharacteristicCore? {
        return getBleCharacteristic(
            bleDevice,
            EXTRA_BLE_UPGRADE_SERVICE_UUID,
            EXTRA_BLE_UPGRADE_CHARACTERISTIC_UUID
        )
    }

    private suspend fun getBleCharacteristic(
        bleDevice: BleDeviceCore,
        serviceUUID: String,
        characteristicUUID: String,
    ): BluetoothGattCharacteristicCore? {
        try {
            val bluetoothGatt = BleManagerCore.getBluetoothGatt(bleDevice)
            if (bluetoothGatt != null) {
                val service = runBlocking { bluetoothGatt.getService(serviceUUID) }
                if (service != null) {
                    return service.getCharacteristic(characteristicUUID)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun getButtonAbleFrame(fmgButtonAbleParams: FmgButtonAbleParams): Pair<Int, List<Int>>? {
        val buttonModes: MutableList<PtzButtonMode> = ArrayList()
        val dataList: MutableList<Int> = ArrayList()

        if (fmgButtonAbleParams.modeBtnParams != null && fmgButtonAbleParams.modeBtnParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.MODE_BTN)
            dataList.add(getButtonEventModeResult(fmgButtonAbleParams.modeBtnParams))
        }

        if (fmgButtonAbleParams.shutterBtnParams != null && fmgButtonAbleParams.shutterBtnParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.SHUTTER_BTN)
            dataList.add(getButtonEventModeResult(fmgButtonAbleParams.shutterBtnParams))
        }

        if (fmgButtonAbleParams.holdParams != null && fmgButtonAbleParams.holdParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.HOLD_BTN)
            dataList.add(getButtonEventModeResult(fmgButtonAbleParams.holdParams))
        }

        if (fmgButtonAbleParams.midBtnParams != null && fmgButtonAbleParams.midBtnParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.MID_BTN)
            dataList.add(getButtonEventModeResult(fmgButtonAbleParams.midBtnParams))
        }

        if (fmgButtonAbleParams.rockerParams != null && fmgButtonAbleParams.rockerParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.ROCKER)
            dataList.add(getRockerEventModeResult(fmgButtonAbleParams.rockerParams))
        }

        if (fmgButtonAbleParams.touchParams != null && fmgButtonAbleParams.touchParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.TOUCH)
            dataList.add(getTouchEventModeResult(fmgButtonAbleParams.touchParams))
        }

        if (fmgButtonAbleParams.dwParams != null && fmgButtonAbleParams.dwParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.DW)
            dataList.add(getDwEventModeResult(fmgButtonAbleParams.dwParams))
        }

        if (fmgButtonAbleParams.powerBtnParams != null && fmgButtonAbleParams.powerBtnParams!!.isNotEmpty()) {
            buttonModes.add(PtzButtonMode.POWER_BTN)
            dataList.add(getButtonEventModeResult(fmgButtonAbleParams.powerBtnParams))
        }

        if (buttonModes.size <= 0) {
            return null
        }

        var frame = buttonModes[0].nativeValue
        if (buttonModes.size > 1) {
            for (i in 1 until buttonModes.size) {
                frame = frame or buttonModes[i].nativeValue
            }
        }
        return Pair(frame, dataList)
    }

    private fun getButtonEventModeResult(clickModes: Array<PtzButtonEventMode>?): Int {
        if (clickModes == null || clickModes.size <= 0) {
            return 0
        }
        var result = clickModes[0]!!.nativeValue
        if (clickModes.size > 1) {
            for (i in 1 until clickModes.size) {
                result = result or clickModes[i]!!.nativeValue
            }
        }
        return result
    }

    private fun getRockerEventModeResult(clickModes: Array<PtzRockerEventMode>?): Int {
        if (clickModes == null || clickModes.size <= 0) {
            return 0
        }
        var result = clickModes[0]!!.nativeValue
        if (clickModes.size > 1) {
            for (i in 1 until clickModes.size) {
                result = result or clickModes[i]!!.nativeValue
            }
        }
        return result
    }

    private fun getTouchEventModeResult(clickModes: Array<PtzTouchEventMode>?): Int {
        if (clickModes == null || clickModes.size <= 0) {
            return 0
        }
        var result = clickModes[0]!!.nativeValue
        if (clickModes.size > 1) {
            for (i in 1 until clickModes.size) {
                result = result or clickModes[i]!!.nativeValue
            }
        }
        return result
    }

    private fun getDwEventModeResult(clickModes: Array<PtzDwEventMode>?): Int {
        if (clickModes == null || clickModes.size <= 0) {
            return 0
        }
        var result = clickModes[0]!!.nativeValue
        if (clickModes.size > 1) {
            for (i in 1 until clickModes.size) {
                result = result or clickModes[i]!!.nativeValue
            }
        }
        return result
    }

    fun ptzGetEtdBleAnalyticsData(): Long {
        val requestId = generateRequestId()
        ptzGetEtdBleItemHeader(requestId)
        return requestId
    }

    /**
     * 获取 Ble 应用埋点的头部信息，标志开始获取 Ble 应用埋点数据。
     *
     * @param requestId - 请求 Id
     */
    private fun ptzGetEtdBleItemHeader(requestId: Long) {
        val getNextEventRunnable = {
            mOneDriver.driverInfoNotify(
                InfoType.FMG_GET_ANALYTICS_DATA,
                requestId,
                Error.ERR_NONE,
                FmgGetAnalyticsDataResp(requestId, null)
            )
        }

        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD_BLE, PtzFrame.ETD_BLE_ITEM_HEADER)
        val ptzDataReqMessage: PtzDataReqMessage = PtzEmptyReqMsg()
        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                BleLog.d("enter ptzGetEtdBleItemHeader onRequestCallback")
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_BLE_ITEM_HEADER) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdBleHeaderRespMsg) {
                        val ptzGetEtdBleHeaderRespMsg = dataRespMessage
                        BleLog.d("ptzGetEtdBleItemHeader result = $ptzGetEtdBleHeaderRespMsg")

                        val fmgBleAnalyticsParams = FmgBleAnalyticsParams.Builder()
                            .setTotalSamsungTrackingTimes(
                                FmgBleAnalyticsParams.SamsungTrackingEvent(
                                    ptzGetEtdBleHeaderRespMsg.samsung_tracking_count
                                )
                            )
                            .setQuickStartEventArray(
                                arrayOfNulls(ptzGetEtdBleHeaderRespMsg.qu_event_length)
                            )
                            .build()

                        ptzGetEtdBleQuickStart(requestId, fmgBleAnalyticsParams, 0)
                        return
                    }
                }
                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    // 低版本的 FMG 会回复这个 ACK_ERR_INVALID_CMD，兼容性考虑不应该返回错误
                    BleLog.w("getFmgBleAnalyticsData cmd invalid, ignored")
                    getNextEventRunnable()
                    return
                }

                BleLog.e("ptzGetEtdBleItemHeader error, frame = " + formatValueToHex(frame) + ", cmd = " + responseDataPacket.cmd)
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    requestId,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null, null)
                )
            }
        })
    }

    private fun ptzGetEtdBleQuickStart(
        requestId: Long,
        fmgBleAnalyticsParams: FmgBleAnalyticsParams,
        startIndex: Int,
    ) {
        val getNextEventRunnable = {
            mOneDriver.driverInfoNotify(
                InfoType.FMG_GET_ANALYTICS_DATA,
                requestId,
                Error.ERR_NONE,
                FmgGetAnalyticsDataResp(requestId, null, fmgBleAnalyticsParams = fmgBleAnalyticsParams)
            )
        }

        val quickStartEventArraySize = fmgBleAnalyticsParams.quickStartEventArray?.size ?: 0
        if (startIndex >= quickStartEventArraySize) {
            getNextEventRunnable()
            return
        }

        val ptzDataPacket = PtzDataPacket(PtzCmd.CMD_GET_ETD_BLE, PtzFrame.ETD_BLE_ITEM_QUICK_START)
        val ptzDataReqMessage: PtzDataReqMessage = PtzGetEtdEventReqMsg(
            startIndex,
            quickStartEventArraySize - startIndex
        )

        addNewRequestTask(requestId, ptzDataPacket, ptzDataReqMessage, object : IRequestCallback {
            override fun onRequestCallback(requestId: Long, responseDataPacket: PtzDataPacket) {
                val frame = responseDataPacket.frame
                if (frame == PtzFrame.ETD_BLE_ITEM_QUICK_START) {
                    val dataRespMessage = responseDataPacket.unPack()
                    if (dataRespMessage is PtzGetEtdBleQuickStartEventRespMsg) {
                        val ptzGetEtdBleQuickStartEventRespMsg = dataRespMessage
                        BleLog.d("ptzGetEtdBleQuickStartEvent result = $ptzGetEtdBleQuickStartEventRespMsg")
                        val quickEventParams = ptzGetEtdBleQuickStartEventRespMsg.quickStartEventParamsArray
                        if (quickEventParams == null || quickEventParams.isEmpty()) {
                            getNextEventRunnable()
                            return
                        }
                        for (i in quickEventParams.indices) {
                            val destPos = startIndex + i
                            val quickStartEventArray = fmgBleAnalyticsParams.quickStartEventArray
                            if (destPos < (quickStartEventArray?.size ?: 0)) {
                                quickEventParams[i]?.let { params ->
                                    quickStartEventArray?.set(
                                        destPos,
                                        FmgBleAnalyticsParams.QuickStartEvent(params)
                                    )
                                }
                            }
                        }
                        ptzGetEtdBleQuickStart(
                            requestId,
                            fmgBleAnalyticsParams,
                            startIndex + quickEventParams.size,
                        )
                        return
                    }
                }
                if (frame == PtzFrame.ACK_ERR_INVALID_CMD) {
                    BleLog.w("ptzGetEtdItemFastPowerOn cmd invalid, ignored")
                    getNextEventRunnable()
                    return
                }
                BleLog.e("ptzGetEtdBleQuickStart error, frame = " + formatValueToHex(frame))
                mOneDriver.driverInfoNotify(
                    InfoType.FMG_GET_ANALYTICS_DATA,
                    requestId,
                    frame.toInt(),
                    FmgGetAnalyticsDataResp(requestId, null, null)
                )
            }
        })
    }


    private abstract inner class IndicatePtzCallback : BleIndicateCallbackCore() {
        @OptIn(ExperimentalStdlibApi::class)
        override fun onCharacteristicChanged(data: ByteArray?) {
            post {
                if (TraceUtil.TRACE) {
                    val hexString = data?.toHexString(HexFormat.Default)
                    Log.d(
                        TAG,
                        "executeNextTaskIfAvailable Ptz Indicate data = $hexString"
                    )
                }
                data?.let { onPtzResponse(it) }
            }
        }
    }

    private abstract inner class NotifyPtzCallback : BleNotifyCallbackCore() {
        @OptIn(ExperimentalStdlibApi::class)
        override fun onCharacteristicChanged(data: ByteArray) {
            post {
                if (TraceUtil.TRACE) {
                    val hexString = data.toHexString(HexFormat.Default)
                    Log.d(
                        TAG,
                        "executeNextTaskIfAvailable Ptz notify data = $hexString"
                    )
                }
                onPtzResponse(data)
            }
        }
    }

    companion object {
        private val TAG: String = FmgCommDelegate::class.simpleName.toString()

        const val PTZ_SERVICE_UUID: String = "00003366-0000-1000-8000-00805f9b34fb"
        const val PTZ_CHARACTERISTIC_UUID: String = "00002726-0000-1000-8000-00805f9b34fb"
        const val PTZ_CHARACTERISTIC_UUID_YAW: String = "00002736-0000-1000-8000-00805f9b34fb"
        const val OTA_CHARACTERISTIC_UUID_BLE: String = "00001644-0000-1000-8000-00805f9b34fb"
        const val EXTRA_BLE_UPGRADE_SERVICE_UUID: String = "00002481-0000-1000-8000-00805f9b34fb"
        const val EXTRA_BLE_UPGRADE_CHARACTERISTIC_UUID: String =
            "00001784-0000-1000-8000-00805f9b34fb"
        const val OTA_SERVICE_UUID_BLE: String = "00005147-0000-1000-8000-00805f9b34fb"
        const val OTA_SERVICE_UUID_YAW: String = "00003377-0000-1000-8000-00805f9b34fb"
        val OTA_SERVICE_UUIDS_1: Array<String> = arrayOf(PTZ_SERVICE_UUID)
        val OTA_SERVICE_UUIDS_2: Array<String> = arrayOf(PTZ_SERVICE_UUID, OTA_SERVICE_UUID_BLE)
        val OTA_SERVICE_UUIDS_3: Array<String> =
            arrayOf(PTZ_SERVICE_UUID, OTA_SERVICE_UUID_YAW, OTA_SERVICE_UUID_BLE)
        val OTA_CHARACTERISTIC_UUIDS_1: Array<String> = arrayOf(PTZ_CHARACTERISTIC_UUID)
        val OTA_CHARACTERISTIC_UUIDS_2: Array<String> =
            arrayOf(PTZ_CHARACTERISTIC_UUID, OTA_CHARACTERISTIC_UUID_BLE)
        val OTA_CHARACTERISTIC_UUIDS_3: Array<String> = arrayOf(
            PTZ_CHARACTERISTIC_UUID,
            PTZ_CHARACTERISTIC_UUID_YAW,
            OTA_CHARACTERISTIC_UUID_BLE
        )
        const val BLE_WRITE_MAX_LEN: Int = 256
        const val DEFAULT_TIMEOUT_MS: Long = 1000
        const val UPGRADE_TIMEOUT_MS: Long = 10000

        const val DEFAULT_WRITE_WITH_RESPONSE: Boolean = true

        /********************  Ptz Cmd Executor   */
        private val sRequestId = atomic(0L)

        fun generateRequestId(): Long {
            return sRequestId.incrementAndGet()
        }

        /******************************* utils  */
        @OptIn(ExperimentalStdlibApi::class)
        fun formatValueToHex(value: Short): String {
            return value.toHexString(HexFormat.Default)
        }
    }
}
