package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class TestTypeCCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.testTypeC()
        return null
    }
}
