package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SyncSetStandByCmd(private val mMode: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setStandbyMode(mMode)
    }
}
