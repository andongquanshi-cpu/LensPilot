package com.arashivision.onecamera

import com.arashivision.ble.OneBleIOProxy
import com.arashivision.camera.RequestOptions
import com.arashivision.camera.listener.IFmgConnectSyncListener
import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.camera.wifiproxy.WifiProxyDataParser
import com.arashivision.common.Log
import com.arashivision.fmg.FmgCommDelegate
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.inskmp.insble.BleLogCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.onedriver.OneDriverImpl
import com.arashivision.onedriver.bean.StreamData
import com.arashivision.onedriver.bean.StreamGimbalData
import com.arashivision.onedriver.packet.Packet
import com.arashivision.onedriver.packet.StreamType
import com.arashivision.utils.CLogUtils
import insta360.messages.AiIntentCtrl
import insta360.messages.AssistantLanguageCtrl
import insta360.messages.AudioStreamCtrl
import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType
import insta360.messages.CalibrateGyro
import insta360.messages.CancelAngleFixed
import insta360.messages.CardLocation
import insta360.messages.CheckAuthorization
import insta360.messages.CloudStorageBindParams
import insta360.messages.CloudStorageUploadParams
import insta360.messages.ConnectToBTPeripheral
import insta360.messages.CtrlPreRecord
import insta360.messages.DataTransPort
import insta360.messages.DataTransPortDir
import insta360.messages.DataTransportResult
import insta360.messages.DeleteFiles
import insta360.messages.DisconnectBTPeripheral
import insta360.messages.DownLoadInfo
import insta360.messages.DownloadListResultSync
import insta360.messages.FeatureBluetoothMacBind
import insta360.messages.FormatStorage
import insta360.messages.GetConnectedBTPeripheral
import insta360.messages.GetFile
import insta360.messages.GetFileExtra
import insta360.messages.GetFileFinish
import insta360.messages.GetFileList
import insta360.messages.GetGyro
import insta360.messages.GetGyroResp
import insta360.messages.GetTimelapseOptions
import insta360.messages.GimbalControl
import insta360.messages.IntervalRecCancel
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecStartStop
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveOptionCtrlInfo
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.OpenTrackingWithRect
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation
import insta360.messages.RecipeShareStatus
import insta360.messages.ScanBTPeripheral
import insta360.messages.SetFavoriteList
import insta360.messages.SetFileExtra
import insta360.messages.SetKeyTimePoint
import insta360.messages.SetNetworkConfigEnable
import insta360.messages.SetPresetComposition
import insta360.messages.SetTimelapseOptions
import insta360.messages.PhotoSettingPage
import insta360.messages.SingleHostCmdInfo
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.StreamTrackData
import insta360.messages.TakePicture
import insta360.messages.TakePictureResponse
import insta360.messages.TestSDCardSpeed
import insta360.messages.TimelapseOptions
import insta360.messages.UserRegionCtrl
import insta360.messages.Video
import insta360.messages.WifiConnectionInfo


class OneDriver() {
    private var mOnNotificationListener: OnNotificationListener? = null

    var gimbalDataCallback: ((StreamGimbalData) -> Unit)? = null
    var trackDataCallback: ((StreamTrackData) -> Unit)? = null
    private var mStreamListener: OnStreamListener? = null
    private var mFmgCommDelegate: FmgCommDelegate? = null
    private var mNeedReconnectCallback: IReconnectCallback? = null
    private var isSendWifiDebug = false
    private val logUtils = CLogUtils()
    private val oneDriverImpl = OneDriverImpl().apply {
        setInfoCallback { infoType, requestId, errorCode, data ->
            driverInfoNotify(infoType, requestId, errorCode, data)
        }

        setStreamDataCallback {
            if (it.streamType == StreamType.VideoPtz) {
                handleDriverPtzStreamDataNotify(it)
            } else if (it.streamType == StreamType.TrackData) {
                handleDriverTrackStreamDataNotify(it, it.timestamp)
            } else {
                handleDriverStreamDataNotify(it)
            }
        }

        setOnReconnectSuccessCallback {
            onReconnectSocketSuccess()
        }

        setNeedReconnectCallback {
            needReconnectWhenSocketError()
        }

        setTimelapseCallback { state, error, video ->
            handleDriverTimelapseNotify(state, error, video)
        }

        setRecordVideoStateCallback { state, error, video ->
            handleDriverRecordVideoStateNotify(state, error, video)
        }

        setStillImageWithoutStorageCallback { error, datas ->
            handleDriverStillImageWithoutStorageNotify(error, datas)
        }

        setStillImageCallback { error, takePictureResult ->
            handleDriverStillImageNotify(error, takePictureResult)
        }

        setWifiProxyDataCallback {
            it?.let { it1 -> handleWifiProxyDataNotify(it1) }
        }

        setUsbStateCallback { usbState, i ->
            handleDriverUsbState(usbState.value, i)
        }
    }


    fun setNativeLoggerCallback(loggerCallback: CLogUtils.ILoggerCallback?) {
        logUtils.setLoggerCallback(loggerCallback)
    }

    /**
     * BLE+SPP 共存时，由 BaseCamera 调用，将 SPP 的 peerBleDriver 指向 BLE 的 OneDriverImpl。
     * 设为 null 表示清除（BLE 断开时调用）。
     */
    fun setPeerDriver(peer: OneDriver?) {
        oneDriverImpl.peerBleDriver = peer?.oneDriverImpl
    }

    /**
     * BLE+SPP 共存时，由 BLE 的 BleConnectCmd 注册,用于接收经 SPP 转发来的同步包/心跳包。
     * 传 null 取消注册。
     */
    fun setForwardedSyncListener(listener: ((ByteArray) -> Unit)?) {
        oneDriverImpl.forwardedSyncListener = listener
    }

    //    @Override
    //    protected void finalize() throws Throwable {
    //        if(mState != State.Release) {
    //            Log.e(TAG, "finalize(): player not released, force clean");
    //            release();
    //        }
    //        super.finalize();
    //    }
    //
    //    public void release() {
    //        Log.i(TAG, "release");
    //        nativeRelease();
    //        mState = State.Release;
    //    }
    /*********************  FMG API Start   */
    fun ptzConnectSync(bleDevice: BleDeviceCore?, syncListener: IFmgConnectSyncListener?) {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzConnectSync(bleDevice, syncListener)
        }
    }

    fun ptzGetDeviceInfo(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetDeviceInfo()
        } else {
            -1L
        }
    }

    fun ptzGetUUID(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetUUID()
        } else {
            -1L
        }
    }

    fun ptzGetActiveTime(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetActiveTime()
        } else {
            -1L
        }
    }

    fun ptzSetActiveTime(activeTime: Long): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetActiveTime(activeTime)
        } else {
            -1L
        }
    }

    fun ptzSetZoomScale(scale: Short): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetZoomScale(scale)
        } else {
            -1L
        }
    }

    fun ptzResetDefaultSettings(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzResetDefaultSettings()
        } else {
            -1L
        }
    }

    fun ptzGetTrackSensitivityMode(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetTrackSensitivityMode()
        } else {
            -1L
        }
    }

    fun ptzSetTrackSensitivityMode(mode: PtzTrackSensitivityMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetTrackSensitivityMode(mode)
        } else {
            -1L
        }
    }

    fun ptzGetAllSettings(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetAllSettings()
        } else {
            -1L
        }
    }

    fun ptzSetSettingsMode(mode: PtzMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingsMode(mode)
        } else {
            -1L
        }
    }

    fun ptzSetSettingFollowSpeed(followSpeed: PtzFollowSpeed): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingFollowSpeed(followSpeed)
        } else {
            -1L
        }
    }

    fun ptzSetSettingRcSpeed(rcSpeed: PtzRcSpeed): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingRcSpeed(rcSpeed)
        } else {
            -1L
        }
    }

    fun ptzSetSettingZoomSpeed(zoomSpeed: PtzZoomSpeed): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingZoomSpeed(zoomSpeed)
        } else {
            -1L
        }
    }

    fun ptzSetSettingRcHorizontalDir(horizontalDir: PtzRcHorizontalDir): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingRcHorizontalDir(horizontalDir)
        } else {
            -1L
        }
    }

    fun ptzSetSettingRcVerticalDir(verticalDir: PtzRcVerticalDir): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingRcVerticalDir(verticalDir)
        } else {
            -1L
        }
    }

    fun ptzSetSettingSoundEnable(enable: PtzSoundMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingSoundEnable(enable)
        } else {
            -1L
        }
    }

    fun ptzSetSettingHvMode(mode: PtzHvMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingHvMode(mode)
        } else {
            -1L
        }
    }

    fun ptzSetSettingSwitchModeWay(mode: PtzSwitchModeWay): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingSwitchModeWay(mode)
        } else {
            -1L
        }
    }

    fun ptzSetSettingLedBrightness(brightness: Int): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingLedBrightness(brightness)
        } else {
            -1L
        }
    }

    fun ptzSetSettingMotorStrength(motorStrength: PtzMotorStrength): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingMotorStrength(motorStrength)
        } else {
            -1L
        }
    }

    fun ptzSetSettingRoll360(rollSpeed: PtzRoll360): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingRollSpeed(rollSpeed)
        } else {
            -1L
        }
    }

    fun ptzSetSettingQuickStart(quickStart: PtzQuickStart): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingQuickStart(quickStart)
        } else {
            -1L
        }
    }

    fun ptzSetSettingPitchLed(pitchLed: PtzPitchLed): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingPitchLed(pitchLed)
        } else {
            -1L
        }
    }

    fun ptzGetVerticalTrimDegree(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetVerticalTrimDegree()
        } else {
            -1L
        }
    }

    fun ptzSetVerticalTrimDegree(degree: Float): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetVerticalTrimDegree(degree)
        } else {
            -1L
        }
    }

    fun ptzStartOrUpdateTargetFollow(followParams: FmgTargetFollowParams) {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzStartOrUpdateTargetFollow(followParams)
        }
    }

    fun ptzSpeculateTargetFollow(followParams: FmgTargetFollowParams) {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSpeculateTargetFollow(followParams)
        }
    }

    fun ptzStartHeartBeat() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzStartHeartBeat()
        }
    }

    fun ptzStopHeartBeat() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzStopHeartBeat()
        }
    }

    fun ptzLostTargetFollow() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzLostTargetFollow()
        }
    }

    fun ptzExitTargetFollow() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzExitTargetFollow()
        }
    }

    fun ptzCompositionTargetFollow() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzCompositionTargetFollow()
        }
    }

    fun ptzStartCalibrate(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzStartCalibrate()
        } else {
            -1L
        }
    }

    fun startFmgUpgrade(
        fileData: ByteArray,
        writeWithoutResponse: Boolean,
        mtu: Int,
        writeExtraBleOTA: Boolean,
    ): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.startFmgUpgrade(
                fileData,
                writeWithoutResponse,
                mtu,
                writeExtraBleOTA
            )
        } else {
            -1L
        }
    }

    fun cancelFmgUpgrade() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.cancelFmgUpgrade()
        }
    }

    fun startFmgAITrackUpgrade(aiTrackUpgradeConfig: AITrackUpgradeConfig): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.startAITrackUpgrade(aiTrackUpgradeConfig)
        } else {
            -1L
        }
    }

    fun cancelFmgAITrackUpgrade() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.cancelAITrackUpgrade()
        }
    }

    fun ptzSetButtonEnable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetButtonEnable(fmgButtonAbleParams)
        } else {
            -1L
        }
    }

    fun ptzSetButtonDisable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetButtonDisable(fmgButtonAbleParams)
        } else {
            -1L
        }
    }

    fun ptzSetDwSrcEventState(enable: Boolean): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.setDwSrcEventState(enable)
        } else {
            -1L
        }
    }

    fun ptzGetButtonEnableStates(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.buttonEnableStates
        } else {
            -1L
        }
    }

    fun ptzGetMidCal(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetMidCal()
        } else {
            -1L
        }
    }

    fun ptzSetMidCal(euler: DoubleArray): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetMidCal(euler)
        } else {
            -1L
        }
    }

    fun ptzGetRunControl(state: PtzGrfState): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetRunControl(state)
        } else {
            -1L
        }
    }

    fun ptzSetRunControl(state: PtzGrfState, yaw: Float, pitch: Float, roll: Float): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetRunControl(state, yaw, pitch, roll)
        } else {
            -1L
        }
    }

    fun ptzSetVirtualRc(x: Short, y: Short): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetVirtualRc(x, y)
        } else {
            -1L
        }
    }

    fun ptzSetTimeElapse(mode: PtzTemMode, state: PtzTemState, duration: Int): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetTimeElapse(mode, state, duration)
        } else {
            -1L
        }
    }

    fun ptzSetPano(mode: PtzPanoMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetPano(mode)
        } else {
            -1L
        }
    }

    fun ptzRecModeStart(mode: PtzRecMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzRecModeStart(mode)
        } else {
            -1L
        }
    }

    fun ptzRecModeEnd(mode: PtzRecMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzRecModeEnd(mode)
        } else {
            -1L
        }
    }

    fun ptzRecModeInit(mode: PtzRecMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzRecModeInit(mode)
        } else {
            -1L
        }
    }

    fun ptzVibration(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzVibration()
        } else {
            -1L
        }
    }

    fun ptzEnableHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.enableHandDrag(list)
        } else {
            -1L
        }
    }

    fun ptzDisableHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.disableHandDrag(list)
        } else {
            -1L
        }
    }

    fun ptzSetCameraFacing(frame: Short): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetCameraFacing(frame)
        } else {
            -1L
        }
    }

    fun ptzBackCenter(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzBackCenter()
        } else {
            -1L
        }
    }

    fun ptzUpdateAppImuAngle(fmgAngleBean: FmgAngleBean?) {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzUpdateAppImuAngle(fmgAngleBean)
        }
    }

    fun ptzUpdateAppImuInfo(floats: FloatArray) {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzUpdateAppImuInfo(floats)
        }
    }

    fun ptzGetAnalyticsData(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetAnalyticsData()
        } else {
            -1L
        }
    }

    fun ptzClearAnalyticsData(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzClearAnalyticsData()
        } else {
            -1L
        }
    }

    fun ptzClearBleAnalyticsData(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzClearBleAnalyticsData()
        } else {
            -1L
        }
    }

    fun ptzGetBleAnalyticsData(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetEtdBleAnalyticsData()
        } else {
            -1L
        }
    }

    fun ptzSetAngleSeq(paramsList: List<FmgSetAngleSeqBean>): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetAngleSeq(paramsList)
        } else {
            -1L
        }
    }

    fun ptzBasketballA2G(
        mode: PtzBaksetballMode,
        state: PtzBaksetballState,
        transition: PtzBaksetballTransition,
    ): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzBasketballA2G(mode, state, transition)
        } else {
            -1L
        }
    }

    fun ptzBasketballInitNoBask() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzBasketballInitNoBask()
        }
    }

    fun ptzSetPanoIndex(index: Short, frame: PtzPanoIndexFrame): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetPanoIndex(index, frame)
        } else {
            -1L
        }
    }

    fun ptzAction(action: Short): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzAction(action)
        } else {
            -1L
        }
    }

    fun ptzSetAppStatus(recording: Short, touch: Short): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetAppStatus(recording, touch)
        } else {
            -1L
        }
    }

    fun ptzSetRoll360Action(action: PtzRoll360Action): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetRoll360Action(action)
        } else {
            -1L
        }
    }

    fun ptzGetAiTrackerDeviceInfo(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetAiTrackerDeviceInfo()
        } else {
            -1L
        }
    }

    fun ptzAiTrackerStandbyMode(mode: PtzAiTrackerStandbyMode): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzAiTrackerStandbyMode(mode)
        } else {
            -1L
        }
    }

    fun ptzAiTrackerAutoStandbyTime(time: PtzAiTrackerAutoStandbyTime): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzAiTrackerAutoStandbyTime(time)
        } else {
            -1L
        }
    }

    fun ptzAiTrackerOnePlamShoot(mode: PtzAiTrackerOnePlamShoot): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzAiTrackerOnePlamShoot(mode)
        } else {
            -1L
        }
    }

    fun ptzGetAiTrackerSettings(): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzGetAiTrackerSettings()
        } else {
            -1L
        }
    }

    fun updateHbRecMode(mode: PtzRecMode) {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.updateHbRecMode(mode)
        }
    }

    /**********************  FMG API End   */
    fun setClassicBluetoothStatus(isSuccess: Boolean) {
        oneDriverImpl.setClassicBluetoothStatus(isSuccess)
    }

    fun isClassicConnected(): Boolean {
        return oneDriverImpl.isClassicConnected()
    }

    /**
     * 打开蓝牙
     */
    suspend fun openCameraBle(callBack: OneBleIOProxy, isUseUcd2: Boolean): Int {
        return oneDriverImpl.openBle(callBack, isUseUcd2)
    }

    fun setBleProxy(isProxy: Boolean) {
        oneDriverImpl.setBleProxy(isProxy)
    }

    fun openFmgBle(delegate: FmgCommDelegate?) {
        mFmgCommDelegate = delegate
    }

    fun closeBle() {
        if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.destroy()
        }
        mFmgCommDelegate = null
    }

    /**
     * inner code will dup the fd, so upper caller should close its connection resource if it doesn't need
     * it.
     */
    suspend fun open(usbSysPath: String): Int {
        return oneDriverImpl.openUsb(usbSysPath)
    }

    suspend fun openWifi(
        networkHandle: Long,
        to: Int,
        addr: String,
        port: Short,
        isUseUcd2: Boolean,
        processBusyPacketEnable: Boolean,
    ): Int {
        return oneDriverImpl.openWifi(
            networkHandle,
            to,
            addr,
            port.toInt(),
            isUseUcd2,
            processBusyPacketEnable
        )
    }

    /** socket 打开失败后还原状态，以便重新 openWifi。仅重试前调用。 */
    suspend fun resetSocketForRetry(): Int {
        return oneDriverImpl.resetSocketForRetry()
    }

    suspend fun close() {
        // 使用协程方式调用
        oneDriverImpl.close()
    }

    fun reboot(): Long {
        return oneDriverImpl.rebootCamera()
    }

    fun notifyOTAError(): Long {
        return oneDriverImpl.notifyOTAError()
    }

    fun startStreaming(
        startLiveStream: StartLiveStream,
    ): Long {
        return oneDriverImpl.startStreaming(
            startLiveStream
        )
    }

    fun stopStreaming(): Long {
        return oneDriverImpl.stopStreaming()
    }

    fun requestStreamingIframe(): Long {
        return oneDriverImpl.requestStreamingIframe()
    }

    fun stopUsbcardBackup(): Long {
        return oneDriverImpl.stopUsbcardBackup()
    }

    val quickReaderStatus: Long
        get() = oneDriverImpl.getQuickReaderStatus()

    fun setOptions(
        optionTypes: List<OptionType>,
        mOptions: Options,
    ): Long {
        return oneDriverImpl.setOptions(optionTypes, mOptions)
    }

    fun setOptionsAsync(
        optionTypes: List<OptionType>,
        mOptions: Options,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.setOptionsAsync(
            optionTypes,
            mOptions,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    private fun needReconnectWhenSocketError(): Boolean {
        if (mNeedReconnectCallback != null) {
            return mNeedReconnectCallback!!.needReconnectSocket()
        }
        return false
    }

    fun onReconnectSocketSuccess() {
        if (mNeedReconnectCallback != null) {
            mNeedReconnectCallback!!.onReconnectSocketSuccess()
        }
    }

    fun driverInfoNotify(what: Int, requestId: Long, err: Int, obj: Any?) {
        handleDriverInfoNotify(what, requestId, err, obj) // DRIVER_INFO_NOTIFY
    }

    fun driverInfoNotify(what: Int, err: Int, obj: Any?) {
        handleDriverInfoNotify(what, 0, err, obj) // DRIVER_INFO_NOTIFY
    }

    private fun handleDriverInfoNotify(what: Int, requestId: Long, err: Int, obj: Any?) {
        mOnNotificationListener?.onDriverInfoNotify(what, requestId, err, obj)
    }

    private fun handleWifiProxyDataNotify(bytes: ByteArray) {
        val iWifiProxyData = WifiProxyDataParser.parse(bytes, Packet.useUcd2)
        mOnNotificationListener?.onWifiProxyDataNotify(iWifiProxyData)
    }

    private fun handleDriverUsbState(state: Int, err: Int) {
        mOnNotificationListener?.onDriverUsbState(state, err)
    }

    private fun handleDriverStillImageNotify(error: Int, obj: TakePictureResponse?) {
        mOnNotificationListener?.onDriverStillImageNotify(error, obj)
    }

    private fun handleDriverStillImageWithoutStorageNotify(error: Int, datas: ByteArray?) {
        mOnNotificationListener?.onDriverStillImageWithoutStorageNotify(error, datas)
    }

    private fun handleDriverRecordVideoStateNotify(state: Int, error: Int, video: Video?) {
        mOnNotificationListener?.onDriverRecordVideoStateNotify(state, error, video)
    }

    private fun handleDriverTimelapseNotify(state: Int, error: Int, video: Video?) {
        mOnNotificationListener?.onDriverTimelapseNotify(state, error, video)
    }

    private fun handleDriverStreamDataNotify(mStreamData: StreamData) {
        if (mStreamListener != null) {
            mStreamListener!!.onDriverStreamDataNotify(mStreamData)
        }
    }

    private fun handleDriverPtzStreamDataNotify(streamData: StreamData) {
        if (gimbalDataCallback == null) return
        val streamGimbalData = StreamGimbalData()
        streamGimbalData.unpack(streamData.data)
        gimbalDataCallback?.invoke(streamGimbalData)
    }

    private fun handleDriverTrackStreamDataNotify(streamData: StreamData, timestamp: Long) {
        if (trackDataCallback == null) return
        val streamTrackData = StreamTrackData.ADAPTER.decode(streamData.data).apply {
            this.timestamp /= 1000L
        }
        trackDataCallback?.invoke(streamTrackData)
    }

    fun sendWakeUpAuthorization(uuid: String) {
        oneDriverImpl.sendWakeUpAuthorization(uuid)
    }

    fun writeBleSync(syncData: ByteArray) {
        oneDriverImpl.writeBleSync(syncData)
    }

    fun writeRawData(rawData: ByteArray) {
        oneDriverImpl.writeRawData(rawData)
    }

    fun ptzSetSettingEnableSaveHv(ptzEnableSaveHv: PtzEnableSaveHv): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingEnableSaveHv(ptzEnableSaveHv)
        } else {
            -1L
        }
    }

    /***
     * 一键环拍
     * @return
     */
    fun ptzSetSettingSurroundShot(ptzSurroundShoot: PtzSurroundShoot): Long {
        return if (mFmgCommDelegate != null) {
            mFmgCommDelegate!!.ptzSetSettingSurroundShot(ptzSurroundShoot)
        } else {
            -1L
        }
    }


    fun setNotificationListener(listener: OnNotificationListener?) {
        mOnNotificationListener = listener
    }

    fun setStreamListener(streamListener: OnStreamListener?) {
        mStreamListener = streamListener
    }

    fun setReconnectCallback(needReconnectCallback: IReconnectCallback?) {
        mNeedReconnectCallback = needReconnectCallback
    }

    interface IReconnectCallback {
        fun needReconnectSocket(): Boolean

        fun onReconnectSocketSuccess()
    }

    interface OnStreamListener {
        fun onDriverStreamDataNotify(mData: StreamData)
    }

    interface OnNotificationListener {
        fun onDriverInfoNotify(what: Int, requestId: Long, err: Int, obj: Any?)

        fun onDriverRecordVideoStateNotify(state: Int, error: Int, video: Video?)

        fun onDriverUsbState(state: Int, err: Int)

        fun onDriverStillImageNotify(errorCode: Int, mResponse: TakePictureResponse?)

        fun onDriverStillImageWithoutStorageNotify(error: Int, datas: ByteArray?)

        fun onDriverTimelapseNotify(state: Int, error: Int, video: Video?)

        fun onWifiProxyDataNotify(wifiProxyData: IWifiProxyData?)
    }

    fun startRecordWithCameraStorage(mode: Int): Long {
        return oneDriverImpl.startRecordWithCameraStorage(mode)
    }

    fun startBulletTime(): Long {
        return oneDriverImpl.startBulletTime()
    }

    fun stopRecordWithCameraStorage(mMode: Int, extraMetaData: ByteArray) {
        oneDriverImpl.stopRecordWithCameraStorage(mMode, extraMetaData)
    }

    fun setGPSData(gpsData: ByteArray): Long {
        return oneDriverImpl.setGPSData(gpsData)
    }

    fun startHdrCapture() {
        oneDriverImpl.startHdrCapture()
    }

    fun stopHdrCapture(extraData: ByteArray) {
        oneDriverImpl.stopHdrCapture(extraData)
    }

    fun stopBulletTime(extraMetaData: ByteArray) {
        oneDriverImpl.stopBulletTime(extraMetaData)
    }

    fun startTimeShift() {
        oneDriverImpl.startTimeshift()
    }

    fun stopTimeShift(extraData: ByteArray) {
        oneDriverImpl.stopTimeshift(extraData)
    }


    fun cancelRecordWithCameraStorage() {
        oneDriverImpl.cancelRecordWithCameraStorage()
    }

    fun stopTakePicture(): Long {
        return oneDriverImpl.stopTakePicture()
    }

    fun captureStillImage(obj: TakePicture) {
        oneDriverImpl.captureStillImage(obj)
    }

    fun captureStillImageWithouStorage(obj: TakePicture) {
        oneDriverImpl.captureStillImageWithoutStorage(obj)
    }

    fun getOptions(optionList: List<OptionType>): Options {
        return oneDriverImpl.getOptions(optionList) as Options
    }

    fun getOptionsAsync(optionList: List<OptionType>, requestOptions: RequestOptions): Long {
        return oneDriverImpl.getOptionsAsync(
            optionList,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun getAllOption(optionTypes: List<OptionType>): Options {
        return oneDriverImpl.getOptions(optionTypes) as Options
    }

    fun getAllOptionsAsync(optionTypes: List<OptionType>, requestOptions: RequestOptions): Long {
        return oneDriverImpl.getOptionsAsync(
            optionTypes,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun bindBluetoothMacFeature(
        featureBluetoothMacBind: FeatureBluetoothMacBind,
    ): Long {
        return oneDriverImpl.bindBluetoothMacFeature(
            featureBluetoothMacBind
        )
    }

    fun negotiateEncryption(onComplete: (Boolean) -> Unit) {
        oneDriverImpl.negotiateEncryption(onComplete)
    }

    fun setPhotographyOptions(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        option: PhotographyOptions,
    ): Long {
        return oneDriverImpl.setPhotographyOptions(funcMode, optionTypes, option)
    }

    fun setPhotographyOptionsAsync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        option: PhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.setPhotographyOptionsAsync(
            funcMode,
            optionTypes,
            option,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun getPhotographyOptions(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
    ): PhotographyOptions {
        return oneDriverImpl.getPhotographyOptions(funcMode, optionTypes) as PhotographyOptions
    }

    fun getPhotographyOptionsAsync(
        funcMode: Int,
        opetions: List<PhotographyOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.getPhotographyOptionsAsync(
            funcMode,
            opetions,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        buttonPressParams: ButtonPressParams,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.setButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            buttonPressParams,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.getButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun setTimelapseOptions(info: SetTimelapseOptions): Long {
        return oneDriverImpl.setTimelapseOptions(info)
    }

    fun setTimelapseOptionsASync(info: SetTimelapseOptions, requestOptions: RequestOptions): Long {
        return oneDriverImpl.setTimelapseOptionsAsync(
            info,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun setCameraLiveOptionsAsync(
        optionList: List<LiveBroadCastOptionType>,
        mOptions: LiveOptionCtrlInfo,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.setCameraLiveOptionsAsync(
            optionList,
            mOptions,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun getCameraLiveOptionsAsync(
        optionList: List<LiveBroadCastOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.getCameraLiveOptionsAsync(
            optionList,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun setFileExtra(fileExtraBytes: SetFileExtra): Long {
        return oneDriverImpl.setFileExtra(fileExtraBytes)
    }

    fun getFileExtra(obj: GetFileExtra): Long {
        return oneDriverImpl.getFileExtra(obj)
    }

    fun recipeShareStatus(obj: RecipeShareStatus): Long {
        return oneDriverImpl.recipeShareStatus(obj)
    }

    fun getGyro(obj: GetGyro): GetGyroResp {
        return oneDriverImpl.getGyro(obj) as GetGyroResp
    }

    fun getFileList(obj: GetFileList): Long {
        return oneDriverImpl.getFileList(obj)
    }

    fun getFileListIncludeRecording(obj: GetFileList): Long {
        return oneDriverImpl.getFileListIncludeRecording(obj)
    }

    val fileInfoList: Long
        get() = oneDriverImpl.getFileInfoList()

    fun getFileInfoList(getFileInfoList: insta360.messages.GetFileInfoList): Long {
        return oneDriverImpl.getFileInfoList(getFileInfoList)
    }

    val editInfoList: Long
        get() = oneDriverImpl.getEditInfoList()

    fun getTranslateConfig(timeoutMs: Int = -1): Long {
        return oneDriverImpl.getTranslateConfig(timeoutMs)
    }

    fun setFavoriteList(favoriteList: SetFavoriteList): Long {
        return oneDriverImpl.setFavoriteList(favoriteList)
    }

    fun getFile(obj: GetFile): Long {
        return oneDriverImpl.getFile(obj)
    }

    fun packFile(obj: GetFile): Long {
        return oneDriverImpl.packFile(obj)
    }

    fun getFileFinish(obj: GetFileFinish): Long {
        return oneDriverImpl.getFileFinish(obj)
    }

    fun setTransferStatus(obj: GetFileFinish): Long {
        return oneDriverImpl.setTransferStatus(obj)
    }

    /**////////////////////////////////////////////////////////////////////////////////////////////////////// */
    fun testSDCardSpeed(obj: TestSDCardSpeed): Long {
        return oneDriverImpl.testSDCardSpeed(obj)
    }

    fun eraseSDCard(): Long {
        return oneDriverImpl.eraseSDCard()
    }

    fun formatStorage(formatStorage: FormatStorage): Long {
        return oneDriverImpl.formatStorage(formatStorage)
    }

    fun setMainStorage(cardLocation: CardLocation): Long {
        return oneDriverImpl.setMainStorage(cardLocation)
    }

    fun openCameraWifi(countryChannel: Int): Long {
        return oneDriverImpl.openCameraWifi(countryChannel)
    }

    fun closeCameraWifi(): Long {
        return oneDriverImpl.closeCameraWifi()
    }

    fun resetCameraWifi(countryChannel: Int): Long {
        return oneDriverImpl.resetCameraWifi(countryChannel)
    }

    /**
     * [com.arashivision.onecamera.OneDriverInfo.Request.ConnectionState]
     */
    fun setCameraWifiSeizeEnable(connectionState: Int): Long {
        return oneDriverImpl.setCameraWifiSeizeEnable(connectionState)
    }

    val wifiConnectionInfo: Long
        get() = oneDriverImpl.getWifiConnectionInfo()

    fun setWifiConnectionInfo(wifiConnectionInfo: WifiConnectionInfo): Long {
        return oneDriverImpl.setWifiConnectionInfo(wifiConnectionInfo)
    }

    fun setAvailableWifi(wifiConnectionInfo: WifiConnectionInfo): Long {
        return oneDriverImpl.setAvailableWifi(wifiConnectionInfo)
    }

    fun setGimbalControlCmd(gimbalControl: GimbalControl): Long {
        return oneDriverImpl.setPhoneCommandGimbalControl(gimbalControl)
    }

    fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long {
        return oneDriverImpl.openTrackingWithRect(openTrackingWithRect)
    }

    fun cancelTracking(): Long {
        return oneDriverImpl.cancelTracking()
    }

    fun setPresetComposition(setPresetComposition: SetPresetComposition): Long {
        return oneDriverImpl.setPresetComposition(setPresetComposition)
    }

    fun notifySettingPage(settingPageNotify: PhotoSettingPage): Long {
        return oneDriverImpl.notifySettingPage(settingPageNotify)
    }

    fun getPresetComposition(): Long {
        return oneDriverImpl.getPresetComposition()
    }

    fun getPtzTrackState(): Long {
        return oneDriverImpl.getPtzTrackState()
    }

    fun setWifiMode(wifiMode: Int, countryCode: String?): Long {
        return oneDriverImpl.setWifiMode(wifiMode, countryCode)
    }

    fun requestData(
        dir: DataTransPortDir,
        rxdatainfo: List<RequestReceiveDataInformation>? = null,
        txdatainfo: List<RequestSendDataInformation>? = null,
    ): Long {
        return oneDriverImpl.requestData(dir, rxdatainfo, txdatainfo)
    }

    fun dataTransportFeedback(dataTransportResult: DataTransportResult): Long {
        return oneDriverImpl.dataTransportFeedback(dataTransportResult)
    }

    fun setWifiState(wifiConnectionInfo: WifiConnectionInfo, wifiNetResult: Int): Long {
        return oneDriverImpl.setWifiState(wifiConnectionInfo, wifiNetResult)
    }

    fun setShowCloudTab(showCloudTab: Boolean): Long {
        return oneDriverImpl.setCloudTabShow(showCloudTab)
    }

    fun setPhoneInfo(manufacturer: String, model: String, osVersion: String): Long {
        return oneDriverImpl.setPhoneInfo(manufacturer, model, osVersion)
    }

    val wifiMode: Long
        get() = oneDriverImpl.getWifiMode()

    fun switchWifiChannel(needScan: Int, channel: Int): Long {
        return oneDriverImpl.switchWifiChannel(needScan, channel)
    }

    val wifiInterfStatus: Long
        get() = oneDriverImpl.getWifiInterfStatus()

    val wifiConnectList: Long
        get() = oneDriverImpl.getWifiConnectList()

    fun getWifiScanList(interval: Int, count: Int): Long {
        return oneDriverImpl.getWifiScanList(interval, count)
    }

    fun startCameraLive(): Long {
        return oneDriverImpl.startCameraLive()
    }

    fun stopCameraLive(): Long {
        return oneDriverImpl.stopCameraLive()
    }

    fun requestP3StaticStreamData(): Long {
        return oneDriverImpl.requestP3StaticStreamData()
    }

    fun prepareCameraLive(): Long {
        return oneDriverImpl.prepareCameraLive()
    }

    /**
     * [com.arashivision.onecamera.OneDriverInfo.Request.AccessCameraFileState]
     */
    fun setAccessCameraFileState(accessState: Int): Long {
        return oneDriverImpl.setAccessCameraFileState(accessState)
    }

    fun openCameraOled(): Long {
        return oneDriverImpl.openCameraOled()
    }

    fun closeCameraOled(): Long {
        return oneDriverImpl.closeCameraOled()
    }

    fun setAppId(appId: String): Long {
        return oneDriverImpl.setAppId(appId)
    }

    fun setShutdown(): Long {
        return oneDriverImpl.setShutdown()
    }

    fun cancelAngleFixed(cancelAngleFixed: CancelAngleFixed): Long {
        return oneDriverImpl.cancelAngleFixed(cancelAngleFixed)
    }

    fun sendOpenCameraClassicBluetooth(connectType: Int): Long {
        return oneDriverImpl.sendOpenClassicBluetooth(connectType)
    }

    fun sendAiVoiceReady(isHuawei: Boolean = false): Long {
        return oneDriverImpl.sendAiVoiceReady(isHuawei)
    }

    fun checkAuthorization(
        checkAuthorization: CheckAuthorization,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.checkAuthorization(
            checkAuthorization,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun cancelAuthorization(requestOptions: RequestOptions): Long {
        return oneDriverImpl.cancelAuthenticate(
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun requestAuthorization(authorizationOperationType: Int): Long {
        return oneDriverImpl.requestAuthorization(authorizationOperationType)
    }

    fun cancelRequestAuthorization(authorizationOperationType: Int): Long {
        return oneDriverImpl.cancelRequestAuthorization(authorizationOperationType)
    }

    fun calibrateGyro(obj: CalibrateGyro): Long {
        return oneDriverImpl.calibrateGyro(obj)
    }

    fun connectBT(obj: ConnectToBTPeripheral): Long {
        return oneDriverImpl.connectToBtPeripheral(obj)
    }

    fun disConnectBT(obj: DisconnectBTPeripheral): Long {
        return oneDriverImpl.disConnectToBtPeripheral(obj)
    }

    fun scanBT(obj: ScanBTPeripheral): Long {
        return oneDriverImpl.scanBtPeripheral(obj)
    }


    fun getTimelapseOptions(obj: GetTimelapseOptions): TimelapseOptions {
        return oneDriverImpl.getTimelapseOptions(obj) as TimelapseOptions
    }

    fun getTimelapseOptionsAsync(obj: GetTimelapseOptions, requestOptions: RequestOptions): Long {
        return oneDriverImpl.getTimelapseOptionsAsync(
            obj,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun getCaptureStatus(requestOptions: RequestOptions): Long {
        return oneDriverImpl.getCurrentRecordStatus(
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun setSyncCaptureMode(mode: Int): Long {
        return oneDriverImpl.setSyncCaptureMode(mode)
    }

    val syncCaptureMode: Long
        get() = oneDriverImpl.getSyncCaptureMode()

    fun pauseRecord(): Long {
        return oneDriverImpl.pauseRecord()
    }

    fun setStandbyMode(mode: Int): Long {
        return oneDriverImpl.setStandbyMode(mode)
    }

    fun sendWifiHearBeat() {
        if (isSendWifiDebug) {
            Log.d(TAG, "send wifi heart beat")
        }
        oneDriverImpl.sendWifiHeartBeat()
    }


    fun sendHeartBeat() {
        oneDriverImpl.sendHeartBeat()
    }

    suspend fun putData(bytes: ByteArray, bleProxy: Boolean): Int {
        oneDriverImpl.putData(bytes, bleProxy)
        return 0
    }

    fun checkVideo(videoResolution: Int): Boolean {
        return oneDriverImpl.checkVideo(videoResolution)
    }

    fun checkVideo(width: Int, height: Int, fps: Int): Boolean {
        return oneDriverImpl.checkVideo(width, height, fps)
    }

    fun resumeInitialState(): Long {
        return oneDriverImpl.resumeInitialState()
    }

    fun startTimeplapse(obj: StartTimelapse) {
        oneDriverImpl.startTimelapseRecord(obj)
    }

    fun stopTimeplapse(obj: StopTimelapse) {
        oneDriverImpl.stopTimelapseRecord(obj)
    }

    fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long {
        return oneDriverImpl.setPreRecord(ctrlPreRecord)
    }

    fun getConnectBT(obj: GetConnectedBTPeripheral): Long {
        return oneDriverImpl.getConnectedBtPeripherals(obj)
    }

    fun deleteFiles(obj: DeleteFiles): Long {
        return oneDriverImpl.deleteFiles(obj)
    }

    val tunelPort: Int
        get() = oneDriverImpl.getTunnelServerPort()

    fun getGyroAsync(obj: GetGyro): Long {
        return oneDriverImpl.getGyroAsync(obj)
    }

    fun startLedTest(): Long {
        return oneDriverImpl.startLedTest()
    }

    fun testButtonPress() {
        oneDriverImpl.testButtonState()
    }

    fun startContactTest() {
        oneDriverImpl.startContactTest()
    }

    fun startColorTest() {
        oneDriverImpl.startColorTest()
    }


    fun startSpeakerTest(): Long {
        return oneDriverImpl.startSpeakerTest()
    }

    fun openIperf(mode: Int): Long {
        return oneDriverImpl.openIperf(mode)
    }

    fun closeIperf(): Long {
        return oneDriverImpl.closeIperf()
    }

    val iperfAverage: Long
        get() = oneDriverImpl.getIperfAverage()

    fun startWifiStatusTest(): Long {
        return oneDriverImpl.startWifiStatusTest()
    }

    fun startBluetoothStatusTest(): Long {
        return oneDriverImpl.startBluetoothStatusTest()
    }

    fun testTypeC() {
        oneDriverImpl.testTypeC()
    }

    fun stopLCDTest() {
        oneDriverImpl.stopLCDTest()
    }

    fun setWifiHeartDebug(isDebug: Boolean): Int {
        isSendWifiDebug = isDebug
        return 0
    }

    fun getCameraWifiDebug(isDebug: Boolean): Int {
        return oneDriverImpl.setWifiHeartDebug(isDebug)
    }

    fun setBleError(error: Int) {
        oneDriverImpl.sendBleError(error)
    }

    fun obtainCameraRtosStatus() {
        oneDriverImpl.sendObtainRtosStatus()
    }

    fun setKeyTimePoint(keyTimePoint: SetKeyTimePoint): Long {
        return oneDriverImpl.setKeyTimePoint(keyTimePoint)
    }

    fun setFlowStateEnable(flowStateEnable: Int): Long {
        return oneDriverImpl.setFlowStateEnable(flowStateEnable)
    }

    val flowStateEnable: Long
        get() = oneDriverImpl.getFlowStateEnable()

    val darkEisStatus: Long
        get() = oneDriverImpl.getDarkEisStatus()

    fun updateDownloadInfo(downLoadInfo: DownLoadInfo): Long {
        return oneDriverImpl.updateDownloadInfo(downLoadInfo)
    }

    fun getDownloadFileList(list: GetFileList): Long {
        return oneDriverImpl.getDownloadFileList(list)
    }

    fun notifyGetDownloadFileListResult(addListResultSync: DownloadListResultSync): Long {
        return oneDriverImpl.notifyGetDownloadFileListResult(addListResultSync)
    }

    fun setMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        options: MultiPhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.setMultiVideoMode(
            funcMode,
            sensorMode,
            optionList,
            options,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun getMultiVideo(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        requestOptions: RequestOptions,
    ): Long {
        return oneDriverImpl.getMultiVideoMode(
            funcMode,
            sensorMode,
            optionList,
            requestOptions.timeoutMs,
            requestOptions.retryCount
        )
    }

    fun setSingleSensor(sensor: Int): Long {
        return oneDriverImpl.setSingleSensor(sensor)
    }

    fun getSingleSensor(requestOptions: RequestOptions): Long {
        return oneDriverImpl.getSingleSensor(requestOptions.timeoutMs, requestOptions.retryCount)
    }


    /**
     * go 2 产测相关接口
     */
    /**
     * dsp 链路测试
     */
    fun dspLinkTest(): Long {
        return oneDriverImpl.dspLinkTest()
    }

    /**
     *
     */
    fun gyroScopeTest(): Long {
        return oneDriverImpl.gyroScopeTest()
    }

    /**
     * 白平衡校正
     */
    fun whiteBlanceTest(): Long {
        return oneDriverImpl.whiteBlanceTest()
    }

    /**
     * 黑电平校正
     */
    fun blackLevelTest(): Long {
        return oneDriverImpl.blackLevelTest()
    }

    /**
     * 坏点校正
     */
    fun badPointTest(): Long {
        return oneDriverImpl.badPointTest()
    }

    val ageStatus: Long
        get() = oneDriverImpl.ageTestStatus()

    fun vibrateTest(): Long {
        return oneDriverImpl.vibrateTest()
    }

    fun vibrateStopTest(): Long {
        return oneDriverImpl.vibrateStopTest()
    }

    /**
     * 充电盒测试
     */
    fun chargingBox(commandType: Int, datas: ByteArray): Long {
        return oneDriverImpl.chargingBox(commandType, datas)
    }

    fun uploadScriptJson(jsonBytes: ByteArray): Long {
        return oneDriverImpl.uploadJson(jsonBytes)
    }

    fun uploadScriptCmd(bytes: ByteArray): Long {
        return oneDriverImpl.uploadCmd(bytes)
    }

    fun scriptResfersh(): Long {
        return oneDriverImpl.scriptRefersh()
    }

    fun scriptRun(): Long {
        return oneDriverImpl.scriptRun()
    }

    fun setAAANormalMode(): Long {
        return oneDriverImpl.setAAANormalMode()
    }

    fun setAAAFactoryMode(): Long {
        return oneDriverImpl.setAAAFactoryMode()
    }

    val whiteBlanceStatus: Long
        get() = oneDriverImpl.getWhiteBlanceStatus()

    val sfrStatus: Long
        get() = oneDriverImpl.getSfrStatus()

    val sfrResult: Long
        get() = oneDriverImpl.getSfrResult()

    /**
     * check c++ camera is whether opened
     *
     * @return if opened return true
     */
    fun checkOpen(): Boolean {
        return oneDriverImpl.checkCameraOpen()
    }

    /**
     * check c++ camera is whether synced
     *
     * @return if synced return true
     */
    fun checkSynced(): Boolean {
        return oneDriverImpl.checkCameraSynced()
    }

    fun setGlobalRequestTimeoutMs(timeoutMs: Int): Boolean {
        return oneDriverImpl.setGlobalRequestTimeoutMs(timeoutMs)
    }

    fun setGlobalRequestRetryCount(retryCount: Int): Boolean {
        return oneDriverImpl.setGlobalRequestRetryCount(retryCount)
    }

    val cloudStorageUploadStatus: Long
        get() = oneDriverImpl.getCloudStorageUploadStatus()

    fun deleteWifiHistoryInfo(ssid: String): Long {
        return oneDriverImpl.deleteWifiHistoryInfo(ssid)
    }


    fun setCloudStorageUploadStatus(cloudStorageUploadParams: CloudStorageUploadParams): Long {
        return oneDriverImpl.setCloudStorageUploadStatus(cloudStorageUploadParams)
    }

    val cloudStorageBindStatus: Long
        get() = oneDriverImpl.getCloudStorageBindStatus()

    fun setCloudStorageBindStatus(cloudStorageBindParams: CloudStorageBindParams): Long {
        return oneDriverImpl.setCloudStorageBindStatus(cloudStorageBindParams)
    }

    fun setNetworkConfigEnable(params: SetNetworkConfigEnable): Long {
        return oneDriverImpl.setNetworkConfigEnable(params)
    }

    fun syncAccurateTime(): Long {
        return oneDriverImpl.syncAccurateTime()
    }

    fun setCloudPromptInterval(intervalSeconds: Long, cloudBackupPromptsSeconds: Long): Long {
        return oneDriverImpl.setCloudPromptInterval(intervalSeconds, cloudBackupPromptsSeconds)
    }

    fun restoreFactorySettings(): Long {
        return oneDriverImpl.restoreFactorySettings()
    }

    fun setSingleHostCmdInfo(singleHostCmdInfo: SingleHostCmdInfo): Long {
        return oneDriverImpl.setSingleHostCmdInfo(singleHostCmdInfo)
    }

    fun getIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return oneDriverImpl.getIntervalRecCfg(intervalRecInfo)
    }

    fun setIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return oneDriverImpl.setIntervalRecCfg(intervalRecInfo)
    }

    fun startStopIntervalRec(intervalRecStartStop: IntervalRecStartStop): Long {
        return oneDriverImpl.startStopIntervalRec(intervalRecStartStop)
    }

    fun cancelIntervalRec(intervalRecCancel: IntervalRecCancel): Long {
        return oneDriverImpl.cancelIntervalRec(intervalRecCancel)
    }

    fun getIntervalRecStatus(): Long {
        return oneDriverImpl.getIntervalRecStatus()
    }

    fun getIntervalRecSceneCfg(): Long {
        return oneDriverImpl.getIntervalRecSceneCfg()
    }

    fun getIntervalRecFeedbackCfg(): Long {
        return oneDriverImpl.getIntervalRecFeedbackCfg()
    }

    fun setIntervalRecFeedbackCfg(intervalRecFeedback: IntervalRecFeedback): Long {
        return oneDriverImpl.setIntervalRecFeedbackCfg(intervalRecFeedback)
    }

    fun setAudioStream(request: AudioStreamCtrl, timeoutMs: Int = -1): Long {
        return oneDriverImpl.setAudioStream(request, timeoutMs)
    }

    fun setAiIntent(request: AiIntentCtrl): Long {
        return oneDriverImpl.setAiIntent(request)
    }

    fun setAssistantLanguage(request: AssistantLanguageCtrl): Long {
        return oneDriverImpl.setAssistantLanguage(request)
    }

    fun setUserRegion(request: UserRegionCtrl): Long {
        return oneDriverImpl.setUserRegion(request)
    }

    fun sendStreamData(streamType: StreamType, timestamp: Long, data: ByteArray) {
        oneDriverImpl.sendStreamData(streamType, timestamp, data)
    }
    fun getFirmwareVersionsInfo(): Long {
        return oneDriverImpl.getFirmwareVersionsInfo()
    }

    companion object {
        private const val TAG = "OneDriverJava"


        private const val DRIVER_INFO_NOTIFY = 0
        private const val DRIVER_USB_ERROR_NOTIFY = 1
        private const val DRIVER_STILL_IMAGE_NOTIFY = 2
        private const val DRIVER_RECORD_VIDEO_STATE_NOTIFY = 3
        private const val DRIVER_TIMELAPSESTATE_NOTIFY = 4
        private const val DRIVER_STEAM_DATA_NOTIFY = 5

        private const val DRIVER_STILL_IMAGE_WITHOUT_STORAGE_NOTIFY = 6

        private const val DRIVER_WIFI_PROXY_DATA_NOTIFY = 7

//        external fun setCameraDevMode(devMode: Boolean)
    }
}

