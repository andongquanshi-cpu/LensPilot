package com.arashivision.fmg.upgrade

import com.arashivision.fmg.FmgCommDelegate
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.common.BleLog
import com.arashivision.common.File

class AITrackUpgradeConfig private constructor(
    val requestId: Long,
    upgradeFilePathLis: List<String>,
    writeWithResponse: Boolean,
    PackDataSize: Int,
    packNum: Int,
    sendSinglePackTimeout: Long
) {
    private var mUpgradeFileTotalSize: Long = 0
    private val mUpgradeFilePathList: List<String>? = upgradeFilePathLis
    val isWriteWithResponse: Boolean
    val packDataSize: Int
    val packNum: Int

    // 发送单包数据的超时时间
    var sendSinglePackTimeout: Long

    init {
        packDataSize = PackDataSize
        this.isWriteWithResponse = writeWithResponse
        this.packNum = packNum
        this.sendSinglePackTimeout = sendSinglePackTimeout
    }

    val isValid: Boolean
        get() = mUpgradeFilePathList != null && !mUpgradeFilePathList.isEmpty()

    fun getOTAFileDataByIndex(index: Int): ByteArray? {
        if (mUpgradeFilePathList != null && mUpgradeFilePathList.size > index) {
            val file = File(mUpgradeFilePathList[index])
            if (file.exists()) {
                return FmgByteUtils.readBytesFromFile(file)
            }
        }
        return null
    }

    val upgradePartSize: Int
        get() {
            if (mUpgradeFilePathList != null) {
                return mUpgradeFilePathList.size
            }
            return 0
        }

    val upgradeFileTotalSize: Long
        get() {
            if (mUpgradeFileTotalSize == 0L) {
                var file: File
                for (path in mUpgradeFilePathList!!) {
                    try {
                        file = File(path)
                        if (file.exists()) {
                            mUpgradeFileTotalSize += file.length()
                        }
                    } catch (e: Exception) {
                        BleLog.e("AITrackUpgradeConfig readBytesFromFile error " + e.message)
                        e.printStackTrace()
                    }
                }
            }
            return mUpgradeFileTotalSize
        }

    override fun toString(): String {
        return "AITrackUpgradeConfig{" +
                "mRequestId=" + requestId +
                ", mUpgradeFileTotalSize=" + mUpgradeFileTotalSize +
                ", mUpgradeFilePathList=" + mUpgradeFilePathList +
                ", writeWithResponse=" + isWriteWithResponse +
                ", mPackDataSize=" + packDataSize +
                ", mPackNum=" + packNum +
                ", mSendSinglePackTimeout=" + sendSinglePackTimeout +
                '}'
    }

    class Builder(private val mUpgradeFilePathLis: List<String>) {
        private var mRequestId: Long = 0
        private var writeWithResponse = false
        private var packDataSize = DEFAULT_PACK_DATA_SIZE
        private var packNum = DEFAULT_PACK_NUM

        // 发送单包数据的超时时间
        private var mSendSinglePackTimeout = 4000L

        fun setRequestId(requestId: Long): Builder {
            mRequestId = requestId
            return this
        }

        fun setWriteWithResponse(writeWithResponse: Boolean): Builder {
            this.writeWithResponse = writeWithResponse
            return this
        }

        fun setPackDataSize(packDataSize: Int): Builder {
            this.packDataSize = packDataSize
            return this
        }

        fun setPackNum(packNum: Int): Builder {
            this.packNum = packNum
            return this
        }

        fun setSendSinglePackTimeout(sendSinglePackTimeout: Int): Builder {
            this.mSendSinglePackTimeout = sendSinglePackTimeout.toLong()
            return this
        }

        fun build(): AITrackUpgradeConfig {
            if (mRequestId == 0L) {
                mRequestId = FmgCommDelegate.Companion.generateRequestId()
            }
            return AITrackUpgradeConfig(
                mRequestId,
                mUpgradeFilePathLis,
                writeWithResponse,
                packDataSize,
                packNum,
                mSendSinglePackTimeout
            )
        }

        companion object {
            const val DEFAULT_PACK_DATA_SIZE: Int = 238
            const val DEFAULT_PACK_NUM: Int = 100
        }
    }
}
