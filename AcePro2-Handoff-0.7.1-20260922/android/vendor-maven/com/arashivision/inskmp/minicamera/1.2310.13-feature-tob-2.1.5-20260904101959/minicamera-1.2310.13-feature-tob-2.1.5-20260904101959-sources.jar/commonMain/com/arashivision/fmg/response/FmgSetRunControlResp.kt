package com.arashivision.fmg.response

class FmgSetRunControlResp(var requestID: Long)
