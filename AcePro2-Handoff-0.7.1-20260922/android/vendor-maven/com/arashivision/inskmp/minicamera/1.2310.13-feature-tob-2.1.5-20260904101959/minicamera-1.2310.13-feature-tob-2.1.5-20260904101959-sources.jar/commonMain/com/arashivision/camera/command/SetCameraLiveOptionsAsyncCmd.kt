package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveOptionCtrlInfo

class SetCameraLiveOptionsAsyncCmd(
    private val optionList: List<LiveBroadCastOptionType>,
    private val mOptions: LiveOptionCtrlInfo,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setCameraLiveOptionsAsync(optionList,mOptions, mRequestOptions)
    }
}
