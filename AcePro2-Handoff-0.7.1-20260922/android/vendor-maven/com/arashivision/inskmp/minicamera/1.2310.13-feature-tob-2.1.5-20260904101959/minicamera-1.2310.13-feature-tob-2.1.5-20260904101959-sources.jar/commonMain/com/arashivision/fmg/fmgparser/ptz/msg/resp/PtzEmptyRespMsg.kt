package com.arashivision.fmg.fmgparser.ptz.msg.resp

class PtzEmptyRespMsg : PtzDataRespMessage() {
    private val data = ByteArray(0)

    override fun unpack(data: ByteArray?) {
    }

    override fun toString(): String {
        return "null"
    }

    override fun name(): String {
        return "Resp data is empty"
    }
}
