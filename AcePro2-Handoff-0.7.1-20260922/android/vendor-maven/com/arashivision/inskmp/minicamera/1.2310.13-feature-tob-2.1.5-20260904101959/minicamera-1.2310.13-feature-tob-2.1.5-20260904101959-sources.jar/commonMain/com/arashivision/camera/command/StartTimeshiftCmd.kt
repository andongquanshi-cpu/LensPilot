package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StartTimeshiftCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.startTimeShift()
        return 0
    }
}
