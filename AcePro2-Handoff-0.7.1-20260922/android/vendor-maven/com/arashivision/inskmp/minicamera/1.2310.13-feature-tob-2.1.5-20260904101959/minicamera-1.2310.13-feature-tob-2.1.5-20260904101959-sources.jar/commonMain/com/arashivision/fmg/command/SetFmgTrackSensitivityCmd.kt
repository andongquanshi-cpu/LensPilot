package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.onecamera.OneDriver

class SetFmgTrackSensitivityCmd(private val mode: PtzTrackSensitivityMode) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetTrackSensitivityMode(mode)
    }
}
