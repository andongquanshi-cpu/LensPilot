package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SwitchWifiChannelCmd(needScan: Int, channel: Int) : InstaCmdExe {
    private var needScan = 2
    private var channel = 0

    fun setNeedScan(needScan: Int) {
        this.needScan = needScan
    }

    fun setChannel(channel: Int) {
        this.channel = channel
    }

    init {
        this.needScan = needScan
        this.channel = channel
    }

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.switchWifiChannel(needScan, channel)
    }
}
