package com.arashivision.camera.command

import com.arashivision.common.Log
import com.arashivision.onecamera.OneDriver
import insta360.messages.StartLiveStream

/**
 * 预览的cmd
 */
class PreviewStreamingCmd(
    startStreamingParam: StartLiveStream,
) :
    InstaCmdExe {
    private val mStreamingParam = startStreamingParam

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return setImagePipleStream(mStreamingParam, oneDrvier)
    }


    private fun setImagePipleStream(
        startStreamingParam: StartLiveStream,
        oneDrvier: OneDriver?,
    ): Long? {
        //设置流

        val retv = oneDrvier?.startStreaming(
            startStreamingParam
        )

        Log.d(TAG, "retv = $retv")
        Log.i(
            TAG, (" start streaming $startStreamingParam ")
        )
        return retv
    }

    companion object {
        private val TAG: String = PreviewStreamingCmd::class.simpleName.toString()
    }
}
