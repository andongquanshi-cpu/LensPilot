package com.arashivision.fmg.response

import com.arashivision.fmg.response.model.FmgAnalyticsParams
import com.arashivision.fmg.response.model.FmgBleAnalyticsParams

class FmgGetAnalyticsDataResp(
    var requestID: Long,
    var fmgAnalyticsParams: FmgAnalyticsParams?,
    var fmgBleAnalyticsParams: FmgBleAnalyticsParams? = null,
)
