package com.arashivision.fmg.response

import com.arashivision.fmg.response.model.FmgResetSettingsParams

class FmgSetResetSettingsResp(var requestID: Long, var resetSettingsParams: FmgResetSettingsParams?)
