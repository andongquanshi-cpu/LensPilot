package com.arashivision.utils

class CLogUtils {
    fun log(level: String, tag: String, message: String) {
        when (level) {
            "E" -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogE(tag, message)
                }
            }

            "W" -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogW(tag, message)
                }
            }

            "I" -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogI(tag, message)
                }
            }

            "D" -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogD(tag, message)
                }
            }

            "V" -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogV(tag, message)
                }
            }

            "FT" -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogFt(tag, message)
                }
            }

            else -> {
                if (sLoggerCallback != null) {
                    sLoggerCallback!!.onLogI(tag, message)
                }
            }
        }
    }


    fun setLoggerCallback(loggerCallback: ILoggerCallback?) {
        sLoggerCallback = loggerCallback
    }

    interface ILoggerCallback {
        fun onLogV(tag: String?, msg: String?)

        fun onLogD(tag: String?, msg: String?)

        fun onLogI(tag: String?, msg: String?)

        fun onLogW(tag: String?, msg: String?)

        fun onLogE(tag: String?, msg: String?)

        fun onLogFt(tag: String?, msg: String?)
    }

    companion object {
        private var sLoggerCallback: ILoggerCallback? = null
    }
}
