package com.arashivision.fmg.response

class FmgSetEtsResp(var requestID: Long)
