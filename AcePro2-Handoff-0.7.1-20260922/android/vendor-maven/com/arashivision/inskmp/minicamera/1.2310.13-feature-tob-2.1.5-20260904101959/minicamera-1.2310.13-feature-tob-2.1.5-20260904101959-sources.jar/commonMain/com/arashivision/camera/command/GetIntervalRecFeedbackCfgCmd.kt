package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 获取间隔录像交互反馈配置
 */
internal class GetIntervalRecFeedbackCfgCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.getIntervalRecFeedbackCfg()
    }
}
