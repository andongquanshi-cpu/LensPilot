package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.DataTransPortDir
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation

class RequestDataCmd(
    private val dir: DataTransPortDir,
    private val rxdatainfo: List<RequestReceiveDataInformation>?,
    private val txdatainfo: List<RequestSendDataInformation>?,
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.requestData(dir, rxdatainfo, txdatainfo)
    }
}
