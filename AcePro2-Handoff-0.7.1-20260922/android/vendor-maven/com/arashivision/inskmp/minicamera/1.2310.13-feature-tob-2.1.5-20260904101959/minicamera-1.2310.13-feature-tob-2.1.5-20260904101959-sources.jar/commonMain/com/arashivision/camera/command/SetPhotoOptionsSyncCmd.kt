package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions

class SetPhotoOptionsSyncCmd(
    private val mFuncMode: Int,
    private val optionTypes: List<PhotographyOptionType>,
    private val mPhotoOptions: PhotographyOptions,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setPhotographyOptionsAsync(
            mFuncMode,
            optionTypes,
            mPhotoOptions,
            mRequestOptions
        )
    }
}
