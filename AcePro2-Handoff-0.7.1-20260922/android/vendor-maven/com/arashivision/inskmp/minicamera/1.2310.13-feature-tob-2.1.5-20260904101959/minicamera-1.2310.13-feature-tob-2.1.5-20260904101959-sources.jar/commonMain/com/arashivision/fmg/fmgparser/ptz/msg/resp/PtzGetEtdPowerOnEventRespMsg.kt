package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.common.BleLog

class PtzGetEtdPowerOnEventRespMsg : PtzDataRespMessage() {
    var powerOnEventParamsArray: Array<PowerOnEventParams>? = null

    @OptIn(ExperimentalStdlibApi::class)
    override fun unpack(data: ByteArray?) {
        val list: MutableList<PowerOnEventParams> = ArrayList()
        try {
            val eventCountSignByteLength = 2
            if (data == null || data.size <= eventCountSignByteLength) {
                Log.d("unpack", "PtzGetEtdPowerOnEventRespMsg data error!!!!")
            } else {
                val eventCount = FmgByteUtils.uint16BytesToInt(data[0], data[1])
                if (eventCount > 0) {
                    val eventDataLength = (data.size - eventCountSignByteLength) / eventCount
                    var i = eventCountSignByteLength
                    while (i < data.size) {
                        val powerOnEventParams = PowerOnEventParams()
                        if (eventDataLength >= 2) {
                            powerOnEventParams.serial_number = FmgByteUtils.uint16BytesToInt(
                                data[i],
                                data[i + 1]
                            )
                        }
                        list.add(powerOnEventParams)
                        i += eventDataLength
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // 固件经常返回异常数据
            BleLog.e(
                "PtzGetEtdPowerOnEventRespMsg data invalid, throw exception! data = " + data?.toHexString(
                    HexFormat.Default
                )
            )
        }
        powerOnEventParamsArray = list.toTypedArray<PowerOnEventParams>()
    }

    override fun toString(): String {
        return "powerOnEventParamsArray length = " + (if (powerOnEventParamsArray != null) powerOnEventParamsArray!!.size else 0)
    }

    override fun name(): String {
        return "CMD_GET_ETD - PowerOnEvent"
    }

    class PowerOnEventParams {
        var serial_number: Int = 0
    }
}
