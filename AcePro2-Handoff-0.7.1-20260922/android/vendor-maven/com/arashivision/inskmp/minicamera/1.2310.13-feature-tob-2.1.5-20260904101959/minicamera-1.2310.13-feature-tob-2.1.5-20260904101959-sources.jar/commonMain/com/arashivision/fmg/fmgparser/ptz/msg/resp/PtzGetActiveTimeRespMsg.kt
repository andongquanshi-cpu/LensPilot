package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetActiveTimeRespMsg : PtzDataRespMessage() {
    var time: Long = 0

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 8) {
            time = -1
            Log.d("unpack", "error!!!!")
            return
        } else {
            time = FmgByteUtils.uint64ByteArrayToLong(data)
        }
    }

    override fun toString(): String {
        return time.toString()
    }

    override fun name(): String {
        return "CMD_DEVICE_STATUS_RESP"
    }
}
