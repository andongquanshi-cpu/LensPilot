package com.arashivision.camera.command.usb

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * 相机屏幕触点测试
 */
class ContactTestCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.startContactTest()
        return null
    }
}
