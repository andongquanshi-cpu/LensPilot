package com.arashivision.fmg.response.model

import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdBleQuickStartEventRespMsg

class FmgBleAnalyticsParams private constructor(builder: Builder) {
    val samsungTrackingEvent: SamsungTrackingEvent?

    val quickStartEventArray: Array<QuickStartEvent?>?

    init {
        this.samsungTrackingEvent = builder.samsungTrackingEvent
        this.quickStartEventArray = builder.quickStartEventArray
    }

    class Builder {
        var samsungTrackingEvent: SamsungTrackingEvent? = null
            private set
        var quickStartEventArray: Array<QuickStartEvent?>? = null
            private set

        fun setTotalSamsungTrackingTimes(samsungTrackingEvent: SamsungTrackingEvent?): Builder {
            this.samsungTrackingEvent = samsungTrackingEvent
            return this
        }

        fun setQuickStartEventArray(quickStartEventArray: Array<QuickStartEvent?>?): Builder {
            this.quickStartEventArray = quickStartEventArray
            return this
        }

        fun build(): FmgBleAnalyticsParams {
            return FmgBleAnalyticsParams(this)
        }
    }

    class QuickStartEvent(
        /**
         * 快速开拍发送消息结果
         * 0：固件蓝牙发送失败
         * 1: 固件蓝牙发送成功
         */
        val result: Int,
        /**
         * 快速开拍使能厂商序号
         */
        val phoneBrand: Int,
    ) {
        constructor(params: PtzGetEtdBleQuickStartEventRespMsg.QuickEventParams) : this(params.result, params.phoneBrand)
    }

    class SamsungTrackingEvent(
        /**
         * 三星追踪连接总次数
         */
        val totalSamsungTrackingTimes: Long,
    )
}
