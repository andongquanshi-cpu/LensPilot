package com.arashivision.common.coroutines

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.SupervisorJob

// 职责明确: 每个作用域都有明确的使用场景
// 性能优化: 根据任务类型选择合适的线程池
// 错误隔离: 使用 SupervisorJob 确保单个协程失败不影响整体
// 扩展性好: 保留了自定义调度器的能力

/**
 * 获取平台特定的主线程调度器
 * 
 * 注意：在 OHOS 平台上，由于使用 knoi 框架，Dispatchers.Main 可能未正确初始化
 * 因此在 OHOS 平台使用 Dispatchers.Default，其他平台使用 Dispatchers.Main
 */
private val platformMainDispatcher: CoroutineDispatcher
    get() = try {
        // 尝试获取 Main 调度器，如果失败则使用 Default
        Dispatchers.Main
    } catch (e: Exception) {
        // 在 OHOS 平台或其他 Main 调度器不可用的情况下，使用 Default
        Dispatchers.Default
    }

/**
 * 主线程协程作用域，用于 UI 更新和主线程操作
 * 
 * 在 OHOS 平台上，实际回调到主线程的操作应该使用 knoi 框架的 runOnMainThread
 * 此作用域主要用于协程的串行化处理，不保证在真正的主线程执行
 */
//val mainScope = CoroutineScope(SupervisorJob() + platformMainDispatcher)

/**
 * IO 协程作用域，用于文件操作、网络请求等 IO 密集型任务
 */
val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

/**
 * 异步计算协程作用域，用于 CPU 密集型任务和并行计算
 */
val asyncScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

/**
 * 通用协程作用域提供器，支持自定义调度器
 * @param dispatcher 自定义的协程调度器
 * @return 基于指定调度器的协程作用域
 */
fun providesCoroutineScope(dispatcher: CoroutineDispatcher) =
    CoroutineScope(SupervisorJob() + dispatcher)

/**
 * 安全地在主线程执行代码块
 * 
 * 这个函数会根据平台自动选择合适的主线程执行方式：
 * - OHOS 平台：使用 knoi 框架的 runOnMainThread
 * - 其他平台：使用协程的 Dispatchers.Main
 * 
 * 使用示例：
 * ```
 * runOnMainThread {
 *     // 这里的代码在主线程执行
 * }
 * ```
 * 
 * @param block 要在主线程执行的代码块
 */
expect fun runOnMainThread(block: () -> Unit)