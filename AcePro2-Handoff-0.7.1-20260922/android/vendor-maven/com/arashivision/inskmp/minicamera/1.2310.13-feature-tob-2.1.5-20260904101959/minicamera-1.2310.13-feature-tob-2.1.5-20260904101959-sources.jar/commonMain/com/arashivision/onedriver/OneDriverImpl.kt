package com.arashivision.onedriver

import com.arashivision.ble.OneBleIOProxy
import com.arashivision.common.BleLog
import com.arashivision.common.Log
import com.arashivision.common.currentTimeMillis
import com.arashivision.inskmp.inssocket.TunnelManagerCore
import com.arashivision.inskmp.inssocket.callback.TunnelCallbackCore
import com.arashivision.inskmp.inssocket.data.TunnelData
import com.arashivision.minicamera.DEBUG
import com.arashivision.onecamera.OneDriverInfo
import com.arashivision.onedriver.InfoTypeMapper.infoTypeFromMessageCode
import com.arashivision.onedriver.action.Action
import com.arashivision.onedriver.action.ActionCategory
import com.arashivision.onedriver.action.ActionQueue
import com.arashivision.onedriver.action.ActionState
import com.arashivision.onedriver.bean.AiVoiceNotification
import com.arashivision.onedriver.bean.Message
import com.arashivision.onedriver.bean.MessageType
import com.arashivision.onedriver.bean.OpState
import com.arashivision.onedriver.bean.OpenAiVoice
import com.arashivision.onedriver.bean.OpenClassicBluetooth
import com.arashivision.onedriver.bean.StreamData
import com.arashivision.onedriver.bean.UsbState
import com.arashivision.onedriver.ble.OneBle
import com.arashivision.onedriver.io.SocketIO
import com.arashivision.onedriver.io.SocketIO.Companion.ERR_SOCKET_DEVICE_BUSY
import com.arashivision.onedriver.packet.Go2BlePacket
import com.arashivision.onedriver.packet.LinuxCmdCmd
import com.arashivision.onedriver.packet.LinuxCmdDirection
import com.arashivision.onedriver.packet.MessageContentType
import com.arashivision.onedriver.packet.MessageDemuxer
import com.arashivision.onedriver.packet.MessageDirection
import com.arashivision.onedriver.packet.MessageMuxer
import com.arashivision.onedriver.packet.Packet
import com.arashivision.onedriver.packet.PacketType
import com.arashivision.onedriver.packet.Protocol
import com.arashivision.onedriver.packet.StreamType
import com.arashivision.onedriver.usb.OneUsb
import com.arashivision.onedriver.utils.StringEncodingUtils
import com.arashivision.onedriver.wapper.parseProtoResponse
import insta360.messages.AiHighlightStatusNotification
import insta360.messages.AiIntentCtrl
import insta360.messages.AssistantLanguageCtrl
import insta360.messages.AudioStreamCtrl
import insta360.messages.AuthorizationOperationType
import insta360.messages.AutoSwitchNightVideo
import insta360.messages.ButtonPressMode
import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType
import insta360.messages.ButtonPressType
import insta360.messages.ButtonStatus
import insta360.messages.CalibrateGyro
import insta360.messages.CancelAngleFixed
import insta360.messages.CameraLiveResult
import insta360.messages.CameraWifiConnectionResult
import insta360.messages.CaptureMode
import insta360.messages.CaptureStatus
import insta360.messages.CardLocation
import insta360.messages.ChargeboxConnectedStatus
import insta360.messages.ChargingBoxData
import insta360.messages.CheckAuthorization
import insta360.messages.CloudStorageBindParams
import insta360.messages.CloudStorageUploadParams
import insta360.messages.ConnectToBTPeripheral
import insta360.messages.CtrlPreRecord
import insta360.messages.DashCamInfo
import insta360.messages.DataTransPort
import insta360.messages.DataTransPortDir
import insta360.messages.DataTransportResult
import insta360.messages.DeleteFiles
import insta360.messages.DeleteWifiConnectList
import insta360.messages.DetachableScreenConnectedStatus
import insta360.messages.DisconnectBTPeripheral
import insta360.messages.DownLoadInfo
import insta360.messages.DownloadListResultSync
import insta360.messages.EncryptCapabilityQuery
import insta360.messages.EncryptKeyExchangeReq
import insta360.messages.EncryptScheme
import insta360.messages.Error
import insta360.messages.ExtraMetadata
import insta360.messages.FeatureBluetoothMacBind
import insta360.messages.FormatStorage
import insta360.messages.FunctionMode
import insta360.messages.GetActiveSensorDevice
import insta360.messages.GetButtonParams
import insta360.messages.GetConnectedBTPeripheral
import insta360.messages.GetFile
import insta360.messages.GetFileExtra
import insta360.messages.GetFileFinish
import insta360.messages.GetFileList
import insta360.messages.GetFlowstateEnable
import insta360.messages.GetGyro
import insta360.messages.GetLiveOptions
import insta360.messages.GetMiniThumbnail
import insta360.messages.GetMultiPhotographyOptions
import insta360.messages.GetOptions
import insta360.messages.GetPhotographyOptions
import insta360.messages.GetPhotographyOptionsResp
import insta360.messages.GetPresetComposition
import insta360.messages.GetTimelapseOptions
import insta360.messages.GetWifiConnectList
import insta360.messages.GetWifiMode
import insta360.messages.GetWifiScanInfo
import insta360.messages.GimbalControl
import insta360.messages.IntervalRecCancel
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecStartStop
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveBroadCastStatus
import insta360.messages.LiveOptionCtrlInfo
import insta360.messages.LivePhotoSwitch
import insta360.messages.LiveStreamParamsUpdate
import insta360.messages.MessageCode
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.NotificationTmTrackerEarHookWearState
import insta360.messages.NotificationAudioActivityStatus
import insta360.messages.NotificationAuthorizationResult
import insta360.messages.NotificationBatteryUpdate
import insta360.messages.NotificationBluetoothCurrInfo
import insta360.messages.NotificationCameraPostureUpdate
import insta360.messages.NotificationCaptureAutoSplit
import insta360.messages.NotificationCaptureStopped
import insta360.messages.NotificationCardUpdate
import insta360.messages.NotificationCloudUploadStatus
import insta360.messages.NotificationDarkEisStatus
import insta360.messages.NotificationDeleteFileOperation
import insta360.messages.NotificationDetectFace
import insta360.messages.NotificationExposureUpdate
import insta360.messages.NotificationGimbalCalibration
import insta360.messages.GimbalStatus
import insta360.messages.NotificationOffsetStateUpdate
import insta360.messages.NotificationP2pTransStatus
import insta360.messages.NotificationPostureRebuildState
import insta360.messages.NotificationRecipeShare
import insta360.messages.NotificationPtzPerspectiveStatus
import insta360.messages.NotificationPhotographyOptions
import insta360.messages.NotificationSendDataInformation
import insta360.messages.NotificationShutdown
import insta360.messages.NotificationStorageLocationChange
import insta360.messages.NotificationStreetPhotoStatus
import insta360.messages.NotificationSupportTakePhotoInREC
import insta360.messages.NotificationTakePictureStateUpdate
import insta360.messages.NotificationTimeLapseStatusUpdate
import insta360.messages.NotificationWifiChannelSwitch
import insta360.messages.NotificationWifiInterfStatus
import insta360.messages.NotificatoinConnectedToPeripheral
import insta360.messages.NotificatoinDisconnectedPeripheral
import insta360.messages.NotificatoinDiscoverBTPeripheral
import insta360.messages.NotificatoinKeyPressed
import insta360.messages.NotifyCameraSubMode
import insta360.messages.OpenIperfService
import insta360.messages.OpenTrackingWithRect
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.PhoneInfo
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.PtzTrackStateReport
import insta360.messages.Ptz_Movement_Status
import insta360.messages.RecipeShareStatus
import insta360.messages.RequestAuthorization
import insta360.messages.RequestData
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation
import insta360.messages.RestartWifi
import insta360.messages.ScanBTPeripheral
import insta360.messages.SensorDevice
import insta360.messages.SetAccessCameraFileState
import insta360.messages.SetActiveSensorDevice
import insta360.messages.SetAppid
import insta360.messages.SetAvailableWifi
import insta360.messages.SetButtonParams
import insta360.messages.SetCloudShowTab
import insta360.messages.SetCloudStorageBindStatus
import insta360.messages.SetCloudStorageUploadStatus
import insta360.messages.SetFavoriteList
import insta360.messages.SetFileExtra
import insta360.messages.SetFlowstateEnable
import insta360.messages.SetKeyTimePoint
import insta360.messages.SetLiveOptions
import insta360.messages.SetMultiPhotographyOptions
import insta360.messages.SetNetworkConfigEnable
import insta360.messages.SetOptions
import insta360.messages.SetPhotographyOptions
import insta360.messages.SetPresetComposition
import insta360.messages.SetPromptInterval
import insta360.messages.SetStandbyMode
import insta360.messages.SetStorage
import insta360.messages.PhotoSettingPage
import insta360.messages.SetSyncCaptureMode
import insta360.messages.SetTimelapseOptions
import insta360.messages.SetWifiConnectionInfo
import insta360.messages.SetWifiMode
import insta360.messages.SetWifiNetResult
import insta360.messages.SetWifiSeizeEnable
import insta360.messages.SingleHostCmdInfo
import insta360.messages.SingleHostNotifyInfo
import insta360.messages.StartCameraLive
import insta360.messages.StartCapture
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopBulletTime
import insta360.messages.StopBulletTimeResp
import insta360.messages.StopCameraLive
import insta360.messages.StopCapture
import insta360.messages.StopCaptureResp
import insta360.messages.StopHdr
import insta360.messages.StopHdrResp
import insta360.messages.StopLiveStream
import insta360.messages.StopTimeShift
import insta360.messages.StopTimeShiftResp
import insta360.messages.StopTimelapse
import insta360.messages.StopTimelapseResp
import insta360.messages.SwitchWifiChannel
import insta360.messages.SyncCaptureMode
import insta360.messages.SyncTimeAccurate
import insta360.messages.TakePicture
import insta360.messages.TakePictureResponse
import insta360.messages.TempState
import insta360.messages.TestSDCardSpeed
import insta360.messages.TimeAccurate_Info
import insta360.messages.TrackState
import insta360.messages.UpgradeStateOptions
import insta360.messages.UploadGps
import insta360.messages.UsbCardStatus
import insta360.messages.UserRegionCtrl
import insta360.messages.Video
import insta360.messages.VideoResolution
import insta360.messages.WifiCloseInfo
import insta360.messages.WifiConnectionInfo
import insta360.messages.WifiMode
import insta360.messages.WifiModeResult
import kotlinx.atomicfu.AtomicInt
import kotlinx.atomicfu.atomic
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.trySendBlocking
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okio.ByteString.Companion.toByteString
import kotlin.concurrent.Volatile


/**
 * OneDriver的纯Kotlin实现
 * 使用协程替代Handler机制，优雅地处理异步操作
 */
class OneDriverImpl {
    companion object {
        const val TAG = "OneDriverImpl"
        const val TRIGGER_ACTION_MIN_INTERVAL_TIME = 4L

        // BLE+SPP 共存时,这些主动通知仅由 SPP 通道消费,不转发给 BLE(数据传输/音频活动类只走 SPP)。
        private val SPP_ONLY_NOTIFICATIONS = setOf(
            MessageCode.CAMERA_NOTIFICATION_DATA_INFO_READY,
            MessageCode.CAMERA_NOTIFICATION_DATA_TRANSPORT,
            MessageCode.CAMERA_NOTIFICATION_AUDIO_ACTIVITY_STATUS,
            MessageCode.CAMERA_NOTIFICATION_AI_QUIT_ASSISTANT,
        )
    }

    private var mError: AtomicInt = atomic(0)

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val messageDispatcher = Dispatchers.Default.limitedParallelism(1)

    // 互斥锁
    private val mutex = Mutex()

    // 状态变量
    @Volatile
    private var isOpened = false
    private var isWriteSynced = false
    private var isClassicConnected = false
    private var tunnelServerPort = 0
    private var isBleProxy = false
    private var currentProtocol = Protocol.USB
    private var usbSysPath = ""
    private var networkHandle = -1L
    private var wifiAddr = ""
    private var wifiPort = 0
    private var globalRequestRetryTime = 0
    private var globalRequestTimeoutMs = 0
    private var mSyncTimeAccurateCount = 0
    private var isWifiDebug = false
    private var isProcessBusyEnable = false
    private var lastTriggerActionTime = 0L

    // 消息通道 - 替代Handler机制
    private val messageChannel = Channel<Message>(Channel.UNLIMITED)

    // BLE+SPP 共存:SPP 的 OneDriverImpl 持有 BLE 的 OneDriverImpl,用于把同步包/通知转发给 BLE。
    @Volatile
    internal var peerBleDriver: OneDriverImpl? = null

    // BLE+SPP 共存:BLE 注册此监听,接收经 SPP 转发来的同步包/心跳包(由 peerBleDriver 回调)。
    @Volatile
    internal var forwardedSyncListener: ((ByteArray) -> Unit)? = null


    // 回调函数
    private var usbStateCallback: ((UsbState, Int) -> Unit)? = null
    private var infoCallback: ((Int, Long, Int, Any?) -> Unit)? = null
    private var streamDataCallback: ((StreamData) -> Unit)? = null
    private var timelapseCallback: ((Int, Int, Video?) -> Unit)? = null
    private var recordVideoCallback: ((Int, Int, Video?) -> Unit)? = null
    private var stillImageWithoutStorageCallback: ((Int, ByteArray?) -> Unit)? =
        null
    private var stillImageCallback: ((Int, TakePictureResponse?) -> Unit)? = null
    private var needReconnectCallback: (() -> Boolean)? = null
    private var onReconnectSuccessCallback: (() -> Unit)? = null
    private var wifiProxyDataCallback: ((ByteArray) -> Unit)? = null

    // 加密协商内部回调
    private val encryptCallbacks = mutableMapOf<Long, (Int, Any?) -> Unit>()

    /**
     * 已应答并出队的拍照请求 messageId。
     *
     * 部分机型(如 X6)对同一个拍照请求会应答两次:首个应答仅表示指令已受理,
     * TakePictureResponse 为空(无成片路径);待落盘完成后,相机针对同一 messageId
     * 再回一个带成片路径的应答。而 [onClientResponse] 在首个应答到达时已将 action
     * 出队,第二个应答便落入"无响应等待项"分支被整包丢弃,成片路径随之丢失。
     *
     * 这里记录首个应答出队时的拍照 messageId,使第二个应答仍能被识别、解析并分发。
     * 不保留 action 本身是为了避免拍照请求滞留 [responseWaitQueue] ——
     * [hasAVActionWaitingResponse] 会将其视为 AV 操作进行中,从而阻塞后续所有非中断指令。
     */
    private var lastAnsweredTakePictureMessageId: Long? = null

    // IO接口 - 替代具体的IO实现
    private var usbIO: OneUsb? = null
    private var mTunnel: TunnelManagerCore? = null
    private var bleIO: OneBle? = null
    private var socketIO: SocketIO? = null
    private var messageDemuxer: MessageDemuxer? = null

    private var messageIdCounter = atomic(0L)

    // Action队列管理 - 对应C++版本的mPrepareQueue和mResponseWaitQueue
    private val prepareQueue = ActionQueue()
    private val responseWaitQueue = ActionQueue()
    private val scheduledTasks = mutableMapOf<Long, Job>()

    // 状态标志
    private var reconnecting = false
    private var hasActionUpdateMsg = false
    private var streamStarted = false
    private var isClosing = false

    // 消息循环任务
    private var messageLoopJob: Job? = null

    private fun startMessageLoop() {
        if (messageLoopJob != null) {
            return
        }
        Log.e(TAG, "startMessageLoop ${messageLoopJob != null}  ${this.hashCode()}")
        messageLoopJob = scope.launch(messageDispatcher) {
//            try {
            for (message in messageChannel) {
//                    Log.e(TAG, "handleMessage ${message.type}  ${this.hashCode()}")
                handleMessage(message)
            }
//            } catch (e: Exception) {
//                Log.e(TAG, "Message loop error: ${e.message}")
//            }
        }
    }

    // 发送延迟消息
    private fun sendDelayedMessage(
        type: MessageType,
        id: Long,
        delayMs: Long,
    ) {
        if (messageLoopJob == null) return
        val message = Message(type, mapOf("actionId" to id))
        // 取消之前的同名任务
        scheduledTasks[id]?.cancel()

        // 创建新的延迟任务
        scheduledTasks[id] = scope.launch {
            delay(delayMs)
            messageChannel.trySendBlocking(message)
            scheduledTasks.remove(id)
        }
    }

    // 取消延迟消息
    private fun cancelDelayedMessage(id: Long) {
        scheduledTasks[id]?.cancel()
        scheduledTasks.remove(id)
    }


    /**
     * 停止消息循环
     */
    private fun stopMessageLoop() {
        messageLoopJob?.cancel()
        messageLoopJob = null
    }

    /**
     * 发送消息到消息循环
     */
    private fun sendMessage(type: MessageType, data: Map<String, Any>? = null) {
        if (messageLoopJob == null) return
        val message = Message(type, data)
        messageChannel.trySendBlocking(message)
    }


    /**
     * 处理启动消息 - 对应C++版本的kWhatStart处理
     */
    private suspend fun handleStart(data: Map<String, Any?>?) {
        // 对应C++版本：mMessageDemuxer = sp<MessageDemuxer>(new MessageDemuxer())
        messageDemuxer = MessageDemuxer()

        when (currentProtocol) {
            Protocol.USB -> {
                usbIO?.setNotify { data ->
                    sendMessage(MessageType.USB_IO, data)
                }
                usbIO?.serve()

                // 创建隧道
                mTunnel = TunnelManagerCore()
                mTunnel?.init()
                mTunnel?.setOnReadableCallback(object : TunnelCallbackCore {
                    override fun OnReadableCallback() {
                        sendMessage(MessageType.TUNNEL_RADABLE, null)
                    }
                })
                tunnelServerPort = mTunnel?.getServerPort() ?: 0
            }

            Protocol.Bluetooth, Protocol.Go2Bluetooth -> {
                // 对应C++版本：mOneBle->setNotify(obtainMessage(kWhatUsbIO))
                bleIO?.setNotify { data ->
                    sendMessage(MessageType.USB_IO, data)
                }
                // BLE不需要额外的serve()调用
            }

            Protocol.Socket -> {
                socketIO?.setNotify { data ->
                    sendMessage(MessageType.USB_IO, data)
                }
                socketIO?.serve()
            }
        }
        val completableDeferred = data?.get("reply") as CompletableDeferred<Int>?

        completableDeferred?.complete(0)
    }


    /**
     * 处理Ble错误消息
     */
    private fun handleBleErrorMessage(data: Map<String, Any?>?) {
        // 处理BLE错误消息
        val error = data?.get("error") as Int? ?: 0
        mError.value = error
        usbStateCallback?.invoke(UsbState.ERROR, mError.value)
    }


    /**
     * 从Action创建Message
     */
    private fun createMessageFromAction(action: Action): com.arashivision.onedriver.packet.Message {
        val messageId = action.getId()
        val method = action.getOp()

        return when {
            action.hasProp("param") -> {
                val param = action.getParam()!!
                com.arashivision.onedriver.packet.Message(
                    messageMethod = method.value,
                    messageContentType = com.arashivision.onedriver.packet.MessageContentType.ApplicationProtobuf,
                    messageDirection = com.arashivision.onedriver.packet.MessageDirection.PhoneToCamera,
                    messageId = messageId,
                    protobufMessage = param
                )
            }

            action.hasProp("raw") -> {
                val raw = action.getRaw()!!
                com.arashivision.onedriver.packet.Message(
                    messageMethod = method.value,
                    messageContentType = com.arashivision.onedriver.packet.MessageContentType.ApplicationOctetStream,
                    messageDirection = com.arashivision.onedriver.packet.MessageDirection.PhoneToCamera,
                    messageId = messageId,
                    messageContent = raw
                )
            }

            else -> {
                com.arashivision.onedriver.packet.Message(
                    messageMethod = method.value,
                    messageContentType = com.arashivision.onedriver.packet.MessageContentType.ApplicationProtobuf,
                    messageDirection = com.arashivision.onedriver.packet.MessageDirection.PhoneToCamera,
                    messageId = messageId
                )
            }
        }
    }

    fun setClassicBluetoothStatus(isSuccess: Boolean) {
        isClassicConnected = isSuccess
    }

    fun isClassicConnected(): Boolean {
        return isClassicConnected
    }

    suspend fun openBle(oneBleIOProxy: OneBleIOProxy, isUseUcd2: Boolean): Int = mutex.withLock {
        if (isOpened) {
            // 对应C++版本的LOGE("ble already opened")
            return -1
        }
        startMessageLoop()
        // 对应C++版本：mProtocol = Protocol::BLUETOOTH
        currentProtocol = Protocol.Bluetooth
        isOpened = true

        // 对应C++版本：mOneBle = sp<OneBle>(new OneBle(obj))
        Packet.useUcd2 = isUseUcd2
        bleIO = OneBle(oneBleIOProxy)

        // 对应C++版本：发送kWhatStart消息并等待结果
        // 使用Deferred来模拟C++版本的promise/future机制
        val startResult = CompletableDeferred<Int>()

        // 发送START消息，对应C++版本的obtainMessage(kWhatStart)->post()
        sendMessage(MessageType.START, mapOf("reply" to startResult))

        // 等待启动完成，对应C++版本的openFuture.get()
        return startResult.await()
    }

    fun setBleProxy(isProxy: Boolean) {
        isBleProxy = isProxy
        currentProtocol = if (isProxy) Protocol.Go2Bluetooth else Protocol.Bluetooth
    }

    /**
     * 经典蓝牙链路上仍然需要按代理协议解析数据，但业务消息必须走普通 Packet，
     * 否则会多包一层 Go2BlePacket 头（ff 07 40 ...）。
     */
    private fun refreshBluetoothProtocol() {
        if (currentProtocol != Protocol.Bluetooth && currentProtocol != Protocol.Go2Bluetooth) {
            return
        }
        currentProtocol = if (isBleProxy && !isClassicConnected) {
            Protocol.Go2Bluetooth
        } else {
            Protocol.Bluetooth
        }
    }

    suspend fun openWifi(
        networkHandle: Long,
        timeout: Int,
        addr: String,
        port: Int,
        isUseUcd2: Boolean,
        processPacketEnable: Boolean,
    ): Int = mutex.withLock {
        if (isOpened) return -1


        Packet.useUcd2 = isUseUcd2
        isWriteSynced = isUseUcd2

        this.networkHandle = networkHandle
        this.wifiAddr = addr
        this.wifiPort = port
        currentProtocol = Protocol.Socket
        this.isOpened = true
        startMessageLoop()
        // 创建Socket IO接口
        socketIO = SocketIO()
        val result = socketIO?.open(networkHandle, timeout, addr, port) ?: -1
        socketIO?.setProcessBusyPacket(processPacketEnable)

        socketIO?.setDebug(isWifiDebug)
        if (result != 0) {
            return@withLock result
        }
        val startResult = CompletableDeferred<Int>()

        // 发送START消息，对应C++版本的obtainMessage(kWhatStart)->post()
        sendMessage(MessageType.START, mapOf("reply" to startResult))

        // 等待启动完成，对应C++版本的openFuture.get()
        return startResult.await()
    }

    /**
     * socket 打开失败后还原状态，使其能基于同一 networkHandle 重新 openWifi。
     * openWifi 失败时不会复位 isOpened，不调用此方法则重试会被开头的 isOpened 检查挡掉。
     */
    suspend fun resetSocketForRetry(): Int = mutex.withLock {
        if (currentProtocol != Protocol.Socket) return 0
        stopMessageLoop()
        socketIO?.close()
        socketIO = null
        isOpened = false
        isWriteSynced = false
        return 0
    }

    suspend fun openUsb(usbSysPath: String): Int = mutex.withLock {
        if (isOpened) return -1

        this.usbSysPath = usbSysPath
        this.currentProtocol = Protocol.USB
        this.isOpened = true

        startMessageLoop()
        // 创建USB IO接口
        usbIO = OneUsb()
        val result = usbIO?.open(usbSysPath) ?: -1

        if (result != 0) {
            return@withLock result
        }

        val startResult = CompletableDeferred<Int>()

        // 发送START消息，对应C++版本的obtainMessage(kWhatStart)->post()
        sendMessage(MessageType.START, mapOf("reply" to startResult))

        // 等待启动完成，对应C++版本的openFuture.get()
        return startResult.await()
    }

    suspend fun close(): Int = mutex.withLock {
        if (!isOpened) return 0
        isClosing = true


        if (streamStarted) {
            stopStreaming()
        }
        // 停止消息循环
        stopMessageLoop()

        // 关闭IO连接
        when (currentProtocol) {
            Protocol.USB -> usbIO?.close()
            Protocol.Bluetooth, Protocol.Go2Bluetooth -> bleIO = null
            Protocol.Socket -> socketIO?.close()
        }
        mTunnel?.release()
        mTunnel?.destroy()
        mTunnel = null

        mError.value = 0
        isOpened = false
        isClassicConnected = false
        isWriteSynced = false
        streamStarted = false
        reconnecting = false
        hasActionUpdateMsg = false
        lastTriggerActionTime = 0
        // 关闭时清除待补发的拍照请求记录,避免跨连接残留导致误判
        lastAnsweredTakePictureMessageId = null
        // BLE+SPP 共存:关闭时清除转发链引用与同步包监听,避免悬空指针
        peerBleDriver = null
        forwardedSyncListener = null
        messageDemuxer = null

        globalRequestTimeoutMs = 0
        globalRequestRetryTime = 0
        tunnelServerPort = 0
        prepareQueue.clear()
        responseWaitQueue.clear()
        encryptCallbacks.clear()
        if (Packet.encryptParams != null) {
            Log.e(TAG, "encrypt: cleared")
            Packet.encryptParams = null
            Packet.decryptParams = null
        }
        usbSysPath = ""


        return 0
    }

    fun getTunnelServerPort(): Int {
        return tunnelServerPort
    }

    private fun ByteArray.readUInt32LE(offset: Int): UInt {
        return ((this[offset].toUByte().toUInt()) or
                (this[offset + 1].toUByte().toUInt() shl 8) or
                (this[offset + 2].toUByte().toUInt() shl 16) or
                (this[offset + 3].toUByte().toUInt() shl 24)
                )
    }

    suspend fun putData(data: ByteArray, isBleProxy: Boolean) {
        if (isBleProxy && data.size >= 19 && data[0] == 0xff.toByte() && data[1] == 0x0d.toByte() && data[2] == 0x05.toByte()) { // TC4 经典蓝牙open
            val sessionId = data.readUInt32LE(5).toLong()        // 取低32位放到 Long
            val connectType = data[9].toUByte().toInt()                 // 0:广播扫描；1：直连
            val btMac = (15 downTo 10)                             // 6 字节
                .joinToString(":") { i ->
                    data[i].toUByte().toString(16).padStart(2, '0')
                }
            val result = data[16].toUByte().toInt()                     // UInt8 → Int
            val openClassicBluetooth = OpenClassicBluetooth(sessionId, connectType, btMac, result)
            Log.d(TAG, "putData, $openClassicBluetooth")
            infoCallback?.invoke(OneDriverInfo.Response.InfoType.UNKNOWN, sessionId, 0, openClassicBluetooth)
            return
        } else if (isBleProxy && data.size > 10 && data[0] == 0xff.toByte() && data[1] == 0x0d.toByte() && data[2] == 0x07.toByte()) { // TC4 发起语言助手指令
            val sessionId = data.readUInt32LE(5).toLong()        // 取低32位放到 Long
            val result = data[9].toUByte().toInt()                      // UInt8 → Int
            val openAiVoice = OpenAiVoice(sessionId, result)
            Log.d(TAG, "putData, $openAiVoice")
            infoCallback?.invoke(OneDriverInfo.Response.InfoType.UNKNOWN, sessionId, 0, openAiVoice)
            return
        } else if (isBleProxy && data[0] == 0xff.toByte() && data[1] == 0x0d.toByte() && data[2] == 0x08.toByte()) { // TC4 发起语言助手指令
            val obj = AiVoiceNotification()
            Log.d(TAG, "putData, $obj")
            infoCallback?.invoke(OneDriverInfo.Response.InfoType.UNKNOWN, -1, 0, obj)
            return
        }
        bleIO?.putData(data, isBleProxy, isClassicConnected)
    }

    fun startStreaming(
        startLiveStream: StartLiveStream,
    ): Long {
        if (currentProtocol == Protocol.Bluetooth) return -1
        if (!isOpened) return -1
//        if (streamStarted) return -1
        streamStarted = true
        Log.d(TAG, "startStreaming run")

        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to startLiveStream,
            "method" to MessageCode.PHONE_COMMAND_START_LIVE_STREAM
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopStreaming(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopStreaming run")
        streamStarted = false
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopLiveStream(),
            "method" to MessageCode.PHONE_COMMAND_STOP_LIVE_STREAM
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun requestStreamingIframe(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "requestStreamingIframe run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND__IFRAME_REQUEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopUsbcardBackup(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopUsbcardBackup run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_STOP_USBCARD_BACKUP
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getQuickReaderStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getQuickReaderStatus run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_QUICKREADER_GET_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startRecordWithCameraStorage(mode: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "startRecordWithCameraStorage run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StartCapture(
                mode = CaptureMode.fromValue(mode) ?: CaptureMode.Capture_MODE_UNKNOWN
            ),
            "method" to MessageCode.PHONE_COMMAND_START_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startHdrCapture(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "startHdrCapture run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_START_HDR_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startTimeshift(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "startTimeshift run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_START_TIMESHIFT_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopTimeshift(extraMetaData: ByteArray): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopTimeshift run")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopTimeShift().apply {
                if (extraMetaData.isNotEmpty()) {
                    extra_metadata = ExtraMetadata.ADAPTER.decode(extraMetaData)
                }
            },
            "method" to MessageCode.PHONE_COMMAND_STOP_TIMESHIFT_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startBulletTime(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "startBulletTime run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_START_BULLETTIME_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setGPSData(gpsData: ByteArray): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setGPSData run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to UploadGps(
                gps = gpsData.toByteString()
            ),
            "method" to MessageCode.PHONE_COMMAND_UPLOAD_GPS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun switchWifiChannel(needScan: Int, channel: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "switchWifiChannel run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SwitchWifiChannel(
                need_scan = needScan,
                channel = channel
            ),
            "method" to MessageCode.PHONE_COMMAND_SWITCH_WIFI_CHANNEL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getWifiInterfStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getWifiInterfStatus run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_WIFI_INTERFERENCE_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopRecordWithCameraStorage(mode: Int, extraMetaData: ByteArray): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopRecordWithCameraStorage run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopCapture().apply {
                this.mode = CaptureMode.fromValue(mode) ?: CaptureMode.Capture_MODE_UNKNOWN
                if (extraMetaData.isNotEmpty()) {
                    extra_metadata = ExtraMetadata.ADAPTER.decode(extraMetaData)
                }
            },
            "method" to MessageCode.PHONE_COMMAND_STOP_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopHdrCapture(extraMetaData: ByteArray): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopHdrCapture run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopHdr().apply {
                if (extraMetaData.isNotEmpty()) {
                    extra_metadata = ExtraMetadata.ADAPTER.decode(extraMetaData)
                }
            },
            "method" to MessageCode.PHONE_COMMAND_STOP_HDR_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopBulletTime(extraMetaData: ByteArray): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopBulletTime run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopBulletTime().apply {
                if (extraMetaData.isNotEmpty()) {
                    extra_metadata = ExtraMetadata.ADAPTER.decode(extraMetaData)
                }
            },
            "method" to MessageCode.PHONE_COMMAND_STOP_BULLETTIME_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun cancelRecordWithCameraStorage(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "cancelRecordWithCameraStorage run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopCapture(),
            "method" to MessageCode.PHONE_COMMAND_CANCEL_CAPTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startTimelapseRecord(obj: StartTimelapse): Long {
        if (!isOpened) return -1
        Log.d(TAG, "startTimelapseRecord run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to obj,
            "method" to MessageCode.PHONE_COMMAND_START_TIMELAPSE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopTimelapseRecord(obj: StopTimelapse): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopTimelapseRecord run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to obj,
            "method" to MessageCode.PHONE_COMMAND_STOP_TIMELAPSE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setPreRecord run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to ctrlPreRecord,
            "method" to MessageCode.PHONE_COMMAND_CTRL_PRE_RECORD
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun pauseRecord(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "pauseRecord run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_PAUSE_RECORDING
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopTakePicture(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "captureStillImage run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_STOP_TAKE_PICTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun captureStillImage(obj: TakePicture): Long {
        if (!isOpened) return -1
        Log.d(TAG, "captureStillImage run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to obj,
            "method" to MessageCode.PHONE_COMMAND_TAKE_PICTURE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun captureStillImageWithoutStorage(obj: TakePicture): Long {
        if (!isOpened) return -1
        Log.d(TAG, "captureStillImageWithoutStorage run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to obj,
            "method" to MessageCode.PHONE_COMMAND_TAKE_PICTURE_WITHOUT_STORING
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun resumeInitialState(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "resumeInitialState run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "resumeInitial" to true,
            "method" to MessageCode.PHONE_COMMAND_GET_CURRENT_CAPTURE_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setOptions(
        optionTypes: List<OptionType>,
        options: Options,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setOptions run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetOptions(
                value_ = options,
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_OPTIONS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getOptions(
        optionTypes: List<OptionType>,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getOptions run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetOptions(
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_OPTIONS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun queryEncryptCapability(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to EncryptCapabilityQuery(),
            "method" to MessageCode.PHONE_COMMAND_ENCRYPT_CAPABILITY_QUERY
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun encryptKeyExchange(scheme: EncryptScheme, publicKey: okio.ByteString): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to EncryptKeyExchangeReq(
                selected_scheme = scheme,
                public_key = publicKey
            ),
            "method" to MessageCode.PHONE_COMMAND_ENCRYPT_KEY_EXCHANGE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun negotiateEncryption(onComplete: (Boolean) -> Unit) {
        if (!isOpened) {
            onComplete(false); return
        }
        Log.i(TAG, "encrypt: start negotiation")
        val capId = queryEncryptCapability()
        if (capId < 0) {
            onComplete(false); return
        }
        encryptCallbacks[capId] = cb@{ errorCode, obj ->
            if (errorCode != 0 || obj == null) {
                Log.e(TAG, "negotiateEncryption: capability query failed, error=$errorCode")
                onComplete(false)
                return@cb
            }
            val resp = obj as? insta360.messages.EncryptCapabilityResp
            val schemes = resp?.supported_schemes
            if (schemes.isNullOrEmpty()) {
                Log.e(TAG, "negotiateEncryption: no supported schemes")
                onComplete(false)
                return@cb
            }
            val selectedScheme = when {
                schemes.contains(EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128) -> EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128
                schemes.contains(EncryptScheme.ENCRYPT_SCHEME_XOR) -> EncryptScheme.ENCRYPT_SCHEME_XOR
                else -> {
                    onComplete(false); return@cb
                }
            }
            Log.i(TAG, "encrypt: capability resp, schemes=$schemes, selected=$selectedScheme")
            performKeyExchangeInternal(selectedScheme, onComplete)
        }
    }

    private fun performKeyExchangeInternal(scheme: EncryptScheme, onComplete: (Boolean) -> Unit) {
        val publicKey: okio.ByteString
        var ecdhPrivateKey: ByteArray? = null
        if (scheme == EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128) {
            val keyPair = com.arashivision.onedriver.encrypt.PlatformCrypto.generateEcdhKeyPair()
            ecdhPrivateKey = keyPair.privateKey
            publicKey = okio.ByteString.of(*keyPair.publicKey)
        } else {
            publicKey = okio.ByteString.EMPTY
        }
        val exchId = encryptKeyExchange(scheme, publicKey)
        @OptIn(ExperimentalStdlibApi::class)
        Log.d(TAG, "performKeyExchangeInternal: scheme=$scheme, localPubKey(hex)=${publicKey.toByteArray().toHexString(HexFormat.UpperCase)}")
        if (exchId < 0) {
            onComplete(false); return
        }
        encryptCallbacks[exchId] = cb@{ errorCode, obj ->
            if (errorCode != 0 || obj == null) {
                Log.e(TAG, "negotiateEncryption: key exchange failed, error=$errorCode")
                onComplete(false)
                return@cb
            }
            val keyResp = obj as? insta360.messages.EncryptKeyExchangeResp
            if (keyResp?.error_code != insta360.messages.EncryptErrorCode.ENCRYPT_ERROR_NONE) {
                Log.e(TAG, "negotiateEncryption: device error=${keyResp?.error_code}")
                onComplete(false)
                return@cb
            }
            val mgr = if (scheme == EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128) {
                val peerPubKey = keyResp.public_key
                if (peerPubKey.size == 0) {
                    onComplete(false); return@cb
                }
                val sharedSecret = com.arashivision.onedriver.encrypt.PlatformCrypto
                    .computeEcdhSharedSecret(ecdhPrivateKey!!, peerPubKey.toByteArray())
                val sessionKey = com.arashivision.onedriver.encrypt.PlatformCrypto
                    .hkdfSha256(sharedSecret, "UCD2-ENCRYPT".encodeToByteArray(), "AES-SESSION-KEY".encodeToByteArray(), 16)
                val sessionId = kotlin.random.Random.nextBytes(4)
                @OptIn(ExperimentalStdlibApi::class)
                Log.d(
                    TAG,
                    "performKeyExchangeInternal: peerPubKey(hex)=${peerPubKey.toByteArray().toHexString(HexFormat.UpperCase)}, " +
                            "sharedSecret(hex)=${sharedSecret.toHexString(HexFormat.UpperCase)}, " +
                            "sessionKey(hex)=${sessionKey.toHexString(HexFormat.UpperCase)}, " +
                            "sessionId(hex)=${sessionId.toHexString(HexFormat.UpperCase)}"
                )
                com.arashivision.onedriver.encrypt.EncryptionManager.createForAesGcm(sessionKey, sessionId)
            } else {
                com.arashivision.onedriver.encrypt.EncryptionManager.createForXor()
            }
            setupEncryption(mgr)
            Log.i(TAG, "encrypt: key exchange done, scheme=$scheme, encryption ready")
            onComplete(true)
        }
    }

    private fun setupEncryption(mgr: com.arashivision.onedriver.encrypt.EncryptionManager) {
        Packet.decryptParams = com.arashivision.onedriver.packet.PacketDecryptParams { ciphertext, aad, nonce, authTag ->
            mgr.decrypt(ciphertext, aad, nonce, authTag)
        }
        Packet.encryptParams = com.arashivision.onedriver.packet.PacketEncryptionParams(
            scheme = mgr.scheme,
            encrypt = { payload, aad, messageId ->
                val result = mgr.encrypt(payload, aad, messageId)
                com.arashivision.onedriver.packet.PacketEncryptResult(result.ciphertext, result.nonce, result.authTag)
            }
        )
    }

    private fun shouldEncryptMessage(action: com.arashivision.onedriver.action.Action): Boolean {
        if (currentProtocol != Protocol.Bluetooth && currentProtocol != Protocol.Go2Bluetooth) return false
        if (Packet.encryptParams == null) return false
        val method = action.getOp()
        if (method == MessageCode.PHONE_COMMAND_GET_OPTIONS) {
            val param = action.getParam() as? GetOptions ?: return false
            if (param.option_types.contains(OptionType.WIFI_INFO)) {
                Log.e(TAG, "encrypt: encrypting message, method=${method.name}, optionTypes=${param.option_types}")
                return true
            }
        }
        return false
    }

    fun setPhotographyOptions(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setPhotographyOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetPhotographyOptions(
                function_mode = FunctionMode.fromValue(funcMode) ?: FunctionMode.FUNCTION_MODE_NORMAL,
                value_ = options,
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_PHOTOGRAPHY_OPTIONS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getPhotographyOptions(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getPhotographyOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetPhotographyOptions(
                function_mode = FunctionMode.fromValue(funcMode) ?: FunctionMode.FUNCTION_MODE_NORMAL,
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_PHOTOGRAPHY_OPTIONS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setTimelapseOptions(info: SetTimelapseOptions): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setTimelapseOptions run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to info,
            "method" to MessageCode.PHONE_COMMAND_SET_TIMELAPSE_OPTIONS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getTimelapseOptions(getTimelapseOptions: GetTimelapseOptions): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getTimelapseOptions run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getTimelapseOptions,
            "method" to MessageCode.PHONE_COMMAND_GET_TIMELAPSE_OPTIONS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setMainStorage(
        cardLocation: CardLocation,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setMainStorage run cardLocation: $cardLocation")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetStorage(
                card_location = cardLocation
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_MAIN_STORAGE
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getCurrentRecordStatus(
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getCurrentRecordStatus run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_CURRENT_CAPTURE_STATUS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun sendHeartBeat() {
        sendMessage(MessageType.HEAT_BEAT)
    }

    fun sendWifiHeartBeat() {
        sendMessage(MessageType.WIFI_HEART_BEAT)
    }

    fun sendObtainRtosStatus() {
        sendMessage(MessageType.OBTAIN_ROTS_STATUS)
    }

    fun sendBleError(error: Int) {
        sendMessage(MessageType.BLE_ERROR, mapOf("error" to error))
    }

    fun getConnectedBtPeripherals(obj: GetConnectedBTPeripheral): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getConnectedBtPeripherals run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to obj,
            "method" to MessageCode.PHONE_COMMAND_GET_CONNECTED_BT_PERIPHERALS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun getGyro(getGyro: GetGyro): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getGyro run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getGyro,
            "method" to MessageCode.PHONE_COMMAND_GET_GYRO
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getGyroAsync(getGyro: GetGyro): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getGyroAsync run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getGyro,
            "method" to MessageCode.PHONE_COMMAND_GET_GYRO
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startLedTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startLedTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_LED_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startSpeakerTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startSpeakerTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_SPEAKER_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun openIperf(mode: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "openIperf run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to OpenIperfService(
                mode = OpenIperfService.Mode.fromValue(mode) ?: OpenIperfService.Mode.TCP
            ),
            "method" to MessageCode.PHONE_COMMAND_OPEN_IPERF
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun closeIperf(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "closeIperf run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CLOSE_IPERF
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getIperfAverage(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getIperfAverage run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_IPERF_AVERAGE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startWifiStatusTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startWifiStatusTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_WIFI_STATUS_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startBluetoothStatusTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startBluetoothStatusTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_BLUETOOTH_STATUS_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun scanBtPeripheral(scanBTPeripheral: ScanBTPeripheral): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "scanBtPeripheral run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to scanBTPeripheral,
            "method" to MessageCode.PHONE_COMMAND_SCAN_BT_PERIPHERAL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun connectToBtPeripheral(connectBTPeripheral: ConnectToBTPeripheral): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "connectToBtPeripheral run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to connectBTPeripheral,
            "method" to MessageCode.PHONE_COMMAND_CONNECT_TO_BT_PERIPHERAL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun disConnectToBtPeripheral(disconnectBTPeripheral: DisconnectBTPeripheral): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "disConnectToBtPeripheral run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to disconnectBTPeripheral,
            "method" to MessageCode.PHONE_COMMAND_DISCONNECT_BT_PERIPHERAL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setFileExtra(setFileExtra: SetFileExtra): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setFileExtra run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to setFileExtra,
            "method" to MessageCode.PHONE_COMMAND_SET_FILE_EXTRA
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFileExtra(getFileExtra: GetFileExtra): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFileExtra run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFileExtra,
            "method" to MessageCode.PHONE_COMMAND_GET_FILE_EXTRA
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun recipeShareStatus(recipeShareStatus: RecipeShareStatus): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "recipeShareStatus run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to recipeShareStatus,
            "method" to MessageCode.PHONE_COMMAND_RECIPE_SHARE_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFileList(getFileList: GetFileList): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFileList run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFileList,
            "method" to MessageCode.PHONE_COMMAND_GET_FILE_LIST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFileListIncludeRecording(getFileList: GetFileList): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFileListIncludeRecording run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFileList,
            "method" to MessageCode.PHONE_COMMAND_GET_RECORDING_FILE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFileInfoList(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFileInfoList run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_FILEINFO_LIST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFileInfoList(getFileInfoList: insta360.messages.GetFileInfoList): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFileInfoList run with cardLocation: ${getFileInfoList.cardLocation}")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFileInfoList,
            "method" to MessageCode.PHONE_COMMAND_GET_FILEINFO_LIST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getEditInfoList(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getEditInfoList run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_EDITINFO_LIST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getTranslateConfig(timeoutMs: Int = -1): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getTranslateConfig run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_TRANSLATE_CONFIG
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setFavoriteList(setFavoriteList: SetFavoriteList): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setFavoriteList run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to setFavoriteList,
            "method" to MessageCode.PHONE_COMMAND_SET_FAVORITE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFile(getFIle: GetFile): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFile run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFIle,
            "method" to MessageCode.PHONE_COMMAND_PREPARE_GET_FILE_PACKAGE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun packFile(getFIle: GetFile): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "packFile run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFIle,
            "method" to MessageCode.PHONE_COMMAND_PREPARE_GET_FILE_SYNC_PACKAGE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFileFinish(getFileFinish: GetFileFinish): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFileFinish run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFileFinish,
            "method" to MessageCode.PHONE_COMMAND_GET_FILE_PACKAGE_FINISH
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setTransferStatus(getFileFinish: GetFileFinish): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setTransferStatus run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to getFileFinish,
            "method" to MessageCode.PHONE_COMMAND_GET_FILE_PACKAGE_SYNC_FINISH
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getMiniThumbnail(path: String): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getMiniThumbnail run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetMiniThumbnail(
                uri = path
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_MINI_THUMBNAIL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun calibrateGyro(calibrateGyro: CalibrateGyro): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "calibrateGyro run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to calibrateGyro,
            "method" to MessageCode.PHONE_COMMAND_CALIBRATE_GYRO
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun testButtonState(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "testButtonState run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to ButtonStatus(),
            "method" to MessageCode.FACTORY_COMMAND_BUTTON_STATUS_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun eraseSDCard(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "eraseSDCard run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_ERASE_SD_CARD
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun formatStorage(formatStorage: FormatStorage): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "formatStorage run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to formatStorage,
            "method" to MessageCode.PHONE_COMMAND_FORMAT_STORAGE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun deleteFiles(deleteFiles: DeleteFiles): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "deleteFiles run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to deleteFiles,
            "method" to MessageCode.PHONE_COMMAND_DELETE_FILES
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun testSDCardSpeed(testSDCardSpeed: TestSDCardSpeed): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "isOpened run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to testSDCardSpeed,
            "method" to MessageCode.PHONE_COMMAND_TEST_SD_CARD_SPEED
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun rebootCamera(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "rebootCamera run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_REBOOT_CAMERA
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun notifyOTAError(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "notifyOTAError run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_NOTIFY_OTA_ERROR
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun setOptionsAsync(
        optionTypes: List<OptionType>,
        options: Options,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setOptionsAsync: options=$options, optionTypes=$optionTypes")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetOptions(
                value_ = options,
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getOptionsAsync(
        optionTypes: List<OptionType>,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
//        Log.d(TAG, "getOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetOptions(
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun setPhotographyOptionsAsync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setPhotographyOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetPhotographyOptions(
                function_mode = FunctionMode.fromValue(funcMode) ?: FunctionMode.FUNCTION_MODE_NORMAL,
                value_ = options,
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_PHOTOGRAPHY_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getPhotographyOptionsAsync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getPhotographyOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetPhotographyOptions(
                function_mode = FunctionMode.fromValue(funcMode) ?: FunctionMode.FUNCTION_MODE_NORMAL,
                option_types = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_PHOTOGRAPHY_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        options: ButtonPressParams,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setButtonPressParams run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetButtonParams(
                button_press_mode = ButtonPressMode.fromValue(buttonPressMode) ?: ButtonPressMode.DO_NOT_CHANGE,
                button_press_type = ButtonPressType.fromValue(buttonPressType) ?: ButtonPressType.CLICK,
                button_param_type = optionType,
                value_ = options
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_BUTTON_PRESS_PARAM
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionTypes: List<ButtonPressParamsType>,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getButtonPressParams run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetButtonParams(
                button_press_mode = ButtonPressMode.fromValue(buttonPressMode) ?: ButtonPressMode.DO_NOT_CHANGE,
                button_press_type = ButtonPressType.fromValue(buttonPressType) ?: ButtonPressType.CLICK,
                button_param_type = optionTypes
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_BUTTON_PRESS_PARAM
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setTimelapseOptionsAsync(
        info: SetTimelapseOptions,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setTimelapseOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to info,
            "method" to MessageCode.PHONE_COMMAND_SET_TIMELAPSE_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getTimelapseOptionsAsync(
        timelapseMode: GetTimelapseOptions,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getTimelapseOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to timelapseMode,
            "method" to MessageCode.PHONE_COMMAND_GET_TIMELAPSE_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopLCDTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "stopLCDTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_USB_LCD_TP_CLOSE_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAccessCameraFileState(accessState: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setAccessCameraFileState run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetAccessCameraFileState(
                state = SetAccessCameraFileState.AccessState.fromValue(accessState) ?: SetAccessCameraFileState.AccessState.UNKNOWN
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_ACCESS_CAMERA_FILE_STATE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun openCameraWifi(countryChannel: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "openCameraWifi run")
        val messageData: MutableMap<String, Any> = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_OPEN_CAMERA_WIFI
        )
        if (countryChannel > 0) {
            messageData["param"] = RestartWifi(restart_channel = countryChannel)
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun closeCameraWifi(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "closeCameraWifi run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CLOSE_CAMERA_WIFI
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun resetCameraWifi(countryChannel: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "resetCameraWifi run")
        val messageData: MutableMap<String, Any> = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_RESET_WIFI
        )
        if (countryChannel > 0) {
            messageData["param"] = RestartWifi(restart_channel = countryChannel)
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setCameraWifiSeizeEnable(connectionState: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setCameraWifiSeizeEnable run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetWifiSeizeEnable(
                state = SetWifiSeizeEnable.ConnectionState.fromValue(connectionState) ?: SetWifiSeizeEnable.ConnectionState.unknown
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_WIFI_SEIZE_ENABLE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getWifiConnectionInfo(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getWifiConnectionInfo run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_WIFI_CONNECTION_INFO
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setWifiConnectionInfo(wifiConnectionInfo: WifiConnectionInfo): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setWifiConnectionInfo run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetWifiConnectionInfo(
                wifi_connection_info = wifiConnectionInfo
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_WIFI_CONNECTION_INFO
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAvailableWifi(wifiConnectionInfo: WifiConnectionInfo): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setAvailableWifi run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetAvailableWifi(
                wifi_connection_info = wifiConnectionInfo
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_AVAILABLE_WIFI
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun openCameraOled(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startContactTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_OPEN_OLED
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun closeCameraOled(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startContactTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CLOSE_OLED
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startContactTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startContactTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_TP_JIUGONGGE_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startColorTest(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startColorTest run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_LCD_COLOR_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun testTypeC(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "testTypeC run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_USB_SPEED_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAppId(appId: String): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setAppId run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetAppid(appid = appId),
            "method" to MessageCode.PHONE_COMMAND_SET_APPID
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setShutdown(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setShutdown run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_SET_SHUTDOWN
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun cancelAngleFixed(cancelAngleFixed: CancelAngleFixed): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "cancelAngleFixed run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to cancelAngleFixed,
            "method" to MessageCode.PHONE_COMMAND_CANCEL_ANGLE_FIXED
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun checkAuthorization(
        checkAuthorization: CheckAuthorization,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "checkAuthorization run")
        val messageData = mutableMapOf(
            "param" to checkAuthorization,
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CHECK_AUTHORIZATION
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun cancelAuthenticate(timeoutMs: Int, retryCount: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "cancelAuthenticate run")
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CANCEL_AUTHORIZATION
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun requestAuthorization(authorizationOperationType: Int): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "requestAuthorization run")
        val messageData = mutableMapOf(
            "param" to RequestAuthorization(
                authorization_operation_type = AuthorizationOperationType.fromValue(
                    authorizationOperationType
                ) ?: AuthorizationOperationType.BLE_CONNECT
            ),
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_REQUEST_AUTHORIZATION
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun cancelRequestAuthorization(authorizationOperationType: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "cancelRequestAuthorization run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "param" to RequestAuthorization(
                authorization_operation_type = AuthorizationOperationType.fromValue(
                    authorizationOperationType
                ) ?: AuthorizationOperationType.BLE_CONNECT
            ),
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CANCEL_REQUEST_AUTHORIZATION
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun setSyncCaptureMode(mode: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setSyncCaptureMode run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetSyncCaptureMode(
                capture_mode = SyncCaptureMode.fromValue(mode) ?: SyncCaptureMode.SYNC_MODE_UNKNOWN
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_SYNC_CAPTURE_MODE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getSyncCaptureMode(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getSyncCaptureMode run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_SYNC_CAPTURE_MODE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setStandbyMode(mode: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setStandbyMode run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetStandbyMode(
                standby_mode = SetStandbyMode.StandbyMode.fromValue(mode) ?: SetStandbyMode.StandbyMode.STANDBY_MODE_UNKNOWN
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_STANDBY_MODE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setCameraLiveOptionsAsync(
        optionList: List<LiveBroadCastOptionType>,
        options: LiveOptionCtrlInfo,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setCameraLiveOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetLiveOptions(
                option_types = optionList,
                value_ = options
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_CAMERA_LIVE_INFO
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun getCameraLiveOptionsAsync(
        optionList: List<LiveBroadCastOptionType>,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getCameraLiveOptionsAsync run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetLiveOptions(option_types = optionList),
            "method" to MessageCode.PHONE_COMMAND_GET_CAMERA_LIVE_INFO
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setPhoneCommandGimbalControl(gimbalControl: GimbalControl): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setPhoneCommandGimbalControl enter")
        val id = generateMessageId()
        Log.d(TAG, "setPhoneCommandGimbalControl $gimbalControl")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to gimbalControl,
            "method" to MessageCode.PHONE_COMMAND_GIMBAL_CONTROL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long {
        if (!isOpened) return -1
        Log.d(TAG, "openTrackingWithRect $openTrackingWithRect")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to openTrackingWithRect,
            "method" to MessageCode.PHONE_COMMAND_OPEN_TRACKING_WITH_RECT
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun cancelTracking(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "cancelTracking")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_CANCEL_TRACKING
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setPresetComposition(setPresetComposition: SetPresetComposition): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setPresetComposition $setPresetComposition")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to setPresetComposition,
            "method" to MessageCode.PHONE_COMMAND_SET_PRESET_COMPOSITION
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun notifySettingPage(settingPageNotify: PhotoSettingPage): Long {
        if (!isOpened) return -1
        Log.d(TAG, "notifySettingPage $settingPageNotify")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to settingPageNotify,
            "method" to MessageCode.PHONE_COMMAND_NOTIFY_PHOTO_SETTING_PAGE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getPresetComposition(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getPresetComposition")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetPresetComposition(),
            "method" to MessageCode.PHONE_COMMAND_GET_PRESET_COMPOSITION
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getPtzTrackState(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getPtzTrackState")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_PTZ_TRACK_STATE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setWifiState(wifiConnectionInfo: WifiConnectionInfo, wifiNetResult: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setWifiState run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetWifiNetResult(
                wifi_connection_info = wifiConnectionInfo,
                wifi_net_result = SetWifiNetResult.WifiNetResult.fromValue(wifiNetResult) ?: SetWifiNetResult.WifiNetResult.NET_SUCCESS
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_WIFI_STATE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setCloudTabShow(showCloudTab: Boolean): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setCloudTabShow run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetCloudShowTab(
                if (showCloudTab) SetCloudShowTab.ShowTab.SHOW else SetCloudShowTab.ShowTab.HIDE
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_CLOUD_TAB_SHOW
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setCloudPromptInterval(promptInterval: Long, cloudBackupPromptsSeconds: Long): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setCloudPromptInterval run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetPromptInterval(
                place_holder = 1,
                prompt_interval = promptInterval,
                charging_prompt_interval = cloudBackupPromptsSeconds
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_CLOUD_PROMPT_INTERVAL
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setPhoneInfo(manufacturer: String, model: String, osVersion: String): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setPhoneInfo run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to PhoneInfo(
                device_type = PhoneInfo.PhoneType.ANDROID_DEVICE,
                manufacturer = manufacturer,
                model = model,
                os_version = osVersion
            ),
            "method" to MessageCode.PHONE_COMMAND_PHONE_INFO
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setWifiMode(wifiMode: Int, countryCode: String?): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to if (countryCode.isNullOrEmpty()) {
                SetWifiMode(
                    place_holder = 1,
                    wifi_mode = WifiMode.fromValue(wifiMode) ?: WifiMode.AP,
                )
            } else {
                SetWifiMode(
                    place_holder = 1,
                    wifi_mode = WifiMode.fromValue(wifiMode) ?: WifiMode.AP,
                    country_code = countryCode
                )
            },
            "method" to MessageCode.PHONE_COMMAND_SET_WIFI_MODE
        )
        Log.d(TAG, "setWifiMode run, $messageData")
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getWifiMode(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getWifiMode run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetWifiMode(),
            "method" to MessageCode.PHONE_COMMAND_GET_WIFI_MODE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun requestData(
        dir: DataTransPortDir,
        rxdatainfo: List<RequestReceiveDataInformation>? = null,
        txdatainfo: List<RequestSendDataInformation>? = null,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "requestData run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to RequestData(
                dir = dir,
                rxdatainfo = rxdatainfo ?: emptyList(),
                txdatainfo = txdatainfo ?: emptyList(),
            ),
            "method" to MessageCode.PHONE_COMMAND_REQUEST_DATA
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun dataTransportFeedback(dataTransportResult: DataTransportResult): Long {
        if (!isOpened) return -1
        Log.d(TAG, "dataTransportFeedback run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to dataTransportResult,
            "method" to MessageCode.PHONE_COMMAND_DATA_TRANSPORT_FEEDBACK
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getWifiConnectList(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getWifiConnectList run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetWifiConnectList(),
            "method" to MessageCode.PHONE_COMMAND_GET_CONNECTED_WIFI_LIST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getWifiScanList(interval: Int, count: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getWifiScanList run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetWifiScanInfo(
                interval = interval,
                count = count
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_WIFI_SCAN_LIST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startCameraLive(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "startCameraLive run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StartCameraLive(),
            "method" to MessageCode.PHONE_COMMAND_START_CAMERA_LIVE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun stopCameraLive(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "stopCameraLive run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to StopCameraLive(),
            "method" to MessageCode.PHONE_COMMAND_STOP_CAMERA_LIVE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun requestP3StaticStreamData(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "requestP3StaticStreamData run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_P3_STATIC_HDR_PARAMS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun prepareCameraLive(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "prepareCameraLive run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_SET_CAMERA_LIVE_PREPARE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setKeyTimePoint(setKeyTimePoint: SetKeyTimePoint): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setKeyTimePoint run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "param" to setKeyTimePoint,
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_SET_KEY_TIME_POINT
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setFlowStateEnable(enable: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setFlowStateEnable run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "param" to SetFlowstateEnable(enable = enable),
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_SET_FLOWSTATE_ENABLE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getFlowStateEnable(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getFlowStateEnable run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "param" to GetFlowstateEnable(),
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_FLOWSTATE_ENABLE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getDarkEisStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getDarkEisStatus run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_DARK_EIS_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    /**
     * 处理心跳
     */
    private suspend fun writeHeartBeartInternal() {
        // 检查是否正在重连
        if (reconnecting) {
            Log.w("OneDriverImpl", "writeHeartBeartInternal, but is reconnecting, ignore.")
            return
        }

        try {
            when (currentProtocol) {
                Protocol.Go2Bluetooth -> {
                    // GO2蓝牙协议需要特殊处理
                    val packets = mutableListOf<Go2BlePacket>()
                    val heartBeatPacket = Packet.newHeartBeatPacket()
                    if (heartBeatPacket != null) {
                        val go2BlePacket = Go2BlePacket.newBlePacketFromPacket(heartBeatPacket)
                        if (go2BlePacket != null) {
                            packets.add(go2BlePacket)
                            bleIO?.writeBle(packets)
                        }
                    }
                }

                Protocol.Bluetooth -> {
                    // 普通蓝牙协议
                    val packets = mutableListOf<Packet>()
                    val heartBeatPacket = Packet.newHeartBeatPacket()
                    if (heartBeatPacket != null) {
                        packets.add(heartBeatPacket)
                        bleIO?.write(packets)
                    }
                }

                Protocol.USB -> {
                    // USB协议
                    val packets = mutableListOf<Packet>()
                    val heartBeatPacket = Packet.newHeartBeatPacket()
                    if (heartBeatPacket != null) {
                        packets.add(heartBeatPacket)
                        usbIO?.write(packets)
                    }
                }

                Protocol.Socket -> {
                    // Socket协议
                    val packets = mutableListOf<Packet>()
                    val heartBeatPacket = Packet.newHeartBeatPacket()
                    if (heartBeatPacket != null) {
                        packets.add(heartBeatPacket)
                        socketIO?.write(packets)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("OneDriverImpl", "writeHeartBeartInternal failed: ${e.message}")
        }
    }

    /**
     * 写入消息 - 对应C++版本的writeMessage
     */
    private suspend fun writeMessage(message: com.arashivision.onedriver.packet.Message, encrypt: Boolean = false) {
        withContext(Dispatchers.IO) {
            if (currentProtocol == Protocol.Go2Bluetooth) {
                val packets = MessageMuxer.muxBle(message, isClassicConnected)
                bleIO?.writeBle(packets)
            } else {
                val packets = MessageMuxer.mux(message, currentProtocol, isClassicConnected, encrypt)
                when (currentProtocol) {
                    Protocol.USB -> usbIO?.write(packets)
                    Protocol.Bluetooth, Protocol.Go2Bluetooth -> bleIO?.write(packets)
                    Protocol.Socket -> socketIO?.write(packets)
                }
            }
        }
    }

    /**
     * 获取相机RTOS状态
     */
    private suspend fun obtainCameraRtosStatus() {
        val packet =
            Packet.newLinuxCmdPacket(LinuxCmdCmd.RtosStatus, LinuxCmdDirection.PhoneToCamera, 0)
        when (currentProtocol) {
            Protocol.USB -> usbIO?.write(listOf(packet))
            Protocol.Socket -> socketIO?.write(listOf(packet))
            else -> {

            }
        }
    }

    fun sendWakeUpAuthorization(uuid: String) {
        if (bleIO == null) return
        val go2BlePacket = Go2BlePacket.newBlePacket2(0x0C, 0x02, uuid.encodeToByteArray())
        bleIO?.writeBle(listOf(go2BlePacket))
    }

    /**
     * Direction: APP_CMD_DIRECT_APP_TO_BT(0x0C)
     * CMD: APP_CMD_PHONE_BT_SPP_START=0x04
     * data:
     * struct {
     * uint32 session_id; // 会话id，可随机
     * uint8 connect_type; //  0:广播扫描；1：直连
     * }
     *
     * @doc https://arashivision.feishu.cn/docx/ALPudc6GBobNf2x8ifFcxxshn3f
     */
    fun sendOpenClassicBluetooth(connectType: Int): Long {
        if (bleIO == null) return -1L
        val sessionId = generateMessageId()
        val go2BlePacket = Go2BlePacket.newOpenClassicBluetoothPacket(sessionId, connectType)
        bleIO?.writeBle(listOf(go2BlePacket))
        return sessionId
    }

    /**
     * Direction: APP_CMD_DIRECT_APP_TO_BT(0x0C)
     * CMD: APP_CMD_PHONE_AI_VOICE_READY=0x06
     * data:
     * struct {
     * uint32 session_id; // 会话id，可随机
     * uint8 phone_platform;// 0 :ios ; 1: Android；2：鸿蒙
     * }
     *
     * @doc https://arashivision.feishu.cn/docx/ALPudc6GBobNf2x8ifFcxxshn3f
     */
    fun sendAiVoiceReady(isHuawei: Boolean = false): Long {
        BleLog.d("sendAiVoiceReady, bleIO=$bleIO, isHuawei=$isHuawei")
        if (bleIO == null) return -1L
        val sessionId = generateMessageId()
        val go2BlePacket = Go2BlePacket.newAiVoiceReadyPacket(sessionId, 1)
        bleIO?.writeBle(listOf(go2BlePacket))
        // 华为手机额外下发手机型号指令(APP_CMD_PHONE_MODEL=0x0B),phone_model:01--华为。
        if (isHuawei) {
            val phoneModelPacket = Go2BlePacket.newPhoneModelPacket(1)
            bleIO?.writeBle(listOf(phoneModelPacket))
        }
        return sessionId
    }

    fun writeBleSync(data: ByteArray) {
        BleLog.d("writeBleSync ")
        if (currentProtocol == Protocol.Bluetooth || currentProtocol == Protocol.Go2Bluetooth) {
            val go2BlePacket = Go2BlePacket.newBleSyncPacket(data)
            bleIO?.writeBle(listOf(go2BlePacket))
        }
    }

    fun writeRawData(data: ByteArray) {
        when (currentProtocol) {
            Protocol.Bluetooth -> {
                bleIO?.writeBleRawData(data)
            }

            Protocol.Socket -> {
                socketIO?.writeRawBuf(data)
            }

            else -> {

            }
        }
    }

    fun checkCameraOpen(): Boolean = isOpened

    fun checkCameraSynced(): Boolean {
        return if (isUsbOrSocket()) isWriteSynced else isOpened
    }

    /**
     * 检查是否有AV操作等待响应
     */
    private suspend fun hasAVActionWaitingResponse(): Boolean {
        val actions = responseWaitQueue.cloneActions()
        return actions.any { action ->
            val category = action.getCategory()
            category == ActionCategory.Stream || category == ActionCategory.Capture || category == ActionCategory.Picture
        }
    }

    /**
     * 检查是否为USB模式
     */
    private fun isUsbOrSocket(): Boolean {
        return currentProtocol == Protocol.USB || currentProtocol == Protocol.Socket
    }

    /**
     * 检查Action是否准备就绪 - 对应C++版本的isActionPrepared
     */
    private suspend fun isActionPrepared(action: Action): Boolean {
        // USB/Socket模式需要同步状态
        if (isUsbOrSocket() && !Packet.useUcd2 && !isWriteSynced) {
            Log.e(TAG, "isActionPrepared useUcd2=${Packet.useUcd2}, isWriteSynced=$isWriteSynced")
            return false
        }

        // 重连期间不能执行
        if (reconnecting) {
            Log.e(TAG, "isActionPrepared reconnecting=$reconnecting")
            return false
        }

        // 非中断命令需要等待AV操作完成
        if (!isInterruptAction(action) && hasAVActionWaitingResponse()) {
            Log.e(TAG, "isActionPrepared ${action.getCategory()}")
            return false
        }

        return true
    }

    /**
     * 检查是否为中断Action
     */
    private fun isInterruptAction(action: Action): Boolean {
        return action.getCategory() == ActionCategory.Interrupt
    }

    /**
     * 触发Action - 对应C++版本的triggerAction
     */
    private suspend fun triggerAction(action: Action): ActionState {
        // 发送命令过快相机会吞消息
        waitIfTriggerActionTooFast()

        val messageId = action.getId()
        val method = action.getOp()
        val message = createMessageFromAction(action)
        val encrypt = shouldEncryptMessage(action)

        Log.e(TAG, "trigger action: ${method.name}(messageId=$messageId)")
        writeMessage(message, encrypt)
        dealWithActionTimeoutParams(action)

        val newState = ActionState.WaitResponse
        action.setState(newState)
        emitActionStateUpdate()
        return newState
    }

    /**
     * 等待触发Action不要太快 - 对应C++版本的waitIfTriggerActionTooFast
     */
    private suspend fun waitIfTriggerActionTooFast() {
        val curTime = currentTimeMillis()

        // 对应C++版本：处理时间回退的情况
        if (curTime < lastTriggerActionTime) {
            lastTriggerActionTime = curTime
        }

        val diffTime = curTime - lastTriggerActionTime
        val waitTime = TRIGGER_ACTION_MIN_INTERVAL_TIME - diffTime

        if (waitTime > 0) {
            Log.e(TAG, "trigger action too fast, sleep ${waitTime}ms")
            delay(waitTime)
            lastTriggerActionTime = curTime + waitTime
        } else {
            lastTriggerActionTime = curTime
        }
    }

    /**
     * 处理Action超时参数
     */
    private suspend fun dealWithActionTimeoutParams(action: Action) {
        // 实现超时处理逻辑
        var timeoutMs = action.getTimeoutMs()
        if (timeoutMs < 0) {
            timeoutMs = globalRequestTimeoutMs
        }

        if (timeoutMs > 0) {
            sendDelayedMessage(MessageType.REQUEST_TIMEOUT, action.getId(), timeoutMs.toLong())
        }
    }

    /**
     * 发出动作状态更新 - 对应C++版本的emitActionStateUpdate
     */
    private fun emitActionStateUpdate() {
        if (hasActionUpdateMsg) return
        hasActionUpdateMsg = true
        sendMessage(MessageType.ACTION_STATE_UPDATE)
    }

    /**
     * Action状态更新处理 - 对应C++版本的onActionStateUpdate
     */
    private suspend fun onActionStateUpdate() {
        val actions = prepareQueue.getIterator()
        val actionsToRemove = mutableListOf<Action>()
        val actionsToMove = mutableListOf<Action>()

        for (action in actions) {
            if (!isActionPrepared(action)) {
                continue
            }

            Log.e(TAG, "asdasd onActionStateUpdate triggerAction ")
            val state = triggerAction(action)
            actionsToRemove.add(action)

            if (state == ActionState.WaitResponse) {
                actionsToMove.add(action)
            }
        }

        // 从准备队列移除
        for (action in actionsToRemove) {
            prepareQueue.removeAction(action.getId())
        }

        // 移动到响应等待队列
        for (action in actionsToMove) {
            responseWaitQueue.pushBack(action)
        }
    }

    private fun generateMessageId(): Long {

        if (messageIdCounter.addAndGet(1) > 0x3FFFFFFFL) // 30 bit length
            messageIdCounter.value = 0L
        return messageIdCounter.value
    }

    fun setUsbStateCallback(callback: (UsbState, Int) -> Unit) {
        usbStateCallback = callback
    }

    fun setInfoCallback(callback: (Int, Long, Int, Any?) -> Unit) {
        infoCallback = callback
    }

    fun setWifiProxyDataCallback(callback: (ByteArray?) -> Unit) {
        wifiProxyDataCallback = callback
    }

    fun setStillImageCallback(callback: (Int, TakePictureResponse?) -> Unit) {
        stillImageCallback = callback
    }

    fun setStillImageWithoutStorageCallback(callback: (Int, ByteArray?) -> Unit) {
        stillImageWithoutStorageCallback = callback
    }

    fun setRecordVideoStateCallback(callback: (Int, Int, Video?) -> Unit) {
        recordVideoCallback = callback
    }

    fun setTimelapseCallback(callback: (Int, Int, Video?) -> Unit) {
        timelapseCallback = callback
    }

    fun setStreamDataCallback(callback: (StreamData) -> Unit) {
        streamDataCallback = callback
    }

    fun setNeedReconnectCallback(callback: () -> Boolean) {
        needReconnectCallback = callback
    }

    fun setOnReconnectSuccessCallback(callback: () -> Unit) {
        onReconnectSuccessCallback = callback
    }

    fun setGlobalRequestTimeoutMs(timeoutMs: Int): Boolean {
        if (timeoutMs >= 0) {
            globalRequestTimeoutMs = timeoutMs;
        }
        return true
    }

    fun setGlobalRequestRetryCount(retryCount: Int): Boolean {
        if (retryCount >= 0) {
            globalRequestRetryTime = retryCount;
        }
        return true
    }

    /**
     * 处理客户端心跳
     */
    private fun onClientHeartBeat() {
        // 本来就是空实现，处理心跳响应
    }

    /**
     * 处理客户端通知
     */
    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun onClientNotification(notification: com.arashivision.onedriver.packet.Message?) {
        if (notification == null) return

        val method = MessageCode.fromValue(notification.messageMethod)
        val content: ByteArray = notification.messageContent
        Log.e(TAG, "onClientNotification method: ${method}")
        if (content.isEmpty() &&
            method != MessageCode.CAMERA_NOTIFICATION_CAM_WIFI_START &&
            method != MessageCode.CAMERA_NOTIFICATION_CAM_BT_MSG_ANALYZE_FAILED &&
            method != MessageCode.CAMERA_NOTIFICATION_LIVEVIEW_BEGIN_ROTATE &&
            method != MessageCode.CAMERA_NOTIFICATION_NEED_DOWNLOAD_FILE &&
            method != MessageCode.CAMERA_NOTIFICATION_FAVORITE_CHANGE_STATUS &&
            method != MessageCode.CAMERA_NOTIFICATION_WIFI_SCAN_LIST_CHANGED &&
            method != MessageCode.CAMERA_NOTIFICATION_USER_TAKEOVER &&
            method != MessageCode.CAMERA_NOTIFICATION_AF_SCENE_CHANGE &&
            method != MessageCode.CAMERA_NOTIFICATION_OFFSET_STATE_UPDATE &&
            method != MessageCode.CAMERA_NOTIFICATION_AUDIO_ACTIVITY_STATUS &&
            method != MessageCode.CAMERA_NOTIFICATION_AI_QUIT_ASSISTANT
        ) {
            return
        }

        // 处理通知消息
        var protoContent: Any? = null
        val infoType = infoTypeFromMessageCode(method)
        try {
            // 对应C++版本的特殊回调处理
            protoContent = when (method) {
                MessageCode.CAMERA_NOTIFICATION_WATCH_RES,
                    -> GetPhotographyOptionsResp.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_USER_TAKEOVER,
                MessageCode.CAMERA_NOTIFICATION_NEED_DOWNLOAD_FILE,
                MessageCode.CAMERA_NOTIFICATION_FIRMWARE_UPGRADE_COMPLETE,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_CAPTURE_AUTO_SPLIT,
                    -> NotificationCaptureAutoSplit.ADAPTER.decode(content).video

                MessageCode.CAMERA_NOTIFICATION_DASH_CAM_INFO,
                    -> DashCamInfo.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_VIRTUAL_PTZ_MOVEMENT_STATUS,
                    -> Ptz_Movement_Status.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_PTZ_PERSPECTIVE_STATUS,
                    -> NotificationPtzPerspectiveStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_PTZ_TRACK_STATE,
                    -> PtzTrackStateReport.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CHARGE_BOX_BATTERY_UPDATE,
                MessageCode.CAMERA_NOTIFICATION_BATTERY_UPDATE,
                MessageCode.CAMERA_NOTIFICATION_BATTERY_LOW,
                    -> NotificationBatteryUpdate.ADAPTER.decode(content).battery_status

                MessageCode.CAMERA_NOTIFICATION_CAM_TEMPERATURE_VALUE,
                    -> TempState.ADAPTER.decode(content).temp_state

                MessageCode.CAMERA_NOTIFICATION_CAM_WIFI_START,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_CAM_BT_MSG_ANALYZE_FAILED,
                    -> {
                    onActionStateUpdate()
                    null
                }

                MessageCode.CAMERA_NOTIFICATION_LIVEVIEW_BEGIN_ROTATE,
                    -> {
                    if (content.isEmpty()) {
                        null
                    } else {
                        NotificationCameraPostureUpdate.ADAPTER.decode(content)
                    }
                }

                MessageCode.CAMERA_NOTIFICATION_UPDATE_LIVE_STREAM_PARAMS,
                    -> LiveStreamParamsUpdate.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_SHUTDOWN,
                    -> NotificationShutdown.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_STORAGE_UPDATE,
                    -> NotificationCardUpdate.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_STORAGE_FULL,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_KEY_PRESSED,
                    -> NotificatoinKeyPressed.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CAPTURE_STOPPED,
                    -> NotificationCaptureStopped.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_TAKE_PICTURE_STATE_UPDATE,
                    -> NotificationTakePictureStateUpdate.ADAPTER.decode(content).state

                MessageCode.CAMERA_NOTIFICATION_INTERVAL_REC_INFO,
                MessageCode.CAMERA_NOTIFICATION_INTERVAL_REC_RESULT,
                    -> IntervalRecInfo.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CURRENT_CAPTURE_STATUS,
                    -> CaptureStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_TAKE_PICTURE_RESPONSE -> {
                    val takePictureResponse = TakePictureResponse.ADAPTER.decode(notification.messageContent)
                    stillImageCallback?.invoke(Error.ErrorCode.UNKNOWN_ERROR.value, takePictureResponse)
                    takePictureResponse
                }

                MessageCode.CAMERA_NOTIFICATION_CLOSE_WIFI,
                    -> WifiCloseInfo.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_AUTHORIZATION_RESULT,
                    -> NotificationAuthorizationResult.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_PHONE_INSERT,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_BT_DISCOVER_PERIPHERAL,
                    -> NotificatoinDiscoverBTPeripheral.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_BT_CONNECTED_TO_PERIPHERAL,
                    -> NotificatoinConnectedToPeripheral.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_BT_DISCONNECTED_PERIPHERAL,
                    -> NotificatoinDisconnectedPeripheral.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_TIMELAPSE_STATUS_UPDATE,
                    -> NotificationTimeLapseStatusUpdate.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_BT_REMOTE_VER_UPDATED,
                MessageCode.CAMERA_NOTIFICATION_SYNC_CAPTURE_MODE_UPDATE,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_EXPOSURE_UPDATE,
                    -> NotificationExposureUpdate.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CHARGE_BOX_CONNECT_STATUS,
                    -> ChargeboxConnectedStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_DETACHABLE_SCREEN_BATTERY_UPDATE,
                    -> NotificationBatteryUpdate.ADAPTER.decode(content).battery_status

                MessageCode.CAMERA_NOTIFICATION_DETACHABLE_SCREEN_CONNECT_STATUS,
                    -> DetachableScreenConnectedStatus.ADAPTER.decode(content).detachable_screen_connection_state

                MessageCode.CAMERA_NOTIFICATION_WIFI_STATUS,
                    -> CameraWifiConnectionResult.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_WIFI_SCAN_LIST_CHANGED,
                    -> {
                    // 安全地解析 WifiScanInfoList，处理其中可能存在的非 UTF-8 SSID
                    // 如果正常解析失败（可能是因为 ssid 字段包含 GBK 编码），会尝试手动解析
                    StringEncodingUtils.safeDecodeWifiScanInfoList(content)
                }

                MessageCode.CAMERA_NOTIFICATION_FIRMWARE_UPGRADE_STATUS_TOAPP,
                    -> UpgradeStateOptions.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_DATA_EXPORT_STATUS,
                    -> TrackState.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_DETECTED_FACE,
                    -> NotificationDetectFace.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_DARK_EIS_STATUS,
                    -> NotificationDarkEisStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_USBCARD_STATUS,
                    -> UsbCardStatus.ADAPTER.decode(content) //傻逼相机会发00000000，导致proto解析失败，外部兜底

                MessageCode.CAMERA_NOTIFICATION_DELETE_FILE_RESULT,
                    -> NotificationDeleteFileOperation.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_SUPPORT_TAKE_PHOTO_ON_REC_STATUS,
                    -> NotificationSupportTakePhotoInREC.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_WIFI_MODE_CHANGE,
                    -> WifiModeResult.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CAMERA_LIVE_STATUS,
                    -> CameraLiveResult.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CLOUD_STORAGE_BIND_STATUS,
                    -> CloudStorageBindParams.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_APP_CLOUD_UPLOAD_INTERRUPT,
                    -> NotificationCloudUploadStatus.ADAPTER.decode(content)

                MessageCode.PHONE_COMMAND_SET_NETWORK_CONFIG_ENABLE,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_WIFI_CHANNEL_SWITCH_RES,
                    -> NotificationWifiChannelSwitch.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_WIFI_INTERFERENCE_STATUS,
                    -> NotificationWifiInterfStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_CAM_SUBMODE_CHANGE,
                    -> NotifyCameraSubMode.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_STREET_PHOTO_STATE,
                    -> NotificationStreetPhotoStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_FAVORITE_CHANGE_STATUS,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_LIVE_ONLINE_STATUS,
                    -> LiveBroadCastStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_IS_P2P_TRANSMITING,
                    -> NotificationP2pTransStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_PHOTOGRAPHY_OPTIONS_CHANGE,
                    -> NotificationPhotographyOptions.ADAPTER.decode(content)


                MessageCode.CAMERA_NOTIFICATION_LIVEPHOTO_SWITCH_STATUS,
                    -> LivePhotoSwitch.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_SINGLE_HOST_INFO,
                    -> SingleHostNotifyInfo.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_AI_HIGHLIGHT_STATUS,
                    -> AiHighlightStatusNotification.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_AUDIO_ACTIVITY_STATUS,
                    -> {
                    if (content.isEmpty()) {
                        null
                    } else {
                        NotificationAudioActivityStatus.ADAPTER.decode(content)
                    }
                }

                MessageCode.CAMERA_NOTIFICATION_DATA_INFO_READY -> {
                    NotificationSendDataInformation.ADAPTER.decode(content)
                }
                MessageCode.CAMERA_NOTIFICATION_DATA_TRANSPORT -> {
                    DataTransPort.ADAPTER.decode(content)
                }

                // 相机 -> APP，语音助手已退出（空 message）
                MessageCode.CAMERA_NOTIFICATION_AI_QUIT_ASSISTANT -> null

                // 相机 -> APP，主动推送蓝牙状态
                MessageCode.CAMERA_NOTIFICATION_BLUETOOTH_STATUS -> {
                    NotificationBluetoothCurrInfo.ADAPTER.decode(content)
                }

                MessageCode.CAMERA_NOTIFICATION_GIMBAL_CALIBRATION,
                    -> NotificationGimbalCalibration.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_PTZ_STATE,
                    -> GimbalStatus.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_RECIPE_SHARE,
                    -> NotificationRecipeShare.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_STORAGE_LOCATION_CHANGE,
                    -> NotificationStorageLocationChange.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_PTZ_TRACK_STATE,
                    -> PtzTrackStateReport.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_AF_SCENE_CHANGE,
                    -> null

                MessageCode.CAMERA_NOTIFICATION_POSTURE_REBUILD_STATE,
                    -> NotificationPostureRebuildState.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_TM_TRACKER_EAR_HOOK_WEAR_STATE,
                    -> NotificationTmTrackerEarHookWearState.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_OFFSET_STATE_UPDATE,
                    -> NotificationOffsetStateUpdate.ADAPTER.decode(content)

                MessageCode.CAMERA_NOTIFICATION_AUTO_SWITCH_NIGHT_VIDEO,
                    -> AutoSwitchNightVideo.ADAPTER.decode(content)

                else -> null
            }
        } catch (e: Exception) {
            val hexString = content.toHexString()
            if (DEBUG) {
                throw e
            } else {
                Log.t(TAG, "parseProtoNotification messageCode $method hex: $hexString")
            }
        }
        infoCallback?.invoke(infoType, 0, 0, protoContent)
        // BLE+SPP 共存时,把主动通知转发给 BLE;但仅 SPP 通道消费的通知(SPP_ONLY_NOTIFICATIONS)不转发。
        if (method !in SPP_ONLY_NOTIFICATIONS) {
            peerBleDriver?.handleSppForwardedNotification(infoType, 0, 0, protoContent)
        }
    }

    /**
     * 处理客户端流数据
     */
    private fun onClientStreamData(packet: Packet?) {
        // 现在蓝牙也可以传流，故注释掉这里
//        if (!isUsbOrSocket()) {
//            Log.e(TAG, "onClientStreamData is not usb, ignore")
//            return
//        }
        val streamType = packet?.streamType ?: return
        val timestamp = packet.streamTimestamp ?: 0L
        val streamDataBytes = packet.streamData ?: return
        val streamData = StreamData(
            streamType = streamType,
            data = streamDataBytes,
            timestamp = timestamp
        )

        streamDataCallback?.invoke(streamData)
    }

    /**
     * 处理客户端隧道数据
     */
    private fun onClientTunnelData(packet: Packet) {
        val tunnelData = TunnelData(
            packet.tunnelContent, packet.tunnelConnectionId,
            packet.tunnelFlags, packet.tunnelWindowLimit
        )
        mTunnel?.write(tunnelData)
    }

    /**
     * 处理客户端Linux命令数据
     */
    private fun onClientLinuxCmdData(packet: Packet) {
        if (packet.linuxCmdDirection == LinuxCmdDirection.CameraToPhone) {
            val cmd = packet.linuxCmdCmd
            val content = packet.linuxCmdContent
            if (cmd == LinuxCmdCmd.RtosStatus) {
                infoCallback?.invoke(
                    OneDriverInfo.Response.InfoType.LINUX_CMD_RTOS_STATUS,
                    0,
                    content ?: 0,
                    null
                )
            }
        }
    }

    /**
     * 处理WiFi代理数据
     */
    private fun onWifiProxyData(packet: Packet) {
        // 实现WiFi代理数据处理逻辑
        // 对应C++版本的onWifiProxyData实现
        if (currentProtocol === Protocol.Bluetooth) {
            bleIO?.onWifiProxyData(packet.getPayload())
        } else {
            wifiProxyDataCallback?.invoke(packet.getPayload())
        }
    }

    /**
     * 处理客户端消息
     */
    private suspend fun onClientMessage(message: com.arashivision.onedriver.packet.Message?) {
        Log.e(TAG, "onClientMessage: messageId=${message?.messageId}, direction=${message?.messageDirection}")
        if (message?.messageDirection == com.arashivision.onedriver.packet.MessageDirection.PhoneToCamera) {
            onClientResponse(message)
        } else {
            onClientNotification(message)
        }
        emitActionStateUpdate()
    }

    /**
     * 处理客户端响应 - 对应C++版本的onClientResponse
     */
    private suspend fun onClientResponse(response: com.arashivision.onedriver.packet.Message?) {
        if (response == null) return

        val messageId = response.messageId
        val method = MessageCode.fromValue(response.messageMethod)

        val action = responseWaitQueue.findAction(messageId)
        if (action == null) {
            if (peerBleDriver?.handleSppForwardedResponse(response) == true) return
            // 部分机型对同一拍照请求应答两次,第二个应答携带成片路径。此时 action 已随首个
            // 应答出队,若按常规"无效响应"丢弃会连带丢掉路径,故在此单独识别并补发。
            if (handleSecondTakePictureResponse(response)) return
            Log.e(
                TAG,
                "invalid response, message id: $messageId, content size: ${response.messageContentSize}, type: ${response.messageContentType}"
            )
            val infoType = infoTypeFromMessageCode(method)
            infoCallback?.invoke(infoType, messageId, -1, null)
            return
        }

        action.setState(ActionState.Finished)
        responseWaitQueue.removeAction(messageId)
        // 记录拍照请求的 messageId,以便识别相机随后针对同一请求发来的第二个应答
        if (action.getOp() == MessageCode.PHONE_COMMAND_TAKE_PICTURE) {
            lastAnsweredTakePictureMessageId = messageId
        }

        Log.e(
            TAG,
            "responseWaitQueue size ${responseWaitQueue.size()} remove messageId $messageId  type: ${action.getOp().name}"
        )

        // 处理响应结果
        handleActionResponse(action, response)
    }

    /**
     * 处理相机针对同一拍照请求发来的第二个应答(携带成片路径)。
     *
     * 仅当 messageId 与最近一个已应答出队的拍照请求一致时才受理,避免把其他无主应答误当拍照结果。
     * 受理后按 [handleActionResponse] 中 [MessageCode.PHONE_COMMAND_TAKE_PICTURE] 分支的同等语义
     * 解析并经 [stillImageCallback] 分发,与首个应答共用同一条回调链路。
     *
     * 一次拍照只受理一次,受理后即清除记录,防止后续无主应答被反复当作拍照结果。
     *
     * @return true 表示已受理,调用方无需再按无效响应处理
     */
    private fun handleSecondTakePictureResponse(
        response: com.arashivision.onedriver.packet.Message,
    ): Boolean {
        if (response.messageId != lastAnsweredTakePictureMessageId) return false
        lastAnsweredTakePictureMessageId = null

        val responseCode = response.messageMethod
        if (responseCode != 200) {
            Log.e(
                TAG,
                "second take picture response failed, messageId=${response.messageId}, code=$responseCode"
            )
            stillImageCallback?.invoke(-kotlin.math.abs(responseCode), null)
            return true
        }

        if (response.messageContentType != MessageContentType.ApplicationProtobuf) {
            Log.e(
                TAG,
                "second take picture response has unexpected content type: ${response.messageContentType}"
            )
            return true
        }

        val takePictureResponse = try {
            TakePictureResponse.ADAPTER.decode(response.messageContent)
        } catch (e: Exception) {
            Log.e(TAG, "decode second take picture response failed: ${e.message}")
            return true
        }

        Log.e(
            TAG,
            "second take picture response, messageId=${response.messageId}, uri=${takePictureResponse.image?.uri}, aeb size=${takePictureResponse.aeb_images.size}"
        )
        stillImageCallback?.invoke(0, takePictureResponse)
        return true
    }

    /**
     * BLE+SPP 共存兜底:由 SPP 的 OneDriverImpl 调用,把本实例(BLE)队列里的对应响应处理掉。
     * 背景:相机存在 bug——有时把 App 经 BLE 发出的指令,其响应错误地走 SPP 回。
     * 此时 SPP 自己队列找不到该 messageId,转交给 BLE(本实例)按正常响应流程处理。
     * 队列中存在对应 action 则处理并返回 true;否则返回 false(交回调用方按 invalid response 处理)。
     */
    suspend fun handleSppForwardedResponse(message: com.arashivision.onedriver.packet.Message): Boolean {
        val action = responseWaitQueue.findAction(message.messageId) ?: return false
        Log.e(TAG, "handleSppForwardedResponse: handle BLE response forwarded from SPP, messageId=${message.messageId}")
        action.setState(ActionState.Finished)
        responseWaitQueue.removeAction(message.messageId)
        handleActionResponse(action, message)
        return true
    }

    /**
     * BLE+SPP 共存:由 SPP 的 OneDriverImpl 调用,把 SPP 收到的主动通知转发给 BLE 的 infoCallback。
     */
    fun handleSppForwardedNotification(infoType: Int, messageId: Long, err: Int, obj: Any?) {
        infoCallback?.invoke(infoType, messageId, err, obj)
    }

    /**
     * 处理Action响应 - 对应C++版本的完整实现，使用策略模式减少when判断
     */
    @OptIn(ExperimentalStdlibApi::class)
    private suspend fun handleActionResponse(
        action: Action,
        msg: com.arashivision.onedriver.packet.Message,
    ) {
        val method = action.getOp()
        val messageId = msg.messageId

        // 对应C++版本：sp<MessageLite> protoContent; RawBuf rawContent; int errorCode = 0;
        var protoContent: com.squareup.wire.Message<*, *>? = null
        var rawContent: ByteArray? = null
        var errorCode = 0

        val responseCode = msg.messageMethod
        val contentType = msg.messageContentType
        Log.e(TAG, "handle action responseCode:$responseCode method ${method.name}(messageId=$messageId)")

        // 对应C++版本：if (responseCode != 200) 错误处理
        if (responseCode != 200) {
            errorCode = -kotlin.math.abs(responseCode)
            if (contentType == MessageContentType.ApplicationProtobuf) {
                try {
                    val errorContent = Error.ADAPTER.decode(msg.messageContent)
                    Log.e(
                        TAG,
                        "camera response error for message ${method.name}(messageId=$messageId), code=$responseCode, desc: ${errorContent.message}"
                    )
                } catch (e: Exception) {
                    Log.e(
                        TAG,
                        "parse error content failed, size: ${msg.messageContentSize}"
                    )
                }
            }
        } else {
            // 对应C++版本：成功响应处理

            // 对应C++版本：特殊方法处理
            if (method == MessageCode.PHONE_COMMAND_GET_FILE_EXTRA ||
                method == MessageCode.PHONE_COMMAND_GET_IPERF_AVERAGE ||
                contentType == MessageContentType.ApplicationOctetStream
            ) {
                rawContent = msg.messageContent
            } else if (contentType == MessageContentType.ApplicationProtobuf) {
                val parseResult = parseProtoResponse(method, msg.messageContent)
                protoContent = parseResult.message
                errorCode = parseResult.errorCode
            }
        }
        // 直接处理响应，对应C++版本的完整实现
        val infoType = infoTypeFromMessageCode(method)
        // 对应C++版本的特殊回调处理
        when (method) {
            MessageCode.PHONE_COMMAND_TAKE_PICTURE -> {
                stillImageCallback?.invoke(errorCode, protoContent as TakePictureResponse?)
            }

            MessageCode.PHONE_COMMAND_TAKE_PICTURE_WITHOUT_STORING -> {
                stillImageWithoutStorageCallback?.invoke(
                    errorCode,
                    rawContent
                )
            }

            MessageCode.PHONE_COMMAND_START_CAPTURE,
            MessageCode.PHONE_COMMAND_START_TIMESHIFT_CAPTURE,
            MessageCode.PHONE_COMMAND_START_HDR_CAPTURE,
                -> {
                val state = if (errorCode == 0) OpState.STARTED else OpState.FAILED
                recordVideoCallback?.invoke(state.value, errorCode, null)
            }

            MessageCode.PHONE_COMMAND_START_BULLETTIME_CAPTURE -> {
                // 对应C++版本：OpState state = errorCode == 0 ? OpState::STARTED : OpState::FAILED;
                // mRecordVideoCallback(state, VideoResult(errorCode));
                val state = if (errorCode == 0) OpState.STARTED else OpState.FAILED
                recordVideoCallback?.invoke(state.value, errorCode, null)
            }

            MessageCode.PHONE_COMMAND_STOP_CAPTURE -> {
                val state = if (errorCode == 0) OpState.COMPLETE else OpState.FAILED
                val stopCaptureResp = protoContent as StopCaptureResp?
                recordVideoCallback?.invoke(state.value, errorCode, stopCaptureResp?.video)
            }

            MessageCode.PHONE_COMMAND_STOP_TIMESHIFT_CAPTURE -> {
                val state = if (errorCode == 0) OpState.COMPLETE else OpState.FAILED
                val stopTimeShiftResp = protoContent as StopTimeShiftResp?
                recordVideoCallback?.invoke(state.value, errorCode, stopTimeShiftResp?.video)
            }

            MessageCode.PHONE_COMMAND_STOP_HDR_CAPTURE -> {
                val state = if (errorCode == 0) OpState.COMPLETE else OpState.FAILED
                val stopHdrResp = protoContent as StopHdrResp?
                recordVideoCallback?.invoke(state.value, errorCode, stopHdrResp?.video)
            }

            MessageCode.PHONE_COMMAND_STOP_BULLETTIME_CAPTURE -> {
                val state = if (errorCode == 0) OpState.COMPLETE else OpState.FAILED
                val stopBulletTimeResp = protoContent as StopBulletTimeResp?
                recordVideoCallback?.invoke(state.value, errorCode, stopBulletTimeResp?.video)
            }

            MessageCode.PHONE_COMMAND_START_TIMELAPSE -> {
                val state = if (errorCode == 0) OpState.STARTED else OpState.FAILED
                timelapseCallback?.invoke(state.value, errorCode, null)
            }

            MessageCode.PHONE_COMMAND_STOP_TIMELAPSE -> {
                val state = if (errorCode == 0) OpState.COMPLETE else OpState.FAILED
                val stopTimelapseResp = protoContent as StopTimelapseResp?
                timelapseCallback?.invoke(state.value, errorCode, stopTimelapseResp?.video)
            }

            MessageCode.PHONE_COMMAND_GET_FILE_EXTRA,
            MessageCode.PHONE_COMMAND_GET_IPERF_AVERAGE,
            MessageCode.PHONE_COMMAND_GET_MINI_THUMBNAIL,
                -> {
                val requestID = action.getId()
                infoCallback?.invoke(
                    infoType,
                    requestID,
                    errorCode,
                    rawContent
                )
            }

            MessageCode.PHONE_COMMAND_SYNCTIME_ACCURATE,
                -> {
                val requestID = action.getId()
                if (mSyncTimeAccurateCount == 1 && errorCode == 0) {
                    mSyncTimeAccurateCount++
                    syncAccurateTime(requestID)
                    return
                } else {
                    infoCallback?.invoke(
                        infoType,
                        requestID,
                        errorCode,
                        protoContent
                    )
                }
            }

            MessageCode.PHONE_COMMAND_ENCRYPT_CAPABILITY_QUERY,
            MessageCode.PHONE_COMMAND_ENCRYPT_KEY_EXCHANGE,
                -> {
                val requestID = action.getId()
                val cb = encryptCallbacks.remove(requestID)
                if (cb != null) {
                    cb(errorCode, protoContent)
                } else {
                    infoCallback?.invoke(infoType, requestID, errorCode, protoContent)
                }
            }

            else -> {
                val requestID = action.getId()
                infoCallback?.invoke(
                    infoType,
                    requestID,
                    errorCode,
                    protoContent
                )
            }
        }
    }

    /**
     * 处理隧道可读事件 - 对应C++版本的onTunnelReadable
     */
    private suspend fun onTunnelReadable() {
        // 循环读取所有可用的隧道数据
        while (true) {
            val tunnelData = mTunnel?.read() ?: break

            if (!isWriteSynced) {
                // 同步未完成，但我们已经写入了所有同步包
                Log.w(TAG, "will write tunnel packets, though sync not finished")
            }

            // 创建隧道数据包
            val packet = Packet.newTunnelPacket(
                tunnelConnectionId = tunnelData.connectionId,
                tunnelFlags = tunnelData.flags,
                tunnelWindowLimit = tunnelData.windowLimit,
                tunnelContent = tunnelData.data,
                protocol = currentProtocol,
                isClassicPipe = isClassicConnected,
            )

            // 发送数据包 - 对应C++版本的 mUsbIO->write(packets)
            val packets = listOf(packet)
            usbIO?.write(packets)
        }
    }

    /**
     * 处理USB消息 - 对应C++版本的handleUsbMessage
     */
    private suspend fun handleUsbMessage(data: Map<String, Any?>?) {
        // 解析消息数据，假设data是Pair<Int, Any?>
        if (data?.containsKey("what") == true) {
            val what = data["what"] as Int
            when (what) {
                // 对应C++版本的OneUsb::kWhatInPacket
                OneUsb.WHAT_IN_PACKET -> { // kWhatInPacket
                    val messageData = data["packet"]
                    if (messageData is Packet) {
                        when (val packetType = messageData.getPacketType()) {
                            PacketType.Stream -> {
                                // 对应C++版本：onClientStreamData(packet)
                                onClientStreamData(messageData)
                            }

                            PacketType.Message -> {
                                // 对应C++版本：mMessageDemuxer->parse(packet)
                                val message = messageDemuxer?.parse(messageData)
                                onClientMessage(message)
                            }

                            PacketType.HeartBeat -> {
                                // 对应C++版本：onClientHeartBeat()
                                onClientHeartBeat()
                            }

                            PacketType.Synchronize -> {
                                // 对应C++版本：LOGI("received sync packet from other side")
                                Log.e(TAG, "received sync packet from other side")
                            }

                            PacketType.SocketTunnel -> {
                                // 对应C++版本：onClientTunnelData(packet)
                                onClientTunnelData(messageData)
                            }

                            PacketType.LinuxCmd -> {
                                // 对应C++版本：onClientLinuxCmdData(packet)
                                onClientLinuxCmdData(messageData)
                            }

                            PacketType.WifiProxy -> {
                                // 对应C++版本：onWifiProxyData(packet)
                                onWifiProxyData(messageData)
                            }

                            else -> {
                                // 对应C++版本：LOGI("parse message type = %d", static_cast<int>(packetType))
                                Log.e(TAG, "parse message type = ${packetType.value}")
                            }
                        }
                    }
                }
                // 对应C++版本的OneUsb::kWhatSynced
                OneUsb.WHAT_SYNCED -> { // kWhatSynced
                    // 对应C++版本：CHECK_NE(mProtocol, Protocol::BLUETOOTH)
                    if (currentProtocol != Protocol.Bluetooth) {
                        // 对应C++版本：mUsbStateCallback(UsbState::SYNCED, 0)
                        // 更新同步状态
                        isWriteSynced = true
                        // 调用回调
                        usbStateCallback?.invoke(UsbState.SYNCED, 0)
                        // 对应C++版本：emitActionStateUpdate()
                        emitActionStateUpdate()
                    }
                }
                // BLE+SPP 共存:SPP 通道收到的同步包 / 心跳包,回调给 BLE 的 OneDriverImpl,
                OneUsb.WHAT_SYNC_SPP_FORWARD -> {
                    val syncData = data["data"] as? ByteArray
                    if (syncData != null) {
                        peerBleDriver?.forwardedSyncListener?.invoke(syncData)
                    }
                }
                // 对应C++版本的OneUsb::kWhatError
                OneUsb.WHAT_ERROR -> { // kWhatError
                    val error = data["error"] as Int
                    if (error == ERR_SOCKET_DEVICE_BUSY || !reconnectIfNeed(error)) {
                        mError.value = error
                        Log.e(TAG, "reconnectIfNeed = false, kWhatError $error")
                        usbStateCallback?.invoke(UsbState.ERROR, mError.value)
                    } else {
                        Log.e(TAG, "kWhatError $error")
                    }
                }
                // 对应C++版本的OneUsb::kWhatTestUsb
                OneUsb.WHAT_TEST_USB -> { // kWhatTestUsb
//                    if (messageData is RawBuf) {
//                        val rawBuf = messageData
//                        // 对应C++版本：创建StreamData并调用mStreamDataCallback
//                        val streamData = StreamData(
//                            streamType = StreamType.Unknown,
//                            data = rawBuf.data(),
//                            timestamp = 0
//                        )
//                        streamDataCallback?.invoke(streamData)
//                    }
                }

                else -> {
                    // 对应C++版本的default分支
                }
            }
        }
    }

    /**
     * 写入WiFi心跳
     */
    private suspend fun writeWifiHeartBeat() {
        // 实现WiFi心跳写入逻辑
        if (reconnecting) {
            Log.w("OneDriverImpl", "writeWifiHeartBeat, but is reconnecting, ignore.")
            return
        }
        val packet = Packet.newHeartBeatPacket()
        packet?.let {
            socketIO?.write(listOf(it))
        }
    }

    fun setWifiHeartDebug(debug: Boolean): Int {
        isWifiDebug = debug
        socketIO?.setDebug(debug)
        return 0
    }

    fun setMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        options: MultiPhotographyOptions,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setMultiVideoMode run $funcMode $sensorMode  $optionList")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetMultiPhotographyOptions(
                function_mode = FunctionMode.fromValue(funcMode) ?: FunctionMode.FUNCTION_MODE_NORMAL,
                device = SensorDevice.fromValue(sensorMode) ?: SensorDevice.SENSOR_DEVICE_UNKNOWN,
                option_types = optionList,
                value_ = options
            ),
            "method" to MessageCode.PHONE_COMMAND_SET_MULTI_PHOTOGRAPHY_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }


    fun getMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        timeoutMs: Int,
        retryCount: Int,
    ): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getMultiVideoMode run  $id  $funcMode $sensorMode  $optionList")
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetMultiPhotographyOptions(
                function_mode = FunctionMode.fromValue(funcMode) ?: FunctionMode.FUNCTION_MODE_NORMAL,
                device = SensorDevice.fromValue(sensorMode) ?: SensorDevice.SENSOR_DEVICE_UNKNOWN,
                option_types = optionList
            ),
            "method" to MessageCode.PHONE_COMMAND_GET_MULTI_PHOTOGRAPHY_OPTIONS
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getSingleSensor(timeoutMs: Int, retryCount: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getSingleSensor run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to GetActiveSensorDevice(),
            "method" to MessageCode.PHONE_COMMAND_GET_ACTIVE_SENSOR
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }
        if (retryCount >= 0) {
            messageData["retryCount"] = retryCount
        }
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setSingleSensor(sensor: Int): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setSingleSensor run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetActiveSensorDevice().apply {
                this.device = SensorDevice.fromValue(sensor) ?: SensorDevice.SENSOR_DEVICE_UNKNOWN
            },
            "method" to MessageCode.PHONE_COMMAND_SET_ACTIVE_SENSOR
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun ageTestStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "ageTestStatus run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_GET_AGEINGTEST_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun dspLinkTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "dspLinkTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_DEVLINK_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun whiteBlanceTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "whiteBlanceTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_VIGNETTE_DATA_SAVE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun blackLevelTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "blackLevelTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_BLC_DATA_SAVE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun badPointTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "badPointTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_BPC_DATA_SAVE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun gyroScopeTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "gyroScopeTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_GYROSCOPE_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun vibrateTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "vibrateTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_MOTOR_TEST
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun vibrateStopTest(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "vibrateStopTest run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_MOTOR_TEST_STOP
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun checkVideo(videoResolution: Int): Boolean {
        Log.d(TAG, "checkVideo run")

        return VideoResolution.fromValue(videoResolution) != null
    }

    fun checkVideo(width: Int, height: Int, fps: Int): Boolean {
        Log.d(TAG, "checkVideo run")
        val pattern = """RES_(\d+)_(\d+)P(\d+)""".toRegex()
        return VideoResolution.entries.firstOrNull {
            val result = pattern.find(it.name) ?: return@firstOrNull false
            val (w, h, f) = result.destructured
            (w.toInt() == width && h.toInt() == height && f.toInt() == fps)
        } != null
    }

    fun chargingBox(commandType: Int, datas: ByteArray): Long {
        if (!isOpened) return -1
        Log.d(TAG, "chargingBox run")
        val id = generateMessageId()
        val method = if (commandType == 7) {
            MessageCode.FACTORY_COMMAND_CHARGINGBOX_BUTTON_TEST
        } else if (commandType == 9) {
            MessageCode.FACTORY_COMMAND_CHARGINGBOX_HALL_TEST
        } else {
            MessageCode.FACTORY_COMMAND_CHARGINGBOX
        }
        val chargingBoxData = ChargingBoxData(chargingboxdata = datas.toByteString())
        val messageData = mutableMapOf(
            "requestID" to id,
            "raw" to chargingBoxData,
            "method" to method
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun uploadJson(bytes: ByteArray): Long {
        Log.d(TAG, "script upload json")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "raw" to bytes,
            "method" to MessageCode.FACTORY_COMMAND_SCRIPT_JSON_UPLOAD
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun uploadCmd(bytes: ByteArray): Long {
        Log.d(TAG, "script upload cmd")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "raw" to bytes,
            "method" to MessageCode.FACTORY_COMMAND_SCRIPT_CMD_UPLOAD
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun scriptRefersh(): Long {
        Log.d(TAG, "script refersh")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_SCRIPT_REFRESH
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun scriptRun(): Long {
        Log.d(TAG, "script run ")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_SCRIPT_CMD_RUN
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAAAFactoryMode(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setAAAFactoryMode run ")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_SET_AAA_FACTORYMODE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAAANormalMode(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setAAANormalMode run ")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_SET_AAA_NORMALMODE
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getWhiteBlanceStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getWhiteBlanceStatus run ")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_GET_WHITEBLANCE_STATUS
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getSfrStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getSfrStatus run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_GET_SFR_STATUS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getSfrResult(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getSfrResult run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.FACTORY_COMMAND_GET_SFR_RESULT
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getCloudStorageUploadStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getCloudStorageUploadStatus run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_CLOUD_STORAGE_UPLOAD_STATUS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun deleteWifiHistoryInfo(ssid: String): Long {
        if (!isOpened) return -1
        Log.d(TAG, "deleteWifiHistoryInfo run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to DeleteWifiConnectList(ssid = ssid),
            "method" to MessageCode.PHONE_COMMAND_DEL_WIFI_HISTORY_INFO
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setCloudStorageUploadStatus(cloudStorageUploadParams: CloudStorageUploadParams): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setCloudStorageUploadStatus run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetCloudStorageUploadStatus(cloudStorageUploadParams),
            "method" to MessageCode.PHONE_COMMAND_SET_CLOUD_STORAGE_UPLOAD_STATUS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getCloudStorageBindStatus(): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getCloudStorageBindStatus run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_CLOUD_STORAGE_BIND_STATUS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setCloudStorageBindStatus(cloudStorageBindParams: CloudStorageBindParams): Long {
        if (!isOpened) return -1
        Log.d(TAG, "setCloudStorageBindStatus run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to SetCloudStorageBindStatus(cloudStorageBindParams),
            "method" to MessageCode.PHONE_COMMAND_SET_CLOUD_STORAGE_BIND_STATUS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    private suspend fun handleStreamMessage(data: Map<String, Any>?) {
        if (data?.containsKey("streamType") == true && data.containsKey("timestamp") && data.containsKey("data")) {
            val packet = Packet.newStreamPacket(
                streamType = data["streamType"] as StreamType,
                streamTimestamp = data["timestamp"] as Long,
                streamData = data["data"] as ByteArray,
                protocol = Protocol.Socket,
                isClassicPipe = isClassicConnected
            )
            when (currentProtocol) {
                Protocol.USB -> usbIO?.write(listOf(packet))
                Protocol.Bluetooth -> bleIO?.write(listOf(packet))
                Protocol.Socket -> socketIO?.write(listOf(packet))
                Protocol.Go2Bluetooth -> bleIO?.writeBle(listOf(Go2BlePacket.newBlePacketFromPacket(packet)))
            }
        }
    }

    /**
     * 添加请求 - 对应C++版本的addRequest
     */
    private suspend fun handleRequestMessage(data: Map<String, Any>?) {

        if (data?.containsKey("method") == true && data["method"] is MessageCode) {
            val action = Action(data["requestID"] as Long, data["method"] as MessageCode)

            action.putAll(data)

            prepareQueue.pushBack(action)
//            Log.e("", "push prepareQueue size ${prepareQueue.size()} id ${action.getId()}")

            if (!isActionPrepared(action)) {
                return
            }

            prepareQueue.removeAction(action.getId())
            val state = triggerAction(action)

            if (state == ActionState.WaitResponse) {
                responseWaitQueue.pushBack(action)
            }

//            Log.e(
//                TAG,
//                "remove prepareQueue size ${prepareQueue.size()} id ${action.getId()} state $state responseWaitQueue size ${responseWaitQueue.size()}"
//            )
        }

    }


    /**
     * 处理Action超时
     */
    private suspend fun handleRequestTimeoutMessage(data: Map<String, Any>?) {
        val actionId = data?.get("actionId") as Long
        // 检查Action是否仍在等待响应
        val action = responseWaitQueue.findAction(actionId)
        if (action != null && action.getState() == ActionState.WaitResponse) {
            // 处理超时重试
            val retryCount = if (action.hasProp("retryCount")) {
                action.getRetryCount()
            } else {
                globalRequestRetryTime
            }
            if (retryCount > 0) {
                action.setProp("retryCount", retryCount - 1)
                triggerAction(action)
            } else {
                Log.e(TAG, "request timeout ${action.toString()}")
                val messageId = action.getId()
                val method = -502

                val message: com.arashivision.onedriver.packet.Message

                // 对应C++版本的if (action->hasProp("raw"))判断
                if (action.hasProp("raw")) {
                    // 对应C++版本：message = sp<Message>(new Message(method, MessageContentType::application_octet_stream, MessageDirection::PHONE_TO_CAMERA, messageId));
                    message = com.arashivision.onedriver.packet.Message(
                        messageMethod = method,
                        messageContentType = MessageContentType.ApplicationOctetStream,
                        messageDirection = MessageDirection.PhoneToCamera,
                        messageId = messageId
                    )
                } else {
                    // 对应C++版本：message = sp<Message>(new Message(method, MessageContentType::application_protobuf, MessageDirection::PHONE_TO_CAMERA, messageId));
                    message = com.arashivision.onedriver.packet.Message(
                        messageMethod = method,
                        messageContentType = MessageContentType.ApplicationProtobuf,
                        messageDirection = MessageDirection.PhoneToCamera,
                        messageId = messageId
                    )
                }
                onClientMessage(message)
            }
        }
    }

    /**
     * 处理消息 - 替代Handler的handleMessage
     */
    private suspend fun handleMessage(message: Message) {
        when (message.type) {
            MessageType.START -> {
                handleStart(message.data)
            }

            MessageType.USB_IO -> handleUsbMessage(message.data)
            MessageType.BLE_ERROR -> handleBleErrorMessage(message.data)
            MessageType.ACTION_STATE_UPDATE -> {
                hasActionUpdateMsg = false
                onActionStateUpdate()
            }

            MessageType.HEAT_BEAT -> writeHeartBeartInternal()
            MessageType.WIFI_HEART_BEAT -> writeWifiHeartBeat()
            MessageType.OBTAIN_ROTS_STATUS -> obtainCameraRtosStatus()
            MessageType.REQUEST -> handleRequestMessage(message.data)
            MessageType.REQUEST_TIMEOUT -> handleRequestTimeoutMessage(message.data)
            MessageType.TUNNEL_RADABLE -> onTunnelReadable()
            MessageType.STREAM -> handleStreamMessage(message.data)

            else -> Unit
        }
    }

    /**
     * 如果需要则重连 - 对应C++版本的reconnectIfNeed
     */
    private fun reconnectIfNeed(error: Int): Boolean {
        val shouldReconnect = needReconnectCallback?.invoke() ?: false
        if (shouldReconnect) {
            // 对应C++版本的条件检查
            if (streamStarted || wifiAddr.isEmpty() || wifiPort == 0 || currentProtocol != Protocol.Socket) {
                return false
            }

            reconnecting = true

            // 对应C++版本：检查是否正在关闭
            if (isClosing) {
                Log.w("OneDriverImpl", "reconnect, but is Closing")
                reconnecting = false
                return false
            }

            // 对应C++版本：在协程中执行重连逻辑
            scope.launch {
                handleReconnect(error)
            }
        }
        return shouldReconnect
    }

    /**
     * 处理重连 - 对应C++版本的重连逻辑
     */
    private suspend fun handleReconnect(error: Int) {
        mutex.withLock {
            try {
                // 对应C++版本：检查是否已打开
                if (!isOpened) {
                    Log.w("OneDriverImpl", "reconnect, but is not opened")
                    return@withLock
                }

                // 再次检查是否正在关闭，避免并发问题
                if (isClosing) {
                    Log.w("OneDriverImpl", "reconnect, but is Closing")
                    return@withLock
                }

                Log.i("OneDriverImpl", "start reconnect socket")

                // 对应C++版本：关闭现有连接
                socketIO?.close()
                socketIO = null
                Log.i("OneDriverImpl", "close end")

                // 对应C++版本：创建新的Socket连接
                socketIO = SocketIO()
                socketIO?.setDebug(isWifiDebug)
                val retv =
                    socketIO?.open(networkHandle, 500, wifiAddr, wifiPort) ?: -1
                Log.d("OneDriverImpl", "open wifi $retv")
                socketIO?.setDebug(isWifiDebug)
                if (retv == 0) {
                    // 对应C++版本：重连成功，合并队列
                    val responseQueueTmp = responseWaitQueue.cloneActions()
                    val waitQueueTmp = prepareQueue.cloneActions()
                    val resetQueue = mutableListOf<Action>()

                    // 将响应队列和等待队列合并到重置队列
                    resetQueue.addAll(responseQueueTmp)
                    resetQueue.addAll(waitQueueTmp)

                    responseWaitQueue.clear()
                    prepareQueue.clear()

                    // 将所有Action重新加入准备队列
                    for (action in resetQueue) {
                        prepareQueue.pushBack(action)
                    }

                    // 对应C++版本：重新设置通知并启动服务
                    socketIO?.setNotify { data ->
                        sendMessage(MessageType.USB_IO, data)
                    }
                    socketIO?.serve()

                    // 对应C++版本：重置同步状态
                    isWriteSynced = Packet.useUcd2

                    // 对应C++版本：发送状态更新
                    emitActionStateUpdate()

                    // 对应C++版本：调用重连成功回调
                    onReconnectSuccessCallback?.invoke()
                } else {
                    // 对应C++版本：重连失败，发送错误消息
                    if (isOpened) {
                        sendMessage(
                            MessageType.USB_IO,
                            mapOf("what" to OneUsb.WHAT_ERROR, "error" to error)
                        )
                    } else {
                        Log.w("OneDriverImpl", "reconnect failed, but is not opened")
                    }
                }

                Log.i("OneDriverImpl", "open end")

            } finally {
                reconnecting = false
            }
        }
    }


    fun updateDownloadInfo(downLoadInfo: DownLoadInfo): Long {
        if (!isOpened) return -1
        Log.d(TAG, "updateDownloadInfo run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to downLoadInfo,
            "method" to MessageCode.PHONE_COMMAND_DOWNLOAD_INFO
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getDownloadFileList(list: GetFileList): Long {
        if (!isOpened) return -1
        Log.d(TAG, "getCloudStorgetDownloadFileListageUploadStatus run ")
        val id = generateMessageId()

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to list,
            "method" to MessageCode.PHONE_COMMAND_GET_DOWNLOAD_FILE_LIST
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun syncAccurateTime(): Long {
        val requestId = generateMessageId()
        Log.d(TAG, "syncAccurateTime run ")
        mSyncTimeAccurateCount = 1
        syncAccurateTime(requestId)
        return requestId
    }

    fun syncAccurateTime(requestId: Long) {
        if (!isOpened) return

        Log.d("OneDriverImpl", "syncAccurateTime")

        // 获取当前时间
        val now = currentTimeMillis()
        val seconds = now / 1000
        val milliseconds = now % 1000

        Log.d("OneDriverImpl", "Seconds since epoch: $seconds")
        Log.d("OneDriverImpl", "Milliseconds since epoch: $milliseconds")
        Log.d("OneDriverImpl", "mSyncTimeAccurateCount epoch: $mSyncTimeAccurateCount")

        val timeAccurateInfo = TimeAccurate_Info(
            time_accurate_s = seconds,
            time_accurate_ms = milliseconds
        )

        val param = SyncTimeAccurate(
            timeaccurate_info = timeAccurateInfo,
            sync_count = mSyncTimeAccurateCount
        )

        val messageData = mutableMapOf(
            "requestID" to requestId,
            "param" to param,
            "method" to MessageCode.PHONE_COMMAND_SYNCTIME_ACCURATE
        )

        sendMessage(MessageType.REQUEST, messageData)
        return
    }

    fun notifyGetDownloadFileListResult(addListResultSync: DownloadListResultSync): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "notifyGetDownloadFileListResult run ")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to addListResultSync,
            "method" to MessageCode.PHONE_COMMAND_ADD_DOWNLOAD_LIST_RESULT_SYNC
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setNetworkConfigEnable(params: SetNetworkConfigEnable): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setNetworkConfigEnable run ")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to params,
            "method" to MessageCode.PHONE_COMMAND_SET_NETWORK_CONFIG_ENABLE
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun restoreFactorySettings(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "restoreFactorySettings run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_RESTORE_FACTORY_SETTINGS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setSingleHostCmdInfo(singleHostCmdInfo: SingleHostCmdInfo): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setSingleHostCmdInfo run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to singleHostCmdInfo,
            "method" to MessageCode.PHONE_COMMAND_SINGLE_HOST_CTRL_INFO
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getIntervalRecCfg(intervalRecCfg: IntervalRecInfo): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getIntervalRecCfg run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to intervalRecCfg,
            "method" to MessageCode.PHONE_COMMAND_GET_INTERVALREC_CFG
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setIntervalRecCfg(intervalRecCfg: IntervalRecInfo): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getIntervalRecCfg run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to intervalRecCfg,
            "method" to MessageCode.PHONE_COMMAND_SET_INTERVALREC_CFG
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun startStopIntervalRec(intervalRecStartStop: IntervalRecStartStop): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "startStopIntervalRec run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to intervalRecStartStop,
            "method" to MessageCode.PHONE_COMMAND_INTERVALREC_REC_START_STOP
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun cancelIntervalRec(intervalRecCancel: IntervalRecCancel): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "cancelIntervalRec run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to intervalRecCancel,
            "method" to MessageCode.PHONE_COMMAND_INTERVALREC_REC_CANCEL_CMD
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getIntervalRecStatus(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getIntervalRecStatus run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_INTERVAL_RECORD_STATUS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getIntervalRecSceneCfg(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getIntervalRecSceneCfg run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_INTERVALREC_SCENE_CFG
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun getIntervalRecFeedbackCfg(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getIntervalRecFeedbackCfg run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_INTERVALREC_FEEDBACK_CFG
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setIntervalRecFeedbackCfg(intervalRecFeedback: IntervalRecFeedback): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setIntervalRecFeedbackCfg run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to intervalRecFeedback,
            "method" to MessageCode.PHONE_COMMAND_SET_INTERVALREC_FEEDBACK_CFG
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAudioStream(request: AudioStreamCtrl, timeoutMs: Int = -1): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setAudioStream run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to request,
            "method" to MessageCode.PHONE_COMMAND_SET_AUDIO_STREAM
        )
        if (timeoutMs >= 0) {
            messageData["timeoutMs"] = timeoutMs
        }

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAiIntent(request: AiIntentCtrl): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setAiIntent run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to request,
            "method" to MessageCode.PHONE_COMMAND_AI_INTENT
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setAssistantLanguage(request: AssistantLanguageCtrl): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setAssistantLanguage run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to request,
            "method" to MessageCode.PHONE_COMMAND_SET_ASSISTANT_LANGUAGE
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun setUserRegion(request: UserRegionCtrl): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "setUserRegion run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to request,
            "method" to MessageCode.PHONE_COMMAND_SET_USER_REGION
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun sendStreamData(streamType: StreamType, timestamp: Long, data: ByteArray) {
        if (!isOpened) return

        val messageData = mutableMapOf(
            "streamType" to streamType,
            "timestamp" to timestamp,
            "data" to data
        )

        sendMessage(MessageType.STREAM, messageData)
    }

    fun getFirmwareVersionsInfo(): Long {
        if (!isOpened) return -1
        val id = generateMessageId()
        Log.d(TAG, "getFirmwareVersionsInfo run")

        val messageData = mutableMapOf(
            "requestID" to id,
            "method" to MessageCode.PHONE_COMMAND_GET_FIRMWARE_VERSIONS
        )

        sendMessage(MessageType.REQUEST, messageData)
        return id
    }

    fun bindBluetoothMacFeature(featureBluetoothMacBind: FeatureBluetoothMacBind): Long {
        if (!isOpened) return -1
        Log.d(TAG, "bindBluetoothMacFeature run")
        val id = generateMessageId()
        val messageData = mutableMapOf(
            "requestID" to id,
            "param" to featureBluetoothMacBind,
            "method" to MessageCode.PHONE_COMMAND_FEATURE_BLUETOOTHMAC_BIND
        )
        sendMessage(MessageType.REQUEST, messageData)
        return id
    }
}

