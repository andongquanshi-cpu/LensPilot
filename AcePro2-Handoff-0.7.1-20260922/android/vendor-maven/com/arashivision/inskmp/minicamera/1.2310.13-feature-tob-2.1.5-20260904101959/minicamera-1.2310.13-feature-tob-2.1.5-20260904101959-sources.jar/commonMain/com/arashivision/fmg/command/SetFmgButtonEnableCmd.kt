package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.onecamera.OneDriver

class SetFmgButtonEnableCmd(private val fmgButtonAbleParams: FmgButtonAbleParams) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetButtonEnable(fmgButtonAbleParams)
    }
}
