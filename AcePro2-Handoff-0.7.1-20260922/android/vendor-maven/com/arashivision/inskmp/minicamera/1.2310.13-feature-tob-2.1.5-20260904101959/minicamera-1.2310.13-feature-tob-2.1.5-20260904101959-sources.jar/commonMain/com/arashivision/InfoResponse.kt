package com.arashivision

class InfoResponse(val requestID: Long, val data: Any?)