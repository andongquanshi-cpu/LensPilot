package com.arashivision.fmg.response

class FmgSetSettingsResp(var requestID: Long)
