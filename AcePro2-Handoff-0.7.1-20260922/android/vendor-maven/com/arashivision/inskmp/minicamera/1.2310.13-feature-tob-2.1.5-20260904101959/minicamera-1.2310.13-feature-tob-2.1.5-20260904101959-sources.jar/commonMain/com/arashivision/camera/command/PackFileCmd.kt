package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetFile

class PackFileCmd(private val mGetFile: GetFile) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.packFile(mGetFile)
    }
}
