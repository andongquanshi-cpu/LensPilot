package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzTimeElapseReqMsg(
//uint_8
    private val mode: Short, //uint_8
    private val status: Short, //uint_16
    private val duration: Int
) :
    PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(4)
        data[0] = mode.toByte()
        data[1] = status.toByte()
        val durationArrays = FmgByteUtils.intToUint16ByteArray(duration)
        durationArrays.copyInto(data, 2, 0, durationArrays.size)
        return data
    }

    override fun toString(): String {
        return "mode: $mode status: $status duration: $duration"
    }

    override fun name(): String {
        return "CMD_TIME_ELAPSE"
    }
}
