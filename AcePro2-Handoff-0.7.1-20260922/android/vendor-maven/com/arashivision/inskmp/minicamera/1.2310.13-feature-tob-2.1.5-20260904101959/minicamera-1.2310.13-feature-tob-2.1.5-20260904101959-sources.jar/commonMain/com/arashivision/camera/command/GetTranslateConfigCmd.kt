package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

internal class GetTranslateConfigCmd(private val timeoutMs: Int = -1) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getTranslateConfig(timeoutMs)
    }
}