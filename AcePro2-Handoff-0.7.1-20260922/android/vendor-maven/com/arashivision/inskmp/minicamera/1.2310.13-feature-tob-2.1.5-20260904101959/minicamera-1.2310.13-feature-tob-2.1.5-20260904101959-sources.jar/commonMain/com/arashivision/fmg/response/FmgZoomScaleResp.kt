package com.arashivision.fmg.response

class FmgZoomScaleResp(var requestID: Long)
