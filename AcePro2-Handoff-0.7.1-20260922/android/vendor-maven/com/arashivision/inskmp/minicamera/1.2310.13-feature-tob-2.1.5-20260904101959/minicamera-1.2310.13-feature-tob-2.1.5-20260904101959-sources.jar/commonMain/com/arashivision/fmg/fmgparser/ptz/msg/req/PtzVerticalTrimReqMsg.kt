package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzVerticalTrimReqMsg(private val degrees: Short) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(2)
        val degreesArray = FmgByteUtils.shortToInt16ByteArray(degrees)
        degreesArray.copyInto(data, 0, 0, 2)
        return data
    }

    override fun toString(): String {
        return "degress: $degrees"
    }

    override fun name(): String {
        return "CMD_VERTICAL_TRIM"
    }
}
