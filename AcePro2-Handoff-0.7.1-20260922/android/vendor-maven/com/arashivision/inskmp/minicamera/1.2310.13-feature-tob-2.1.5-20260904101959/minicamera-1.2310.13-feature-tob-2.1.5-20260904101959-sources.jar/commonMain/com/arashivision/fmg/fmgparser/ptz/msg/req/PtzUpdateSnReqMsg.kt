package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzUpdateSnReqMsg(private val sn: String) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        return FmgByteUtils.StringToByteArrayOnUS_ASCII(sn, sn.length)
    }

    override fun toString(): String {
        return sn
    }

    override fun name(): String {
        return "CMD_UPDATE_SN"
    }
}
