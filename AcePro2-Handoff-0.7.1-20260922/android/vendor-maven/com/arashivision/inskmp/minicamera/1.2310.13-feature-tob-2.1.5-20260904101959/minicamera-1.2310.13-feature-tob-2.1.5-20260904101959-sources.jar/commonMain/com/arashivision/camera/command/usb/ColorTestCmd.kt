package com.arashivision.camera.command.usb

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * 相机屏幕颜色效果测试
 */
class ColorTestCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.startColorTest()
        return null
    }
}
