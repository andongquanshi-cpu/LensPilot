package com.arashivision.camera.listener

interface ICameraInfoListener {
    fun onCameraInfo(what: Int, requestId: Long, err: Int, obj: Any?)
}
