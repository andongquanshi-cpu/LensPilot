package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.onecamera.OneDriver

/**
 * 关闭蓝牙的cmd
 */
class BleCloseCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any {
        oneDrvier?.closeBle()
        BleManagerCore.disconnectAllDevice()
        return 0
    }
}
