package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.DownLoadInfo

class UpdateDownloadInfoCmd(private val mDownLoadInfo: DownLoadInfo) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.updateDownloadInfo(mDownLoadInfo)
    }
}
