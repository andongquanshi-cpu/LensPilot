package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.SetTimelapseOptions

class AyncSetTimelapseOptionCmd(
    private val timelapseOptions: SetTimelapseOptions,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        val optionsASync = oneDrvier?.setTimelapseOptionsASync(timelapseOptions, mRequestOptions)
        return optionsASync
    }
}
