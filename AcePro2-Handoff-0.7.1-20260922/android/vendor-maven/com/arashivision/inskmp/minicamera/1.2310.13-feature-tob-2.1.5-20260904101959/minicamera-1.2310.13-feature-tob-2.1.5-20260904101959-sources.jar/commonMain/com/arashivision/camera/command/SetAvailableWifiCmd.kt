package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.WifiConnectionInfo

class SetAvailableWifiCmd(private val mWifiConnectionInfo: WifiConnectionInfo) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setAvailableWifi(mWifiConnectionInfo)
    }
}
