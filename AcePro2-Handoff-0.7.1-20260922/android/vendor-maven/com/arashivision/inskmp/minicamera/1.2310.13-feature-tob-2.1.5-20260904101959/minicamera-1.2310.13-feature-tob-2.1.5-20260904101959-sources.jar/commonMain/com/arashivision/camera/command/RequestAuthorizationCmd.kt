package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class RequestAuthorizationCmd(
    /**
     * [com.arashivision.onecamera.OneDriverInfo.Notification.AuthorizationOperationType]
     */
    private val authorizationOperationType: Int
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.requestAuthorization(authorizationOperationType)
    }
}
