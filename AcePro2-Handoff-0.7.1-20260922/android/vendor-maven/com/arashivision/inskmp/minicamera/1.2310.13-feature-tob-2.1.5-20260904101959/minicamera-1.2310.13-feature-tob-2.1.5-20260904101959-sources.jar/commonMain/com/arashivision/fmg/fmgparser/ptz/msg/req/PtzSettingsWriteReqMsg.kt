package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzSettingsWriteReqMsg(private val data: Byte) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val packdata = ByteArray(1)
        packdata[0] = data
        return packdata
    }

    override fun toString(): String {
        return "data: $data"
    }

    override fun name(): String {
        return "CMD_SETTINGS_WRITE"
    }
}
