package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetEtdEventReqMsg(private val index: Int, private val length: Int) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(4)
        val indexBytes = FmgByteUtils.intToUint16ByteArray(index)
        val lengthBytes = FmgByteUtils.intToUint16ByteArray(length)
        indexBytes.copyInto(data, 0, 0, indexBytes.size)
        lengthBytes.copyInto(data, 2, 0, lengthBytes.size)
        return data
    }

    override fun toString(): String {
        return "PtzGetEtdEventReqMsg{" +
                "index=" + index +
                ", length=" + length +
                '}'
    }

    override fun name(): String {
        return "CMD_GET_ETD"
    }
}
