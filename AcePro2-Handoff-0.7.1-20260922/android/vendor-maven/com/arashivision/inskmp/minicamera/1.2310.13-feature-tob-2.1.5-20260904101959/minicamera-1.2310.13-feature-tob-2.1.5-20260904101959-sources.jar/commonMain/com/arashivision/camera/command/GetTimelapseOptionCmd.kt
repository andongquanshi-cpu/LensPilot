package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetTimelapseOptions

class GetTimelapseOptionCmd(private val getTimelapseOptions: GetTimelapseOptions) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getTimelapseOptions(getTimelapseOptions)
    }
}
