//package com.arashivision.camera.listener
//
//import com.arashivision.camera.stream.StreamGimbalData
//import com.arashivision.onestream.Gyro.OneGyroField
//
///**
// * 预览中的参数回调
// */
//interface ICameraPreviewListener {
//    fun onVideoData(data: ByteArray?, offset: Int, size: Int, timestamp: Long)
//
//    fun onGyroData(gyroFields: List<OneGyroField>?)
//
//    fun onExposureData(exposureTime: Double, timestamp: Long)
//
//    fun onResolutionUpdate(width: Int, height: Int, fps: Int)
//
//    fun onGimbalData(gimbalData: StreamGimbalData?)
//}
