package com.arashivision.common

expect object Build {
    val BRAND: String?

}
