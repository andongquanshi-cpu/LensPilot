package com.arashivision.camera.listener

import com.arashivision.camera.wifiproxy.IWifiProxyData

fun interface IWifiProxyDataListener {
    fun onReadWifiProxyData(wifiProxyData: IWifiProxyData?)
}
