package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver

class GetCaptureStatus(private val mRequestOptions: RequestOptions) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getCaptureStatus(mRequestOptions)
    }
}
