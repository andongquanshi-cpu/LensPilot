package com.arashivision.fmg.response

class FmgOTAProgressChangedResp(var requestID: Long, var percent: Float)
