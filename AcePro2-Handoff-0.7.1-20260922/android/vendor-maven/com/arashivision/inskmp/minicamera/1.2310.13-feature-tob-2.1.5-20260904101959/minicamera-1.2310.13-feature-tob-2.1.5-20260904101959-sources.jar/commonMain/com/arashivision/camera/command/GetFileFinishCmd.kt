package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetFileFinish

class GetFileFinishCmd(private val mGetFileFinish: GetFileFinish) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getFileFinish(mGetFileFinish)
    }
}
