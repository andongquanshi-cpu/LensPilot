package com.arashivision.fmg.fmgparser.ota

object OtaFirmwarePacketPack {
    private const val PACKET_DATA_LENGTH = 16

    fun firmwareToPackets(data: ByteArray, iOtaFirmwarePacketPack: IOtaFirmwarePacketPack) {
        val len = data.size
        val lastPacketLen = len % PACKET_DATA_LENGTH
        var loopNumber = 0

        loopNumber = if (lastPacketLen == 0) {
            len / PACKET_DATA_LENGTH
        } else {
            len / PACKET_DATA_LENGTH + 1
        }

        for (i in 0 until loopNumber) {
            val packetFwDataLength: Int
            val packetData = ByteArray(PACKET_DATA_LENGTH)
            if (i == loopNumber - 1 && lastPacketLen != 0) {
                packetFwDataLength = lastPacketLen
                data.copyInto(
                    destination = packetData,
                    destinationOffset = 0,
                    startIndex = i * PACKET_DATA_LENGTH,
                    endIndex = i * PACKET_DATA_LENGTH + lastPacketLen
                )
                //不足部分用0xFF填充
                for (j in lastPacketLen until PACKET_DATA_LENGTH) {
                    packetData[j] = 0xFF.toByte()
                }
            } else {
                packetFwDataLength = PACKET_DATA_LENGTH
                data.copyInto(
                    destination = packetData,
                    destinationOffset = 0,
                    startIndex = i * PACKET_DATA_LENGTH,
                    endIndex = (i + 1) * PACKET_DATA_LENGTH
                )
            }
            val otaFirmwarePacket = OtaFirmwarePacket()
            otaFirmwarePacket.pack(i, packetData)
            iOtaFirmwarePacketPack.onPackSuccess(
                i,
                otaFirmwarePacket.packetData,
                packetFwDataLength
            )
        }
        iOtaFirmwarePacketPack.onPackEnd(loopNumber - 1)
    }

    interface IOtaFirmwarePacketPack {
        fun onPackSuccess(i: Int, buf: ByteArray?, packetFwDataLength: Int)

        fun onPackEnd(i: Int)
    }
}