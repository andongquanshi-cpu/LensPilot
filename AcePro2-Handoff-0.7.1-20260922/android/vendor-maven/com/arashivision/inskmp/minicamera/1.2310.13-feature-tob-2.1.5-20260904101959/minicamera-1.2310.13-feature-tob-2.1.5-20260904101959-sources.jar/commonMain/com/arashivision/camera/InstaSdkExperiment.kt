package com.arashivision.camera

/**
 * 业务传递的实验值
 */
object InstaSdkExperiment {
    var bleHeartDelayExperiment: Long = 0L

    var isHitFixLibOneCrashExperiment: Boolean? = false
}
