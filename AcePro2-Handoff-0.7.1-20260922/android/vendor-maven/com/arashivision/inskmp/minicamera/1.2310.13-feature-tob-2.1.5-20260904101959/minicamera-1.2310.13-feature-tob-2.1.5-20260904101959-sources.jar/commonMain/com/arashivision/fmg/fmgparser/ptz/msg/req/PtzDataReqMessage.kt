package com.arashivision.fmg.fmgparser.ptz.msg.req

abstract class PtzDataReqMessage {
    abstract fun packData(): ByteArray?

    abstract override fun toString(): String

    abstract fun name(): String
}
