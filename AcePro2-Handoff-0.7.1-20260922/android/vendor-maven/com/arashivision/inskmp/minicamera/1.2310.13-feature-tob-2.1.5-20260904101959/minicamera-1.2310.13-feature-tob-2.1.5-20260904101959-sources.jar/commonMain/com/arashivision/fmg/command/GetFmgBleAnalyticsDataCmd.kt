package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * 获取 FMG 蓝牙应用的埋点信息，与 FMG 主板埋点信息区分开来{@link GetFmgAnalyticsDataCmd}
 */
class GetFmgBleAnalyticsDataCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzGetBleAnalyticsData()
    }
}
