package com.arashivision.onedriver.encrypt

import insta360.messages.EncryptScheme
import kotlinx.atomicfu.atomic

class EncryptionManager(
    val scheme: EncryptScheme,
    private val sessionKey: ByteArray,
    private val sessionId: ByteArray = ByteArray(4),
) {
    private val counter = atomic(0L)

    @Suppress("UNUSED_PARAMETER")
    @OptIn(ExperimentalStdlibApi::class)
    fun encrypt(payload: ByteArray, aad: ByteArray, messageId: Long): EncryptResult {
        return when (scheme) {
            EncryptScheme.ENCRYPT_SCHEME_XOR -> {
                val ciphertext = xorCrypt(payload.copyOf(), XOR_KEY)
                EncryptResult(ciphertext, null, null)
            }
            EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128 -> {
                val nonce = buildNonce()
                val result = PlatformCrypto.aesGcmEncrypt(sessionKey, nonce, aad, payload)
                com.arashivision.common.Log.d(
                    "EncryptionManager",
                    "encrypt[GCM] keyHex=${sessionKey.toHexString(HexFormat.UpperCase)} " +
                        "nonceHex=${nonce.toHexString(HexFormat.UpperCase)} " +
                        "aadHex=${aad.toHexString(HexFormat.UpperCase)} " +
                        "ptLen=${payload.size} " +
                        "ptHead=${payload.copyOf(minOf(16, payload.size)).toHexString(HexFormat.UpperCase)} " +
                        "ctHead=${result.ciphertext.copyOf(minOf(16, result.ciphertext.size)).toHexString(HexFormat.UpperCase)} " +
                        "tagHex=${result.authTag.toHexString(HexFormat.UpperCase)}"
                )
                EncryptResult(result.ciphertext, nonce, result.authTag)
            }
            else -> EncryptResult(payload, null, null)
        }
    }

    fun decrypt(ciphertext: ByteArray, aad: ByteArray, nonce: ByteArray?, authTag: ByteArray?): ByteArray {
        return when (scheme) {
            EncryptScheme.ENCRYPT_SCHEME_XOR -> xorCrypt(ciphertext.copyOf(), XOR_KEY)
            EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128 -> {
                if (nonce == null || authTag == null) return ciphertext
                PlatformCrypto.aesGcmDecrypt(sessionKey, nonce, aad, ciphertext, authTag)
            }
            else -> ciphertext
        }
    }

    // Nonce: EncryptDevType(2B, 小端) + SessionId(4B) + Counter(6B, 小端)
    // EncryptDevType: 相机=0x0000, APP=0x0001, Apple Watch=0x0002
    private fun buildNonce(): ByteArray {
        val nonce = ByteArray(12)
        nonce[0] = 0x01
        nonce[1] = 0x00
        sessionId.copyInto(nonce, 2)
        val cnt = counter.getAndIncrement()
        nonce[6] = (cnt and 0xFF).toByte()
        nonce[7] = ((cnt shr 8) and 0xFF).toByte()
        nonce[8] = ((cnt shr 16) and 0xFF).toByte()
        nonce[9] = ((cnt shr 24) and 0xFF).toByte()
        nonce[10] = ((cnt shr 32) and 0xFF).toByte()
        nonce[11] = ((cnt shr 40) and 0xFF).toByte()
        return nonce
    }

    companion object {
        private val XOR_KEY = byteArrayOf(
            0x55, 0x43, 0x44, 0x32, 0x2D, 0x58, 0x4F, 0x52,
            0x2D, 0x4B, 0x45, 0x59, 0x2D, 0x30, 0x30, 0x31
        )

        fun xorCrypt(data: ByteArray, key: ByteArray): ByteArray {
            for (i in data.indices) {
                data[i] = (data[i].toInt() xor key[i % key.size].toInt()).toByte()
            }
            return data
        }

        fun createForXor(): EncryptionManager {
            return EncryptionManager(EncryptScheme.ENCRYPT_SCHEME_XOR, XOR_KEY)
        }

        fun createForAesGcm(sessionKey: ByteArray, sessionId: ByteArray): EncryptionManager {
            require(sessionId.size == 4) { "sessionId must be 4 bytes" }
            return EncryptionManager(EncryptScheme.ENCRYPT_SCHEME_AES_GCM_128, sessionKey, sessionId)
        }
    }
}

data class EncryptResult(
    val ciphertext: ByteArray,
    val nonce: ByteArray?,
    val authTag: ByteArray?,
)