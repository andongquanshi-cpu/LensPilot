package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzAiTrackerSettingsReadRespMsg : PtzDataRespMessage() {
    private val DATA_LENGTH = 3
    var standby_mem_flag: Short = 0
    var auto_standby_time: Short = 0
    var one_plam_shoot: Short = 0

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < DATA_LENGTH) {
            return
        }
        standby_mem_flag = FmgByteUtils.byteToShort(data[0])
        auto_standby_time = FmgByteUtils.byteToShort(data[1])
        one_plam_shoot = FmgByteUtils.byteToShort(data[2])
    }

    override fun toString(): String {
        return "PtzAiTrackerSettingsReadRespMsg{" +
                "standby_mem_flag=" + standby_mem_flag +
                ", auto_standby_time=" + auto_standby_time +
                ", one_plam_shoot=" + one_plam_shoot +
                '}'
    }

    override fun name(): String {
        return "CMD_AI_TRACKER_SETTING_READ"
    }
}
