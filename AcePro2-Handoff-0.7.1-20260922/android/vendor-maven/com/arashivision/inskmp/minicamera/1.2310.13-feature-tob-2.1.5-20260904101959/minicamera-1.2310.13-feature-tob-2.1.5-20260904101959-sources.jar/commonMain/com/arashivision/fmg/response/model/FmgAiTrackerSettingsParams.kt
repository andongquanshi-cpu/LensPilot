package com.arashivision.fmg.response.model

import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode

class FmgAiTrackerSettingsParams {
    var standbyMode: PtzAiTrackerStandbyMode? = null // AI追踪模块随开随关标志，0：随开随关，1：低功耗记忆，固件初始值为0
    var autoStandbyTime: PtzAiTrackerAutoStandbyTime? = null // AI追踪模块自动休眠时间，单位分钟，固件初始值为5
    var onePlamShoot: PtzAiTrackerOnePlamShoot? = null // AI追踪模块一步开拍配置，0：关闭一步开拍，1：打开一步开拍，固件初始值为0

    override fun toString(): String {
        return "FmgAiTrackerSettingsParams{" +
                "standbyMode=" + standbyMode +
                ", autoStandbyTime=" + autoStandbyTime +
                ", onePlamShoot=" + onePlamShoot +
                '}'
    }
}
