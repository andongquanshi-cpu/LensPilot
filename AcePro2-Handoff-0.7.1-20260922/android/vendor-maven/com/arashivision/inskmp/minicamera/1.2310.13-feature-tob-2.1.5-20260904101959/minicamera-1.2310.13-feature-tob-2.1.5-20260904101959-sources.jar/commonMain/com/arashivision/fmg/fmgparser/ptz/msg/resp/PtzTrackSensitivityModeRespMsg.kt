package com.arashivision.fmg.fmgparser.ptz.msg.resp


class PtzTrackSensitivityModeRespMsg : PtzDataRespMessage() {
    var mode: Short = 0

    override fun unpack(data: ByteArray?) {
        mode = data?.get(0)?.toShort() ?: 0
    }

    override fun toString(): String {
        return "mode: $mode"
    }

    override fun name(): String {
        return "CMD_ETS"
    }
}
