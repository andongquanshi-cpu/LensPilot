package com.arashivision.fmg.fmgparser.ptz.msg.req

class PtzSetPanoIndexReqMsg(
//uint8_t
    private val index: Short
) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(1)
        data[0] = index.toByte()
        return data
    }

    override fun toString(): String {
        return "index: $index"
    }

    override fun name(): String {
        return "CMD_PANO_INDEX"
    }
}
