package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CardLocation
import insta360.messages.GetFileInfoList

class GetFileInfoListCmd(
    private val cardLocation: CardLocation = CardLocation.STOR_CL_CAMERA
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        val getFileInfoList = GetFileInfoList(cardLocation)
        return oneDrvier?.getFileInfoList(getFileInfoList)
    }
}
