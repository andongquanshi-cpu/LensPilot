package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SendOpenCameraClassicBluetoothCmd(
    /**
     *  0:广播扫描；1：直连
     */
    private val connectType: Int
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.sendOpenCameraClassicBluetooth(connectType)
    }
}
