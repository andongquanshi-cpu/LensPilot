package com.arashivision.fmg.response

class FmgGetRunControlResp(var requestID: Long) {
    var yaw: Float = 0f
    var patch: Float = 0f
    var roll: Float = 0f

    override fun toString(): String {
        return "FmgGetRunControlResp{" +
                "requestID=" + requestID +
                ", yaw=" + yaw +
                ", patch=" + patch +
                ", roll=" + roll +
                '}'
    }
}
