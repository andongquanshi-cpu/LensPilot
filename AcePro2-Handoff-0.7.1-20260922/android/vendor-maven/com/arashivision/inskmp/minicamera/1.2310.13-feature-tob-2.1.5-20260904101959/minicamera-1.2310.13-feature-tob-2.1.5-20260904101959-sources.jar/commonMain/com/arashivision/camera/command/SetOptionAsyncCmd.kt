package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.onecamera.OneDriver
import insta360.messages.OptionType
import insta360.messages.Options

class SetOptionAsyncCmd(

    private val optionList: List<OptionType>,
    private val mOptions: Options,
    private val mRequestOptions: RequestOptions,
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setOptionsAsync(optionList, mOptions, mRequestOptions)
    }
}
