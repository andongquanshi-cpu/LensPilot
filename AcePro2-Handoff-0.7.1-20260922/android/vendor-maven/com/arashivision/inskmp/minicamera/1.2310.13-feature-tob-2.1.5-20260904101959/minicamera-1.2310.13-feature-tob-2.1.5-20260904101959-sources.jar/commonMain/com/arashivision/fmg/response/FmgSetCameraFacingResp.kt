package com.arashivision.fmg.response

class FmgSetCameraFacingResp(var requestID: Long)
