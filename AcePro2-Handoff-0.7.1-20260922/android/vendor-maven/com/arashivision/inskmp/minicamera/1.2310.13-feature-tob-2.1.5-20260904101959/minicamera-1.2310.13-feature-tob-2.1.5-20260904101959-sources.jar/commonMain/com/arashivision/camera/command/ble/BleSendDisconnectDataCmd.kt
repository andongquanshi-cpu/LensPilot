package com.arashivision.camera.command.ble

import com.arashivision.common.Log
import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * Go2桃心芯片用，disconnect蓝牙前发送断开指令
 */
class BleSendDisconnectDataCmd : InstaCmdExe {
    private val disconnectData = byteArrayOf(
        0xff.toByte(),
        0x0c.toByte(),
        0x01.toByte(),
        0x01.toByte(),
        0x00.toByte(),
        0x00.toByte(),
        0xcc.toByte()
    )

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any {
        if (oneDrvier != null) {
            Log.d(TAG, "send disconnect data")
            oneDrvier.writeRawData(disconnectData)
        }
        return 0
    }

    companion object {
        private val TAG: String = BleSendDisconnectDataCmd::class.simpleName.toString()
    }
}
