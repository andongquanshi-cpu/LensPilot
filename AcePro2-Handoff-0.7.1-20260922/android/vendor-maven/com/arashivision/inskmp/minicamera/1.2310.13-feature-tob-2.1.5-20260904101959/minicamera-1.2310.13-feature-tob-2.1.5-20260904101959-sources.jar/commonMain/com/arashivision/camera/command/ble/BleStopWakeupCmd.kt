package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.callback.BleStopWakeupCallbackCore
import com.arashivision.onecamera.OneDriver

class BleStopWakeupCmd(private val mBleStopWakeupCallback: BleStopWakeupCallbackCore?) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        stopWakeup()
        return null
    }

    private fun stopWakeup() {
        BleManagerCore.stopWakeupAdvertise(mBleStopWakeupCallback)
    }
}
