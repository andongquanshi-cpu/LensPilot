package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.onecamera.OneDriver

class SetAiTrackerOnePlamShootCmd(private val onePlamShoot: PtzAiTrackerOnePlamShoot) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzAiTrackerOnePlamShoot(onePlamShoot)
    }
}
