package com.arashivision.fmg.fmgparser.ota

import com.arashivision.fmg.fmgparser.FmgByteUtils
import kotlin.experimental.inv

class OtaCmdPacket {
    private var mCmd_L: Byte = 0x00
    private var mCmd_H: Byte = 0x00
    private var mIndex_L: Byte = 0x00
    private var mIndex_H: Byte = 0x00
    private var mCrc_L: Byte = 0x00
    private var mCrc_H: Byte = 0x00
    private var isCrc = false
    private var isIndex = false

    fun setCmdData(cmd_L: Byte, cmd_H: Byte) {
        this.mCmd_L = cmd_L
        this.mCmd_H = cmd_H
    }

    fun setIndex(index: Int) {
        val indexBytes = FmgByteUtils.intToUint16ByteArray(index)
        mIndex_L = indexBytes[0]
        mIndex_H = indexBytes[1]
        isIndex = true
    }

    fun setCrc() {
        val crcData = ByteArray(6)
        crcData[0] = mCmd_L
        crcData[1] = mCmd_H
        crcData[2] = mIndex_L
        crcData[3] = mIndex_H
        crcData[4] = mIndex_L.inv() as Byte
        crcData[5] = mIndex_H.inv() as Byte
        val crc = FmgByteUtils.otaCrc16(crcData)
        mCrc_L = crc[0]
        mCrc_H = crc[1]
        isCrc = true
    }

    val packetData: ByteArray
        get() {
            val data = ByteArray(20)

            data[0] = mCmd_L
            data[1] = mCmd_H

            if (isIndex) {
                data[2] = mIndex_L
                data[3] = mIndex_H
                data[4] = mIndex_L.inv() as Byte
                data[5] = mIndex_H.inv() as Byte
            }
            if (isCrc) {
                data[6] = mCrc_L
                data[7] = mCrc_H
            }
            return data
        }
}
