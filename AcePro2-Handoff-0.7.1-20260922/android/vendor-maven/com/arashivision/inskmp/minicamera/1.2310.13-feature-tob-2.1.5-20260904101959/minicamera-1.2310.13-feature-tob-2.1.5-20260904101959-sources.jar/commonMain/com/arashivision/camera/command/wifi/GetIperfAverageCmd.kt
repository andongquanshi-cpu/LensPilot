package com.arashivision.camera.command.wifi

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

class GetIperfAverageCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.iperfAverage
    }
}
