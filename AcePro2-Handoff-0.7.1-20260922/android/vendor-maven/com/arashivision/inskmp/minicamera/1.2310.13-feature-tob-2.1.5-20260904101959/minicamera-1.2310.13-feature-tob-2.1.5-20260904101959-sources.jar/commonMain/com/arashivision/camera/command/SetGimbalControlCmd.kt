package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GimbalControl

class SetGimbalControlCmd(private val gimbalControl: GimbalControl) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setGimbalControlCmd(gimbalControl)
    }
}
