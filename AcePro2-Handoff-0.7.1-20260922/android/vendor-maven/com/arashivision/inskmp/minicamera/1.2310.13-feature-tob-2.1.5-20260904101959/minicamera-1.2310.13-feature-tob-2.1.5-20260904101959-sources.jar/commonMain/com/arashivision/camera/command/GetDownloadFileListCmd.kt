package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GetFileList

class GetDownloadFileListCmd(private val mFileList: GetFileList) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getDownloadFileList(mFileList)
    }
}
