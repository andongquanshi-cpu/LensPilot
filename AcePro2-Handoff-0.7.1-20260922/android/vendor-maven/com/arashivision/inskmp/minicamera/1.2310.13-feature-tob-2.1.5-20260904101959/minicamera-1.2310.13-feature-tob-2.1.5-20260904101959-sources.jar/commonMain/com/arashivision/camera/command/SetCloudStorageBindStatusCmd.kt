package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CloudStorageBindParams

class SetCloudStorageBindStatusCmd(private val params: CloudStorageBindParams) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setCloudStorageBindStatus(params)
    }
}
