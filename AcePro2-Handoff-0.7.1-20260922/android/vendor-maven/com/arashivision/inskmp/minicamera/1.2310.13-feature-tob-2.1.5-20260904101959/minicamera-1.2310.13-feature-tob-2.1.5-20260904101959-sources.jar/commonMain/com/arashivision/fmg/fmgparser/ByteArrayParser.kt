package com.arashivision.fmg.fmgparser

import com.arashivision.common.Log

class ByteArrayParser(private val data: ByteArray, var currentPosition: Int) {
    fun parseByte(): Byte {
        if (this.currentPosition < 0 || this.currentPosition >= data.size) {
            Log.e(TAG, "parseByte: position error: " + this.currentPosition)
            return 0
        }
        val result = data[this.currentPosition]
        this.currentPosition++
        return result
    }

    fun parseByteArray(length: Int): ByteArray {
        if (this.currentPosition < 0 || this.currentPosition >= data.size) {
            Log.e(TAG, "parseByte: position error: " + this.currentPosition)
            return ByteArray(length)
        }
        if (this.currentPosition + length > data.size) {
            Log.e(TAG, "parseByteArray: length error: length: " + length + ", position: " + this.currentPosition)
            return ByteArray(length)
        }
        val result = ByteArray(length)
        data.copyInto(result, 0, this.currentPosition, this.currentPosition + length)
        this.currentPosition += length
        return result
    }

    val reamingLength: Int
        /**
         * 获取余下的数据字节长度
         * @return 剩余长度
         */
        get() {
            if (this.currentPosition < 0) {
                return 0
            }
            return data.size - this.currentPosition
        }

    companion object {
        private val TAG = "ByteArrayParser"
    }
}