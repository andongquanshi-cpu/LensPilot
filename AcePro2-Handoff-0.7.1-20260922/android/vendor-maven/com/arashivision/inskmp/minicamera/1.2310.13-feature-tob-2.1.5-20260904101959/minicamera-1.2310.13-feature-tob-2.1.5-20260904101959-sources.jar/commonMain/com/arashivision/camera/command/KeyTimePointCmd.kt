package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.SetKeyTimePoint

/**
 * 录像过程中告诉相机
 */
class KeyTimePointCmd(private val mKeyTimePoint: SetKeyTimePoint) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setKeyTimePoint(mKeyTimePoint)
    }
}
