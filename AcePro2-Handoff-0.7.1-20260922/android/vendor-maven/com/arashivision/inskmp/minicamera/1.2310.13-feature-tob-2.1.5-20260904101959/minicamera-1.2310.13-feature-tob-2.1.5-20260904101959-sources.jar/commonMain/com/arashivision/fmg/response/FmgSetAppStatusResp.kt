package com.arashivision.fmg.response

class FmgSetAppStatusResp(var requestID: Long)
