package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class ScriptJsonUploadCmd(private val jsonBytes: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.uploadScriptJson(jsonBytes)
    }
}
