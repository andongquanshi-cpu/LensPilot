package com.arashivision.common

expect class File(path: String, fileName: String? = null) {
    fun exists(): Boolean
    fun length(): Long
    fun read(): ByteArray?

    fun getName(): String
    fun getFileMD5String(): String

    fun getParent(): String?

    fun getAbsolutePath(): String

    fun renameTo(dstPath: String): Boolean
    fun fullDelete(): Boolean
    fun mkdirs(): Boolean

    fun isFile(): Boolean

    fun listFiles(): List<File>?
    fun readBytesFromFile(): ByteArray
    fun delete(): Boolean
}
