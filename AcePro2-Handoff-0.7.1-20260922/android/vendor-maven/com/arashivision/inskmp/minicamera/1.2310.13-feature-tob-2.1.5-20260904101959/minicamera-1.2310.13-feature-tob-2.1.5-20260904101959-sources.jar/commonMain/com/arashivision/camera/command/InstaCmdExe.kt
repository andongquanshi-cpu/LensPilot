package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 连接相机的一些指令
 */
interface InstaCmdExe {
    suspend fun exeCmd(oneDrvier: OneDriver?): Any?
}
