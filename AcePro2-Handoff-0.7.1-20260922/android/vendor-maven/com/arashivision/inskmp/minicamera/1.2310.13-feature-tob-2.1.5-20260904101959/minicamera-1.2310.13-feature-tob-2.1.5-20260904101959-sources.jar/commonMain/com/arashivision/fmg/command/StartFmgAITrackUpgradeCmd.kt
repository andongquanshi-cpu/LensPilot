package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.onecamera.OneDriver

class StartFmgAITrackUpgradeCmd(private val mAiTrackUpgradeConfig: AITrackUpgradeConfig) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.startFmgAITrackUpgrade(mAiTrackUpgradeConfig)
    }
}
