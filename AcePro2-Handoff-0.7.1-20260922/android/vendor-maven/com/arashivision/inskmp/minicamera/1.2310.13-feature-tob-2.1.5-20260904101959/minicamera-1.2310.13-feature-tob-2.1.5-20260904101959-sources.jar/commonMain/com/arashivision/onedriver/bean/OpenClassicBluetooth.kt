package com.arashivision.onedriver.bean

data class OpenClassicBluetooth (
    val sessionId: Long,
    val connectType: Int,
    val btMac: String,
    val result: Int
)