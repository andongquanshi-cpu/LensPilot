package com.arashivision.fmg.response.model

class FmgTargetFollowParams {
    // 中心为0，0，向右向下是正方向
    var posX: Int = 0 // x轴方向坐标，归一化到-32768到32767
    var posY: Int = 0 // y轴方向坐标，归一化到-32768到32767
    var scale: Float = 0f // 缩放系数，倍率范围为0.1~25.5
    var width: Int = 0 // 目标在图像中的宽度，以255归一化
    var height: Int = 0 // 目标在图像中的高度，以255归一化
    var followType: FollowType? = null //追踪类型
    var isFront: Boolean = false // ture:前摄，false:后摄
    var composition: Boolean = false

    enum class FollowType(val nativeValue: Byte) {
        COMMON(1.toByte()),  //通用
        FACE(2.toByte()),  //人脸
        BODY(3.toByte()),  //人体
        HAND(4.toByte()),  //头肩
        BASKET(10.toByte()),  //篮筐
        BASEKTBALL(11.toByte()),
        ; //篮球

        fun nativeValueOf(nativeValue: Byte): FollowType? {
            for (type in values()) {
                if (type.nativeValue == nativeValue) {
                    return type
                }
            }
            return null
        }
    }
}
