package com.arashivision.camera

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

class StopTimeshiftCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return null
    }
}
