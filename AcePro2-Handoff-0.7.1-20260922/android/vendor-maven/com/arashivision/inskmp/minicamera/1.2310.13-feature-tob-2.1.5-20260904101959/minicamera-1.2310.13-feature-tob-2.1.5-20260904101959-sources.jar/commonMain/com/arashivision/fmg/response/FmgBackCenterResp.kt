package com.arashivision.fmg.response

class FmgBackCenterResp(var requestID: Long)
