package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzUpdateInfoReqMsg(updateInfo: ByteArray) : PtzDataReqMessage() {
    var type: Short = 0 //uint8_t
        private set
    var fireware_version: Short = 0 //uint8_t
        private set
    var hardware_version: Short = 0 //uint8_t
        private set
    var reserved: Short = 0 //uint8_t
        private set
    var size_of_image: Long = 0 //uint32_t
        private set
    var crc32_of_image: Long = 0 //uint32_t
        private set
    var checksum_of_image: Long = 0 //uint32_t
        private set
    private val data = ByteArray(UPDATE_INFO_DATA_SIZE)

    init { //传入固件的最后16个字节
        if (updateInfo.size != UPDATE_INFO_DATA_SIZE) {
            Log.d("PtzMsgError", "updateInfoBytes length is not " + UPDATE_INFO_DATA_SIZE)
        } else {
            updateInfo.copyInto(data, 0, 0, updateInfo.size)

            type = FmgByteUtils.byteToShort(updateInfo[0])
            fireware_version = FmgByteUtils.byteToShort(updateInfo[1])
            hardware_version = FmgByteUtils.byteToShort(updateInfo[2])
            reserved = FmgByteUtils.byteToShort(updateInfo[3])
            size_of_image = FmgByteUtils.uint32BytesToLong(
                updateInfo[4],
                updateInfo[5], updateInfo[6], updateInfo[7]
            )
            crc32_of_image = FmgByteUtils.uint32BytesToLong(
                updateInfo[8],
                updateInfo[9], updateInfo[10], updateInfo[11]
            )
            checksum_of_image = FmgByteUtils.uint32BytesToLong(
                updateInfo[12],
                updateInfo[13], updateInfo[14], updateInfo[15]
            )
        }
    }

    override fun packData(): ByteArray? {
        return data
    }

    override fun toString(): String {
        return "null"
    }

    override fun name(): String {
        return "CMD_UPDATE_INFO_REQ"
    }

    companion object {
        const val UPDATE_INFO_DATA_SIZE: Int = 16
    }
}
