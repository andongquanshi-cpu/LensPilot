package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class CheckVideoCmd(private val videoResolution: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Boolean? {
        return oneDrvier?.checkVideo(videoResolution)
    }
}
