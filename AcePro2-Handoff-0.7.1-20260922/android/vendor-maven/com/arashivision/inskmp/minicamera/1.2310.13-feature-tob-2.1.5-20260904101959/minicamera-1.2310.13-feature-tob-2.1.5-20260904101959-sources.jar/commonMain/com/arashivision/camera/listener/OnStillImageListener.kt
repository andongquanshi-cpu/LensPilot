package com.arashivision.camera.listener

import insta360.messages.TakePictureResponse

/**
 * 拍照之后的回调
 */
interface OnStillImageListener {
    fun onDriverStillImageNotify(errorCode: Int, mResponse: TakePictureResponse?)

    fun onDriverStillImageWithoutStorageNotify(error: Int, datas: ByteArray?)
}