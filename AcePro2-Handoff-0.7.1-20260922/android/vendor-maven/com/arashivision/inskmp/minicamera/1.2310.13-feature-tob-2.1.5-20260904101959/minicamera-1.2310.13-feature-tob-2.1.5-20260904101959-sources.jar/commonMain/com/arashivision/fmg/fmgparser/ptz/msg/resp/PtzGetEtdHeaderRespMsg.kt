package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetEtdHeaderRespMsg : PtzDataRespMessage() {
    var power_on_cnt: Int = 0 //开机总次数(不可清零)
    var fast_power_on_cnt: Int = 0 //快速开机次数(不可清零)
    var fast_power_on_etd_length: Int = 0 //快速开机事件项数组的长度
    var key_power_on_cnt: Int = 0 //按键开机次数(不可清零)
    var key_power_on_etd_length: Int = 0 //按键开机事件项数组的长度
    var power_off_cnt: Int = 0 //关机总次数(不可清零)
    var fast_power_off_cnt: Int = 0 //快速关机次数(不可清零)
    var fast_power_off_etd_length: Int = 0 //快速关机事件项数组的长度
    var key_power_off_cnt: Int = 0 //按键关机次数(不可清零)
    var key_power_off_etd_length: Int = 0 //按键关机事件项数组的长度
    var force_power_off_cnt: Int = 0 //强制关机的总次数(不可清零)
    var force_power_off_etd_length: Int = 0 //强制关机事件项数组的长度
    var err_etd_length: Int = 0 //出错的事件项数组的长度
    var cf_etd_length: Int = 0 //侧翻事件项数组的长度
    var yaw_360_length: Int = 0 //Yaw轴360°转动事件项的长度
    var reserved: IntArray = IntArray(9)

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 26) {
            Log.d("unpack", "PtzGetEtdHeaderRespMsg data error!!!!")
            return
        }
        power_on_cnt = FmgByteUtils.uint16BytesToInt(data[0], data[1])
        fast_power_on_cnt = FmgByteUtils.uint16BytesToInt(data[2], data[3])
        fast_power_on_etd_length = FmgByteUtils.uint16BytesToInt(data[4], data[5])
        key_power_on_cnt = FmgByteUtils.uint16BytesToInt(data[6], data[7])
        key_power_on_etd_length = FmgByteUtils.uint16BytesToInt(data[8], data[9])
        power_off_cnt = FmgByteUtils.uint16BytesToInt(data[10], data[11])
        fast_power_off_cnt = FmgByteUtils.uint16BytesToInt(data[12], data[13])
        fast_power_off_etd_length = FmgByteUtils.uint16BytesToInt(data[14], data[15])
        key_power_off_cnt = FmgByteUtils.uint16BytesToInt(data[16], data[17])
        key_power_off_etd_length = FmgByteUtils.uint16BytesToInt(data[18], data[19])
        force_power_off_cnt = FmgByteUtils.uint16BytesToInt(data[20], data[21])
        force_power_off_etd_length = FmgByteUtils.uint16BytesToInt(data[22], data[23])
        err_etd_length = FmgByteUtils.uint16BytesToInt(data[24], data[25])
        cf_etd_length = if (data.size >= 28) {
            FmgByteUtils.uint16BytesToInt(data[26], data[27])
        } else {
            0
        }
        yaw_360_length = if (data.size >= 30) {
            FmgByteUtils.uint16BytesToInt(data[28], data[29])
        } else {
            0
        }
    }

    override fun toString(): String {
        return "PtzGetEtdHeaderRespMsg{" +
                "power_on_cnt=" + power_on_cnt +
                ", fast_power_on_cnt=" + fast_power_on_cnt +
                ", fast_power_on_etd_length=" + fast_power_on_etd_length +
                ", key_power_on_cnt=" + key_power_on_cnt +
                ", key_power_on_etd_length=" + key_power_on_etd_length +
                ", power_off_cnt=" + power_off_cnt +
                ", fast_power_off_cnt=" + fast_power_off_cnt +
                ", fast_power_off_etd_length=" + fast_power_off_etd_length +
                ", key_power_off_cnt=" + key_power_off_cnt +
                ", key_power_off_etd_length=" + key_power_off_etd_length +
                ", force_power_off_cnt=" + force_power_off_cnt +
                ", force_power_off_etd_length=" + force_power_off_etd_length +
                ", err_etd_length=" + err_etd_length +
                ", cf_etd_length=" + cf_etd_length +
                ", yaw_360_length=" + yaw_360_length +
                '}'
    }

    override fun name(): String {
        return "CMD_GET_ETD - ETD_ITEM_HEADER"
    }
}
