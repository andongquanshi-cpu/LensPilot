package com.arashivision.fmg.response.model

class FmgSetAngleSeqBean(roll: Float, pitch: Float, yaw: Float, time: Int) {
    var roll: Int = roll.toInt() * 10
    var pitch: Int = pitch.toInt() * 10
    var yaw: Int = yaw.toInt() * 10
    var time: Int = time / 100 //为到达该点的单次运动时间
}
