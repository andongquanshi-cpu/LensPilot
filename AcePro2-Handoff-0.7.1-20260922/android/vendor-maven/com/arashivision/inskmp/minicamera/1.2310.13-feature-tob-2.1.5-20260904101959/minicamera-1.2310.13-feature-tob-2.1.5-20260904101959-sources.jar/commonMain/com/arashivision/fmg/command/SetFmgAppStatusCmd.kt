package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

class SetFmgAppStatusCmd(private val recording: Short, private val touch: Short) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetAppStatus(recording, touch)
    }
}
