package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetGpsCmd(private val mGpsData: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setGPSData(mGpsData)
    }
}
