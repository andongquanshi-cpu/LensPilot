package com.arashivision.onedriver.packet

import com.arashivision.common.Log

/**
 * PacketDemuxer 测试工具类
 * 用于测试将十六进制字符串转换为字节数组并解析数据包
 */
@OptIn(ExperimentalStdlibApi::class)
object PacketDemuxerTest {
    private const val TAG = "PacketDemuxerTest"

    /**
     * 将十六进制字符串转换为字节数组
     * 支持空格分隔或连续格式（无空格），例如：
     * - 有空格: "01 02 03 FF"
     * - 无空格: "010203FF" (推荐，更简洁)
     * - 混合格式: "01 02 03FF" (会自动处理)
     */
    fun hexStringToByteArray(hexString: String): ByteArray {
        // 移除所有空白字符（空格、换行符、制表符等），支持无空格格式
        val cleanHex = hexString.replace(Regex("\\s+"), "")
        
        // 验证是否为有效的十六进制字符串
        require(cleanHex.matches(Regex("[0-9A-Fa-f]+"))) {
            "Invalid hex string: $hexString"
        }
        
        // 确保长度为偶数
        require(cleanHex.length % 2 == 0) {
            "Hex string length must be even: $hexString"
        }
        
        val byteArray = ByteArray(cleanHex.length / 2)
        for (i in byteArray.indices) {
            val startIndex = i * 2
            val endIndex = startIndex + 2
            val hexByte = cleanHex.substring(startIndex, endIndex)
            byteArray[i] = hexByte.toInt(16).toByte()
        }
        
        return byteArray
    }

    /**
     * 测试方法：将十六进制字符串解析为数据包列表
     * 
     * @param hexString 十六进制字符串，例如 "01 02 03 FF" 或 "010203FF"
     * @param description 测试描述，用于日志输出
     */
    fun testParseHexString(hexString: String, description: String = "Test") {
        Log.d(TAG, "========== $description ==========")
        Log.d(TAG, "Input hex string: $hexString")
        
        try {
            // 转换为字节数组
            val byteArray = hexStringToByteArray(hexString)
            Log.d(TAG, "Byte array length: ${byteArray.size}")
            Log.d(TAG, "Byte array hex: ${byteArray.toHexString()}")
            Log.d(TAG, "Byte array decimal: [${byteArray.joinToString(", ") { it.toString() }}]")
            
            // 创建 PacketDemuxer 实例
            val demuxer = PacketDemuxer()
            
            // 解析数据包列表
            val packets = demuxer.parseList(byteArray, byteArray.size)
            
            Log.d(TAG, "Parsed packets count: ${packets.size}")
            
            if (packets.isEmpty()) {
                Log.w(TAG, "No packets parsed from the data")
                Log.d(TAG, "Buffer has remaining data: ${demuxer.bufferHasData()}")
            } else {
                // 打印每个包的详细信息
                packets.forEachIndexed { index, packet ->
                    Log.d(TAG, "--- Packet ${index + 1} ---")
                    printPacketInfo(packet)
                }
            }
            
            // 检查缓冲区是否还有剩余数据
            if (demuxer.bufferHasData()) {
                Log.w(TAG, "Buffer still has remaining data after parsing")
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing hex string: ${e.message}")
            e.printStackTrace()
        }
        
        Log.d(TAG, "========== End $description ==========\n")
    }

    /**
     * 打印数据包的详细信息
     */
    private fun printPacketInfo(packet: Packet) {
        val packetType = packet.getPacketType()
        Log.d(TAG, "Packet Type: $packetType")
        Log.d(TAG, "Packet Length (with padding): ${packet.getPacketLengthBesidesPadding()}")
        Log.d(TAG, "Packet Length (without padding): ${packet.getPacketLengthWithoutPadding()}")
        Log.d(TAG, "Packet Padding Length: ${packet.getPacketPaddingLength()}")
        
        val rawBytes = packet.toBytes()
        Log.d(TAG, "Raw bytes hex: ${rawBytes.toHexString()}")
        
        when (packetType) {
            PacketType.Message -> {
                Log.d(TAG, "--- Message Packet Details ---")
                Log.d(TAG, "Message Method: ${packet.messageMethod}")
                Log.d(TAG, "Message Content Type: ${packet.messageContentType}")
                Log.d(TAG, "Message Direction: ${packet.messageDirection}")
                Log.d(TAG, "Message ID: ${packet.messageId}")
                Log.d(TAG, "Message End Flag: ${packet.messageEndFlag}")
                packet.messageContent?.let { content ->
                    Log.d(TAG, "Message Content Length: ${content.size}")
                    if (content.size > 0 && content.size <= 100) {
                        Log.d(TAG, "Message Content Hex: ${content.toHexString()}")
                    } else if (content.size > 100) {
                        Log.d(TAG, "Message Content Hex (first 100 bytes): ${content.take(100).toByteArray().toHexString()}...")
                    }
                }
            }
            
            PacketType.Stream -> {
                Log.d(TAG, "--- Stream Packet Details ---")
                Log.d(TAG, "Stream Type: ${packet.streamType}")
                Log.d(TAG, "Stream Timestamp: ${packet.streamTimestamp}")
                packet.streamData?.let { data ->
                    Log.d(TAG, "Stream Data Length: ${data.size}")
                    if (data.size > 0 && data.size <= 50) {
                        Log.d(TAG, "Stream Data Hex (first 50 bytes): ${data.take(50).toByteArray().toHexString()}")
                    }
                }
            }
            
            PacketType.LinuxCmd -> {
                Log.d(TAG, "--- Linux Command Packet Details ---")
                Log.d(TAG, "Linux Cmd: ${packet.linuxCmdCmd}")
                Log.d(TAG, "Linux Cmd Direction: ${packet.linuxCmdDirection}")
                Log.d(TAG, "Linux Cmd Content: ${packet.linuxCmdContent}")
            }
            
            PacketType.SocketTunnel -> {
                Log.d(TAG, "--- Socket Tunnel Packet Details ---")
                Log.d(TAG, "Tunnel Connection ID: ${packet.tunnelConnectionId}")
                Log.d(TAG, "Tunnel Flags: ${packet.tunnelFlags}")
                Log.d(TAG, "Tunnel Window Limit: ${packet.tunnelWindowLimit}")
                val tunnelContent = packet.tunnelContent
                Log.d(TAG, "Tunnel Content Length: ${tunnelContent.size}")
                if (tunnelContent.size > 0 && tunnelContent.size <= 50) {
                    Log.d(TAG, "Tunnel Content Hex (first 50 bytes): ${tunnelContent.take(50).toByteArray().toHexString()}")
                }
            }
            
            PacketType.HeartBeat -> {
                Log.d(TAG, "--- Heartbeat Packet ---")
            }
            
            PacketType.Synchronize -> {
                Log.d(TAG, "--- Synchronize Packet ---")
                val payload = packet.getPayload()
                Log.d(TAG, "Synchronize Payload Length: ${payload.size}")
                if (payload.size > 0 && payload.size <= 50) {
                    Log.d(TAG, "Synchronize Payload Hex: ${payload.toHexString()}")
                }
            }
            
            else -> {
                Log.d(TAG, "--- Other Packet Type ---")
                val payload = packet.getPayload()
                Log.d(TAG, "Payload Length: ${payload.size}")
                if (payload.size > 0 && payload.size <= 50) {
                    Log.d(TAG, "Payload Hex (first 50 bytes): ${payload.take(50).toByteArray().toHexString()}")
                }
            }
        }
    }

    /**
     * 便捷方法：测试多个十六进制字符串
     */
    fun testMultipleHexStrings(vararg hexStrings: Pair<String, String>) {
        hexStrings.forEach { (hexString, description) ->
            testParseHexString(hexString, description)
        }
    }
}

/**
 * 使用示例：
 * 
 * // 示例1: 测试单个十六进制字符串（无空格格式，推荐）
 * PacketDemuxerTest.testParseHexString("07000000010000", "Heartbeat Packet")
 * 
 * // 示例2: 测试消息包（无空格格式）
 * PacketDemuxerTest.testParseHexString(
 *     "1A0000000200003202010100000000000000000000000000000000",
 *     "Message Packet Test"
 * )
 * 
 * // 示例3: 也支持有空格格式（会自动处理）
 * PacketDemuxerTest.testParseHexString("07 00 00 00 01 00 00", "Heartbeat Packet")
 * 
 * // 示例4: 测试多个字符串（无空格格式）
 * PacketDemuxerTest.testMultipleHexStrings(
 *     "07000000010000" to "Heartbeat",
 *     "0A000000020000320201" to "Message"
 * )
 * 
 * // 示例5: 从错误日志中复制的十六进制字符串
 * // 如果日志输出有空格，可以手动移除空格，或直接使用（会自动处理）
 * PacketDemuxerTest.testParseHexString("00010203", "Error Case Test")
 * // 或者
 * PacketDemuxerTest.testParseHexString("00 01 02 03", "Error Case Test")
 */

