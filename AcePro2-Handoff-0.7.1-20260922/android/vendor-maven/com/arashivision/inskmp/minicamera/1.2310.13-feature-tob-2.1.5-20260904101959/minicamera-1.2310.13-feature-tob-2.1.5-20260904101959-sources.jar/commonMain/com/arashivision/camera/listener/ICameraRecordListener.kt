package com.arashivision.camera.listener

import insta360.messages.Video

/**
 * 录制视频的回调
 */
interface ICameraRecordListener {
    fun onDriverRecordVideoStateNotify(state: Int, error: Int, video: Video?)
}
