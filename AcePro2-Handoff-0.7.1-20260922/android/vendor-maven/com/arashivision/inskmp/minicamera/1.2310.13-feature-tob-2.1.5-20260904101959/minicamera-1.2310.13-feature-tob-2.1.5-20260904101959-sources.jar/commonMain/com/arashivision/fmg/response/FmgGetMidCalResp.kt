package com.arashivision.fmg.response

class FmgGetMidCalResp(var requestID: Long) {
    var euler: DoubleArray? = null

    override fun toString(): String {
        return "FmgGetMidCalResp{" +
                ", euler=" + euler.contentToString() +
                '}'
    }
}
