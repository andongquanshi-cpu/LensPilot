package com.arashivision.camera.listener

interface IFmgHandShakeListener {
    fun onHandShakeSuccess()

    fun onHandShakeError(error: Int)
}
