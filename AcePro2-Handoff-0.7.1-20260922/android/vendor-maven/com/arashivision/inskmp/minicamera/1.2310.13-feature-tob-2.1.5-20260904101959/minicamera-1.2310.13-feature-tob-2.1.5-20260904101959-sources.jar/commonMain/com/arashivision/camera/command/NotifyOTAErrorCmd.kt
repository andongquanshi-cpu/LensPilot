package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class NotifyOTAErrorCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDriver: OneDriver?): Any? {
        return oneDriver?.notifyOTAError()
    }
}
