package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetShowCloudTabCmd(private val showCloudTab: Boolean) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setShowCloudTab(showCloudTab)
    }
}
