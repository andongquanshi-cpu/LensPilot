package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.onecamera.OneDriver

class BasketballA2GCmd(
    private val mode: PtzBaksetballMode,
    private val state: PtzBaksetballState,
    private val transition: PtzBaksetballTransition
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzBasketballA2G(mode, state, transition)
    }
}
