package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.RecipeShareStatus

class RecipeShareStatusCmd(private val recipeShareStatus: RecipeShareStatus) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.recipeShareStatus(recipeShareStatus)
    }
}
