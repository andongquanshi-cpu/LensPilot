package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.PhotoSettingPage

class NotifySettingPageCmd(private val settingPageNotify: PhotoSettingPage) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.notifySettingPage(settingPageNotify)
    }
}
