package com.arashivision.camera.strategy

import com.arashivision.camera.RequestOptions
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IBleScanListener
import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.arashivision.onedriver.packet.StreamType
import insta360.messages.AiIntentCtrl
import insta360.messages.AssistantLanguageCtrl
import insta360.messages.AudioStreamCtrl
import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType
import insta360.messages.FeatureBluetoothMacBind
import insta360.messages.CalibrateGyro
import insta360.messages.CancelAngleFixed
import insta360.messages.CardLocation
import insta360.messages.CheckAuthorization
import insta360.messages.CloudStorageBindParams
import insta360.messages.CloudStorageUploadParams
import insta360.messages.ConnectToBTPeripheral
import insta360.messages.CtrlPreRecord
import insta360.messages.DataTransPort
import insta360.messages.DataTransPortDir
import insta360.messages.DataTransportResult
import insta360.messages.DeleteFiles
import insta360.messages.DisconnectBTPeripheral
import insta360.messages.DownLoadInfo
import insta360.messages.DownloadListResultSync
import insta360.messages.FormatStorage
import insta360.messages.GetConnectedBTPeripheral
import insta360.messages.GetFile
import insta360.messages.GetFileExtra
import insta360.messages.GetFileFinish
import insta360.messages.GetFileList
import insta360.messages.GetGyro
import insta360.messages.GetGyroResp
import insta360.messages.GetTimelapseOptions
import insta360.messages.GimbalControl
import insta360.messages.IntervalRecCancel
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecStartStop
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveOptionCtrlInfo
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.OpenTrackingWithRect
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation
import insta360.messages.RecipeShareStatus
import insta360.messages.ScanBTPeripheral
import insta360.messages.SetFavoriteList
import insta360.messages.SetFileExtra
import insta360.messages.SetKeyTimePoint
import insta360.messages.SetNetworkConfigEnable
import insta360.messages.SetPresetComposition
import insta360.messages.PhotoSettingPage
import insta360.messages.SetTimelapseOptions
import insta360.messages.SingleHostCmdInfo
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.TakePicture
import insta360.messages.TestSDCardSpeed
import insta360.messages.TimelapseOptions
import insta360.messages.UserRegionCtrl
import insta360.messages.WifiConnectionInfo

/**
 * 相机操作的公共接口
 */
interface IContentStaregyListener {
    fun syncCaptureStatus(): Long
    fun previewStream(startStreamingParam: StartLiveStream, offset: String)
    fun closePreviewStream()

    fun requestStreamIframe()

    fun stopUsbcardBackup(): Long

    fun getQuickReaderStatus(): Long

    fun takePicture(takePicture: TakePicture, withoutStorage: Boolean)

    fun stopTakePicture(): Long

    fun startRecord(
        recordOriginVideo: Boolean,
        livePush: Boolean,
        mode: Int,
    )

    fun stopRecord(mode: Int, extraData: ByteArray)

    fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long

    fun setOptionAsync(
        optionList: List<OptionType>,
        options: Options,
        requestOptions: RequestOptions,
    ): Long

    fun getPort(): Int

    fun calibrateGyro(gyro: CalibrateGyro): Long

    fun startTimeplapse(startTimelapse: StartTimelapse)

    fun eraseSdcard(): Long

    fun formatStorage(formatStorage: FormatStorage): Long

    fun setMainStorage(cardLocation: CardLocation): Long

    fun reboot(): Long

    fun notifyOTAError(): Long

    fun setAppId(appId: String): Long

    fun setShutdown(): Long

    fun cancelAngleFixed(cancelAngleFixed: CancelAngleFixed): Long

    fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long

    fun cancelTracking(): Long

    fun getPtzTrackState(): Long

    fun checkAuthorization(
        checkAuthorization: CheckAuthorization,
        requestOptions: RequestOptions,
    ): Long

    fun requestAuthorization(authorizationOperationType: Int): Long

    fun writeWifiProxyData(wifiProxyData: IWifiProxyData)

    fun getOptions(optionList: List<OptionType>): Options?

    fun getOptionsSync(optionList: List<OptionType>?, requestOptions: RequestOptions): Long

    fun negotiateEncryption(onComplete: (Boolean) -> Unit)

    fun getPhotoOptionsAsync(
        funcMode: Int,
        options: List<PhotographyOptionType>,
        requestOptions: RequestOptions,
    ): Long

    fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        opetions: List<ButtonPressParamsType>,
        requestOptions: RequestOptions,
    ): Long

    fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        buttonPressParams: ButtonPressParams,
        requestOptions: RequestOptions,
    ): Long

    fun getTimelapseOption(getTimelapseOptions: GetTimelapseOptions): TimelapseOptions?

    fun getTimelapseOptionAsync(
        getTimelapseOptions: GetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long

    fun getCameraLiveOptionsSync(
        optionList: List<LiveBroadCastOptionType>,
        requestOptions: RequestOptions,
    ): Long

    fun setCameraLiveOptionsAsync(
        optionList: List<LiveBroadCastOptionType>,
        options: LiveOptionCtrlInfo,
        requestOptions: RequestOptions,
    ): Long

    fun getFileInfoList(cardLocation: CardLocation = CardLocation.STOR_CL_CAMERA): Long

    fun getEditInfoList(): Long

    fun getTranslateConfig(timeoutMs: Int = -1): Long

    fun getFileList(fileList: GetFileList): Long

    fun getFileListIncludeRecording(fileList: GetFileList): Long

    fun getFile(getFile: GetFile): Long

    fun setFavoriteList(setFavoriteList: SetFavoriteList): Long
    fun packFile(getFile: GetFile): Long

    fun getFileFinish(getFileFinish: GetFileFinish): Long

    fun setTransferStatus(getFileFinish: GetFileFinish): Long

    fun startLedTest()

    fun startBleStatusTest()

    fun startWifiStatusTest()

    fun startSpeakerTest()

    fun delteFileList(obj: DeleteFiles): Long

    fun getGyro(getGyro: GetGyro): GetGyroResp?

    fun getGyroSync(getGyro: GetGyro): Long

    fun setFileExtra(setFileExtra: SetFileExtra): Long

    fun getFileExtra(getFileExtra: GetFileExtra): Long

    fun recipeShareStatus(recipeShareStatus: RecipeShareStatus): Long

    fun testButtonState()

    fun startTestTypeC()

    fun stopLCDTest()

    fun getCaptureStatus(requestOptions: RequestOptions): Long

    fun setSyncCaptureMode(mode: Int): Long

    fun getSyncCaptureMode(): Long

    fun pauseRecord(): Long

    fun setStandbyMode(mode: Int): Long

    fun getPhotoOptions(funcMode: Int, options: List<PhotographyOptionType>): PhotographyOptions?

    fun setTimelapseOptions(info: SetTimelapseOptions): Long

    fun setTimelapseOptionsASync(info: SetTimelapseOptions, requestOptions: RequestOptions): Long

    fun startBulletTime(): Long

    fun cancelAuthorization(requestOptions: RequestOptions): Long

    fun cancelRequestAuthorization(authorizationOperationType: Int): Long

    fun stopTimelapse(stopTimelapse: StopTimelapse)

    fun stopBulletTime(extraData: ByteArray)

    fun setPhotoOptions(
        funcMode: Int,
        optionList: List<PhotographyOptionType>,
        options: PhotographyOptions,
    ): Long

    fun scanBT(obj: ScanBTPeripheral): Long

    fun connectBT(obj: ConnectToBTPeripheral): Long

    fun disConnectBT(obj: DisconnectBTPeripheral): Long

    fun getConnectBT(obj: GetConnectedBTPeripheral): Long

    fun setGpsData(gpsData: ByteArray): Long

    fun setCameraWifiHeartDebug(debug: Boolean)

    fun setSyncStandByMode(mode: Int): Long

    fun setPhotoOptionSync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
        requestOptions: RequestOptions,
    ): Long

    fun startTimeShift(): Long

    fun stopTimeShift(extraData: ByteArray)

    fun setKeyTimePoint(keyTimePoint: SetKeyTimePoint): Long

    fun openCameraWifi(countryChannel: Int): Long

    fun closeCameraWifi(): Long

    fun resetCameraWifi(countryChannel: Int): Long

    fun setCameraWifiSeizeEnable(connectionState: Int): Long

    fun setAvailableWifi(wifiConnectionInfo: WifiConnectionInfo): Long

    fun setWifiConnectionInfo(wifiConnectionInfo: WifiConnectionInfo): Long

    fun getWifiConnectionInfo(): Long

    fun setWifiMode(wifiMode: Int, countryCode: String?): Long

    fun requestData(
        dir: DataTransPortDir,
        rxdatainfo: List<RequestReceiveDataInformation>?,
        txdatainfo: List<RequestSendDataInformation>?,
    ): Long

    fun dataTransportFeedback(dataTransportResult: DataTransportResult): Long

    fun switchWifiChannel(needScan: Int, channel: Int): Long

    fun getWifiInterfStatus(): Long

    fun setWifiState(info: WifiConnectionInfo, wifiNetState: Int): Long

    fun setShowCloudTab(showCloudTab: Boolean): Long

    fun setPhoneInfo(manufacturer: String, model: String, osVersion: String): Long

    fun getWifiMode(): Long

    fun getWifiConnectList(): Long

    fun deleteWifiHistoryInfo(ssid: String): Long

    fun getWifiScanList(interval: Int, count: Int): Long

    fun startCameraLive(): Long

    fun stopCameraLive(): Long

    fun requestP3StaticStreamData(): Long

    fun prepareCameraLive(): Long

    fun setAccessCameraFileState(accessState: Int): Long

    fun setFlowStateEnable(enable: Int): Long

    fun getFlowStateEnable(): Long

    fun getDarkEisStatus(): Long

    fun updateDownloadInfo(downLoadInfo: DownLoadInfo): Long

    fun getDownloadFileList(fileList: GetFileList): Long

    fun notifyGetDownloadFileListResult(addListResultSync: DownloadListResultSync): Long

    fun setGimbalControl(gimbalControl: GimbalControl): Long

    fun dspLinkTest(): Long

    fun gyroScopeTest(): Long

    fun whiteBlanceTest(): Long

    fun blackLevelTest(): Long

    fun badPointTest(): Long

    fun getAgeTestStatus(): Long

    fun setMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        options: MultiPhotographyOptions,
        requestOptions: RequestOptions,
    ): Long

    fun getMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        requestOptions: RequestOptions,
    ): Long

    fun setSingleSensor(sensor: Int): Long

    fun getSingleSensor(requestOptions: RequestOptions): Long

    fun vibrateTest(): Long

    fun stopVibrate(): Long

    fun chargingBox(commandType: Int, datas: ByteArray): Long

    fun checkVideoSupport(videoResultion: Int): Boolean

    fun checkVideoSupport(width: Int, height: Int, fps: Int): Boolean

    fun wakeUpGo2Ble(bleDevice: BleDeviceCore)

    fun openBle(): Int

    fun uploadScriptJson(jsonFile: ByteArray): Long

    fun uploadScriptCmd(cmdFile: ByteArray): Long

    fun scriptRefersh(): Long

    fun scriptRun(): Long

    fun setAAAFactoryMode(): Long

    fun setAAANormalMode(): Long

    fun getWhiteBlanceStatus(): Long

    fun getSFRStatus(): Long

    fun getSFRResult(): Long

    fun obtainCameraRtosStatus()

    fun setGlobalRequestTimeoutMs(timeoutMs: Int): Boolean

    fun setGlobalRequestRetryCount(retryCount: Int): Boolean

    fun getCloudStorageUploadStatus(): Long

    fun setCloudStorageUploadStatus(params: CloudStorageUploadParams): Long

    fun getCloudStorageBindStatus(): Long

    fun setCloudStorageBindStatus(params: CloudStorageBindParams): Long

    fun setNetworkConfigEnable(params: SetNetworkConfigEnable): Long

    fun syncAccurateTime(): Long


    /**
     * 蓝牙特有方法
     */
    interface IBleConntectListener {
        fun scan(scanTimeout: Long, autoConnect: Boolean, bleScanListener: IBleScanListener)

        fun scan(bleScanRuleConfigCore: BleScanRuleConfigCore, bleScanListener: IBleScanListener)
        fun stopScan()

        fun disConnect(bleDevice: BleDeviceCore)

        fun connectDevice(
            bleDevice: BleDeviceCore,
            wakeUpAuthorizationUUID: String,
            enableHeartBeat: Boolean,
            isUseUcd2: Boolean,
            bleConnectListener: IBleConnectListener?,
        )

        fun disConnectBle()

        fun sendDisconnectBleData()

        fun wakeUpBle(mode: Int, deviceName: String, txPower: Byte)

        fun closeBle()

        fun stopWakeup()
    }

    interface IClassicConnectListener {
        fun connectClassicBluetooth(bleDevice: BleDeviceCore, isBleProxy: Boolean, isHeartBeatEnable: Boolean, isUseUcd2: Boolean, listener: IBleConnectListener)

        fun disconnectClassicBluetooth(address: String): Boolean

        fun extendClassicConnectTimeout()

        fun sendOpenCameraClassicBluetooth(connectType: Int): Long

        fun sendAiVoiceReady(isHuawei: Boolean = false): Long
    }

    interface IWIfiConnectListener {
        fun openWifi(
            networkHandle: Long,
            to: Int,
            addr: String,
            port: Short,
            heartBeats: Boolean,
            isUseUcd2: Boolean,
            processBusyPacketEnable: Boolean,
        )

        fun closeWifi()

        fun openIperf(mode: Int)

        fun closeIperf()

        fun getIperfAverage()

        fun isCameraSyncedReady(): Boolean
    }

    interface IUsbConnectListener {
        fun openUsb()

        fun startHdrCapture()

        fun stopHdrCapture(extraData: ByteArray)

        fun testUsbSpeed(testSDCardSpeed: TestSDCardSpeed)

        fun closeUsb()

        fun startContactTest()

        fun startColorTest()
    }

    interface IFmgOperateListener {
        fun getFmgDeviceInfo(): Long

        fun getFmgUUID(): Long

        fun getFmgActiveTime(): Long

        fun setFmgActiveTime(activeTime: Long): Long

        fun setFmgZoomScale(scale: Short)

        fun getFmgAllSettings(): Long

        fun setFmgSettingsMode(mode: PtzMode): Long

        fun setFmgSettingFollowSpeed(followSpeed: PtzFollowSpeed): Long

        fun setFmgSettingRcSpeed(rcSpeed: PtzRcSpeed): Long

        fun setFmgSettingZoomSpeed(zoomSpeed: PtzZoomSpeed): Long

        fun setFmgSettingRcHorizontalDir(horizontalDir: PtzRcHorizontalDir): Long

        fun setFmgSettingRcVerticalDir(verticalDir: PtzRcVerticalDir): Long

        fun setFmgSettingSoundEnable(soundMode: PtzSoundMode): Long

        fun setFmgSettingHvMode(hvMode: PtzHvMode): Long

        fun setFmgSettingSwitchModeWay(modeWay: PtzSwitchModeWay): Long

        fun setSettingLedBrightness(brightness: Int): Long

        fun setFmgSettingMotorStrength(motorStrength: PtzMotorStrength): Long

        fun setFmgSettingRoll360(rollSpeed: PtzRoll360): Long

        fun setFmgSettingQuickStart(quickStart: PtzQuickStart): Long

        fun setFmgSettingPitchLed(pitchLed: PtzPitchLed): Long

        fun getFmgVerticalTrimDegree(): Long

        fun setFmgVerticalTrimDegree(degree: Float): Long

        fun startOrUpdateFmgTargetFollow(followParams: FmgTargetFollowParams)

        fun speculateFmgTargetFollow(followParams: FmgTargetFollowParams)

        fun compositionFmgTargetFollow()

        fun lostFmgTargetFollow()

        fun exitFmgTargetFollow()

        fun startFmgCalibrate(): Long

        fun startFmgUpgrade(
            fileData: ByteArray,
            writeWithoutResponse: Boolean,
            mtu: Int,
            writeExtraBleOTA: Boolean,
        ): Long

        fun cancelFmgUpgrade()

        fun startFmgAITrackUpgrade(upgradeConfig: AITrackUpgradeConfig): Long

        fun cancelFmgAITrackUpgrade()

        fun setFmgButtonEnable(fmgButtonAbleParams: FmgButtonAbleParams): Long

        fun setFmgButtonDisable(fmgButtonAbleParams: FmgButtonAbleParams): Long

        fun setDwSrcEventState(enable: Boolean): Long

        fun getFmgButtonEnableStates(): Long

        fun getFmgMidCal(): Long

        fun setFmgMidCal(euler: DoubleArray): Long

        fun getFmgRunControl(state: PtzGrfState): Long

        fun setFmgRunControl(state: PtzGrfState, yaw: Float, pitch: Float, roll: Float): Long

        fun setFmgVirtualRc(x: Short, y: Short): Long

        fun setFmgTimeElapse(mode: PtzTemMode, state: PtzTemState, duration: Int): Long

        fun resetFmgDefaultSettings(): Long

        fun getFmgTrackSensitivityMode(): Long

        fun setFmgTrackSensitivityMode(mode: PtzTrackSensitivityMode): Long

        fun setFmgPano(frame: PtzPanoMode): Long

        fun startFmgRecMode(mode: PtzRecMode): Long

        fun stopFmgRecMode(mode: PtzRecMode): Long

        fun initFmgRecMode(mode: PtzRecMode): Long

        fun fmgVibration(): Long

        fun enableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long

        fun disableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long

        fun setFmgCameraFacing(frame: Short): Long

        fun backCenter(): Long

        fun updateFmgAppImuAngle(fmgAngleBean: FmgAngleBean)

        fun updateFmgAppImuInfo(floats: FloatArray)

        fun getFmgAnalyticsData(): Long

        fun clearFmgAnalyticsData(): Long

        fun getFmgBleAnalyticsData(): Long
        fun clearFmgBleAnalyticsData(): Long
        fun startFmgHeartBeat()

        fun stopFmgHeartBeat()

        fun setFmgAngleSeq(paramsList: List<FmgSetAngleSeqBean>): Long

        fun ptzBasketballA2G(
            mode: PtzBaksetballMode,
            state: PtzBaksetballState,
            transition: PtzBaksetballTransition,
        ): Long

        fun ptzBasketballInitNoBask()

        fun setPanoIndex(index: Short, frame: PtzPanoIndexFrame): Long

        fun setFmgAction(action: Short): Long

        fun setFmgAppStatus(recording: Short, touch: Short): Long

        fun setFmgRoll360Action(action: PtzRoll360Action): Long

        fun getAiTrackerDeviceInfo(): Long

        fun setAiTrackerStandbyMode(standbyMode: PtzAiTrackerStandbyMode): Long

        fun setAiTrackerAutoStandbyTime(standbyTime: PtzAiTrackerAutoStandbyTime): Long

        fun setAiTrackerOnePlamShoot(onePlamShoot: PtzAiTrackerOnePlamShoot): Long

        fun getAiTrackerSettings(): Long

        fun updateHbRecMode(mode: PtzRecMode)

        //记忆横竖屏方向
        fun setFmgSettingEnableSaveHv(enableSaveHv: PtzEnableSaveHv): Long

        //一键环拍速度和方向
        fun setFmgSettingSurroundShoot(surroundShoot: PtzSurroundShoot): Long

        fun setCloudPromptInterval(intervalSeconds: Long, cloudBackupInterval: Long): Long

        fun restoreFactorySettings(): Long

        fun setSingleHostInfo(singleHostCmdInfo: SingleHostCmdInfo): Long

        fun getIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long

        fun setIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long

        fun startStopIntervalRec(intervalRecStartStop: IntervalRecStartStop): Long

        fun cancelIntervalRec(intervalRecCancel: IntervalRecCancel): Long

        fun getIntervalRecStatus(): Long

        fun getIntervalRecSceneCfg(): Long

        fun getIntervalRecFeedbackCfg(): Long

        fun setIntervalRecFeedbackCfg(intervalRecFeedback: IntervalRecFeedback): Long

        fun setAudioStream(request: AudioStreamCtrl, timeoutMs: Int = -1): Long

        fun setAiIntent(request: AiIntentCtrl): Long

        fun setAssistantLanguage(request: AssistantLanguageCtrl): Long

        fun setUserRegion(request: UserRegionCtrl): Long

        fun bindBluetoothMacFeature(featureBluetoothMacBind: FeatureBluetoothMacBind): Long

        fun sendStreamData(streamType: StreamType, timestamp: Long, data: ByteArray)

        fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long

        fun cancelTracking(): Long

        fun setPresetComposition(setPresetComposition: SetPresetComposition): Long

        fun notifySettingPage(settingPageNotify: PhotoSettingPage): Long

        fun getPresetComposition(): Long

        fun getPtzTrackState(): Long

        fun getFirmwareVersionsInfo(): Long
    }
}
