package com.arashivision.fmg.response.model

import com.arashivision.fmg.fmgparser.ptz.PtzStatus.HAND_DRAG
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PANO_INDEX_FRAME
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PANO_MODE
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzFrame
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.REC_MODE
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.ROLL_360_MODE
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.TEM
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.TRACK_SENSITIVITY_MODE

class FmgModel {
    // 云台模式
    enum class PtzMode {
        AUTO, FOLLOW, PITCH_LOCK, FPV, LOCK;

        companion object {
            fun findByValue(nativeValue: Int): PtzMode {
                for (value in values()) {
                    if (nativeValue == value.ordinal) {
                        return value
                    }
                }
                return AUTO
            }
        }
    }

    // 跟随速度
    enum class PtzFollowSpeed {
        FAST, MIDDLE, SLOW;

        companion object {
            fun findByValue(nativeValue: Int): PtzFollowSpeed {
                return if (nativeValue == 0) {
                    FAST
                } else if (nativeValue == 1) {
                    MIDDLE
                } else {
                    SLOW
                }
            }
        }
    }

    // 摇杆速度
    enum class PtzRcSpeed {
        FAST, MIDDLE, SLOW;

        companion object {
            fun findByValue(nativeValue: Int): PtzRcSpeed {
                return if (nativeValue == 0) {
                    FAST
                } else if (nativeValue == 1) {
                    MIDDLE
                } else {
                    SLOW
                }
            }
        }
    }

    // 变焦速度
    enum class PtzZoomSpeed {
        FAST, MIDDLE, SLOW, LINEAR;

        companion object {
            fun findByValue(nativeValue: Int): PtzZoomSpeed {
                return if (nativeValue == 0) {
                    FAST
                } else if (nativeValue == 1) {
                    MIDDLE
                } else if (nativeValue == 2) {
                    SLOW
                } else {
                    LINEAR
                }
            }
        }
    }

    // 摇杆水平方向
    enum class PtzRcHorizontalDir(var nativeValue: Int) {
        DEFAULT(1), REVERSE(-1);

        companion object {
            fun findByValue(nativeValue: Int): PtzRcHorizontalDir {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return DEFAULT
            }
        }
    }

    // 摇杆垂直方向
    enum class PtzRcVerticalDir(var nativeValue: Int) {
        DEFAULT(1), REVERSE(-1);

        companion object {
            fun findByValue(nativeValue: Int): PtzRcVerticalDir {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return DEFAULT
            }
        }
    }

    enum class PtzSoundMode(val nativeValue: Int) {
        DISABLE(0),
        ENABLE(1),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzSoundMode {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return DISABLE
            }
        }
    }

    enum class PtzHvMode(val nativeValue: Int) {
        VERTICAL(0),
        HORIZONTAL(1),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzHvMode {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return VERTICAL
            }
        }
    }

    enum class PtzSwitchModeWay(val nativeValue: Int) {
        HALFCIRCLE(0),
        DOUBLECLICK(1),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzSwitchModeWay {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return HALFCIRCLE
            }
        }
    }

    // 握把 按键事件类型
    enum class PtzButtonEvent(val nativeValue: Int) {
        SINGLE_CLICK(PtzFrame.FHE_SINGLE_CLICK.toInt()),  //按键事件：单击 ;
        DOUBLE_CLICK(PtzFrame.FHE_DOUBLE_CLICK.toInt()),  //按键事件：双击
        TRIPLE_CLICK(PtzFrame.FHE_TRIPLE_CLICK.toInt()),  //按键事件：三击
        LONG(PtzFrame.FHE_LONG.toInt()),  //按键事件：长按
        LONG_RELEASE(PtzFrame.FHE_LONG_RELEASE.toInt()),  //按键事件：长按释放

        RC_UP(PtzFrame.FHE_RC_UP.toInt()),  //摇杆事件：上（摇杆上推再释放触发）
        RC_DOWN(PtzFrame.FHE_RC_DOWN.toInt()),  //摇杆事件：下（摇杆下推再释放触发）
        RC_LEFT(PtzFrame.FHE_RC_LEFT.toInt()),  //摇杆事件：左（摇杆左推再释放触发）
        RC_RIGHT(PtzFrame.FHE_RC_RIGHT.toInt()),  //摇杆事件：右（摇杆右推再释放触发）
        RC_IDLE(PtzFrame.FHE_RC_IDLE.toInt()),
        RC_SRC_VALUE(PtzFrame.FHE_RC_SRC_VALUE.toInt()),  //摇杆事件 flow2开始支持，遥感原始值

        TOUCH_CW(PtzFrame.FHE_TOUCH_CW.toInt()),  //触摸事件：顺时针触摸
        TOUCH_CCW(PtzFrame.FHE_TOUCH_CCW.toInt()),  //触摸事件：逆时针触摸
        TOUCH_START(PtzFrame.FHE_TOUCH_START.toInt()),  //触摸事件：开始了触摸
        TOUCH_END(PtzFrame.FHE_TOUCH_END.toInt()),  //触摸事件：结束了触摸
        TOUCH_LEFT_DOUBLE_CLICK(PtzFrame.FHE_TOUCH_LEFT_DC.toInt()),  //触摸事件：左边区域（拍摄按键）的触摸双击
        TOUCH_RIGHT_DOUBLE_CLICK(PtzFrame.FHE_TOUCH_RIGHT_DC.toInt()),  //触摸事件：右边区域（切换按键）的触摸双击

        DW_CW_SINGLE(PtzFrame.FHE_DW_CW_SINGLE.toInt()),  //拨轮事件：顺时针单次拨动
        DW_CW_START(PtzFrame.FHE_DW_CW_START.toInt()),  //拨轮事件：顺时针持续拨动开始
        DW_CW_STOP(PtzFrame.FHE_DW_CW_STOP.toInt()),  //拨轮事件：顺时针持续拨动结束
        DW_CCW_SINGLE(PtzFrame.FHE_DW_CCW_SINGLE.toInt()),  //拨轮事件：逆时针单次拨动
        DW_CCW_START(PtzFrame.FHE_DW_CCW_START.toInt()),  //拨轮事件：逆时针持续拨动开始
        DW_CCW_STOP(PtzFrame.FHE_DW_CCW_STOP.toInt()),  //拨轮事件：逆时针持续拨动结束
        DW_SRC_VALUE(PtzFrame.FHE_DW_SRC_VALUE.toInt()),
        ; //拨轮事件：拨轮原始值事件 此时data有一个字节(int8_t)的数据，范围为-100到100;拨轮偏离中位时会以5HZ频率给app发送此帧命令数据。

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzButtonEvent? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzButtonMode(val nativeValue: Int) {
        MODE_BTN(PtzFrame.MB_EVENT.toInt()),  //模式按键
        SHUTTER_BTN(PtzFrame.SB_EVENT.toInt()),  //快门按键
        HOLD_BTN(PtzFrame.HOLD_EVENT.toInt()),  //扳机按键
        MID_BTN(PtzFrame.MID_EVENT.toInt()),  //摇杆中键
        ROCKER(PtzFrame.RC_EVENT.toInt()),  //摇杆
        TOUCH(PtzFrame.TOUCH_EVENT.toInt()),  //触摸
        DW(PtzFrame.DW_EVENT.toInt()),  //拨轮
        POWER_BTN(PtzFrame.PB_EVENT.toInt()) //电源按键
    }

    enum class PtzButtonEventMode(val nativeValue: Int) {
        ALL(0xff),
        CLICK_SINGLE(0x01),
        CLICK_DOUBLE(0x02),
        CLICK_TRIPLE(0x04),
        CLICK_LONG(0x08),
        CLICK_LONG_RELEASE(0x10)
    }

    enum class PtzRockerEventMode(val nativeValue: Int) {
        ALL(0xff),
        RC_UP(0x01),
        RC_DOWN(0x02),
        RC_LEFT(0x04),
        RC_RIGHT(0x08),
        RC_IDLE(0x10)
    }


    enum class PtzTouchEventMode(val nativeValue: Int) {
        ALL(0xff),
        TOUCH_CW(0x01),
        TOUCH_CCW(0x02),
        TOUCH_START(0x04),
        TOUCH_END(0x08),
        TOUCH_LEFT_DOUBLE_CLICK(0x10),
        TOUCH_RIGHT_DOUBLE_CLICK(0x20)
    }

    enum class PtzDwEventMode(val nativeValue: Int) {
        ALL(0xff),
        DW_CW_SINGLE(0x01),
        DW_CW_START(0x02),
        DWE_CW_STOP(0x04),
        DW_CCW_SINGLE(0x08),
        DW_CCW_START(0x10),
        DW_CCW_STOP(0x20),
        DW_SRC_VALUE(0x40)
    }


    enum class PtzGrfState(val nativeValue: Short) {
        GRF_IDLE(PtzFrame.GRF_IDLE),  //空闲
        GRF_ANGLE(PtzFrame.GRF_ANGLE),  //角度 表示设置的内容为位置信息
        GRF_SPEED(PtzFrame.GRF_SPEED),
        ; //角速度 表示设置的内容为速度信息

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzGrfState? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzAngleSqeState(val nativeValue: Short) {
        GRF_ANGLE_SEQ_FINISH(PtzFrame.GRF_ANGLE),
        GRF_ANGLE_SEQ_PROCESS(PtzFrame.GRF_ANGLE_SEQ_PROCESS),
        GRF_INDEX_FINISH(PtzFrame.GRF_INDEX_FINISH),
        GRF_ROLL_FINISH(PtzFrame.GRF_ROLL_FINISH),
        GRF_ANGLE_NOT_SUPPORT(PtzFrame.GRF_ANGLE_NOT_SUPPORT),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzAngleSqeState? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzTemMode(val nativeValue: Short) {
        TEM_STATIC(TEM.TEM_STATIC),  //静态延时
        TEM_LEFT_TO_RIGHT(TEM.TEM_LEFT_TO_RIGHT),  //角度 表示设置的内容为位置信息
        TEM_RIGHT_TO_LEFT(TEM.TEM_RIGHT_TO_LEFT),  //角速度 表示设置的内容为速度信息
        TEM_CUSTOM(TEM.TEM_CUSTOM),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzTemMode? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzTemState(val nativeValue: Short) {
        TE_START_EXE(TEM.TE_START_EXE),  //开始延时
        TE_STOP_EXE(TEM.TE_STOP_EXE),
        ; //停止延时

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzTemState? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzRecMode(val nativeValue: Short) {
        PANO_CAPTURE(REC_MODE.REC_PANO_CAPTURE),
        NORMAL_CAPTURE(REC_MODE.REC_NORMAL_CAPTURE),
        NORMAL_RECORD(REC_MODE.REC_NORMAL_RECORD),
        TIME_LAPSE(REC_MODE.REC_TIME_LAPSE),
        TIME_SHIFT(REC_MODE.REC_TIME_SHIFT),
        FILM_MODE(REC_MODE.REC_FILM_MODE),
        SLOW_MOTION(REC_MODE.REC_SLOW_MOTION),
        BASKETBALL(REC_MODE.REC_BASKETBALL),
        SCREEN_RECORDING_TRACKING(REC_MODE.REC_SCREEN_RECORDING_TRACKING),
        DOLLY_ZOOM(REC_MODE.REC_DOLLY_ZOOM),
        NULL(REC_MODE.REC_NULL);

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzRecMode? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzPanoMode(val nativeValue: Short) {
        PANO_3X3_START(PANO_MODE.GPT_3X3_START),
        PANO_3X3_STOP(PANO_MODE.GPT_3X3_STOP),
        PANO_180_START(PANO_MODE.GPT_180_START),
        PANO_180_STOP(PANO_MODE.GPT_180_STOP),
        PANO_SPHERICAL_START(PANO_MODE.GPT_SPHERICAL_START),
        PANO_SPHERICAL_STOP(PANO_MODE.GPT_SPHERICAL_STOP),
        PANO_240_START(PANO_MODE.GPT_240_START),
        PANO_240_STOP(PANO_MODE.GPT_240_STOP),
        PANO_SPHERICAL_0_5_START(PANO_MODE.GPT_SPHERICAL_0_5_START),
        PANO_SPHERICAL_0_5_STOP(PANO_MODE.GPT_SPHERICAL_0_5_STOP),
        PANO_SPHERICAL_1_0_START(PANO_MODE.GPT_SPHERICAL_1_0_START),
        PANO_SPHERICAL_1_0_STOP(PANO_MODE.GPT_SPHERICAL_1_0_STOP),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzPanoMode? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzHandDrag(val nativeValue: Short) {
        GHDF_ROLL(HAND_DRAG.GHDF_ROLL),
        GHDF_PITCH(HAND_DRAG.GHDF_PITCH),
        GHDF_YAW(HAND_DRAG.GHDF_YAW),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzHandDrag? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzTrackSensitivityMode(val nativeValue: Short) {
        TS_NORMAL(TRACK_SENSITIVITY_MODE.TS_NORMAL),
        TS_SENSITIVE(TRACK_SENSITIVITY_MODE.TS_SENSITIVE),
        TS_HILAG(TRACK_SENSITIVITY_MODE.TS_HILAG);

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzTrackSensitivityMode? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzBaksetballMode(val nativeValue: Short) {
        HALF_COURT(0x00.toShort()),
        FULL_COURT(0x01.toShort())
    }

    enum class PtzBaksetballState(val nativeValue: Short) {
        IDLE(0x00.toShort()),
        LEFT_HALF_FIELD(0x01.toShort()),
        RIGHT_HALF_FIELD(0x02.toShort()),
        LEFT_TRANSITION(0x03.toShort()),
        RIGHT_TRANSITION(0x04.toShort()),
        INIT(0xFF.toShort())
    }

    enum class PtzBaksetballTransition(val nativeValue: Byte) {
        LEFT_WEAK_SIGNAL((-0x02.toByte()).toByte()),
        LEFT_STRONG_SIGNAL((-0x01.toByte()).toByte()),
        IDLE(0x00.toByte()),
        RIGHT_STRONG_SIGNAL(0x01.toByte()),
        RIGHT_WEAK_SIGNAL(0x02.toByte())
    }


    enum class PtzPanoIndexFrame(val nativeValue: Short) {
        IDLE(PANO_INDEX_FRAME.PIF_IDLE),
        WIDE(PANO_INDEX_FRAME.PIF_SPHERICAL_1_0),
        ULTRA_WIDE(PANO_INDEX_FRAME.PIF_SPHERICAL_0_5);

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzPanoIndexFrame? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzMotorStrength {
        HIGH, MEDIUM, LOW, UNKNWOW;

        companion object {
            fun findByValue(nativeValue: Int): PtzMotorStrength {
                return if (nativeValue == 0) {
                    HIGH
                } else if (nativeValue == 1) {
                    MEDIUM
                } else if (nativeValue == 2) {
                    LOW
                } else {
                    UNKNWOW
                }
            }
        }
    }

    enum class PtzRoll360(val nativeValue: Int) {
        CW_FAST(0), CW_MIDDLE(1), CW_SLOW(2), CCW_FAST(128), CCW_MIDDLE(129), CCW_SLOW(130), UNKNOW(
            -1
        );

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzRoll360 {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return UNKNOW
            }
        }
    }

    enum class PtzQuickStart(val nativeValue: Int) {
        DISABLE(0),
        ENABLE(1),
        UNKNOW(-1);

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzQuickStart {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return UNKNOW
            }
        }
    }

    enum class PtzPitchLed {
        CLOSE, LOW, MEDIUM, HIGHT, UNKNWOW;

        companion object {
            fun findByValue(nativeValue: Int): PtzPitchLed {
                return if (nativeValue == 0) {
                    CLOSE
                } else if (nativeValue == 2) {
                    LOW
                } else if (nativeValue == 3) {
                    MEDIUM
                } else if (nativeValue == 4) {
                    HIGHT
                } else {
                    UNKNWOW
                }
            }
        }
    }

    enum class PtzRoll360Action(val nativeValue: Short) {
        GROLL_IDLE(ROLL_360_MODE.GROLL_IDLE),
        GROLL_INIT(ROLL_360_MODE.GROLL_INIT),
        GROLL_MOVE(ROLL_360_MODE.GROLL_MOVE),
        GROLL_STOP(ROLL_360_MODE.GROLL_STOP),
        ;

        companion object {
            fun nativeValueOf(nativeValue: Short): PtzRoll360Action? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzAiTrackerStandbyMode(val nativeValue: Int) {
        STANDBY_MODE(0),
        LOW_POWER_MODE(1);

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzAiTrackerStandbyMode? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzAiTrackerAutoStandbyTime(val nativeValue: Int) {
        SLEEP_2_MIN(2),
        SLEEP_3_MIN(3),
        SLEEP_4_MIN(4),
        SLEEP_5_MIN(5),
        SLEEP_10_MIN(10),
        SLEEP_20_MIN(20);

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzAiTrackerAutoStandbyTime? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    enum class PtzAiTrackerOnePlamShoot(val nativeValue: Int) {
        ONE_PLAM_SHOOT_CLOSE(0),
        ONE_PLAM_SHOOT_OPEN(1);

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzAiTrackerOnePlamShoot? {
                for (event in values()) {
                    if (event.nativeValue == nativeValue) {
                        return event
                    }
                }
                return null
            }
        }
    }

    /***
     * 记忆FMG横竖屏方向
     */
    enum class PtzEnableSaveHv(val nativeValue: Int) {
        CLOSE(1), HORIZONTAL(2), VERTICAL(3), UNKNWOW(0);

        companion object {
            fun findByValue(nativeValue: Int): PtzEnableSaveHv {
                return if (nativeValue == 1) {
                    CLOSE
                } else if (nativeValue == 2) {
                    HORIZONTAL
                } else if (nativeValue == 3) {
                    VERTICAL
                } else {
                    UNKNWOW
                }
            }
        }
    }

    /***
     * 一键环拍速度和方向
     * CCW 1 逆时针
     * CW  0 顺时针
     */
    enum class PtzSurroundShoot(val nativeValue: Int) {
        CW_FAST(1), CW_MIDDLE(2), CW_SLOW(3), CCW_FAST(129), CCW_MIDDLE(130), CCW_SLOW(131), UNKNOW(
            0
        );

        companion object {
            fun nativeValueOf(nativeValue: Int): PtzSurroundShoot {
                for (value in values()) {
                    if (nativeValue == value.nativeValue) {
                        return value
                    }
                }
                return UNKNOW
            }
        }
    }
}
