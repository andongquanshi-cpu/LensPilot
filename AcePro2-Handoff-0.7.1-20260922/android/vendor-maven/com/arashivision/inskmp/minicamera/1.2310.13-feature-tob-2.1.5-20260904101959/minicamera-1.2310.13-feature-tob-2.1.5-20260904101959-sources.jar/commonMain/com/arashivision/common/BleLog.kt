package com.arashivision.common

import com.arashivision.inskmp.insble.BleLogCore

typealias BleLog = BleLogCore