package com.arashivision.camera.listener

interface IFmgConnectSyncListener {
    fun onSyncSuccess()

    fun onSyncError(error: Int)
}
