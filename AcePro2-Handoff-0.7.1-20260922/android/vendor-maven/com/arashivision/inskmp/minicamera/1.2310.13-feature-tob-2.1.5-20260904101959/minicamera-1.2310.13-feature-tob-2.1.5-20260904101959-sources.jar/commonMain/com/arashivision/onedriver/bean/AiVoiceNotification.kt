package com.arashivision.onedriver.bean

class AiVoiceNotification
