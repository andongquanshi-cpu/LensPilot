package com.arashivision.fmg.response

class FmgSetMidCalResp(var requestID: Long)
