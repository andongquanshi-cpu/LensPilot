package com.arashivision.fmg.response

import com.arashivision.fmg.response.model.FmgAiTrackerSettingsParams

class FmgGetAiTrackerSettingsResp(
    var requestID: Long,
    var aiTrackerSettingsParams: FmgAiTrackerSettingsParams?
)
