package com.arashivision.camera.command.usb

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver
import insta360.messages.TestSDCardSpeed

class UsbSpeedCmd(private val mTestSDCardSpeed: TestSDCardSpeed) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.testSDCardSpeed(mTestSDCardSpeed)
    }
}
