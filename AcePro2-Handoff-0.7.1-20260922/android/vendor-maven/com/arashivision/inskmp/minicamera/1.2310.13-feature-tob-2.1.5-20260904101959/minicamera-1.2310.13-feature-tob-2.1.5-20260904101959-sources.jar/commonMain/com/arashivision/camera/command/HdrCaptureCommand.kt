package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * hdr拍照
 */
class HdrCaptureCommand : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.startHdrCapture()

        return 0
    }
}
