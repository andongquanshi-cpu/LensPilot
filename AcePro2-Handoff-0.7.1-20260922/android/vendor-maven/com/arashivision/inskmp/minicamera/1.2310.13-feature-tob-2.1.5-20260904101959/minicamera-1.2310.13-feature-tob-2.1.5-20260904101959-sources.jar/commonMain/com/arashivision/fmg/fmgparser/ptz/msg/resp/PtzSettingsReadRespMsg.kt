package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzSettingsReadRespMsg : PtzDataRespMessage() {
    private val DATA_LENGTH = 11
    var mode: Short = 0
    var follow_speed: Short = 0
    var rc_speed: Short = 0
    var zoom_speed: Short = 0
    var horizontal_dir: Byte = 0
    var vertical_dir: Byte = 0
    var key_define: Short = 0
    var sound_enable: Short = 0
    var hv_mode: Short = 0
    var switch_mode_way: Short = 0
    var led_status: Short = 0
    var motor_strength: Short = 0
    var roll_360: Short = 0
    var quick_start_enable: Short = 0
    var pitch_led: Short = 0
    var enable_dockkit: Short = 0
    var enable_save_hv: Short = 0 //是否记忆横竖模式 1：记忆横竖拍 2：强制开机横屏 3：强制开机竖屏
    var yaw_300: Short = 0 //一键环拍设置 0：顺时针 1：逆时针  低7位表示速度 1：快 2：中 3：慢

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < DATA_LENGTH) {
            return
        }
        Log.d("PtzSettingsReadRespMsg", "unpack=" + data.size)
        for (i in data.indices) {
            Log.d("PtzSettingsReadRespMsg", "unpack=list=" + i + " -> " + data[i])
        }
        mode = FmgByteUtils.byteToShort(data[0])
        follow_speed = FmgByteUtils.byteToShort(data[1])
        rc_speed = FmgByteUtils.byteToShort(data[2])
        zoom_speed = FmgByteUtils.byteToShort(data[3])
        horizontal_dir = data[4]
        vertical_dir = data[5]
        key_define = FmgByteUtils.byteToShort(data[6])
        sound_enable = FmgByteUtils.byteToShort(data[7])
        hv_mode = FmgByteUtils.byteToShort(data[8])
        switch_mode_way = FmgByteUtils.byteToShort(data[9])
        led_status = FmgByteUtils.byteToShort(data[10])
        if (data.size < 18) { //flow2新增的内容，已经超过了原先预留的长度，如果不分开处理会导致旧云台crash
            motor_strength = -1
            roll_360 = -1
            quick_start_enable = -1
            pitch_led = -1
            enable_dockkit = -1
            enable_save_hv = -1
            yaw_300 = -1
            return
        }
        motor_strength = FmgByteUtils.byteToShort(data[11])
        roll_360 = FmgByteUtils.byteToShort(data[12])
        quick_start_enable = FmgByteUtils.byteToShort(data[13])
        Log.d("txs", "quick_start_enable: $quick_start_enable")
        pitch_led = FmgByteUtils.byteToShort(data[14])
        enable_dockkit = FmgByteUtils.byteToShort(data[15])
        enable_save_hv = FmgByteUtils.byteToShort(data[16])
        yaw_300 = FmgByteUtils.byteToShort(data[17])
    }

    override fun toString(): String {
        return ("mode: " + mode + " follow_speed: " + follow_speed + " rc_speed: " + rc_speed + " zoom_speed: " + zoom_speed + " horizontal_dir: " + horizontal_dir + " vertical_dir: "
                + vertical_dir + " key_define: " + key_define + " sound_enable: " + sound_enable + " hv_mode: " + hv_mode + " switch_mode_way: " + switch_mode_way + " led_status: " + led_status
                + " motor_strength: " + motor_strength + " roll_speed: " + roll_360 + " quick_start_enable: " + quick_start_enable + " pitch_led: " + pitch_led
                + "enable_save_hv: " + enable_save_hv + " yaw_300: " + yaw_300)
    }

    override fun name(): String {
        return "CMD_SETTINGS_READ"
    }
}
