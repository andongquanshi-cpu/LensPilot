package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.onecamera.OneDriver

class BleStopScanCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        BleManagerCore.cancelScan()
        return null
    }
}
