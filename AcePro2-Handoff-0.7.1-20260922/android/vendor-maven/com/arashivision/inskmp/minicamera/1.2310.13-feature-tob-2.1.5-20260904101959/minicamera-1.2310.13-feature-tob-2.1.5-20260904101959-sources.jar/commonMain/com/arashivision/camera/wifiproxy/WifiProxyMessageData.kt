package com.arashivision.camera.wifiproxy

import okio.Buffer

/**
 * KMP兼容的WifiProxyMessageData实现
 * 使用okio替代java.nio.ByteBuffer
 */
class WifiProxyMessageData(var socketId: Int, var msg: ByteArray, var isUcd2: Boolean) : IWifiProxyData {

    override fun toBytes(): ByteArray {

        if (isUcd2) {
            return Buffer().apply {
                // 使用小端序写入数据
                writeIntLe(0x32444355)    // magic
                writeByte(0x01)         // version
                writeByte(12)            // header_length
                writeByte(0x0c)          // type
                writeByte(1)            // sequence
                writeIntLe(6 + msg.size)              // payload_len：messageHeadSize + messageContent.size()
                writeByte(IWifiProxyData.CMD_MESSAGE.toInt())
                writeByte(0)
                writeIntLe(socketId)         // 4 bytes: socketId
                write(msg)              // variable: url bytes
                val crc = WifiProxyDataParser.crc32(this)
                writeIntLe(crc)
            }.readByteArray()
        }

        val length = 4 + 1 + 2 + 1 + 1 + 4 + msg.size
        return Buffer().apply {
            // 使用小端序写入数据
            writeIntLe(length)           // 4 bytes: length
            writeByte(0x0c)              // 1 byte: 0x0c
            writeByte(0)                 // 1 byte: 0
            writeByte(0)                 // 1 byte: 0
            writeByte(IWifiProxyData.CMD_MESSAGE.toInt()) // 1 byte: CMD_MESSAGE
            writeByte(0)                 // 1 byte: 0
            writeIntLe(socketId)         // 4 bytes: socketId
            write(msg)                   // variable: message bytes
        }.readByteArray()
    }

    override fun size(): Int {
        return if (isUcd2) {
            4 + 1 + 1 + 1 + 1 + 4 + 1 + 1 + 4 + msg.size + 4
        } else {
            return 4 + 1 + 2 + 1 + 1 + 4 + msg.size
        }
    }
}
