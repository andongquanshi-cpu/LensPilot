package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class ChargingBoxCmd(private val mCommandType: Int, private val mDatas: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.chargingBox(mCommandType, mDatas)
    }
}
