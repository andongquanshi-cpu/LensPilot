package com.arashivision.camera.exception

class ObjectShouldNotNullException(msg: String?) : RuntimeException(msg)
