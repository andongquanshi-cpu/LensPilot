package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.DownloadListResultSync

class notifyGetDownloadFileListResultCmd(private val addListResultSync: DownloadListResultSync) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.notifyGetDownloadFileListResult(addListResultSync)
    }
}
