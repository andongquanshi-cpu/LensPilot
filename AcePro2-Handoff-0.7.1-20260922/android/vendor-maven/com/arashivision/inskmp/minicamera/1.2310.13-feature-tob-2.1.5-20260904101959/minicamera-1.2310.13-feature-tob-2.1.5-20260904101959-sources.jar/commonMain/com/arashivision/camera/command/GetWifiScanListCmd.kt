package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class GetWifiScanListCmd(private val interval: Int, private val count: Int) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getWifiScanList(interval, count)
    }
}
