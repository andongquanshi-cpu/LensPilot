package com.arashivision.fmg.fmgparser.ota

object OtaCmdPacketPack {
    const val OTA_LOW: Byte = 0xFF.toByte() //OTA_CMD - 0xFF00：获取设备 slave 的版本号命令
    const val OTA_GET_SLAVE_VERSION: Byte = 0x00.toByte() //OTA_CMD - 0xFF00：获取设备 slave 的版本号命令,未启用
    const val OTA_START_UPDATE: Byte = 0x01.toByte() //OTA_CMD - 0xFF01：启动升级命令
    const val OTA_END_UPDATE: Byte = 0x02.toByte() //OTA_CMD - 0xFF02：升级结束命令，app（master）发送完固件数据后下发

    val slaveVersionPack: ByteArray?
        get() {
            val otaCmdPacket = OtaCmdPacket()
            otaCmdPacket.setCmdData(
                OTA_GET_SLAVE_VERSION,
                OTA_LOW
            )
            return otaCmdPacket.packetData
        }

    fun startUpdatePack(): ByteArray? {
        val otaCmdPacket = OtaCmdPacket()
        otaCmdPacket.setCmdData(OTA_START_UPDATE, OTA_LOW)
        return otaCmdPacket.packetData
    }

    fun endUpdatePack(index: Int): ByteArray? {
        val otaCmdPacket = OtaCmdPacket()
        otaCmdPacket.setCmdData(OTA_END_UPDATE, OTA_LOW)
        otaCmdPacket.setIndex(index)
        otaCmdPacket.setCrc()
        return otaCmdPacket.packetData
    }
}
