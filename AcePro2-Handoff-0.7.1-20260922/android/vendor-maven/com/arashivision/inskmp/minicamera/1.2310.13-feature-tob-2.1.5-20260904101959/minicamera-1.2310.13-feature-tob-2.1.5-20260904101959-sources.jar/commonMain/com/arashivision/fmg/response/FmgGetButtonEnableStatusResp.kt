package com.arashivision.fmg.response

import com.arashivision.fmg.response.model.FmgButtonAbleParams

class FmgGetButtonEnableStatusResp(var requestID: Long) {
    var fmgButtonAbleParams: FmgButtonAbleParams? = null

    override fun toString(): String {
        return "FmgGetButtonEnableStatusResp{" +
                "requestID=" + requestID +
                ", fmgButtonAbleParams=" + fmgButtonAbleParams +
                '}'
    }
}
