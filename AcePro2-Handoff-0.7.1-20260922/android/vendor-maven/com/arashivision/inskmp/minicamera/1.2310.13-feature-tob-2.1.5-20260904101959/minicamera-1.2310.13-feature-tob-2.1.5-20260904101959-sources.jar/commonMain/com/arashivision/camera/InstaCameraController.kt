package com.arashivision.camera

import com.arashivision.camera.exception.ObjectShouldNotNullException
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IBleScanListener
import com.arashivision.camera.listener.ICameraConnectionListener
import com.arashivision.camera.listener.ICameraInfoListener
import com.arashivision.camera.listener.ICameraRecordListener
import com.arashivision.camera.listener.IReconnectCallback
import com.arashivision.camera.listener.ITimelapseListener
import com.arashivision.camera.listener.IWifiProxyDataListener
import com.arashivision.camera.listener.OnStillImageListener
import com.arashivision.camera.strategy.ConnectStrategyImpl
import com.arashivision.camera.strategy.InstaCameraStrategy
import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.inskmp.insble.callback.BleStopWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.arashivision.onecamera.OneDriver
import com.arashivision.onedriver.bean.StreamGimbalData
import com.arashivision.onedriver.packet.StreamType
import insta360.messages.SetPresetComposition
import insta360.messages.PhotoSettingPage
import insta360.messages.StreamTrackData
import com.arashivision.utils.CLogUtils
import insta360.messages.AiIntentCtrl
import insta360.messages.AssistantLanguageCtrl
import insta360.messages.AudioStreamCtrl

import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType
import insta360.messages.CalibrateGyro
import insta360.messages.CancelAngleFixed
import insta360.messages.CardLocation
import insta360.messages.CheckAuthorization
import insta360.messages.CloudStorageBindParams
import insta360.messages.CloudStorageUploadParams
import insta360.messages.ConnectToBTPeripheral
import insta360.messages.CtrlPreRecord
import insta360.messages.DataTransPort
import insta360.messages.DataTransPortDir
import insta360.messages.DataTransportResult
import insta360.messages.DeleteFiles
import insta360.messages.DisconnectBTPeripheral
import insta360.messages.DownLoadInfo
import insta360.messages.DownloadListResultSync
import insta360.messages.FeatureBluetoothMacBind
import insta360.messages.FormatStorage
import insta360.messages.GetConnectedBTPeripheral
import insta360.messages.GetFile
import insta360.messages.GetFileExtra
import insta360.messages.GetFileFinish
import insta360.messages.GetFileList
import insta360.messages.GetGyro
import insta360.messages.GetGyroResp
import insta360.messages.GetTimelapseOptions
import insta360.messages.GimbalControl
import insta360.messages.IntervalRecCancel
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecStartStop
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveOptionCtrlInfo
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.OpenTrackingWithRect
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation
import insta360.messages.RecipeShareStatus
import insta360.messages.ScanBTPeripheral
import insta360.messages.SetFavoriteList
import insta360.messages.SetFileExtra
import insta360.messages.SetKeyTimePoint
import insta360.messages.SetNetworkConfigEnable
import insta360.messages.SetTimelapseOptions
import insta360.messages.SingleHostCmdInfo
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.TakePicture
import insta360.messages.TestSDCardSpeed
import insta360.messages.TimelapseOptions
import insta360.messages.UserRegionCtrl
import insta360.messages.WifiConnectionInfo

/**
 * insta360相机的控制类
 *
 *
 * 是个单例
 */
class InstaCameraController private constructor() {
    private val mCameraState: InstaCameraState = InstaCameraState.Companion.create()

    private lateinit var mInstaCameraStrategy: InstaCameraStrategy

    fun setStrategy(cameraStrategy: InstaCameraStrategy) {
        mInstaCameraStrategy = cameraStrategy
    }

    fun setPeerDriver(peer: com.arashivision.onecamera.OneDriver?) = mInstaCameraStrategy.setPeerDriver(peer)
    fun getOneDriver(): com.arashivision.onecamera.OneDriver = mInstaCameraStrategy.getOneDriver()


    /**
     * 蓝牙扫描
     */
    fun scan(scanTimeout: Long, autoConnect: Boolean, bleScanListener: IBleScanListener) {
        mInstaCameraStrategy.scan(scanTimeout, autoConnect, bleScanListener)
    }

    fun scan(bleScanRuleConfigCore: BleScanRuleConfigCore, bleScanListener: IBleScanListener) {
        mInstaCameraStrategy.scan(bleScanRuleConfigCore, bleScanListener)
    }

    fun connectDevice(
        bleDevice: BleDeviceCore,
        wakeUpAuthorizationUUID: String,
        enableHeartBeat: Boolean,
        isUseUcd2: Boolean,
        listener: IBleConnectListener,
    ) {
        mInstaCameraStrategy.connectDevice(
            bleDevice,
            wakeUpAuthorizationUUID,
            enableHeartBeat,
            isUseUcd2,
            listener,
        )
    }

    fun connectClassicBluetooth(bleDevice: BleDeviceCore, isBleProxy: Boolean, isHeartBeatEnable: Boolean, isUseUcd2: Boolean, listener: IBleConnectListener) {
        mInstaCameraStrategy.connectClassicBluetooth(bleDevice, isBleProxy, isHeartBeatEnable, isUseUcd2, listener)
    }

    fun disconnectClassicBluetooth(address: String): Boolean {
        return mInstaCameraStrategy.disconnectClassicBluetooth(address)
    }

    fun extendClassicConnectTimeout() {
        mInstaCameraStrategy.extendClassicConnectTimeout()
    }
    fun openWifi(
        networkHandle: Long,
        to: Int,
        addr: String,
        port: Short,
        heartBeats: Boolean,
        isUseUcd2: Boolean,
        processBusyPacketEnable: Boolean,
    ) {
        mInstaCameraStrategy.openWifi(
            networkHandle, to,
            addr, port, heartBeats, isUseUcd2, processBusyPacketEnable
        )
    }

    fun isCameraSyncedReady(): Boolean {
        return mInstaCameraStrategy.isCameraSyncedReady()
    }

    fun setGlobalRequestTimeoutMs(timeoutMs: Int): Boolean {
        return mInstaCameraStrategy.setGlobalRequestTimeoutMs(timeoutMs)
    }

    fun setGlobalRequestRetryCount(retryCount: Int): Boolean {
        return mInstaCameraStrategy.setGlobalRequestRetryCount(retryCount)
    }

    fun takePicture(takePicture: TakePicture, withoutStorage: Boolean) {
        mInstaCameraStrategy.takePicture(takePicture, withoutStorage)
    }

    fun stopTakePicture(): Long {
        return mInstaCameraStrategy.stopTakePicture()
    }

    fun startRecord(
        recordOriginVideo: Boolean,
        livePush: Boolean,
        mode: Int,
    ) {
        if (livePush) {
            throw ObjectShouldNotNullException("on livepush mode StartCaptureWithoutStorage should not null")
        }

        mInstaCameraStrategy.startRecord(recordOriginVideo, livePush, mode)
    }

    fun stopRecord(mode: Int, extraData: ByteArray) {
        mInstaCameraStrategy.stopRecord(mode, extraData)
    }

    fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long {
        return mInstaCameraStrategy.setPreRecord(ctrlPreRecord)
    }

    fun release() {
        mInstaCameraStrategy.reset()
        mInstaCameraStrategy.release()
    }

    fun ersaSDcasrd(): Long {
        return mInstaCameraStrategy.eraseSdcard()
    }

    fun formatStorage(formatStorage: FormatStorage): Long {
        return mInstaCameraStrategy.formatStorage(formatStorage)
    }

    fun setMainStorage(cardLocation: CardLocation): Long {
        return mInstaCameraStrategy.setMainStorage(cardLocation)
    }

    fun disConnect(bleDevice: BleDeviceCore) {
        mInstaCameraStrategy.disConnect(bleDevice)
    }

    fun startHdrCapture() {
        mInstaCameraStrategy.startHdrCapture()
    }

    fun close() {
        mInstaCameraStrategy.closeUsb()
    }

    fun obtainCameraRtosStatus() {
        mInstaCameraStrategy.obtainCameraRtosStatus()
    }

    fun calibrateGyro(calibrateGyro: CalibrateGyro): Long {
        return mInstaCameraStrategy.calibrateGyro(calibrateGyro)
    }

    fun getCaptureStatus(requestOptions: RequestOptions): Long {
        return mInstaCameraStrategy.getCaptureStatus(requestOptions)
    }

    fun startTimelapseDelay(startTimelapse: StartTimelapse, toMs: Int) {
        mInstaCameraStrategy.startTimeplapse(startTimelapse)
    }

    fun reboot(): Long {
        return mInstaCameraStrategy.reboot()
    }

    fun notifyOTAError(): Long {
        return mInstaCameraStrategy.notifyOTAError()
    }

    fun setAppId(appId: String): Long {
        return mInstaCameraStrategy.setAppId(appId)
    }

    fun setShutdown(): Long {
        return mInstaCameraStrategy.setShutdown()
    }

    fun cancelAngleFixed(cancelAngleFixed: CancelAngleFixed): Long {
        return mInstaCameraStrategy.cancelAngleFixed(cancelAngleFixed)
    }
    fun sendOpenCameraClassicBluetooth(connectType: Int): Long {
        return mInstaCameraStrategy.sendOpenCameraClassicBluetooth(connectType)
    }

    fun sendAiVoiceReady(isHuawei: Boolean = false): Long {
        return mInstaCameraStrategy.sendAiVoiceReady(isHuawei)
    }

    fun checkAuthorization(
        checkAuthorization: CheckAuthorization,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.checkAuthorization(checkAuthorization, requestOptions)
    }

    fun requestAuthorization(authorizationOperationType: Int): Long {
        return mInstaCameraStrategy.requestAuthorization(authorizationOperationType)
    }

    fun getOptions(optionList: List<OptionType>): Options? {
        return mInstaCameraStrategy.getOptions(optionList)
    }

    fun getOptionsSync(optionList: List<OptionType>, requestOptions: RequestOptions): Long {
        return mInstaCameraStrategy.getOptionsSync(optionList, requestOptions)
    }

    fun negotiateEncryption(onComplete: (Boolean) -> Unit) {
        mInstaCameraStrategy.negotiateEncryption(onComplete)
    }

    fun getPhotoOptionsAsync(
        funcMode: Int,
        options: List<PhotographyOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.getPhotoOptionsAsync(funcMode, options, requestOptions)
    }

    fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        opetions: List<ButtonPressParamsType>,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.getButtonPressParams(
            buttonPressMode, buttonPressType,
            opetions, requestOptions
        )
    }

    fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        buttonPressParams: ButtonPressParams,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.setButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            buttonPressParams,
            requestOptions
        )
    }

    fun getTimelapseOption(getTimelapseOptions: GetTimelapseOptions): TimelapseOptions? {
        return mInstaCameraStrategy.getTimelapseOption(getTimelapseOptions)
    }

    fun getTimelapseOptionAsync(
        getTimelapseOptions: GetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.getTimelapseOptionAsync(
            getTimelapseOptions,
            requestOptions
        )
    }

    fun getCameraLiveOptionsSync(
        optionList: List<LiveBroadCastOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.getCameraLiveOptionsSync(optionList, requestOptions)
    }

    fun setCameraLiveOptionsSync(
        optionList: List<LiveBroadCastOptionType>,
        options: LiveOptionCtrlInfo,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.setCameraLiveOptionsAsync(optionList, options, requestOptions)
    }

    fun openUsb() {
        mInstaCameraStrategy.openUsb()
    }

    fun closeWifi() {
        mInstaCameraStrategy.closeWifi()
    }

    fun getFileInfoList(cardLocation: CardLocation = CardLocation.STOR_CL_CAMERA): Long {
        return mInstaCameraStrategy.getFileInfoList(cardLocation)
    }

    fun getEditInfoList(): Long {
        return mInstaCameraStrategy.getEditInfoList()
    }

    fun getTranslateConfig(timeoutMs: Int = -1): Long {
        return mInstaCameraStrategy.getTranslateConfig(timeoutMs)
    }

    fun getFileList(fileList: GetFileList): Long {
        return mInstaCameraStrategy.getFileList(fileList)
    }

    fun getFileListIncludeRecording(fileList: GetFileList): Long {
        return mInstaCameraStrategy.getFileListIncludeRecording(fileList)
    }

    fun getFile(getFile: GetFile): Long {
        return mInstaCameraStrategy.getFile(getFile)
    }

    fun setFavoriteList(setFavoriteList: SetFavoriteList): Long {
        return mInstaCameraStrategy.setFavoriteList(setFavoriteList)
    }

    fun packFile(getFile: GetFile): Long {
        return mInstaCameraStrategy.packFile(getFile)
    }

    fun getFileFinish(getFileFinish: GetFileFinish): Long {
        return mInstaCameraStrategy.getFileFinish(getFileFinish)
    }

    fun setTransferStatus(getFileFinish: GetFileFinish): Long {
        return mInstaCameraStrategy.setTransferStatus(getFileFinish)
    }

    fun changeConnectType(type: Int) {
    }

    fun getPort(): Int {
        return mInstaCameraStrategy.getPort()
    }

    fun previewStream(startStreamingParam: StartLiveStream, offset: String) {
        mInstaCameraStrategy.previewStream(startStreamingParam, offset)
    }

    fun closePreviewStream() {
        mInstaCameraStrategy.closePreviewStream()
    }

    fun requestStreamIframe() {
        mInstaCameraStrategy.requestStreamIframe()
    }

    fun startWifiStatusTest() {
        mInstaCameraStrategy.startWifiStatusTest()
    }

    fun stopUsbcardBackup(): Long {
        return mInstaCameraStrategy.stopUsbcardBackup()
    }

    fun getQuickReaderStatus(): Long {
        return mInstaCameraStrategy.getQuickReaderStatus()
    }

    fun startBleStatusTest() {
        mInstaCameraStrategy.startBleStatusTest()
    }

    fun startLedTest() {
        mInstaCameraStrategy.startLedTest()
    }

    fun openIperf(mode: Int) {
        mInstaCameraStrategy.openIperf(mode)
    }

    fun getIperfAverage(): Unit {
        return mInstaCameraStrategy.getIperfAverage()
    }

    fun testUsbSpeed(testSDCardSpeed: TestSDCardSpeed) {
        mInstaCameraStrategy.testUsbSpeed(testSDCardSpeed)
    }

    fun startSpeakerTest() {
        mInstaCameraStrategy.startSpeakerTest()
    }

    fun disConnectBle() {
        mInstaCameraStrategy.disConnectBle()
    }

    fun sendDisconnectBleData() {
        mInstaCameraStrategy.sendDisconnectBleData()
    }

    fun setOptions(
        optionList: List<OptionType>,
        options: Options,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.setOptionAsync(optionList, options, requestOptions)
    }

    fun wakeUpBle(mode: Int, deviceName: String, txPower: Byte) {
        mInstaCameraStrategy.wakeUpBle(mode, deviceName, txPower)
    }

    fun stopWakeupBle() {
        mInstaCameraStrategy.stopWakeup()
    }

    fun stopScanBle() {
        mInstaCameraStrategy.stopScan()
    }

    fun closeBle() {
        mInstaCameraStrategy.closeBle()
    }

    fun deleteFileList(deleteFiles: DeleteFiles): Long {
        return mInstaCameraStrategy.delteFileList(deleteFiles)
    }

    fun getGyro(getGyro: GetGyro): GetGyroResp? {
        return mInstaCameraStrategy.getGyro(getGyro)
    }

    fun getGyroSync(getGyro: GetGyro): Long {
        return mInstaCameraStrategy.getGyroSync(getGyro)
    }

    fun testButtonState() {
        mInstaCameraStrategy.testButtonState()
    }

    fun setBleWakeupListener(bleWakeupListener: BleWakeupCallbackCore) {
        mInstaCameraStrategy.setBleWakeupListener(bleWakeupListener)
    }

    fun setBleStopWakeupListener(bleStopWakeupCallback: BleStopWakeupCallbackCore) {
        mInstaCameraStrategy.setBleStopWakeupListener(bleStopWakeupCallback)
    }

    fun setNeedReconnectCallback(needReconnectCallback: IReconnectCallback) {
        mInstaCameraStrategy.setReconnectCallback(needReconnectCallback)
    }

    fun setStreamListener(streamListener: OneDriver.OnStreamListener?) {
        mInstaCameraStrategy.setStreamListener(streamListener)
    }

    fun startContactTest() {
        mInstaCameraStrategy.startContactTest()
    }

    fun startColorTest() {
        mInstaCameraStrategy.startColorTest()
    }

    fun getFmgDeviceInfo(): Long {
        return mInstaCameraStrategy.getFmgDeviceInfo()
    }

    fun getFmgUUID(): Long {
        return mInstaCameraStrategy.getFmgUUID()
    }

    fun getFmgActiveTime(): Long {
        return mInstaCameraStrategy.getFmgActiveTime()
    }

    fun setFmgActiveTime(activeTime: Long): Long {
        return mInstaCameraStrategy.setFmgActiveTime(activeTime)
    }

    fun setFmgZoomScale(scale: Short) {
        mInstaCameraStrategy.setFmgZoomScale(scale)
    }

    fun getFmgAllSettings(): Long {
        return mInstaCameraStrategy.getFmgAllSettings()
    }

    fun setFmgSettingsMode(mode: PtzMode): Long {
        return mInstaCameraStrategy.setFmgSettingsMode(mode)
    }

    fun setFmgSettingFollowSpeed(followSpeed: PtzFollowSpeed): Long {
        return mInstaCameraStrategy.setFmgSettingFollowSpeed(followSpeed)
    }

    fun setFmgSettingRcSpeed(rcSpeed: PtzRcSpeed): Long {
        return mInstaCameraStrategy.setFmgSettingRcSpeed(rcSpeed)
    }

    fun setFmgSettingZoomSpeed(zoomSpeed: PtzZoomSpeed): Long {
        return mInstaCameraStrategy.setFmgSettingZoomSpeed(zoomSpeed)
    }

    fun setFmgSettingRcHorizontalDir(horizontalDir: PtzRcHorizontalDir): Long {
        return mInstaCameraStrategy.setFmgSettingRcHorizontalDir(horizontalDir)
    }

    fun setFmgSettingRcVerticalDir(verticalDir: PtzRcVerticalDir): Long {
        return mInstaCameraStrategy.setFmgSettingRcVerticalDir(verticalDir)
    }

    fun setFmgSettingSoundEnable(soundMode: PtzSoundMode): Long {
        return mInstaCameraStrategy.setFmgSettingSoundEnable(soundMode)
    }

    fun setFmgSettingHvMode(hvMode: PtzHvMode): Long {
        return mInstaCameraStrategy.setFmgSettingHvMode(hvMode)
    }

    fun setFmgSettingSwitchModeWay(modeWay: PtzSwitchModeWay): Long {
        return mInstaCameraStrategy.setFmgSettingSwitchModeWay(modeWay)
    }

    fun setSettingLedBrightness(brightness: Int): Long {
        return mInstaCameraStrategy.setSettingLedBrightness(brightness)
    }

    fun setFmgSettingMotorStrength(motorStrength: PtzMotorStrength): Long {
        return mInstaCameraStrategy.setFmgSettingMotorStrength(motorStrength)
    }

    fun setFmgSettingRoll360(roll360: PtzRoll360): Long {
        return mInstaCameraStrategy.setFmgSettingRoll360(roll360)
    }

    fun setFmgSettingQuickStart(quickStart: PtzQuickStart): Long {
        return mInstaCameraStrategy.setFmgSettingQuickStart(quickStart)
    }

    fun setFmgSettingPitchLed(pitchLed: PtzPitchLed): Long {
        return mInstaCameraStrategy.setFmgSettingPitchLed(pitchLed)
    }

    fun getFmgVerticalTrimDegree(): Long {
        return mInstaCameraStrategy.getFmgVerticalTrimDegree()
    }

    fun setFmgVerticalTrimDegree(degree: Float): Long {
        return mInstaCameraStrategy.setFmgVerticalTrimDegree(degree)
    }

    fun startOrUpdateFmgTargetFollow(followParams: FmgTargetFollowParams) {
        mInstaCameraStrategy.startOrUpdateFmgTargetFollow(followParams)
    }

    fun speculateFmgTargetFollow(followParams: FmgTargetFollowParams) {
        mInstaCameraStrategy.speculateFmgTargetFollow(followParams)
    }

    fun compositionFmgTargetFollow() {
        mInstaCameraStrategy.compositionFmgTargetFollow()
    }

    fun lostFmgTargetFollow() {
        mInstaCameraStrategy.lostFmgTargetFollow()
    }

    fun exitFmgTargetFollow() {
        mInstaCameraStrategy.exitFmgTargetFollow()
    }

    fun startFmgCalibrate(): Long {
        return mInstaCameraStrategy.startFmgCalibrate()
    }

    fun startFmgUpgrade(
        fileData: ByteArray,
        writeWithoutResponse: Boolean,
        mtu: Int,
        writeExtraBleOTA: Boolean,
    ): Long {
        return mInstaCameraStrategy.startFmgUpgrade(
            fileData,
            writeWithoutResponse,
            mtu,
            writeExtraBleOTA
        )
    }

    fun cancelFmgUpgrade() {
        mInstaCameraStrategy.cancelFmgUpgrade()
    }

    fun startFmgAITrackUpgrade(upgradeConfig: AITrackUpgradeConfig): Long {
        return mInstaCameraStrategy.startFmgAITrackUpgrade(upgradeConfig)
    }

    fun cancelFmgAITrackUpgrade() {
        mInstaCameraStrategy.cancelFmgAITrackUpgrade()
    }

    fun setFmgButtonEnable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return mInstaCameraStrategy.setFmgButtonEnable(fmgButtonAbleParams)
    }

    fun setFmgButtonDisable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return mInstaCameraStrategy.setFmgButtonDisable(fmgButtonAbleParams)
    }

    fun setDwSrcEventState(enable: Boolean): Long {
        return mInstaCameraStrategy.setDwSrcEventState(enable)
    }

    fun getFmgButtonEnableStates(): Long {
        return mInstaCameraStrategy.getFmgButtonEnableStates()
    }

    fun getFmgMidCal(): Long {
        return mInstaCameraStrategy.getFmgMidCal()
    }

    fun setFmgMidCal(euler: DoubleArray): Long {
        return mInstaCameraStrategy.setFmgMidCal(euler)
    }

    fun getFmgRunControl(state: PtzGrfState): Long {
        return mInstaCameraStrategy.getFmgRunControl(state)
    }

    fun setFmgRunControl(state: PtzGrfState, yaw: Float, pitch: Float, roll: Float): Long {
        return mInstaCameraStrategy.setFmgRunControl(state, yaw, pitch, roll)
    }

    fun setFmgVirtualRc(x: Short, y: Short): Long {
        return mInstaCameraStrategy.setFmgVirtualRc(x, y)
    }

    fun setFmgTimeElapse(mode: PtzTemMode, state: PtzTemState, duration: Int): Long {
        return mInstaCameraStrategy.setFmgTimeElapse(mode, state, duration)
    }

    fun setFmgPano(mode: PtzPanoMode): Long {
        return mInstaCameraStrategy.setFmgPano(mode)
    }

    fun startFmgRecMode(mode: PtzRecMode): Long {
        return mInstaCameraStrategy.startFmgRecMode(mode)
    }

    fun stopFmgRecMode(mode: PtzRecMode): Long {
        return mInstaCameraStrategy.stopFmgRecMode(mode)
    }

    fun initFmgRecMode(mode: PtzRecMode): Long {
        return mInstaCameraStrategy.initFmgRecMode(mode)
    }

    fun fmgVibration(): Long {
        return mInstaCameraStrategy.fmgVibration()
    }

    fun enableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return mInstaCameraStrategy.enableFmgHandDrag(list)
    }

    fun disableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return mInstaCameraStrategy.disableFmgHandDrag(list)
    }

    fun setFmgCameraFacing(frame: Short): Long {
        return mInstaCameraStrategy.setFmgCameraFacing(frame)
    }

    fun backCenter(): Long {
        return mInstaCameraStrategy.backCenter()
    }

    fun updateFmgAppImuAngle(fmgAngleBean: FmgAngleBean) {
        mInstaCameraStrategy.updateFmgAppImuAngle(fmgAngleBean)
    }

    fun updateFmgAppImuInfo(floats: FloatArray) {
        mInstaCameraStrategy.updateFmgAppImuInfo(floats)
    }

    fun getFmgAnalyticsData(): Long {
        return mInstaCameraStrategy.getFmgAnalyticsData()
    }

    fun clearFmgAnalyticsData(): Long {
        return mInstaCameraStrategy.clearFmgAnalyticsData()
    }

    fun getFmgBleAnalyticsData(): Long {
        return mInstaCameraStrategy.getFmgBleAnalyticsData()
    }

    fun clearFmgBleAnalyticsData(): Long {
        return mInstaCameraStrategy.clearFmgBleAnalyticsData()
    }

    fun setFmgAngleSeq(paramsList: List<FmgSetAngleSeqBean>): Long {
        return mInstaCameraStrategy.setFmgAngleSeq(paramsList)
    }

    fun ptzBasketballA2G(
        mode: PtzBaksetballMode,
        state: PtzBaksetballState,
        transition: PtzBaksetballTransition,
    ): Long {
        return mInstaCameraStrategy.ptzBasketballA2G(mode, state, transition)
    }

    fun ptzBasketballInitNoBask() {
        mInstaCameraStrategy.ptzBasketballInitNoBask()
    }

    fun setPanoIndex(index: Short, frame: PtzPanoIndexFrame): Long {
        return mInstaCameraStrategy.setPanoIndex(index, frame)
    }

    fun setFmgAction(action: Short): Long {
        return mInstaCameraStrategy.setFmgAction(action)
    }

    fun setFmgAppStatus(recording: Short, touch: Short): Long {
        return mInstaCameraStrategy.setFmgAppStatus(recording, touch)
    }

    fun setFmgRoll360Action(action: PtzRoll360Action): Long {
        return mInstaCameraStrategy.setFmgRoll360Action(action)
    }

    fun getAiTrackerDeviceInfo(): Long {
        return mInstaCameraStrategy.getAiTrackerDeviceInfo()
    }

    fun setAiTrackerStandbyMode(standbyMode: PtzAiTrackerStandbyMode): Long {
        return mInstaCameraStrategy.setAiTrackerStandbyMode(standbyMode)
    }

    fun setAiTrackerAutoStandbyTime(standbyTime: PtzAiTrackerAutoStandbyTime): Long {
        return mInstaCameraStrategy.setAiTrackerAutoStandbyTime(standbyTime)
    }

    fun setAiTrackerOnePlamShoot(onePlamShoot: PtzAiTrackerOnePlamShoot): Long {
        return mInstaCameraStrategy.setAiTrackerOnePlamShoot(onePlamShoot)
    }

    fun getAiTrackerSettings(): Long {
        return mInstaCameraStrategy.getAiTrackerSettings()
    }

    fun updateHbRecMode(mode: PtzRecMode) {
        mInstaCameraStrategy.updateHbRecMode(mode)
    }

    fun startFmgHeartBeat() {
        mInstaCameraStrategy.startFmgHeartBeat()
    }

    fun stopFmgHeartBeat() {
        mInstaCameraStrategy.stopFmgHeartBeat()
    }

    fun resetFmgDefaultSettings(): Long {
        return mInstaCameraStrategy.resetFmgDefaultSettings()
    }

    fun getFmgTrackSensitivityMode(): Long {
        return mInstaCameraStrategy.getFmgTrackSensitivityMode()
    }

    fun setFmgTrackSensitivityMode(mode: PtzTrackSensitivityMode): Long {
        return mInstaCameraStrategy.setFmgTrackSensitivityMode(mode)
    }

    fun addCameraInfoListener(cameraInfoListener: ICameraInfoListener) {
        mInstaCameraStrategy.addCameraInfoListener(cameraInfoListener)
    }

    fun removeCameraInfoListener(cameraInfoListener: ICameraInfoListener) {
        mInstaCameraStrategy.removeCameraInfoListener(cameraInfoListener)
    }

    fun addOnStillImageListener(listener: OnStillImageListener) {
        mInstaCameraStrategy.addStillImageListener(listener)
    }

    fun removeStillImageListener(listener: OnStillImageListener) {
        mInstaCameraStrategy.removeStillImageListener(listener)
    }

    fun closeIperf() {
        mInstaCameraStrategy.closeIperf()
    }

    fun addCameraRecordListener(cameraRecordListener: ICameraRecordListener) {
        mInstaCameraStrategy.addCameraRecordListener(cameraRecordListener)
    }

    fun removeCameraRecordListener(cameraRecordListener: ICameraRecordListener) {
        mInstaCameraStrategy.removeCameraRecordListener(cameraRecordListener)
    }

    fun addConnectionListener(cameraConnectionListener: ICameraConnectionListener) {
        mInstaCameraStrategy.addConnectionListener(cameraConnectionListener)
    }

    fun removeConnectionListener(connectionListener: ICameraConnectionListener) {
        mInstaCameraStrategy.removeConnectionListener(connectionListener)
    }

    fun addWifiProxyDataListener(wifiProxyDataListener: IWifiProxyDataListener) {
        mInstaCameraStrategy.addWifiProxyDataListener(wifiProxyDataListener)
    }

    fun removeWifiProxyDataListener(wifiProxyDataListener: IWifiProxyDataListener) {
        mInstaCameraStrategy.removeWifiProxyDataListener(wifiProxyDataListener)
    }

    fun testTypec() {
        mInstaCameraStrategy.startTestTypeC()
    }

    fun stopLCDTest() {
        mInstaCameraStrategy.stopLCDTest()
    }

    fun setSyncCaptureMode(mode: Int): Long {
        return mInstaCameraStrategy.setSyncCaptureMode(mode)
    }

    fun getSyncCaptureMode(): Long {
        return mInstaCameraStrategy.getSyncCaptureMode()
    }

    fun pauseRecord(): Long {
        return mInstaCameraStrategy.pauseRecord()
    }

    fun setStandbyMode(mode: Int): Long {
        return mInstaCameraStrategy.setStandbyMode(mode)
    }

    fun setGyroRebaseMatrix(matrix3: FloatArray) {
        mInstaCameraStrategy.setGyroRebaseMatrix(matrix3)
    }

    fun getPhotoOptions(funcMode: Int, options: List<PhotographyOptionType>): PhotographyOptions? {
        return mInstaCameraStrategy.getPhotoOptions(funcMode, options)
    }

    fun setTimelapseOptions(info: SetTimelapseOptions): Long {
        return mInstaCameraStrategy.setTimelapseOptions(info)
    }

    fun setTimelapseOptionsASync(
        info: SetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.setTimelapseOptionsASync(info, requestOptions)
    }

    fun startBulletTime(): Long {
        return mInstaCameraStrategy.startBulletTime()
    }

    fun setFileExtra(obj: SetFileExtra): Long {
        return mInstaCameraStrategy.setFileExtra(obj)
    }

    fun getFileExtra(obj: GetFileExtra): Long {
        return mInstaCameraStrategy.getFileExtra(obj)
    }

    fun recipeShareStatus(obj: RecipeShareStatus): Long {
        return mInstaCameraStrategy.recipeShareStatus(obj)
    }

    fun cancelAuthorization(requestOptions: RequestOptions): Long {
        return mInstaCameraStrategy.cancelAuthorization(requestOptions)
    }

    fun cancelRequestAuthorization(authorizationOperationType: Int): Long {
        return mInstaCameraStrategy.cancelRequestAuthorization(authorizationOperationType)
    }

    fun syncCaptureStatus(): Long {
        return mInstaCameraStrategy.syncCaptureStatus()
    }

    fun stopHdrCapture(extraData: ByteArray) {
        mInstaCameraStrategy.stopHdrCapture(extraData)
    }

    fun stopTimelapse(obj: StopTimelapse) {
        mInstaCameraStrategy.stopTimelapse(obj)
    }

    fun stopBulletTime(extraData: ByteArray) {
        mInstaCameraStrategy.stopBulletTime(extraData)
    }

    fun setPhotoOptions(
        funcMode: Int,
        optionList: List<PhotographyOptionType>,
        options: PhotographyOptions,
    ): Long {
        return mInstaCameraStrategy.setPhotoOptions(funcMode, optionList, options)
    }

    fun scanBT(obj: ScanBTPeripheral): Long {
        return mInstaCameraStrategy.scanBT(obj)
    }

    fun connectBT(obj: ConnectToBTPeripheral): Long {
        return mInstaCameraStrategy.connectBT(obj)
    }

    fun disConnectBT(obj: DisconnectBTPeripheral): Long {
        return mInstaCameraStrategy.disConnectBT(obj)
    }

    fun getConnectBT(obj: GetConnectedBTPeripheral): Long {
        return mInstaCameraStrategy.getConnectBT(obj)
    }

    fun addTimelapseListener(timelapseListener: ITimelapseListener) {
        mInstaCameraStrategy.addTimelapseListener(timelapseListener)
    }

    fun removeTimelapseListener(timelapseListener: ITimelapseListener) {
        mInstaCameraStrategy.removeTimelapseListener(timelapseListener)
    }

    fun writeWifiProxyData(wifiProxyData: IWifiProxyData) {
        mInstaCameraStrategy.writeWifiProxyData(wifiProxyData)
    }

    fun setGpsData(gpsData: ByteArray): Long {
        return mInstaCameraStrategy.setGpsData(gpsData)
    }

    fun setCameraWifiHeartDebug(debug: Boolean) {
        mInstaCameraStrategy.setCameraWifiHeartDebug(debug)
    }

    fun setSyncStandByMode(mode: Int): Long {
        return mInstaCameraStrategy.setSyncStandByMode(mode)
    }

    fun setPhotoOptionsSync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.setPhotoOptionSync(
            funcMode,
            optionTypes,
            options,
            requestOptions
        )
    }

    fun startTimeShift(): Long {
        return mInstaCameraStrategy.startTimeShift()
    }

    fun stopTimeShift(extraData: ByteArray) {
        mInstaCameraStrategy.stopTimeShift(extraData)
    }

    fun setKeyTimePoint(keyTimePoint: SetKeyTimePoint): Long {
        return mInstaCameraStrategy.setKeyTimePoint(keyTimePoint)
    }

    fun openCameraWifi(countryChannel: Int): Long {
        return mInstaCameraStrategy.openCameraWifi(countryChannel)
    }

    fun closeCameraWifi(): Long {
        return mInstaCameraStrategy.closeCameraWifi()
    }

    fun resetCameraWifi(countryChannel: Int): Long {
        return mInstaCameraStrategy.resetCameraWifi(countryChannel)
    }

    fun setCameraWifiSeizeEnable(connectionState: Int): Long {
        return mInstaCameraStrategy.setCameraWifiSeizeEnable(connectionState)
    }

    fun setAvailableWifi(wifiConnectionInfo: WifiConnectionInfo): Long {
        return mInstaCameraStrategy.setAvailableWifi(wifiConnectionInfo)
    }

    fun setWifiConnectionInfo(wifiConnectionInfo: WifiConnectionInfo): Long {
        return mInstaCameraStrategy.setWifiConnectionInfo(wifiConnectionInfo)
    }

    fun getWifiConnectionInfo(): Long {
        return mInstaCameraStrategy.getWifiConnectionInfo()
    }

    fun setWifiMode(wifiMode: Int, countryCode: String?): Long {
        return mInstaCameraStrategy.setWifiMode(wifiMode, countryCode)
    }

    fun requestData(
        dir: DataTransPortDir,
        rxdatainfo: List<RequestReceiveDataInformation>? = null,
        txdatainfo: List<RequestSendDataInformation>? = null,
    ): Long {
        return mInstaCameraStrategy.requestData(dir, rxdatainfo, txdatainfo)
    }

    fun dataTransportFeedback(dataTransportResult: DataTransportResult): Long {
        return mInstaCameraStrategy.dataTransportFeedback(dataTransportResult)
    }

    fun switchWifiChannel(needScan: Int, channel: Int): Long {
        return mInstaCameraStrategy.switchWifiChannel(needScan, channel)
    }

    fun getWifiInterfStatus(): Long {
        return mInstaCameraStrategy.getWifiInterfStatus()
    }

    fun setWifiState(info: WifiConnectionInfo, wifiNetState: Int): Long {
        return mInstaCameraStrategy.setWifiState(info, wifiNetState)
    }

    fun setShowCloudTab(showCloudTab: Boolean): Long {
        return mInstaCameraStrategy.setShowCloudTab(showCloudTab)
    }

    fun setPhoneInfo(manufacturer: String, model: String, osVersion: String): Long {
        return mInstaCameraStrategy.setPhoneInfo(manufacturer, model, osVersion)
    }

    fun getWifiMode(): Long {
        return mInstaCameraStrategy.getWifiMode()
    }

    fun deleteWifiHistoryInfo(ssid: String): Long {
        return mInstaCameraStrategy.deleteWifiHistoryInfo(ssid)
    }

    fun getWifiConnectList(): Long {
        return mInstaCameraStrategy.getWifiConnectList()
    }

    fun getWifiScanList(interval: Int, count: Int): Long {
        return mInstaCameraStrategy.getWifiScanList(interval, count)
    }

    fun startCameraLive(): Long {
        return mInstaCameraStrategy.startCameraLive()
    }

    fun stopCameraLive(): Long {
        return mInstaCameraStrategy.stopCameraLive()
    }

    fun requestP3StaticStreamData(): Long {
        return mInstaCameraStrategy.requestP3StaticStreamData()
    }

    fun prepareCameraLive(): Long {
        return mInstaCameraStrategy.prepareCameraLive()
    }

    fun setAccessCameraFileState(accessState: Int): Long {
        return mInstaCameraStrategy.setAccessCameraFileState(accessState)
    }

    fun setFlowStateEnable(enable: Int): Long {
        return mInstaCameraStrategy.setFlowStateEnable(enable)
    }

    fun getFlowStateEnable(): Long {
        return mInstaCameraStrategy.getFlowStateEnable()
    }

    fun getDarkEisStatus(): Long {
        return mInstaCameraStrategy.getDarkEisStatus()
    }

    fun updateDownloadInfo(downLoadInfo: DownLoadInfo): Long {
        return mInstaCameraStrategy.updateDownloadInfo(downLoadInfo)
    }

    fun getDownloadFileList(fileList: GetFileList): Long {
        return mInstaCameraStrategy.getDownloadFileList(fileList)
    }

    fun notifyGetDownloadFileListResult(addListResultSync: DownloadListResultSync): Long {
        return mInstaCameraStrategy.notifyGetDownloadFileListResult(addListResultSync)
    }

    fun setGimbalControl(gimbalControl: GimbalControl): Long {
        return mInstaCameraStrategy.setGimbalControl(gimbalControl)
    }

    fun setNativeLoggerCallback(loggerCallback: CLogUtils.ILoggerCallback) {
        mInstaCameraStrategy.setNativeLoggerCallback(loggerCallback)
    }

    fun dspLinkTest(): Long {
        return mInstaCameraStrategy.dspLinkTest()
    }

    fun gyroScopeTest(): Long {
        return mInstaCameraStrategy.gyroScopeTest()
    }

    fun whiteBlanceTest(): Long {
        return mInstaCameraStrategy.whiteBlanceTest()
    }

    fun blackLevelTest(): Long {
        return mInstaCameraStrategy.blackLevelTest()
    }

    fun badPointTest(): Long {
        return mInstaCameraStrategy.badPointTest()
    }

    fun getAgeTestStatus(): Long {
        return mInstaCameraStrategy.getAgeTestStatus()
    }

    fun setMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        options: MultiPhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.setMultiVideoMode(
            funcMode,
            sensorMode,
            optionList,
            options,
            requestOptions
        )
    }

    fun getMultiVideoMode(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        requestOptions: RequestOptions,
    ): Long {
        return mInstaCameraStrategy.getMultiVideoMode(
            funcMode,
            sensorMode,
            optionList,
            requestOptions
        )
    }

    fun setSingleSensor(sensor: Int): Long {
        return mInstaCameraStrategy.setSingleSensor(sensor)
    }

    fun getSingleSensor(requestOptions: RequestOptions): Long {
        return mInstaCameraStrategy.getSingleSensor(requestOptions)
    }

    fun vibrateTest(): Long {
        return mInstaCameraStrategy.vibrateTest()
    }

    fun vibrateStop(): Long {
        return mInstaCameraStrategy.stopVibrate()
    }

    fun chargingBox(commandType: Int, datas: ByteArray): Long {
        return mInstaCameraStrategy.chargingBox(commandType, datas)
    }

    fun checkVideoSupport(videoResultion: Int): Boolean {
        return mInstaCameraStrategy.checkVideoSupport(videoResultion)
    }

    fun checkVideoSupport(width: Int, height: Int, fps: Int): Boolean {
        return mInstaCameraStrategy.checkVideoSupport(width, height, fps)
    }

    fun wakeUpGo2Ble(bleDevice: BleDeviceCore) {
        mInstaCameraStrategy.wakeUpGo2Ble(bleDevice)
    }

    fun openBle(): Int {
        return mInstaCameraStrategy.openBle()
    }

    fun uploadScriptJson(jsonFile: ByteArray): Long {
        return mInstaCameraStrategy.uploadScriptJson(jsonFile)
    }

    fun uploadScriptCmd(cmdFile: ByteArray): Long {
        return mInstaCameraStrategy.uploadScriptCmd(cmdFile)
    }

    fun scriptRefersh(): Long {
        return mInstaCameraStrategy.scriptRefersh()
    }

    fun scriptRun(): Long {
        return mInstaCameraStrategy.scriptRun()
    }

    fun setAAAFactoryMode(): Long {
        return mInstaCameraStrategy.setAAAFactoryMode()
    }

    fun setAAANormalMode(): Long {
        return mInstaCameraStrategy.setAAANormalMode()
    }

    fun getWhiteBlanceStatus(): Long {
        return mInstaCameraStrategy.getWhiteBlanceStatus()
    }

    fun getSFRStatus(): Long {
        return mInstaCameraStrategy.getSFRStatus()
    }

    fun getSFRResult(): Long {
        return mInstaCameraStrategy.getSFRResult()
    }

    fun getCloudStorageUploadStatus(): Long {
        return mInstaCameraStrategy.getCloudStorageUploadStatus()
    }

    fun setCloudStorageUploadStatus(params: CloudStorageUploadParams): Long {
        return mInstaCameraStrategy.setCloudStorageUploadStatus(params)
    }

    fun getCloudStorageBindStatus(): Long {
        return mInstaCameraStrategy.getCloudStorageBindStatus()
    }

    fun setCloudStorageBindStatus(params: CloudStorageBindParams): Long {
        return mInstaCameraStrategy.setCloudStorageBindStatus(params)
    }

    fun setNetworkConfigEnable(params: SetNetworkConfigEnable): Long {
        return mInstaCameraStrategy.setNetworkConfigEnable(params)
    }

    fun syncAccurateTime(): Long {
        return mInstaCameraStrategy.syncAccurateTime()
    }

    fun setFmgSettingEnableSaveHv(enableSaveHv: PtzEnableSaveHv): Long {
        return mInstaCameraStrategy.setFmgSettingEnableSaveHv(enableSaveHv)
    }

    fun setFmgSettingSurroundShoot(surroundShoot: PtzSurroundShoot): Long {
        return mInstaCameraStrategy.setFmgSettingSurroundShoot(surroundShoot)
    }

    fun setCloudPromptInterval(intervalSeconds: Long, cloudBackupInterval: Long): Long {
        return mInstaCameraStrategy.setCloudPromptInterval(intervalSeconds, cloudBackupInterval)
    }

    fun restoreFactorySettings(): Long {
        return mInstaCameraStrategy.restoreFactorySettings()
    }

    fun setSingleHostInfo(singleHostCmdInfo: SingleHostCmdInfo): Long {
        return mInstaCameraStrategy.setSingleHostInfo(singleHostCmdInfo)
    }

    fun getIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return mInstaCameraStrategy.getIntervalRecCfg(intervalRecInfo)
    }

    fun setIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return mInstaCameraStrategy.setIntervalRecCfg(intervalRecInfo)
    }

    fun startStopIntervalRec(intervalRecStartStop: IntervalRecStartStop): Long {
        return mInstaCameraStrategy.startStopIntervalRec(intervalRecStartStop)
    }

    fun cancelIntervalRec(intervalRecCancel: IntervalRecCancel): Long {
        return mInstaCameraStrategy.cancelIntervalRec(intervalRecCancel)
    }

    fun getIntervalRecStatus(): Long {
        return mInstaCameraStrategy.getIntervalRecStatus()
    }

    fun getIntervalRecSceneCfg(): Long {
        return mInstaCameraStrategy.getIntervalRecSceneCfg()
    }

    fun getIntervalRecFeedbackCfg(): Long {
        return mInstaCameraStrategy.getIntervalRecFeedbackCfg()
    }

    fun setIntervalRecFeedbackCfg(intervalRecFeedback: IntervalRecFeedback): Long {
        return mInstaCameraStrategy.setIntervalRecFeedbackCfg(intervalRecFeedback)
    }

    fun getFirmwareVersionsInfo(): Long {
        return mInstaCameraStrategy.getFirmwareVersionsInfo()
    }

    fun setAudioStream(request: AudioStreamCtrl, timeoutMs: Int = -1): Long {
        return mInstaCameraStrategy.setAudioStream(request, timeoutMs)
    }

    fun setAiIntent(request: AiIntentCtrl): Long {
        return mInstaCameraStrategy.setAiIntent(request)
    }

    fun setAssistantLanguage(request: AssistantLanguageCtrl): Long {
        return mInstaCameraStrategy.setAssistantLanguage(request)
    }

    fun setUserRegion(request: UserRegionCtrl): Long {
        return mInstaCameraStrategy.setUserRegion(request)
    }

    fun bindBluetoothMacFeature(featureBluetoothMacBind: FeatureBluetoothMacBind): Long {
        return mInstaCameraStrategy.bindBluetoothMacFeature(featureBluetoothMacBind)
    }

    fun sendStreamData(streamType: StreamType, timestamp: Long, data: ByteArray) {
        mInstaCameraStrategy.sendStreamData(streamType, timestamp, data)
    }

    fun setGimbalDataCallback(gimbalDataCallback: ((StreamGimbalData) -> Unit)? = null) {
        mInstaCameraStrategy.setGimbalDataCallback(gimbalDataCallback)
    }

    fun setTrackDataCallback(trackDataCallback: ((StreamTrackData) -> Unit)? = null) {
        mInstaCameraStrategy.setTrackDataCallback(trackDataCallback)
    }

    fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long {
        return mInstaCameraStrategy.openTrackingWithRect(openTrackingWithRect)
    }

    fun cancelTracking(): Long {
        return mInstaCameraStrategy.cancelTracking()
    }

    fun setPresetComposition(setPresetComposition: SetPresetComposition): Long {
        return mInstaCameraStrategy.setPresetComposition(setPresetComposition)
    }

    fun notifySettingPage(settingPageNotify: PhotoSettingPage): Long {
        return mInstaCameraStrategy.notifySettingPage(settingPageNotify)
    }

    fun getPresetComposition(): Long {
        return mInstaCameraStrategy.getPresetComposition()
    }

    fun getPtzTrackState(): Long {
        return mInstaCameraStrategy.getPtzTrackState()
    }

    /**
     * 构建相机的一些参数
     */
    class InstaCameraParmas {
        /**
         * 相机型号
         */
        var mInstaMode: InstaMode? = null

        var mConnectionListener: ICameraConnectionListener? = null

        var mConnectType: Int = 0

        fun apply(cameraController: InstaCameraController) {
            val instaCameraStrategy = ConnectStrategyImpl()
            instaCameraStrategy.init()
            cameraController.setStrategy(instaCameraStrategy)
        }
    }


    companion object {
        fun create(): InstaCameraController {
            return InstaCameraController()
        }
    }
}
