package com.arashivision.camera

import com.arashivision.camera.InstaCameraController.InstaCameraParmas
import com.arashivision.camera.listener.IBleConnectListener
import com.arashivision.camera.listener.IBleScanListener
import com.arashivision.camera.listener.ICameraConnectionListener
import com.arashivision.camera.listener.ICameraInfoListener
import com.arashivision.camera.listener.ICameraRecordListener
import com.arashivision.camera.listener.IReconnectCallback
import com.arashivision.camera.listener.ITimelapseListener
import com.arashivision.camera.listener.IWifiProxyDataListener
import com.arashivision.camera.listener.OnStillImageListener
import com.arashivision.camera.strategy.ConnectStrategyImpl
import com.arashivision.camera.strategy.TraceUtil
import com.arashivision.camera.wifiproxy.IWifiProxyData
import com.arashivision.common.Log
import com.arashivision.fmg.response.model.FmgAngleBean
import com.arashivision.fmg.response.model.FmgButtonAbleParams
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerAutoStandbyTime
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerOnePlamShoot
import com.arashivision.fmg.response.model.FmgModel.PtzAiTrackerStandbyMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballMode
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballState
import com.arashivision.fmg.response.model.FmgModel.PtzBaksetballTransition
import com.arashivision.fmg.response.model.FmgModel.PtzEnableSaveHv
import com.arashivision.fmg.response.model.FmgModel.PtzFollowSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzGrfState
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.fmg.response.model.FmgModel.PtzHvMode
import com.arashivision.fmg.response.model.FmgModel.PtzMode
import com.arashivision.fmg.response.model.FmgModel.PtzMotorStrength
import com.arashivision.fmg.response.model.FmgModel.PtzPanoIndexFrame
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.fmg.response.model.FmgModel.PtzPitchLed
import com.arashivision.fmg.response.model.FmgModel.PtzQuickStart
import com.arashivision.fmg.response.model.FmgModel.PtzRcHorizontalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRcSpeed
import com.arashivision.fmg.response.model.FmgModel.PtzRcVerticalDir
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360
import com.arashivision.fmg.response.model.FmgModel.PtzRoll360Action
import com.arashivision.fmg.response.model.FmgModel.PtzSoundMode
import com.arashivision.fmg.response.model.FmgModel.PtzSurroundShoot
import com.arashivision.fmg.response.model.FmgModel.PtzSwitchModeWay
import com.arashivision.fmg.response.model.FmgModel.PtzTemMode
import com.arashivision.fmg.response.model.FmgModel.PtzTemState
import com.arashivision.fmg.response.model.FmgModel.PtzTrackSensitivityMode
import com.arashivision.fmg.response.model.FmgModel.PtzZoomSpeed
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean
import com.arashivision.fmg.response.model.FmgTargetFollowParams
import com.arashivision.fmg.upgrade.AITrackUpgradeConfig
import com.arashivision.inskmp.insble.callback.BleStopWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.arashivision.onecamera.OneDriver
import com.arashivision.onedriver.bean.StreamGimbalData
import com.arashivision.onedriver.packet.StreamType
import insta360.messages.OpenTrackingWithRect
import insta360.messages.SetPresetComposition
import insta360.messages.PhotoSettingPage
import insta360.messages.StreamTrackData
import com.arashivision.utils.CLogUtils
import insta360.messages.AiIntentCtrl
import insta360.messages.AssistantLanguageCtrl
import insta360.messages.AudioStreamCtrl
import insta360.messages.ButtonPressParams
import insta360.messages.ButtonPressParamsType
import insta360.messages.CalibrateGyro
import insta360.messages.CancelAngleFixed
import insta360.messages.CardLocation
import insta360.messages.CheckAuthorization
import insta360.messages.CloudStorageBindParams
import insta360.messages.CloudStorageUploadParams
import insta360.messages.ConnectToBTPeripheral
import insta360.messages.CtrlPreRecord
import insta360.messages.DataTransPortDir
import insta360.messages.DataTransportResult
import insta360.messages.DeleteFiles
import insta360.messages.DisconnectBTPeripheral
import insta360.messages.DownLoadInfo
import insta360.messages.DownloadListResultSync
import insta360.messages.FeatureBluetoothMacBind
import insta360.messages.FormatStorage
import insta360.messages.GetConnectedBTPeripheral
import insta360.messages.GetFile
import insta360.messages.GetFileExtra
import insta360.messages.GetFileFinish
import insta360.messages.GetFileList
import insta360.messages.GetGyro
import insta360.messages.GetGyroResp
import insta360.messages.GetTimelapseOptions
import insta360.messages.GimbalControl
import insta360.messages.IntervalRecCancel
import insta360.messages.IntervalRecFeedback
import insta360.messages.IntervalRecInfo
import insta360.messages.IntervalRecStartStop
import insta360.messages.LiveBroadCastOptionType
import insta360.messages.LiveOptionCtrlInfo
import insta360.messages.MultiPhotographyOptions
import insta360.messages.MultiPhotographyOptionsType
import insta360.messages.OptionType
import insta360.messages.Options
import insta360.messages.PhotographyOptionType
import insta360.messages.PhotographyOptions
import insta360.messages.RequestReceiveDataInformation
import insta360.messages.RequestSendDataInformation
import insta360.messages.RecipeShareStatus
import insta360.messages.ScanBTPeripheral
import insta360.messages.SetFavoriteList
import insta360.messages.SetFileExtra
import insta360.messages.SetKeyTimePoint
import insta360.messages.SetNetworkConfigEnable
import insta360.messages.SetTimelapseOptions
import insta360.messages.SingleHostCmdInfo
import insta360.messages.StartLiveStream
import insta360.messages.StartTimelapse
import insta360.messages.StopTimelapse
import insta360.messages.TakePicture
import insta360.messages.TestSDCardSpeed
import insta360.messages.UserRegionCtrl
import insta360.messages.WifiConnectionInfo

/**
 * insta360 camera的入口，所有的操作都调用这个类的接口
 */
class InstaCamera private constructor() {
    /****************************************Feild */
    private val mCameraController: InstaCameraController


    init {
        Log.d(
            TAG,
            "camera instance = $this"
        )
        mCameraController = InstaCameraController.Companion.create()
    }


    private object InstaCameraHolder {
        private val sInstance = InstaCamera()
    }

    /**
     * 在构造函数之后调用
     *
     * @param context
     */
    fun init() {

        val instaCameraStrategy = ConnectStrategyImpl()
        instaCameraStrategy.init()
        mCameraController.setStrategy(instaCameraStrategy)
    }

    fun setPeerDriver(peer: com.arashivision.onecamera.OneDriver?) = mCameraController.setPeerDriver(peer)
    fun getOneDriver(): com.arashivision.onecamera.OneDriver = mCameraController.getOneDriver()


    /*******************************************Method */
    /**
     * 蓝牙模式scan
     * 默认scan的超时时间为10s
     * 不自动连接
     */
    fun scan(bleScanListener: IBleScanListener) {
        mCameraController.scan(10000L, false, bleScanListener)
    }

    /**
     * 蓝牙scan，指定扫描的超时时间
     */
    fun scan(scanTimeout: Long, autoConnect: Boolean, bleScanListener: IBleScanListener) {
        mCameraController.scan(scanTimeout, autoConnect, bleScanListener)
    }

    fun scan(bleScanRuleConfigCore: BleScanRuleConfigCore, bleScanListener: IBleScanListener) {
        mCameraController.scan(bleScanRuleConfigCore, bleScanListener)
    }

    fun stopScanBle() {
        mCameraController.stopScanBle()
    }


    fun connect(
        bleDevice: BleDeviceCore,
        wakeUpAuthorizationUUID: String?,
        enableHeartBeat: Boolean,
        isUseUcd2: Boolean,
        listener: IBleConnectListener,
    ) {
        mCameraController.connectDevice(
            bleDevice,
            wakeUpAuthorizationUUID ?: "",
            enableHeartBeat,
            isUseUcd2,
            listener,
        )
    }

    /**
     * 断开连接
     */
    fun disConnect(bleDevice: BleDeviceCore) {
        mCameraController.disConnect(bleDevice)
    }

    fun disConnectBle() {
        mCameraController.disConnectBle()
    }

    fun sendDisconnectBleData() {
        mCameraController.sendDisconnectBleData()
    }

    /**
     * 唤醒蓝牙
     *
     * @param deviceName
     * @param txPower    this value must one of -55 and -59
     */
    fun wakeUpBle(mode: Int, deviceName: String, txPower: Byte) {
        mCameraController.wakeUpBle(mode, deviceName, txPower)
    }

    /**
     * 停止唤醒蓝牙
     */
    fun stopWakeupBle() {
        mCameraController.stopWakeupBle()
    }


    /**
     * 唤醒Go2蓝牙，机制和以前有所改变，现在的相机主机是从设备，需要连接后获取到bleDevice，然后通过notify再唤醒
     */
    fun wakeUpGo2Ble(bleDevice: BleDeviceCore) {
        mCameraController.wakeUpGo2Ble(bleDevice)
    }

    /**
     * 连接蓝牙并发送心跳包
     *
     * @param address  蓝牙设备
     * @param listener   listener
     */
    fun connectClassicBluetooth(bleDevice: BleDeviceCore, isBleProxy: Boolean, isHeartBeatEnable: Boolean, isUseUcd2: Boolean, listener: IBleConnectListener) {
        mCameraController.connectClassicBluetooth(bleDevice, isBleProxy, isHeartBeatEnable, isUseUcd2, listener)
    }

    fun disconnectClassicBluetooth(address: String): Boolean {
        return mCameraController.disconnectClassicBluetooth(address)
    }

    fun extendClassicConnectTimeout() {
        mCameraController.extendClassicConnectTimeout()
    }

    /**
     * 打开usb设备
     */
    fun openUsb() {
        mCameraController.openUsb()
    }

    /**
     * 打开默认端口的Wi-Fi
     * 默认超时时间为5s，并且发送心跳包
     *
     * @param addr addr
     * @param port port
     */
    fun openWifi(
        networkHandle: Long,
        to: Int,
        addr: String,
        port: Short,
        heartBeats: Boolean,
        isUseUcd2: Boolean,
        processBusyPacketEnable: Boolean = false,
    ) {
        mCameraController.openWifi(
            networkHandle,
            to,
            addr,
            port,
            heartBeats,
            isUseUcd2,
            processBusyPacketEnable
        )
    }

    fun isCameraSyncedReady(): Boolean {
        return mCameraController.isCameraSyncedReady()
    }

    fun setGlobalRequestTimeoutMs(timeoutMs: Int): Boolean {
        return mCameraController.setGlobalRequestTimeoutMs(timeoutMs)
    }

    fun setGlobalRequestRetryCount(retryCount: Int): Boolean {
        return mCameraController.setGlobalRequestRetryCount(retryCount)
    }

    /**
     * 只有在go2，关机状态下，被唤醒后，需要调用此方法
     */
    /* public int openBle(){
        return mCameraController.openBle();
    }*/
    fun closeBle() {
        mCameraController.closeBle()
    }

    fun openCameraWifi(countryChannel: Int): Long {
        return mCameraController.openCameraWifi(countryChannel)
    }

    fun closeCameraWifi(): Long {
        return mCameraController.closeCameraWifi()
    }

    fun resetCameraWifi(countryChannel: Int): Long {
        return mCameraController.resetCameraWifi(countryChannel)
    }

    /**
     * [com.arashivision.onecamera.OneDriverInfo.Request.ConnectionState]
     */
    fun setCameraWifiSeizeEnable(connectionState: Int): Long {
        return mCameraController.setCameraWifiSeizeEnable(connectionState)
    }

    fun setAvailableWifi(wifiConnectionInfo: WifiConnectionInfo): Long {
        return mCameraController.setAvailableWifi(wifiConnectionInfo)
    }

    fun setWifiConnectionInfo(wifiConnectionInfo: WifiConnectionInfo): Long {
        return mCameraController.setWifiConnectionInfo(wifiConnectionInfo)
    }

    fun getWifiConnectionInfo(): Long {
        return mCameraController.getWifiConnectionInfo()
    }

    fun setWifiMode(wifiMode: Int, countryCode: String?): Long {
        return mCameraController.setWifiMode(wifiMode, countryCode)
    }

    fun requestData(
        dir: DataTransPortDir,
        rxdatainfo: List<RequestReceiveDataInformation>? = null,
        txdatainfo: List<RequestSendDataInformation>? = null,
    ): Long {
        return mCameraController.requestData(dir, rxdatainfo, txdatainfo)
    }

    fun dataTransportFeedback(dataTransportResult: DataTransportResult): Long {
        return mCameraController.dataTransportFeedback(dataTransportResult)
    }

    fun switchWifiChannel(needScan: Int, channel: Int): Long {
        return mCameraController.switchWifiChannel(needScan, channel)
    }

    fun getWifiInterfStatus(): Long {
        return mCameraController.getWifiInterfStatus()
    }

    fun setWifiState(info: WifiConnectionInfo, wifiNetState: Int): Long {
        return mCameraController.setWifiState(info, wifiNetState)
    }

    fun setShowCloudTab(showCloudTab: Boolean): Long {
        return mCameraController.setShowCloudTab(showCloudTab)
    }

    fun setCloudPromptInterval(intervalSeconds: Long, cloudBackupInterval: Long): Long {
        return mCameraController.setCloudPromptInterval(intervalSeconds, cloudBackupInterval)
    }

    fun setPhoneInfo(manufacturer: String, model: String, osVersion: String): Long {
        return mCameraController.setPhoneInfo(manufacturer, model, osVersion)
    }

    fun getWifiMode(): Long {
        return mCameraController.getWifiMode()
    }

    fun deleteWifiHistoryInfo(ssid: String): Long {
        return mCameraController.deleteWifiHistoryInfo(ssid)
    }

    fun getWifiConnectList(): Long {
        return mCameraController.getWifiConnectList()
    }

    fun getWifiScanList(interval: Int, count: Int): Long {
        return mCameraController.getWifiScanList(interval, count)
    }

    fun startCameraLive(): Long {
        return mCameraController.startCameraLive()
    }

    fun stopCameraLive(): Long {
        return mCameraController.stopCameraLive()
    }

    fun requestP3StaticStreamData(): Long {
        return mCameraController.requestP3StaticStreamData()
    }

    fun prepareCameraLive(): Long {
        return mCameraController.prepareCameraLive()
    }

    fun setAccessCameraFileState(accessState: Int): Long {
        return mCameraController.setAccessCameraFileState(accessState)
    }

    /**
     *
     */
    fun close() {
        mCameraController.close()
    }

    fun obtainCameraRtosStatus() {
        mCameraController.obtainCameraRtosStatus()
    }

    /**
     * 拍照，默认会存储
     */
    fun tackPicture(takePicture: TakePicture, withoutStorage: Boolean = false) {
        mCameraController.takePicture(takePicture, withoutStorage)
    }

    fun stopTackPicture(): Long {
        return mCameraController.stopTakePicture()
    }

    fun writeWifiProxyData(wifiProxyData: IWifiProxyData) {
        mCameraController.writeWifiProxyData(wifiProxyData)
    }

    fun previewStream(startStreamingParam: StartLiveStream, offset: String) {
        mCameraController.previewStream(startStreamingParam, offset)
    }

    fun closePreviewStream() {
        mCameraController.closePreviewStream()
    }

    fun requestStreamIframe() {
        mCameraController.requestStreamIframe()
    }

    fun stopUsbcardBackup(): Long {
        return mCameraController.stopUsbcardBackup()
    }

    /**
     * 获取闪传状态
     */
    fun getQuickReaderStatus(): Long {
        return mCameraController.getQuickReaderStatus()
    }

    /**
     * 开始录制视频
     *
     *
     * 如果livepush为true，一定要设置StartCaptureWithoutStorage
     *
     * @param recordOriginVideo 原始视频录制
     * @param livePush          live支持
     * @param mode              [com.arashivision.onecamera.OneDriverInfo.Options.CaptureMode]
     */
    fun startRecord(
        recordOriginVideo: Boolean,
        livePush: Boolean,
        mode: Int,
    ) {
        mCameraController.startRecord(recordOriginVideo, livePush, mode)
    }


    fun stopRecord(mode: Int, extraData: ByteArray) {
        mCameraController.stopRecord(mode, extraData)
    }

    fun setPreRecord(ctrlPreRecord: CtrlPreRecord): Long {
        return mCameraController.setPreRecord(ctrlPreRecord)
    }

    fun startHdrCapture() {
        mCameraController.startHdrCapture()
    }

    fun stopHdrCapture(extraData: ByteArray) {
        mCameraController.stopHdrCapture(extraData)
    }

    fun calibrateGyro(calibrateGyro: CalibrateGyro): Long {
        return mCameraController.calibrateGyro(calibrateGyro)
    }

    val captureStatus: Long
        get() = getCaptureStatus(RequestOptions())

    fun getCaptureStatus(requestOptions: RequestOptions): Long {
        return mCameraController.getCaptureStatus(requestOptions)
    }

    fun setSyncCaptureMode(mode: Int): Long {
        return mCameraController.setSyncCaptureMode(mode)
    }

    fun getSyncCaptureMode(): Long {
        return mCameraController.getSyncCaptureMode()
    }

    fun pauseRecord(): Long {
        return mCameraController.pauseRecord()
    }

    /**
     * 设置高温模式
     *
     * @param mode {@StandbyMode}
     * @return long
     */
    fun setSyncStandByMode(mode: Int): Long {
        return mCameraController.setStandbyMode(mode)
    }


    fun setGyroRebaseMatrix(matrix3: FloatArray) {
        mCameraController.setGyroRebaseMatrix(matrix3)
    }

    fun startTimelapse(startTimelapse: StartTimelapse) {
        startTimelapseDelay(startTimelapse, 0)
    }

    fun startTimelapseDelay(startTimelapse: StartTimelapse, toMs: Int) {
        mCameraController.startTimelapseDelay(startTimelapse, toMs)
    }

    fun stopTimelapse(obj: StopTimelapse) {
        mCameraController.stopTimelapse(obj)
    }

    fun setAppId(appId: String): Long {
        return mCameraController.setAppId(appId)
    }

    fun setShutdown(): Long {
        return mCameraController.setShutdown()
    }

    fun cancelAngleFixed(cancelAngleFixed: CancelAngleFixed): Long {
        return mCameraController.cancelAngleFixed(cancelAngleFixed)
    }

    fun sendOpenCameraClassicBluetooth(connectType: Int): Long {
        return mCameraController.sendOpenCameraClassicBluetooth(connectType)
    }

    fun sendAiVoiceReady(isHuawei: Boolean = false): Long {
        return mCameraController.sendAiVoiceReady(isHuawei)
    }

    fun checkAuthorization(
        checkAuthorization: CheckAuthorization,
        requestOptions: RequestOptions = RequestOptions(),
    ): Long {
        return mCameraController.checkAuthorization(checkAuthorization, requestOptions)
    }

    /**
     * [com.arashivision.onecamera.OneDriverInfo.Notification.AuthorizationOperationType]
     */
    fun requestAuthorization(authorizationOperationType: Int): Long {
        return mCameraController.requestAuthorization(authorizationOperationType)
    }

    fun cancelAuthorization(requestOptions: RequestOptions = RequestOptions()): Long {
        return mCameraController.cancelAuthorization(requestOptions)
    }

    /**
     * [com.arashivision.onecamera.OneDriverInfo.Notification.AuthorizationOperationType]
     */
    fun cancelRequestAuthorization(authorizationOperationType: Int): Long {
        return mCameraController.cancelRequestAuthorization(authorizationOperationType)
    }

    fun syncCaptureStatus(): Long {
        return mCameraController.syncCaptureStatus()
    }

    fun setGPSData(gpsData: ByteArray): Long {
        return mCameraController.setGpsData(gpsData)
    }

//    /**
//     * 同步获取options
//     */
//    fun getOptions(optionList: List<OptionType>): Options? {
//        return mCameraController.getOptions(optionList)
//    }

    /**
     * 异步获取options
     *
     * @param optionList opetionsList
     */
    fun getOptionsSync(optionList: List<OptionType>): Long {
        return getOptionsSync(optionList, RequestOptions())
    }

    fun getOptionsSync(optionList: List<OptionType>, requestOptions: RequestOptions): Long {
        return mCameraController.getOptionsSync(optionList, requestOptions)
    }

    fun negotiateEncryption(onComplete: (Boolean) -> Unit) {
        mCameraController.negotiateEncryption(onComplete)
    }

    fun setOptionAsync(optionList: List<OptionType>, options: Options): Long {
        return setOptionAsync(optionList, options, RequestOptions())
    }

    fun setOptionAsync(
        optionList: List<OptionType>,
        options: Options,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.setOptions(optionList, options, requestOptions)
    }

//    fun getPhotoOptions(funcMode: Int, options: List<PhotographyOptionType>): PhotographyOptions? {
//        return mCameraController.getPhotoOptions(funcMode, options)
//    }

//    fun setPhotoOptions(
//        funcMode: Int,
//        optionList: List<PhotographyOptionType>,
//        options: PhotographyOptions
//    ): Long {
//        return mCameraController.setPhotoOptions(funcMode, optionList, options)
//    }

    fun setPhotoOptionsSync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
    ): Long {
        return setPhotoOptionsSync(funcMode, optionTypes, options, RequestOptions())
    }

    fun setPhotoOptionsSync(
        funcMode: Int,
        optionTypes: List<PhotographyOptionType>,
        options: PhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.setPhotoOptionsSync(
            funcMode,
            optionTypes,
            options,
            requestOptions
        )
    }

    fun getPhotoOptionsAsync(funcMode: Int, options: MutableList<PhotographyOptionType>): Long {
        return getPhotoOptionsAsync(funcMode, options, RequestOptions())
    }

    fun getPhotoOptionsAsync(
        funcMode: Int,
        options: MutableList<PhotographyOptionType>,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.getPhotoOptionsAsync(funcMode, options, requestOptions)
    }

    fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        opetions: List<ButtonPressParamsType>,
    ): Long {
        return mCameraController.getButtonPressParams(
            buttonPressMode,
            buttonPressType,
            opetions,
            RequestOptions()
        )
    }

    fun getButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        opetions: List<ButtonPressParamsType>,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.getButtonPressParams(
            buttonPressMode,
            buttonPressType,
            opetions,
            requestOptions
        )
    }

    fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        buttonPressParams: ButtonPressParams,
    ): Long {
        return mCameraController.setButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            buttonPressParams,
            RequestOptions()
        )
    }

    fun setButtonPressParams(
        buttonPressMode: Int,
        buttonPressType: Int,
        optionType: List<ButtonPressParamsType>,
        buttonPressParams: ButtonPressParams,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.setButtonPressParams(
            buttonPressMode,
            buttonPressType,
            optionType,
            buttonPressParams,
            requestOptions
        )
    }

//    fun setTimelapseOptions(info: SetTimelapseOptions): Int {
//        return mCameraController.setTimelapseOptions(info)
//    }

    fun setTimelapseOptionsASync(info: SetTimelapseOptions): Long {
        return setTimelapseOptionsASync(info, RequestOptions())
    }

    fun setTimelapseOptionsASync(
        info: SetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.setTimelapseOptionsASync(info, requestOptions)
    }

//    fun getTimelapseOption(getTimelapseOptions: GetTimelapseOptions): TimelapseOptions? {
//        return mCameraController.getTimelapseOption(getTimelapseOptions)
//    }

    fun getTimelapseOptionAsync(getTimelapseOptions: GetTimelapseOptions): Long {
        return getTimelapseOptionAsync(getTimelapseOptions, RequestOptions())
    }

    fun getTimelapseOptionAsync(
        getTimelapseOptions: GetTimelapseOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.getTimelapseOptionAsync(getTimelapseOptions, requestOptions)
    }

    fun setCameraLiveOptionAsync(
        optionList: List<LiveBroadCastOptionType>,
        options: LiveOptionCtrlInfo,
    ): Long {
        return mCameraController.setCameraLiveOptionsSync(optionList, options, RequestOptions())
    }

    fun getCameraLiveOptionsAsync(optionList: List<LiveBroadCastOptionType>): Long {
        return mCameraController.getCameraLiveOptionsSync(optionList, RequestOptions())
    }

    fun startBulletTime(): Long {
        return mCameraController.startBulletTime()
    }


    fun stopBulletTime(extraData: ByteArray) {
        mCameraController.stopBulletTime(extraData)
    }


    fun setFileExtra(obj: SetFileExtra): Long {
        return mCameraController.setFileExtra(obj)
    }

    fun getFileExtra(obj: GetFileExtra): Long {
        return mCameraController.getFileExtra(obj)
    }

    fun recipeShareStatus(obj: RecipeShareStatus): Long {
        return mCameraController.recipeShareStatus(obj)
    }

    fun changeConnectType(type: Int) {
        mCameraController.changeConnectType(type)
    }

    /**
     * 设置录制时候的关键点
     *
     * @param keyTimePoint keytime
     */
    fun setKeyTimePoint(keyTimePoint: SetKeyTimePoint): Long {
        return mCameraController.setKeyTimePoint(keyTimePoint)
    }

    /**
     * 释放
     */
    fun release() {
        mCameraController.release()
    }


    /**
     * 抹去sd卡内容
     */
    fun ersaSDcard(): Long {
        return mCameraController.ersaSDcasrd()
    }

    /**
     * 格式化存储（按类型区分内置/外置）
     */
    fun formatStorage(formatStorage: FormatStorage): Long {
        return mCameraController.formatStorage(formatStorage)
    }

    /**
     * 设置主存储
     */
    fun setMainStorage(cardLocation: CardLocation): Long {
        return mCameraController.setMainStorage(cardLocation)
    }


    fun reboot(): Long {
        return mCameraController.reboot()
    }

    fun notifyOTAError(): Long {
        return mCameraController.notifyOTAError()
    }

    fun closeWifi() {
        mCameraController.closeWifi()
    }


    fun getFileInfoList(cardLocation: CardLocation): Long {
        return mCameraController.getFileInfoList(cardLocation)
    }

    fun getEditInfoList(): Long {
        return mCameraController.getEditInfoList()
    }

    fun getTranslateConfig(timeoutMs: Int = -1): Long {
        return mCameraController.getTranslateConfig(timeoutMs)
    }


    fun getFileList(fileList: GetFileList): Long {
        return mCameraController.getFileList(fileList)
    }

    fun getFileListIncludeRecording(fileList: GetFileList): Long {
        return mCameraController.getFileListIncludeRecording(fileList)
    }

    fun getFile(getFile: GetFile): Long {
        return mCameraController.getFile(getFile)
    }

    fun setFavoriteList(setFavoriteList: SetFavoriteList): Long {
        return mCameraController.setFavoriteList(setFavoriteList)
    }

    fun packFile(getFile: GetFile): Long {
        return mCameraController.packFile(getFile)
    }

    fun getFileFinish(getFileFinish: GetFileFinish): Long {
        return mCameraController.getFileFinish(getFileFinish)
    }

    fun setTransferStatus(getFileFinish: GetFileFinish): Long {
        return mCameraController.setTransferStatus(getFileFinish)
    }

    fun getPort(): Int {
        return mCameraController.getPort()
    }


    fun deleteFileList(deleteFiles: DeleteFiles): Long {
        return mCameraController.deleteFileList(deleteFiles)
    }

    fun getGyro(getGyro: GetGyro): GetGyroResp? {
        return mCameraController.getGyro(getGyro)
    }

    fun getGyroSync(getGyro: GetGyro): Long {
        return mCameraController.getGyroSync(getGyro)
    }


    /**
     * 蓝牙遥控器相关接口
     */
    fun scanBT(obj: ScanBTPeripheral): Long {
        return mCameraController.scanBT(obj)
    }

    fun connectBT(obj: ConnectToBTPeripheral): Long {
        return mCameraController.connectBT(obj)
    }

    fun disConnectBT(obj: DisconnectBTPeripheral): Long {
        return mCameraController.disConnectBT(obj)
    }

    fun getConnectBT(obj: GetConnectedBTPeripheral): Long {
        return mCameraController.getConnectBT(obj)
    }

    /**
     * 设置flow state的状态
     *
     * @return
     */
    fun setFlowStateEnable(enable: Int): Long {
        return mCameraController.setFlowStateEnable(enable)
    }

    /**
     * 获取flow state的状态
     *
     * @return
     */
    fun getFlowStateEnable(): Long {
        return mCameraController.getFlowStateEnable()
    }

    /**
     * 获取暗光状态
     *
     * @return
     */
    fun getDarkEisStatus(): Long {
        return mCameraController.getDarkEisStatus()
    }

    // 更新下载进度
    fun updateDownloadInfo(downLoadInfo: DownLoadInfo): Long {
        return mCameraController.updateDownloadInfo(downLoadInfo)
    }

    // 获取待下载列表
    fun getDownloadFileList(fileList: GetFileList): Long {
        return mCameraController.getDownloadFileList(fileList)
    }

    // 快传创建下载任务后状态同步
    fun notifyGetDownloadFileListResult(addListResultSync: DownloadListResultSync): Long {
        return mCameraController.notifyGetDownloadFileListResult(addListResultSync)
    }

    fun setGimbalControl(gimbalControl: GimbalControl): Long {
        return mCameraController.setGimbalControl(gimbalControl)
    }

    /**
     * 设置multi options,类似option
     *
     * @param funcMode 指定设置的功能，于photooptions的相同[com.arashivision.onecamera.OneDriverInfo.PhotoOptionsConstants.FunctionMode]
     * @param sensorMode 镜头的类型[com.arashivision.onecamera.OneDriverInfo.MultiVideoMode]
     * @param multiPhotoOptions [MultiPhotoOptions]
     */
    fun setMultiVideoOptions(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        multiPhotoOptions: MultiPhotographyOptions,
    ): Long {
        return setMultiVideoOptions(
            funcMode,
            sensorMode,
            optionList,
            multiPhotoOptions,
            RequestOptions()
        )
    }

    fun setMultiVideoOptions(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        multiPhotoOptions: MultiPhotographyOptions,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.setMultiVideoMode(
            funcMode,
            sensorMode,
            optionList,
            multiPhotoOptions,
            requestOptions
        )
    }

    /**
     * 获取多镜头模式
     */
    fun getMultiVideoOptions(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
    ): Long {
        return getMultiVideoOptions(funcMode, sensorMode, optionList, RequestOptions())
    }

    fun getMultiVideoOptions(
        funcMode: Int,
        sensorMode: Int,
        optionList: List<MultiPhotographyOptionsType>,
        requestOptions: RequestOptions,
    ): Long {
        return mCameraController.getMultiVideoMode(funcMode, sensorMode, optionList, requestOptions)
    }

    /**
     * 设置镜头类型
     * [com.arashivision.onecamera.OneDriverInfo.MultiVideoMode]
     */
    fun activeSensor(sensorType: Int): Long {
        return mCameraController.setSingleSensor(sensorType)
    }

    val sensorMode: Long
        /**
         * 获取当前的镜头模式
         */
        get() = getSensorMode(RequestOptions())

    fun getSensorMode(requestOptions: RequestOptions): Long {
        return mCameraController.getSingleSensor(requestOptions)
    }

    /********************************Test */
    fun startWifiStatusTest() {
        mCameraController.startWifiStatusTest()
    }

    fun startBleStatusTest() {
        mCameraController.startBleStatusTest()
    }

    fun startLedTest() {
        mCameraController.startLedTest()
    }

    fun openIperf(mode: Int) {
        mCameraController.openIperf(mode)
    }

    fun closeIperf() {
        mCameraController.closeIperf()
    }

    val iperfAverage: Unit
        get() {
            mCameraController.getIperfAverage()
        }


    fun testUsbSpeed(testSDCardSpeed: TestSDCardSpeed) {
        mCameraController.testUsbSpeed(testSDCardSpeed)
    }

    fun startSpeakerTest() {
        mCameraController.startSpeakerTest()
    }

    val testButtonState: Unit
        get() {
            mCameraController.testButtonState()
        }

    /**
     * 触点测试
     */
    fun startContactTest() {
        mCameraController.startContactTest()
    }

    /**
     * 颜色效果测试
     */
    fun startColorTest() {
        mCameraController.startColorTest()
    }


    fun testSpeedTypec() {
        mCameraController.testTypec()
    }

    fun stopLCDTest() {
        mCameraController.stopLCDTest()
    }

    /**
     * 震动
     */
    fun vibrateTest(): Long {
        return mCameraController.vibrateTest()
    }

    /**
     * 停止震动
     */
    fun vibrateStop(): Long {
        return mCameraController.vibrateStop()
    }

    /**
     * dsp链路测试
     */
    fun dspLinkTest(): Long {
        return mCameraController.dspLinkTest()
    }

    /**
     * 白平衡矫正测试
     */
    fun whiteBlanceTest(): Long {
        return mCameraController.whiteBlanceTest()
    }

    /**
     * 黑电平校正
     */
    fun blackLevelTest(): Long {
        return mCameraController.blackLevelTest()
    }

    /**
     * 坏点检测
     */
    fun badPointTest(): Long {
        return mCameraController.badPointTest()
    }

    /**
     * 获取老化状态
     */
    fun getAgeingTestStatus(): Long {
        return mCameraController.getAgeTestStatus()
    }


    /**
     * 开启timeshift
     */
    fun startTimeShift() {
        mCameraController.startTimeShift()
    }

    /**
     * 停止timeshift
     *
     * @param extraData extra
     */
    fun stopTimeShift(extraData: ByteArray) {
        mCameraController.stopTimeShift(extraData)
    }


    fun debug(debug: Boolean) {
        TraceUtil.TRACE = debug
    }

    /**
     * 相机返回的心跳包日志打印的接口
     *
     * @param debug
     */
    fun setCameraWifiHeartDebug(debug: Boolean) {
        mCameraController.setCameraWifiHeartDebug(debug)
    }

    /**
     * 校验分辨率是否支持
     *
     * @param videoResolution [com.arashivision.onecamera.OneDriverInfo.Options.VideoResolution]
     */
    fun checkVideoSupport(videoResolution: Int): Boolean {
        return mCameraController.checkVideoSupport(videoResolution)
    }

    /**
     * 校验是否支持分辨率
     * 宽，高，fps
     */
    fun checkVideoSupport(width: Int, height: Int, fps: Int): Boolean {
        return mCameraController.checkVideoSupport(width, height, fps)
    }

    /**
     * go2充电盒测试
     * @param commandType [com.arashivision.onecamera.OneDriverInfo.ChargingBoxType]
     *
     * 返回的结果 [com.arashivision.onecamera.cameraresponse.ChargingBoxResp]
     * 其中的状态类型 state [com.arashivision.onecamera.OneDriverInfo.ChargingBoxRespType]
     *
     */
    fun chargingBox(commandType: Int, datas: ByteArray): Long {
        return mCameraController.chargingBox(commandType, datas)
    }

    /**
     * go2充电盒测试，默认不需要向相机写入数据
     */
    fun chargingBox(commandType: Int): Long {
        val datas = byteArrayOf(0x01)
        return mCameraController.chargingBox(commandType, datas)
    }

    /**
     * 上传json脚本文件
     */
    fun uploadScriptJson(jsonFile: ByteArray): Long {
        return mCameraController.uploadScriptJson(jsonFile)
    }

    /**
     * 上传cmd脚本文件
     */
    fun uploadScriptCmd(cmdFile: ByteArray): Long {
        return mCameraController.uploadScriptCmd(cmdFile)
    }

    /**
     * 刷新脚本
     */
    fun scriptRefersh(): Long {
        return mCameraController.scriptRefersh()
    }

    /**
     * 运行脚本
     */
    fun scriptRun(): Long {
        return mCameraController.scriptRun()
    }

    /**
     * 3A 工厂模式
     * @return
     */
    fun setAAAFactoryMode(): Long {
        return mCameraController.setAAAFactoryMode()
    }

    /**
     * 3A普通模式
     * @return
     */
    fun setAAANornamMode(): Long {
        return mCameraController.setAAANormalMode()
    }

    /**
     * 获取白平衡测试状态
     * 结果：[com.arashivision.onecamera.cameraresponse.WhiteBlanceStatusResp]
     * @return
     */
    fun getWhiteBlanceStatus(): Long {
        return mCameraController.getWhiteBlanceStatus()
    }

    /**
     * 获取SFR执行状态
     * @return
     */
    fun getSFRStatus(): Long {
        return mCameraController.getSFRStatus()
    }

    fun getSFRResult(): Long {
        return mCameraController.getSFRResult()
    }

    fun getCloudStorageUploadStatus(): Long {
        return mCameraController.getCloudStorageUploadStatus()
    }

    fun setCloudStorageUploadStatus(params: CloudStorageUploadParams): Long {
        return mCameraController.setCloudStorageUploadStatus(params)
    }

    fun getCloudStorageBindStatus(): Long {
        return mCameraController.getCloudStorageBindStatus()
    }

    fun setCloudStorageBindStatus(params: CloudStorageBindParams): Long {
        return mCameraController.setCloudStorageBindStatus(params)
    }

    fun setNetworkConfigEnable(params: SetNetworkConfigEnable): Long {
        return mCameraController.setNetworkConfigEnable(params)
    }

    fun syncAccurateTime(): Long {
        return mCameraController.syncAccurateTime()
    }

    fun restoreFactorySettings(): Long {
        return mCameraController.restoreFactorySettings()
    }

    fun setSingleHostInfo(singleHostCmdInfo: SingleHostCmdInfo): Long {
        return mCameraController.setSingleHostInfo(singleHostCmdInfo)
    }

    fun getIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return mCameraController.getIntervalRecCfg(intervalRecInfo)
    }

    fun setIntervalRecCfg(intervalRecInfo: IntervalRecInfo): Long {
        return mCameraController.setIntervalRecCfg(intervalRecInfo)
    }

    fun startStopIntervalRec(intervalRecStartStop: IntervalRecStartStop): Long {
        return mCameraController.startStopIntervalRec(intervalRecStartStop)
    }

    fun cancelIntervalRec(intervalRecCancel: IntervalRecCancel): Long {
        return mCameraController.cancelIntervalRec(intervalRecCancel)
    }

    fun getIntervalRecStatus(): Long {
        return mCameraController.getIntervalRecStatus()
    }

    fun getIntervalRecSceneCfg(): Long {
        return mCameraController.getIntervalRecSceneCfg()
    }

    fun getIntervalRecFeedbackCfg(): Long {
        return mCameraController.getIntervalRecFeedbackCfg()
    }

    fun setIntervalRecFeedbackCfg(intervalRecFeedback: IntervalRecFeedback): Long {
        return mCameraController.setIntervalRecFeedbackCfg(intervalRecFeedback)
    }

    fun setAudioStream(request: AudioStreamCtrl, timeoutMs: Int = -1): Long {
        return mCameraController.setAudioStream(request, timeoutMs)
    }

    fun setAiIntent(request: AiIntentCtrl): Long {
        return mCameraController.setAiIntent(request)
    }

    fun setAssistantLanguage(request: AssistantLanguageCtrl): Long {
        return mCameraController.setAssistantLanguage(request)
    }

    fun setUserRegion(request: UserRegionCtrl): Long {
        return mCameraController.setUserRegion(request)
    }

    fun bindBluetoothMacFeature(featureBluetoothMacBind: FeatureBluetoothMacBind): Long {
        return mCameraController.bindBluetoothMacFeature(featureBluetoothMacBind)
    }

    fun sendStreamData(streamType: StreamType, timestamp: Long, data: ByteArray) {
        mCameraController.sendStreamData(streamType, timestamp, data)
    }


    fun getFirmwareVersionsInfo(): Long {
        return mCameraController.getFirmwareVersionsInfo()
    }

    /******************************** FMG  */
    fun getFmgDeviceInfo(): Long {
        return mCameraController.getFmgDeviceInfo()
    }

    fun getFmgUUID(): Long {
        return mCameraController.getFmgUUID()
    }

    fun getFmgActiveTime(): Long {
        return mCameraController.getFmgActiveTime()
    }

    fun setFmgActiveTime(activeTime: Long): Long {
        return mCameraController.setFmgActiveTime(activeTime)
    }

    /**
     * 由app发送给云台（缩放结束后发送此命令即可，云台需要app的变焦倍数）
     * @param scale 如8.1X发送81
     * @return
     */
    fun setFmgZoomScale(scale: Short) {
        mCameraController.setFmgZoomScale(scale)
    }

    fun getFmgAllSettings(): Long {
        return mCameraController.getFmgAllSettings()
    }

    fun setFmgSettingsMode(mode: PtzMode): Long {
        return mCameraController.setFmgSettingsMode(mode)
    }

    fun setFmgSettingFollowSpeed(followSpeed: PtzFollowSpeed): Long {
        return mCameraController.setFmgSettingFollowSpeed(followSpeed)
    }

    fun setFmgSettingRcSpeed(rcSpeed: PtzRcSpeed): Long {
        return mCameraController.setFmgSettingRcSpeed(rcSpeed)
    }

    fun setFmgSettingZoomSpeed(zoomSpeed: PtzZoomSpeed): Long {
        return mCameraController.setFmgSettingZoomSpeed(zoomSpeed)
    }

    fun setFmgSettingRcHorizontalDir(horizontalDir: PtzRcHorizontalDir): Long {
        return mCameraController.setFmgSettingRcHorizontalDir(horizontalDir)
    }

    fun setFmgSettingRcVerticalDir(verticalDir: PtzRcVerticalDir): Long {
        return mCameraController.setFmgSettingRcVerticalDir(verticalDir)
    }

    fun setFmgSettingSoundEnable(soundMode: PtzSoundMode): Long {
        return mCameraController.setFmgSettingSoundEnable(soundMode)
    }

    fun setFmgSettingHvMode(hvMode: PtzHvMode): Long {
        return mCameraController.setFmgSettingHvMode(hvMode)
    }

    fun SetFmgSettingSwitchModeWay(modeWay: PtzSwitchModeWay): Long {
        return mCameraController.setFmgSettingSwitchModeWay(modeWay)
    }

    fun setSettingLedBrightness(brightness: Int): Long {
        return mCameraController.setSettingLedBrightness(brightness)
    }

    fun setFmgSettingMotorStrength(motorStrength: PtzMotorStrength): Long {
        return mCameraController.setFmgSettingMotorStrength(motorStrength)
    }

    fun setFmgSettingRoll360(roll360: PtzRoll360): Long {
        return mCameraController.setFmgSettingRoll360(roll360)
    }

    fun setFmgSettingQuickStart(quickStart: PtzQuickStart): Long {
        return mCameraController.setFmgSettingQuickStart(quickStart)
    }

    fun setFmgSettingPitchLed(pitchLed: PtzPitchLed): Long {
        return mCameraController.setFmgSettingPitchLed(pitchLed)
    }

    fun setFmgSettingEnableSaveHv(enableSaveHv: PtzEnableSaveHv): Long {
        return mCameraController.setFmgSettingEnableSaveHv(enableSaveHv)
    }

    fun setFmgSettingSurroundShoot(surroundShoot: PtzSurroundShoot): Long {
        return mCameraController.setFmgSettingSurroundShoot(surroundShoot)
    }

    fun getFmgVerticalTrimDegree(): Long {
        return mCameraController.getFmgVerticalTrimDegree()
    }

    fun setFmgVerticalTrimDegree(degree: Float): Long {
        return mCameraController.setFmgVerticalTrimDegree(degree)
    }

    fun startOrUpdateFmgTargetFollow(followParams: FmgTargetFollowParams) {
        mCameraController.startOrUpdateFmgTargetFollow(followParams)
    }

    fun speculateFmgTargetFollow(followParams: FmgTargetFollowParams) {
        mCameraController.speculateFmgTargetFollow(followParams)
    }

    fun compositionFmgTargetFollow() {
        mCameraController.compositionFmgTargetFollow()
    }

    fun lostFmgTargetFollow() {
        mCameraController.lostFmgTargetFollow()
    }

    fun exitFmgTargetFollow() {
        mCameraController.exitFmgTargetFollow()
    }

    fun startFmgCalibrate(): Long {
        return mCameraController.startFmgCalibrate()
    }

    fun startFmgUpgrade(
        fileData: ByteArray,
        writeWithoutResponse: Boolean,
        mtu: Int,
        writeExtraBleOTA: Boolean,
    ): Long {
        return mCameraController.startFmgUpgrade(
            fileData,
            writeWithoutResponse,
            mtu,
            writeExtraBleOTA
        )
    }

    fun cancelFmgUpgrade() {
        mCameraController.cancelFmgUpgrade()
    }

    fun startFmgAITrackUpgrade(upgradeConfig: AITrackUpgradeConfig): Long {
        return mCameraController.startFmgAITrackUpgrade(upgradeConfig)
    }

    fun cancelFmgAITrackUpgrade() {
        mCameraController.cancelFmgAITrackUpgrade()
    }

    fun setFmgButtonEnable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return mCameraController.setFmgButtonEnable(fmgButtonAbleParams)
    }

    fun setFmgButtonDisable(fmgButtonAbleParams: FmgButtonAbleParams): Long {
        return mCameraController.setFmgButtonDisable(fmgButtonAbleParams)
    }

    fun setDwSrcEventState(enable: Boolean): Long {
        return mCameraController.setDwSrcEventState(enable)
    }

    fun getFmgButtonEnableStates(): Long {
        return mCameraController.getFmgButtonEnableStates()
    }

    /**
     * 获取 中心点标定值
     * @return
     */
    fun getFmgMidCal(): Long {
        return mCameraController.getFmgMidCal()
    }

    /**
     * 设置 中心点标定值
     * @param euler 欧拉角数据[yaw, pitch, roll]
     * @return
     */
    fun setFmgMidCal(euler: DoubleArray): Long {
        return mCameraController.setFmgMidCal(euler)
    }

    /**
     * 获取 运动控制参数
     * @param state
     * @return
     */
    fun getFmgRunControl(state: PtzGrfState): Long {
        return mCameraController.getFmgRunControl(state)
    }

    /**
     * 设置 运动控制参数
     * state == GRF_ANGLE 时 yaw, pitch, roll 为位置信息
     * state == GRF_SPEED 时 yaw, pitch, roll 为速度信息
     * @param state
     * @param yaw
     * @param pitch
     * @param roll
     * @return
     */
    fun setFmgRunControl(state: PtzGrfState, yaw: Float, pitch: Float, roll: Float): Long {
        return mCameraController.setFmgRunControl(state, yaw, pitch, roll)
    }

    fun setFmgVirtualRc(x: Short, y: Short): Long {
        return mCameraController.setFmgVirtualRc(x, y)
    }

    /**
     * 设置延迟摄影
     * @param mode
     * @param state
     * @param duration
     * @return
     */
    fun setFmgTimeElapse(mode: PtzTemMode, state: PtzTemState, duration: Int): Long {
        return mCameraController.setFmgTimeElapse(mode, state, duration)
    }

    fun setFmgAngleSeq(paramsList: List<FmgSetAngleSeqBean>): Long {
        return mCameraController.setFmgAngleSeq(paramsList)
    }

    fun ptzBasketballA2G(
        mode: PtzBaksetballMode,
        state: PtzBaksetballState,
        transition: PtzBaksetballTransition,
    ): Long {
        return mCameraController.ptzBasketballA2G(mode, state, transition)
    }

    fun ptzBasketballInitNoBask() {
        mCameraController.ptzBasketballInitNoBask()
    }

    fun setPanoIndex(index: Short, frame: PtzPanoIndexFrame): Long {
        return mCameraController.setPanoIndex(index, frame)
    }

    fun setFmgAction(action: Short): Long {
        return mCameraController.setFmgAction(action)
    }

    fun setFmgAppStatus(recording: Short, touch: Short): Long {
        return mCameraController.setFmgAppStatus(recording, touch)
    }

    fun setFmgRoll360Action(action: PtzRoll360Action): Long {
        return mCameraController.setFmgRoll360Action(action)
    }

    fun getAiTrackerDeviceInfo(): Long {
        return mCameraController.getAiTrackerDeviceInfo()
    }

    fun setAiTrackerStandbyMode(standbyMode: PtzAiTrackerStandbyMode): Long {
        return mCameraController.setAiTrackerStandbyMode(standbyMode)
    }

    fun setAiTrackerAutoStandbyTime(standbyTime: PtzAiTrackerAutoStandbyTime): Long {
        return mCameraController.setAiTrackerAutoStandbyTime(standbyTime)
    }

    fun setAiTrackerOnePlamShoot(onePlamShoot: PtzAiTrackerOnePlamShoot): Long {
        return mCameraController.setAiTrackerOnePlamShoot(onePlamShoot)
    }

    fun getAiTrackerSettings(): Long {
        return mCameraController.getAiTrackerSettings()
    }

    fun updateHbRecMode(mode: PtzRecMode) {
        mCameraController.updateHbRecMode(mode)
    }

    fun startFmgHeartBeat() {
        mCameraController.startFmgHeartBeat()
    }

    fun stopFmgHeartBeat() {
        mCameraController.stopFmgHeartBeat()
    }

    fun resetFmgDefaultSettings(): Long {
        return mCameraController.resetFmgDefaultSettings()
    }

    fun getFmgTrackSensitivityMode(): Long {
        return mCameraController.getFmgTrackSensitivityMode()
    }

    fun setFmgTrackSensitivityMode(mode: PtzTrackSensitivityMode): Long {
        return mCameraController.setFmgTrackSensitivityMode(mode)
    }

    fun setFmgPano(mode: PtzPanoMode): Long {
        return mCameraController.setFmgPano(mode)
    }

    fun startFmgRecMode(mode: PtzRecMode): Long {
        return mCameraController.startFmgRecMode(mode)
    }

    fun stopFmgRecMode(mode: PtzRecMode): Long {
        return mCameraController.stopFmgRecMode(mode)
    }

    fun initFmgRecMode(mode: PtzRecMode): Long {
        return mCameraController.initFmgRecMode(mode)
    }

    fun fmgVibration(): Long {
        return mCameraController.fmgVibration()
    }

    fun enableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return mCameraController.enableFmgHandDrag(list)
    }

    fun disableFmgHandDrag(list: ArrayList<PtzHandDrag>): Long {
        return mCameraController.disableFmgHandDrag(list)
    }

    fun setFmgCameraFacing(frame: Short): Long {
        return mCameraController.setFmgCameraFacing(frame)
    }

    fun backCenter(): Long {
        return mCameraController.backCenter()
    }

    fun updateFmgAppImuAngle(fmgAngleBean: FmgAngleBean) {
        mCameraController.updateFmgAppImuAngle(fmgAngleBean)
    }

    fun updateFmgAppImuInfo(floats: FloatArray) {
        mCameraController.updateFmgAppImuInfo(floats)
    }

    fun getFmgAnalyticsData(): Long {
        return mCameraController.getFmgAnalyticsData()
    }

    fun clearFmgAnalyticsData(): Long {
        return mCameraController.clearFmgAnalyticsData()
    }

    fun getFmgBleAnalyticsData(): Long {
        return mCameraController.getFmgBleAnalyticsData()
    }

    fun clearFmgBleAnalyticsData(): Long {
        return mCameraController.clearFmgBleAnalyticsData()
    }

    fun setNativeLoggerCallback(loggerCallback: CLogUtils.ILoggerCallback) {
        mCameraController.setNativeLoggerCallback(loggerCallback)
    }

    fun addConnectionListener(connectionListener: ICameraConnectionListener) {
        mCameraController.addConnectionListener(connectionListener)
    }

    fun removeConnectionListener(connectionListener: ICameraConnectionListener) {
        mCameraController.removeConnectionListener(connectionListener)
    }

    fun addWifiProxyDataListener(wifiProxyDataListener: IWifiProxyDataListener) {
        mCameraController.addWifiProxyDataListener(wifiProxyDataListener)
    }

    fun removeWifiProxyDataListener(wifiProxyDataListener: IWifiProxyDataListener) {
        mCameraController.removeWifiProxyDataListener(wifiProxyDataListener)
    }

    fun addStillImageListener(onStillImageListener: OnStillImageListener) {
        mCameraController.addOnStillImageListener(onStillImageListener)
    }

    fun removeStillImageListener(onStillImageListener: OnStillImageListener) {
        mCameraController.removeStillImageListener(onStillImageListener)
    }

    fun addCameraRecordListener(cameraRecordListener: ICameraRecordListener) {
        mCameraController.addCameraRecordListener(cameraRecordListener)
    }

    fun removeCameraReocrdListener(cameraRecordListener: ICameraRecordListener) {
        mCameraController.removeCameraRecordListener(cameraRecordListener)
    }

    fun addTimelapseRecordListener(timelapseListener: ITimelapseListener) {
        mCameraController.addTimelapseListener(timelapseListener)
    }

    fun removeTimelapseRecordListener(timelapseListener: ITimelapseListener) {
        mCameraController.removeTimelapseListener(timelapseListener)
    }

    fun addCameraInfoListener(cameraInfoListener: ICameraInfoListener) {
        mCameraController.addCameraInfoListener(cameraInfoListener)
    }

    fun removeCameraInfoListener(cameraInfoListener: ICameraInfoListener) {
        mCameraController.removeCameraInfoListener(cameraInfoListener)
    }

    fun setBleWakeupListener(bleWakeupListener: BleWakeupCallbackCore) {
        mCameraController.setBleWakeupListener(bleWakeupListener)
    }

    fun stopBleWakeupListener(bleStopWakeupCallback: BleStopWakeupCallbackCore) {
        mCameraController.setBleStopWakeupListener(bleStopWakeupCallback)
    }

    fun setNeedReconnectCallback(needReconnectCallback: IReconnectCallback) {
        mCameraController.setNeedReconnectCallback(needReconnectCallback)
    }

    fun setStreamListener(streamListener: OneDriver.OnStreamListener?) {
        mCameraController.setStreamListener(streamListener)
    }

    fun setGimbalDataCallback(gimbalDataCallback: ((StreamGimbalData) -> Unit)? = null) {
        mCameraController.setGimbalDataCallback(gimbalDataCallback)
    }

    fun setTrackDataCallback(trackDataCallback: ((StreamTrackData) -> Unit)? = null) {
        mCameraController.setTrackDataCallback(trackDataCallback)
    }

    fun openTrackingWithRect(openTrackingWithRect: OpenTrackingWithRect): Long {
        return mCameraController.openTrackingWithRect(openTrackingWithRect)
    }

    fun cancelTracking(): Long {
        return mCameraController.cancelTracking()
    }

    fun setPresetComposition(setPresetComposition: SetPresetComposition): Long {
        return mCameraController.setPresetComposition(setPresetComposition)
    }

    fun notifySettingPage(settingPageNotify: PhotoSettingPage): Long {
        return mCameraController.notifySettingPage(settingPageNotify)
    }

    fun getPresetComposition(): Long {
        return mCameraController.getPresetComposition()
    }

    fun getPtzTrackState(): Long {
        return mCameraController.getPtzTrackState()
    }

    /**********************************************Builder */
    class Builder() {
        var mParams: InstaCameraParmas = InstaCameraParmas()


        fun build(): InstaCamera {
            val instaCamera =
                instance
            mParams.apply(instaCamera.mCameraController)

            return instaCamera
        }


        fun mode(mode: InstaMode): Builder {
            mParams.mInstaMode = mode
            return this
        }


        fun addCameraConnectionListener(listener: ICameraConnectionListener): Builder {
            mParams.mConnectionListener = listener
            return this
        }

        fun connectType(connectType: Int): Builder {
            mParams.mConnectType = connectType
            return this
        }
    }


    companion object {
        private val TAG: String = InstaCamera::class.simpleName.toString()


        val instance: InstaCamera
            get() = InstaCamera()
    }
}
