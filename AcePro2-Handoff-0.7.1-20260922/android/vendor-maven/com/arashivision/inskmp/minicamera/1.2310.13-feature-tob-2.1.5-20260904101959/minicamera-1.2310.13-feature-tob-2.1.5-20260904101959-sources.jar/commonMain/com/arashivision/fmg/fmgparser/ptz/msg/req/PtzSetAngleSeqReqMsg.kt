package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.fmg.response.model.FmgSetAngleSeqBean

class PtzSetAngleSeqReqMsg(private val setAngleSeqBeanList: List<FmgSetAngleSeqBean>) :
    PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val itemSize = 8
        val dataSize = setAngleSeqBeanList.size * itemSize
        val data = ByteArray(dataSize)
        for (i in setAngleSeqBeanList.indices) {
            val item = setAngleSeqBeanList[i]
            val itemData = ByteArray(itemSize)
            val rollByteArray = FmgByteUtils.intToUint16ByteArray(item.roll)
            val pitchByteArray = FmgByteUtils.intToUint16ByteArray(item.pitch)
            val yawByteArray = FmgByteUtils.intToUint16ByteArray(item.yaw)
            val timeByteArray = FmgByteUtils.intToUint16ByteArray(item.time)
            rollByteArray.copyInto(itemData, 0, 0, rollByteArray.size)
            pitchByteArray.copyInto(itemData, 2, 0, pitchByteArray.size)
            yawByteArray.copyInto(itemData, 4, 0, yawByteArray.size)
            timeByteArray.copyInto(itemData, 6, 0, timeByteArray.size)
            val destPos = itemSize * i
            itemData.copyInto(data, destPos, 0, itemData.size)
        }
        return data
    }

    override fun toString(): String {
        return "PtzSetAngleSeqReqMsg{" +
                "setAngleSeqBeanList=" + setAngleSeqBeanList +
                '}'
    }

    override fun name(): String {
        return "CMD_ANGLE_SEQ_SET"
    }
}
