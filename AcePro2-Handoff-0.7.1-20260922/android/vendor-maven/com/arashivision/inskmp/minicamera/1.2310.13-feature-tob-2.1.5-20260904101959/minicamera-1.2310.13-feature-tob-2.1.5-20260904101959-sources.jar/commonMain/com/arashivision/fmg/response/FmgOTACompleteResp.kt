package com.arashivision.fmg.response

class FmgOTACompleteResp(var requestID: Long, var errorCode: Int)
