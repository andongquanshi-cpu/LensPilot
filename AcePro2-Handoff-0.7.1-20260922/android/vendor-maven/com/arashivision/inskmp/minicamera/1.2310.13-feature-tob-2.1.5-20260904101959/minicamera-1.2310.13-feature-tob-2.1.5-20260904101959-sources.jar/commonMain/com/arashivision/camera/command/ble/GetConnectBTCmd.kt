package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver
import insta360.messages.GetConnectedBTPeripheral

class GetConnectBTCmd(private val mGetConnectedBTPeripheral: GetConnectedBTPeripheral) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getConnectBT(mGetConnectedBTPeripheral)
    }
}
