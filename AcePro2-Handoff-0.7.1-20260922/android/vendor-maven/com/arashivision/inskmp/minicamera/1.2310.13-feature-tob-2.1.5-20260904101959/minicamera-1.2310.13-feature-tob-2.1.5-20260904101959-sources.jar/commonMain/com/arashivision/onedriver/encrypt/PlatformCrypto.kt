package com.arashivision.onedriver.encrypt

expect object PlatformCrypto {
    fun generateEcdhKeyPair(): EcdhKeyPair
    fun computeEcdhSharedSecret(privateKey: ByteArray, peerPublicKey: ByteArray): ByteArray
    fun hkdfSha256(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray
    fun aesGcmEncrypt(key: ByteArray, nonce: ByteArray, aad: ByteArray, plaintext: ByteArray): AesGcmResult
    fun aesGcmDecrypt(key: ByteArray, nonce: ByteArray, aad: ByteArray, ciphertext: ByteArray, authTag: ByteArray): ByteArray
}

data class EcdhKeyPair(val publicKey: ByteArray, val privateKey: ByteArray)

data class AesGcmResult(val ciphertext: ByteArray, val authTag: ByteArray)