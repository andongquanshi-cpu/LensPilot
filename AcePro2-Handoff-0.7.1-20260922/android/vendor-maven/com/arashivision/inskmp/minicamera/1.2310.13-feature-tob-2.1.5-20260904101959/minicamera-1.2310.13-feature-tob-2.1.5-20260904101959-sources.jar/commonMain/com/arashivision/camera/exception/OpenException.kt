package com.arashivision.camera.exception

class OpenException : RuntimeException {
    constructor(msg: String?) : super(msg)

    constructor()

    constructor(cause: Throwable?) : super(cause)

    constructor(msg: String?, cause: Throwable?) : super(msg, cause)
}
