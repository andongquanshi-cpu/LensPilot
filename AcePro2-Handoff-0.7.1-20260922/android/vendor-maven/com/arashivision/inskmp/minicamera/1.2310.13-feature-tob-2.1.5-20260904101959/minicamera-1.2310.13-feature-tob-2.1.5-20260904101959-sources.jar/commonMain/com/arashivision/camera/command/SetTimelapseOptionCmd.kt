package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.SetTimelapseOptions

class SetTimelapseOptionCmd(private val setTimelapseOptions: SetTimelapseOptions) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setTimelapseOptions(setTimelapseOptions)
    }
}
