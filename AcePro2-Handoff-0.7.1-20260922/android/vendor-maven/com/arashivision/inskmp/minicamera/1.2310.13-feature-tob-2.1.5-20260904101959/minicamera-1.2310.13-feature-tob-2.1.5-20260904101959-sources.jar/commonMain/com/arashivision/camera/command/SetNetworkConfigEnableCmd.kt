package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.SetNetworkConfigEnable

class SetNetworkConfigEnableCmd(private val params: SetNetworkConfigEnable) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setNetworkConfigEnable(params)
    }
}
