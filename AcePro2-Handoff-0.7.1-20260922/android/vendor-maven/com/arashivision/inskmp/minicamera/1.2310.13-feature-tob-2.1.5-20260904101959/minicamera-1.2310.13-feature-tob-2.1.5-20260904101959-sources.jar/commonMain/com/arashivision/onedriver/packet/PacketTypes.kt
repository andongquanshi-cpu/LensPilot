// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/ProtocolTypes.kt
package com.arashivision.onedriver.packet

/**
 * 协议相关的枚举和数据类型定义
 * 对应C++中的packet.h中的枚举定义
 */

/**
 * 数据包类型
 */
enum class PacketType(val value: Int) {
    Stream(0x01),
    Message(0x04),
    HeartBeat(0x05),
    Synchronize(0x06),
    SocketTunnel(0x07),
    SyncMediaTime(0x08),
    LinuxCmd(0x09),
    WifiProxy(0x0c);

    companion object {
        fun fromValue(value: Int): PacketType? = values().find { it.value == value }
    }
}

/**
 * 消息内容类型
 */
enum class MessageContentType(val value: Int) {
    Application(0x00),
    ApplicationOctetStream(0x01),
    ApplicationProtobuf(0x02),
    ApplicationNano1Dict(0x03);

    companion object {
        fun fromValue(value: Int): MessageContentType? = values().find { it.value == value }
    }
}

/**
 * 消息方向
 */
enum class MessageDirection(val value: Int) {
    PhoneToCamera(0x00),  // 相机必须响应所有此类消息
    CameraToPhone(0x01);  // 手机不需要响应此类消息

    companion object {
        fun fromValue(value: Int): MessageDirection? = values().find { it.value == value }
    }
}

/**
 * 流类型
 */
enum class StreamType(val value: Int) {
    AudioStream(0x10),
    AudioStreamPcm(0x11),
    AudioStreamLC3(0x12),
    VideoStream(0x20),
    VideoStreamL(0x21),
    VideoStreamR(0x22),
    GyroStream(0x30),
    VideoExposureTime(0x40),
    VideoPtz(0x83),
    P3Algorithm(0x84),
    TrackData(0x85),
    Unknown(0xFF);

    companion object {
        fun fromValue(value: Int): StreamType = values().find { it.value == value } ?: Unknown
    }
}

/**
 * Linux命令类型
 */
enum class LinuxCmdCmd(val value: Int) {
    RtosStatus(0x01),
    WifiStatus(0x02);

    companion object {
        fun fromValue(value: Int): LinuxCmdCmd? = values().find { it.value == value }
    }
}

/**
 * Linux命令方向
 */
enum class LinuxCmdDirection(val value: Int) {
    PhoneToCamera(0x01),
    CameraToPhone(0x02);

    companion object {
        fun fromValue(value: Int): LinuxCmdDirection? = values().find { it.value == value }
    }
}

/**
 * 协议类型
 */
enum class Protocol(val value: Int) {
    USB(0x00),
    Bluetooth(0x01),
    Socket(0x02),
    Go2Bluetooth(0x03);

    companion object {
        fun fromValue(value: Int): Protocol? = values().find { it.value == value }
    }
}

/**
 * RTOS状态结果
 */
data class RtosStatusResult(
    val statusCode: Int = 0,
)

/**
 * 常量定义
 */
object ProtocolConstants {
    const val MAX_USB_PHOTO_TO_CAMERA_PACKET_SIZE = 2 * 1024 * 1024
    const val MAX_BLUETOOTH_PHOTO_TO_CAMERA_PACKET_SIZE = 250
    const val MAX_CLASSIC_PHOTO_TO_CAMERA_PACKET_SIZE = 900

    // 包头大小
    const val PACKET_HEAD_SIZE = 7
    const val MESSAGE_HEAD_SIZE = 9
    const val STREAM_HEAD_SIZE = 9
    const val TUNNEL_HEAD_SIZE = 14
    const val LINUX_CMD_HEAD_SIZE = 3
}