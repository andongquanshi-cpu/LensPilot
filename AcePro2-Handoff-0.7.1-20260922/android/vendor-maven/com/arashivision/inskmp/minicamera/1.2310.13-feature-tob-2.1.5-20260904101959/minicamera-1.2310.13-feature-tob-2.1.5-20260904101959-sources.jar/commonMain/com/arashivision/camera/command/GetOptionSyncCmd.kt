package com.arashivision.camera.command

import com.arashivision.camera.RequestOptions
import com.arashivision.common.BleLog
import com.arashivision.onecamera.OneDriver
import insta360.messages.OptionType

/**
 * 异步获取options的cmd
 */
class GetOptionSyncCmd(
    private val mOptionList: List<OptionType>?,
    private val mRequestOptions: RequestOptions
) :
    InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        if (mOptionList == null) {
            BleLog.i("syncOptions, mOptionList: null")
            return oneDrvier?.getAllOptionsAsync(OptionType.entries,mRequestOptions)
        }
        if (mOptionList.isEmpty()) {
            BleLog.i("syncOptions, mOptionList: 0")
        } else {
            BleLog.i("syncOptions, mOptionList: " + mOptionList.toTypedArray().contentToString())
        }
        return oneDrvier?.getOptionsAsync(mOptionList, mRequestOptions)
    }
}
