package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

class FmgVibrationCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzVibration()
    }
}
