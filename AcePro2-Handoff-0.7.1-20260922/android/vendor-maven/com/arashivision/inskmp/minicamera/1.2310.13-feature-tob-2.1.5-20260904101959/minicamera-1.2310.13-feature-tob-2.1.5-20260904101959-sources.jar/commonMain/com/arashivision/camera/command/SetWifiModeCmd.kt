package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetWifiModeCmd(private val wifiMode: Int, private val countryCode: String?) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setWifiMode(wifiMode, countryCode)
    }
}
