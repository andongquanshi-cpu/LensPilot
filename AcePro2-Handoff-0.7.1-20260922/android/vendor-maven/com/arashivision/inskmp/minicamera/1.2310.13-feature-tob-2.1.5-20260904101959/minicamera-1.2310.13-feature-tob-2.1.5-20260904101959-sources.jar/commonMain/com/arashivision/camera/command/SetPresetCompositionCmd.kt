package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GimbalControl
import insta360.messages.OpenTrackingWithRect
import insta360.messages.SetPresetComposition

class SetPresetCompositionCmd(private val setPresetComposition: SetPresetComposition) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setPresetComposition(setPresetComposition)
    }
}
