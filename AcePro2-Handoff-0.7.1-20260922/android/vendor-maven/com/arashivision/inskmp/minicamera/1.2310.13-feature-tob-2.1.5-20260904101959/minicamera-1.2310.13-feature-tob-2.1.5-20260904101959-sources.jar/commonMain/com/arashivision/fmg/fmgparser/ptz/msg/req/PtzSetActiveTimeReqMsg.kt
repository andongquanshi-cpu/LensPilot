package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzSetActiveTimeReqMsg(data: Long) : PtzDataReqMessage() {
    private val time: ByteArray? = FmgByteUtils.longToUint64ByteArray(data)

    override fun packData(): ByteArray? {
        return time
    }

    override fun toString(): String {
        return FmgByteUtils.uint64ByteArrayToLong(time!!).toString()
    }

    override fun name(): String {
        return "CMD_SET_ACITVE_TIME"
    }
}
