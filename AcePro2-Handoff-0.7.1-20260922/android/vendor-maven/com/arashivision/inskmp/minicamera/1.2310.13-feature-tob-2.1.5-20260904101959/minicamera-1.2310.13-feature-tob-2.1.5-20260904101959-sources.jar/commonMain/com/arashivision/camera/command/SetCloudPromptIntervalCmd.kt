package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetCloudPromptIntervalCmd(private val intervalSeconds: Long, private val cloudBackupPromptsSeconds: Long) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setCloudPromptInterval(intervalSeconds, cloudBackupPromptsSeconds)
    }
}
