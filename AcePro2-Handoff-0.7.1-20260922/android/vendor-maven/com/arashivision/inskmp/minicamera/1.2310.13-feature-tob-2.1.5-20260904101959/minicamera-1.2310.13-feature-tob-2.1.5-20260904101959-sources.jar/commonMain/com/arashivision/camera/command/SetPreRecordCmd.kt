package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CtrlPreRecord

class SetPreRecordCmd(private val ctrlPreRecord: CtrlPreRecord) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setPreRecord(ctrlPreRecord)
    }
}
