package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class StopLCDCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.stopLCDTest()
        return null
    }
}
