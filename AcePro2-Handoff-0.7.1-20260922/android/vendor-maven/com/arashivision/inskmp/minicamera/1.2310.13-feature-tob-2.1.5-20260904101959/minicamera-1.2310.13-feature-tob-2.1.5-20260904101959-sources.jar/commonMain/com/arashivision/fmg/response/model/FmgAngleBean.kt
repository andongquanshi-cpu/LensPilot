package com.arashivision.fmg.response.model

class FmgAngleBean(roll: Float, pitch: Float, yaw: Float) {
    var roll: Int = (roll * 10).toInt()
    var pitch: Int = (pitch * 10).toInt()
    var yaw: Int = (yaw * 10).toInt()
}
