package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzAITrackUpdateInfoReqMsg(updateInfo: ByteArray) : PtzDataReqMessage() {
    var type: Long = 0 //uint32_t
        private set
    var fireware_version: Long = 0 //uint32_t
        private set
    var hardware_version: Long = 0 //uint32_t
        private set
    var reserved: Long = 0 //uint32_t
        private set
    var size_of_image: Long = 0 //uint32_t
        private set
    var crc32_of_image: Long = 0 //uint32_t
        private set
    var checksum_of_image: Long = 0 //uint32_t
        private set
    val filename: ByteArray = ByteArray(64)
    var packet_num: Long = 0 //uint32_t
        private set

    private val data = ByteArray(UPDATE_INFO_DATA_SIZE)


    init { //传入固件的最后96个字节
        if (updateInfo.size != UPDATE_INFO_DATA_SIZE) {
            Log.d("PtzMsgError", "updateInfoBytes length is not " + UPDATE_INFO_DATA_SIZE)
        } else {
            updateInfo.copyInto(data, 0, 0, updateInfo.size)

            type = FmgByteUtils.uint32BytesToLong(
                updateInfo[0],
                updateInfo[1], updateInfo[2], updateInfo[3]
            )
            fireware_version = FmgByteUtils.uint32BytesToLong(
                updateInfo[4],
                updateInfo[5], updateInfo[6], updateInfo[7]
            )
            hardware_version = FmgByteUtils.uint32BytesToLong(
                updateInfo[8],
                updateInfo[9], updateInfo[10], updateInfo[11]
            )
            reserved = FmgByteUtils.uint32BytesToLong(
                updateInfo[12],
                updateInfo[13], updateInfo[14], updateInfo[15]
            )
            size_of_image = FmgByteUtils.uint32BytesToLong(
                updateInfo[16],
                updateInfo[17], updateInfo[18], updateInfo[19]
            )
            crc32_of_image = FmgByteUtils.uint32BytesToLong(
                updateInfo[20],
                updateInfo[21], updateInfo[22], updateInfo[23]
            )
            checksum_of_image = FmgByteUtils.uint32BytesToLong(
                updateInfo[24],
                updateInfo[25], updateInfo[26], updateInfo[27]
            )
            updateInfo.copyInto(filename, 0, 28, 28 + 64)
            packet_num = FmgByteUtils.uint32BytesToLong(
                updateInfo[92],
                updateInfo[93], updateInfo[94], updateInfo[95]
            )
        }
    }

    override fun packData(): ByteArray? {
        return data
    }

    override fun toString(): String {
        return "PtzAITrackUpdateInfoReqMsg{" +
                "type=" + type +
                ", fireware_version=" + fireware_version +
                ", hardware_version=" + hardware_version +
                ", reserved=" + reserved +
                ", size_of_image=" + size_of_image +
                ", crc32_of_image=" + crc32_of_image +
                ", checksum_of_image=" + checksum_of_image +
                ", filename=" + filename.contentToString() +
                ", packet_num=" + packet_num +
                '}'
    }

    override fun name(): String {
        return "CMD_UPDATE_INFO_REQ"
    }

    companion object {
        const val UPDATE_INFO_DATA_SIZE: Int = 96
    }
}
