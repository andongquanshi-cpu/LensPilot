package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.common.BleLog

class PtzGetEtdErrorStateEventRespMsg : PtzDataRespMessage() {
    var errorStateEventParamsArray: Array<ErrorStateEventParams>? = null

    @OptIn(ExperimentalStdlibApi::class)
    override fun unpack(data: ByteArray?) {
        val list: MutableList<ErrorStateEventParams> = ArrayList()
        if (data == null) return
        try {
            val eventCountSignByteLength = 2
            if (data.size <= eventCountSignByteLength) {
                Log.d("unpack", "PtzGetEtdErrorStateEventRespMsg data error!!!!")
            } else {
                val eventCount = FmgByteUtils.uint16BytesToInt(data[0], data[1])
                if (eventCount > 0) {
                    val eventDataLength = (data.size - eventCountSignByteLength) / eventCount
                    var i = eventCountSignByteLength
                    while (i < data.size) {
                        val powerOffEventParams = ErrorStateEventParams()
                        if (eventDataLength >= 2) {
                            powerOffEventParams.serial_number = FmgByteUtils.uint16BytesToInt(
                                data[i],
                                data[i + 1]
                            )
                        }
                        if (eventDataLength >= 3) {
                            powerOffEventParams.battery = FmgByteUtils.byteToShort(data[i + 2])
                        }
                        if (eventDataLength >= 4) {
                            val s1 = FmgByteUtils.byteToBinary(data[i + 3])
                            val chars1 = s1.toCharArray()
                            powerOffEventParams.bt_connected_state = chars1[0] == '1'
                            var errorType = 0
                            if (chars1[7] == '1') {
                                errorType += 1
                            }
                            if (chars1[6] == '1') {
                                errorType += 2
                            }
                            if (chars1[5] == '1') {
                                errorType += 4
                            }
                            powerOffEventParams.bt_state_err_type = errorType
                        }
                        if (eventDataLength >= 6) {
                            powerOffEventParams.running_times = FmgByteUtils.uint16BytesToInt(
                                data[i + 4],
                                data[i + 5]
                            )
                        }
                        list.add(powerOffEventParams)
                        i += eventDataLength
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // 固件经常返回异常数据
            BleLog.e(
                "PtzGetEtdErrorStateEventRespMsg data invalid, throw exception! data = " + data.toHexString(HexFormat.Default)
            )
        }
        errorStateEventParamsArray = list.toTypedArray<ErrorStateEventParams>()
    }

    override fun toString(): String {
        return "errorStateEventParamsArray length = " + (if (errorStateEventParamsArray != null) errorStateEventParamsArray!!.size else 0)
    }

    override fun name(): String {
        return "CMD_GET_ETD - ErrorStateEvent"
    }

    class ErrorStateEventParams {
        var serial_number: Int = 0
        var running_times: Int = 0
        var battery: Short = 0
        var bt_state_err_type: Int = 0
        var bt_connected_state: Boolean = false
    }
}
