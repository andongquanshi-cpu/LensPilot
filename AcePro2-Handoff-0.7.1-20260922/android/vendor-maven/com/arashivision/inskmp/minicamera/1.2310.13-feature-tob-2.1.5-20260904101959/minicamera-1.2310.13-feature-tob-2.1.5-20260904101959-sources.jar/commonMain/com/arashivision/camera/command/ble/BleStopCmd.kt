package com.arashivision.camera.command.ble

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.inskmp.insble.BleManagerCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.onecamera.OneDriver

class BleStopCmd(private val bleDevice: BleDeviceCore?) : InstaCmdExe {

    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.closeBle()
        if (bleDevice == null) {
            BleManagerCore.disconnectAllDevice()
        } else {
            BleManagerCore.disconnect(bleDevice)
        }
        return null
    }
}
