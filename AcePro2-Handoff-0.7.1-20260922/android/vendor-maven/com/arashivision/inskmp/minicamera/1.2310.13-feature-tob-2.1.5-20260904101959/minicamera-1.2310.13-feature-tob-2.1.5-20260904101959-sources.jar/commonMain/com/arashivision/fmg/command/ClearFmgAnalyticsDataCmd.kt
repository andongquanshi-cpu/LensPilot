package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.onecamera.OneDriver

/**
 * 清除 FMG 主板的埋点数据，区别于
 * {@link ClearBleFmgAnalyticsDataCmd}
 */
class ClearFmgAnalyticsDataCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzClearAnalyticsData()
    }
}
