package com.arashivision.camera.exception

object InstaError {
    fun onError(error: Throwable?) {
    }


    fun onError(errorString: String?) {
    }
}
