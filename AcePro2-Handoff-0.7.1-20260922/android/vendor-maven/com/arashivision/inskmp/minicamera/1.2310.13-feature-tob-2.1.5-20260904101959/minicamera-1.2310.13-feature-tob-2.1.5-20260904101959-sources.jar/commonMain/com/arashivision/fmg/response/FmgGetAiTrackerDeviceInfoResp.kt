package com.arashivision.fmg.response

class FmgGetAiTrackerDeviceInfoResp(
    var requestID: Long,
    var sn: String,
    var type: String,
    var kernelVersion: String,
    var modelVersionList: List<Int>
) {
    override fun toString(): String {
        return "FmgGetAiTrackerDeviceInfoResp{" +
                "sn='" + sn + '\'' +
                ", type='" + type + '\'' +
                ", kernelVersion='" + kernelVersion + '\'' +
                ", modelVersionList=" + modelVersionList +
                '}'
    }
}
