package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SendAiVoiceReadyCmd(private val isHuawei: Boolean = false) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.sendAiVoiceReady(isHuawei)
    }
}
