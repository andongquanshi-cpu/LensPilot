package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.GimbalControl
import insta360.messages.OpenTrackingWithRect
import insta360.messages.SetPresetComposition

class GetPtzTrackStateCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.getPtzTrackState()
    }
}
