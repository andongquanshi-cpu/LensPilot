package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class SetCameraWifiSeizeEnableCmd(
    /**
     * [com.arashivision.onecamera.OneDriverInfo.Request.ConnectionState]
     */
    private val mConnectionState: Int
) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setCameraWifiSeizeEnable(mConnectionState)
    }
}
