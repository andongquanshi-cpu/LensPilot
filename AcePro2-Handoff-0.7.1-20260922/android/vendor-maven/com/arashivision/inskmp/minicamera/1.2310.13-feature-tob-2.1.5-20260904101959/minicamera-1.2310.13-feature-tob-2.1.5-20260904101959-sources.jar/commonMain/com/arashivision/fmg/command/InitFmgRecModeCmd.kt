package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzRecMode
import com.arashivision.onecamera.OneDriver

class InitFmgRecModeCmd(private val mode: PtzRecMode) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzRecModeInit(mode)
    }
}
