package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzUpDateShakeHandReqMsg(
//uint8_t
    val protocol: Short, val phoneBrand: Short, //uint32_t
    val bps: Long
) :
    PtzDataReqMessage() {
    val reserved: ByteArray = ByteArray(7) //uint8_t


    override fun packData(): ByteArray? {
        val data = ByteArray(12)
        data[0] = protocol.toByte()
        data[1] = phoneBrand.toByte()
        reserved.copyInto(data, 2, 0, 7)
        val bpsBytes = FmgByteUtils.longToUint32ByteArray(bps)
        bpsBytes.copyInto(data, 8, 0, 4)
        return data
    }

    override fun toString(): String {
        return "protocol " + protocol + ", phoneBrand " + phoneBrand + ", Bps " + bps
    }

    override fun name(): String {
        return "CMD_UPDATE_SHAKE_HAND_REQ"
    }
}
