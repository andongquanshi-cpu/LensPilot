package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.IntervalRecFeedback

/**
 * 设置间隔录像交互反馈配置
 */
internal class SetIntervalRecFeedbackCfgCmd(private val intervalRecFeedback: IntervalRecFeedback) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.setIntervalRecFeedbackCfg(intervalRecFeedback)
    }
}
