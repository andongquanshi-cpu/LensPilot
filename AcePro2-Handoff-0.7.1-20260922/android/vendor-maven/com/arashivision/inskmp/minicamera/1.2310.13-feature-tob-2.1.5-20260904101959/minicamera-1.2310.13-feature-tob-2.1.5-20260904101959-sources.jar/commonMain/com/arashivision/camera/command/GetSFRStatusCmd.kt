package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class GetSFRStatusCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.sfrStatus
    }
}
