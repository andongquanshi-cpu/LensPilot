package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 获取相机Rtos状态（是否死机）
 */
class ObtainRtosStatusCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        oneDrvier?.obtainCameraRtosStatus()
        return null
    }
}
