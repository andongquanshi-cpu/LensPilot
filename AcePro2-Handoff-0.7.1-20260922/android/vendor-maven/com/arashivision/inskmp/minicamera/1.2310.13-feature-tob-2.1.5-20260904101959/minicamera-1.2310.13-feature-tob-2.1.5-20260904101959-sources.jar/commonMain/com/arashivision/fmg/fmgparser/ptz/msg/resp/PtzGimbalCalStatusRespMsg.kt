package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log
import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGimbalCalStatusRespMsg : PtzDataRespMessage() {
    var status: Short = 0
    var percentage: Short = 0
    var reserved: ByteArray = ByteArray(8)

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 5) {
            Log.d("unpack", "error!!!!")
            return
        }
        status = FmgByteUtils.byteToShort(data[0])
        percentage = FmgByteUtils.byteToShort(data[1])
        data.copyInto(reserved, 0, 2, 2 + reserved.size)
    }

    override fun toString(): String {
        return "status: $status percentage: $percentage"
    }

    override fun name(): String {
        return "CMD_GIMBAL_CAL_STATUS"
    }
}
