package com.arashivision.camera.wifiproxy

import com.arashivision.onedriver.packet.Packet
import okio.Buffer

/**
 * KMP兼容的WifiProxyDataParser实现
 * 使用okio替代java.nio.ByteBuffer
 */
object WifiProxyDataParser {

    fun parse(bytes: ByteArray, isUseUcd2: Boolean): IWifiProxyData? {
        return try {
            val buffer = Buffer().apply { write(bytes) }

            // 读取命令类型
            val cmd = buffer.readByte()

            when (cmd) {
                IWifiProxyData.CMD_CONNECT -> {
                    val rsv = buffer.readByte()  // 读取保留字节
                    val socketId = buffer.readIntLe()
                    val port = buffer.readIntLe()
                    val urlBytes = buffer.readByteArray()
                    val url = urlBytes.decodeToString()
                    WifiProxyConnectData(socketId, port, url, isUseUcd2)
                }

                IWifiProxyData.CMD_MESSAGE -> {
                    val rsv = buffer.readByte()  // 读取保留字节
                    val socketId = buffer.readIntLe()
                    val msg = buffer.readByteArray()
                    WifiProxyMessageData(socketId, msg, isUseUcd2)
                }

                IWifiProxyData.CMD_DISCONNECT -> {
                    val rsv = buffer.readByte()  // 读取保留字节
                    val socketId = buffer.readIntLe()
                    WifiProxyDisconnectData(socketId, isUseUcd2)
                }

                else -> null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    fun crc32(byteBuffer: Buffer): Int {
        val data = byteBuffer.snapshot().toByteArray()
        return Packet.crc32(data, data.size)
    }
}
