package com.arashivision.onedriver.utils

expect object PlatformGBKDecoder {
    fun decode(bytes: ByteArray): String
    fun encode(text: String): ByteArray
}