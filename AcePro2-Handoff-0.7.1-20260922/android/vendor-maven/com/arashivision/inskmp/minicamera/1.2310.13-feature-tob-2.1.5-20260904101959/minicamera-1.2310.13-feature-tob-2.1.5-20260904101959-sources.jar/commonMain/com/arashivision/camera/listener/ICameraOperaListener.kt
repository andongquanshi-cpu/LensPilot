package com.arashivision.camera.listener

/**
 * 相机操作的一些回调接口
 */
interface ICameraOperaListener 
