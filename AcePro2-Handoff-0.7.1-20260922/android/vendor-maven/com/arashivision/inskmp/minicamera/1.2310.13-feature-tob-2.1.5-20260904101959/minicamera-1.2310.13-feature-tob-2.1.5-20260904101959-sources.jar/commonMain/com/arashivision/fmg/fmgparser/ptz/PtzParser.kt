package com.arashivision.fmg.fmgparser.ptz

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzParser(private val mIPtzParser: IPtzParser) {
    private val cache = ArrayList<Byte>()
    private var pos = 0

    /**
     * 支持分包、粘包、丢包解析用
     * @param data
     */
    fun resolverV2(data: ByteArray) {
        val len = data.size
        var startPos = 0
        pos = 0
        if (cache.size == 0) {
            startPos = findHead(data)
            if (startPos == -1) {
                mIPtzParser.onError(PTZ_PARSER_DATA_ERROR)
                return
            }
            if (len - startPos >= 4) { //包剩余内容足够头部
//                Log.i("fmgTest", "包剩余内容足够头部，startpos = "+startPos+" length = "+len);
                for (i in startPos until startPos + 4) {
                    cache.add(data[i])
                }
                pos = startPos + 4
                val needLength = (cache[3].toInt() and 0xFF) + 2

                //                Log.i("fmgTest", "needLength = "+needLength);
//                byte[] testData = new byte[cache.size()];
//                for(int i = 0;i<cache.size();i++){
//                    testData[i] = cache.get(i);
//                }
//                Log.i("fmgTest", ByteUtils.bytes2hexDebug(testData));
                if (needLength == len - startPos - 4) { //完美情况，包剩余内容正好为完整内容
//                    Log.i("fmgTest", "包剩余内容正好为完整内容");
                    for (i in pos until len) { //全部add进cache
                        cache.add(data[i])
                        pos++
                    }
                    OnByteEnough(cache) //传出cache
                } else if (needLength < len - startPos - 4) { //包剩余内容大于所需内容，包剩余内容重新循环
//                    Log.i("fmgTest", "包剩余内容重新循环");
                    for (i in pos until needLength + startPos + 4) {
                        cache.add(data[i])
                    }
                    pos = startPos + 4 + needLength
                    OnByteEnough(cache)
                    val remain = ByteArray(len - pos)
                    data.copyInto(remain, 0, pos, pos + remain.size)
                    resolverV2(remain)
                } else if (needLength > len - startPos - 4) { //包剩余内容小于所需内容，等待后续包
//                    Log.i("fmgTest", "等待后续包");
                    for (i in pos until len) { //全部add进cache
                        cache.add(data[i])
                        pos++
                    }
                }
            } else { //找到头，但是包剩余内容不够头部内容，需在后续包特殊处理补充头部
//                Log.i("fmgTest", "包剩余内容不够头部内容 + len:" + len);
                for (i in startPos until len) {
                    cache.add(data[i])
                }
            }
        } else {
            if (cache.size < 4) { //头不完整，需补全头
//                Log.i("fmgTest", "头不完整，需补全头 cacheSize = " + cache.size());
                if (len < 4 - cache.size) { //缺头，并且包太短，无法补齐头，缓存部分add进cache
//                    Log.i("fmgTest", "缺头，并且包太短，无法补齐头，缓存部分add进cache");
                    for (datum in data) {
                        cache.add(datum)
                    }
                } else {
                    val originSize = cache.size
                    for (i in 0 until 4 - originSize) {
                        cache.add(data[i])
                    }
                    val remain = ByteArray(len - (4 - originSize))
                    data.copyInto(remain, 0, 4 - originSize, 4 - originSize + remain.size)
                    resolverV2(remain)
                }
            } else { //有头,找后续data
                val needLength = (cache[3].toInt() and 0xFF) + 2 - (cache.size - 4)

                //                Log.i("fmgTest", "有头,找后续data,needLength = "+needLength + " len = " + len);
                if (needLength == len) {
                    for (i in pos until len) { //全部add进cache
                        cache.add(data[i])
                        pos++
                    }
                    OnByteEnough(cache) //传出cache
                } else if (needLength < len) {
                    for (i in 0 until needLength) {
                        cache.add(data[i])
                        pos++
                    }
                    OnByteEnough(cache)
                    val remain = ByteArray(len - pos)
                    data.copyInto(remain, startIndex = pos, endIndex = pos + remain.size)
                    resolverV2(remain)
                } else if (needLength > len) {
                    for (i in pos until len) { //全部add进cache
                        cache.add(data[i])
                        pos++
                    }
                }
            }
        }
    }

    /**
     * 不支持粘包、丢包等情况
     * @param data
     */
    fun resolver(data: ByteArray) {
        val len = data.size
        var startPos = 0

        if (cache.size == 0) { //cache is empty
            startPos = findHead(data)
            if (startPos == -1) {
                mIPtzParser.onError(PTZ_PARSER_DATA_NOT_FINDHEAD_ERROR)
                return
            }
            if (len - startPos < 4) {
                mIPtzParser.onError(PTZ_PARSER_LENGTH_ERROR)
                return
            }

            for (i in startPos until len) {
                cache.add(data[i])
            }
            if ((cache[3].toInt() and 0xFF) + 6 == cache.size) {
                OnByteEnough(cache)
            }
        } else {
            for (datum in data) {
                cache.add(datum)
            }

            if ((cache[3].toInt() and 0xFF) + 6 == cache.size) {
                OnByteEnough(cache)
            }
        }
    }

    private fun OnByteEnough(list: ArrayList<Byte>) {
//        Log.i("fmgTest", "成功组成完整包，传出解析length =" + Byte.toUnsignedInt(list.get(3)) + " listsize = "+ list.size());
        if (((cache[3].toInt() and 0xFF) + 6) == list.size) {
            val ptzDataPacket = ArrayListToPacket(cache)
            val crcData = FmgByteUtils.intToUint16ByteArray(ptzDataPacket.crc16)
            //        Log.i("fmgTest","crcData[0]  :" + crcData[0]  + " crcData[1]  :" + crcData[1] );
            if (crcData[0] == list[list.size - 2] && crcData[1] == list[list.size - 1]) {
                mIPtzParser.onGetCompletePacket(ptzDataPacket)
            } else {
                mIPtzParser.onError(PTZ_PARSER_CRC_ERROR)
            }
            cache.clear()
        } else {
            mIPtzParser.onError(PTZ_PARSER_UNKNOW_ERROR) //异常情况，正常不会到这一步
            cache.clear()
        }
    }

    private fun ArrayListToPacket(list: ArrayList<Byte>): PtzDataPacket {
        val ptzDataPacket = PtzDataPacket(
            FmgByteUtils.byteToShort(cache[1]), FmgByteUtils.byteToShort(
                cache[2]
            )
        )
        val data = ByteArray((cache[3].toInt() and 0xFF))
        for (i in data.indices) {
            data[i] = list[i + 4]
        }
        ptzDataPacket.packetPack(data)

        return ptzDataPacket
    }

    private fun findHead(data: ByteArray): Int {
        var pos = -1
        for (i in data.indices) {
            if (data[i] == 0xA5.toByte()) {
                pos = i
                return pos
            }
        }
        return pos
    }

    interface IPtzParser {
        fun onGetCompletePacket(ptzDataPacket: PtzDataPacket)

        fun onError(e: Int)
    }

    companion object {
        const val PTZ_PARSER_CRC_ERROR: Int = 1001
        const val PTZ_PARSER_DATA_ERROR: Int = 1002
        const val PTZ_PARSER_LENGTH_ERROR: Int = 1003
        const val PTZ_PARSER_DATA_NOT_FINDHEAD_ERROR: Int = 1004
        const val PTZ_PARSER_UNKNOW_ERROR: Int = 1005
    }
}
