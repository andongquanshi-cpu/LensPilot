package com.arashivision.onedriver.utils

/**
 * 字符串编码工具类
 * 用于处理 WiFi SSID 等字段的 UTF-8 验证和编码转换
 */
object StringEncodingUtils {

    /**
     * 验证字节数组是否为有效的 UTF-8 编码
     * 参考 C++ 实现：使用计数器跟踪后续字节数量
     *
     * @param bytes 要验证的字节数组
     * @return 如果是有效的 UTF-8 编码返回 true，否则返回 false
     */
    fun isValidUTF8(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return true

        var numContinuationBytes = 0

        for (byte in bytes) {
            val c = byte.toInt() and 0xFF

            if (numContinuationBytes == 0) {
                // 检查是否是 UTF-8 序列的开始字节
                when {
                    (c shr 5) == 0b110 -> {
                        // 2 字节序列 (110xxxxx)
                        numContinuationBytes = 1
                    }

                    (c shr 4) == 0b1110 -> {
                        // 3 字节序列 (1110xxxx)
                        numContinuationBytes = 2
                    }

                    (c shr 3) == 0b11110 -> {
                        // 4 字节序列 (11110xxx)
                        numContinuationBytes = 3
                    }

                    (c shr 7) != 0 -> {
                        // 多字节字符的无效起始字节（MSB 为 1 但不是有效的 UTF-8 起始字节）
                        return false
                    }
                    // else: ASCII 字符 (0xxxxxxx)，numContinuationBytes 保持为 0
                }
            } else {
                // 检查是否是有效的后续字节 (10xxxxxx)
                if ((c shr 6) != 0b10) {
                    return false
                }
                numContinuationBytes--
            }
        }

        // 如果所有序列都完整（没有未完成的序列），则是有效的 UTF-8
        return numContinuationBytes == 0
    }

    /**
     * 安全地解码字符串，如果 UTF-8 无效则尝试 GBK/GB2312 编码
     *
     * @param bytes 要解码的字节数组
     * @return 解码后的字符串
     */
    fun safeDecodeString(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""

        return try {
            // 首先尝试作为 UTF-8 解码
            val utf8String = bytes.decodeToString()
            // 验证解码后的字符串是否有效
            // 如果字节数组是有效的 UTF-8，直接返回
            if (isValidUTF8(bytes)) {
                utf8String
            } else {
                // 如果不是有效的 UTF-8，尝试使用平台特定的编码转换
                // 在 Android 上尝试 GBK/GB2312
                decodeWithFallback(bytes)
            }
        } catch (e: Exception) {
            // 如果 UTF-8 解码失败，尝试使用备用编码
            bytes.decodeToString()
        }
    }

    /**
     * 使用备用编码解码（GBK/GB2312）
     * 注意：这是一个平台相关的实现
     */
    private fun decodeWithFallback(bytes: ByteArray): String {
        return PlatformGBKDecoder.decode(bytes)
    }


    /**
     * 安全地解析 WifiScanInfoList，处理其中可能存在的非 UTF-8 SSID
     *
     * @param content Protocol Buffers 字节数组
     * @return 解析后的 WifiScanInfoList，如果解析失败返回 null
     */
    fun safeDecodeWifiScanInfoList(content: ByteArray): insta360.messages.WifiScanInfoList? {
        return try {
            // 首先尝试正常解析
            val wifiScanInfoList = insta360.messages.WifiScanInfoList.ADAPTER.decode(content)

            // 检查是否有 ssid 字段包含替换字符（U+FFFD）
            // 如果包含替换字符，说明 Wire 库使用了替换字符，无法恢复原始数据
            // 需要重新手动解析
            val hasReplacementChar = wifiScanInfoList.wifi_info.any { wifiInfo ->
                wifiInfo.ssid.contains('\uFFFD')
            }

            if (hasReplacementChar) {
                // 包含替换字符，需要重新手动解析
                safeDecodeWifiScanInfoListManual(content)
            } else {
                wifiScanInfoList
            }
        } catch (e: Exception) {
            // 如果解析失败（可能是因为 ssid 字段包含非 UTF-8 数据），尝试手动处理
            // 注意：Wire 库在遇到非 UTF-8 字符串时会抛出异常，导致整个解析失败
            // 这种情况下，我们需要手动解析 Protocol Buffers
            try {
                safeDecodeWifiScanInfoListManual(content)
            } catch (e2: Exception) {
                // 如果手动解析也失败，返回 null
                null
            }
        }
    }

    /**
     * 手动解析 WifiScanInfoList，跳过 ssid 字段的 UTF-8 验证
     * 这是一个回退方案，当正常解析失败时使用
     *
     * @param content Protocol Buffers 字节数组
     * @return 解析后的 WifiScanInfoList
     */
    private fun safeDecodeWifiScanInfoListManual(content: ByteArray): insta360.messages.WifiScanInfoList {
        // 使用 ProtoReader 手动解析，对 ssid 字段进行特殊处理
        val buffer = okio.Buffer().apply { write(content) }
        val reader = com.squareup.wire.ProtoReader(buffer)
        val wifiInfoList = mutableListOf<insta360.messages.WifiScanInfo>()
        var listCount = 0

        val unknownFields = reader.forEachTag { tag ->
            when (tag) {
                1 -> {
                    // WifiScanInfo 字段（repeated）
                    // Protocol Buffers 的 repeated message 字段格式：tag + varint length + message bytes
                    // 使用 ProtoAdapter.BYTES 读取 length-delimited 字段
                    try {
                        val byteString = com.squareup.wire.ProtoAdapter.BYTES.decode(reader)
                        val wifiInfoBytes = byteString.toByteArray()

                        // 总是使用手动解析，确保 ssid 字段能正确处理 GBK 编码
                        // 因为即使正常解析成功，如果 ssid 包含非 UTF-8 数据，Wire 库可能会使用替换字符
                        // 导致后续无法恢复原始数据
                        val wifiInfo = safeDecodeWifiScanInfoManual(wifiInfoBytes)
                        wifiInfoList.add(wifiInfo)
                    } catch (e: Exception) {
                        // 如果读取失败，跳过这个字段
                    }
                }

                2 -> {
                    // list_count 字段
                    listCount = com.squareup.wire.ProtoAdapter.INT32.decode(reader)
                }

                else -> reader.readUnknownField(tag)
            }
        }

        return insta360.messages.WifiScanInfoList(
            wifi_info = wifiInfoList,
            list_count = listCount,
            unknownFields = unknownFields
        )
    }

    /**
     * 手动解析 WifiScanInfo，对 ssid 字段进行特殊处理
     * 注意：这个方法需要从完整的 WifiScanInfo 字节数组中解析
     */
    private fun safeDecodeWifiScanInfoManual(wifiInfoBytes: ByteArray): insta360.messages.WifiScanInfo {
        val reader = com.squareup.wire.ProtoReader(okio.Buffer().apply { write(wifiInfoBytes) })
        var bssid = ""
        var frequency = 0
        var signalLevel = 0
        var flags = ""
        var ssid = ""

        val unknownFields = reader.forEachTag { tag ->
            when (tag) {
                1 -> {
                    // bssid 字段 - Protocol Buffers string 字段格式：varint length + bytes
                    bssid = com.squareup.wire.ProtoAdapter.STRING.decode(reader)
                }

                2 -> {
                    // frequency 字段
                    frequency = com.squareup.wire.ProtoAdapter.UINT32.decode(reader)
                }

                3 -> {
                    // signal_level 字段
                    signalLevel = com.squareup.wire.ProtoAdapter.INT32.decode(reader)
                }

                4 -> {
                    // flags 字段
                    flags = com.squareup.wire.ProtoAdapter.STRING.decode(reader)
                }

                5 -> {
                    // ssid 字段 - 特殊处理，可能包含 GBK 编码
                    // 直接使用 BYTES adapter 读取原始字节，然后手动解码
                    // 这样可以避免 Wire 库使用替换字符
                    val byteString = com.squareup.wire.ProtoAdapter.BYTES.decode(reader)
                    val ssidBytes = byteString.toByteArray()

                    // 检查是否是有效的 UTF-8
                    if (isValidUTF8(ssidBytes)) {
                        // 如果是有效的 UTF-8，直接解码
                        ssid = ssidBytes.decodeToString()
                    } else {
                        // 如果不是有效的 UTF-8，尝试使用 GBK 解码
                        ssid = safeDecodeString(ssidBytes)
                    }
                }

                else -> reader.readUnknownField(tag)
            }
        }

        return insta360.messages.WifiScanInfo(
            bssid = bssid,
            frequency = frequency,
            signal_level = signalLevel,
            flags = flags,
            ssid = ssid,
            unknownFields = unknownFields
        )
    }

    /**
     * 处理 WifiScanInfoList，修复其中可能存在的非 UTF-8 SSID
     *
     * @param wifiScanInfoList 原始的 WifiScanInfoList
     * @return 处理后的 WifiScanInfoList，其中 SSID 字段已正确解码
     */
    fun processWifiScanInfoList(wifiScanInfoList: insta360.messages.WifiScanInfoList): insta360.messages.WifiScanInfoList {
        val processedWifiInfo = wifiScanInfoList.wifi_info.map { wifiInfo ->
            // 处理每个 WifiScanInfo 的 ssid 字段
            val processedSsid = processWifiSsid(wifiInfo.ssid)

            // 如果 SSID 被修改了，创建新的 WifiScanInfo
            if (processedSsid != wifiInfo.ssid) {
                wifiInfo.copy(ssid = processedSsid)
            } else {
                wifiInfo
            }
        }

        // 如果列表有变化，创建新的 WifiScanInfoList
        return if (processedWifiInfo != wifiScanInfoList.wifi_info) {
            wifiScanInfoList.copy(wifi_info = processedWifiInfo)
        } else {
            wifiScanInfoList
        }
    }

    /**
     * 处理 WiFi SSID 字符串，确保正确解码
     *
     * @param ssid 原始 SSID 字符串（可能已经是解码后的，也可能需要重新处理）
     * @param originalBytes 原始的字节数组（如果可用）
     * @return 处理后的 SSID 字符串
     */
    fun processWifiSsid(ssid: String, originalBytes: ByteArray? = null): String {
        if (ssid.isEmpty()) return ssid

        return try {
            // 如果提供了原始字节数组，使用它进行验证和转换
            if (originalBytes != null && originalBytes.isNotEmpty()) {
                return safeDecodeString(originalBytes)
            }

            // 否则，尝试将字符串编码回字节数组进行验证
            val bytes = ssid.encodeToByteArray()
            if (isValidUTF8(bytes)) {
                ssid
            } else {
                // 如果当前字符串的字节表示不是有效的 UTF-8，可能需要重新处理
                // 这种情况下，我们假设字符串已经是正确解码的，直接返回
                ssid
            }
        } catch (e: Exception) {
            // 如果处理失败，返回原始字符串
            ssid
        }
    }
}
