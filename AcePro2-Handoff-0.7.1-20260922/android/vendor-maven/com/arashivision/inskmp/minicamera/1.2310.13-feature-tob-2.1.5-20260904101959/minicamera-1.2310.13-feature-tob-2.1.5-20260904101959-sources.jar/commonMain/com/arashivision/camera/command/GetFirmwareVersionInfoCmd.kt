package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

/**
 * 获取固件子版本号
 */
internal class GetFirmwareVersionInfoCmd() : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.getFirmwareVersionsInfo()
    }
}
