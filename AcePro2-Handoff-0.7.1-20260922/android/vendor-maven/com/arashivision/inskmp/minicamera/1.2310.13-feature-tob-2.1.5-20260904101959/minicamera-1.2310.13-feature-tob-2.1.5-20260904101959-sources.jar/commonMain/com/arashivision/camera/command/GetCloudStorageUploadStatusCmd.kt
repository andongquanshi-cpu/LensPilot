package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class GetCloudStorageUploadStatusCmd : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.cloudStorageUploadStatus
    }
}
