package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.CloudStorageUploadParams

class SetCloudStorageUploadStatusCmd(private val params: CloudStorageUploadParams) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.setCloudStorageUploadStatus(params)
    }
}
