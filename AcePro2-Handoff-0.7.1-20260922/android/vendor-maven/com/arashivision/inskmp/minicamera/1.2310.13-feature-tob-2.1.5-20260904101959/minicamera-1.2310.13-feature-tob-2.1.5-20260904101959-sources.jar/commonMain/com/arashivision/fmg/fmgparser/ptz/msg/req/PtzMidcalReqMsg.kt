package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzMidcalReqMsg(private val euler: DoubleArray) : PtzDataReqMessage() {
    override fun packData(): ByteArray? {
        val data = ByteArray(24)
        val doublebytes1 = FmgByteUtils.doubleToUint64ByteArray(euler[0])
        val doublebytes2 = FmgByteUtils.doubleToUint64ByteArray(euler[1])
        val doublebytes3 = FmgByteUtils.doubleToUint64ByteArray(euler[2])
        doublebytes1.copyInto(data, 0, 0, doublebytes1.size)
        doublebytes2.copyInto(data, 8, 0, doublebytes2.size)
        doublebytes3.copyInto(data, 16, 0, doublebytes3.size)
        return data
    }

    override fun toString(): String {
        return euler.contentToString()
    }

    override fun name(): String {
        return "CMD_MID_CAL"
    }
}
