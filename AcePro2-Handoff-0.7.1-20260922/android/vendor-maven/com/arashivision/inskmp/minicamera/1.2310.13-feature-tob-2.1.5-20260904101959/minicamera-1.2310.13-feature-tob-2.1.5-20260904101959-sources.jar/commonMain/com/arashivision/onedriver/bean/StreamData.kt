package com.arashivision.onedriver.bean

import com.arashivision.onedriver.packet.StreamType

/**
 * 流数据结构
 */
data class StreamData(
    val streamType: StreamType,
    val data: ByteArray,
    val timestamp: Long = 0,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true

        other as StreamData

        if (!data.contentEquals(other.data)) return false
        if (timestamp != other.timestamp) return false

        return true
    }

    override fun hashCode(): Int {
        var result = data.contentHashCode()
        result = 31 * result + timestamp.hashCode()
        return result
    }
}