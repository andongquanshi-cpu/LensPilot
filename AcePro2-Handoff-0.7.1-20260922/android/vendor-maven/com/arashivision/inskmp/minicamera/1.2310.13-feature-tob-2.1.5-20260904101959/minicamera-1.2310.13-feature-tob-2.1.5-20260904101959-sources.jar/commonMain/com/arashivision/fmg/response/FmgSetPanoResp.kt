package com.arashivision.fmg.response

class FmgSetPanoResp(var requestID: Long)
