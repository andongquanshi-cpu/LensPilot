package com.arashivision.camera.listener

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.ConnectL2SuccessResultCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore

/**
 * 蓝牙连接的回调
 */
interface IBleConnectListener {
    fun onStartConnect()

    fun onStartFailed()

    fun onConnectFail(bleDevice: BleDeviceCore?, exception: BleExceptionCore?)

    fun onConnectSuccess(bleDevice: BleDeviceCore?, gatt: Any?, status: Int)
    fun onConnectL2Success(bleDevice: BleDeviceCore, gatt: Any?, status: Int): ConnectL2SuccessResultCore

    /**
     * BLE 物理通道就绪(notify 成功、openCameraBle 之后),在等待 sync 包之前回调。
     * 用于 BLE+SPP 共存:此时若 SPP 已连接,上层需建立 SPP→BLE 转发链,sync 才能经 SPP 到达。
     * 默认空实现:仅常规 BLE 连接(BleConnectCmd)会触发,其余实现可忽略。
     */
    fun onBlePhysicalConnected(bleDevice: BleDeviceCore?, gatt: Any?, status: Int) {}

    fun onDisConnected(
        isActiveDisConnected: Boolean,
        device: BleDeviceCore?,
        gatt: Any?,
        status: Int,
    )

    fun onBondReject(bleDevice: BleDeviceCore?)

    fun onWriteFailed(bleDevice: BleDeviceCore?, exception: BleExceptionCore?)

    fun onConnectClassicSuccess(bleDevice: BleDeviceCore?, status: Int)

    fun onConnectClassicFail(bleDevice: BleDeviceCore?, exception: BleExceptionCore?)

}
