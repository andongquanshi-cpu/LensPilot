package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver

class ScriptcmdUploadCmd(private val cmdBytes: ByteArray) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.uploadScriptCmd(cmdBytes)
    }
}
