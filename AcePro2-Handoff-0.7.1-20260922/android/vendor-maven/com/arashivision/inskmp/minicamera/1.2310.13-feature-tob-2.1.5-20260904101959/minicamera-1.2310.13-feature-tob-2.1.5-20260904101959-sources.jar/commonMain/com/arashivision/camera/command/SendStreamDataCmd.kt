package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import com.arashivision.onedriver.packet.StreamType

class SendStreamDataCmd(val streamType: StreamType, val timestamp: Long, val data: ByteArray): InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.sendStreamData(streamType, timestamp, data)
    }
}