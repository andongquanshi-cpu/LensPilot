package com.arashivision.fmg.response

class FmgGetVerticalTrimDegreeResp {
    var requestID: Long
    var degree: Float = 0f

    constructor(requestID: Long) {
        this.requestID = requestID
    }

    constructor(requestID: Long, degree: Float) {
        this.requestID = requestID
        this.degree = degree
    }
}
