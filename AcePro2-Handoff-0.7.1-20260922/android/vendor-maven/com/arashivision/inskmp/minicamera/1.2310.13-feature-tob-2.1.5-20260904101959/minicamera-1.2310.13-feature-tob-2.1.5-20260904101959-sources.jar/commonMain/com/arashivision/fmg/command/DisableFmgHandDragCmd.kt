package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzHandDrag
import com.arashivision.onecamera.OneDriver

class DisableFmgHandDragCmd(private val list: ArrayList<PtzHandDrag>) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzDisableHandDrag(list)
    }
}
