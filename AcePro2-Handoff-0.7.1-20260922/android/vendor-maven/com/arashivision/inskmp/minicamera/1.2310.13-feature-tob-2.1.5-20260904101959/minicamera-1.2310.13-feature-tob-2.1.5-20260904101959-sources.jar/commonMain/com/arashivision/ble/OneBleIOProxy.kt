package com.arashivision.ble

/**
 * Created by vans on 30/11/17.
 */
interface OneBleIOProxy {
    fun onWrite(mData: ByteArray)

    fun onWifiProxyData(proxyData: ByteArray)
}

