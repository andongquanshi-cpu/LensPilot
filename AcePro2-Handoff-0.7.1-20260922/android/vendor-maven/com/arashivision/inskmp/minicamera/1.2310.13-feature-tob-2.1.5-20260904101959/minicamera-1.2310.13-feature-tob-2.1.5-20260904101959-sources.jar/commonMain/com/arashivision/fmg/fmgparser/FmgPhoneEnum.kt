package com.arashivision.fmg.fmgparser

import com.arashivision.common.BleLog
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PHONE_BRAND

enum class FmgPhoneEnum(val key: String, val value: Short) {
    IDLE("idle", PHONE_BRAND.PHONEBRAND_IDLE),
    IOS("ios", PHONE_BRAND.PHONEBRAND_IOS),
    HUIWEI("huawei", PHONE_BRAND.PHONEBRAND_HUAWEI),
    HONOR("honor", PHONE_BRAND.PHONEBRAND_HONOR),
    SAMSUNG("samsung", PHONE_BRAND.PHONEBRAND_SAMSUNG),
    OPPO("oppo", PHONE_BRAND.PHONEBRAND_OPPO),
    VIVO("vivo", PHONE_BRAND.PHONEBRAND_VIVO),
    ONEPLUS("oneplus", PHONE_BRAND.PHONEBRAND_ONEPLUS),
    REALME("realme", PHONE_BRAND.PHONEBRAND_REALME),
    GOOGLE("google", PHONE_BRAND.PHONEBRAND_GOOGLE),
    NOTHING("nothing", PHONE_BRAND.PHONEBRAND_Nothing),
    MEIZU("meizu", PHONE_BRAND.PHONEBRAND_MEIZU),
    XIAOMI("xiaomi", PHONE_BRAND.PHONEBRAND_XIAOMI),
    REDMI("redmi", PHONE_BRAND.PHONEBRAND_REDMI),
    OTHER("other", PHONE_BRAND.PHONEBRAND_OTHER);

    companion object {
        fun findByKey(key: String?): FmgPhoneEnum {
            for (data in values()) {
                if (data.key.equals(key, ignoreCase = true)) {
                    BleLog.e("find phone brand success, brand key is " + data.key + ", value is " + data.value)
                    return data
                }
            }
            BleLog.e("find phone brand fail $key")
            return OTHER
        }
    }
}
