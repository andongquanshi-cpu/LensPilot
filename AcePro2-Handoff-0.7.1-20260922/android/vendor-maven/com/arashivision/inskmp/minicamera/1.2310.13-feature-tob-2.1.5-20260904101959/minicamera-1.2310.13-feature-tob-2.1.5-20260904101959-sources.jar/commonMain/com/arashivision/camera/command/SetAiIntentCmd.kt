package com.arashivision.camera.command

import com.arashivision.onecamera.OneDriver
import insta360.messages.AiIntentCtrl

internal class SetAiIntentCmd(private val request: AiIntentCtrl) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Long? {
        return oneDrvier?.setAiIntent(request)
    }
}
