package com.arashivision.fmg.fmgparser.ptz.msg.req

import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.common.BleLog

class PtzAppHbReqMsg(
    private val time: Long, // 手机当前的拍摄模式，详细见rec_mode_e 的说明，在非拍摄页为REC_NULL
    private val mode: Short, // roll轴角度，单位0.1
    private val rollAngle: Short
) :
    PtzDataReqMessage() {
    private val mReserved = ByteArray(3) //uint8_t
    private val res16: Short = 0 // 保留

    override fun packData(): ByteArray? {
        val data = ByteArray(16)
        val byteArray = FmgByteUtils.longToUint64ByteArray(time)
        byteArray.copyInto(data, 0, 0, byteArray.size)
        data[8] = mode.toByte()
        mReserved.copyInto(data, 9, 0, 3)
        val rollAngleByteArray = FmgByteUtils.intToUint16ByteArray(rollAngle.toInt())
        rollAngleByteArray.copyInto(data, 12, 0, 2)
        val res16ByteArray = FmgByteUtils.intToUint16ByteArray(res16.toInt())
        res16ByteArray.copyInto(data, 14, 0, 2)
        BleLog.i("PtzAppHbReqMsg data = " + data.contentToString())
        return data
    }

    override fun toString(): String {
        return "PtzAppHbReqMsg{" +
                "time=" + time +
                ", mode=" + mode +
                ", rollAngle =" + rollAngle +
                '}'
    }

    override fun name(): String {
        return "CMD_APP_HB"
    }
}
