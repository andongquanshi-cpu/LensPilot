// minicamera/src/commonMain/kotlin/com/arashivision/onedriver/packet/MessageMuxer.kt
package com.arashivision.onedriver.packet

import com.arashivision.common.BleLog
import com.arashivision.common.Log
import insta360.messages.MessageCode

/**
 * 消息复用器 - 对应C++中的MessageMuxer类
 * 优化：简化分片逻辑，减少不必要的计算
 */
object MessageMuxer {

    /**
     * 将消息打包成数据包列表
     */
    fun mux(message: Message, protocol: Protocol, isClassicPipe: Boolean, encrypt: Boolean = false): List<Packet> {
        val maxContentSize = Packet.getMaxMessageContentSize(protocol, isClassicPipe)
        val contentSize = message.messageContentSize

        return if (contentSize > maxContentSize) {
            // 需要分片
            muxFragmented(message, maxContentSize, protocol, isClassicPipe)
        } else {
            // 单包
            listOf(createSinglePacket(message, protocol, isClassicPipe, encrypt))
        }
    }

    /**
     * 将消息打包成BLE数据包列表
     */
    fun muxBle(message: Message, isClassicPipe: Boolean): List<Go2BlePacket> {
        val maxContentSize = Go2BlePacket.getMaxMessageContentSize(isClassicPipe)
        val contentSize = message.messageContentSize
        return if (contentSize > maxContentSize) {
            // 需要分片
            muxBleFragmented(message, maxContentSize, isClassicPipe)
        } else {
            // 单包
            listOf(createSingleBlePacket(message, isClassicPipe))
        }
    }

    private fun muxFragmented(
        message: Message,
        maxContentSize: Int,
        protocol: Protocol,
        isClassicPipe: Boolean,
    ): List<Packet> {
        val packets = mutableListOf<Packet>()
        val content = message.messageContent
        var offset = 0

        while (offset < content.size) {
            val remainingSize = content.size - offset
            val currentSize = minOf(remainingSize, maxContentSize)
            val isLastFragment = offset + currentSize >= content.size

            val partContent = content.copyOfRange(offset, offset + currentSize)

            val packet = Packet.newMessagePacket(
                MessageCode.fromValue(message.messageMethod)!!,
                message.messageContentType,
                if (isLastFragment) 1 else 0,
                message.messageDirection,
                message.messageId,
                partContent,
                protocol,
                null,
                isClassicPipe
            )

            packets.add(packet)
            offset += currentSize
        }

        return packets
    }

    private fun createSinglePacket(message: Message, protocol: Protocol, isClassicPipe: Boolean, encrypt: Boolean): Packet {
        val encryption = if (encrypt) Packet.encryptParams else null
        return Packet.newMessagePacket(
            MessageCode.fromValue(message.messageMethod)!!,
            message.messageContentType,
            1, // 单包消息，结束标志为1
            message.messageDirection,
            message.messageId,
            message.messageContent,
            protocol,
            encryption,
            isClassicPipe,
        )
    }

    private fun muxBleFragmented(message: Message, maxContentSize: Int, isClassicPipe: Boolean): List<Go2BlePacket> {
        val packets = mutableListOf<Go2BlePacket>()
        val content = message.messageContent
        var offset = 0

        while (offset < content.size) {
            val remainingSize = content.size - offset
            val currentSize = minOf(remainingSize, maxContentSize)
            val isLastFragment = offset + currentSize >= content.size

            val partContent = content.copyOfRange(offset, offset + currentSize)
            val packet = Go2BlePacket.newBlePacket(
                MessageCode.fromValue(message.messageMethod)!!,
                message.messageContentType,
                if (isLastFragment) 1 else 0,
                message.messageDirection,
                message.messageId,
                partContent,
                isClassicPipe
            )

            packets.add(packet)
            offset += currentSize
        }

        return packets
    }

    private fun createSingleBlePacket(message: Message, isClassicPipe: Boolean): Go2BlePacket {
        return Go2BlePacket.newBlePacket(
            MessageCode.fromValue(message.messageMethod)!!,
            message.messageContentType,
            1, // 单包消息，结束标志为1
            message.messageDirection,
            message.messageId,
            message.messageContent,
            isClassicPipe
        )
    }
}