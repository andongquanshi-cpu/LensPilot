package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.common.Log

class PtzAngleSeqProcessRespMsg : PtzDataRespMessage() {
    var process: Int = 0

    override fun unpack(data: ByteArray?) {
        if (data == null || data.size < 1) {
            process = -1
            Log.d("unpack", "error!!!!")
            return
        } else {
            process = data[0].toInt()
        }
    }

    override fun toString(): String {
        return process.toString()
    }

    override fun name(): String {
        return "CMD_GRF_ANGLE_REACH"
    }
}
