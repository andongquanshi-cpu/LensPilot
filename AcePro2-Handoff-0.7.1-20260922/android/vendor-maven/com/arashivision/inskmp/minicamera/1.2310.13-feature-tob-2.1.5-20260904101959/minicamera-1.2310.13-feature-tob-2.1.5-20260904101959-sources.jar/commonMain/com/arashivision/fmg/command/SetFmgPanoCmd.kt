package com.arashivision.fmg.command

import com.arashivision.camera.command.InstaCmdExe
import com.arashivision.fmg.response.model.FmgModel.PtzPanoMode
import com.arashivision.onecamera.OneDriver

class SetFmgPanoCmd(private val mode: PtzPanoMode) : InstaCmdExe {
    override suspend fun exeCmd(oneDrvier: OneDriver?): Any? {
        return oneDrvier?.ptzSetPano(mode)
    }
}
