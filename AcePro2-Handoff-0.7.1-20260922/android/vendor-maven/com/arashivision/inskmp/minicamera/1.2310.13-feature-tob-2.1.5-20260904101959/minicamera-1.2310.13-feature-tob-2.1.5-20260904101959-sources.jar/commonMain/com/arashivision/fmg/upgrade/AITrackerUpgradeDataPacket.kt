package com.arashivision.fmg.upgrade

import com.arashivision.fmg.fmgparser.ptz.IDataPacket
import com.arashivision.fmg.fmgparser.ptz.PtzDataPacket
import com.arashivision.fmg.fmgparser.ptz.msg.req.PtzUpdateingReqMsg

class AITrackerUpgradeDataPacket(
//uint8_t
    override val cmd: Short, //uint8_t
    override val frame: Short
) : IDataPacket {
    private val mStart = 0xA5.toByte().toShort() //uint8_t

    override var data: ByteArray? = null
        private set
    private val mMsgList: MutableList<PtzUpdateingReqMsg> = ArrayList()
    override var crc16: Int = 0 //uint16_t
        private set

    var dataContextLength: Int = 0
        private set

    fun addPtzUpdateingReqMsg(msg: PtzUpdateingReqMsg) {
        mMsgList.add(msg)
    }

    private fun sumData(data: ByteArray, data1: ByteArray): ByteArray {
        val sumData = ByteArray(data.size + data1.size)
        data.copyInto(sumData, 0, 0, data.size)
        data1.copyInto(sumData, data.size, 0, data1.size)
        return sumData
    }


    override fun packetPack(data: ByteArray?): ByteArray {
        if (mMsgList == null || mMsgList.isEmpty()) return byteArrayOf()
        var packet = PtzDataPacket(cmd, frame)
        crc16 = packet.crc16
        var dataContext: ByteArray?
        dataContextLength = 0
        for (i in mMsgList.indices) {
            dataContext = mMsgList[i].packData()
            dataContextLength += dataContext!!.size
            if (i == 0) {
                this.data = packet.packetPack(dataContext)
            } else {
                packet = PtzDataPacket(cmd, (frame + i).toShort())
                this.data = sumData(this.data!!, packet.packetPack(dataContext))
            }
        }
        if (this.data == null) {
            this.data = byteArrayOf()
        }
        return this.data!!
    }
}
