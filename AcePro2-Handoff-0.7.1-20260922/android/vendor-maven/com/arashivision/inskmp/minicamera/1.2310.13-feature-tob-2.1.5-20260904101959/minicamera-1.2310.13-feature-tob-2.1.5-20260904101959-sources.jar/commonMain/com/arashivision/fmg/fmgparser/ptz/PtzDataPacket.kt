package com.arashivision.fmg.fmgparser.ptz

import com.arashivision.fmg.fmgparser.FmgByteUtils
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzCmd
import com.arashivision.fmg.fmgparser.ptz.PtzStatus.PtzFrame
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzAiTrackerSettingsReadRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzAngleSeqProcessRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzBasketballG2ARespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzDataRespMessage
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzDeviceInfoRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzDeviceStatusRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzEmptyRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetActiveTimeRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetAiTrackerDeviceInfoRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetAiTrackerUpdatingRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetButtonEnableRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdBleHeaderRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdBleQuickStartEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdCFEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdErrorStateEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdHeaderRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdPowerOffEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdPowerOnEventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetEtdYaw360EventRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGetUuidRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzGimbalCalStatusRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzMidcalRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzRcGetRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzResetDefaultSettingRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzSettingsReadRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzShakeHandRespOkMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzTrackSensitivityModeRespMsg
import com.arashivision.fmg.fmgparser.ptz.msg.resp.PtzVerticalTrimRespMsg
import com.arashivision.fmg.response.model.FmgModel.PtzAngleSqeState
import kotlin.experimental.inv

class PtzDataPacket(
//uint8_t
    override val cmd: Short, //uint8_t
    override val frame: Short,
) : IDataPacket {
    private val mStart = 0xA5.toByte().toShort() //uint8_t
    private var mLength: Short = 0 //uint8_t
    override var data: ByteArray? = null
        //uint8_t
        private set
    override var crc16: Int = 0 //uint16_t
        private set

    override fun packetPack(data: ByteArray?): ByteArray {
        var data = data
        if (data == null) {
            data = ByteArray(0)
        }
        this.data = data
        if (data.size == 256) { //特殊情况，在升级固件时，data长度为256，但length的值为254，做特殊处理
            this.mLength = 254
        } else {
            this.mLength = data.size.toByte().toShort()
        }
        val packetCrcData = ByteArray(data.size + 5)
        packetCrcData[0] = mStart.toByte()
        packetCrcData[1] = cmd.toByte()
        packetCrcData[2] = frame.toByte()
        packetCrcData[3] = mLength.toByte()
        data.copyInto(packetCrcData, 4, 0, data.size)
        packetCrcData[data.size + 4] = cmd.toByte().inv() //原mavlink的crc_extra换为cmd取反

        val crc = PtzCrc()
        for (packetCrcDatum in packetCrcData) {
            crc.update_checksum(packetCrcDatum.toInt())
        }

        val packetData = ByteArray(packetCrcData.size + 1)
        packetCrcData.copyInto(packetData, 0, 0, packetCrcData.size - 1)
        crc16 = crc.crcValue
        val crcbytes = FmgByteUtils.intToUint16ByteArray(crc16)
        packetData[packetData.size - 2] = crcbytes[0]
        packetData[packetData.size - 1] = crcbytes[1]

        return packetData
    }

    fun unPack(): PtzDataRespMessage { //返回packet的data为空时，返回一个EmptyMsg，其中data数组长度为0
        if (data == null || data!!.size == 0) {
            return PtzEmptyRespMsg()
        }
        when (cmd) {
            PtzCmd.CMD_SHAKE_HAND -> when (frame) {
                PtzFrame.ACK_OK, PtzFrame.ACK_SHAKE_HAND -> {
                    val ptzShakeHandRespMsg = PtzShakeHandRespOkMsg()
                    ptzShakeHandRespMsg.unpack(data!!)
                    return ptzShakeHandRespMsg
                }

                else -> return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_DEVICE_INFO -> when (frame) {
                PtzFrame.ACK_OK -> {
                    val ptzDeviceInfoRespMsg = PtzDeviceInfoRespMsg()
                    ptzDeviceInfoRespMsg.unpack(data)
                    return ptzDeviceInfoRespMsg
                }

                else -> return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_DEVICE_STATUS -> {
                val ptzDeviceStatusRespMsg = PtzDeviceStatusRespMsg()
                ptzDeviceStatusRespMsg.unpack(data!!)
                return ptzDeviceStatusRespMsg
            }

            PtzCmd.CMD_GET_ACTIVE_TIME -> when (frame) {
                PtzFrame.ACK_OK -> {
                    val ptzGetActiveTimeRespMsg = PtzGetActiveTimeRespMsg()
                    ptzGetActiveTimeRespMsg.unpack(data!!)
                    return ptzGetActiveTimeRespMsg
                }

                else -> return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_SETTINGS_READ -> if (frame == PtzFrame.SF_ALL) {
                val ptzSettingsReadRespMsg = PtzSettingsReadRespMsg()
                ptzSettingsReadRespMsg.unpack(data!!)
                return ptzSettingsReadRespMsg
            } else {
                return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_RESET_DEFAULT_SETTINGS -> if (frame == PtzFrame.ACK_OK) {
                val resetDefaultSettingRespMsg = PtzResetDefaultSettingRespMsg()
                resetDefaultSettingRespMsg.unpack(data!!)
                return resetDefaultSettingRespMsg
            } else {
                return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_VERTICAL_TRIM -> if (frame.toInt() == 0) {
                val ptzVerticalTrimRespMsg = PtzVerticalTrimRespMsg()
                ptzVerticalTrimRespMsg.unpack(data!!)
                return ptzVerticalTrimRespMsg
            } else {
                return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_GIMBAL_CAL_STATUS -> {
                val ptzGimbalCalStatusRespMsg = PtzGimbalCalStatusRespMsg()
                ptzGimbalCalStatusRespMsg.unpack(data!!)
                return ptzGimbalCalStatusRespMsg
            }

            PtzCmd.CMD_MID_CAL -> {
                val ptzMidcalRespMsg = PtzMidcalRespMsg()
                ptzMidcalRespMsg.unpack(data!!)
                return ptzMidcalRespMsg
            }

            PtzCmd.CMD_GET_UUID -> {
                val ptzGetUuidRespMsg = PtzGetUuidRespMsg()
                ptzGetUuidRespMsg.unpack(data!!)
                return ptzGetUuidRespMsg
            }

            PtzCmd.CMD_RC_GET -> {
                val ptzRcGetRespMsg = PtzRcGetRespMsg()
                ptzRcGetRespMsg.unpack(data!!)
                return ptzRcGetRespMsg
            }

            PtzCmd.CMD_GET_ETD -> when (frame) {
                PtzFrame.ETD_ITEM_HEADER -> {
                    val ptzGetEtdHeaderRespMsg = PtzGetEtdHeaderRespMsg()
                    ptzGetEtdHeaderRespMsg.unpack(data!!)
                    return ptzGetEtdHeaderRespMsg
                }

                PtzFrame.ETD_ITEM_FPON, PtzFrame.ETD_ITEM_KPON -> {
                    val ptzGetEtdPowerOnEventRespMsg = PtzGetEtdPowerOnEventRespMsg()
                    ptzGetEtdPowerOnEventRespMsg.unpack(data!!)
                    return ptzGetEtdPowerOnEventRespMsg
                }

                PtzFrame.ETD_ITEM_FPO, PtzFrame.ETD_ITEM_KPO, PtzFrame.ETD_ITEM_FOPO -> {
                    val ptzGetEtdPowerOffEventRespMsg = PtzGetEtdPowerOffEventRespMsg()
                    ptzGetEtdPowerOffEventRespMsg.unpack(data!!)
                    return ptzGetEtdPowerOffEventRespMsg
                }

                PtzFrame.ETD_ITEM_ERR -> {
                    val ptzGetEtdErrorStateEventRespMsg = PtzGetEtdErrorStateEventRespMsg()
                    ptzGetEtdErrorStateEventRespMsg.unpack(data!!)
                    return ptzGetEtdErrorStateEventRespMsg
                }

                PtzFrame.ETD_ITEM_CF -> {
                    val ptzGetEtdCFEventRespMsg = PtzGetEtdCFEventRespMsg()
                    ptzGetEtdCFEventRespMsg.unpack(data!!)
                    return ptzGetEtdCFEventRespMsg
                }

                PtzFrame.ETD_ITEM_YAW_360 -> {
                    val ptzGetEtdYaw360EventRespMsg = PtzGetEtdYaw360EventRespMsg()
                    ptzGetEtdYaw360EventRespMsg.unpack(data!!)
                    return ptzGetEtdYaw360EventRespMsg
                }

                else -> return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_GET_ETD_BLE -> {
                when (frame) {
                    PtzStatus.PtzFrame.ETD_BLE_ITEM_HEADER -> {
                        val ptzGetEtdBleHeaderRespMsg = PtzGetEtdBleHeaderRespMsg()
                        ptzGetEtdBleHeaderRespMsg.unpack(data)
                        return ptzGetEtdBleHeaderRespMsg
                    }

                    PtzStatus.PtzFrame.ETD_BLE_ITEM_QUICK_START -> {
                        val ptzGetEtdBleQuickStartEventRespMsg = PtzGetEtdBleQuickStartEventRespMsg()
                        ptzGetEtdBleQuickStartEventRespMsg.unpack(data)
                        return ptzGetEtdBleQuickStartEventRespMsg
                    }

                    else -> return PtzEmptyRespMsg()
                }
            }

            PtzCmd.CMD_GRF_ANGLE_REACH -> if (frame == PtzAngleSqeState.GRF_ANGLE_SEQ_PROCESS.nativeValue) {
                val respMsg = PtzAngleSeqProcessRespMsg()
                respMsg.unpack(data!!)
                return respMsg
            } else {
                return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_GET_EVENT_STATUS -> {
                val respMsg = PtzGetButtonEnableRespMsg()
                respMsg.unpack(data!!)
                return respMsg
            }

            PtzCmd.CMD_ETS -> if (frame == PtzFrame.ETS_GET) {
                val trackSensitivityModeRespMsg = PtzTrackSensitivityModeRespMsg()
                trackSensitivityModeRespMsg.unpack(data!!)
                return trackSensitivityModeRespMsg
            } else {
                return PtzEmptyRespMsg()
            }

            PtzCmd.CMD_BASKETBALL_G2A -> {
                val ptzBasketballG2ARespMsg = PtzBasketballG2ARespMsg()
                ptzBasketballG2ARespMsg.unpack(data)
                return ptzBasketballG2ARespMsg
            }

            PtzCmd.CMD_AI_TRACKER_DEVICE_INFO -> {
                val ptzGetAiTrackerDeviceInfoRespMsg = PtzGetAiTrackerDeviceInfoRespMsg()
                ptzGetAiTrackerDeviceInfoRespMsg.unpack(data!!)
                return ptzGetAiTrackerDeviceInfoRespMsg
            }

            PtzCmd.CMD_AI_TRACKER_UPDATING -> {
                val aiTrackerUpdatingRespMsg = PtzGetAiTrackerUpdatingRespMsg()
                aiTrackerUpdatingRespMsg.unpack(data!!)
                return aiTrackerUpdatingRespMsg
            }

            PtzCmd.CMD_AI_TRACKER_SETTING_READ -> if (frame == PtzFrame.SF_ALL) {
                val aiTrackerSettingsReadRespMsg = PtzAiTrackerSettingsReadRespMsg()
                aiTrackerSettingsReadRespMsg.unpack(data!!)
                return aiTrackerSettingsReadRespMsg
            }
        }
        return PtzEmptyRespMsg()
    }
}
