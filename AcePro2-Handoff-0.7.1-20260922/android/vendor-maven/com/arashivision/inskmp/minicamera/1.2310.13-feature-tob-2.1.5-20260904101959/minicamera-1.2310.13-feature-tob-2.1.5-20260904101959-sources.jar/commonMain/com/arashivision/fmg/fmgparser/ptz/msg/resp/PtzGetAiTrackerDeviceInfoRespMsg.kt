package com.arashivision.fmg.fmgparser.ptz.msg.resp

import com.arashivision.fmg.fmgparser.FmgByteUtils

class PtzGetAiTrackerDeviceInfoRespMsg : PtzDataRespMessage() {
    var sn: String = ""
    var type: String = ""
    var kernel_version: String = ""
    var models_version: MutableList<Int> = ArrayList()

    override fun unpack(data: ByteArray?) {
        if (data == null) return
        sn = FmgByteUtils.byteArrayToStringOnUS_ASCII(data.copyOfRange(0, 14))
        type = FmgByteUtils.byteArrayToStringOnUS_ASCII(data.copyOfRange(14, 40))
        kernel_version = parserKernelVersion(data.copyOfRange(40, 44))
        val versionList = data.copyOfRange(44, 64)
        for (b in versionList) {
            models_version.add(b.toUnsignedInt())
        }
    }

    private fun parserKernelVersion(bytes: ByteArray): String {
        val stringBuilder = StringBuilder()
        for (i in bytes.indices.reversed()) {
            stringBuilder.append(bytes[i].toUnsignedInt())
            if (i > 0) {  // 如果不是第一个元素（现在是从后向前，所以条件也反过来）
                stringBuilder.append('.')
            }
        }
        return stringBuilder.toString()
    }

    override fun toString(): String {
        return "PtzGetAiTrackerDeviceInfoRespMsg{" +
                "sn='" + sn + '\'' +
                ", type='" + type + '\'' +
                ", kernel_version='" + kernel_version + '\'' +
                ", models_version=" + models_version +
                '}'
    }

    override fun name(): String {
        return "CMD_AI_TRACKER_DEVICE_INFO"
    }
}

fun Byte.toUnsignedInt(): Int = this.toInt() and 0xFF
