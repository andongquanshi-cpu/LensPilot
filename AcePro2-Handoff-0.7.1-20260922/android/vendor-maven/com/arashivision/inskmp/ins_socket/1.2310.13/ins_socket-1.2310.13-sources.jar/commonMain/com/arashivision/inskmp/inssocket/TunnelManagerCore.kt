package com.arashivision.inskmp.inssocket

import com.arashivision.inskmp.inssocket.callback.TunnelCallbackCore
import com.arashivision.inskmp.inssocket.data.TunnelData
/**
 * Socket Manager Core - Common interface for socket operations
 * Provides cross-platform socket functionality with open(), serve(), write(), read() methods
 */
expect class TunnelManagerCore() {

    /**
     * Initialize the socket manager
     * @return 0 on success, error code on failure
     */
    fun init(): Int

    /**
     * Write data to tunnel
     * @param tunnelData TunnelData containing data and metadata to write
     * @return 0 on success, error code on failure
     */
    fun write(tunnelData: TunnelData): Int

    /**
     * Read data from tunnel
     * @return TunnelData containing data, connectionId, flags, windowLimit, or null if no data
     */
    fun read(): TunnelData?

    /**
     * Get current tunnelServerPort
     * @return serverPort
     */
    fun getServerPort(): Int

    /**
     * Set callback for tunnel
     * @param callback TunnelCallbackCore callback interface
     */
    fun setOnReadableCallback(callback: TunnelCallbackCore?)

    /**
     * C++ DriverTunnel release
     */
    fun release()

    /**
     * Destroy tunnel manager and cleanup resources
     */
    fun destroy()
}
