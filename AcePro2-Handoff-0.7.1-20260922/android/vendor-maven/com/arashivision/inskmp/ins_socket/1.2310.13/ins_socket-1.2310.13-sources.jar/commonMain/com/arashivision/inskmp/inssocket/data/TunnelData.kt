package com.arashivision.inskmp.inssocket.data

/**
 * Tunnel data container
 * Contains tunnel content and metadata
 */
data class TunnelData(
    val data: ByteArray,
    val connectionId: Int,
    val flags: Int,
    val windowLimit: Long
) {
    override fun toString(): String {
        return "TunnelData(connectionId=$connectionId, flags=$flags, windowLimit=$windowLimit, dataSize=${data.size})"
    }
}
