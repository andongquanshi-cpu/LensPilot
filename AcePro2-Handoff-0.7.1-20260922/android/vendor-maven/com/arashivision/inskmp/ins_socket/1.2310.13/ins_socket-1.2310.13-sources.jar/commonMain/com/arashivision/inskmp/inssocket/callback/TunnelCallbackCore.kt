package com.arashivision.inskmp.inssocket.callback

/**
 * Tunnel callback interface for handling tunnel events
 */
interface TunnelCallbackCore {
    /**
     * Called when data is received from tunnel
     */
    fun OnReadableCallback()
}
