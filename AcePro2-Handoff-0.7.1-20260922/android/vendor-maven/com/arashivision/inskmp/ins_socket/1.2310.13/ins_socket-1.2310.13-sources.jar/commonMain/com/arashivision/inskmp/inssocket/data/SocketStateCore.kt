package com.arashivision.inskmp.inssocket.data

/**
 * Socket state enumeration
 */
enum class SocketStateCore {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR,
    CLOSED
}

enum class SocketError {
    NONE,
    OPEN,
    SERVE,
    SYNCED,
    WRITE,
    READ,
    CLOSE
}
