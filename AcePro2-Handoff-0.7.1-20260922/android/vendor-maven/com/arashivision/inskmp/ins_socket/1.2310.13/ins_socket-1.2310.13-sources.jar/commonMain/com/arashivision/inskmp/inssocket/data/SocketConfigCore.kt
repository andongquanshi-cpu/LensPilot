package com.arashivision.inskmp.inssocket.data

/**
 * Socket configuration data class
 * Contains all necessary parameters for socket connection
 */
data class SocketConfigCore(
    val networkHandle: Long = 0L,
    val to: Int = 30000, // 30 seconds default
    val addr: String,
    val port: Int
)
