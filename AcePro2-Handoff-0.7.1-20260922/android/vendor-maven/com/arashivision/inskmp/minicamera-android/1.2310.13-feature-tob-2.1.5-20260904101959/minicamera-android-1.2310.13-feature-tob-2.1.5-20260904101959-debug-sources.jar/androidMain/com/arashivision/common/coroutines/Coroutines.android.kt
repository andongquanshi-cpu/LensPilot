package com.arashivision.common.coroutines

import android.os.Looper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * 安全地在主线程执行代码块
 *
 * 这个函数会根据平台自动选择合适的主线程执行方式：
 * - OHOS 平台：使用 knoi 框架的 runOnMainThread
 * - 其他平台：使用协程的 Dispatchers.Main
 *
 * 使用示例：
 * ```
 * runOnMainThread {
 *     // 这里的代码在主线程执行
 * }
 * ```
 *
 * @param block 要在主线程执行的代码块
 */

val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

actual fun runOnMainThread(block: () -> Unit) {
    if (Thread.currentThread() == Looper.getMainLooper().thread) {
        block.invoke()
    } else {
        mainScope.launch {
            block.invoke()
        }
    }
}