package com.arashivision.onedriver.utils


/**
 * Android 平台的 GBK 编码解码实现
 * 通过内部类提供平台特定的实现
 */
actual object PlatformGBKDecoder {
    actual fun decode(bytes: ByteArray): String {
        val gbkCharset = java.nio.charset.Charset.forName("GBK")
        return String(bytes, gbkCharset)
    }

    actual fun encode(text: String): ByteArray {
        val gbkCharset = java.nio.charset.Charset.forName("GBK")
        return text.toByteArray(gbkCharset)
    }

}
