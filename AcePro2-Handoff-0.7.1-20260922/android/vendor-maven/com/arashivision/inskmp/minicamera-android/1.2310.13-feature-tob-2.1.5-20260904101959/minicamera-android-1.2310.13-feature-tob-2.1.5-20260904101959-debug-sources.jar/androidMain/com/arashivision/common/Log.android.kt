package com.arashivision.common

import android.util.Log

actual object Log {
    private var callback: ICameraLoggerCallback? = null
    actual fun v(tag: String, msg: String) {
        callback?.onLogV(tag, msg) ?: Log.v(tag, msg)
    }

    actual fun d(tag: String, msg: String) {
        callback?.onLogD(tag, msg) ?: Log.d(tag, msg)
    }

    actual fun i(tag: String, msg: String) {
        callback?.onLogI(tag, msg) ?: Log.i(tag, msg)
    }

    actual fun w(tag: String, msg: String) {
        callback?.onLogW(tag, msg) ?: Log.w(tag, msg)
    }

    actual fun e(tag: String, msg: String) {
        callback?.onLogE(tag, msg) ?: Log.e(tag, msg)
    }

    actual fun t(tag: String, msg: String) {
        callback?.onLogT(tag, msg) ?: Log.e(tag, msg)
    }

    actual fun setCameraLoggerCallback(callback: ICameraLoggerCallback) {
        this.callback = callback
    }

}