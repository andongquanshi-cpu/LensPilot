package com.arashivision.common

import android.os.Build

actual object Build {
    actual val BRAND: String?
        get() = Build.BOARD
}