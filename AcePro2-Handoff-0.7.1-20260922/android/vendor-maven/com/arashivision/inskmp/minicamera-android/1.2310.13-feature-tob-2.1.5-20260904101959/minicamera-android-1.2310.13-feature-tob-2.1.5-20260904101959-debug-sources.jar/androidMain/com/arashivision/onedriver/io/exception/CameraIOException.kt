package com.arashivision.onedriver.io.exception

import java.io.IOException


open class CameraIOException : IOException {
    constructor(msg: String?) : super(msg)

    constructor()

    constructor(cause: Throwable?) : super(cause)

    constructor(msg: String?, cause: Throwable?) : super(msg, cause)
}
