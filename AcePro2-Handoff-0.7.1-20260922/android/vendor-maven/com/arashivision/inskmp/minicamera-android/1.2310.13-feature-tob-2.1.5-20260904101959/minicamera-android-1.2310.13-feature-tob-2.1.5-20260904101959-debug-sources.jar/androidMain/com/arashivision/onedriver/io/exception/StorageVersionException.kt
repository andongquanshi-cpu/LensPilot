package com.arashivision.onedriver.io.exception


class StorageVersionException(msg: String?) : CameraIOException(msg)
