package com.arashivision.onedriver.io.exception


class StorageInvalidDataException(msg: String?) : CameraIOException(msg)
