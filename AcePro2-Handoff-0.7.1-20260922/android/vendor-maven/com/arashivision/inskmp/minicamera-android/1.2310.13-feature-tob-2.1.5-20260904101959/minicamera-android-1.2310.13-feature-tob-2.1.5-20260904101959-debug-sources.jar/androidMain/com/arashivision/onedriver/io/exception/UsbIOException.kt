package com.arashivision.onedriver.io.exception

import java.io.IOException


class UsbIOException(msg: String?) : IOException(msg)
