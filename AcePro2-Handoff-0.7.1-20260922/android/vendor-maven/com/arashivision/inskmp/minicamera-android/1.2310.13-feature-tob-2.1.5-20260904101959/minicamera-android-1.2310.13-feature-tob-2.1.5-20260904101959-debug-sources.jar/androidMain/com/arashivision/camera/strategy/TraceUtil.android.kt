package com.arashivision.camera.strategy

import com.arashivision.minicamera.BuildConfig

actual object TraceUtil {
    actual var TRACE: Boolean = BuildConfig.DEBUG
}