package com.arashivision.common

import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.IOException
import java.security.MessageDigest

actual class File actual constructor(path: String, fileName: String?) {

    private val file: java.io.File = if(fileName.isNullOrEmpty()) java.io.File(path) else java.io.File(path, fileName)
    actual fun exists(): Boolean {
        return file.exists()
    }

    actual fun length(): Long {
        return file.length()
    }

    actual fun read(): ByteArray? {
        var buffer: ByteArray? = null
        try {
            FileInputStream(file).use { fis ->
                ByteArrayOutputStream().use { bos ->
                    val b = ByteArray(1024)
                    var n: Int
                    while ((fis.read(b).also { n = it }) != -1) {
                        bos.write(b, 0, n)
                    }
                    buffer = bos.toByteArray()
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }
        return buffer
    }

    actual fun getName(): String {
        return file.name
    }

    actual fun getFileMD5String(): String {
        if (!file.exists() || !file.isFile) {
            return ""
        }
        try {
            FileInputStream(file).use { fis ->
                val md = MessageDigest.getInstance("MD5")
                val buffer = ByteArray(8192)
                var bytesRead: Int
                while (fis.read(buffer).also { bytesRead = it } != -1) {
                    md.update(buffer, 0, bytesRead)
                }
                val digest = md.digest()
                val sb = StringBuilder()
                for (b in digest) {
                    sb.append(String.format("%02x", b))
                }
                return sb.toString()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return ""
        }
    }

    actual fun getParent(): String? {
        return file.parent
    }

    actual fun getAbsolutePath(): String {
        return file.absolutePath
    }

    actual fun renameTo(dstPath: String): Boolean {
        val destFile = java.io.File(dstPath)
        return file.renameTo(destFile)
    }

    actual fun fullDelete(): Boolean {
        return deleteRecursively(file)
    }

    private fun deleteRecursively(file: java.io.File): Boolean {
        if (file.isDirectory) {
            val files = file.listFiles()
            if (files != null) {
                for (child in files) {
                    if (!deleteRecursively(child)) {
                        return false
                    }
                }
            }
        }
        return file.delete()
    }

    actual fun mkdirs(): Boolean {
        return file.mkdirs()
    }

    actual fun isFile(): Boolean {
        return file.isFile
    }

    actual fun listFiles(): List<File>? {
        val files = file.listFiles() ?: return null
        return files.map { File(it.absolutePath, null) }
    }

    actual fun readBytesFromFile(): ByteArray {
        return read() ?: ByteArray(0)
    }

    actual fun delete(): Boolean {
        return file.delete()
    }


}