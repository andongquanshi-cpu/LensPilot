package com.arashivision.onedriver.io.exception

class StorageFileEmptyException(msg: String?) : CameraIOException(msg)


