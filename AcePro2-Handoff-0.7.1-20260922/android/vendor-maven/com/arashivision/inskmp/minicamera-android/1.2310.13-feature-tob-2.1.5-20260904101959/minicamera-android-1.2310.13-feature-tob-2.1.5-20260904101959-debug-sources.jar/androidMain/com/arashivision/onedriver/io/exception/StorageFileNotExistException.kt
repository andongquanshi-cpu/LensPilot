package com.arashivision.onedriver.io.exception

class StorageFileNotExistException(msg: String?) : CameraIOException(msg)
