package com.arashivision.common

import android.os.SystemClock
import java.util.TimeZone

actual fun currentTimeMillis(): Long {
    return System.currentTimeMillis()
}

actual fun formatLocalTime(time: Long): Int {
    return TimeZone.getDefault().getOffset(time * 1000) / 1000
}

actual fun elapsedRealtime(): Long {
    return SystemClock.elapsedRealtime()
}