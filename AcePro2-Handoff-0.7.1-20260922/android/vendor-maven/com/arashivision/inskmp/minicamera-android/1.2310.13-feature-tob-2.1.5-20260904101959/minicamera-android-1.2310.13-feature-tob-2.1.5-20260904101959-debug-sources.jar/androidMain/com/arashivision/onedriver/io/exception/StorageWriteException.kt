package com.arashivision.onedriver.io.exception


class StorageWriteException(msg: String?) : CameraIOException(msg)
