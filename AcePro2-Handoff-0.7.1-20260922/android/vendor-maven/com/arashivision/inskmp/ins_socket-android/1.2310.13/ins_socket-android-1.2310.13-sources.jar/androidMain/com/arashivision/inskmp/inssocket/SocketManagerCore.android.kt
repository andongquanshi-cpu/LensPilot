package com.arashivision.inskmp.inssocket

import com.arashivision.inskmp.inssocket.callback.SocketCallbackCore
import com.arashivision.inskmp.inssocket.data.SocketConfigCore
import com.arashivision.inskmp.inssocket.data.SocketStateCore

actual class SocketManagerCore {

    companion object {
        // 静态初始化 JNI 库
        init {
            try {
                System.loadLibrary("inssocket")
                println("[Kotlin] SocketManagerCore JNI 库加载成功！")
            } catch (e: Exception) {
                println("[Kotlin] SocketManagerCore JNI 库加载失败: ${e.message}")
            }
        }
    }

    private external fun nativeOpen(networkHandle: Long, to: Int, addr: String, port: Int): Int
    private external fun nativeServe(): Int
    private external fun nativeSetSynced(synced: Boolean): Int
    private external fun nativeWrite(data: List<ByteArray>): Int
    private external fun nativeClose(): Int
    private external fun nativeSetCallback(): Int
    private external fun nativeClearJni(): Int

    // JNI 原生对象指针，由JNI层管理
    private var mNativeInstance: Long = 0

    private var config: SocketConfigCore? = null
    private var callback: SocketCallbackCore? = null
    private var currentState: SocketStateCore = SocketStateCore.DISCONNECTED

    actual fun init(config: SocketConfigCore): Int {
        this.config = config
        currentState = SocketStateCore.DISCONNECTED
        return 0
    }

    actual fun open(): Int {
        if (config == null) {
            println("[SocketManagerCore] Open(), but config == null!")
            return -1
        }

        currentState = SocketStateCore.CONNECTING
        try {
            // 调用 JNI OPEN函数！
            println("[SocketManagerCore] 调用 nativeOpen...")
            val result = nativeOpen(
                config!!.networkHandle,
                config!!.to,
                config!!.addr,
                config!!.port
            )
            println("[SocketManagerCore] Socket 打开完成，result=$result")

            if (result == 0) {
                currentState = SocketStateCore.CONNECTED
                println("[SocketManagerCore] Socket 连接成功！")
            } else {
                currentState = SocketStateCore.ERROR
                println("[SocketManagerCore] Socket 连接失败，错误码: $result")
            }
            return result
        } catch (e: Exception) {
            currentState = SocketStateCore.ERROR
            println("[SocketManagerCore] Exception during JNI socket open:: ${e.message}")
            return -1
        }
    }

    actual fun setCallback(callback: SocketCallbackCore?) {
        this.callback = callback

        // 如果callback不为null，确保JNI层已经初始化
        if (this.callback != null) {
            try {
                // 初始化 JNI 层的全局引用
                nativeSetCallback()
                println("[SocketManagerCore] JNI Callback 初始化成功")
            } catch (e: Exception) {
                println("[SocketManagerCore] JNI Callback 初始化失败: ${e.message}")
                return
            }
        }

        println("[SocketManagerCore] Callback 设置成功: ${callback != null}")
    }

    // JNI 回调方法，供 C++ 层调用（参考 OneDriverJni.cpp 的 callInfoNotify）
    private fun onDataReceived(data: ByteArray) {
//        println("[SocketManagerCore] C++ 层数据回调: 收到 ${data.size} 字节")
        callback?.onDataReceived(data)
    }

    private fun onError(errorCode: Int) {
        println("[SocketManagerCore] C++ 层错误回调: errorCode=$errorCode")
        currentState = SocketStateCore.ERROR
        callback?.onError(errorCode)
    }

    actual fun serve(): Int {
        if (currentState != SocketStateCore.CONNECTED) {
            println("[SocketManagerCore] serve(), but Socket not opened")
            return -1
        }

        try {
            // 调用 JNI serve 函数
            println("[SocketManagerCore] 调用 nativeServe...")
            val result = nativeServe()
            println("[SocketManagerCore] Socket serve 完成，result=$result")

            if (result != 0) {
                currentState = SocketStateCore.ERROR
                println("[SocketManagerCore] Failed to start socket serve via JNI")
            }
            return result
        } catch (e: Exception) {
            currentState = SocketStateCore.ERROR
            println("[SocketManagerCore] Exception during JNI socket serve: ${e.message}")
            return -1
        }
    }

    actual fun setSynced(synced: Boolean): Int {
        if (currentState != SocketStateCore.CONNECTED) {
            println("[SocketManagerCore] setSynced, currentState != SocketStateCore.CONNECTED!")
            return -1
        }

        try {
            // 调用 JNI setSynced 函数
            println("[SocketManagerCore] 调用 nativeSetSynced...")
            val result = nativeSetSynced(synced)
            println("[SocketManagerCore] Socket setSynced 完成，result=$result")

            if (result != 0) {
                currentState = SocketStateCore.ERROR
                println("[SocketManagerCore] Failed to start socket setSynced via JNI")
            }
            return result
        } catch (e: Exception) {
            currentState = SocketStateCore.ERROR
            println("[SocketManagerCore] Exception during JNI socket setSynced: ${e.message}")
            return -1
        }
    }

    actual fun write(data: List<ByteArray>): Int {
        if (currentState != SocketStateCore.CONNECTED) {
            println("[SocketManagerCore] write, but currentState != SocketStateCore.CONNECTED")
            return -1
        }

        try {
            // 调用 JNI write 函数
            val result = nativeWrite(data)

            if (result != 0) {
                println("[SocketManagerCore] Failed to write data to socket via JNI")
            }
            return result
        } catch (e: Exception) {
            println("[SocketManagerCore] Exception during JNI socket write: ${e.message}")
            return -1
        }
    }

    actual fun read(buffer: ByteArray): Int {
        if (currentState != SocketStateCore.CONNECTED) {
            println("[SocketManagerCore] read, but currentState != SocketStateCore.CONNECTED")
            return -1
        }

        try {
            // 注意：对于 JNI，read 操作通常通过回调处理
            // 这里返回 0 表示没有立即可用的数据
            println("[SocketManagerCore] read 操作 - JNI 版本通过回调处理数据")
            return 0
        } catch (e: Exception) {
            println("[SocketManagerCore] Exception during JNI socket read: ${e.message}")
            return -1
        }
    }

    actual fun getState(): SocketStateCore {
        return currentState
    }

    actual fun close(): Int {
        try {
            // 调用 JNI close 函数
            println("[SocketManagerCore] 调用 nativeClose...")
            val result = nativeClose()
            println("[SocketManagerCore] Socket close 完成，result=$result")

            currentState = SocketStateCore.CLOSED
            return result
        } catch (e: Exception) {
            println("[SocketManagerCore] Exception during JNI socket close: ${e.message}")
            return -1
        }
    }

    actual fun destroy() {
        // 释放kt和jni资源
        println("[SocketManagerCore] 调用 destroy...")

        // 1. 确保C++资源已清理
        if (currentState != SocketStateCore.CLOSED) {
            close()
        }

        // 2. 清理JNI层资源
        try {
            nativeClearJni()
            println("[SocketManagerCore] JNI 资源已清理")
        } catch (e: Exception) {
            println("[SocketManagerCore] 清理JNI资源失败: ${e.message}")
        }

        // 3. 清理Kotlin层资源
        mNativeInstance = 0
        config = null
        callback = null
        currentState = SocketStateCore.DISCONNECTED
        println("[SocketManagerCore] destroy 完成")
    }
}
