package com.arashivision.inskmp.inssocket

import com.arashivision.inskmp.inssocket.callback.TunnelCallbackCore
import com.arashivision.inskmp.inssocket.data.TunnelData

actual class TunnelManagerCore {

    companion object {
        // 静态初始化 JNI 库
        init {
            try {
                System.loadLibrary("inssocket")
                println("[Kotlin] TunnelManagerCore JNI 库加载成功！")
            } catch (e: Exception) {
                println("[Kotlin] TunnelManagerCore JNI 库加载失败: ${e.message}")
            }
        }
    }

    private external fun nativeOpen(): Int
    private external fun nativeSetCallback(): Int
    private external fun nativeWrite(tunnelData: TunnelData): Int
    private external fun nativeRead(): TunnelData?
    private external fun nativeGetServerPort(): Int
    private external fun nativeClose(): Int
    private external fun nativeClearJni(): Int

    // JNI 原生对象指针，由JNI层管理
    private var mNativeInstance: Long = 0

    private var callback: TunnelCallbackCore? = null

    actual fun init():Int {
        println("[TunnelManagerCore] init(), but config == null!")

        try {
            // 调用 JNI OPEN函数！
            println("[TunnelManagerCore] 调用nativeOpen...")
            nativeOpen()
            println("[TunnelManagerCore] Socket 打开完成")
            return 0;
        } catch (e: Exception) {
            println("[TunnelManagerCore] Exception during JNI socket open:: ${e.message}")
            return -1;
        }
    }

    actual fun setOnReadableCallback(callback: TunnelCallbackCore?){
        this.callback = callback

        // 如果callback不为null，确保JNI层已经初始化
        if (this.callback != null ) {
            try {
                // 初始化 JNI 层的全局引用
                nativeSetCallback()
                println("[SocketManagerCore] JNI Callback 初始化成功")
            } catch (e: Exception) {
                println("[SocketManagerCore] JNI Callback 初始化失败: ${e.message}")
            }
        }

        println("[SocketManagerCore] Callback 设置成功: ${callback != null}")
    }

    actual fun write(tunnelData: TunnelData): Int {
        try {
            // 调用 JNI write 函数
            val result = nativeWrite(tunnelData)

            if (result != 0) {
                println("[TunnelManagerCore] Failed to write data to tunnel via JNI")
            }
            return result
        } catch (e: Exception) {
            println("[TunnelManagerCore] Exception during JNI tunnel write: ${e.message}")
            return -1
        }
    }

    actual fun read(): TunnelData? {
        try {
            return nativeRead()
        } catch (e: Exception) {
            println("[TunnelManagerCore] Exception during JNI tunnel read: ${e.message}")
            return null
        }
    }

    actual fun getServerPort(): Int {
        try {
            println("[TunnelManagerCore] getServerPort")
            return nativeGetServerPort();
        } catch (e: Exception) {
            println("[TunnelManagerCore] Exception during JNI getServerPort: ${e.message}")
            return -1
        }
    }

    // JNI 回调方法，供 C++ 层调用（参考 OneDriverJni.cpp 的 callInfoNotify）
    private fun OnReadableCallback() {
        println("[TunnelManagerCore] C++ 层数据可读通知")
        callback?.OnReadableCallback()
    }

    actual fun release(){
        try {
            // 调用 JNI close 函数
            println("[TunnelManagerCore] 调用 nativeRelase...")
            val result = nativeClose()
            println("[TunnelManagerCore] Socket close 完成，result=$result")
        } catch (e: Exception) {
            println("[TunnelManagerCore] Exception during JNI socket close: ${e.message}")
        }
    }

    actual fun destroy() {
        // 释放kt和jni资源
        println("[TunnelManagerCore] 调用 destroy...")

        // 1. 确保 C++ 资源已清理（release 会 join tunnel 线程）
        if (mNativeInstance != 0L) {
            release()
        }

        // 2. 清理JNI层资源（必须在 release 之后，确保无回调在执行）
        try {
            nativeClearJni()
            println("[TunnelManagerCore] JNI 资源已清理")
        } catch (e: Exception) {
            println("[TunnelManagerCore] 清理JNI资源失败: ${e.message}")
        }

        // 3. 清理Kotlin层资源
        mNativeInstance = 0
        callback = null
        println("[TunnelManagerCore] destroy 完成")
    }
}
