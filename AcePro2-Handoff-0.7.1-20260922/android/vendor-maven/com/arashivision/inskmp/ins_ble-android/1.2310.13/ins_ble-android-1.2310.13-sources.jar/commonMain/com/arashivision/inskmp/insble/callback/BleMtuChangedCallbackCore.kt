package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleMtuChangedCallbackCore  {

    abstract fun onSetMTUFailure(exception: BleExceptionCore)

    abstract fun onMtuChanged(mtu: Int)
}
