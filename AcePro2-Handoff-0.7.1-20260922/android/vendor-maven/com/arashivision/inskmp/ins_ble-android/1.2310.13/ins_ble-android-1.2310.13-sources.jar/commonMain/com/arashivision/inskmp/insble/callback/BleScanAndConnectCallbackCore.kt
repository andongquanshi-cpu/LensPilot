package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.data.BleDeviceCore

abstract class BleScanAndConnectCallbackCore : BleGattCallbackCore(), BleScanPresenterImpCore {

    abstract fun onScanFinished(scanResult: BleDeviceCore)

    open fun onLeScan(bleDevice: BleDeviceCore) {
        // 默认空实现
    }
}
