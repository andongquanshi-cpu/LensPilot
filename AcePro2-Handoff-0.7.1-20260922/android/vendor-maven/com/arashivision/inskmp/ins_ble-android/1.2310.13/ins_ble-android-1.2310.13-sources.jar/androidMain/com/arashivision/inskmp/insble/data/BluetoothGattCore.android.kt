package com.arashivision.inskmp.insble.data

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.os.Build
import androidx.annotation.RequiresPermission
import com.arashivision.inskmp.insble.toBluetoothGattServiceCore
import java.util.UUID


/**
 * 对应 BluetoothGatt.getServices() 函数
 * */
actual suspend fun getBluetoothGattService(nativeBluetoothGatt: Any): List<BluetoothGattServiceCore>? {
    return (nativeBluetoothGatt as? BluetoothGatt)?.getServices()
        ?.mapNotNull { it.toBluetoothGattServiceCore() }
}

actual suspend fun getBluetoothGattService(
    nativeBluetoothGatt: Any,
    serviceUUID: String,
): BluetoothGattServiceCore? {
    return (nativeBluetoothGatt as? BluetoothGatt)?.getService(UUID.fromString(serviceUUID))
        ?.toBluetoothGattServiceCore()

}

actual suspend fun getGattServiceByIdContain(
    nativeBluetoothGatt: Any,
    serviceIdContain: String
): BluetoothGattServiceCore? {
    val services = (nativeBluetoothGatt as? BluetoothGatt)?.getServices()
    services?.forEach {
        if (it.uuid.toString().contains(serviceIdContain)) {
            return it.toBluetoothGattServiceCore()
        }
    }
    return null
}

@RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
actual  fun setPreferredPhy(nativeBluetoothGatt: Any) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        (nativeBluetoothGatt as? BluetoothGatt)?.setPreferredPhy(
            BluetoothDevice.PHY_LE_2M_MASK,
            BluetoothDevice.PHY_LE_2M_MASK,
            BluetoothDevice.PHY_OPTION_NO_PREFERRED
        )
    }
}