package com.arashivision.inskmp.insble.data

data class BleDeviceCore constructor(
    val nativeBleDevice: Any,
    private var _name: String? = null,
    private var _mac: String? = null,
    private var _key: String? = null,
    private var _rssi: Int? = null,//大于等于0为无效值，小于0才是正常值
    private var _timestampNanos: Long? = null,
    private var _scanRecord: ByteArray? = null,
    private var _serviceUuids: List<String>? = null,
) {

    /**
     *
     * todo ohos中，需要增加逻辑：在BleDeviceCore发送给外部时，需要解析蓝牙广播协议。
     * */
    private var bleScanProtoCore: BleScanProtoCore? = null

    val name: String?
        get() = _name ?: getName(nativeBleDevice).also { _name = it }

    val mac: String?
        get() = _mac ?: getMac(nativeBleDevice).also { _mac = it }

    val key: String?
        get() = _key ?: getKey(nativeBleDevice).also { _key = it }

    /**
     * ohos中无此接口，是安卓增加的业务。
     * todo ohos中，需要增加逻辑：在BleDeviceCore发送给外部时，需要解析蓝牙广播协议。
     * */
    val bleScanProto: BleScanProtoCore?
        get() = bleScanProtoCore ?: getBleScanProto(nativeBleDevice).also { bleScanProtoCore = it }

    val type: Int
        get() = getBluetoothDeviceType(nativeBleDevice)

    val address: String
        get() = getBluetoothDeviceAddress(nativeBleDevice)

    val isClassicBluetooth: Boolean
        get() = nativeBleDevice is String

    fun getScanRecord(): ByteArray? {
        return _scanRecord ?: getScanRecord(nativeBleDevice).also { _scanRecord = it }
    }

    fun getNameInner(): String? {
        return getNameInner(nativeBleDevice)
    }

    fun isCameraServiceUuid(): Boolean {
        return isCameraServiceUuid(nativeBleDevice)
    }

    val rssi: Int?
        get() = _rssi ?: getRssi(nativeBleDevice).also { _rssi = it }

    val timestampNanos: Long?
        get() = _timestampNanos ?: getTimestampNanos(nativeBleDevice).also { _timestampNanos = it }

    val serviceUuids: List<String>?
        get() = _serviceUuids ?: getServiceUuids(nativeBleDevice).also { _serviceUuids = it }

}

expect fun isCameraServiceUuid(nativeDevice: Any): Boolean

expect fun getNameInner(nativeDevice: Any): String?

expect fun getName(nativeDevice: Any): String?
expect fun getMac(nativeDevice: Any): String?
expect fun getKey(nativeDevice: Any): String?
expect fun getBleScanProto(nativeDevice: Any): BleScanProtoCore?
expect fun getScanRecord(nativeDevice: Any): ByteArray?
expect fun getRssi(nativeDevice: Any): Int?
expect fun getTimestampNanos(nativeDevice: Any): Long?
expect fun getBluetoothDeviceType(nativeDevice: Any): Int
expect fun getBluetoothDeviceAddress(nativeDevice: Any): String
expect fun getBluetoothDevice(nativeDevice: Any): Any?

/**
 * 安卓主工程akiko用来判断是否包含be80 或者 3366, 判断是否我们的蓝牙相机。
 * 但是安卓在构造BleDevice时，给ServiceUuids赋值的方法，并不是每次都有值，有好几个构造的地方传入的null，这样看的话，用这个判断并不稳定。
 * */
expect fun getServiceUuids(nativeDevice: Any): List<String>?

/**
 * 用于通过原生系统的蓝牙设备构造FastBle对应的BleDevice，再转为BleDeviceCore
 * */
expect fun buildBleDeviceCoreByNative(nativeDevice: Any, deviceName: String?, rssi: Int): BleDeviceCore?