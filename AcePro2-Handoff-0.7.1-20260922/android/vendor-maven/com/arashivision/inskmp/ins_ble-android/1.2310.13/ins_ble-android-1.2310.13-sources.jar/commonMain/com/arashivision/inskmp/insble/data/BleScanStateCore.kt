package com.arashivision.inskmp.insble.data

enum class BleScanStateCore(val code: Int) {
    STATE_IDLE(-1),
    STATE_SCANNING(0x01)
}
