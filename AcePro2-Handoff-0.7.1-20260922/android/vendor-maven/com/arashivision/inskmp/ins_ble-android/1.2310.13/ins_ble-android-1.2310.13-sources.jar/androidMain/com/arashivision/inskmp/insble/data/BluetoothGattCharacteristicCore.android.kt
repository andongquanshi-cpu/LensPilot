package com.arashivision.inskmp.insble.data

import android.bluetooth.BluetoothGattCharacteristic

actual fun canReadAndWrite(nativeCharacter: Any): Boolean {
    return (nativeCharacter as? BluetoothGattCharacteristic)?.properties?.let { charaProp ->
        (charaProp and BluetoothGattCharacteristic.PROPERTY_READ) > 0 &&
                (charaProp and BluetoothGattCharacteristic.PROPERTY_WRITE) > 0
    } == true
}

actual fun canNotify(nativeCharacter: Any): Boolean {
    return (nativeCharacter as? BluetoothGattCharacteristic)?.properties?.let { charaProp ->
        (charaProp and BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0
    } == true
}

actual fun getCharacterServiceUuid(nativeCharacter: Any): String {
    return (nativeCharacter as? BluetoothGattCharacteristic)?.service?.uuid.toString()
}

actual fun getCharacterUuid(nativeCharacter: Any): String {
    return (nativeCharacter as? BluetoothGattCharacteristic)?.uuid.toString()
}

actual fun isIndicate(nativeCharacter: Any): Boolean {
    return (nativeCharacter as? BluetoothGattCharacteristic)?.properties?.let { charaProp ->
        (charaProp and BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0
    } == true
}

actual fun setWriteType(nativeCharacter: Any, type: Int) {
    (nativeCharacter as? BluetoothGattCharacteristic)?.writeType = type
}