package com.arashivision.inskmp.insble

import com.arashivision.inskmp.insble.callback.BleGattCallbackCore
import com.arashivision.inskmp.insble.callback.BleIndicateCallbackCore
import com.arashivision.inskmp.insble.callback.BleMtuChangedCallbackCore
import com.arashivision.inskmp.insble.callback.BleNotifyCallbackCore
import com.arashivision.inskmp.insble.callback.BleScanCallbackCore
import com.arashivision.inskmp.insble.callback.BleStopWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWriteCallbackCore
import com.arashivision.inskmp.insble.callback.ClassicCallback
import com.arashivision.inskmp.insble.callback.IBleScanProtoDependenceCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BleScanStateCore
import com.arashivision.inskmp.insble.data.BluetoothGattCore
import com.arashivision.inskmp.insble.data.BluetoothGattServiceCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore

expect object BleManagerCore {


    val DEVICE_EVO: Int

    val DEVICE_ONE: Int

    val DEVICE_ONEX: Int

    val DEVICE_GO: Int

    val DEVICE_AKIKO: Int

    val DEVICE_GO2: Int

    /**
     * 在鸿蒙中没有application，而且初始化鸿蒙的ble也不需要application
     * */
    fun init(app: Any?): Int

    /**
     * Configure scan and connection properties 配置扫描和连接的规则，例如扫描超时时间、连接重试次数
     */
    fun initScanRule(config: BleScanRuleConfigCore)

    /**
     * 协议注入入口
     */
    fun setBleScanProtoDependence(bleScanProtoDependence: IBleScanProtoDependenceCore)

    /**
     * Set operate timeout 设置操作超时时间
     */
    fun setOperateTimeout(count: Int): BleManagerCore

    /**
     * Set connect retry count and interval 设置重试次数
     */
    fun setReConnectCount(count: Int): BleManagerCore

    /**
     * Set split WriteNum
     */
    fun setSplitWriteNum(num: Int): BleManagerCore

    /**
     * Set connect Over Time
     */
    fun setConnectOverTime(time: Long): BleManagerCore

    /**
     * scan device around
     */
    fun scan(callback: BleScanCallbackCore)

    /**
     * connect a known device, 原工程中的返回值并未使用，可以删除。
     */
    fun connect(bleDevice: BleDeviceCore?, bleGattCallback: BleGattCallbackCore): BluetoothGattCore?

    /**
     * Cancel scan
     */
    fun cancelScan()

    /**
     * notify
     */
    fun notify(
        bleDevice: BleDeviceCore?,
        uuid_service: String?,
        uuid_notify: String?,
        callback: BleNotifyCallbackCore
    )

    /**
     * indicate
     */
    fun indicate(
        bleDevice: BleDeviceCore?,
        uuid_service: String?,
        uuid_indicate: String?,
        callback: BleIndicateCallbackCore
    )

    fun write(
        bleDevice: BleDeviceCore?,
        uuid_service: String?,
        uuid_write: String?,
        writeType: Int,
        data: ByteArray,
        split: Boolean,
        sync: Boolean,
        callback: BleWriteCallbackCore
    )

    /**
     * set Mtu
     */
    fun setMtu(
        bleDevice: BleDeviceCore?,
        mtu: Int,
        callback: BleMtuChangedCallbackCore
    )

    /**
     * requestConnectionPriority
     */
    fun requestConnectionPriority(bleDevice: BleDeviceCore?, connectionPriority: Int): Boolean

    /**
     * 手机是否支持ble功能
     */
    fun isSupportBle(): Boolean

    /**
     * 原工程中，外部调用这个接口，只用于判空，所以可以返回Any ？类型。
     * */
    fun getBleBluetooth(bleDevice: BleDeviceCore?): Any?

    /**
     * 原工程中，外部调用这个接口，只用于获取gatt后，再获取gatt服务，其实可以直接返回gatt服务，删除这个接口；先跟原工程保持一致。
     * */
    fun getBluetoothGatt(bleDevice: BleDeviceCore?): BluetoothGattCore?

    /**
     * 安卓是直接返回，鸿蒙是异步回调。调用逻辑需要调整
     * */
    suspend fun getBluetoothGattServices(bleDevice: BleDeviceCore?): List<BluetoothGattServiceCore>?

    fun getScanSate(): BleScanStateCore

    /**
     * 原工程中，回调传入的是null，所以也定义为可null
     * */
    fun startWakeupAdvertise(
        mode: Int,
        deviceName: String?,
        txPower: Byte,
        bleWakeupCallbackCore: BleWakeupCallbackCore?
    )

    fun stopWakeupAdvertise(bleStopWakeupCallback: BleStopWakeupCallbackCore?)

    fun isConnected(bleDevice: BleDeviceCore?): Boolean

    fun disconnect(bleDevice: BleDeviceCore?)

    fun disconnectAllDevice()

    fun destroy()
    fun getSplitWriteNum(): Int

    fun removeWriteCallback(bleDevice: BleDeviceCore?, characterUuid: String?)

    ///////////////////////////////////////////////////////////////////////////
    // classic
    ///////////////////////////////////////////////////////////////////////////
    fun connectClassic(cameraMac: String, classicCallback: ClassicCallback)

    fun classicWrite(data: ByteArray,
                     split: Boolean,
                     callback: BleWriteCallbackCore)

    fun disconnectClassicBluetooth(address: String): Boolean

    /** 收到 appear（相机在场）时延长正在进行的经典蓝牙 connect 超时，避免正卡在握手的 connect 被超时打断。 */
    fun extendClassicConnectTimeout()

}