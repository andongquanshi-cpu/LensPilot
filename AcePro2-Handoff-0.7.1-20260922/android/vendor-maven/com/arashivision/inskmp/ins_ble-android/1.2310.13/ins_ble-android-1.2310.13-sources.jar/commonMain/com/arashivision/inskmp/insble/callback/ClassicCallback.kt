package com.arashivision.inskmp.insble.callback

interface ClassicCallback {
    fun connectSuccess()

    fun connectFailed(errorCode: Int)

    fun onReceive(byteArray: ByteArray)

    fun writeHeart()
}