package com.arashivision.inskmp.insble.callback

interface BleStopWakeupCallbackCore {

    /**
     * 原工程中函数定义为 ：void stopWakeupSuccess(AdvertiseSettings settingsInEffect);
     * 但是原工程中 stopWakeupSuccess（）并没有被override，所以理论上这个接口可以删除。
     * 但是为了保持一致性，将接口保留，将平台相关的参数 settingsInEffect 删除。
     *
     * */
    fun stopWakeupSuccess()

    fun stopWakeupError(errorCode: Int)
}
