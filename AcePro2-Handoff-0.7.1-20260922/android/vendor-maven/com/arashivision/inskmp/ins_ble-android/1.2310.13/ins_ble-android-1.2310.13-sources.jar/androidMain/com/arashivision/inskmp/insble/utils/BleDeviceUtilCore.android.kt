package com.arashivision.inskmp.insble.utils

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.toBleDevice
import com.arashivision.inskmp.insble.toBleDeviceCore
import com.clj.fastble.data.BleDevice
import com.clj.fastble.utils.BleDeviceUtil

actual object BleDeviceUtilCore {
    actual fun getAllSystemConnectedDevices(): List<BleDeviceCore> {
        val list = BleDeviceUtil.getAllSystemConnectedDevices().map { value ->
            BleDevice(value, null, 0, null, 0, null, null).toBleDeviceCore()
        }
        return list
    }

    actual fun getAllSystemBondedDevices(): List<BleDeviceCore> {
        val list = BleDeviceUtil.getAllSystemBondedDevices().map { value ->
            BleDevice(value, null, 0, null, 0, null, null).toBleDeviceCore()
        }
        return list
    }

    actual fun createBond(bleDeviceCore: BleDeviceCore): Boolean {
        return BleDeviceUtil.createBond(bleDeviceCore.toBleDevice())
    }
}