package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleNotifyCallbackCore  {

    abstract fun onNotifySuccess()

    abstract fun onNotifyFailure(exception: BleExceptionCore)

    abstract fun onCharacteristicChanged(data: ByteArray)
}
