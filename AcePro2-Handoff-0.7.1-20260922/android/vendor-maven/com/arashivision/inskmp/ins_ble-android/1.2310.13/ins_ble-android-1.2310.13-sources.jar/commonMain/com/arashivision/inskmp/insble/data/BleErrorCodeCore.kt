package com.arashivision.inskmp.insble.data

object BleErrorCodeCore {

    // Scan
    const val SCAN_SUCCESS = 0
    const val SCAN_FAILED_BLUETOOTH_DISABLED = -1
    const val SCAN_FAILED_BLE_SCANNER_INVALID = -2
    const val SCAN_FAILED_ALREADY_STARTED_IN_APP = -3
    const val SCAN_FAILED_LACK_PERMISSION = -4
    const val SCAN_FAILED_OHOS = -100
    const val SCAN_FAILED_ALREADY_STARTED_IN_SYSTEM = 1
    const val SCAN_FAILED_APPLICATION_REGISTRATION_FAILED = 2
    const val SCAN_FAILED_INTERNAL_ERROR = 3
    const val SCAN_FAILED_FEATURE_UNSUPPORTED = 4
    const val SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES = 5
    const val SCAN_FAILED_SCANNING_TOO_FREQUENTLY = 6
}
