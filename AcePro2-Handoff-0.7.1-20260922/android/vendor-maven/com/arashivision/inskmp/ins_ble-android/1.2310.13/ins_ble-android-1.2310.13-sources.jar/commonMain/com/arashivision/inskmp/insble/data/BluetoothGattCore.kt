package com.arashivision.inskmp.insble.data

data class BluetoothGattCore constructor(val nativeBluetoothGatt: Any) {

    /**
     *
     * */
    @Deprecated(
        "arkts回调给kotlin的Array<JSValue>有问题，size从3变为1，内容也不对。" +
                "业务层只是为了拿特定serviceId的GattService，用 getGattServiceByIdContain 替代",
        level = DeprecationLevel.ERROR
    )
    suspend fun getBluetoothGattService(): List<BluetoothGattServiceCore>? {
        return getBluetoothGattService(nativeBluetoothGatt)
    }

    suspend fun getService(serviceUUID: String): BluetoothGattServiceCore? {
        return getBluetoothGattService(nativeBluetoothGatt, serviceUUID)
    }

    suspend fun getGattServiceByIdContain(serviceIdContain: String): BluetoothGattServiceCore? {
        return getGattServiceByIdContain(nativeBluetoothGatt, serviceIdContain)
    }
}

/**
 * 对应 BluetoothGatt.getServices() 函数
 * */
expect suspend fun getBluetoothGattService(nativeBluetoothGatt: Any): List<BluetoothGattServiceCore>?
expect suspend fun getBluetoothGattService(
    nativeBluetoothGatt: Any,
    serviceUUID: String,
): BluetoothGattServiceCore?

expect suspend fun getGattServiceByIdContain(
    nativeBluetoothGatt: Any,
    serviceIdContain: String,
): BluetoothGattServiceCore?

expect fun setPreferredPhy(nativeBluetoothGatt: Any)