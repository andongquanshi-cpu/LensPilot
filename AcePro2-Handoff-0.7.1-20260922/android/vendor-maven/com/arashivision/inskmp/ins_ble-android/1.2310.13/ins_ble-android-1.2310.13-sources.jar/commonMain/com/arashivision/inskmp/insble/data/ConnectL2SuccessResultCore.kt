package com.arashivision.inskmp.insble.data

data class ConnectL2SuccessResultCore(var isContinue: Boolean = true, var discoverServicesDelayMillis: Long = 500)