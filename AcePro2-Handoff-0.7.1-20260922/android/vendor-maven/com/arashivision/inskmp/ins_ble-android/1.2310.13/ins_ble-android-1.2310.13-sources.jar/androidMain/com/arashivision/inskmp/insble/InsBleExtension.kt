package com.arashivision.inskmp.insble

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.le.ScanResult
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BleScanProtoCore
import com.arashivision.inskmp.insble.data.BleScanStateCore
import com.arashivision.inskmp.insble.data.BluetoothGattCharacteristicCore
import com.arashivision.inskmp.insble.data.BluetoothGattCore
import com.arashivision.inskmp.insble.data.BluetoothGattServiceCore
import com.arashivision.inskmp.insble.data.ScanResultCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.clj.fastble.data.BleDevice
import com.clj.fastble.data.BleScanProto
import com.clj.fastble.data.BleScanState
import com.clj.fastble.exception.BleException
import com.clj.fastble.exception.ConnectException
import com.clj.fastble.scan.BleScanRuleConfig
import java.util.UUID

/**
 * 将 BleScanRuleConfigCore 转换为 BleScanRuleConfig
 */
fun BleScanRuleConfigCore.toBleScanRuleConfig(): BleScanRuleConfig {
    val builder = BleScanRuleConfig.Builder()

    // 转换服务UUID
    val serviceUuids = this.getServiceUuids()
    if (serviceUuids != null) {
        val uuidArray = serviceUuids.mapNotNull { uuidString ->
            try {
                UUID.fromString(uuidString)
            } catch (e: IllegalArgumentException) {
                null
            }
        }.toTypedArray()
        if (uuidArray.isNotEmpty()) {
            builder.setServiceUuids(uuidArray)
        }
    }

    // 转换设备名称
    val deviceNames = this.getDeviceNames()
    if (deviceNames != null && deviceNames.isNotEmpty()) {
        builder.setDeviceName(this.isFuzzy(), *deviceNames)
    }

    // 转换设备MAC
    val deviceMac = this.getDeviceMac()
    if (!deviceMac.isNullOrEmpty()) {
        builder.setDeviceMac(deviceMac)
    }

    // 设置自动连接
    builder.setAutoConnect(this.isAutoConnect())

    // 设置扫描超时
    builder.setScanTimeOut(this.getScanTimeOut())

    return builder.build()
}

/**
 * 将 BleScanRuleConfig 转换为 BleScanRuleConfigCore
 */
fun BleScanRuleConfig.toBleScanRuleConfigCore(): BleScanRuleConfigCore {
    val builder = BleScanRuleConfigCore.Builder()

    // 转换服务UUID
    val serviceUuids = this.getServiceUuids()
    if (serviceUuids != null) {
        val uuidStringArray = serviceUuids.map { it.toString() }.toTypedArray()
        builder.setServiceUuids(uuidStringArray)
    }

    // 转换设备名称
    val deviceNames = this.getDeviceNames()
    if (deviceNames != null && deviceNames.isNotEmpty()) {
        builder.setDeviceName(this.isFuzzy(), *deviceNames)
    }

    // 转换设备MAC
    val deviceMac = this.getDeviceMac()
    if (deviceMac != null) {
        builder.setDeviceMac(deviceMac)
    }

    // 设置自动连接
    builder.setAutoConnect(this.isAutoConnect())

    // 设置扫描超时
    builder.setScanTimeOut(this.getScanTimeOut())

    return builder.build()
}

fun BleScanProto.toBleScanProtoCore(): BleScanProtoCore {
    return BleScanProtoCore(this)
}

fun BleDevice.toBleDeviceCore(): BleDeviceCore {
    return BleDeviceCore(this)
}

fun BleDeviceCore.toBleDevice(): BleDevice? {
    return (this.nativeBleDevice as? BleDevice)
}


fun BleScanState.toBleScanStateCore(): BleScanStateCore {
    return when (this) {
        BleScanState.STATE_IDLE -> BleScanStateCore.STATE_IDLE
        BleScanState.STATE_SCANNING -> BleScanStateCore.STATE_SCANNING
        else -> BleScanStateCore.STATE_IDLE
    }
}

fun ScanResult.toScanResultCore(): ScanResultCore {
    return ScanResultCore(this)
}

fun BleException.toBleExceptionCore(): BleExceptionCore {
    if (this is ConnectException) {
        return BleExceptionCore(this.code, this.description, this.gattStatus)
    }
    return BleExceptionCore(this.code, this.description)
}

fun BluetoothGatt.toBluetoothGattCore(): BluetoothGattCore {
    return BluetoothGattCore(this)
}

fun BluetoothGattService.toBluetoothGattServiceCore(): BluetoothGattServiceCore {
    return BluetoothGattServiceCore(this)
}

fun BluetoothGattCharacteristic.toBluetoothGattCharacteristicCore(): BluetoothGattCharacteristicCore {
    return BluetoothGattCharacteristicCore(this)
}