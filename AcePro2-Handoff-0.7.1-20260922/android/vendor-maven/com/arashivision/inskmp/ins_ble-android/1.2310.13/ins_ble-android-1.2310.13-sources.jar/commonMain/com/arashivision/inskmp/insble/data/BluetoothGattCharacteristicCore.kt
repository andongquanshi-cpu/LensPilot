package com.arashivision.inskmp.insble.data

data class BluetoothGattCharacteristicCore constructor(val nativeCharacter: Any) {

    fun canReadAndWrite(): Boolean {
        return canReadAndWrite(nativeCharacter)
    }

    fun canNotify(): Boolean {
        return canNotify(nativeCharacter)
    }

    fun isIndicate(): Boolean {
        return isIndicate(nativeCharacter)
    }

    fun getCharacterServiceUuid(): String {
        return getCharacterServiceUuid(nativeCharacter)
    }

    fun getCharacterUuid(): String {
        return getCharacterUuid(nativeCharacter)
    }

    fun setWriteType(type: Int) {
        setWriteType(nativeCharacter, type)
    }

}


expect fun canReadAndWrite(nativeCharacter: Any): Boolean
expect fun canNotify(nativeCharacter: Any): Boolean
expect fun getCharacterServiceUuid(nativeCharacter: Any): String
expect fun getCharacterUuid(nativeCharacter: Any): String
expect fun isIndicate(nativeCharacter: Any): Boolean
expect fun setWriteType(nativeCharacter: Any, type: Int)