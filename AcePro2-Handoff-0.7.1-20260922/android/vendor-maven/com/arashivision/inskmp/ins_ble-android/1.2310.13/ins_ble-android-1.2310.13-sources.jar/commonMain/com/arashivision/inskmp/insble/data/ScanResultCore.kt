package com.arashivision.inskmp.insble.data

data class ScanResultCore constructor(val nativeScanResult:Any) {
    fun getNativeBleDevice():Any? {
        return getNativeBleDevice(nativeScanResult)
    }
}

expect fun getNativeBleDevice(nativeScanResult: Any): Any?