package com.arashivision.inskmp.insble.exception

/**
 * 不需要像原fastble中一样定义那么多子类型的exception，因为外部只有basecamera中使用connectexception ，可以直接通过code判断
 * */
class BleExceptionCore {
    companion object {
        const val ERROR_CODE_TIMEOUT = 100
        const val ERROR_CODE_GATT = 101
        const val ERROR_CODE_OTHER = 102
        const val ERROR_CODE_OPEN = 103
        const val ERROR_CODE_SYNC_PACK = 104
        const val ERROR_CODE_NOTIFY_FAILURE = 105
        const val ERROR_CODE_SET_MTU = 106
        const val ERROR_CODE_WRITE_CHARACTERISTIC_FAIL = 107
        const val ERROR_CODE_SHAKE_HAND = 108
        const val ERROR_CODE_WAKE_UP_AUTHORIZATION_FAIL = 109
        const val ERROR_CODE_ERROR_CODE_OPEN_BUSY = 110
        const val ERROR_CODE_SYSTEM_STATUS_133 = 133
        const val ERROR_CODE_CHARACTERISTICS = 134
        const val ERROR_CODE_THROWABLE = 135
        const val ERROR_CODE_CRASH_PRIVILEGED = 136
        const val ERROR_CODE_CONNECT_CLASSIC_TIMEOUT = 137
        const val ERROR_CODE_CONNECT_CLASSIC_CANCELLED = 138
        const val ERROR_CODE_CONNECT_CLASSIC_BOND_FAILED = 139
    }

    private var code: Int = 0
    private var description: String? = null
    private var _gattStatus: Int = 0

    constructor(code: Int, description: String?, gattStatus: Int = 0) {
        this.code = code
        this.description = description
        _gattStatus = gattStatus
    }

    fun getCode(): Int = code

    fun setCode(code: Int): BleExceptionCore {
        this.code = code
        return this
    }

    fun getDescription(): String? = description

    fun setDescription(description: String?): BleExceptionCore {
        this.description = description
        return this
    }

    fun getGattStatus(): Int {
        return _gattStatus
    }

    override fun toString(): String {
        return "BleExceptionCore { " +
                "code=$code" +
                ", description='$description'" +
                ", gattStatus='$_gattStatus'" +
                '}'
    }
}
