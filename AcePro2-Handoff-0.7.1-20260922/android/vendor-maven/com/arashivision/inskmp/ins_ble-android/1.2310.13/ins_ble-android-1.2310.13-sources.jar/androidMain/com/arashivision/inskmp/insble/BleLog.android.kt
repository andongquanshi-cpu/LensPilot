package com.arashivision.inskmp.insble

import com.clj.fastble.utils.BleLog

actual object BleLogCore {
    actual fun v(msg: String) {
        BleLog.v(msg)
    }

    actual fun d(msg: String) {
        BleLog.d(msg)
    }

    actual fun i(msg: String) {
        BleLog.i(msg)
    }

    actual fun w(msg: String) {
        BleLog.w(msg)
    }

    actual fun e(msg: String) {
        BleLog.e(msg)
    }

    actual fun ft(msg: Throwable) {
        BleLog.ft(msg)
    }

    actual fun enableLog(enable: Boolean) {
        BleLog.enableLog(enable)
    }

    actual fun setLoggerCallback(callback: ILoggerCallbackCore) {
        BleLog.setLoggerCallback(object : BleLog.ILoggerCallback {
            override fun onLogV(tag: String?, msg: String?) {
                callback.onLogV(tag, msg)
            }

            override fun onLogD(tag: String?, msg: String?) {
                callback.onLogD(tag, msg)
            }

            override fun onLogI(tag: String?, msg: String?) {
                callback.onLogI(tag, msg)
            }

            override fun onLogW(tag: String?, msg: String?) {
                callback.onLogW(tag, msg)
            }

            override fun onLogE(tag: String?, msg: String?) {
                callback.onLogE(tag, msg)
            }

            override fun onLogFt(tag: String?, t: Throwable?) {
                callback.onLogFt(tag, t)
            }

        })
    }

}