package com.arashivision.inskmp.insble.data

import android.bluetooth.BluetoothGattService
import com.arashivision.inskmp.insble.toBluetoothGattCharacteristicCore
import java.util.UUID

/**
 * 对应 BluetoothGattService.getCharacteristics() 函数
 * */
actual fun getCharacteristics(nativeBluetoothGattService: Any): List<BluetoothGattCharacteristicCore>? {
    return (nativeBluetoothGattService as? BluetoothGattService)?.characteristics?.mapNotNull {
        it.toBluetoothGattCharacteristicCore()
    }
}

actual fun getCharacteristicArray(nativeBluetoothGattService: Any): Any? {
    return (nativeBluetoothGattService as? BluetoothGattService)?.characteristics?.mapNotNull {
        it.toBluetoothGattCharacteristicCore()
    }
}

/**
 * 对应 BluetoothGattService.getUuid(): UUID
 * */
actual fun getUuid(nativeBluetoothGattService: Any): String? {
    return (nativeBluetoothGattService as? BluetoothGattService)?.uuid?.toString()
}

/**
 * BluetoothGattService..getCharacteristic(UUID uuid): BluetoothGattCharacteristic
 * */
actual fun getCharacteristics(
    nativeBluetoothGattService: Any,
    characteristicUUID: String,
): BluetoothGattCharacteristicCore? {
    return (nativeBluetoothGattService as? BluetoothGattService)?.getCharacteristic(
        UUID.fromString(characteristicUUID)
    )?.toBluetoothGattCharacteristicCore()
}

actual inline fun forEachJsArrayCharacteristic(
    jsArrayCharacteristic: Any,
    crossinline eachCallback: (characteristicCore: BluetoothGattCharacteristicCore) -> Unit
) {
    if (jsArrayCharacteristic !is List<*>) {
        println("InsLibBle kt forEachJsArrayCharacteristic error, jsArrayCharacteristic not List<BluetoothGattCharacteristicCore>?")
        return
    }
    jsArrayCharacteristic.forEach {
        eachCallback(it as BluetoothGattCharacteristicCore)
    }
}