package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BluetoothGattCore
import com.arashivision.inskmp.insble.data.ConnectL2SuccessResultCore
import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleGattCallbackCore {

    abstract fun onStartConnect()

    abstract fun onConnectFail(bleDevice: BleDeviceCore, exception: BleExceptionCore)

    /**
     * @param status 原生测状态码，例如 ： Status of the connect or disconnect operation. {@link BluetoothGatt#GATT_SUCCESS} if the operation succeeds.
     *                  0: GATT_SUCCESS
     *                  8: GATT_INSUFFICIENT_AUTHORIZATION Insufficient authorization for a given operation
     */
    abstract fun onConnectSuccess(bleDevice: BleDeviceCore, gatt: Any, status: Int)

    abstract fun onDisConnected(
        isActiveDisConnected: Boolean,
        device: BleDeviceCore,
        gatt: Any,
        status: Int,
    )

    open fun onConnectL2Success(bleDevice: BleDeviceCore, gatt: BluetoothGattCore, status: Int): ConnectL2SuccessResultCore{
        return ConnectL2SuccessResultCore()
    }
}
