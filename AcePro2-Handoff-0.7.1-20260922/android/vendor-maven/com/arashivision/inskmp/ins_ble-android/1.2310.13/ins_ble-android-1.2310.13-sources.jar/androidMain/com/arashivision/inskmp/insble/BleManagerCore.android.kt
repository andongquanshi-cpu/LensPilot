package com.arashivision.inskmp.insble

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothSocket
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.arashivision.inskmp.insble.callback.BleGattCallbackCore
import com.arashivision.inskmp.insble.callback.BleIndicateCallbackCore
import com.arashivision.inskmp.insble.callback.BleMtuChangedCallbackCore
import com.arashivision.inskmp.insble.callback.BleNotifyCallbackCore
import com.arashivision.inskmp.insble.callback.BleScanCallbackCore
import com.arashivision.inskmp.insble.callback.BleStopWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWakeupCallbackCore
import com.arashivision.inskmp.insble.callback.BleWriteCallbackCore
import com.arashivision.inskmp.insble.callback.ClassicCallback
import com.arashivision.inskmp.insble.callback.IBleScanProtoDependenceCore
import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.BleScanStateCore
import com.arashivision.inskmp.insble.data.BluetoothGattCore
import com.arashivision.inskmp.insble.data.BluetoothGattServiceCore
import com.arashivision.inskmp.insble.scan.BleScanRuleConfigCore
import com.clj.fastble.BleManager
import com.clj.fastble.callback.BleGattCallback
import com.clj.fastble.callback.BleIndicateCallback
import com.clj.fastble.callback.BleMtuChangedCallback
import com.clj.fastble.callback.BleNotifyCallback
import com.clj.fastble.callback.BleScanCallback
import com.clj.fastble.callback.BleStopWakeupCallback
import com.clj.fastble.callback.BleWakeupCallback
import com.clj.fastble.callback.BleWriteCallback
import com.clj.fastble.callback.IBleScanProtoDependence
import com.clj.fastble.data.BleDevice
import com.clj.fastble.exception.BleException
import com.arashivision.inskmp.insble.exception.BleExceptionCore
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock

actual object BleManagerCore {

    actual val DEVICE_EVO: Int = 0

    actual val DEVICE_ONE: Int = 1

    actual val DEVICE_ONEX: Int = 2

    actual val DEVICE_GO: Int = 3

    actual val DEVICE_AKIKO: Int = 4

    actual val DEVICE_GO2: Int = 5

    actual fun init(app: Any?): Int {
        return BleManager.getInstance().init(app as Application?)
    }

    /**
     * Configure scan and connection properties
     */
    actual fun initScanRule(config: BleScanRuleConfigCore) {
        BleManager.getInstance().initScanRule(config.toBleScanRuleConfig())
    }

    actual fun setBleScanProtoDependence(bleScanProtoDependence: IBleScanProtoDependenceCore) {
        BleManager.getInstance().setBleScanProtoDependence(object : IBleScanProtoDependence {
            override fun getDeviceType(value: Int): String? {
                return bleScanProtoDependence.getDeviceType(value)
            }

            override fun transformDeviceName(deviceName: String?): String? {
                return bleScanProtoDependence.transformDeviceName(deviceName)
            }

            override fun getScanMode(): Int {
                return bleScanProtoDependence.getScanMode()
            }
        })
    }

    /**
     * Set operate timeout
     */
    actual fun setOperateTimeout(count: Int): BleManagerCore {
        BleManager.getInstance().setOperateTimeout(count)
        return this
    }

    /**
     * Set connect retry count and interval
     */
    actual fun setReConnectCount(count: Int): BleManagerCore {
        BleManager.getInstance().setReConnectCount(count)
        return this
    }

    /**
     * Set split WriteNum
     */
    actual fun setSplitWriteNum(num: Int): BleManagerCore {
        BleManager.getInstance().setSplitWriteNum(num)
        return this
    }

    /**
     * Set connect Over Time
     */
    actual fun setConnectOverTime(time: Long): BleManagerCore {
        BleManager.getInstance().setConnectOverTime(time)
        return this
    }

    /**
     * scan device around
     */
    actual fun scan(callback: BleScanCallbackCore) {
        // 创建适配器将Core回调转换为原始回调
        val adapter = object : BleScanCallback() {
            override fun onScanStarted(errorCode: Int) {
                callback.onScanStarted(errorCode)
            }

            override fun onRawScanResult(
                callbackType: Int,
                result: ScanResult?,
            ) {
                callback.onRawScanResult(callbackType, result?.toScanResultCore())
            }

            override fun onScanning(bleDevice: BleDevice?) {
                callback.onScanning(bleDevice?.toBleDeviceCore())
            }

            override fun onScanUpdate(bleDeviceList: List<BleDevice?>?) {
                callback.onScanUpdate(bleDeviceList?.mapNotNull { it?.toBleDeviceCore() }
                    ?: emptyList())
            }

            override fun onScanReject() {
                callback.onScanReject()
            }

            override fun onScanFinished(scanResultList: List<BleDevice>?) {
                val coreDeviceList =
                    scanResultList?.mapNotNull { it.toBleDeviceCore() } ?: emptyList()
                callback.onScanFinished(coreDeviceList)
            }
        }

        BleManager.getInstance().scan(adapter)
    }

    /**
     * connect a known device
     */
    actual fun connect(bleDevice: BleDeviceCore?, bleGattCallback: BleGattCallbackCore): BluetoothGattCore? {
        // 创建适配器将Core回调转换为原始回调
        val adapter = object : BleGattCallback() {
            override fun onStartConnect() {
                bleGattCallback.onStartConnect()
            }

            override fun onConnectFail(
                bleDevice: BleDevice,
                exception: BleException,
            ) {
                bleGattCallback.onConnectFail(
                    bleDevice.toBleDeviceCore(),
                    exception.toBleExceptionCore()
                )
            }

            override fun onConnectSuccess(device: BleDevice, gatt: BluetoothGatt, status: Int) {
                bleGattCallback.onConnectSuccess(
                    device.toBleDeviceCore(),
                    gatt.toBluetoothGattCore(),
                    status
                )
            }

            override fun onDisConnected(
                isActiveDisConnected: Boolean,
                device: BleDevice,
                gatt: BluetoothGatt,
                status: Int,
            ) {
                bleGattCallback.onDisConnected(
                    isActiveDisConnected,
                    device.toBleDeviceCore(),
                    gatt.toBluetoothGattCore(),
                    status
                )
            }

            override fun onConnectL2Success(bleDevice: BleDevice, gatt: BluetoothGatt, status: Int): ConnectL2SuccessResult? {
                return bleGattCallback.onConnectL2Success(
                    bleDevice.toBleDeviceCore(),
                    gatt.toBluetoothGattCore(),
                    status
                ).let {
                    ConnectL2SuccessResult().apply {
                        isContinue = it.isContinue
                        discoverServicesDelayMillis = it.discoverServicesDelayMillis
                    }
                }
            }
        }

        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR connect fail, originalBleDevice null")
            return null
        }
        return BleManager.getInstance().connect(originalBleDevice, adapter)?.toBluetoothGattCore()
    }

    /**
     * Cancel scan
     */
    actual fun cancelScan() {
        BleManager.getInstance().cancelScan()
    }

    /**
     * notify
     */
    actual fun notify(
        bleDevice: BleDeviceCore?,
        uuid_service: String?,
        uuid_notify: String?,
        callback: BleNotifyCallbackCore,
    ) {
        // 创建适配器将Core回调转换为原始回调
        val adapter = object : BleNotifyCallback() {
            override fun onNotifySuccess() {
                callback.onNotifySuccess()
            }

            override fun onNotifyFailure(exception: BleException) {
                callback.onNotifyFailure(exception.toBleExceptionCore())
            }

            override fun onCharacteristicChanged(data: ByteArray) {
                callback.onCharacteristicChanged(data)
            }
        }

        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR notify fail, originalBleDevice null")
            return
        }
        BleManager.getInstance().notify(originalBleDevice, uuid_service, uuid_notify, adapter)
    }

    /**
     * indicate
     */
    actual fun indicate(
        bleDevice: BleDeviceCore?,
        uuid_service: String?,
        uuid_indicate: String?,
        callback: BleIndicateCallbackCore,
    ) {
        val adapter = object : BleIndicateCallback() {
            override fun onIndicateSuccess() {
                callback.onIndicateSuccess()
            }

            override fun onIndicateFailure(exception: BleException) {
                callback.onIndicateFailure(exception.toBleExceptionCore())
            }

            override fun onCharacteristicChanged(data: ByteArray?) {
                callback.onCharacteristicChanged(data)
            }
        }

        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR indicate fail, originalBleDevice null")
            return
        }
        BleManager.getInstance().indicate(originalBleDevice, uuid_service, uuid_indicate, adapter)
    }

    actual fun write(
        bleDevice: BleDeviceCore?,
        uuid_service: String?,
        uuid_write: String?,
        writeType: Int,
        data: ByteArray,
        split: Boolean,
        sync: Boolean,
        callback: BleWriteCallbackCore,
    ) {
        val adapter = object : BleWriteCallback() {
            override fun onWriteSuccess(
                current: Int,
                total: Int,
                justWrite: ByteArray?,
            ) {
                callback.onWriteSuccess(current, total, justWrite)
            }

            override fun onWriteFailure(exception: BleException) {
                callback.onWriteFailure(exception.toBleExceptionCore())
            }
        }
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR write fail, originalBleDevice null")
            return
        }
        BleManager.getInstance().write(
            originalBleDevice,
            uuid_service,
            uuid_write,
            writeType,
            data,
            split,
            sync,
            adapter
        )
    }

    /**
     * set Mtu
     */
    actual fun setMtu(
        bleDevice: BleDeviceCore?,
        mtu: Int,
        callback: BleMtuChangedCallbackCore,
    ) {
        // 创建适配器将Core回调转换为原始回调
        val adapter = object : BleMtuChangedCallback() {
            override fun onMtuChanged(mtu: Int) {
                callback.onMtuChanged(mtu)
            }

            override fun onSetMTUFailure(exception: BleException) {
                callback.onSetMTUFailure(exception.toBleExceptionCore())
            }
        }

        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR setMtu fail, originalBleDevice null")
            return
        }
        BleManager.getInstance().setMtu(originalBleDevice, mtu, adapter)
    }

    /**
     * requestConnectionPriority
     */
    actual fun requestConnectionPriority(
        bleDevice: BleDeviceCore?,
        connectionPriority: Int,
    ): Boolean {
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR requestConnectionPriority fail, originalBleDevice null")
            return false
        }
        return BleManager.getInstance()
            .requestConnectionPriority(originalBleDevice, connectionPriority)
    }

    /**
     * 手机是否支持ble功能
     */
    actual fun isSupportBle(): Boolean {
        return BleManager.getInstance().isSupportBle
    }

    actual fun getBleBluetooth(bleDevice: BleDeviceCore?): Any? {
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR getBleBluetooth fail, originalBleDevice null")
            return null
        }
        return BleManager.getInstance().getBleBluetooth(originalBleDevice)
    }

    actual fun getBluetoothGatt(bleDevice: BleDeviceCore?): BluetoothGattCore? {
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR getBluetoothGatt fail, originalBleDevice null")
            return null
        }
        return BleManager.getInstance().getBluetoothGatt(originalBleDevice).toBluetoothGattCore()
    }

    actual suspend fun getBluetoothGattServices(bleDevice: BleDeviceCore?): List<BluetoothGattServiceCore>? {
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR getBluetoothGattServices fail, originalBleDevice null")
            return null
        }
        return BleManager.getInstance().getBluetoothGattServices(originalBleDevice)
            ?.mapNotNull { it.toBluetoothGattServiceCore() }
    }

    actual fun getScanSate(): BleScanStateCore {
        return BleManager.getInstance().scanSate.toBleScanStateCore()
    }

    actual fun startWakeupAdvertise(
        mode: Int,
        deviceName: String?,
        txPower: Byte,
        bleWakeupCallbackCore: BleWakeupCallbackCore?,
    ) {
        // 创建适配器将Core回调转换为原始回调
        val adapter = bleWakeupCallbackCore?.let {
            object : BleWakeupCallback {
                /**
                 * 原工程中，advertiseSettings并未被使用，可以删除
                 * */
                override fun wakeupSuccess(advertiseSettings: AdvertiseSettings?) {
                    it.wakeupSuccess()
                }

                override fun wakeupError(errorCode: Int) {
                    it.wakeupError(errorCode)
                }
            }
        }
        BleManager.getInstance().startWakeupAdvertise(mode, deviceName, txPower, adapter)
    }

    actual fun stopWakeupAdvertise(bleStopWakeupCallback: BleStopWakeupCallbackCore?) {
        // 创建适配器将Core回调转换为原始回调
        val adapter = bleStopWakeupCallback?.let {
            object : BleStopWakeupCallback {
                override fun stopWakeupSuccess(settingsInEffect: AdvertiseSettings) {
                    it.stopWakeupSuccess()
                }

                override fun stopWakeupError(errorCode: Int) {
                    it.stopWakeupError(errorCode)
                }
            }
        }
        BleManager.getInstance().stopWakeupAdvertise(adapter)
    }

    actual fun isConnected(bleDevice: BleDeviceCore?): Boolean {
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR isConnected fail, originalBleDevice null")
            return false
        }
        return BleManager.getInstance().isConnected(originalBleDevice)
    }

    actual fun disconnect(bleDevice: BleDeviceCore?) {
        val originalBleDevice = bleDevice?.toBleDevice() ?: run {
            println("ERROR disconnect fail, originalBleDevice null")
            return
        }
        BleManager.getInstance().disconnect(originalBleDevice)
    }

    actual fun disconnectAllDevice() {
        BleManager.getInstance().disconnectAllDevice()
    }

    actual fun destroy() {
        BleManager.getInstance().destroy()
    }

    actual fun getSplitWriteNum(): Int {
        return BleManager.getInstance().splitWriteNum
    }

    actual fun removeWriteCallback(bleDevice: BleDeviceCore?, characterUuid: String?) {
        BleManager.getInstance().removeWriteCallback(bleDevice?.toBleDevice(), characterUuid)
    }

    ///////////////////////////////////////////////////////////////////////////
    // classic bluetooth
    ///////////////////////////////////////////////////////////////////////////
    private const val CLASSIC_TAG = "classic_bluetooth"
    private val classicLock = ReentrantLock()
    // 外部主动取消（closeClassic）置位；与超时区分，避免超时被误判成 CANCELLED(138)
    @Volatile private var cancelRequested = false
    // 仅 connectSocket 超时 Runnable 置位：靠它把 close 打断的 connect 归类为 TIMEOUT(137) 而非 CANCELLED(138)
    @Volatile private var connectTimedOut = false
    // 以下四个字段在锁外有跨线程读（closeClassic/disconnectClassicBluetooth/读线程），需 @Volatile 保证可见性
    @Volatile private var classicDevice: BluetoothDevice? = null
    @Volatile private var classicSocket: BluetoothSocket? = null
    private var writePrint: Int = 0
    private var receivePrint: Int = 0
    @Volatile private var readThread: Thread? = null
    @Volatile private var receiveRunning = false
    @Volatile private var input: InputStream? = null
    @Volatile private var classicCallback: ClassicCallback? = null

    @Volatile private var bondReceiverRegistered = false
    private var bondTimeoutHandler: android.os.Handler? = null
    private var bondTimeoutRunnable: Runnable? = null

    // appear 到来时置 true：connectSocket 的超时 runnable 到点时据此延长一次（每次 connect 仅一次）。
    @Volatile private var connectExtended = false

    // 主动配对最长等待时间，需预留用户确认系统配对弹框的时间
    private const val BOND_TIMEOUT_MS = 20_000L
    // socket.connect() 阻塞超时（appear 到来时按同一时长再延长一次）
    private const val CLASSIC_CONNECT_TIMEOUT_MS = 5_000L
    // closeClassic join 读线程的上限：好 ROM 关流后毫秒级退出；坏 ROM 等再久也无益，后续 clearClassicState 会兜底
    private const val CLOSE_JOIN_TIMEOUT_MS = 300L

    @SuppressLint("MissingPermission")
    private val bondReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent?) {
            // 只处理目标设备的事件，避免被系统中其它设备的配对事件干扰
            val eventDevice: BluetoothDevice? =
                intent?.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            val target = classicDevice
            if (target != null && eventDevice != null &&
                !eventDevice.address.equals(target.address, ignoreCase = true)
            ) {
                return
            }
            when (intent?.action) {
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val state = intent.getIntExtra(
                        BluetoothDevice.EXTRA_BOND_STATE,
                        BluetoothDevice.ERROR
                    )
                    BleLogCore.i("$CLASSIC_TAG, ACTION_BOND_STATE_CHANGED(state=$state)")
                    when (state) {
                        BluetoothDevice.BOND_BONDED -> {
                            cancelBondTimeout()
                            unregisterBondReceiver()
                            // receiver 回调在主线程，connectSocket 会阻塞，必须切到子线程
                            val device = classicDevice ?: return
                            Thread { connectSocket(device) }.start()
                        }
                        BluetoothDevice.BOND_NONE -> {
                            // 配对失败或被用户拒绝，避免一直挂起
                            BleLogCore.w("$CLASSIC_TAG, bond failed (BOND_NONE)")
                            cancelBondTimeout()
                            unregisterBondReceiver()
                            clearClassicState()
                                ?.connectFailed(BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_BOND_FAILED)
                        }
                        BluetoothDevice.BOND_BONDING -> {
                            BleLogCore.i("$CLASSIC_TAG, bonding...")
                        }
                    }
                }
                BluetoothDevice.ACTION_PAIRING_REQUEST -> {
                    val type = intent.getIntExtra(
                        BluetoothDevice.EXTRA_PAIRING_VARIANT,
                        BluetoothDevice.ERROR
                    )
                    BleLogCore.i("$CLASSIC_TAG, ACTION_PAIRING_REQUEST(type=$type)")
                }
            }
        }
    }

    private fun registerBondReceiver() {
        if (bondReceiverRegistered) return
        BleLogCore.i("$CLASSIC_TAG, 注册 bond")
        val filter = IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        filter.addAction(BluetoothDevice.ACTION_PAIRING_REQUEST)
        BleManager.getInstance().getContext().registerReceiver(bondReceiver, filter)
        bondReceiverRegistered = true
    }

    private fun unregisterBondReceiver() {
        if (!bondReceiverRegistered) return
        try {
            BleManager.getInstance().getContext().unregisterReceiver(bondReceiver)
        } catch (e: Exception) {
            BleLogCore.w("$CLASSIC_TAG, unregisterBondReceiver-> $e")
        }
        bondReceiverRegistered = false
    }

    /**
     * 主动发起配对：注册监听 + 启动配对超时 + createBond。
     * 配对成功后由 bondReceiver 在子线程触发 connectSocket。
     */
    @SuppressLint("MissingPermission")
    private fun startBond(device: BluetoothDevice) {
        BleLogCore.i("$CLASSIC_TAG, startBond-> ${device.address}")
        registerBondReceiver()
        bondTimeoutHandler = android.os.Handler(android.os.Looper.getMainLooper())
        bondTimeoutRunnable = Runnable {
            BleLogCore.w("$CLASSIC_TAG, startBond-> timeout")
            unregisterBondReceiver()
            // 配对失败不触发上层重试，使用 BOND_FAILED 而非 TIMEOUT
            clearClassicState()
                ?.connectFailed(BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_BOND_FAILED)
        }
        bondTimeoutHandler?.postDelayed(bondTimeoutRunnable!!, BOND_TIMEOUT_MS)
        val started = try {
            device.createBond()
        } catch (e: Exception) {
            BleLogCore.e("$CLASSIC_TAG, createBond-> $e")
            false
        }
        if (!started) {
            BleLogCore.e("$CLASSIC_TAG, createBond returned false")
            cancelBondTimeout()
            unregisterBondReceiver()
            clearClassicState()
                ?.connectFailed(BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_BOND_FAILED)
        }
    }

    private fun cancelBondTimeout() {
        bondTimeoutRunnable?.let { bondTimeoutHandler?.removeCallbacks(it) }
        bondTimeoutRunnable = null
        bondTimeoutHandler = null
    }

    @SuppressLint("MissingPermission")
    actual fun connectClassic(cameraMac: String, classicCallback: ClassicCallback) {
        this.classicCallback = classicCallback
        cancelRequested = false
        connectTimedOut = false
        if (classicDevice != null) {
            BleLogCore.e("$CLASSIC_TAG, connectClassic($cameraMac). classicDevice is not null! running=$receiveRunning")
            if (receiveRunning) {
                classicCallback.connectSuccess()
            }
            return
        }
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        // 记录适配器开关状态，便于排查“BT 未就绪即发起 connect”的时序问题（如测试脚本切 BT 期间 CDM 抢先 appear）
        BleLogCore.i("$CLASSIC_TAG, connectClassic. adapter.isEnabled=${bluetoothAdapter?.isEnabled}, state=${bluetoothAdapter?.state}, isOn=${bluetoothAdapter?.state == BluetoothAdapter.STATE_ON}")
        // cameraMac 可能为小写(CDM 透传),BluetoothDevice.address 为大写,需忽略大小写,否则会误判未配对
        classicDevice = bluetoothAdapter?.bondedDevices?.firstOrNull {
            it.address.equals(cameraMac, ignoreCase = true)
        }
        if (classicDevice == null) {
            BleLogCore.w("$CLASSIC_TAG, connectClassic. bondedDevices don't contain $cameraMac")
            try {
                classicDevice = bluetoothAdapter.getRemoteDevice(cameraMac.uppercase())
            } catch (e: Exception) {
                BleLogCore.e("$CLASSIC_TAG, connectClassic. $e")
                clearClassicState()?.connectFailed(BleExceptionCore.ERROR_CODE_OPEN)
                return
            }
        }
        val device = classicDevice
        if (device != null) {
            BleLogCore.i("$CLASSIC_TAG, bondState=${device.bondState}")
//            if (device.bondState == BluetoothDevice.BOND_BONDED) {
            connectSocket(device)
//            } else {
//                startBond(device)
//            }
        } else {
            BleLogCore.w("$CLASSIC_TAG, classicDevice is still null")
            clearClassicState()?.connectFailed(BleExceptionCore.ERROR_CODE_OPEN)
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectSocket(device: BluetoothDevice) {
        if (device.uuids.isNullOrEmpty()) {
            BleLogCore.w("$CLASSIC_TAG, connectSocket-> uuids is empty")
        }
        BleLogCore.i("$CLASSIC_TAG, connectSocket-> 开始连接...")
        BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
        var cb: ClassicCallback? = null
        var errorCode = -1
        var success = false
        classicLock.lock()
        try {
            val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
            classicSocket = device.createRfcommSocketToServiceRecord(uuid)
            val socket = classicSocket!!
            val connectStartMs = System.currentTimeMillis()
            connectTimedOut = false
            connectExtended = false
            // 未配对(bondState != BOND_BONDED)时 socket.connect() 会隐式触发配对协商，耗时更长，
            // 超时放宽到 2 倍；已配对直连用基准超时。
            val isBonded = device.bondState == BluetoothDevice.BOND_BONDED
            val connectTimeoutMs = if (isBonded) CLASSIC_CONNECT_TIMEOUT_MS else CLASSIC_CONNECT_TIMEOUT_MS * 2
            BleLogCore.i("$CLASSIC_TAG, connectSocket-> isBonded=$isBonded, connectTimeout=${connectTimeoutMs}ms")
            val timeoutHandler = android.os.Handler(android.os.Looper.getMainLooper())
            // 用对象 Runnable 以便延长时重新 post 自身：到点若 connectExtended 已被 appear 置位，则清标志并再延长一次（每次 connect 仅一次），否则超时 close。
            val timeoutRunnable = object : Runnable {
                override fun run() {
                    if (connectExtended) {
                        connectExtended = false
                        BleLogCore.i("$CLASSIC_TAG, connectSocket-> appear 到来，延长超时 ${CLASSIC_CONNECT_TIMEOUT_MS}ms。device=${device.address}")
                        timeoutHandler.postDelayed(this, CLASSIC_CONNECT_TIMEOUT_MS)
                        return
                    }
                    // 用独立标志 connectTimedOut 标记超时（不复用 cancelRequested，否则无法区分超时与取消）
                    connectTimedOut = true
                    BleLogCore.w("$CLASSIC_TAG, connectSocket-> 连接超时触发，主动 close 打断 connect。device=${device.address}")
                    try {
                        socket.close()
                    } catch (e: Exception) {
                        BleLogCore.w("$CLASSIC_TAG, connectSocket-> 超时 close 异常: $e")
                    }
                }
            }
            timeoutHandler.postDelayed(timeoutRunnable, connectTimeoutMs)
            try {
                socket.connect()
                // 正常返回后仍可能因超时/取消竞态需判错
                success = !connectTimedOut && !cancelRequested
                if (success) {
                    BleLogCore.w("$CLASSIC_TAG, connectSocket-> 连接成功(耗时${System.currentTimeMillis() - connectStartMs}ms)。classicCallback=$classicCallback")
                    input = socket.inputStream
                    receiveRunning = true
                }
            } finally {
                timeoutHandler.removeCallbacks(timeoutRunnable)
            }
        } catch (e: Exception) {
            BleLogCore.w("$CLASSIC_TAG, connectSocket-> connect 异常: $e")
        } finally {
            if (!success) {
                errorCode = classifyConnectError()
                cb = clearClassicStateLocked()
            }
            classicLock.unlock()
        }
        if (errorCode == -1) {
            classicCallback?.writeHeart()
            classicCallback?.connectSuccess()
            startReadThread()
        } else {
            cb?.connectFailed(errorCode)
        }
    }

    private fun startReadThread() {
        readThread = Thread {
            val buffer = ByteArray(1024)
            BleLogCore.i("$CLASSIC_TAG, startReadThread-> receiveRunning=$receiveRunning")
            while (receiveRunning) {
                try {
                    val len = input?.read(buffer) ?: -1
                    receivePrint++
                    if (receivePrint > 20) {
                        receivePrint = 0
                        BleLogCore.i("$CLASSIC_TAG, startReadThread-> len=$len")
                    }
                    if (len > 0) {
                        val data = buffer.copyOf(len)
                        classicCallback?.onReceive(data)
                    }
                } catch (e: Exception) {
                    BleLogCore.w("$CLASSIC_TAG, startReadThread-> $e")
                    val code = if (cancelRequested) {
                        BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_CANCELLED
                    } else {
                        BleExceptionCore.ERROR_CODE_OPEN
                    }
                    clearClassicState()?.connectFailed(code)
                }
            }
        }
        readThread?.start()
    }

    actual fun classicWrite(
        data: ByteArray,
        split: Boolean,
        callback: BleWriteCallbackCore,
    ) {
        val adapter = object : BleWriteCallback() {
            override fun onWriteSuccess(
                current: Int,
                total: Int,
                justWrite: ByteArray?,
            ) {
                callback.onWriteSuccess(current, total, justWrite)
            }

            override fun onWriteFailure(exception: BleException) {
                callback.onWriteFailure(exception.toBleExceptionCore())
            }
        }
        try {
            classicSocket?.outputStream?.let {
                it.write(data)
                writePrint++
                if (writePrint > 20) {
                    writePrint = 0
                    BleLogCore.i("$CLASSIC_TAG, write data successfully by classic, size=${data.size}")
                }
                it.flush()
                adapter.onWriteSuccess(0, data.size, data)
            }
        } catch (e: Exception) {
            BleLogCore.e("$CLASSIC_TAG, write data by classic. $e")
        }
    }

    actual fun disconnectClassicBluetooth(address: String): Boolean {
        if (classicDevice?.address?.contentEquals(address, true) == true) {
            BleLogCore.i("$CLASSIC_TAG, disconnectClassicBluetooth")
            closeClassic()
            return true
        }
        BleLogCore.i("$CLASSIC_TAG, disconnectClassicBluetooth, address is error, classicDevice=$classicDevice")
        return false
    }

    /**
     * 收到 appear（相机确认在场）时置位延长标志：connectSocket 的超时 runnable 到点时据此延长一次超时，
     * 避免正卡在握手的 connect 被超时打断。仅置标志、不直接操作 handler；
     * 即使在 connect 真正开始前调用，也会被本次 connect 的超时 runnable 到点时消费（每次 connect 仅延长一次）。
     */
    actual fun extendClassicConnectTimeout() {
        // 临时停用超时延长:connect 现由 appear/ACL 触发(appear 早已到),不再需要靠后续 appear 延长;
        // 且华为机型 appear 反复到来会反复置位,把单次 connect 从 5s 拖到数分钟。以后再决定是否整条链路移除。
        // connectExtended = true
        BleLogCore.i("$CLASSIC_TAG, extendClassicConnectTimeout-> mark extended (disabled)")
    }

    fun closeClassic(errorCode: Int = BleExceptionCore.ERROR_CODE_OPEN) {
        BleLogCore.i("$CLASSIC_TAG, closeClassic(errorCode=$errorCode)")
        cancelRequested = true
        cancelBondTimeout()
        unregisterBondReceiver()
        // 不持锁关流/socket：若 connectSocket 正阻塞在 connect() 持有 classicLock，持锁会死锁
        // （且超时 Runnable 跑在主线程，主线程被锁挡住则超时不触发 → connect() 无限阻塞 → ANR）。
        // 先无锁关 socket 中断 connect()、让 connectSocket 释放锁，后续 clearClassicState 才拿得到锁。
        closeClassicChannels()
        try {
            readThread?.join(CLOSE_JOIN_TIMEOUT_MS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        clearClassicState()?.connectFailed(BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_CANCELLED)
    }

    private fun clearClassicState(): ClassicCallback? {
        BleLogCore.i("$CLASSIC_TAG, clearClassicState")
        classicLock.lock()
        return try {
            clearClassicStateLocked()
        } finally {
            classicLock.unlock()
        }
    }

    private fun clearClassicStateLocked(): ClassicCallback? {
        BleLogCore.i("$CLASSIC_TAG, clearClassicStateLocked-> receiveRunning=$receiveRunning, classicSocket=$classicSocket, classicDevice=$classicDevice")
        if (!receiveRunning && classicSocket == null && classicDevice == null) return null
        receiveRunning = false
        cancelRequested = false
        connectTimedOut = false
        val cb = classicCallback
        classicCallback = null
        closeClassicChannels()
        input = null
        classicSocket = null
        classicDevice = null
        cancelBondTimeout()
        unregisterBondReceiver()
        return cb
    }

    /** 关闭 input/outputStream/socket。幂等；input 字段的置空由调用方在锁内处理。 */
    private fun closeClassicChannels() {
        try {
            input?.close()
        } catch (_: Exception) {
        }
        try {
            classicSocket?.outputStream?.close()
        } catch (_: Exception) {
        }
        try {
            classicSocket?.close()
        } catch (_: Exception) {
        }
    }

    /** connect 异常/竞态归类：超时优先，其次主动取消，最后通用失败。 */
    private fun classifyConnectError(): Int = when {
        connectTimedOut -> BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_TIMEOUT
        cancelRequested -> BleExceptionCore.ERROR_CODE_CONNECT_CLASSIC_CANCELLED
        else -> BleExceptionCore.ERROR_CODE_OPEN
    }
}