package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleIndicateCallbackCore {

    abstract fun onIndicateSuccess()

    abstract fun onIndicateFailure(exception: BleExceptionCore)

    abstract fun onCharacteristicChanged(data: ByteArray?)
}
