package com.arashivision.inskmp.insble

expect object SDKABTestExperimentManagerCore {
    fun setImpl(isThreadOptHits: () -> Boolean)

    fun setBleScanFilterExperiment(enable: Boolean)
}