package com.arashivision.inskmp.insble

expect object BleLogCore {
    fun v(msg: String)
    fun d(msg: String)
    fun i(msg: String)
    fun w(msg: String)
    fun e(msg: String)
    fun ft(msg: Throwable)
    fun enableLog(enable: Boolean)

    fun setLoggerCallback(callback: ILoggerCallbackCore)
}

interface ILoggerCallbackCore {
    fun onLogV(tag: String?, msg: String?)

    fun onLogD(tag: String?, msg: String?)

    fun onLogI(tag: String?, msg: String?)

    fun onLogW(tag: String?, msg: String?)

    fun onLogE(tag: String?, msg: String?)

    fun onLogFt(tag: String?, t: Throwable?)
}