package com.arashivision.inskmp.insble.data

typealias JsArrayCharacteristic = Any

data class BluetoothGattServiceCore constructor(val nativeBluetoothGattService: Any) {

    @Deprecated(
        "Knoi天坑，arkts返回给kotlin的Array<JSValue>有问题，变为了Array<HashMap>, 用 getCharacteristicArray 替代",
        level = DeprecationLevel.ERROR
    )
    fun getCharacteristics(): List<BluetoothGattCharacteristicCore>? {
        return getCharacteristics(nativeBluetoothGattService)
    }

    /**
     * return JSValue<List<BluetoothGattCharacteristicCore>?>?
     * */
    fun getCharacteristicArray(): JsArrayCharacteristic? {
        return getCharacteristicArray(nativeBluetoothGattService)
    }

    fun getUuid(): String? {
        return getUuid(nativeBluetoothGattService)
    }

    fun getCharacteristic(characteristicUUID: String): BluetoothGattCharacteristicCore? {
        return getCharacteristics(nativeBluetoothGattService, characteristicUUID)
    }
}

inline fun JsArrayCharacteristic.forEachItem(crossinline eachCallback: (characteristicCore: BluetoothGattCharacteristicCore) -> Unit) {
    forEachJsArrayCharacteristic(this, eachCallback)
}

/**
 * 对应 BluetoothGatt.getServices() 函数
 * */
expect fun getCharacteristics(nativeBluetoothGattService: Any): List<BluetoothGattCharacteristicCore>?

expect fun getCharacteristics(
    nativeBluetoothGattService: Any,
    characteristicUUID: String,
): BluetoothGattCharacteristicCore?

expect fun getUuid(nativeBluetoothGattService: Any): String?

expect fun getCharacteristicArray(nativeBluetoothGattService: Any): Any?

expect inline fun forEachJsArrayCharacteristic(
    jsArrayCharacteristic: Any,
    crossinline eachCallback: (characteristicCore: BluetoothGattCharacteristicCore) -> Unit
)
