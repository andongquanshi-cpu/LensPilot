package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.data.BleDeviceCore

abstract class BleScanCallbackCore : BleScanPresenterImpCore {

    abstract fun onScanFinished(scanResultList: List<BleDeviceCore>)

    open fun onLeScan(bleDevice: BleDeviceCore?) {
        // 原安卓工程中，默认空实现，而且没有类继承它，可以删除。
    }
}
