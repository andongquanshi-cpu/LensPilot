package com.arashivision.inskmp.insble.utils

import com.arashivision.inskmp.insble.data.BleDeviceCore

expect object BleDeviceUtilCore {
    fun getAllSystemConnectedDevices(): List<BleDeviceCore>
    fun getAllSystemBondedDevices(): List<BleDeviceCore>
    fun createBond(bleDeviceCore: BleDeviceCore): Boolean

}