package com.arashivision.inskmp.insble.data

import android.Manifest
import android.bluetooth.BluetoothDevice
import androidx.annotation.RequiresPermission
import com.arashivision.inskmp.insble.toBleScanProtoCore
import com.clj.fastble.data.BleDevice

actual fun getName(nativeDevice: Any): String? {
    return (nativeDevice as? BleDevice)?.name
}

actual fun getMac(nativeDevice: Any): String? {
    return (nativeDevice as? BleDevice)?.mac
}

actual fun getKey(nativeDevice: Any): String? {
    return (nativeDevice as? BleDevice)?.key
}

actual fun getBleScanProto(nativeDevice: Any): BleScanProtoCore? {
    return (nativeDevice as? BleDevice)?.bleScanProto?.toBleScanProtoCore()
}

actual fun getScanRecord(nativeDevice: Any): ByteArray? {
    return (nativeDevice as? BleDevice)?.scanRecord
}

actual fun getRssi(nativeDevice: Any): Int? {
    return (nativeDevice as? BleDevice)?.rssi
}

actual fun getTimestampNanos(nativeDevice: Any): Long? {
    return (nativeDevice as? BleDevice)?.timestampNanos
}

actual fun getServiceUuids(nativeDevice: Any): List<String>? {
    return (nativeDevice as? BleDevice)?.serviceUuids?.map { it.uuid.toString() }
}

@RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
actual fun getBluetoothDeviceType(nativeDevice: Any): Int {
    return (nativeDevice as? BleDevice)?.device?.type ?: 0
}

actual fun getBluetoothDeviceAddress(nativeDevice: Any): String {
    return (nativeDevice as? BleDevice)?.device?.address ?: ""
}

actual fun getNameInner(nativeDevice: Any): String? {
    return (nativeDevice as? BleDevice)?.nameInner
}

actual fun isCameraServiceUuid(nativeDevice: Any): Boolean {
    return (nativeDevice as? BleDevice)?.isCameraServiceUuid == true
}

actual fun buildBleDeviceCoreByNative(nativeDevice: Any, deviceName: String?, rssi: Int): BleDeviceCore? {
    return BleDeviceCore(BleDevice(nativeDevice as BluetoothDevice, deviceName, rssi, null, 0, null, null))
}

actual fun getBluetoothDevice(nativeDevice: Any): Any? {
    return (nativeDevice as? BleDevice)?.device
}