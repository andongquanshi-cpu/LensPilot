package com.arashivision.inskmp.insble.callback

interface IBleScanProtoDependenceCore {
    fun getDeviceType(value: Int): String?

    fun transformDeviceName(deviceName: String?): String?

    fun getScanMode(): Int
}
