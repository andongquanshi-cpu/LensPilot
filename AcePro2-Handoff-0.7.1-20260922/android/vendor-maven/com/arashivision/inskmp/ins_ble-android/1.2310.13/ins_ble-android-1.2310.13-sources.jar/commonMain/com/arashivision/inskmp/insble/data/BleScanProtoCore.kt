package com.arashivision.inskmp.insble.data

data class BleScanProtoCore(val nativeProto: Any) {

    companion object {
        const val BOOT_UP_STATUS_SHUT_DOWN: Int = 0
        const val BOOT_UP_STATUS_NORMAL_BOOT_UP: Int = 1
        const val BOOT_UP_STATUS_UNCONNECTABLE: Int = 2 // 低电(或其他不可连接状态)
        const val BOOT_UP_STATUS_QUICK_CAPTURE: Int = 3
        const val WIFI_CLOSE: Int = 0
        const val WIFI_UNINITIALIZED: Int = 255

        // 网络类型 @see WifiMode.kt
        const val WIFI_MODE_AP = 0
        const val WIFI_MODE_STA = 1
        const val WIFI_MODE_P2P = 2
        const val WIFI_MODE_ANDROID_AWARE = 3
        const val WIFI_MODE_IOS_AWARE = 4
    }

    private var _wifiActiveTimeS: Int = getWifiActiveTimeS(nativeProto)
    private var _wifiPWDVersion: Int = getWifiPWDVersion(nativeProto)
    private var _bootUpStatus: Int = getBootUpStatus(nativeProto)
    private var _deviceType: Int = getDeviceType(nativeProto) // 广播中代表相机型号的字节
    private var _protoVersion: Int = getProtoVersion(nativeProto) // 广播版本
    private var _deviceNamePrefix: String = getDeviceNamePrefix(nativeProto)
    private var _nfcCrc: Byte = getNfcCrc(nativeProto) // nfc crc 比较
    private var _nfcCrc2: Byte = getNfcCrc2(nativeProto) // nfc crc2 (MSB of CRC-16/XMODEM for V4 broadcast)
    private var _netType: Int = getNetType(nativeProto) // 相机启动的网络类型

    val wifiActiveTimeS: Int
        get() = _wifiActiveTimeS

    val wifiPWDVersion: Int
        get() = _wifiPWDVersion

    val bootUpStatus: Int
        get() = _bootUpStatus

    val deviceType: Int
        get() = _deviceType

    val protoVersion: Int
        get() = _protoVersion

    val deviceNamePrefix: String
        get() = _deviceNamePrefix

    val nfcCrc: Byte
        get() = _nfcCrc

    val nfcCrc2: Byte
        get() = _nfcCrc2

    /**
     * 相机启动的网络类型：AP = 0; STA = 1; P2P = 2; Android_Aware = 3; IOS_Aware = 4;
     * @see WifiMode.kt
     */
    val netType: Int
        get() = _netType

    override fun toString(): String {
        return "BleScanProtoCore{" +
                "wifiActiveTimeS=${wifiActiveTimeS}" +
                ", wifiPWDVersion=${wifiPWDVersion}" +
                ", bootUpStatus=${bootUpStatus}" +
                ", deviceType=${deviceType}" +
                ", protoVersion=${protoVersion}" +
                ", deviceNamePrefix=${deviceNamePrefix}" +
                ", nfcCrc=${nfcCrc}" +
                ", nfcCrc2=${nfcCrc2}" +
                ", netType=${netType}" +
                '}'
    }
}

expect fun getWifiActiveTimeS(nativeProto: Any): Int
expect fun getWifiPWDVersion(nativeProto: Any): Int
expect fun getBootUpStatus(nativeProto: Any): Int
expect fun getDeviceType(nativeProto: Any): Int
expect fun getProtoVersion(nativeProto: Any): Int
expect fun getDeviceNamePrefix(nativeProto: Any): String
expect fun getNfcCrc(nativeProto: Any): Byte
expect fun getNfcCrc2(nativeProto: Any): Byte
expect fun getNetType(nativeProto: Any): Int