package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.data.BleDeviceCore
import com.arashivision.inskmp.insble.data.ScanResultCore

interface BleScanPresenterImpCore {

    fun onScanStarted(errorCode: Int)

    fun onRawScanResult(callbackType: Int, result: ScanResultCore?)

    fun onScanning(bleDevice: BleDeviceCore?)

    fun onScanUpdate(bleDeviceList: List<BleDeviceCore>)

    fun onScanReject()
}
