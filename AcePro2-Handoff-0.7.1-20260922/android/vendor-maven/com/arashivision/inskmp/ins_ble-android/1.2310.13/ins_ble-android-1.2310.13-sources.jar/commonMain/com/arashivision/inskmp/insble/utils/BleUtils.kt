package com.arashivision.inskmp.insble.utils

object BleUtils {
    fun printProtoBytes(hex: String?): String {
        val print = StringBuilder("{")
        if (hex == null) {
            print.append("null")
        } else {
            val length = hex.length
            if (hex.length < 50) {
                print.append("length = ")
                    .append(length)
                    .append(", bytes = ")
                    .append(hex)
            } else {
                print.append("length = ")
                    .append(length)
                    .append(", bytes = ")
                    .append(hex.substring(0, 32))
                    .append(" ... ")
                    .append(hex.substring(hex.length - 16))
            }
        }
        return print.append("}").toString()
    }
}