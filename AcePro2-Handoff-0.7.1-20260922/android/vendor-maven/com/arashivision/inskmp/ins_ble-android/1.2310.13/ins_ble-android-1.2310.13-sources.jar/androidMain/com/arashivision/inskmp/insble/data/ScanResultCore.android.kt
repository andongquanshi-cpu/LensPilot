package com.arashivision.inskmp.insble.data

import android.bluetooth.le.ScanResult

actual fun getNativeBleDevice(nativeScanResult: Any): Any? {
    return (nativeScanResult as? ScanResult)?.device
}