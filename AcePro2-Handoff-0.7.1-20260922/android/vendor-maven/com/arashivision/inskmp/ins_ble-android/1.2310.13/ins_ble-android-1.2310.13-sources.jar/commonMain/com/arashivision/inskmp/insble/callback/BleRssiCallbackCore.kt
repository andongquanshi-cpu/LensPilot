package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleRssiCallbackCore  {

    abstract fun onRssiFailure(exception: BleExceptionCore)

    abstract fun onRssiSuccess(rssi: Int)
}
