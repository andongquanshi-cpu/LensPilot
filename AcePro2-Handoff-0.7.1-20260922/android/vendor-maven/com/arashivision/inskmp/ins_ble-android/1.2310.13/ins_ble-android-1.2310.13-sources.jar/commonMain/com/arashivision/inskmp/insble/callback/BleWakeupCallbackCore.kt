package com.arashivision.inskmp.insble.callback

interface BleWakeupCallbackCore {

    /**
     * 原工程中接口定义是 void wakeupSuccess(AdvertiseSettings errorCode);
     * 原工程中，advertiseSettings并未被使用，可以删除
     * */
    fun wakeupSuccess()

    fun wakeupError(errorCode: Int)
}
