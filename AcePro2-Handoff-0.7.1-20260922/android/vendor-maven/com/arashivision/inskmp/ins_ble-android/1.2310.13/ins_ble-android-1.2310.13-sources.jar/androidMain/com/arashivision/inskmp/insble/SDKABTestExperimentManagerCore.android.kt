package com.arashivision.inskmp.insble

import com.clj.fastble.FastbleInstaSdkExperiment
import com.clj.fastble.abtest.SDKABTestExperimentManager

actual object SDKABTestExperimentManagerCore {
    actual fun setImpl(isThreadOptHits: () -> Boolean) {
        SDKABTestExperimentManager.setABTestExperimentImpl { isThreadOptHits.invoke() }
    }

    actual fun setBleScanFilterExperiment(enable: Boolean) {
        FastbleInstaSdkExperiment.sBleScanFilterExperiment = enable
    }
}