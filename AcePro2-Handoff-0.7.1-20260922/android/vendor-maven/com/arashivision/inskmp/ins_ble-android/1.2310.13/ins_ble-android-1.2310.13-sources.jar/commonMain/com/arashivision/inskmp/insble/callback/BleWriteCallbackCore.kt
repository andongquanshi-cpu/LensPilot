package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleWriteCallbackCore  {

    abstract fun onWriteSuccess(current: Int, total: Int, justWrite: ByteArray?)

    abstract fun onWriteFailure(exception: BleExceptionCore)
}
