package com.arashivision.inskmp.insble.data

import com.clj.fastble.data.BleScanProto

actual fun getWifiActiveTimeS(nativeProto: Any): Int {
    return (nativeProto as? BleScanProto)?.wifiActiveTimeS ?: 0
}

actual fun getWifiPWDVersion(nativeProto: Any): Int {
    return (nativeProto as? BleScanProto)?.wifiPWDVersion ?: 0
}

actual fun getBootUpStatus(nativeProto: Any): Int {
    return (nativeProto as? BleScanProto)?.bootUpStatus ?: 0
}

actual fun getDeviceType(nativeProto: Any): Int {
    return (nativeProto as? BleScanProto)?.deviceType ?: -1
}
actual fun getProtoVersion(nativeProto: Any): Int {
    return (nativeProto as? BleScanProto)?.protoVersion ?: 1
}

actual fun getDeviceNamePrefix(nativeProto: Any): String {
    return (nativeProto as? BleScanProto)?.deviceNamePrefix ?: ""
}

actual fun getNfcCrc(nativeProto: Any): Byte {
    return (nativeProto as? BleScanProto)?.nfcCrc ?: 0
}

actual fun getNfcCrc2(nativeProto: Any): Byte {
    return (nativeProto as? BleScanProto)?.nfcCrc2 ?: 0
}
actual fun getNetType(nativeProto: Any): Int {
    return (nativeProto as? BleScanProto)?.netType ?: BleScanProtoCore.WIFI_MODE_AP
}
