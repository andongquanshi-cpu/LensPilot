package com.arashivision.inskmp.insble.callback

import com.arashivision.inskmp.insble.exception.BleExceptionCore

abstract class BleReadCallbackCore  {

    abstract fun onReadSuccess(data: ByteArray)

    abstract fun onReadFailure(exception: BleExceptionCore)
}
