package com.arashivision.inskmp.insble.scan

class BleScanRuleConfigCore {
    private var mServiceUuids: Array<String>? = null
    private var mDeviceNames: Array<String>? = null
    private var mDeviceMac: String? = null
    private var mAutoConnect = false
    private var mFuzzy = false
    private var mScanTimeOut = 10000L // DEFAULT_SCAN_TIME

    fun getServiceUuids(): Array<String>? {
        return mServiceUuids
    }

    fun getDeviceNames(): Array<String>? {
        return mDeviceNames
    }

    fun getDeviceMac(): String? {
        return mDeviceMac
    }

    fun isAutoConnect(): Boolean {
        return mAutoConnect
    }

    fun isFuzzy(): Boolean {
        return mFuzzy
    }

    fun getScanTimeOut(): Long {
        return mScanTimeOut
    }

    class Builder {
        private var mServiceUuids: Array<String>? = null
        private var mDeviceNames: Array<String>? = null
        private var mDeviceMac: String? = null
        private var mAutoConnect = false
        private var mFuzzy = false
        private var mTimeOut = 10000L

        fun setServiceUuids(uuids: Array<String>?): Builder {
            this.mServiceUuids = uuids
            return this
        }

        fun setDeviceName(fuzzy: Boolean, vararg name: String): Builder {
            this.mFuzzy = fuzzy
            this.mDeviceNames = Array(name.size) { name[it] }
            return this
        }

        fun setDeviceMac(mac: String?): Builder {
            this.mDeviceMac = mac
            return this
        }

        fun setAutoConnect(autoConnect: Boolean): Builder {
            this.mAutoConnect = autoConnect
            return this
        }

        fun setScanTimeOut(timeOut: Long): Builder {
            this.mTimeOut = timeOut
            return this
        }

        private fun applyConfig(config: BleScanRuleConfigCore) {
            config.mServiceUuids = this.mServiceUuids
            config.mDeviceNames = this.mDeviceNames
            config.mDeviceMac = this.mDeviceMac
            config.mAutoConnect = this.mAutoConnect
            config.mFuzzy = this.mFuzzy
            config.mScanTimeOut = this.mTimeOut
        }

        fun build(): BleScanRuleConfigCore {
            val config = BleScanRuleConfigCore()
            applyConfig(config)
            return config
        }
    }
}
