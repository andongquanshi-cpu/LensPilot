package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.data.UsbDeviceCore

expect class AppUsbServiceCore(context: Any?) {
    fun getUsbSysPath(): String

    fun getDevice(mDeviceFilter: DeviceFilter): UsbDeviceCore?

    fun openDevice(device: UsbDeviceCore)

    fun addObserver(mDeviceFilter: DeviceFilter, observer: UsbObserver)

    fun release()
}