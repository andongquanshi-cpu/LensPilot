package com.arashivision.inskmp.insusb.data


object UsbError {
    const val ERR_CONNECTION: Int = -900000
    const val ERR_PERMISSION: Int = -900001
    const val ERR_UNKNOWN: Int = -900002
}
