package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.callback.UsbCallbackCore
import com.arashivision.inskmp.insusb.data.UsbStateCore

/**
 * Socket Manager Core - Common interface for socket operations
 * Provides cross-platform socket functionality with open(), serve(), write(), read() methods
 */
expect class UsbManagerCore() {

    /**
     * Initialize the socket manager
     * @param config Socket configuration including address, port, timeout, etc.
     * @return 0 on success, error code on failure
     */
    fun init(config: String): Int

    /**
     * Open socket connection
     * @return 0 on success, error code on failure
     */
    fun open(): Int

    /**
     * Start serving the socket (begin async I/O operations)
     * @return 0 on success, error code on failure
     */
    fun serve(): Int

    /**
     * Set setSynced flag, after serve() get syncPacket!
     * @return 0 on success, error code on failure
     */
    fun setSynced(synced: Boolean): Int

    /**
     * Write data to socket
     * @param data ByteArray data to write
     * @return 0 on success, error code on failure
     */
    fun write(data: List<ByteArray>): Int

    /**
     * Read data from socket (non-blocking)
     * @param buffer ByteArray buffer to store read data
     * @return number of bytes read, 0 if no data available, -1 on error
     */
    fun read(buffer: ByteArray): Int

    /**
     * Get current socket state
     * @return SocketStateCore current state
     */
    fun getState(): UsbStateCore

    /**
     * Set callback for socket events
     * @param callback SocketCallbackCore callback interface
     */
    fun setCallback(callback: UsbCallbackCore?)

    /**
     * Close socket connection
     * @return 0 on success, error code on failure
     */
    fun close(): Int

    /**
     * Destroy socket manager and cleanup resources
     */
    fun destroy()
}
