package com.arashivision.inskmp.insusb.data

/**
 * Socket state enumeration
 */
enum class UsbStateCore {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR,
    CLOSED
}

enum class SocketError {
    NONE,
    OPEN,
    SERVE,
    SYNCED,
    WRITE,
    READ,
    CLOSE
}
