package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.data.UsbDeviceCore


expect open class UsbObserver() {
    fun onDeviceAttached(device: UsbDeviceCore?, filter: DeviceFilter?)

    fun onDeviceDetached(device: UsbDeviceCore?, filter: DeviceFilter?)

    open fun onDeviceOpenComplete(
        device: UsbDeviceCore?, con: UsbDeviceConnectionCore?,
        filter: DeviceFilter?, err: Int
    )
}
