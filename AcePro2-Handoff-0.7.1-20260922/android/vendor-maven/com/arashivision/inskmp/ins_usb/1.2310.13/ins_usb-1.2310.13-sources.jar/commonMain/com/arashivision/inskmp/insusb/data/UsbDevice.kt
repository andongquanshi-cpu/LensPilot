package com.arashivision.inskmp.insusb.data


expect class UsbDeviceCore(device: Any?) {

    fun getInterfaceCount(): Int
    fun getVendorId(): Int?
    fun getDeviceId(): Int?

    fun getProductName(): String?

}