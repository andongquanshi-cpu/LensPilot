package com.arashivision.inskmp.insusb.callback

/**
 * Socket callback interface for handling socket events
 */
interface UsbCallbackCore {
    /**
     * Called when data is received from socket
     * @param data ByteArray received data
     */
    fun onDataReceived(data: ByteArray)

    /**
     * Called when an error occurs
     * @param errorCode Int error code
     * @param errorMessage String error message
     */
    fun onError(errorCode: Int)
}
