package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.data.UsbDeviceCore

expect interface DeviceFilter {
    fun filter(device: UsbDeviceCore?): Boolean
}
