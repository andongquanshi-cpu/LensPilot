package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.data.UsbDeviceCore

actual interface DeviceFilter {
    actual fun filter(device: UsbDeviceCore?): Boolean
}