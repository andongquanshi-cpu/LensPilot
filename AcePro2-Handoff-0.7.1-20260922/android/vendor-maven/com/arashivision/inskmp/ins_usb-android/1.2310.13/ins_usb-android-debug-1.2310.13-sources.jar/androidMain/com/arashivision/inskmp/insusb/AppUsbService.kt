package com.arashivision.inskmp.insusb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Message
import android.util.Log
import com.arashivision.inskmp.insusb.data.UsbDeviceCore
import com.arashivision.inskmp.insusb.data.UsbError
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.ref.WeakReference
import java.util.Locale
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.Volatile

class AppUsbService(context: Context) {
    private var mAppContext: Context = context.applicationContext
    private var mUsbReceiver = UsbBroadcastReceiver(this)
    private val mUsbManager =
        mAppContext.getSystemService(Context.USB_SERVICE) as UsbManager
    private val mDefaultObserverHandler =
        Handler(mAppContext.mainLooper)
    private var mPermPendingDevice: UsbDevice? = null
    private var mPermissionState: UsbPermission? = null
    private val mPermissionSyncObj = Any()

    private enum class UsbPermission {
        WaitingGrant, Granted, Deny
    }

    private var mUsbDir: File? = null
    private var mUsbThread: HandlerThread?
    private val mUsbHandler: Handler

    @Volatile
    private var mIsRunning: Boolean

    private class ConnectionInfo(var device: UsbDevice, var con: UsbDeviceConnection) {
        var devDir: File? = null
    }

    private val mConnections = ArrayList<ConnectionInfo>()

    private class ObserverInfo(var filter: DeviceFilter, var observer: UsbObserver)

    private val mObserverLists = ArrayList<ObserverInfo>()

    private fun loadOnce(context: Context) {
        synchronized(mLoadSyncObject) {
            if (mLoaded) return
            try {
                var fileDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                if (fileDir == null) {
                    if (context.filesDir != null) {
                        fileDir = File(context.filesDir, Environment.DIRECTORY_DOCUMENTS)
                    } else {
                        var absolutePath = Environment.getExternalStorageDirectory().absolutePath
                        absolutePath =
                            absolutePath + File.separator + Environment.DIRECTORY_DOCUMENTS
                        fileDir = File(absolutePath)
                    }
                }
                Log.i(TAG, "file_dir = " + fileDir.absolutePath)
                mUsbSysRootDir = File(fileDir, "usb_sys")
                Log.i(TAG, "clean usb sys root directory " + mUsbSysRootDir!!.absolutePath)
                deleteFile(mUsbSysRootDir)
                mUsbSysRootDir!!.mkdir()
                if (!mUsbSysRootDir!!.isDirectory) throw IOException("failed create path: " + mUsbSysRootDir.toString())
            } catch (e: Exception) {
                Log.e(TAG, "can not create usb_sys dir")
            }
            mLoaded = true
        }
    }

    fun release() {
        if (!mIsRunning) return
        Log.i(TAG, "release app usb service")
        mIsRunning = false
        mAppContext.unregisterReceiver(mUsbReceiver)
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_QUIT))
        try {
//            mUsbThread.join();
            mUsbThread!!.quitSafely()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mUsbThread = null
        try {
            deleteFile(mUsbDir)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.i(TAG, "app usb service released")
    }


    val usbSysPath: String
        get() {
            val usbDir = mUsbDir
            return if (usbDir != null && usbDir.exists()) usbDir.absolutePath else ""
        }

    fun addObserver(filter: DeviceFilter, usbObserver: UsbObserver) {
        val latch = CountDownLatch(1)
        val objs = arrayOf(filter, usbObserver, latch)
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_ADD_OBSERVER, objs))
        try {
            latch.await()
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    fun removeObserver(filter: DeviceFilter, usbObserver: UsbObserver) {
        val latch = CountDownLatch(1)
        val objs = arrayOf(filter, usbObserver, latch)
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_REMOVE_OBSERVER, objs))
        try {
            latch.await()
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    fun openDevice(originDev: UsbDevice?) {
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_OPEN_DEVICE, originDev))
    }

    fun closeDevice(device: UsbDevice?) {
        Log.i(TAG, "close device: " + deviceName(device))
        val latch = CountDownLatch(1)
        val objs = arrayOf(device, latch)
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_CLOSE_DEVICE, objs))
        try {
            latch.await()
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    fun getDevice(filter: DeviceFilter?): UsbDevice? {
        val latch = CountDownLatch(1)
        val objs = arrayOf(filter, latch, null)
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_GET_DEVICE, objs))

        try {
            latch.await()
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
        return objs[2] as UsbDevice?
    }

    private fun handleRequest(msg: Message) {
        when (msg.what) {
            MSG_ADD_OBSERVER -> {
                val argv = msg.obj as Array<Any>
                doAddObserver(argv[0] as DeviceFilter, argv[1] as UsbObserver)
                (argv[2] as CountDownLatch).countDown()
            }

            MSG_REMOVE_OBSERVER -> {
                val argv = msg.obj as Array<Any>
                doRemoveObserver(argv[0] as DeviceFilter, argv[1] as UsbObserver)
                (argv[2] as CountDownLatch).countDown()
            }

            MSG_OPEN_DEVICE -> {
                doOpenDevice(msg.obj as UsbDevice)
            }

            MSG_CLOSE_DEVICE -> {
                val argv = msg.obj as Array<Any>
                doCloseDevice(argv[0] as UsbDevice)
                (argv[1] as CountDownLatch).countDown()
            }

            MSG_GET_DEVICE -> {
                val argv = msg.obj as Array<Any?>
                val filter = argv[0] as DeviceFilter?
                val latch = argv[1] as CountDownLatch?
                argv[2] = doGetDevice(filter!!)
                latch!!.countDown()
            }

            MSG_SYS_DEVICE_ATTACHED -> {
                notifyDeviceAttached(msg.obj as UsbDevice)
            }

            MSG_SYS_DEVICE_DETACHED -> {
                notifyDeviceDetached(msg.obj as UsbDevice)
            }

            MSG_QUIT -> {
                doQuit()
            }
        }
    }

    private class UsbHandler(appUsbService: AppUsbService, looper: Looper) : Handler(looper) {
        private val mAppUsbService =
            WeakReference(appUsbService)

        override fun handleMessage(msg: Message) {
            val appUsbService = mAppUsbService.get() ?: return
            appUsbService.handleRequest(msg)
        }
    }

    private fun doAddObserver(filter: DeviceFilter, usbObserver: UsbObserver) {
        for (info in mObserverLists) {
            if (info.filter === filter && info.observer === usbObserver) return
        }
        mObserverLists.add(ObserverInfo(filter, usbObserver))
    }

    private fun doRemoveObserver(filter: DeviceFilter, usbObserver: UsbObserver) {
        val itr = mObserverLists.iterator()
        while (itr.hasNext()) {
            val observerInfo = itr.next()
            if (observerInfo.filter === filter && observerInfo.observer === usbObserver) itr.remove()
        }
    }

    private fun doGetDevice(filter: DeviceFilter): UsbDevice? {
        Log.d(TAG, "mUsbManager.getDeviceList() size " + mUsbManager.deviceList.size)
        for (device in mUsbManager.deviceList.values) {
            val deviceCore = UsbDeviceCore(device)
            if (filter.filter(deviceCore)) return device
        }
        return null
    }

    private fun doQuit() {
        val itr = mConnections.iterator()
        if (itr.hasNext()) {
            val connectionInfo = itr.next()
            closeConnection(connectionInfo)
            Log.i(TAG, "quiting... close connection: " + connectionInfo.device)
            itr.remove()
        }
        val looper = Looper.myLooper()
        looper?.quit()
    }

    private fun executeObserverCb(observer: UsbObserver, runnable: Runnable) {
        val handler = mDefaultObserverHandler
        handler.post(runnable)
    }

    private fun notifyOpenResult(
        device: UsbDevice,
        con: UsbDeviceConnection?, err: Int,
    ) {
        synchronized(mObserverLists) {
            for (info in mObserverLists) {
                val filter = info.filter
                val observer = info.observer
                val deviceCore = UsbDeviceCore(device)
                if (!filter.filter(deviceCore)) continue
                executeObserverCb(
                    observer
                ) { observer.onDeviceOpenComplete(deviceCore, null, filter, err) }
            }
        }
    }

    private fun notifyDeviceAttached(device: UsbDevice) {
        synchronized(mObserverLists) {
            for (info in mObserverLists) {
                val filter = info.filter
                val observer = info.observer
                val deviceCore = UsbDeviceCore(device)
                if (!filter.filter(deviceCore)) continue
                executeObserverCb(
                    observer
                ) { observer.onDeviceAttached(deviceCore, filter) }
            }
        }
    }

    private fun notifyDeviceDetached(device: UsbDevice) {
        synchronized(mObserverLists) {
            for (info in mObserverLists) {
                val filter = info.filter
                val observer = info.observer
                val deviceCore = UsbDeviceCore(device)
                if (!filter.filter(deviceCore)) continue
                executeObserverCb(
                    observer
                ) { observer.onDeviceDetached(deviceCore, filter) }
            }
        }
    }

    private var mFakeBusNum = 1
    private var mFakeDevNum = 1

    init {
        mIsRunning = true

        mUsbThread = HandlerThread("UsbThread")
        mUsbThread!!.start()
        mUsbHandler = UsbHandler(this, mUsbThread!!.looper)

        val filter = IntentFilter()
        filter.addAction(APP_SERVICE_ACTION_USB_PERMISSION)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            mAppContext.registerReceiver(mUsbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            mAppContext.registerReceiver(mUsbReceiver, filter)
        }
    }

    private class BusDev(var busNum: Int, var devNum: Int)

    private fun fakeBusDev(): BusDev {
        val busDev = BusDev(mFakeBusNum, mFakeDevNum)
        ++mFakeDevNum
        if (mFakeDevNum >= 255) {
            ++mFakeBusNum
            mFakeDevNum = 0
        }
        return busDev
    }

    @Throws(IOException::class)
    private fun createFile(dir: File, filename: String, content: String) {
        val bytes = content.toByteArray(charset("utf-8"))
        createFile(dir, filename, bytes)
    }

    @Throws(IOException::class)
    private fun createFile(dir: File, filename: String, content: ByteArray) {
        val file = File(dir, filename)
        var fos: FileOutputStream? = null
        try {
            fos = FileOutputStream(file)
            fos.write(content)
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (fos != null) {
                try {
                    fos.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun createUsbDir() {
        if (mUsbDir == null) {
            loadOnce(mAppContext)
            try {
                mUsbDir = File.createTempFile("usb-", "", mUsbSysRootDir)
                mUsbDir?.delete()
                if (mUsbDir?.mkdir() != true) throw IOException("failed create directory: " + mUsbDir.toString())
            } catch (e: IOException) {
                Log.e(TAG, "fail to create temp file")
            }
        }
    }

    @Throws(IOException::class)
    private fun createFsNode(connectionInfo: ConnectionInfo) {
        createUsbDir()
        val busDev = fakeBusDev()
        val devDir = File(mUsbDir, busDev.busNum.toString() + "-" + busDev.devNum)
        devDir.mkdir()
        connectionInfo.devDir = devDir
        createFile(devDir, "busnum", busDev.busNum.toString())
        createFile(devDir, "devnum", busDev.devNum.toString())
        createFile(devDir, "speed", 480.toString())
        val rawDescriptors = connectionInfo.con.rawDescriptors
        if (rawDescriptors == null) {
            Log.w(TAG, "raw descriptors is null, create empty descriptors file")
            createFile(devDir, "descriptors", ByteArray(0))
        } else {
            createFile(devDir, "descriptors", rawDescriptors)
        }
        createFile(devDir, "dev_fd", connectionInfo.con.fileDescriptor.toString())
    }

    private fun openGrantedDevice(device: UsbDevice) {
        if (!mUsbManager.hasPermission(device)) {
            notifyOpenResult(device, null, UsbError.ERR_PERMISSION)
            return
        }
        val con = mUsbManager.openDevice(device)
        if (con == null) {
            notifyOpenResult(device, null, UsbError.ERR_CONNECTION)
            return
        }
        val connectionInfo = ConnectionInfo(device, con)
        try {
            createFsNode(connectionInfo)
            Log.i(TAG, "usb fs dir: " + connectionInfo.devDir!!.absolutePath)
        } catch (e: IOException) {
            notifyOpenResult(device, null, UsbError.ERR_UNKNOWN)
            return
        }
        mConnections.add(connectionInfo)
        notifyOpenResult(device, con, 0)
    }

    private fun doOpenDevice(device: UsbDevice) {
        if (mUsbManager.hasPermission(device)) {
            openGrantedDevice(device)
            return
        }
        Log.i(TAG, "request permission: " + deviceName(device))
        val granted = requestAndWaitPermission(device)
        Log.i(TAG, "permission " + (if (granted) "granted" else "deny"))
        if (granted) {
            openGrantedDevice(device)
            return
        }
        notifyOpenResult(device, null, UsbError.ERR_PERMISSION)
    }

    private fun closeConnection(connectionInfo: ConnectionInfo) {
        try {
            deleteFile(connectionInfo.devDir)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        connectionInfo.con.close()
    }

    private fun doCloseDevice(device: UsbDevice) {
        var num = 0
        val itr = mConnections.iterator()
        while (itr.hasNext()) {
            val info = itr.next()
            if (device === info.device) {
                closeConnection(info)
                itr.remove()
                ++num
                Log.i(TAG, "device closed: " + deviceName(device))
            }
        }
        if (num != 1) {
            if (num == 0) {
                Log.w(TAG, "no matched device to close")
                Log.i(TAG, "total connection: " + mConnections.size)
                for (i in mConnections.indices) {
                    Log.i(
                        TAG, "con " + i + ":" + mConnections[i].device.hashCode() + deviceName(
                            mConnections[i].device
                        )
                    )
                }
            } else {
                Log.w(TAG, "closed $num usb connection")
            }
        }
    }

    private fun requestAndWaitPermission(device: UsbDevice): Boolean {
        if (mUsbManager.hasPermission(device)) return true
        synchronized(mPermissionSyncObj) {
            if (mPermPendingDevice != null) throw RuntimeException("request permission in bad state")
            mPermPendingDevice = device
            mPermissionState = UsbPermission.WaitingGrant

            val intent = Intent(APP_SERVICE_ACTION_USB_PERMISSION)
            val pendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                PendingIntent.getBroadcast(
                    mAppContext,
                    0,
                    intent,
                    (PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_ALLOW_UNSAFE_IMPLICIT_INTENT)
                )
            } else {
                PendingIntent.getBroadcast(
                    mAppContext,
                    0,
                    intent,
                    PendingIntent.FLAG_MUTABLE
                )
            }
            try {
                mUsbManager.requestPermission(device, pendingIntent)
            } catch (e: IllegalArgumentException) {
                e.printStackTrace()
                return false
            }
            while (mPermissionState == UsbPermission.WaitingGrant && mIsRunning) try {
                (mPermissionSyncObj as Object).wait(100)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
            if (!mIsRunning) {
                mPermPendingDevice = null
                mPermissionState = UsbPermission.Deny
            }
            val granted = mPermissionState == UsbPermission.Granted
            mPermPendingDevice = null
            return granted
        }
    }

    // call on main ui thread
    private fun onPermission(device: UsbDevice?, granted: Boolean) {
        Log.i(
            TAG,
            "onPermission: " + deviceName(device) + " " + (if (granted) "granted" else "deny")
        )
        synchronized(mPermissionSyncObj) {
            if (mPermissionState == UsbPermission.WaitingGrant && (device == null || isTheSameDevice(
                    device,
                    mPermPendingDevice
                ))
            ) {
                mPermissionState = if (granted) UsbPermission.Granted else UsbPermission.Deny
                (mPermissionSyncObj as Object).notifyAll()
            } else {
                Log.i(TAG, "device is not requesting permission, ignored")
            }
        }
    }

    // call on main ui thread
    private fun onDeviceAttached(device: UsbDevice?) {
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_SYS_DEVICE_ATTACHED, device))
    }

    // call on main ui thread
    private fun onDeviceDetached(device: UsbDevice?) {
        synchronized(mPermissionSyncObj) {
            if (mPermissionState == UsbPermission.WaitingGrant && (device == null || isTheSameDevice(
                    device,
                    mPermPendingDevice
                ))
            ) {
                Log.i(TAG, "device detached, but the device is waiting grant permission, as deny")
                mPermissionState = UsbPermission.Deny
                (mPermissionSyncObj as Object).notifyAll()
            }
        }
        mUsbHandler.sendMessage(mUsbHandler.obtainMessage(MSG_SYS_DEVICE_DETACHED, device))
    }

    private class UsbBroadcastReceiver(usbService: AppUsbService) : BroadcastReceiver() {
        private val mAppUsbService =
            WeakReference(usbService)

        override fun onReceive(context: Context, intent: Intent) {
            val usbService = mAppUsbService.get() ?: return
            val action = intent.action
            if (APP_SERVICE_ACTION_USB_PERMISSION == action) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                usbService.onPermission(device, granted)
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED == action) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                Log.i(TAG, "device attached: " + deviceName(device))
                usbService.onDeviceAttached(device)
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED == action) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                Log.i(TAG, "device detached: " + deviceName(device))
                usbService.onDeviceDetached(device)
            }
        }
    }

    companion object {
        private const val TAG = "AppUsbService"
        private const val APP_SERVICE_ACTION_USB_PERMISSION = "AppUsbService.USB_PERMISSION"
        private val mLoadSyncObject = Any()
        private var mLoaded = false
        private var mUsbSysRootDir: File? = null
        private const val MSG_ADD_OBSERVER = 0
        private const val MSG_REMOVE_OBSERVER = 1
        private const val MSG_OPEN_DEVICE = 2
        private const val MSG_CLOSE_DEVICE = 3
        private const val MSG_GET_DEVICE = 4
        private const val MSG_SYS_DEVICE_ATTACHED = 10
        private const val MSG_SYS_DEVICE_DETACHED = 11
        private const val MSG_QUIT = 20

        private fun deviceName(device: UsbDevice?): String {
            return if (device != null) {
                String.format(
                    Locale.getDefault(),
                    "%x:%x",
                    device.vendorId,
                    device.productId
                )
            } else {
                "null:null"
            }
        }

        @Throws(IOException::class)
        private fun deleteFile(f: File?) {
            if (f == null) return
            if (f.isDirectory) {
                val files = f.listFiles()
                if (files != null) {
                    for (c in files) deleteFile(c)
                }
            }
            if (!f.delete() && f.exists()) throw IOException("Failed to delete file: $f")
        }

        private fun isTheSameDevice(a: UsbDevice?, b: UsbDevice?): Boolean {
            return if ((a == null && b != null) || (a != null && b == null)) {
                false
            } else {
                a === b || a!!.vendorId == b!!.vendorId && a.productId == b.productId && a.deviceClass == b.deviceClass && a.deviceSubclass == b.deviceSubclass && a.deviceProtocol == b.deviceProtocol && a.interfaceCount == b.interfaceCount
            }
        }
    }
}
