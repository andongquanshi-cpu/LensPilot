package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.data.UsbDeviceCore

actual open class UsbObserver {
    actual fun onDeviceAttached(
        device: UsbDeviceCore?,
        filter: DeviceFilter?,
    ) {
    }

    actual fun onDeviceDetached(
        device: UsbDeviceCore?,
        filter: DeviceFilter?,
    ) {
    }

    actual open fun onDeviceOpenComplete(
        device: UsbDeviceCore?,
        con: UsbDeviceConnectionCore?,
        filter: DeviceFilter?,
        err: Int,
    ) {
    }

}