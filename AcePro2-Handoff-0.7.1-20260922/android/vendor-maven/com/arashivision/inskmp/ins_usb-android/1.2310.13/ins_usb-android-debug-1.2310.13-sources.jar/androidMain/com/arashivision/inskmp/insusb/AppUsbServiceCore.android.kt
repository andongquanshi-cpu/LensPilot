package com.arashivision.inskmp.insusb

import android.content.Context
import android.hardware.usb.UsbDevice
import android.util.Log
import com.arashivision.inskmp.insusb.data.UsbDeviceCore

actual class AppUsbServiceCore actual constructor(val context: Any?) {

    val appUsbService = AppUsbService(context as Context)
    actual fun getUsbSysPath(): String {
       return appUsbService.usbSysPath
    }

    actual fun getDevice(mDeviceFilter: DeviceFilter): UsbDeviceCore? {
        return UsbDeviceCore(appUsbService.getDevice(mDeviceFilter))
    }

    actual fun openDevice(device: UsbDeviceCore) {
        if (device.device == null) {
            Log.e("TAG", "no device found")
            return
        }
        appUsbService.openDevice(device.device as UsbDevice?)
    }

    actual fun addObserver(
        mDeviceFilter: DeviceFilter,
        observer: UsbObserver,
    ) {
        appUsbService.addObserver(mDeviceFilter, observer)
    }

    actual fun release() {
        appUsbService.release()
    }

}