package com.arashivision.inskmp.insusb

import com.arashivision.inskmp.insusb.callback.UsbCallbackCore
import com.arashivision.inskmp.insusb.data.UsbStateCore

actual class UsbManagerCore {
    
    companion object {
        // 静态初始化 JNI 库
        init {
            try {
                System.loadLibrary("insusb")
                println("[Kotlin] UsbManagerCore JNI 库加载成功！")
            } catch (e: Exception) {
                println("[Kotlin] UsbManagerCore JNI 库加载失败: ${e.message}")
            }
        }
    }

    private external fun nativeOpen(usbSysPath: String): Int
    private external fun nativeServe(): Int
    private external fun nativeSetSynced(synced: Boolean): Int
    private external fun nativeWrite(data: List<ByteArray>): Int
    private external fun nativeClose(): Int
    private external fun nativeSetCallback(): Int
    private external fun nativeClearJni(): Int

    // JNI 原生对象指针，由JNI层管理
    private var mNativeInstance: Long = 0
    
    private var config: String? = null
    private var callback: UsbCallbackCore? = null
    private var currentState: UsbStateCore = UsbStateCore.DISCONNECTED
    
    actual fun init(config: String): Int {
        this.config = config
        currentState = UsbStateCore.DISCONNECTED
        return 0
    }

    actual fun open(): Int {
        if (config == null) {
            println("[UsbManagerCore] Open(), but config == null!")
            return -1
        }
        
        currentState = UsbStateCore.CONNECTING
        try {
            // 调用 JNI OPEN函数！
            println("[UsbManagerCore] 调用 nativeOpen...")
            val result = nativeOpen(
                config!!)
            println("[UsbManagerCore] Usb 打开完成，result=$result")
            
            if (result == 0) {
                currentState = UsbStateCore.CONNECTED
                println("[UsbManagerCore] Usb 连接成功！")
            } else {
                currentState = UsbStateCore.ERROR
                println("[UsbManagerCore] Usb 连接失败，错误码: $result")
            }
            return result
        } catch (e: Exception) {
            currentState = UsbStateCore.ERROR
            println("[UsbManagerCore] Exception during JNI Usb open:: ${e.message}")
            return -1
        }
    }

    actual fun setCallback(callback: UsbCallbackCore?) {
        this.callback = callback

        // 如果callback不为null，确保JNI层已经初始化
        if (this.callback != null ) {
            try {
                // 初始化 JNI 层的全局引用
                nativeSetCallback()
                println("[UsbManagerCore] JNI Callback 初始化成功")
            } catch (e: Exception) {
                println("[UsbManagerCore] JNI Callback 初始化失败: ${e.message}")
                return
            }
        }

        println("[UsbManagerCore] Callback 设置成功: ${callback != null}")
    }

    // JNI 回调方法，供 C++ 层调用（参考 OneDriverJni.cpp 的 callInfoNotify）
    private fun onDataReceived(data: ByteArray) {
        println("[UsbManagerCore] C++ 层数据回调: 收到 ${data.size} 字节")
        callback?.onDataReceived(data)
    }

    private fun onError(errorCode: Int) {
        println("[UsbManagerCore] C++ 层错误回调: errorCode=$errorCode")
        currentState = UsbStateCore.ERROR
        callback?.onError(errorCode)
    }

    actual fun serve(): Int {
        if ( currentState != UsbStateCore.CONNECTED) {
            println("[UsbManagerCore] serve(), but Usb not opened")
            return -1
        }
        
        try {
            // 调用 JNI serve 函数
            println("[UsbManagerCore] 调用 nativeServe...")
            val result = nativeServe()
            println("[UsbManagerCore] Usb serve 完成，result=$result")
            
            if (result != 0) {
                currentState = UsbStateCore.ERROR
                println("[UsbManagerCore] Failed to start Usb serve via JNI")
            }
            return result
        } catch (e: Exception) {
            currentState = UsbStateCore.ERROR
            println("[UsbManagerCore] Exception during JNI Usb serve: ${e.message}")
            return -1
        }
    }

    actual fun setSynced(synced: Boolean): Int {
        if (currentState != UsbStateCore.CONNECTED) {
            println("[UsbManagerCore] setSynced, currentState != UsbStateCore.CONNECTED!")
            return -1
        }

        try {
            // 调用 JNI setSynced 函数
            println("[UsbManagerCore] 调用 nativeSetSynced...")
            val result = nativeSetSynced(synced)
            println("[UsbManagerCore] Usb setSynced 完成，result=$result")

            if (result != 0) {
                currentState = UsbStateCore.ERROR
                println("[UsbManagerCore] Failed to start UsbsetSynced via JNI")
            }
            return result
        } catch (e: Exception) {
            currentState = UsbStateCore.ERROR
            println("[UsbManagerCore] Exception during JNI Usb setSynced: ${e.message}")
            return -1
        }
    }

    actual fun write(data: List<ByteArray>): Int {
        if (currentState != UsbStateCore.CONNECTED) {
            println("[UsbManagerCore] write, but currentState != UsbStateCore.CONNECTED")
            return -1
        }
        
        try {
            // 调用 JNI write 函数
            println("[UsbManagerCore] 调用 nativeWrite，数据长度: ${data.size}")
            val result = nativeWrite(data)
            println("[UsbManagerCore] Usb write 完成，result=$result")
            
            if (result != 0) {
                println("[UsbManagerCore] Failed to write data to Usb via JNI")
            }
            return result
        } catch (e: Exception) {
            println("[UsbManagerCore] Exception during JNI Usb write: ${e.message}")
            return -1
        }
    }

    actual fun read(buffer: ByteArray): Int {
        if (currentState != UsbStateCore.CONNECTED) {
            println("[UsbManagerCore] read, but currentState != UsbStateCore.CONNECTED")
            return -1
        }
        
        try {
            // 注意：对于 JNI，read 操作通常通过回调处理
            // 这里返回 0 表示没有立即可用的数据
            println("[UsbManagerCore] read 操作 - JNI 版本通过回调处理数据")
            return 0
        } catch (e: Exception) {
            println("[UsbManagerCore] Exception during JNI Usb read: ${e.message}")
            return -1
        }
    }

    actual fun getState(): UsbStateCore {
        return currentState
    }

    actual fun close(): Int {
        try {
            // 调用 JNI close 函数
            println("[UsbManagerCore] 调用 nativeClose...")
            val result = nativeClose()
            println("[UsbManagerCore] Usb close 完成，result=$result")
            
            currentState = UsbStateCore.CLOSED
            return result
        } catch (e: Exception) {
            println("[UsbManagerCore] Exception during JNI Usb close: ${e.message}")
            return -1
        }
    }

    actual fun destroy() {
        // 释放kt和jni资源
        println("[UsbManagerCore] 调用 destroy...")
        
        // 1. 确保C++资源已清理
        if (currentState != UsbStateCore.CLOSED) {
            close()
        }
        
        // 2. 清理JNI层资源
        try {
            nativeClearJni()
            println("[UsbManagerCore] JNI 资源已清理")
        } catch (e: Exception) {
            println("[UsbManagerCore] 清理JNI资源失败: ${e.message}")
        }
        
        // 3. 清理Kotlin层资源
        mNativeInstance = 0
        config = null
        callback = null
        currentState = UsbStateCore.DISCONNECTED
        println("[UsbManagerCore] destroy 完成")
    }
}
