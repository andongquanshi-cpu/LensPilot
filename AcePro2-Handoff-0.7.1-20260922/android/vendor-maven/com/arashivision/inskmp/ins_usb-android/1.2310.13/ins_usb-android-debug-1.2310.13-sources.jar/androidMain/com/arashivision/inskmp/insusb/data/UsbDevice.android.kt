package com.arashivision.inskmp.insusb.data

import android.hardware.usb.UsbDevice

actual class UsbDeviceCore actual constructor(val device: Any?) {
    actual fun getInterfaceCount(): Int {
        return (device as UsbDevice).interfaceCount
    }

    actual fun getVendorId(): Int? {
        return (device as UsbDevice).vendorId
    }

    actual fun getProductName(): String? {
        return (device as UsbDevice).productName
    }

    actual fun getDeviceId(): Int? {
        return (device as UsbDevice).deviceId
    }


}